The "Asana Math" OpenType font includes all mathematical symbols
included in the latest version of Unicode. It includes a MATH 
table, which is an extension to OpenType font technology, that 
makes it possible to select glyphs for stretchy operators in a 
not-so-font-specific manner. The font has been successfully tested 
with XeTeX 0.99999 and Word 2007/2010/2016/2021. It was constructed using 
glyphs from the pxfonts of Young Ryu while many symbols were designed 
by the author. The name  Asana (Ἀσάνα, Asána) is the name of the 
mythological goddess Athena in the Doric dialect. The font is 
finished (?), but it is quite possible that users may find bugs 
and/or problems. Anyone who will find a bug or a problem, should 
contact the author and report her findings. 

*******************************************************************
NOTE: Ideally, the font should be installed systemwide. However,  *
the .TTC file should be installed only in Windows systems and it  *
is provided for people using FireFox, Word, etc. In addition, the *
.TTC file should not be included in a standard TeX installation.  *
On Unix or Unix-like system, an administrtor can install either   *
the .otf or the .TTC file in her system.                          *
*******************************************************************
WARNING: The .TTC file is a bit dated. I plan to update it when I *
will get some free time.                                          *
*******************************************************************

Apostolos Syropoulos
Xanthi, Greece
November 19, 2025

%%%% Copyright Information %%%%%%%%%%%%

Family:              Asana Math
Subfamily:           Regular
Full name:           Asana Math
PostScript name:     Asana-Math
Preferred family:    Asana Math
Preferred subfamily: Regular
Version:             Version 000.962 
Unique ID:           FontForge : Asana Math : 3-10-2007
Copyright:           Copyright (C) 2007-2025 Apostolos Syropoulos. 
Copyright (C) 2000 Young Ryu.
Copyright (C) 1997, 1999 Claudio Beccari.
License URL:         http://scripts.sil.org/ofl
License Description: Copyright (c) 2007-2025, Apostolos Syropoulos (<asyropoulos@yahoo.com),
with Reserved Font Name Asana Math.
Copyright (c) 2000 Young Ryu,
with Reserved Font Name pxfonts.
Copyright (c) 1997, 1999 Claudio Beccari, 
with Reserved Font Name gsmn1000.

This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at:
http://scripts.sil.org/OFL


-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded, 
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.
Vendor ID:           PfEd
