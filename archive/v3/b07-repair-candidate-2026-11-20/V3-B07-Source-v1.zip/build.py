"""Compile the V3 editorial candidate through the fixed ReadFlow configuration."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parent
ENTRY_DIR = ROOT / "layout" / "study"
NAME = "V3-B07-ReadFlow-R1.pdf"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def environment(output, font_dir):
    env = os.environ.copy()
    env["SOURCE_DATE_EPOCH"] = "1794950400"
    env["FORCE_SOURCE_DATE"] = "1"
    if font_dir:
        # Keep discovery local to this invocation. Noto Sans and DejaVu stay system faces.
        font_dir = font_dir.resolve(strict=True)
        config = output / "fontconfig.xml"
        config.write_text(
            '<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">'
            '<fontconfig><include>/etc/fonts/fonts.conf</include>'
            f'<dir>{escape(str(font_dir))}</dir></fontconfig>\n'
        )
        env["FONTCONFIG_FILE"] = str(config)
        env["OPENTYPEFONTS"] = str(font_dir) + os.pathsep + env.get("OPENTYPEFONTS", "")
    return env

def compile_manuscript(output, font_dir):
    env = environment(output, font_dir)
    cmd = ["xelatex", "-no-shell-escape", "-interaction=nonstopmode", "-file-line-error",
           "-halt-on-error", "-recorder", f"-output-directory={output}", "main.tex"]
    previous = None
    for attempt in range(1, 7):
        out = subprocess.run(cmd, cwd=ENTRY_DIR, env=env, capture_output=True, text=True)
        log_run = out.stdout + out.stderr
        (output / f"pass-{attempt}.txt").write_text(log_run)
        if out.returncode:
            raise SystemExit(log_run[-7200:])
        state = tuple(sha(p) if p.exists() else None
                      for p in (output / f"main.{ext}" for ext in ("aux", "toc", "out")))
        if state == previous:
            break
        previous = state
    else:
        raise SystemExit("Auxiliary files did not converge.")
    log = (output / "main.log").read_text(errors="replace")
    hard = re.findall(r"Missing character:.*|Undefined control sequence.*|LaTeX Warning: Reference.*"
                      r"|LaTeX Warning: There were undefined.*|.*multiply-defined.*"
                      r"|.*destination with the same identifier.*|Overfull \\[hv]box.*"
                      r"|Package fancyhdr Warning.*", log)
    if hard:
        raise SystemExit("\n".join(hard))
    pdf = output / NAME
    shutil.copyfile(output / "main.pdf", pdf)
    report = {
        "engine": subprocess.check_output(["xelatex","--version"],text=True).splitlines()[0],
        "entry": "layout/study/main.tex", "converged_passes": attempt, "pdf_sha256": sha(pdf),
        "errors_missing_glyphs_bad_refs_overfull": hard,
        "underfull": re.findall(r"Underfull \\[hv]box[^\n]*",log),
    }
    (output / "build.json").write_text(json.dumps(report,indent=2)+"\n")
    print(pdf)
    print(json.dumps(report,indent=2))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--font-dir",type=Path)
    parser.add_argument("--output-dir",type=Path,default=ROOT / ".build")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True,exist_ok=True)
    compile_manuscript(output,args.font_dir)

if __name__=="__main__":
    main()
