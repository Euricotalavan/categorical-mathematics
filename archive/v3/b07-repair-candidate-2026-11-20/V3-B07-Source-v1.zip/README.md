# Categorical Mathematics · Volume 3 · B-07 repair candidate

This source snapshot accompanies the 507-page `V3-B07-ReadFlow-R1.pdf`. `layout/study/main.tex` is the editable entry point. The 68 sections cover Chapters 52–70. The independent whole-volume mathematical review is pending.

## Rebuild the PDF

Use XeLaTeX and the installed ReadFlow TeX packages. `fonts/` contains the fixed supplement and its license notices. Install Noto Sans and DejaVu Sans Mono. The command runs XeLaTeX until the auxiliary files stabilize.

```sh
python3 build.py --font-dir "$PWD/fonts" --output-dir "$PWD/build"
```

For a Debian TeX Live installation that needs a local XeLaTeX format cache, the following setup was used for the V3 candidates.

```sh
mkdir -p .texfmt
env TEXMF=/usr/share/texlive/texmf-dist xetex -ini -etex \
  -jobname=xelatex -interaction=nonstopmode \
  -output-directory="$PWD/.texfmt" xelatex.ini
env TEXMF='{/usr/share/texlive/texmf-dist,/usr/share/texmf}' \
  TEXFORMATS="$PWD/.texfmt:" \
  python3 build.py --font-dir "$PWD/fonts" --output-dir "$PWD/build"
```

