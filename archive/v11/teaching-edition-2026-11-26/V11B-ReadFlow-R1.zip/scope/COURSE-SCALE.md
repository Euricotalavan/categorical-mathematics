# V11 B — locked before drafting
One semester, 8 chapters (146–153), **48 planned contact hours**. The original v4.1 card gives 4.5 hours per chapter and mathematical logic as a prerequisite; a finished V10 PDF ends at 145. English, ReadFlow R1.
- Core: 8 × 3 × 90 minutes = 36 hours. Each: 10 recall + 15 setup + 30 guided mathematical reasoning + 25 independent problem + 10 debrief. Real definitions, proof/construction, worked reasoning, reader check and answer, not just larger page count.
- Workshops: 8 × 45 minutes = 6 hours; new worked example, three distinct problems with complete solutions.
- Project: 2 × 90 minutes = 3 hours; linked tasks, solved instructor version, 100-point rubric.
- Assessment: 90-minute paper, four independent 25-point questions, separate worked answer key, plus 90-minute debrief = 3 hours.
Independently review each chapter and supplement, compile and visually confirm the PDF, reopen final native sources. This scale is a plan, not evidence from a classroom. Do not publish V11 to GitHub.
