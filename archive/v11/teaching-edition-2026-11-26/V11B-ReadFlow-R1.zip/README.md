# Categorical Mathematics: Volume 11

ReadFlow R1, Chapters 146--153, 87 PDF pages. Planned contact hours: 48. The hour estimates describe the manuscript schedule, not a classroom trial.

To rebuild, place the nine fonts listed in QA/readflow-fingerprints.json in source/fonts/ from the original adopted V0 ReadFlow R1 source bundle. The package does not redistribute the fonts. Use XeLaTeX with the ReadFlow packages, from source/layout/study. Run:

    xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode V6-ReadFlow-R1.tex

Run until the table of contents stabilizes. The filename is inherited from the layout driver; its document title and body are this volume.
