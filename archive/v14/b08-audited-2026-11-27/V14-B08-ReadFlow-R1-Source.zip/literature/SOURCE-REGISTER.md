# V14 文獻來源表

文獻盤點日期為 2026-11-27。L1、T、Y、TAO 是附表原有四筆。Y 依使用者指示列為選讀參考。L2、M 為另增的補充來源，正式採用範圍留待 B-01。各來源的版權標示以原件為準。

| ID | 固定或辨識版本 | 本次可讀與保存 | 實際核到的位置 |
| --- | --- | --- | --- |
| L1 | Jiří Lebl, *Basic Analysis I*, v6.3，2026-05-15 | 作者 PDF 312 頁全文，原檔在包中 | 封面、授權、目錄及正文抽查頁 29、51、87、113、162、171、181、200、228、235、237–240、255、264、274、279、284、288、291、296。印頁與 PDF 實體頁相同 |
| T | William F. Trench, *Introduction to Real Analysis*, Free Hyperlinked Edition 2.04，2013-12，Trinity 封裝版 | Trinity 總庫 PDF 587 頁全文，原檔在包中 | 封面、授權、目錄及正文抽查實體頁 10、39、107、122、137、145–146、149–154、181、189、210、244、248、252–254、267、270–272、276、279、528、536、542、546、555。PDF 與印頁的差距見定位表 |
| Y | 于品，《數學分析之課程講義（丘成桐數學英才班試用）》，封面 2020-12-27 | 公開 PDF 共 1001 頁。依使用者指示，僅作補充參考。包內附書目、連結和選讀定位 | 核封面、前言、聲明與相關目錄（PDF 1–11 頁），以及實體頁 116 的兩種函數列收斂、實體頁 193 的階梯函數逼近。若引用特定陳述或例子，回原頁核對 |
| TAO | Terence Tao, *Analysis II*, Fourth Edition，©2022，Springer eBook 2023-02-22，DOI/eISBN 對應 978-981-19-7284-3 | 官方卷首 PDF 14 頁，章 1–4 各 2 頁。正文其餘 UNKNOWN。出版社 PDF 以連結與指紋記錄 | 卷首題名頁、版權頁及目錄（PDF 3–4、12–13）。四個官方預覽均為實體頁 1–2，分別對應書本 pp. 1–2、23–24、39–40、65–66 |
| L2 | Jiří Lebl, *Basic Analysis II*, v6.3，2026-05-15 | 作者 PDF 217 頁全文，原檔在包中 | 封面、授權、目錄，正文抽查 pp. 144、153、155、157、161、172、176。優先定位 §11.2、§11.3。§11.6 只列延伸。印頁等於 PDF 實體頁 |
| M | Paige Bright, MIT OCW 18.S190, Lecture 5, *Complete Metric Spaces*，2023-01-24 | 官方講義 PDF 7 頁，原檔在包中 | pp. 1–3 的一致連續與不動點敘述、pp. 5–6 的度量完備化、p. 7 的來源聲明。印頁等於 PDF 實體頁 |

## 取得記錄與版本差異

- **L1、L2** 取自作者入口的同日 v6.3 PDF。L1 的 SHA-256 與本專案 math-extractor 曾用的 312 頁基線完全吻合，可重用既有驗證證據。作者亦提供 HTML 與 LaTeX。兩份 PDF 原樣附錄，本包採原件許可之一 CC BY-SA 4.0。[作者頁](https://www.jirka.org/ra/) · [L1 PDF](https://www.jirka.org/ra/realanal.pdf) · [L2 PDF](https://www.jirka.org/ra/realanal2.pdf) · [授權](https://creativecommons.org/licenses/by-sa/4.0/)
- **T** Trinity 書頁的全文下載已於本次取得。University of South Carolina 課程入口另提供同一 2.04 版的 586 頁封裝，PDF 位元及實體頁偏移不同，統一使用包內 Trinity 587 頁版本。2003 年 Pearson 版及限教師索取的解答手冊單獨區分。Trench 的反常積分補遺可在 Trinity 正式頁取得，與本卷目前規劃的正常 Riemann 積分邊界分開待定。原書採 CC BY-NC-SA 3.0，附入本非商業準備包的 PDF 保持原樣。[Trinity 書頁與補遺入口](https://digitalcommons.trinity.edu/mono/7/) · [Trinity PDF](https://digitalcommons.trinity.edu/cgi/viewcontent.cgi?article=1006&context=mono) · [South Carolina 同版封裝](https://people.math.sc.edu/girardi/m5545/TrenchBook/FreeHyperlinkedEdition2pt04.pdf) · [授權](https://creativecommons.org/licenses/by-nc-sa/3.0/)
- **Y** 專案提供的復旦 URL 實際為 217 頁課程文件，PDF 實體第 176、181 頁列于品於推薦書目。復旦另一個教材支撐頁也未列此講義。清華數學系作者頁可確認授課與聯絡入口。第三方彙整頁連至實際能開的 2020-12-27 PDF，講義前言明說該版在 2020 年 6 月稿後補了第三學期。2018 秋季的轉載目錄另有登入限制，版本勿互換。V14 只參考與本卷直接相干的小節，例如實數完備性、度量完備化、函數列收斂及 Riemann 積分的不同講法。[復旦課程 PDF](https://jwc.fudan.edu.cn/_upload/article/files/d4/56/707002a8413b8a3cc690244c1118/5f39341f-9c23-496e-807b-cc7ae77cd970.pdf) · [復旦教材頁](https://jwc.fudan.edu.cn/17/ed/c39500a464877/page.htm) · [清華作者頁](https://www.math.tsinghua.edu.cn/info/1125/2640.htm) · [2020-12-27 版公開 PDF](https://txj2006.github.io/files/math-resources/archive-2026-11-08-60.pdf) · [公開書目入口](https://txj2006.github.io/math-resources/) · [2018 轉載書目](https://mathtranslations.org/notes/413/)
- **TAO** Springer 書頁、四個章頁、卷首及四個兩頁章節預覽均核過。整本 PDF 入口回出版商書頁。清大 2026-11-14 書目快照列三筆線上館藏。本次可開啟 2022 筆的檢索外頁，授權正文尚未進入。後續依 ISBN 核 2022 版權年／2023 電子版記錄，2016 第三版及 2026 修訂印本分列。出版社顯示的 Fourth Edition 和平台內部 edition number 是不同欄位。第四版有作者勘誤，引用時應保留對應版本。取用校外正文可從清大館藏走正式登入流程。[Springer 第四版](https://link.springer.com/book/10.1007/978-981-19-7284-3) · [卷首與詳細目錄](https://link.springer.com/content/pdf/bfm:978-981-19-7284-3/1) · [清大館藏筆](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma9957417110206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw&search_scope=NTHU_holding&tab=LibraryCatalog) · [清大校外電子資源說明](https://www.lib.nthu.edu.tw/research/guide.html) · [作者頁與勘誤](https://terrytao.wordpress.com/books/analysis-ii/)
- **M** 補入一般度量完備化的證明入口，尤其是等距嵌入、稠密像、唯一到等距同構。PDF 原樣附錄，MIT OCW 依條款 CC BY-NC-SA 4.0。[正式課程](https://ocw.mit.edu/courses/18-s190-introduction-to-metric-spaces-january-iap-2023/pages/lecture-notes/) · [PDF](https://www.ocw.mit.edu/courses/18-s190-introduction-to-metric-spaces-january-iap-2023/mit18_s190iap23_lec5.pdf) · [授權條款](https://ocw.mit.edu/pages/privacy-and-terms-of-use/)

## Tao 可實讀的正文入口

| 章節 | 書本章範圍 | 已讀到的預覽 | 公開入口 |
| --- | --- | --- | --- |
| 1 Metric Spaces | 1–22 | pp. 1–2，§1.1 的距離公理與起始例子 | [官方預覽](https://page-one.springer.com/pdf/preview/10.1007/978-981-19-7284-3_1) |
| 2 Continuous Functions on Metric Spaces | 23–37 | pp. 23–24，§2.1 的連續性刻畫，部分證明由習題承接 | [官方預覽](https://page-one.springer.com/pdf/preview/10.1007/978-981-19-7284-3_2) |
| 3 Uniform Convergence | 39–64 | pp. 39–40，章首與 §3.1 的函數極限定義。§§3.2–3.7 目前僅目錄定位 | [官方預覽](https://page-one.springer.com/pdf/preview/10.1007/978-981-19-7284-3_3) |
| 4 Power Series | 65–92 | pp. 65–66，§4.1 的形式冪級數起頭 | [官方預覽](https://page-one.springer.com/pdf/preview/10.1007/978-981-19-7284-3_4) |

同一主題的其他書能支持各自的陳述與證明。Tao 版特有的定義、證明安排、假設與例題，待對到該版可讀正文再更新。于品講義依實際選讀段落引用。
