#!/usr/bin/env python3
"""Build the separate R1 fixture, or the volume after a fixed B-05 manifest."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

import prepare_fonts

ROOT = Path(__file__).resolve().parent
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_template():
    lock = json.loads((ROOT / 'engineering/TEMPLATE-LOCK.json').read_text())
    for record in lock['files']:
        path = ROOT / record['path']
        if path.stat().st_size != record['bytes'] or digest(path) != record['sha256']:
            raise SystemExit('Fixed template changed: ' + record['path'])

def verify_b05(path):
    if not path:
        raise SystemExit('Volume build requires --b05-manifest after the B-05 handoff.')
    data = json.loads(Path(path).read_text())
    if data.get('volume') != 14 or data.get('stage') != 'B-05' or data.get('status') != 'fixed':
        raise SystemExit('Expected a fixed V14 B-05 handoff manifest.')
    entries = {r['path']: r for r in data['files']}
    required = {f'chapters/ch{n}.tex' for n in range(179, 195)}
    if not required.issubset(entries):
        raise SystemExit('B-05 manifest must include all sixteen chapter files.')
    for name, record in entries.items():
        p = Path(name)
        if p.is_absolute() or '..' in p.parts:
            raise SystemExit('Unsafe B-05 manifest path: ' + name)
        if digest(ROOT / name) != record['sha256']:
            raise SystemExit('B-05 source mismatch: ' + name)
    return entries

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--entry', choices=['smoke', 'volume'], default='smoke')
    parser.add_argument('--b05-manifest')
    parser.add_argument('--clean', action='store_true')
    parser.add_argument('--debian-unindexed', action='store_true')
    args = parser.parse_args()
    verify_template()
    prepare_fonts.main()
    b05 = verify_b05(args.b05_manifest) if args.entry == 'volume' else None
    work = ROOT / 'layout/study'
    name = 'readflow-smoke' if args.entry == 'smoke' else 'V14-B06'
    source = '../../engineering/smoke/readflow-smoke.tex' if args.entry == 'smoke' else name + '.tex'
    output = ROOT / 'build' / args.entry
    if args.clean and output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(SOURCE_DATE_EPOCH='1795737600', FORCE_SOURCE_DATE='1')
    for key in ('FONTCONFIG_FILE', 'OSFONTDIR', 'OPENTYPEFONTS'):
        env.pop(key, None)
    if args.debian_unindexed:
        fmt = ROOT / 'build/format'
        fmt.mkdir(exist_ok=True)
        env.update(TEXMF='{/usr/share/texlive/texmf-dist,/usr/share/texmf}',
                   TEXFORMATS=str(fmt) + os.pathsep,
                   TEXMFVAR=str(ROOT / 'build/texmf-var'))
        if not (fmt / 'xelatex.fmt').exists():
            with (fmt / 'format-build.txt').open('wb') as stream:
                subprocess.run(['xetex', '-ini', '-etex', '-jobname=xelatex',
                    '-interaction=nonstopmode', '-output-directory=' + str(fmt), '*xelatex.ini'],
                    cwd=work, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
    previous = None
    for run in range(1, 7):
        log = output / f'pass-{run}.txt'
        with log.open('wb') as stream:
            result = subprocess.run(['xelatex', '-no-shell-escape', '-interaction=nonstopmode',
                '-halt-on-error', '-file-line-error', '-recorder',
                '-output-directory=' + str(output), source], cwd=work, env=env,
                stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            raise SystemExit(log.read_text(errors='replace')[-6000:])
        state = tuple(digest(output / (name + '.' + suffix))
            if (output / (name + '.' + suffix)).exists() else None for suffix in ('aux','toc','out'))
        if previous == state:
            break
        previous = state
    else:
        raise SystemExit('Auxiliary files failed to converge in six passes.')
    text = (output / (name + '.log')).read_text(errors='replace')
    bad = re.compile(r'Missing character:|Undefined control sequence|undefined references|'
        r'Reference .* undefined|multiply-defined|Overfull \\[hv]box|fancyhdr Warning|'
        r'Font shape .* undefined|destination with the same identifier', re.I)
    blocking = [line for line in text.splitlines() if bad.search(line)]
    local_inputs = {}
    for line in (output / (name + '.fls')).read_text().splitlines():
        if line.startswith('INPUT '):
            p = (work / line[6:]).resolve()
            if p.is_file() and p.is_relative_to(ROOT) and 'build' not in p.relative_to(ROOT).parts:
                local_inputs[str(p.relative_to(ROOT))] = digest(p)
    pdf = output / (name + '.pdf')
    if b05 is not None:
        for name, actual in local_inputs.items():
            if name.startswith('chapters/') and (name not in b05 or b05[name]['sha256'] != actual):
                raise SystemExit('Reachable chapter input absent from fixed B-05 manifest: ' + name)
    report = {'entry': args.entry, 'state': 'ENGINEERING_ONLY' if args.entry == 'smoke' else 'B06_CANDIDATE',
        'passes': run, 'pdf': str(pdf.relative_to(ROOT)), 'pdf_sha256': digest(pdf),
        'blocking_diagnostics': blocking,
        'underfull_diagnostics': [l for l in text.splitlines() if 'Underfull ' in l],
        'recorded_local_inputs': local_inputs,
        'visual_review': 'NOT_REPLACED_BY_THIS_BUILD',
        'math_review': 'NOT_PERFORMED_BY_THIS_BUILD'}
    (ROOT / f'qa/build-{args.entry}.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'recorded_local_inputs'}, indent=2))
    if blocking:
        raise SystemExit('Blocking diagnostics; see qa report.')

if __name__ == '__main__':
    main()
