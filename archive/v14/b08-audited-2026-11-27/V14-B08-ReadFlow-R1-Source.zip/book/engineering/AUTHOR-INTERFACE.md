# V14 author interface

State: engineering preparation only. Formal B-06 awaits the fixed B-05 handoff.
The adopted R1 config, shared base, and layout remain byte-for-byte unchanged.

Place chapter files at `chapters/ch179.tex` through `chapters/ch194.tex`.
Each begins with `\chapter{English title}\label{ch:179-topic}`. Do not put
`\documentclass`, `\begin{document}`, font settings, or counter resets in a chapter.
The entry sets the preceding chapter counter to 178 once. Use `\section` and
`\subsection`; section numbering follows the current chapter automatically.

Optional author-owned files are `chapters/notation.tex` (preamble commands),
`chapters/frontmatter.tex`, and `chapters/bibliography.tex`. All files actually
used in the final build must be fixed in the B-05 source manifest. The layout
engineer does not edit `chapters/` during preparation.

## Standard environments

```tex
\begin{definition}[Name]\label{def:179-topic}
  Complete assumptions, objects, conditions, and scope.
\end{definition}
\begin{theorem}[Name]\label{thm:179-topic}
  Complete statement.
\end{theorem}
\begin{proof}[Proof of Theorem~\ref{thm:179-topic}]
  \ProofStep{First goal}
  Complete argument.
\end{proof}
\begin{example}[Name]\label{ex:179-topic} ... \end{example}
\begin{problem}\label{prob:179-topic} ... \end{problem}
\begin{psolution} ... \end{psolution}
```

Also available: `proposition`, `lemma`, `corollary`, `remark`. These share
the chapter's `definition` counter; `problem` has its own chapter counter.
Equations are chapter-numbered. Standard `equation`, `align`, `multline`,
`enumerate`, `itemize`, `description`, and `tikzcd` work directly.

Use `\label` immediately after the opening theorem command, or on the relevant
equation row. Reference with `\ref` and `\eqref`. Use unique labels beginning
with `ch:`, `sec:`, `def:`, `thm:`, `prop:`, `lem:`, `cor:`, `ex:`, `rem:`,
`prob:`, or `eq:`, followed by chapter number and a stable descriptive suffix.

`\ReadFlowKeyIdea{title}{short key}{short reason}` is available only for a
genuinely short observation; it is unbreakable. Necessary proof remains in
the main proof environment. Do not put a long argument in a `minipage`,
`samepage`, or giant `aligned` block. Use `align` for long derivations that
may need page breaks; `aligned` and `split` cannot break across pages.

Do not redefine adopted commands, add package imports to chapter files,
insert artificial page quotas, or shrink wide formulas by scaling. Request
new preamble packages through the local engineer-owned adapter.

## Build and QA

Run from `book/`:

```sh
python build.py --entry smoke --clean --debian-unindexed
python engineering/pdf_qa.py build/smoke/readflow-smoke.pdf --fixture
```

The `--debian-unindexed` option supports this machine's unindexed TeX tree.
On a normal indexed TeX installation, omit it. Exact original fonts are
verified and recovered locally before every build; no fallback fonts are used.
Dependencies and license notices are retained from the published V13 package.

After the B-05 handoff, the manifest has this form:

```json
{"volume":14,"stage":"B-05","status":"fixed","files":[
  {"path":"chapters/ch179.tex","sha256":"actual SHA256"}
]}
```

Include all sixteen chapters and every notation/frontmatter/bibliography or
other input file, using actual hashes. The volume build refuses missing or
changed chapters. Then use:

```sh
python build.py --entry volume --clean --debian-unindexed --b05-manifest qa/B05-fixed.json
python engineering/pdf_qa.py build/volume/V14-B06.pdf
```

The build records reachable local inputs, PDF SHA256, converged logs, and
diagnostics. PDF QA checks extracted geometry and unintended light text;
these are engineering signals. Render and inspect every actual final page,
read each chapter in order, and record L/E/N/M issues and reflow effects.
Compilation, extraction, hashes, and zero overflow do not replace full-page
visual review or the independent B-07 mathematical audit.
