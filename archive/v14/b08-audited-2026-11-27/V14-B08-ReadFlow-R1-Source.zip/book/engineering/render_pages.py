#!/usr/bin/env python3
"""Render every PDF page and create a pending review ledger tied to its hash."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

import fitz

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pdf',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--dpi',type=int,default=144)
    args = parser.parse_args()
    pdf = args.pdf.resolve()
    target = args.output.resolve()
    # Never let new PDF pages silently mingle with a previous review's images.
    if target.exists() and any(target.iterdir()):
        raise SystemExit('Use a new empty output directory for each fixed PDF.')
    target.mkdir(parents=True,exist_ok=True)
    subprocess.run(['pdftoppm','-r',str(args.dpi),'-png',str(pdf),str(target/'page')],check=True)
    images = sorted(target.glob('page-*.png'),key=lambda p:int(p.stem.split('-')[-1]))
    document = fitz.open(pdf)
    if len(images) != len(document):
        raise SystemExit('Rendered image count does not match PDF page count.')
    record = {'pdf':str(pdf),'pdf_sha256':digest(pdf),'renderer':'Poppler pdftoppm',
              'dpi':args.dpi,'state':'RENDERED_NOT_REVIEWED','pages':[]}
    for index,(page,png) in enumerate(zip(document,images),1):
        record['pages'].append({'physical_page':index,'page_label':page.get_label(),
            'image':png.name,'image_sha256':digest(png),'visual_review':'PENDING',
            'sequential_reading':'PENDING','findings':[]})
    (target/'REVIEW-LEDGER.json').write_text(json.dumps(record,indent=2)+'\n')
    print(f'Rendered {len(images)} pages. All review states remain PENDING.')

if __name__ == '__main__':
    main()
