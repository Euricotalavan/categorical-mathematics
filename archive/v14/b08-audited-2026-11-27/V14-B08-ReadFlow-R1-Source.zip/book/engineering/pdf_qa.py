#!/usr/bin/env python3
"""Geometry/content/color diagnostics; never a substitute for visual review."""
import argparse
import hashlib
import json
from pathlib import Path
import fitz

def inspect(path, fixture=False):
    doc = fitz.open(path)
    out = {'pdf': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
           'pages': len(doc), 'metadata': doc.metadata, 'page_sizes': [], 'outside_media': [],
           'near_white_text': [], 'fixture_missing': [], 'bookmarks': doc.get_toc(),
           'visual_review': 'REQUIRED_SEPARATELY', 'mathematical_review': 'NOT_PERFORMED'}
    texts = []
    for index, page in enumerate(doc, 1):
        out['page_sizes'].append([index, round(page.rect.width,2), round(page.rect.height,2)])
        texts.append(page.get_text())
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines', []):
                for span in line['spans']:
                    if not span['text'].strip():
                        continue
                    rect = fitz.Rect(span['bbox'])
                    if rect.x0 < -0.5 or rect.y0 < -0.5 or rect.x1 > page.rect.width + 0.5 or rect.y1 > page.rect.height + 0.5:
                        out['outside_media'].append([index,span['text'],list(rect)])
                    rgb = [(span['color'] >> shift) & 255 for shift in (16,8,0)]
                    if min(rgb) > 235:
                        out['near_white_text'].append([index,span['text'],rgb])
    if fixture:
        alltext = '\n'.join(texts)
        for marker in ['Definition 179.1','Theorem 179.2','Example 179.3','Remark 179.4',
                       'Exercise 179.1','Proposition 179.5','Lemma 179.6','Corollary 179.7',
                       'Fixture footnote:','(179.1)']:
            if marker not in alltext:
                out['fixture_missing'].append(marker)
        out['fixture_content_scope'] = 'Presence checks only; no inference about V14 content.'
    out['engineering_status'] = 'FAIL' if any(out[k] for k in ['outside_media','near_white_text','fixture_missing']) else 'PASS_WITH_VISUAL_REVIEW_REQUIRED'
    return out

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('pdf',type=Path)
    p.add_argument('--fixture',action='store_true')
    p.add_argument('--output',type=Path)
    a = p.parse_args()
    record = inspect(a.pdf,a.fixture)
    target = a.output or a.pdf.with_suffix('.qa.json')
    target.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))
    raise SystemExit(record['engineering_status']=='FAIL')
