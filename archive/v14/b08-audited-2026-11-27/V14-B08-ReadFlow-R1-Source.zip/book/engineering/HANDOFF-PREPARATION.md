# V14 排版工程前置交接 v1.1

【交接】

交接 ID：V14-EDITOR-PREPARATION-v1.1；日期：2026-11-27 UTC。
發出：獨立行文排版子任務 `/root/editor`；接收：主控 `/root`。
對話 URL：UNKNOWN；傳遞：本 Work 內訊息及共享檔，接收實讀由主控回執。

卷／方案／階段：V14，B 單一 Work，Chapter 179–194；目前僅工程前置
READY。B-06 尚未開始，更未完成；B-05 固定正文、覆蓋及缺陷處置尚未收訖。
授權依據：主控轉達使用者已授權自動 B01–B08，本次派工限方法讀入、
正式 R1 工程準備與隔離冒煙。未上傳、未改 Git、未動 `chapters/`，未搬 V0 正文。
實際模型／推理強度：本子任務不能獨立查證，記未核實，不聲稱已切換模型或 High。

有效版本：正式 R1 artifact commit
`8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，ZIP SHA256
`5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。
採用三個共享模板檔逐位元保留。`engineering/TEMPLATE-LOCK.json` 列
每檔 bytes/hash，並保留原 `build.py`、`verify.py`、`MANIFEST.json`
於 `engineering/upstream/`。原腳本專屬 V0，故未拿它建新卷。

Git 接續基準：`ee4d2b7e723a32c2b58961e3903391c535fb8b07` 的公開 V13
工程包，章 167–178；本入口只設定前章值 178，依序 input 179–194。
V13 的字型原檔、完整 newpx archive、hash、授權與恢復工具保留；沒有
移入 V13 正文或其章別分頁特例。

已讀回執：`qa/PREPARATION-RECEIPT.json` 列實讀來源與逐檔 hash。
含 v2.1 導覽、20-Git-QA-v3、v4 第三篇、B 單一 Work、ReadFlow Study／
Operating／研究交接、固定 Git 成功分析與重用指南、METHODOLOGY、EDITOR-QA。
歷史研究的未採納文字按現行正式 R1 採納規則解讀，未用它更換模板。

唯一正文接口：`chapters/ch179.tex` … `chapters/ch194.tex` 由主控／作者管理。
排版入口 `layout/study/V14-B06.tex`，作者格式見 `AUTHOR-INTERFACE.md`。
目前只有另檔 `engineering/smoke/readflow-smoke.tex`；不構成 V14 正式正文。

改動與保留：新增 V14 字型命令局部橋接、卷別 metadata、三位數 TOC 欄寬、
空的局部分頁 patch 檔、build／QA 入口及隔離冒煙。共享幾何、字級、行距、
彩框、計數器不變。未做語義修改；未推測上游正文已通過。

來源／PDF 配對：冒煙以 `build.py` 兩輪收斂，PDF 四頁，SHA256
`86b459e4d44ee28f02c56c13e81bc5d8bb6c820d71497dc9c3f2568500e3071f`。
`qa/build-smoke.json` 列 XeLaTeX recorder 可達本地輸入 hash；
`qa/pdf-smoke.json` 列頁面尺寸、標識、書籤及顏色／頁界檢查。
清單總表見 `engineering/PREPARATION-MANIFEST.json`。

建置：在 `book/` 執行 `python build.py --entry smoke --clean --debian-unindexed`。
再執行 `python engineering/pdf_qa.py build/smoke/readflow-smoke.pdf --fixture`。
一般已索引 TeX 安裝可省略 `--debian-unindexed`。正式 volume build 必須收到
固定 B-05 manifest；會核全部 16 章及實際可達作者輸入。依賴為 Python3、
XeLaTeX 與 R1 TeX 套件；PDF QA 另需 PyMuPDF，渲染用 Poppler。

三層狀態：

|層次|本次證據與界線|
|---|---|
|內容保留|只核模板身份、冒煙標識／流水號／引用；未接正文，未做全卷語義／覆蓋核查|
|工程|兩輪收斂；無缺字、overfull、underfull、未解析引用或 header 警告；九字型臉原檔 hash 已核，實際使用的八臉均嵌入|
|視檢／閱讀|Poppler 四頁依序全頁實看；正式書名與標題三行斷行、TOC、章首、footnote、短 proof、共享定理流序、數字開頭 label、公式、圖、頁尾均無所見缺陷；只涵蓋冒煙|

負向控制：獨立故障 PDF 的白字被 QA 檢出；故意壞引用雖成功編 PDF，
仍被日誌檢查檢出。見 `qa/negative-controls.json`；故障檔只在 build 內，
不得混入正式交付。未聲稱所有裁切、數學遺漏或跨頁缺陷可自動檢出。

OPEN／UNKNOWN：

|ID|影響／責任／下一步|
|---|---|
|B06-WAIT-B05|阻正式 B06；主控交固定整合正文、來源覆蓋、記號、缺陷處置及 OPEN|
|FULL-VOLUME-READING|阻 B06 完成；排版正式編譯後逐頁視檢、逐章順讀，記具體 L/E/N/M 與重流|
|MODEL-MODE|實際模型與 High 未獨立核實|
|PRESS|本卷只準備閱讀版，未產印刷版；沒有印刷副作用已測的聲明|
|CROSS-PLATFORM|只測此機器；跨 OS／TeX／實體印刷／無障礙未測|
|HISTORICAL-UNKNOWN|16／22 映射、六全局門檻及歷史 OPEN 按舊紀錄保留，未解凍任何卷|

下一唯一階段：保持工程 READY，待主控另派正式 B-06；收到後先核實讀版本、
hash、B-05 整合證據，再行文排版。B06 候選只交打厚 B-07 唯一整卷終審；
回修仍回打厚。通過條件不是冒煙、頁數、hash 或工具全綠。

禁止重做／改動：不重造共享樣式、不改作者主稿、不搬歷史正文、不復活
雙 NO OBJECTIONS、不提早標 B06 完成，不上傳或改 Git。
待使用者決策：無；本前置工作無須新增批准。

更新 v1.1：正式書名及系列 metadata 已採用；隔離冒煙新增同一標題宏並重編／全頁視檢。逐頁視檢操作與正式輸出位置見 `B06-REVIEW-OPERATIONS.md`；渲染器 `render_pages.py` 對新 PDF 只產 PENDING ledger，絕不自動標審完。正式 B06 仍未開始。
