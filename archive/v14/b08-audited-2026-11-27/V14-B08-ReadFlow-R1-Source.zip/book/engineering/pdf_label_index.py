"""Locate every manuscript label in the exact compiled PDF."""
import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path
import re

import fitz


def brace_groups(text):
    depth = 0
    start = 0
    for position, char in enumerate(text):
        if position and text[position - 1] == "\\":
            continue
        if char == "{":
            if depth == 0:
                start = position + 1
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                yield text[start:position]


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--pdf", type=Path, required=True)
parser.add_argument("--aux", type=Path, required=True)
parser.add_argument("--source-index", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
known = json.loads(args.source_index.read_text())["label_locations"]
lookup = {}
for line in args.aux.read_text().splitlines():
    if line.startswith(r"\newlabel{"):
        label, props = brace_groups(line)
        if label in known:
            number, page_label, caption, target, extra = brace_groups(props)
            lookup[label] = (number, page_label, target)
if lookup.keys() != known.keys():
    raise SystemExit(f"Fixed source labels absent from the compiled auxiliary file: {sorted(known.keys() - lookup.keys())}")

digest = sha256(args.pdf.read_bytes()).hexdigest()
issues = []
with fitz.open(args.pdf) as pdf, args.output.open("w", newline="") as output:
    targets = pdf.resolve_names()
    writer = csv.writer(output)
    writer.writerow(("label", "source_file", "source_line", "reference_number", "printed_page", "physical_page", "destination", "pdf_sha256"))
    for label, (file, source_line) in known.items():
        number, printed, target = lookup[label]
        resolved = targets.get(target)
        if resolved is None:
            issues.append(f"Reader destination for {label} is missing from PDF: {target}")
            continue
        physical = resolved["page"] + 1
        if not 1 <= physical <= len(pdf) or pdf[physical - 1].get_label() != printed:
            issues.append(f"{label} jumps to physical {physical} / label {pdf[physical - 1].get_label()}, expected printed {printed}.")
        writer.writerow((label, file, source_line, number, printed, physical, target, digest))
if issues:
    raise SystemExit("\n".join(issues))
print(f"Verified {len(lookup)} manuscript destinations in {digest}")
