# V14 formal B-06 operations, prepared in advance

Current state: B-06 engineering and final152-page review completed for the R3 bounded-refit candidate.
The B-05 receipt and exact final source/PDF identities are in `qa/B06-HANDOFF.md`.
This procedure was prepared before B-05; the formal assignment and receipt then activated it.
The same B-07 auditor’s affected-scope final recheck remains the next stage.

The formal title is **Basic Analysis: One Variable, Metric Spaces, and
Sequences of Functions**. The title page uses three clear lines, while PDF
metadata retains the uninterrupted full title. Series: Categorical Mathematics;
Volume 14. Adopted R1 shared files are unchanged.

## Fixed paths

|Purpose|Path relative to `book/`|
|---|---|
|Formal entry|`layout/study/V14-B06.tex`|
|Author-owned manuscript|`chapters/ch179.tex` through `chapters/ch194.tex`|
|Local layout changes|`layout/study/v14-local-patches.tex`|
|B-05 input lock|`qa/B05-fixed.json` after actual handoff|
|Formal compiled candidate|`build/volume/V14-B06.pdf`|
|Final-pass log and recorder|`build/volume/V14-B06.log`, `V14-B06.fls`|
|Build report and reachable input hashes|`qa/build-volume.json`|
|PDF engineering report|`qa/pdf-volume.json`|
|Page images and pending review ledger|`qa/volume-pages-VERSION/`|

Use a fresh version directory for every changed candidate. Never attach a
previous PDF's completed visual review to a reflowed PDF by filename alone.

## Receive and fix inputs

Read the actual B-05 manuscript, notation, coverage, dependency receipt,
defect dispositions, KEEP scope, and important OPEN/UNKNOWN. Verify source
hashes against the handoff. Confirm Chapter 179 continues the published 178,
and verify formal metadata against the intended volume. Return a receipt
identifying exactly which files were read and which checks were completed.

Only after that receipt and the formal B-06 assignment:

```sh
python build.py --entry volume --clean --debian-unindexed --b05-manifest qa/B05-fixed.json
python engineering/pdf_qa.py build/volume/V14-B06.pdf --output qa/pdf-volume.json
python engineering/render_pages.py build/volume/V14-B06.pdf --output qa/volume-pages-VERSION
```

## Review every actual page

1. Open the full rendered image of each physical page in sequence. Record
   review against its image hash and PDF hash; a contact sheet is navigation,
   not completion evidence. Enlarge doubtful formulas and page boundaries.
2. Read each chapter continuously. Check the actual prerequisites at first use,
   readable scope and conditions, proof continuation, formula items, diagrams,
   exercises and solutions, and the adjoining chapter seam. This is a reading
   check; mathematical doubts go to the responsible content role.
3. Check title, TOC, bookmarks, chapter/section/theorem/exercise/equation numbers,
   references, footnotes, header/footer separation, clipping, white text, isolated
   headings, split short units, overlong unbreakable displays, and short tails.
   Treat density and whitespace as clues, without fixed page or character quotas.
4. Log concrete defects with ID, source and physical page, original text or
   layout, reader impact, L/E/N/M classification, responsible role, patch,
   retained obligations, and recheck evidence. Preserve all resolved history.
5. Make minimum authorized L/E changes; N/M changes return to content roles.
   After each accepted change, rebuild and check the full affected unit, adjacent
   pages, propagated reflow, and chapter seam. Refresh the hash-paired ledger.

A ledger entry becomes REVIEWED only after the image was actually inspected.
The document is not visually complete while any page is PENDING. Source/PDF
preservation, engineering, full-page viewing, and continuous chapter reading
must each be reported with their actual scope. None is mathematical final audit.

## Handoff

Fix the final source/PDF pair, reachable input manifest, coverage and dependency
identities, complete defect history, logs, page review evidence, and remaining
OPEN/UNKNOWN. Deliver the B-06 candidate solely to the independent B-07 thickening
auditor. All returns go back for B-07 recheck after the responsible role repairs
them. Publication and B-08 remain governed by the existing authorization.
