# V14 B-06 完整交接 R3

【交接】

交接 ID／文案版本／日期：V14-B06-R3-20261127／v1.0／2026-11-27 UTC。
發出：獨立行文排版官 `/root/editor`；接收：主控 `/root` 轉原獨立打厚 B-07 審查者。
對話 URL：UNKNOWN。本 Work 訊息及共享檔為送達主控證據；B-07 對本候選的最終實讀回執尚未收到。

V14，Categorical Mathematics / Volume 14；英文書名 **Basic Analysis: One Variable, Metric Spaces, and Sequences of Functions**。
方案 B 單一 Work，B-06 有界回修排版候選 R3 已完成；對應原 A 行文排版責任。下一唯一階段是回原打厚 B-07，核直接及傳遞影響。
本結論只含排版責任，不是數學通過、整卷驗收或已封存。

授權：使用者已授權自動 B01–B08；主控正式轉交 B07 四處缺漏回修，指定本官重編、核變動與回流、建立新配對證據。
固定正文只讀；沒有由本官另改任何正文、layout patch 或共用 R1。沒有上傳、改 Git、解凍／重做其他卷。實際模型／High 設定本官不能獨立查證，記未核實。

有效基線：唯一作者稿 `V14-B05-R2-B07-RECHECK`，18 輸入為16章加 frontmatter、bibliography。
B02 卷界／依賴／記號：`b02/B02-fixed.json`、`RESOLUTIONS.md`、`common-conventions.md`；來源責任入口 `b01/B01-fixed.json`。
適用 Git commit `ee4d2b7e723a32c2b58961e3903391c535fb8b07`；前卷末章178，本卷179–194正式接續。
前卷工程恢復路徑 `archive/v13/b08-audited-2026-11-27/V13-B08-ReadFlow-R1.zip`，只取工程依賴，不搬歷史正文。
正式 R1 artifact `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`；模板 ZIP SHA256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。
三個共用檔、上游腳本及九字型臉 hash 再核相同，見 `qa/B06-FINAL-IDENTITY.json`；共享樣式沒有升版。

| 本次權威固定檔 | SHA256 |
|---|---|
| `b07/INPUT-REVISION.md` | `c08c374d7938570aa614adf95e66d170d4b624a8376f6149e5cb531c244fe1ad` |
| `book/qa/B05-fixed.json` | `efa95697955b123e4a0010144cceea2a296d590c9edaf6f89569612b18d98088` |
| `b05/V14-coverage-verified.csv` | `b6ca1a9871b71b3c9a9fe83abbd3ca7fb34c48a3f087d6e330b5f64b4a6a0a10` |

回執：`qa/B06-RECEIPT.json`。已實讀修訂交接、四份差分、固定正文／證據身份和變動閱讀單元；18正文與11上游證據hash均核同。
本次內容角色只改 `ch179.tex`、`ch181.tex`、`ch182.tex`、`ch185.tex`；其它十二章、兩校準節、標籤順序與 shared R1 原樣保留。
四改文依序補有理環境sup/max、Trench識別號、可移除連續性對照、嚴格階梯誤差的等價及積分值。
數學查證及內容角色回覆保存於 `b07/repairs/`，本官沒有再寫另一份正文。

建置時收到的 B05 SHA 為 `068b06dcf4b414456a8d303010cc37cbc996a0111f833dd5ee3c70e8ebfa14ee`，coverage 為 `d3d7eab181d9cf02ca862db95e971a8ae58a559d22905bf58755bacd29246844`。
建置後主控只把證據 note 中舊 proposed/not-applied 字樣改成已套用對應，刷新上述最終固定hash；18 TeX 輸入及全部來源落點沒有再變。
本官實核最終 lock 全部18章輸入都與剛編的 `.fls`／build report一致；此 note-only 變更不重編 PDF。
B05覆蓋仍391落點列（375 VERIFIED、7 UNKNOWN、9 DEFERRED），分列狀態及原責任 ID 不變。
375 VERIFIED 的整段／子段行數界及正文 hash（前半 fixed_body、後半 baseline 欄）實核，無不符。330唯一label及103次引用（71不同目標）無缺目標。
本次身份／行界核對不取代來源／證明語義重核。

正式來源／PDF 配對：`book/build/volume/V14-B06.pdf`，652917 bytes，152實體頁，SHA256
`b3030ad435f25a2219fba4a3130aaeaed3747656a4c08b1047acd6cce915848e`。
入口 `book/layout/study/V14-B06.tex`；XeLaTeX乾淨三輪收斂，`.fls`實際可達輸入hash及警告在 `qa/build-volume.json` 與 `build/volume/V14-B06.log`。
正式工程報告 `qa/pdf-volume.json`，本次330定位 `qa/B06-label-locations.csv`。

在 `book/` 重建：

```sh
python build.py --entry volume --clean --debian-unindexed --b05-manifest qa/B05-fixed.json
python engineering/pdf_qa.py build/volume/V14-B06.pdf --output qa/pdf-volume-rebuilt.json
python engineering/pdf_label_index.py --pdf build/volume/V14-B06.pdf --aux build/volume/V14-B06.aux --source-index ../b05/chapter-inventory.json --output qa/B06-label-locations-rebuilt.csv
python engineering/render_pages.py build/volume/V14-B06.pdf --output qa/volume-pages-NEW --dpi 110
```

新渲染只產 PENDING，不自動把新 PDF 當審完。依賴 Python3、XeLaTeX/R1套件、PyMuPDF、Poppler；一般已索引 TeX 可省 `--debian-unindexed`。
九字型原臉及完整 newpx archive／原授權／恢復工具均在 `dependencies/`；正式PDF用了6臉，全部嵌入、子集、有Unicode映射。
詳細XeTeX／Poppler／PyMuPDF版本及字型輸出見 `qa/B06-ENVIRONMENT.json`。SOURCE_DATE_EPOCH=1795737600。
只測此機 Linux 閱讀版；沒有印刷版／跨OS／實體印刷／無障礙驗收的聲明。

| 三層責任 | R3證據與範圍 | 界線 |
|---|---|---|
| 內容保留 | 18最新固定作者輸入等於實際編譯輸入；變動只四章；330label、103引用、391覆蓋落點保持；新增公式及條件在變動頁完整呈現 | 本官核保留與可讀性，原 B07 審查者仍須核四改文及直接／傳遞影響 |
| 工程 | 三輪收斂，無缺字、overfull、未解析引用、duplicate destination或header硬警示；頁界／近白字零所見；330目的地逐一重算，152頁標唯一，98書籤、201內連、7外連 | 編譯／hash／抽取不能單獨當數學或視檢通過 |
| 閱讀／視檢 | 同 Poppler110dpi 渲染152頁；145頁PNG bytes和R2已實看頁完全相同；7改頁和8鄰頁共15頁重新全頁實看，另137頁按精確舊頁證據重用 | 沒有假稱R3全部152頁重新手動看過；首次R2全部152頁已真正依序視檢及整卷順讀 |

最終 ledger：`qa/volume-pages-r3-110/REVIEW-LEDGER.json`，綁本R3 PDF hash與逐頁PNG hash。
真正變動：實體8、9、35、40、41、42、79；另實看7、10、34、36、39、43、78、80作鄰頁、章縫及傳遞回流核驗。
15頁為 `REVIEWED_R3_ACTUAL`；其餘137頁為 `REUSED_R2_EXACT_IMAGE`，每頁明記R2 PDF hash、舊ledger hash、物理頁及完全相同image hash。無PENDING。
物理／印頁標與330跳轉在R3全部重新驗證；沒有頁號位移或下游章首變動。
中途另產的144dpi `volume-pages-r3/`是非正式中間渲染，沒有沿用其PENDING作審查證據；正式配對只用110dpi上述ledger。

R3布局結果：新增有理例的完整定義仍同頁，鄰頁補充順接；Trench名稱段落可讀；182.9完整保留三種限制／改值對照，Thomae例重流後成一整頁框，鄰節命題完整；185.7新增階梯公式與不等式同頁，185.8標題及正文相鄰，186章首未變。
無新增L/E/N/M版面或行文疑問，無新layout patch。修補正文來自授權內容角色，其數學通過仍以打厚回執為準。
原B06-L01–L26完整缺陷史保留在 `qa/B06-DEFECTS.md/.json`；26個修補後頁的PNG全與R2已核頁相同，故保持閉合。183.5仍實體56／印50。
局部Needspace、三位數TOC及卷別metadata原樣保留；未縮字、未加負間距、未把長證明整章包成不可分容器、未為湊頁改文。
B05 RN-01、NAR-M01、RN-02及本輪B07四項歷史均保留，不把舊問題抹掉或重算未修。

R3定位CSV由本官用更新 `b05/chapter-inventory.json` 實算330/330，SHA256
`30a7b7267ad7792d44cab3991e73155d4db5686c90cd6c3172bd3b81a3577d71`，與主控獨立回歸結果相同。
原7 underfull警告仍在實體64、66兩處、84、103、124、149；這些頁皆與R2視檢PNG相同。原接受理由逐條保留：普通積分說明與兩例標題字距展開，但可讀且無碰撞或遺失公式。
白字／壞引用負向試片仍隔離，結果 `qa/negative-controls.json`；不混進正式PDF。

舊R2交接／lock／coverage／locator由主控保留 `b07/initial-input/`；本官另保留 `book/qa/history/B06-R2/`、`book/build/volume-r2/` 與原全頁ledger／images。
原工程前置文件與R2交接是歷史，不當本次權威輸入。來源／PDF、工程／語義狀態分開；没有把初次讀16章的B07紀錄當此次新稿已終審。

完整檔案清單：`book/qa/B06-MANIFEST.json`。
每檔分列用途、完整路徑、版本、bytes、SHA256、核驗方法與可取位置，含當前正文／PDF／覆蓋／索引／模板／依賴／新舊視檢證據。
清單不含自身及本交接以避免hash循環，兩檔最終hash隨送達訊息提供。
本角色遵禁止上傳指令，未產新遠端ID；正式可恢復封存及遠端可見性由主控B08處理，沒有編造Library或Git回執。

| OPEN／UNKNOWN ID | 影響／責任／是否阻下一階段／下一步 |
|---|---|
| B07-R3-FINAL-RECHECK | 原打厚已讀前版16章並提出四修；本候選四改文及直接／傳遞影響仍待原打厚實讀複核；下一唯一階段本身 |
| TAO-UNKNOWN-7 | 後續原文證明頁未全取；內容精修／可帶限制交B07，不冒稱全來源已核 |
| DEFERRED-9 | 固定後卷／範圍外責任；擴充／不阻既定卷界，保留排除理由 |
| HISTORICAL-16-22／GLOBAL6 | 舊映射及六門檻仍UNKNOWN；原統籌／本次不解凍、不猜名清零 |
| MODEL-MODE | 實際模型／High未獨立核實；主控／如實保留 |
| PRESS／CROSS-PLATFORM／ACCESSIBILITY | 只驗此機閱讀版；其它用途需另驗，不阻本閱讀版B07 |
| REMOTE-RECOVERY | 本官未上傳；主控B08封存前核配對恢復、可見性與授權；不阻B07 |

下一角色唯一動作：主控鎖定本R3 source/PDF，同交原 B07 打厚審查者。接收者先回執實讀版本與hash，核四項內容及影響，再查完整既修史；有問題依類退相應角色，任何修後仍回打厚複核。
驗收條件為唯一打厚整卷／影響複核通過；不能用152頁、hash、工具全綠、視檢重用或兩份NO OBJECTIONS代替。
禁止重做：不重寫不受影響正文、不重造共享R1、不改章號／卷界／文獻表、不啟動其它卷、不提前稱整卷通過或封存。
待使用者決策：無。

【接收回執待填】

交接ID V14-B06-R3-20261127；接收者填實際讀入檔及SHA核對、可讀／缺檔／權限／衝突、角色／章號／凍結理解、接受續作或具體阻塞、下一動作及不重做範圍。
本官送達主控不等於原B07已實讀或已接受，本候選終審結果待該角色回執。
