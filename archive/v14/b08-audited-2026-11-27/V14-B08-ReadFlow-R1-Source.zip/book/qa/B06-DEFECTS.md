# V14 B06 layout defect disposition

Final candidate SHA256 `b3030ad435f25a2219fba4a3130aaeaed3747656a4c08b1047acd6cce915848e`; 26 R2 layout/electronic-location issues remain closed in R3: their fixed page images are byte-identical to R2, and destinations were reverified. R3 changed7 pages plus8 adjacent pages were actually viewed. Fixed author text is unchanged.

| ID | Original physical pages | Observed problem | Local repair | Final physical / printed pages | Status |
|---|---|---|---|---|---|
| B06-L01 | 1,2 | Duplicate roman i page label across unnumbered title page and first frontmatter page | Set page=2 immediately after maketitle in volume entry | 1,2 / i,ii | CLOSED |
| B06-L02 | 13,14 | Short Proposition 179.14 splits its final bounds across page; section 179.5 should travel with complete statement | Local pre-section guard chapter179 counter13 | 14 / 8 | CLOSED |
| B06-L03 | 16,17 | Short Proposition 180.5 leaves final sentence fragment in continued box | Local before-proposition guard chapter180 counter4 | 17 / 11 | CLOSED |
| B06-L04 | 17,18 | Section 180.4 first proposition splits its paired arithmetic display across pages | Local pre-section guard chapter180 counter6 | 18 / 12 | CLOSED |
| B06-L05 | 18,19 | Example180.8 starts with only its recurrence and breaks before the first verification | Local before-example minimum start guard chapter180 counter7 | 19 / 13 | CLOSED |
| B06-L06 | 22,23 | Section180.6 heading isolated above empty lower area; definition begins next page | Local pre-section guard chapter180 counter12 | 23 / 17 | CLOSED |
| B06-L07 | 23,24 | Moderate Example180.15 splits and produces a five-line continued chapter-ending page | Local before-example keep complete unit if short enough; recheck reflow | 24 / 18 | CLOSED |
| B06-L08 | 53,54 | Section183.5 anchor/bookmark lands previous page while visual heading next page | Parent index flagged; local section guard chapter183 counter10 plus anchor regression | 56 / 50 | CLOSED |
| B06-L09 | 33,34 | Example181.14 splits its coefficient computation from the short divergence estimate | before-example guard181 counter13 | 34 / 28 | CLOSED |
| B06-L10 | 35,36 | Short Definition182.2 leaves one final convention line in a continued box | before-definition guard182 counter1 | 37 / 31 | CLOSED |
| B06-L11 | 41,42 | Example182.13 leaves one concluding line on the next page | before-example guard182 counter12 | 43 / 37 | CLOSED |
| B06-L12 | 48,49 | Short Proposition183.2 begins with one assumption line and continues its defining formula on next page | before-proposition guard183 counter1 | 51 / 45 | CLOSED |
| B06-L13 | 58,59 | Short Theorem184.4 breaks its local derivative assumptions across pages | before-theorem guard184 counter3 | 61 / 55 | CLOSED |
| B06-L14 | 71,72 | Short Proposition185.9 separates integrability assumptions from formulas | before-proposition guard185 counter8 | 74 / 68 | CLOSED |
| B06-L15 | 73,74 | Short Proposition185.11 breaks endpoint hypotheses mid-sentence | before-proposition guard185 counter10 | 76 / 70 | CLOSED |
| B06-L16 | 83,84 | Two-line integration-by-parts recurrence breaks after first equality line | before-align* guard186 counter11 | 86 / 80 | CLOSED |
| B06-L17 | 125,126 | Short Theorem191.13 separates map hypothesis from convergence statement | before-theorem guard191 counter12 | 129 / 123 | CLOSED |
| B06-L18 | 126,127 | Short Definition191.15 strands singleton-interval qualification on next page | before-definition guard191 counter14 | 130 / 124 | CLOSED |
| B06-L19 | 131,132 | Short Proposition192.7 separates rectangle assumptions from the parameter integral formula | before-proposition guard192 counter6 | 135 / 129 | CLOSED |
| B06-L20 | 134,135 | Section193.2 heading isolated; central derivative-limit theorem begins next page | pre-section guard193 counter3 | 138 / 132 | CLOSED |
| B06-L21 | 136,137 | Section193.3 short Corollary193.7 splits its anchor assumption from conclusion | pre-section guard193 counter6 | 140 / 134 | CLOSED |
| B06-L22 | 139,140 | Short Theorem194.4 leaves absolute-convergence conclusion alone on next page | pre-section guard194 counter3 | 143 / 137 | CLOSED |
| B06-L23 | 140,141 | Theorem194.6 separates paired derivative/integral formulas across pages | before-theorem guard194 counter5 | 144 / 138 | CLOSED |
| B06-L24 | 54,55 | Short Proposition183.10 assumptions/results split after R1 reflow | before-proposition guard183 counter9 | 55 / 49 | CLOSED |
| B06-L25 | 62,63 | Short Definition184.7 continuity/Taylor qualifications split after R1 reflow | before-definition guard184 counter6 | 63 / 57 | CLOSED |
| B06-L26 | 87,88 | Paired exponential laws in Proposition186.15 split after R1 reflow | before-proposition guard186 counter14 | 88 / 82 | CLOSED |

All rows retain full original and final PDF hashes, responsibility and exact repair paths in `B06-DEFECTS.json`. L01 and L08 also affect electronic page/anchor behavior; the rest protect statement/argument continuity. No new E/N/M body defect was raised in B06.

Seven underfull diagnostics were each checked on final pages64,66(two),84,103,124,149 and accepted as readable prose/heading spacing. No overfull, missing-glyph, unresolved-reference, duplicate-destination or header warning remains.

Long examples remain breakable with numbered continuation titles; paired formulas and compact statements repaired locally. Chapter-end whitespace remains when the text is complete. B05 wording remains byte-identical; there is no replacement body text.

B05 RN-01, NAR-M01, RN-02 remain in the upstream closed-defect history. B06 does not replace the content roles or the B07 unique mathematical audit.

R3 bounded refit: no further body or layout edit by the editor. Content roles supplied the four authorized repairs. Full new paired reuse/actual ledger: `volume-pages-r3-110/REVIEW-LEDGER.json`.
