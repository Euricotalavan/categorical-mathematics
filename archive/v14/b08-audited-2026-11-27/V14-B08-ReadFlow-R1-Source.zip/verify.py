"""Verify a restored V14 archive's manifest and exact reviewed pair."""
from hashlib import sha256
import json
from pathlib import Path


root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text())
expected = {entry["path"] for entry in manifest["files"]}
actual = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file()}
untracked = actual - expected - {"MANIFEST.json"}
untracked = {name for name in untracked if not name.startswith(("book/build/", "book/dependencies/fonts/"))
             and "__pycache__" not in Path(name).parts}
if untracked or expected - actual:
    raise SystemExit(f"Archive differs from manifest. Untracked: {sorted(untracked)}. Missing: {sorted(expected - actual)}")
for entry in manifest["files"]:
    path = root / entry["path"]
    if not path.resolve().is_relative_to(root):
        raise SystemExit(f"Unsafe path: {path}")
    content = path.read_bytes()
    if len(content) != entry["bytes"] or sha256(content).hexdigest() != entry["sha256"]:
        raise SystemExit(f"File differs from manifest: {path}")

pair = manifest["audited_pair"]
for name in ("pdf", "source_lock", "candidate_lock", "audit"):
    item = pair[name]
    if item["path"] not in expected or sha256((root / item["path"]).read_bytes()).hexdigest() != item["sha256"]:
        raise SystemExit(f"The {name} differs from the audited pair.")
source_lock = json.loads((root / pair["source_lock"]["path"]).read_text())
for item in source_lock["files"]:
    path = root / "book" / item["path"]
    if sha256(path.read_bytes()).hexdigest() != item["sha256"]:
        raise SystemExit(f"Audited body changed: {path}")
candidate = json.loads((root / pair["candidate_lock"]["path"]).read_text())
audit = json.loads((root / pair["audit"]["path"]).read_text())
if (candidate["pdf"]["sha256"] != pair["pdf"]["sha256"]
        or audit["pdf_sha256"] != pair["pdf"]["sha256"]
        or audit["b05_sha256"] != pair["source_lock"]["sha256"]
        or audit["b06_candidate_sha256"] != pair["candidate_lock"]["sha256"]
        or audit["status"] != "PASS"):
    raise SystemExit("Audit approval and archive versions differ.")
print(f"PASS: {len(expected)} files, exact B-07 source and PDF, chapters 179–194")
