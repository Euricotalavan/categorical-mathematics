# V14 B-04 Chapter 181 | Thickening receipt

- Handoff `V14-B04-181-THICK-20261127`. Expansion → thickening → independent refinement. Scope is the seven sections of chapter 181. The main manuscript and layout are protected.
- Read the full raw chapter, B-02 real-half design and resolutions, and B-01 responsibilities V14-181-01–26. In this chapter, the last responsibility is a pointer to chapter 194. Chapters 179–180 provide the field, rational powers, and sequence tests.
- Raw `v14-work/b04/raw/real/ch181.tex`, 18785 bytes, SHA-256 `1c158176ef197ca8378db13a1d1bcd148e607d26afd93b41b7b7e3ccd23b7284`.
- Thick `v14-work/b04/thick/real/ch181.tex`, 22038 bytes, SHA-256 `e5824fe76ef98fbc8cffb629d3d0e1f7afc369ecfed634bc6fc3347fb589003e`.
- Diff `v14-work/b04/thick/real/ch181.diff`, 18268 bytes, SHA-256 `17b73f2b67a217191aea7376e98214c1a6f1e35c857ead9b85b616210015fa7f`. Replay against the raw chapter is byte-exact. All labels match.

| Responsibility suffix | Section and evidence |
| --- | --- |
| 01 | §181.1 defines partial sums and s₀, identifies a tail with shifted partial sums minus a fixed number, and reduces the series Cauchy criterion to sequence completeness. |
| 02 | §181.1 derives terms as differences of consecutive partial sums with equal limits. The harmonic counterexample realizes failure of the converse. |
| 03 | §181.1 uses finite cancellation, index-zero constant 1 including r=0, geometric powers, and the precise tail magnitude. At modulus at least 1 the terms violate the necessary term test. |
| 04 | §181.1 uses 2^k terms bounded below by 1/2^(k+1) for each dyadic block, giving unbounded selected partial sums. |
| 05 | §181.2 applies limit arithmetic only after convergence and writes ordered finite blocks by strictly increasing endpoints. Their partial sums form a subsequence. |
| 06 | §181.2 computes the two alternating-constant block groupings and exposes the divergent ungrouped partial sums. |
| 07 | §181.2 records separate definitions for nonnegative terms, absolute convergence, and conditional convergence; monotone convergence gives the positive-tail boundedness test. |
| 08 | §181.2 uses finite triangle and the Cauchy criterion to show absolute convergence suffices, then order preservation for the sum bound. |
| 09 | §181.3 removes only a finite initial segment for eventual comparison, and bounds the positive ratio between positive constants for limit comparison. |
| 10 | §181.3 covers p≤0 by the term test, 0<p≤1 by lower bounds for dyadic blocks, and p>1 by their geometric upper bounds even if a partial sum ends within a block. Only rational power laws used; real p in §186.6. |
| 11 | §181.3 bounds 1/(n²+1) by 1/n² and concludes convergence. |
| 12 | §181.3 uses a q strictly between the finite ratio limit and 1 for the small-ratio estimate, and the prior sequence estimate to fail the term test for ratio limit >1. |
| 13 | §181.3 computes 2/(n+1) for the factorial series. No exponential identification. |
| 14 | §181.3 gives the tail supremum step for root upper limit <1 and the infinitely-many-index criterion for root upper limit >1 including +∞. Harmonic and square reciprocal series exhibit both behaviors at root and ratio boundary 1. |
| 15 | §181.4 explicitly establishes s_even≤s_odd for any pair, bounds both monotone subsequences, uses zero gap, and sandwiches the full tail and the alternating remainder. |
| 16 | §181.4 checks n^-p→0 by rational powers, applies the alternating test and absolute divergence, then gives the failure when monotonicity is dropped. |
| 17 | §181.5 defines permutation on indices, preserving repeated values and every occurrence. |
| 18 | §181.5 uses the inclusion of a fixed head by surjectivity, and all unused terms are in the small absolute tail. Nonnegative rearranged absolute partial sums are bounded. |
| 19 | §181.5 proves alternating harmonic sign subseries are unbounded, computes the first zero-target crossings, and applies the general finite target construction. |
| 20 | §181.5 proves the two sign sums diverge by contradiction and enumerates positive, negative, and zero indices. Each completed stage advances both signs. For equal finite endpoints, first crossings have vanishing overshoot and bound intermediate sums. For ±∞, the single adverse-sign term gives a lower bound throughout each stage before sign symmetry for the other direction. For α<β, all four threshold pairs have B_(k−1)>A_k for k>1, so both actual crossings begin on the correct side, with errors bounded by the final positive or negative magnitude. Every stage sum is between d_k and max(e_(k−1),e_k). This and the arbitrarily late crossing endpoints prove each stated finite or infinite upper/lower limit. |
| 21 | §181.6 temporarily indexes both coefficients from zero and defines the Cauchy product by a finite sum. States convergence of both factors and absolute convergence of one. |
| 22 | §181.6 uses a bounded B_j tail and B, then fixes K by the absolute tail, takes a common threshold J of B_j for the finite head, and closes the three-error estimate for N≥K+J. |
| 23 | §181.6 checks each factor is conditionally convergent and every product coefficient magnitude is at least 1. |
| 24 | §181.7 checks the general finite p-to-q identity, including p=1 and p=q, and controls both ends plus variation with one threshold for all late p,q. |
| 25 | §181.7 proves the monotone-zero special case by telescoping and distinguishes the source terminology. |
| 26 | Formal radius, endpoints, and power-series algebra remain in §194.1. §181.7 supplies a scope pointer. |

No new mathematical blocker for independent refinement. Tao unavailable fourth-edition body remains UNKNOWN and Yu remains an optional reference. This receipt does not decide full-volume or layout acceptance.
