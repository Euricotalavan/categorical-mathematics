# V14 B-04 Chapter 179 | Thickening receipt

- Handoff `V14-B04-179-THICK-20261127`. Expansion → thickening → independent refinement. Scope is chapter 179 and its five sections. The main manuscript, material outside this chapter, and shared layout files are protected.
- Read the complete expansion copy, B-02 real design and main resolutions, and the nineteen chapter 179 responsibilities in B-01 real.csv. This pass checks the chapter's mathematics and use of prior material. Independent refinement checks source fidelity.
- Raw `v14-work/b04/raw/real/ch179.tex`, 15902 bytes, SHA-256 `82f41cfe8c3b536081273d9110457be6a4a647bfe1b9a4d0ca359386533fef02`.
- Thick `v14-work/b04/thick/real/ch179.tex`, 17364 bytes, SHA-256 `b53b26c193a32b43379511b4980e49c8667298145479e4dff0d6939de467f917`.
- Diff `v14-work/b04/thick/real/ch179.diff`, 9519 bytes, SHA-256 `445787a7e9a9c2dabe66f838132a509592927d0c5ed17545bb21814c8feb09a9`. Applying it to the raw copy reproduces the thick copy byte for byte. All five section labels and numbered-object labels match the raw copy.

| B-01 responsibility | Checked in the thick copy |
| --- | --- |
| V14-179-01 | §179.1 specifies the ordered field and its rational subfield, both identities, inverse domains, and total-order axioms. |
| V14-179-02 | §179.1 gives the negative/positive multiplication rules and square positivity. Establish product signs before inverse positivity. The reciprocal statement treats positive and negative domains separately. |
| V14-179-03 | §179.2 types bounds as real and explains the two level sets of comparisons for the least and greatest bounds. Uniqueness follows from antisymmetry. |
| V14-179-04 | §179.2 now gives an explicit interval point above any proposed upper bound below 1, and explains the included endpoint and finite extrema. |
| V14-179-05 | §179.2 assumes existence of a real supremum for nonempty subsets bounded above. The two conditions refer to the underlying real order. |
| V14-179-06 | §179.2 uses the order-reversing bijection between sets of bounds under negation and applies the supremum approximation lemma. |
| V14-179-07 | §179.2 handles the two strict signs of the rational candidate's square by a rational perturbation chosen algebraically. Equality is ruled out by the parity argument. |
| V14-179-08 | §179.3 chooses x/2 if x>0. When applied to the nonnegative absolute value, the case definition gives x=0. |
| V14-179-09 | §179.3 specializes the integer root theorem to 2 and n=2. The general proof gives a positive feasible point and a finite upper bound, excludes both sides of the target, and uses strict increase for uniqueness. No IVT. |
| V14-179-10 | §179.3 uses supremum approximation on the hypothetical bounded natural numbers, then proves the integer part using a bounded finite list covering negative t. Consecutive integer order gives uniqueness. The rational density construction stays strictly inside the interval. |
| V14-179-11 | §179.3 uses the Archimedean bound for 1/n and shifts a rational point by the proved irrational square root. |
| V14-179-12 | §179.4 uses the §179.2 approximation lemma under translation and positive scaling and the order reversal for negative scaling. Infimum approximation has already been derived. |
| V14-179-13 | §179.4 verifies the independent quantifiers give a lower bound for B. Same-input comparison is tested with f=g=identity on [0,1]. |
| V14-179-14 | §179.4 computes infimum 0 by the earlier 1/n estimate, so the bound comparison loses strictness. |
| V14-179-15 | §179.4 explicitly records the empty and unbounded cases in the extended order. Arithmetic of new symbols is outside this convention. |
| V14-179-16 | §179.5 proves interval equivalence from the case definition first, then proves the triangle inequality and absolute product rule including zero. Exchange of inputs gives reverse triangle and induction gives the finite-sum inequality. |
| V14-179-17 | §179.5 gives a single uniform real bound M for all domain points, and relates extrema notation to the image set. Finite extrema assertions exclude the empty domain. |
| V14-179-18 | §179.5 checks all three summands in the bound 71 and supplies an unboundedness witness family on the whole real line. |
| V14-179-19 | §179.3 avoids the ambiguous 0^0 monomial by treating zero separately in strict power increase. Equal exponent representations and composition are verified by the exact common power nq. Product and reciprocal identities cover negative numerators. Strict order uses positive roots and positive integer powers. |

Separate B-02 nested interval responsibility `A179-NEST` is proved in §179.4. For every fixed k, a_n≤b_k for all n by the two nesting directions. The supremum of all left endpoints is therefore in every interval. The direct difference bound and arbitrarily small lengths give uniqueness without invoking sequence convergence. This remains the input for chapters 180 and 182.

Tao unavailable fourth-edition body remains UNKNOWN. Yu remains optional reference. No new blocking mathematical issue was found for transfer to independent refinement. Full-volume mathematics and layout are outside this receipt.
