# V14 B-04 Chapter 185 | Thickening receipt

- Handoff `V14-B04-185-THICK-20261127`. Read all eight sections, the 26 B-01 responsibilities, and B-02 real-half design. The approved B-03 §185.3, with its two hyperlink substitutions already in the raw chapter, is preserved byte for byte in this pass. The new upstream notation, refinement results, and later uses of its tagged-sum characterization were checked.
- Raw `v14-work/b04/raw/real/ch185.tex`, 32308 bytes, SHA-256 `7a8e65cab73bd5c68fc02618d03b42ba95830dab109e1718908bf7fe3d0984b5`.
- Thick `v14-work/b04/thick/real/ch185.tex`, 33824 bytes, SHA-256 `b8e344ffcff97b30270c3f54ac3022d2a5797149acb30d55ea149196494569ed`.
- Diff `v14-work/b04/thick/real/ch185.diff`, 17309 bytes, SHA-256 `0abf15d2d74a89fad2caacbb270eb8bbdb37962c7a0ea0488abdf863da1a824d`. Replay is byte exact. All eight section labels and all numbered-object labels match.

| Responsibility suffix | Checked evidence |
| --- | --- |
| 01 | §185.1 records the positive lengths, finite index set, mesh, precisely one tag in each closed subinterval, and the corresponding sum. |
| 02 | §185.1 takes both extrema on each nonempty closed subinterval, with boundedness and no attainment requirement. |
| 03 | §185.1 bounds both Darboux sums by the global constants multiplied by total length. |
| 04 | §185.1 defines both finite Darboux integrals and integrability when equal. For a large domain it is the closed-interval restriction that must be bounded. |
| 05 | §185.1 uses rational and irrational density to compute local infimum 0 and supremum 1, proving the bounded Dirichlet function is not integrable. |
| 06 | §185.2 inserts a new division point in a subinterval's interior, compares both changes, iterates over a finite sequence of insertions, and uses the sorted union for a common refinement. |
| 07 | §185.2 puts arbitrary lower and upper sums in order using their common refinement, then takes sup and inf in that order. |
| 08 | §185.2 bounds the integral gap by every partition gap. Necessity chooses one partition near each extremum and takes the common refinement. |
| 09 | §185.3 retains the universal tagged-sum theorem and both proofs, including first deriving boundedness from two sets of tags differing at one point, and obtaining the same integral value in both directions. |
| 10 | §185.3 retains both insertion estimates with 2Mr mesh, counting only cells with a new interior division point and explicitly covering zero bound or zero inserted points. |
| 11 | §185.3 retains two tag families with sums 0 and 1 on the same uniform partitions, giving failure for every candidate limit. |
| 12 | §185.4 checks constant sums, spikes with at most two short cells, and each step function by a sufficiently fine refinement of its representing partition. Finite point values change only a controlled set of cells. |
| 13 | §185.4 telescopes the uniform-partition gap for 1/(1+x), without assigning a logarithmic value. |
| 14 | §185.4 states the singleton and reversed-endpoint conventions and keeps the bounds and fixed parameters separate from the bound integration variable. |
| 15 | §185.5 uses partitions containing the cut, the independent restrictions on the two closed pieces, and upper/lower approximation on both pieces. Splitting the nonnegative gaps proves integrability in both directions and gives closed-interval restriction. |
| 16 | §185.5 uses signed scaling of extrema, explicitly including the exchange of upper/lower integrals for negative scalars. For addition, a common signed oscillation estimate proves integrability and the smaller of the two mesh cutoffs proves exact equality by §185.3. Comparison and constants give the bounds. |
| 17 | §185.5 proves only upper subadditivity and lower superadditivity for bounded inputs. Dirichlet and its negative make both inequalities strict. |
| 18 | §185.5 verifies the absolute-value and product oscillation estimates and a common refined good partition. The product estimate permits general signs and bounds either zero coefficient. |
| 19 | §185.6 uses real-variable closed-interval boundedness and uniform continuity from chapter 182. A mesh cutoff then controls the sum of oscillations. |
| 20 | §185.6 first controls both endpoint cells by a single global bound, combines with a small interior gap, and proves whole integrability. Only then uses interval addition and the integral bound on each remaining endpoint portion. |
| 21 | §185.6 chooses a finite fine partition, with at most 2r closed cells meeting r exceptional points. Refine only the continuous cells so the total gap is small. A finite difference of point spikes has integral zero; the Thomae discussion rules out arbitrary countable modification. |
| 22 | §185.6 uses bounded endpoints of a real monotone function and the telescoping sum of local variations times mesh. Constant and decreasing cases are checked. |
| 23 | §185.6 uses finitely many bounded-denominator inputs and at most two bad cells for each, including division-point duplications, with r=0 separation. The remaining cells have small supremum, and all infima are zero by irrational density. |
| 24 | §185.7 treats V=0 before forming the weighted ratio. The attained interval image of u permits endpoint ratios and a singleton image. An interval of positive lower bound around a point with u>0 prevents zero integral of continuous nonnegative u. |
| 25 | §185.7 proves step-integral independence by common refinement and isolates division-point values, with a concrete overlapping indicator example. For an envelope from a partition the step constants on each open piece are the extrema on its corresponding closed subinterval, and both envelopes equal f at division points. This supplies precisely the L/U integrals asserted. The converse uses both Darboux integrals separately. Yu's treatment is supplementary only. |
| 26 | §185.8 confines proved results to the finite, bounded Riemann theory and names the adjacent settings without adding their existence criteria. |

Critical raw defect fixed in §185.7: open-piece extrema need not equal closed-piece extrema, so they cannot justify the former assertion of equality to L/U. Choosing the closed-piece extrema preserves the enclosure and proves the asserted values. Tao unavailable body remains UNKNOWN. No new blocker found for independent refinement. Main source, template and other chapters were not changed.
