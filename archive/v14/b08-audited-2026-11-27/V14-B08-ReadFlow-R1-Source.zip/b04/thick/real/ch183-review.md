# V14 B-04 Chapter 183 | Thickening receipt

- Handoff `V14-B04-183-THICK-20261127`. Read all six sections, B-01 V14-183-01–20, B-02 design and resolutions. The main manuscript and shared layout remain outside this edit.
- Raw `v14-work/b04/raw/real/ch183.tex`, 15762 bytes, SHA-256 `a8a53d05e2a02e801a43e92937accdfeb93cf14893860b75edbd974c7d70bc57`.
- Thick `v14-work/b04/thick/real/ch183.tex`, 17314 bytes, SHA-256 `261f7da88994f91d15710baebf67a8f7885f63c33b54719d288974f2d2117987`.
- Diff `v14-work/b04/thick/real/ch183.diff`, 11552 bytes, SHA-256 `d775b621cf8cc106b3e66666066d96c8846ca00d2481b2b08db14f7db6da23b2`. Replay is byte exact. All six section labels and other labels agree.

| Responsibility suffix | Checked evidence |
| --- | --- |
| 01 | §183.1 defines the quotient on the punctured relative domain and a finite derivative. Nondegenerate interval excludes isolated inputs; the available side determines included endpoint derivatives. |
| 02 | §183.1 checks the square and affine quotient, and rationalizes the square root for c>0 under the nonzero limiting denominator. |
| 03 | §183.1 computes the two values ±1 for the absolute-value quotient at 0; differentiability fails in spite of continuity. |
| 04 | §183.1 gives the exact local error coefficient on the relative domain, defines it at c, proves both directions and uses bounded coefficient times x−c to obtain continuity. |
| 05 | §183.2 starts with a common interval for addition and linearity, then uses the product and reciprocal rules for integral powers. Negative powers exclude 0. |
| 06 | §183.2 gives the exact product splitting and the reciprocal identity on a relative neighborhood where the denominator stays away from zero. |
| 07 | §183.2 fills the outer difference quotient at d by f′(d), checks the zero-inner-difference branch explicitly, and obtains convergence of the first factor by continuity. A constant inner function exercises the zero branch. |
| 08 | §183.3 specifies relative/strict local extrema, interior critical points, and the relative endpoint convention for C¹. |
| 09 | §183.3 uses opposite signs of the two local-minimum quotients at an interior point. Negation treats a maximum. The x³ and identity examples check insufficient converse and endpoint distinction. |
| 10 | §183.3 applies the extreme-value theorem under the correct interval regularity. Compares an interior value with the common endpoint value to find an interior extremum, with constant case separate. |
| 11 | §183.3 checks equal endpoint values for absolute value but no existing zero derivative. |
| 12 | §183.4 writes the matching affine function, verifies Rolle's conditions, then treats the Cauchy combination and proves both denominators nonzero before division. |
| 13 | §183.4 restricts MVT to the closed segment between any two domain points, and uses the difference of two functions for equal derivatives. The disjoint interval example records the connected-domain requirement. |
| 14 | §183.4 verifies nonnegative derivative ⇔ nondecreasing, positive ⇒ strictly increasing, and sign reversal. The forward implication uses MVT and the converse uses both one-sided signs of the difference quotient. |
| 15 | §183.4 checks x³ as strictly increasing with zero derivative at 0. |
| 16 | §183.4 uses MVT for arbitrary ordered x,y to transfer the uniform derivative bound to the Lipschitz estimate. |
| 17 | §183.4 proves the first-derivative sign test by segments containing c, and gives both endpoint quotient identities with interval-local MVT point estimates. |
| 18 | §183.5 uses f−λx and signed derivative quotients to exclude endpoints as minimizers, then continuity of the original auxiliary function and Fermat. No continuity of f′ is used. |
| 19 | §183.5 verifies the same φ has matching endpoint derivatives and continuous derivative. The corrected F=x²(2+φ(1/x)) has a strict minimum at 0 and vanishing derivative there. Evaluations at 1/n and 1/(n+1/2) have distinct derivative limits and opposite eventual signs. |
| 20 | §183.6 gives the finite local rule with continuous endpoint values 0/0, punctured derivative hypotheses, and separate one-sided domains. Rolle first excludes zeros of g, then Cauchy MVT places each derivative ratio at a strict intermediate point under the same ε radius. The |x|/x example diagnoses a failed ratio-limit hypothesis. |

The B-02 inverse derivative responsibility A183-INV is verified in §183.2. A strictly monotone continuous map sends the interior c to an interior point of its interval image. The inverse is relatively continuous by §182.7; its punctured difference quotients are reciprocals of nonvanishing original difference quotients, with nonzero limiting denominator. The adopted φ uses the resolutions' 2+φ case, rather than the older proposal in the design narrative. Tao unavailable text remains UNKNOWN; Yu remains optional. Ready for independent refinement.
