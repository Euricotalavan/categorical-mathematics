# V14 B-07 統一缺陷與複核表

終審角色 `/root/auditor`。第一次獨立閱讀對應 B06-R2，PDF SHA-256 `154c7be281d048b0cc2a8389676c577daf1f3c2b1e18aa4f9299254ac1d33381`；回修正文與 R3 PDF SHA-256 `b3030ad435f25a2219fba4a3130aaeaed3747656a4c08b1047acd6cce915848e` 已核。頁碼從 1 起算，實體頁 7 起對應正文印頁 1。

## 終審四處正文責任修補

| ID／原文位置與影響 | 改文和來源 | 責任、重核證據與處置 |
|---|---|---|
| B07-01，`ch182.tex:228–231`，R2 實體頁 40。原正文證明單點尖峰原域不連續和 singleton 限制連續，缺刪去和改值可修該點的辨識。 | `repairs/B07-01-ch182.diff`。R3 `ch182.tex:228–248` 逐任意誤差核去心極限 0，說明兩種域與改點方式，以及另例的不同單側極限。Lebl I v6.3 PDF 127 Ex. 3.2.13。 | 精修交件、主控合入，終審重播差分，核第 182.1–3、185.4 和 186.3 的定義與用例。R3 實體頁 40／印 34，Example 182.9 同頁完整，h 連到 182.2，且「at that point」在場。已結。 |
| B07-02，`ch185.tex:745–769`，R2 實體頁 78–79。原正文證成上下階梯包絡，但未交代選讀的嚴格階梯誤差法及兩者關係。 | `repairs/B07-02-ch185.diff`。R3 `ch185.tex:771–800` 用 \(s_n,\psi_n\) 的誤差積分給 Cauchy 與同值，以 \(s_n\pm\psi_n\) 和包絡中點加正鬆弛作兩方向。于品固定 PDF 193–194，Lemma 118 和 Definitions 119–120。 | 精修交件、主控合入，終審核原書視覺的誤差絕對值、第 185.4–7 的有限階梯、線性和包絡，及第 186、192–194 的正常積分依賴。R3 實體頁 79／印 73 全段及三個展示式皆可見，章末邊界相接。已結。 |
| B07-03，`ch179.tex:67–76`，R2 實體頁 8。原有實數兩例；固定責任另以指定有理環境核上下界與是否取到。 | `repairs/B07-03-ch179.diff`。R3 `ch179.tex:78–83` 對有理 \(u<1\) 取 \((1+u)/2\) 仍在有理域。由兩個集合與 1 的成員關係辨識 supremum 和 maximum。Lebl I v6.3 PDF 24。 | 精修交件、主控合入，終審查兩個實例及有理缺口反例的先後，後文仍採原實數完備公理。R3 實體頁 8／印 2 有完整新增段落，續頁 9 原證明完備。已結。 |
| B07-04，`ch181.tex:483–486`，R2 實體頁 35。原 Trench 命名沒有作者原條號，讀者循條號核假設缺一定位。 | `repairs/B07-04-ch181.diff`。R3 `ch181.tex:483–486` 明列 Trench's Corollary 4.3.21。Trinity 587 頁版 PDF 229／印 219。 | 精修交件、主控合入，終審核 181.7 單調零列及有界部分和條件與呈現。R3 實體頁 35／印 29 可見原條號、Abel 命名和上下文。已結。 |

## 既有內容問題

B-03 與 B-04 的原文和改文以各固定 `.diff` 為逐字證據。重播 B-03 四步及 B-04 三十二步，共三十五個有變更補丁，另有一對相同正文。第 179–192 章精修輸出與 B06-R2 正文一致。193、194 的 B-05 補丁亦以 `--fuzz=0` 重播並逐位元符合 R2。下表記錄主要證明與相鄰用法的複核，逐節來源責任另見正文覆蓋表。

| 舊問題及位置 | 原問題與讀者影響 | 已見改文和 B-07 複核證據 |
|---|---|---|
| B-03 §185.3，185-09–11 | 加細後分割型別和兩端夾界需分步，反例需明示任意 mesh 門檻。 | `b03/{thick,refined}/sec185-3.diff`。以去重排序定新分割，先證反向有界再用上下和，任意 δ 可取 1/n 小於 δ。重讀現 §185.3 的全標記量詞與同積分值。 |
| B-03 §191.1，191-01–06、21 | 函數項級數和函數的域、固定點與反例移動點須分明，0 值不能靠正幾何比支撐。 | `b03/{thick,refined}/sec191-1.diff`。明定收斂集合 C、和 s:C→R、限制、原域 R，並另處理 q=0。重核本章 §191.1 和 191.3 加常數項的例子。 |
| B-04 Ch.179，§§179.2–179.4 | 根的微擾估計與正/負邊界要可驗，平移或倍乘取界只需相應一側有界。 | `b04/{thick,refined}/real/ch179.diff`。兩方向以差冪和估計，界運算依所需一側。§180.4 根式和 §181.3 有理冪先備仍合法。 |
| B-04 Ch.180，§§180.4–180.6 | 擴充尾界需可運算，收到任一子列要能比較其上下極限，實數 Cauchy 需建立存在性。 | `b04/{thick,refined}/real/ch180.diff`。以其非空尾界分支和相應集合定 inf/sup，子列鏈逐項估，Cauchy 有界且極端差為 0。§181.3、§189.3 已驗使用。 |
| B-04 Ch.181，§§181.4–181.7 | 交錯 p 收斂、重排耗盡各索引、極端越界與 Mertens 頭尾條件要交代。 | `b04/{thick,refined}/real/ch181.diff`。自然索引與零項三列、每階兩邊都前進及獨立尾誤差已核。§194.3 卷積以同中心的有限對角與內半徑絕對性使用。 |
| B-04 Ch.182，§§182.1、182.5–182.7 | 黏著點需先定，端點延拓必要方向、合成域洞及無窮內/外極限需處理。 | `b04/{thick,refined}/real/ch182.diff`。延拓逆向按已證 Heine–Cantor、準許外值規則和無窮實 threshold、單調無窮端點的上下界均在。§183.2 逆微分與 §186.6 對數的逆滿足先備。 |
| B-04 Ch.183，§§183.2、183.5–183.6 | 一階誤差定義引用、鏈式允許相同中心及例子的兩側端導數、差商分母可能為零要逐項核。 | `b04/thick/real/ch183.diff`，精修稿逐位元相同。補值商與整數處左右商供 §186.4 相對鏈式和 §193.1 週期例；§184.2 用 0/0 法前另證分母導數去心非零。 |
| B-04 Ch.184，§184.2 | 把 Peano 證明的「分母導數非零」讀成連中心皆成立會誤用。 | `b04/refined/real/ch184.diff`。明寫 punctured neighborhood，n=1 直接差商，其餘降階逐次核條件。與 §183.6 的 0/0 條件正合。 |
| B-04 Ch.185，§§185.4、185.5、185.7 | 單點域的可積性要能用於切段，振幅需非空。開段極值一般不等閉片極值，否則錯把階梯積分認成 Darboux 和。 | `b04/{thick,refined}/real/ch185.diff`。單點可積值0，J 非空，包絡在開片賦閉片極值，在分點賦 f 值。用閉片極值求和與 Darboux 值逐項相合。 |
| B-04 Ch.186，§186.6 | 交錯 p 證明末句的適用區間、log 換元中尚未定的 compact 用詞。 | `b04/refined/real/ch186.diff`。明列 \(0<p\le1\)，換元域與像是有限閉正區間，另見 RN-01。核 §181.3 實 p 承接與 §194.3 exp 不循環。 |
| REF187-01，§187.3 | 原開射線證明只寫端點 0，§187.5 用任意 c。 | `b04/refined/metric/ch187.diff`。對任意 \(c\)，取 \(|x-c|/2\)。分離兩半仍是子空間開集。 |
| REF187-02，§187.3 | 相對開/閉刻畫還欠開子空間或閉子空間時的直接推論。 | 同一 diff。以相對表示和有限交把相對開性／閉性帶回母空間，兩方向均在。 |
| REF187-03，§187.5 | sup 分支須有 \(c<b\) 才能往右取點。 | 同一 diff。在 \(c\in U\) 分支明以 \(b\in V\) 排除相等。 |
| B-04 Ch.188，§188.3 | Cauchy 尾界加上有限前段的半徑只口述。 | `b04/refined/metric/ch188.diff`。固定 \(R=2+\sum_{j<N}d(x_j,x_N)\) 蓋全列。§189.3 借移動兩點距離，估計兩索引門檻。 |
| B-04 Ch.189，§189.3 | 代表元等價和商點相等要兩向，商內 Cauchy 與逼近點 Cauchy 要各自推極限。 | `b04/{thick,refined}/metric/ch189.diff`。逐集合成員證類相等；距離有限，再證代表無關。由兩段三角控制原商內列，並核唯一證明保原嵌入的滿射。 |
| B-04 Ch.190，§190.3 | 有限網有界性需要可算轉換。 | `b04/refined/metric/ch190.diff`。一個有限 1-net，取第一中心和最大中心距離，空集獨立。與後續完備＋全有界判準的證明無循環。 |
| B-04 Ch.191，§191.2 | 有限 supremum norm 的域和差函數的收斂條件須清楚。 | `b04/refined/metric/ch191.diff`。正文保留無界函數可一致收斂，及以有限誤差界得 uniform 的推理。 |
| B-04 Ch.192，§§192.1、192.3 | 尖峰的移動反例及參數切片相對端點未充分點明。 | `b04/refined/metric/ch192.diff`。指定峰輸入，切片保距，參數 \(s,t\in[c,d]\)。依 185 界先證極限可積。 |
| B-04 Ch.193，§193.1 | 尖角逼近只證到 C¹，稿曾泛稱 smooth。 | `b04/refined/metric/ch193.diff`。按正文已證範圍改 C¹，正分母連續求導，\(1/n\) 正確控制逼近。 |
| REF194-01，§194.2 | 導數級數的 majorant 未排 \(M=0\) 會使比值未定。 | `b04/refined/metric/ch194.diff`。明取正上界 \(M\)，\(0<r<\rho\) 保證項非零。 |
| REF194-02，§194.4 | 閉球的 boundedness 誤寫成整個函數空間的性質。 | 同一 diff。閉球 A 閉且有界，整個函數空間完備。\(x^n\) 的點態極限在 1 斷裂，無 sup 收斂子列。 |
| REF194-03，§194.4 | C¹ 的圖度量稱 norm，須有閉合、齊次。 | 同一 diff。有限線性微分給閉合與齊次，sup norm 與零元判別給其他性質。 |
| REF194-04，§194.4 | 任意 \([a,b]\) 的 D 不連續只在 \([0,1]\) 寫例。 | 同一 diff。局部 C¹ 例加正長度伸縮，導數範數 \(1/(b-a)>0\) 在左端取到。 |
| RN-01，§186.6 舊行352–353 | 舊文 “Both domain and image segments are positive and compact”，度量緊緻尚未定。 | 現文 “finite closed intervals contained in \((0,\infty)\)” 並核 affine 為 C¹。責任精修，查 `quality/B05-defects.md` 及 ch186 精修補丁。 |
| NAR-M01，Ch.193 舊行13 | 舊端點 C¹ 引向 183.5 的週期反例。 | `b05/ch193-reference-fix.diff` 鏈到 183.3 的 `def:183-extrema-c1`。週期例仍取 183.5。責任精修及擴充，兩實際交叉參照與 PDF 重核。 |
| RN-02，§194.1 行47–57 | 舊 \(q=\infty\) 援引此前只證有限極限的比值判準。 | `b05/ch194-ratio-infinity-fix.diff`。對每個非中心點 \(t_{N+k}\ge 2^kt_N\)，尾段 \(t_N>0\)，發散依法。責任精修及擴充，核 root radius 比較。 |

## B-06 已修的呈現問題

R2 的 26 列原呈現、讀者影響、本卷局部 guard／metadata、來源定位和原新圖片頁，逐列保留於 `book/qa/B06-DEFECTS.json` 及 `B06-DEFECTS.md`。本表沿用既有 ID，正文語義評估見前兩段。R2 接收時，尚未因 B07 回修觸發重排。

| ID | 原問題與位置 | 修補與 R2 重核 |
|---|---|---|
| B06-L01 | 實體頁 1,2。Duplicate roman i page label across unnumbered title page and first frontmatter page | Set page=2 immediately after maketitle in volume entry。R2 實體頁 1,2。 |
| B06-L02 | 實體頁 13,14。Short Proposition 179.14 splits its final bounds across page; section 179.5 should travel with complete statement | Local pre-section guard chapter179 counter13。R2 實體頁 14。 |
| B06-L03 | 實體頁 16,17。Short Proposition 180.5 leaves final sentence fragment in continued box | Local before-proposition guard chapter180 counter4。R2 實體頁 17。 |
| B06-L04 | 實體頁 17,18。Section 180.4 first proposition splits its paired arithmetic display across pages | Local pre-section guard chapter180 counter6。R2 實體頁 18。 |
| B06-L05 | 實體頁 18,19。Example180.8 starts with only its recurrence and breaks before the first verification | Local before-example minimum start guard chapter180 counter7。R2 實體頁 19。 |
| B06-L06 | 實體頁 22,23。Section180.6 heading isolated above empty lower area; definition begins next page | Local pre-section guard chapter180 counter12。R2 實體頁 23。 |
| B06-L07 | 實體頁 23,24。Moderate Example180.15 splits and produces a five-line continued chapter-ending page | Local before-example keep complete unit if short enough; recheck reflow。R2 實體頁 24。 |
| B06-L08 | 實體頁 53,54。Section183.5 anchor/bookmark lands previous page while visual heading next page | Parent index flagged; local section guard chapter183 counter10 plus anchor regression。R2 實體頁 56。 |
| B06-L09 | 實體頁 33,34。Example181.14 splits its coefficient computation from the short divergence estimate | before-example guard181 counter13。R2 實體頁 34。 |
| B06-L10 | 實體頁 35,36。Short Definition182.2 leaves one final convention line in a continued box | before-definition guard182 counter1。R2 實體頁 37。 |
| B06-L11 | 實體頁 41,42。Example182.13 leaves one concluding line on the next page | before-example guard182 counter12。R2 實體頁 43。 |
| B06-L12 | 實體頁 48,49。Short Proposition183.2 begins with one assumption line and continues its defining formula on next page | before-proposition guard183 counter1。R2 實體頁 51。 |
| B06-L13 | 實體頁 58,59。Short Theorem184.4 breaks its local derivative assumptions across pages | before-theorem guard184 counter3。R2 實體頁 61。 |
| B06-L14 | 實體頁 71,72。Short Proposition185.9 separates integrability assumptions from formulas | before-proposition guard185 counter8。R2 實體頁 74。 |
| B06-L15 | 實體頁 73,74。Short Proposition185.11 breaks endpoint hypotheses mid-sentence | before-proposition guard185 counter10。R2 實體頁 76。 |
| B06-L16 | 實體頁 83,84。Two-line integration-by-parts recurrence breaks after first equality line | before-align* guard186 counter11。R2 實體頁 86。 |
| B06-L17 | 實體頁 125,126。Short Theorem191.13 separates map hypothesis from convergence statement | before-theorem guard191 counter12。R2 實體頁 129。 |
| B06-L18 | 實體頁 126,127。Short Definition191.15 strands singleton-interval qualification on next page | before-definition guard191 counter14。R2 實體頁 130。 |
| B06-L19 | 實體頁 131,132。Short Proposition192.7 separates rectangle assumptions from the parameter integral formula | before-proposition guard192 counter6。R2 實體頁 135。 |
| B06-L20 | 實體頁 134,135。Section193.2 heading isolated; central derivative-limit theorem begins next page | pre-section guard193 counter3。R2 實體頁 138。 |
| B06-L21 | 實體頁 136,137。Section193.3 short Corollary193.7 splits its anchor assumption from conclusion | pre-section guard193 counter6。R2 實體頁 140。 |
| B06-L22 | 實體頁 139,140。Short Theorem194.4 leaves absolute-convergence conclusion alone on next page | pre-section guard194 counter3。R2 實體頁 143。 |
| B06-L23 | 實體頁 140,141。Theorem194.6 separates paired derivative/integral formulas across pages | before-theorem guard194 counter5。R2 實體頁 144。 |
| B06-L24 | 實體頁 54,55。Short Proposition183.10 assumptions/results split after R1 reflow | before-proposition guard183 counter9。R2 實體頁 55。 |
| B06-L25 | 實體頁 62,63。Short Definition184.7 continuity/Taylor qualifications split after R1 reflow | before-definition guard184 counter6。R2 實體頁 63。 |
| B06-L26 | 實體頁 87,88。Paired exponential laws in Proposition186.15 split after R1 reflow | before-proposition guard186 counter14。R2 實體頁 88。 |

R3 對 R2 實際逐頁渲染，只有第 8、9、35、40–42、79 頁像素不同。上述 26 項曾受影響的終版頁及相鄰區域以排版官同批 R3 交接檔為準。B-07 另檢七張變動全頁，沒有新殘缺；其餘 145 頁保留 R2 整頁視檢證據。154c 候選與 b303 終版各有其固定配對，舊頁碼供追溯。
