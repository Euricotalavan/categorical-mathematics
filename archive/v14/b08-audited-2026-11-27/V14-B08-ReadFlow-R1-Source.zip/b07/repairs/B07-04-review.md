# B07-04｜Trench單調零列推論原條號｜獨立精修回執

角色 `/root/refine_metric` → 主控 `/root`，2026-11-27 UTC。V14／B單一Work／B-07退回精修的局部來源識別修正；不改B05，不代替打厚複核。模型實際High設定未核實。

**判定：同意修正，補原條號可接受；原命題、條件與證明全部保留。** 等待主控於盲讀後批次合入，再由打厚確認。

## 接收與獨立核源

實讀 `book/chapters/ch181.tex:451–490`，輸入SHA-256 `66d9302555c9a2f01c24aa40c2b9f2148415a27b1b7e46c31699131f2f2b2c36`。原483–486行只稱「corresponding Trench corollary」，不足以滿足B01 `V14-181-25`所要求的原條號以避免同名Abel判別混淆。派工p35僅為舊排版位置識別，本輪沒有生成或簽收新PDF。

獨立實讀包內 `sources/Trench-Introduction-to-Real-Analysis-v2.04-Trinity.pdf` 實體229／印219，版本為Free Hyperlinked Edition 2.04／Trinity 587頁封裝；來源檔SHA-256 `228ff181ab301bf9f53db8ae29bbd0e02e6022f0463001efa44dae9a0ad7aa2b`。頁上確為 **Corollary 4.3.21 (Abel’s Test)**：從某k起a_(n+1)≤a_n、a_n→0，且b_k至b_n的部分和一致有界。原證以單調零列的變差望遠鏡求和為a_k，再用前面的Dirichlet判別。故本稿將同一單調零列版本稱Dirichlet，而指出Trench名Abel，是真實版本命名差異，不能換成另一組常見Abel假設。

## 改文、保留與驗證

原484–485行跨行的「the corresponding Trench corollary」改成「Trench's Corollary 4.3.21」。仍為原兩行，新485行含完整原條號；原483、486句、451–481命題與全證明、487–490冪級數移交均保留。只是識別來源，無新假設或依賴、沒有縮去討論。

- 候選 `B07-04-ch181-proposed.tex`：22395 bytes／490行，SHA-256 `25aeb7fed3202e2a6c127737ecc807eca18e6032b2b961601aa127310cd3cbf2`。
- unified diff `B07-04-ch181.diff`：SHA-256 `a2ea4ef93d34946557303f1f175e7488ce7a198ebac98b09e1dcf10b0b94e463`。
- 實際在臨時副本套patch，逐bytes比對候選相符。所有labels、總行數及行號維持；主稿與B05檔未改。
- `B07-04-manifest.json`記錄輸入／候選／patch身份及待批次套用狀態。

覆蓋子集 `coverage-real-179-181-revised.csv`保留當前B05表header、ID與原Verified狀態。按source_file收全25行ch181（亦含跨段多責任窗口），每行更新至新正文hash；行數未變，所以181各anchor、line_start/end與actual_ranges沿用且逐一驗證。181-25 note明載Trinity PDF229／印219／Corollary4.3.21及新L485原條號。沒有只更新181-25而留下其他ch181列舊hash。該子集另包含B07-03的19行ch179；兩修各自有候選和diff，不預先改主表。

## 下一步與交接邊界

主控於B07盲讀結束後批次合入，實算候選hash吻合，合入新coverage子集並重新排版；打厚對181-25原條號及同名條件比較複核後再判B07。本項沒有數學OPEN；既有UNKNOWN、其他B07問題與整卷終審結論保持各自責任。本件已寫出並回報主控，接收方實讀及打厚重核待記。未上傳、未封存、未啟動其他卷。
