# B07-02｜第185章Y選讀階梯逼近比較修補提案

交接ID V14-B07-02-REPAIR-20261127；2026-11-27 UTC。精修修補 `/root/refine_real` → 主控 `/root` → B07唯一打厚終審者複核。方案B單一Work；原A11的局部內容修正/回打厚責任，模型/High未核實。

**缺漏成立。** V14-185-25的原745–769只寫單次上下階梯envelope判準，還沒有承擔Y選讀路線中以嚴格正階梯誤差控制一列逼近、並以階梯積分極限定積分的具體比較。新增以下5句及其公式，保留既有證明與Darboux核心構造，沒有擴大至其他積分理論。

## 固定基線與實讀

基線`book/chapters/ch185.tex` 33870 bytes，SHA256 `b18768e9330858a40d10104dc74b086b12dfd831ffa9e8cf3a8c048df55b1a96`，實算一致。於原769後/原771的`sec:185-8`之前新增；原745–769既有文字不改。

直接讀`tmp-v14/refs/yu-public-2020-12-27.pdf`，1001頁，SHA256 `6f2b9dc65d45728472908f12a74d5f5434e51458600f945a7236b53cead58888`。本次讀實體193–194並渲染兩頁視核：193的Lemma118是ε式/序列式嚴格誤差與小誤差積分等價，194完成反方向、Def119取此為可積條件，Def120取階梯積分極限且論存在/選法無關。嚴格符號是`<`；誤差因此逐點正。只用直接相關選讀，不引入原書後面的Lebesgue或向量值擴展；原書版面中差積分/撇號的排字不沿抄，本稿用已證階梯三角/線性/比較估計自行核良定性。

## 精確新增文字

擬稿771–800；共5句，段落後加空行使原771之後整體+31行：

```tex
For comparison, Yu's selected step-approximation formulation uses step
functions \(s_n,\psi_n\) on the same \([a,b]\), with \(\psi_n>0\)
and \(|f-s_n|<\psi_n\) pointwise and \(\int_a^b\psi_n\to0\).
In that formulation the integral is defined as \(\lim_n\int_a^b s_n\):
the estimate
\[
 \left|\int_a^b s_n-\int_a^b s_m\right|
 \le\int_a^b\psi_n+\int_a^b\psi_m
\]
makes the step integrals Cauchy, and the same estimate for two choices
makes the limit independent of the approximation.
In our construction, the step envelopes \(s_n-\psi_n\le f\le s_n+\psi_n\)
have integral gap \(2\int_a^b\psi_n\to0\), so the criterion just proved
makes the bounded \(f\) integrable and gives
\(\left|\int_a^b f-\int_a^b s_n\right|\le\int_a^b\psi_n\to0\),
identifying the two values.
Conversely, choose step envelopes \(g_n\le f\le h_n\) with
\(\int_a^b(h_n-g_n)\to0\), and put
\[
 s_n=\frac{g_n+h_n}{2},\qquad
 \psi_n=\frac{h_n-g_n}{2}+\eta_n,
 \quad \eta_n>0,\quad\eta_n\to0;
\]
then \(|f-s_n|\le(h_n-g_n)/2<\psi_n\), and
\[
 \int_a^b\psi_n
 =\frac12\int_a^b(h_n-g_n)+\eta_n(b-a)\longrightarrow0.
\]
Thus this comparison describes the same bounded real normal Riemann
integral on a finite closed interval, retaining our Darboux construction.
```

## 數學核查與保護範圍

1. 步函數已在185.4/7定義並證可積及加減封閉，任意分點值有獨立型別；這裡s_n、ψ_n、g_n、h_n、常數η_n全是同一有限閉段上的實階梯函數。嚴格|f−s_n|<ψ_n給ψ_n處處正，包含分點，沒有ψ_n=0時錯稱嚴格不等式的漏洞。
2. |s_n−s_m|≤ψ_n+ψ_m，三角/比較與R的Cauchy完備給階梯積分限存在；另一逼近族用相同型別估計，兩族積分差趨0，所以不依選法。這只用先前180及185已證結果。
3. s_n−ψ_n≤f≤s_n+ψ_n，兩階梯積分的gap恰2∫ψ_n→0，符合本節已有判準；先得到f可積，再用積分誤差界識別值為lim∫s_n，沒有先使用未建的f積分。
4. 反向從每個ε=1/n選envelope得序列，再用中點。半差≥0且|f−s_n|≤半差；加任意常數η_n>0→0使界嚴格且ψ_n處處正。因0<b−a<∞，其積分額外項η_n(b−a)可任意小，故∫ψ_n→0。亦包含精確階梯逼近/半差0的情況。
5. 這是選讀比較及等價描述；Darboux定義、所有細網格標記和定理、可積類、FTC與後續積分交換的條件不變。§185.3的原section切片逐位元相同；八節及全部labels相同，沒有新增待先定的詞或隱式換理論。

## 固定提案與後續

| 檔（本資料夾） | bytes | SHA256 |
| --- | ---: | --- |
| ch185-B07-02-proposed.tex | 35096 | `c2bd09b7940d3b3ff9b5dcc6d0e91bd5a3e36f2f4973c0c8c95bdc61817bbe65` |
| B07-02-ch185.diff | 1618 | `c34706f315f90d5d581bdeec90fc0f976d7f89225bcbe63810114e2e1b9fc18c` |
| coverage-real-revised.csv（合併B07-01/02） | 83804 | `7a81f37d09a558f18c7d803ed8978143f760d8d047099c48926fc4510fa15fbc` |

單一局部unified diff在臨時副本套用逐位元吻合；185.3保護檢查通過。合併coverage保原186列/183個ID與12欄，只刷新182的38列及185的26列（章hash與必要行號/證據）；其餘列逐欄相同，Tao UNKNOWN及185-26 DEFERRED原狀。185-25新比較771–800有實際定位，185-26篇界移804–813，後卷理論仍未建立。

本角色未直接改正式book、原B05及原報告；提案與CSV保留生成時的PROPOSED/NOT_APPLIED標記，未上傳或封存。新CSV只在主控批次套用同一組正文後才可成為現行定位依據；同章如有新缺陷，需合批重算。唯一下一步為主控套用後交B07打厚複核，並重建配對PDF/排版檢查；本次未做新PDF/視檢，不宣稱B07結案。既有UNKNOWN、來源選讀限制及凍結前卷保留，待主控實際讀入/套用回執。

## 交件時接收狀態更新

主控已另行將同hash的182/185提案批次合入，並與179/181補丁整合B05；本角色沒有直接寫正式檔。此CSV保留對原`f318f…`固定基線的回修記錄，不可全表覆蓋含其他修補的新B05；以本兩章source_file組件合併或使用主控現行整合表。正式ch185現為`c2bd09b7940d3b3ff9b5dcc6d0e91bd5a3e36f2f4973c0c8c95bdc61817bbe65`；下一步是主控重編/視檢及B07終審者實讀複核，不是再由本角色套用。
