# B07-01｜第182章可移除間斷局部修補提案

交接ID V14-B07-01-REPAIR-20261127；2026-11-27 UTC。角色：精修修補 `/root/refine_real` → 主控 `/root` → B07唯一打厚終審者複核。方案B單一Work；本件是B07退回精修的單一局部補丁，對照原A11修正後回打厚。模型/High未核實。

**缺漏成立。** V14-182-18的原段只證零點不連續與單點限制連續，沒有展示來源的去心極限、刪點與補值可移除，也沒有接到不可補值的階跳對照。以下只交作者所有的擬稿/補丁，本角色沒有直接改正式book、B05或原回執，也不代簽B07通過；主控後續套用狀態見末段。

## 接收與來源實讀

- 正式基線：`book/chapters/ch182.tex`，34134 bytes，SHA256 `4bafe5dc17be100009b7ac7eee094ceab42ee475ea2bfd5388a9f897012ee3a0`，實算一致；原問題位置228–231，label `ex:182-dirichlet-spike`。
- 實際來源：`tmp-v14/pack/sources/Lebl-Basic-Analysis-I-v6.3.pdf`，SHA256 `9c204ae1f1ee1641fa604a6456c0d13db4390db44633ee2df9c9d97b5486b7a6`。直接讀實體PDF第127頁Ex.3.2.13，並核既有文字擷取。源例確有g在0可補值、域刪0後連續、單點域限制連續及不同於無去心極限的例子；本提案以自己的敘述/證明承擔，不抄源文。
- 先備實核：本章38–63/176–219的去心限與連續判準、119–136的左右限與h，以及179誤差/三角界。未新增外部先備。

## 原文與精確改文

原228–231：

```tex
For \(g(0)=1\) and \(g(x)=0\) at all other real inputs, a nonzero
sequence tending to zero proves discontinuity at zero. But \(g|_{\{0\}}\)
is continuous, because its domain has only one point. Restricting the
domain can change the continuity question.
```

只以以下20行替換，擬稿228–247（example結束為248）：

```tex
For \(g(0)=1\) and \(g(x)=0\) at all other real inputs,
the punctured limit at zero is \(0\): for every \(\varepsilon>0\),
take \(\delta=1\); then \(0<|x|<\delta\) gives
\(|g(x)-0|=0<\varepsilon\). Since this limit differs from \(g(0)\),
\(g\) is discontinuous at zero. At any \(c\ne0\), the neighborhood
of radius \(|c|/2\) excludes zero, so \(g\) is locally constant and
continuous there.
Deleting zero from the domain gives the identically zero restriction
\(g|_{\mathbb R\setminus\{0\}}\), which is continuous. Replacing
only \(g(0)\) by \(0\) gives a new function \(\widetilde g\equiv0\)
on \(\mathbb R\), also continuous. This is a removable discontinuity:
changing only the point value can make the function continuous at that point.

By contrast, the function \(h\) in Section~\ref{sec:182-2} has
left limit \(1\) and right limit \(0\) at zero. Its punctured
limit does not exist, so no assignment to \(h(0)\) can make it
continuous there.

But \(g|_{\{0\}}\) is continuous, because its domain has only one
point. Restricting the domain can change the continuity question.
```

## 本地證明與傳遞影響

任意ε可取δ=1，因所有去心值等0，故真正證得有限去心極限0；它與原點值1不同，所以原g在0不連續。非零c用|c|/2鄰域避免0，證原函數在其他點連續；刪點限制與補值後的新函數分別是恆0，不混淆原g、其限制與新函數。可移除的定義明寫**在該點**修復連續，沒有要求修改一點就使有其他間斷的整個函數處處連續。h的兩側限1/0不等，且改中心值不影響去心限，因此無中心值能使其在0連續。原g在單點限制仍取值1而相對連續，保留原比較。

本地只補一個必要例及名稱；所有定義/定理的條件及先後依賴不變，七節與全部labels相同。186的尖峰積分例仍可引用既有有限改值積分/相對連續結果，不需換證；185/192/193的實分析接口不變。交叉引用只新增已存在的`sec:182-2`。之後章內原232以上的實際行號整體+16，這是定位/版面影響，不是其他正文的語義變更。

## 補丁及覆蓋提案

| 檔（本資料夾） | bytes | SHA256 |
| --- | ---: | --- |
| ch182-B07-01-proposed.tex | 34962 | `a48d6976839bfde2a4cfee43ef21eddd74a8c18daf1e96f0d130e7fdcb5fd848` |
| B07-01-ch182.diff | 1640 | `970a944d8d018bec1e70c9877022d0d47df79ac4b9788c2457328fd0fa4cd92f` |
| coverage-real-revised.csv（與B07-02共享） | 83804 | `7a81f37d09a558f18c7d803ed8978143f760d8d047099c48926fc4510fa15fbc` |

單一unified diff相對指定正式基線；在臨時副本套用後逐位元重建吻合。覆蓋提案以原`b05/coverage-real.csv` SHA `f318f1788cde69ea791f536d91094b374fa236195ad974bc27161d69ee1358ea`為基線，同時納B07-01/02的兩章擬稿hash。182-18落點更新到228–248，完整記去心限/刪點/補值/h/單點比較；182-16只保真正Dirichlet221–226；本章其餘行號及38列章hash刷新。未知Tao來源列、其他章責任與原報告不改。CSV的VERIFIED描述本地擬稿中已核的責任，`PROPOSED...NOT_APPLIED`明列未套用，不是B07結案標記。

唯一下一步：主控在盲審掃描後按同一正式基線批次套用，再將固定正文/新PDF與覆蓋表交B07打厚複核此項及受影響範圍。如同章再有補丁，須合批重算正文hash及所有受影響locator；不可把本提案直接當現行B05。排版編譯/全頁視檢尚未作，本件不以hash取代它。既有UNKNOWN/後卷責任與凍結限制保留，未上傳或封存；待主控實際讀入/套用回執。

## 交件時接收狀態更新

回執完成期間觀察到主控已另行合入：正式ch182的SHA256已是本提案`a48d6976839bfde2a4cfee43ef21eddd74a8c18daf1e96f0d130e7fdcb5fd848`，ch185也已合入B07-02。本角色沒有執行該正式寫入。原B05 `f318f…`已保留在`b07/initial-input/coverage-real-R1.csv`；現行B05另含179/181的批次補丁，不能用本提案舊基線全表覆蓋它，只取本兩章source_file組件或沿主控合併結果。接下來按主控固定版本重編及視檢受影響PDF，再交B07終審者做直接/傳遞影響複核；本地修補角色不代其結論。
