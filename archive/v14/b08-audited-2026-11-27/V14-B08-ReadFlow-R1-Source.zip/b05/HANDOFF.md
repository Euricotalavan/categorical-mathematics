# V14 B-05 → B-06 整卷交接

交接 ID `V14-B05-B06-20261127-R1`。主控 → 行文排版。用同一 Work 內固定檔與回執交接。對話無另行實際 URL。

V14 *Basic Analysis: One Variable, Metric Spaces, and Sequences of Functions*。B 方案單一 Work，使用者授權 B01–B08 自動續行及主控裁決。B-05 含逐節精修後的整卷順讀、來源落點、責任與依賴驗證，接原 A 的 08–09 行文排版。B-07 終審由新獨立打厚執行。

固定卷界以 `b02/RESOLUTIONS.md` 為準，分卷 v4-git-aligned H01。適用 Git `ee4d2b7e723a32c2b58961e3903391c535fb8b07`。V13 發布本截至第 178 章，本卷第 179–194 章。正式模板 ReadFlow R1 artifact `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，三個共享檔與授權字型見 `book/engineering/TEMPLATE-LOCK.json` 及 `book/dependencies/FONTS.json`。角色實際推理設定未獨立核實，派工參數見 `quality/WORKFLOW.md`。

唯一正文在 `book/chapters/`，固定檔案、大小、SHA-256、覆蓋及四份獨立回執見 `book/qa/B05-fixed.json`。原書入口在固定準備包與 B-01 來源表。相關階段存取資料見 `quality/WORKFLOW.md`。分別核查實際正文、可讀原版書的責任、讀者看到的PDF。B-05 尚無對應正式整卷PDF，B-03十頁校準另存。

已核必要先備與章縫。185正常積分與186兩向微積分基本定理先於192–194交換極限。186用有限正常積分建 log 與 exp，194先辨認 exp 級數，再證平坦函數。189商完備化先立，194在有界連續函數空間完備後給第二構造。三處具體更正與證據見 `quality/B05-defects.md`。無阻 B-06 的內容缺陷。Tao 未取得正文的七個來源責任 UNKNOWN 保留，于品講義採已讀相關段落補充。本卷邊界為有限區間正常 Riemann 積分，後卷責任見覆蓋表。既有歷史16／22映射與六全局門檻 UNKNOWN 按總規範留存。

排版接收請回報實讀稿、固定版及雜湊；發現數學問題退內容角色。使用正式 ReadFlow R1 與原樣固定共享模板，允許有界本卷局部排版修正。以 `python build.py --entry volume --clean --debian-unindexed --b05-manifest qa/B05-fixed.json`（從 `book/`）建置。核對英文正文、高對比、公式層次、視覺逐頁、章節、書籤與引用。內容、工程、視檢各列結果。B-06 完成後只交新獨立打厚 B-07；回修須用同一打厚複核。V14 本次交付作用域以外的舊卷、原始規劃、字型來源、共享模板與工具保護。

待使用者決策無。B-06實讀收件及固定PDF回執由接收角色補證。最終封存須待B-07對配對版本正式簽核。
