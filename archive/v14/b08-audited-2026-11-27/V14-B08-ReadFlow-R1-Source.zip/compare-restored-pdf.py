"""Compare the paired PDF to a clean build on the recorded runtime."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import re

import fitz


def page_identity(page):
    """Use full-page pixels plus exported navigation and text for visible equivalence."""
    pixels = page.get_pixmap(dpi=144, alpha=False)
    links = [{key: value for key, value in link.items() if key not in ("id", "xref")}
             for link in page.get_links()]
    return (tuple(page.rect), page.get_text(sort=True), sha256(pixels.samples).hexdigest(), links)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def ignore_pdf_trailer_id(path):
    content = path.read_bytes()
    pointer = re.search(rb"startxref\s+(\d+)\s+%%EOF\s*$", content)
    if pointer is None:
        return content
    xref = int(pointer[1])
    return content[:xref] + re.sub(rb"/ID\s*\[\s*<[a-fA-F\d]{32}>\s*<[a-fA-F\d]{32}>\s*\]",
                                   b"/ID[rerender]", content[xref:], count=1)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("paired", type=Path)
parser.add_argument("rebuilt", type=Path)
parser.add_argument("--output", type=Path, required=True)
arguments = parser.parse_args()
paired_sha = digest(arguments.paired)
rebuilt_sha = digest(arguments.rebuilt)
with fitz.open(arguments.paired) as paired, fitz.open(arguments.rebuilt) as rebuilt:
    if len(paired) != len(rebuilt) or paired.get_toc() != rebuilt.get_toc():
        raise SystemExit("Restoration changed page count or bookmarks.")
    if paired_sha != rebuilt_sha:
        changed = [number for number, (old, new) in enumerate(zip(paired, rebuilt), 1)
                   if page_identity(old) != page_identity(new)]
        if changed:
            raise SystemExit(f"Restoration changed pages: {changed}.")
    trailer_id_only = paired_sha != rebuilt_sha and (
        ignore_pdf_trailer_id(arguments.paired) == ignore_pdf_trailer_id(arguments.rebuilt)
    )
    result = {
        "paired_pdf_sha256": paired_sha,
        "clean_rebuild_pdf_sha256": rebuilt_sha,
        "pages": len(paired),
        "bookmarks": len(paired.get_toc()),
        "result": "BYTE_IDENTICAL" if paired_sha == rebuilt_sha else "ALL_PAGES_TEXT_PIXELS_AND_LINKS_IDENTICAL",
        "binary_difference_is_only_the_pdf_trailer_id": trailer_id_only,
        "comparison_dpi": None if paired_sha == rebuilt_sha else 144,
    }

arguments.output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
