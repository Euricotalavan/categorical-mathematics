# V14 B-08 封存交接

交接 ID `V14-B08-20261127-R1`。主控 → 卷主及後續 Work。B 方案單一 Work，依本輪授權完成 B01–B08。使用者將卷內例行裁決交主控，B-07 由獨立打厚角色負責整卷簽核。

**Basic Analysis: One Variable, Metric Spaces, and Sequences of Functions**。第 179–194 章，152 頁。分卷 v4-git-aligned H01，V13 發布版末章 178。查核 Git `ee4d2b7e723a32c2b58961e3903391c535fb8b07`，前卷入口 `archive/v13/b08-audited-2026-11-27/`。正式 ReadFlow R1 artifact `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，固定模板及字型見 `book/engineering/TEMPLATE-LOCK.json`、`book/dependencies/FONTS.json`。工作分配與未能獨立確認的運行模型、推理強度見 `quality/WORKFLOW.md`。

## 固定檔案

| 用途 | 檔案 | bytes | SHA-256 |
| --- | --- | ---: | --- |
| LaTeX 整卷整合清單 | `book/qa/B05-fixed.json` | 6,169 | `efa95697955b123e4a0010144cceea2a296d590c9edaf6f89569612b18d98088` |
| 內容與排版的配對清單 | `b06/B06-candidate.json` | 5,750 | `2a02e525555e59765652c3baf008c5ed1d17543b8cb4f6a3155a1a029c5df8ca` |
| 配對閱讀 PDF | `reading/V14-B08-ReadFlow-R1.pdf` | 652,917 | `b3030ad435f25a2219fba4a3130aaeaed3747656a4c08b1047acd6cce915848e` |
| 獨立打厚簽核 | `audit/B07-signed.json` | 3,636 | `35648507fbdf2c0df7e7d0b1ff3da6e0a9437191f4f5fc1a80c9c4c5f545f7e3` |
| 文獻與實際正文落點 | `b05/V14-coverage-verified.csv` | 236,598 | `b6ca1a9871b71b3c9a9fe83abbd3ca7fb34c48a3f087d6e330b5f64b4a6a0a10` |

以同一 ZIP 的 `MANIFEST.json` 核其餘每檔大小、身份與 SHA-256，包含建置依賴、回執及缺陷處置。讀者見到的 PDF 與唯一正文由固定配對逐件核對。所有正文位於 `book/chapters/`，前置、書目及章界照同一卷入口重建。`README.md` 有 Linux／跨平台建置入口。重編核對結果見 `RESTORE-RESULT.json`。讀者若使用有索引的完整 TeX Live，執行 `python build.py --entry volume --clean --b05-manifest qa/B05-fixed.json`（在 `book/`）。當前 Debian 使用 `--debian-unindexed`。

## 驗收證據與缺陷記錄

- B-01 固定文獻範圍與 337 筆責任。B-02 核後依賴並裁決卷界。B-03 以 §185.3、§191.1 作校準。B-04 逐章寫作、打厚及精修，主控驗全部差分。B-05 兩半順讀後合表。B 主線的角色、版本與階段細節見 `quality/WORKFLOW.md`。
- B-06 閱讀版使用正式 R1，版面調整有據。`book/qa/B06-HANDOFF.md` 與頁面簿記說明實際視檢、閱讀、工程三層及回流。交接實檔由 B-07 獨立打厚實讀後審查。
- B-07 只以 `audit/B07-signed.json` 所指精確版本通過。盲讀證據、歷史核對、註明缺陷的修文與重核見 `b07/`。此前階段的回執和副本只作歷史材料。
- B-08 使用配對 PDF 與 LaTeX 來源作私人封存。解壓完整性、指紋、建置與恢復回執由同版封存核驗。公開分支與系列 Git 基線為既有讀取依據。

## OPEN／UNKNOWN 與續行界線

| ID / 範圍 | 位置、影響、責任與下一步 |
| --- | --- |
| UNKNOWN-V14-TAO | 《Analysis II》第四版公開卷首及四份兩頁預覽外，七筆來源責任維持 UNKNOWN。精修若取得同版合法正文再核。已見的定義比較另留正文證據。 |
| 補充來源及相鄰卷界 | 于品講義只取實讀的 V14 相關段落。本卷積分為有限區間正常 Riemann；9 筆後卷與範圍外責任留在覆蓋表。 |
| 既有歷史未知 | 16 主題與 22 章對應、六全局門檻舊未知由原項目保留。任何凍結前卷及正式模板仍以各自固定版本為準。 |
| 實際環境核對 | 在已記錄的 XeLaTeX 與字型環境重建。未另做實體印刷或跨環境驗收。 |

待當前卷主裁決無。唯一續行為用此版閱讀或依另行授權管理封存版本。接收人應核本版章號、manifest、配對閱讀 PDF 與簽核，不用較早草稿替代。若以新版本改動定義、假設、證明、章間依賴或版面重流，舊簽核只對本固定版成立。封存外的其它卷依各自工作範圍。
