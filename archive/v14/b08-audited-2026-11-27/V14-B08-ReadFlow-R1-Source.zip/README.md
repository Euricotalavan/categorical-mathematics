# Categorical Mathematics · Volume 14

**Basic Analysis: One Variable, Metric Spaces, and Sequences of Functions**  
Chapters 179–194 · ReadFlow R1 · 2026-11-27

The volume starts with completeness of the real numbers and ends with two constructions of metric completion. The first part develops the calculus of one variable. The second part separates completeness from compactness, then uses uniform estimates to integrate and differentiate limits of functions.

| Path | Contents |
| --- | --- |
| `reading/V14-B08-ReadFlow-R1.pdf` | Audited reading PDF |
| `book/chapters/` | The LaTeX manuscript used to build the PDF |
| `book/layout/` and `book/dependencies/` | Adopted ReadFlow R1, volume-specific layout, font files, upstream font archive, and notices |
| `b05/V14-coverage-verified.csv` | Source responsibilities and precise body locations |
| `book/qa/`, `b06/`, `b07/`, and `audit/` | Build and visual checks, independent mathematical audit, and approval of the exact pair |
| `RESTORE-RESULT.json` | Result of rebuilding after restoring the source |
| `HANDOFF.md` | Decisions, open source limits, version identities, and continuation instructions |

## Verify and rebuild

Unpack the ZIP into an empty directory and run `python verify.py` from its root. Keep that copy for the fixed review records. The build writes a new report, so use a second extraction for the rebuild:

```sh
cd book
python build.py --entry volume --clean --b05-manifest qa/B05-fixed.json
```

The build needs Python 3, XeLaTeX with a complete TeX Live installation, and the bundled font dependencies. On the recorded Debian runtime with an unindexed TeX tree, add `--debian-unindexed`. The output is `book/build/volume/V14-B06.pdf`. The local output filename is the build entry name. The paired reading PDF carries the stage name of the archive.

With PyMuPDF installed, compare the rebuilt PDF from the unpacked root:

```sh
python compare-restored-pdf.py reading/V14-B08-ReadFlow-R1.pdf book/build/volume/V14-B06.pdf --output ../v14-compare.json
```

The comparison checks binary identity first. If binary serialization differs, it checks page text, rasterized pages at 144 dpi, page rectangles, links, and bookmarks on the same runtime.

`MANIFEST.json` inventories this archive. The editor's working inventory also records the rendered page images. The archive carries the exact visual-review ledger and image hashes. To regenerate the page images on the recorded runtime, run the renderer with the resolution and options in `book/qa/B06-HANDOFF.md`.

Source references and their access limits are in `literature/SOURCE-REGISTER.md`. Pin Yu's public notes were consulted for selected passages. Terence Tao's fourth edition is covered only for the available previews and front matter. Unavailable passages are recorded in the source table as UNKNOWN.
