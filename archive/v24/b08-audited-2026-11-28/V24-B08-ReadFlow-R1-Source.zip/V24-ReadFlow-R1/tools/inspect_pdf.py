#!/usr/bin/env python3
"""Inspect rendered bounds, fonts and navigation; optionally render pages in order."""
import argparse
import hashlib
import json
from pathlib import Path
import re

import fitz
from PIL import Image, ImageDraw


def inspect(document):
    fonts = {}
    pages = []
    for index, page in enumerate(document, 1):
        counts = {"valid_internal": 0, "external": 0}
        anomalies = {"near_white_text": [], "outside_page_text": [], "broken_links": []}
        outer = page.rect + (-0.5, -0.5, 0.5, 0.5)
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    value = span["text"].strip()
                    if not value:
                        continue
                    box = fitz.Rect(span["bbox"])
                    if box not in outer:
                        anomalies["outside_page_text"].append(
                            {"text": value, "bounds": list(box)}
                        )
                    color = span["color"]
                    if min(color >> 16 & 255, color >> 8 & 255, color & 255) >= 232:
                        anomalies["near_white_text"].append(value)
        for link in page.get_links():
            if link["kind"] == fitz.LINK_GOTO:
                if 0 <= link.get("page", -1) < len(document):
                    counts["valid_internal"] += 1
                else:
                    anomalies["broken_links"].append(
                        {"kind": "internal", "target": link.get("page")}
                    )
            elif link["kind"] == fitz.LINK_URI:
                counts["external"] += 1
        for ref, _, kind, name, *_ in page.get_fonts():
            if ref not in fonts:
                payload = document.extract_font(ref)[3]
                fonts[ref] = {"font": name, "type": kind, "embedded_bytes": len(payload or b"")}
        pages.append(
            {"page": index, "label": page.get_label(), "printable_chars": len(page.get_text().strip()),
             "links": counts, "geometry": [page.rect.width, page.rect.height], "anomalies": anomalies}
        )
    return pages, list(fonts.values())


def render(document, directory, dpi):
    directory.mkdir(parents=True, exist_ok=True)
    tile_width, tile_height = 336, 476
    for group_start in range(0, len(document), 6):
        sheet = Image.new("RGB", (3 * tile_width, 2 * tile_height), "white")
        draw = ImageDraw.Draw(sheet)
        for slot, page_index in enumerate(range(group_start, min(group_start + 6, len(document)))):
            page = document[page_index]
            bitmap = page.get_pixmap(dpi=dpi, alpha=False)
            target = directory / f"page-{page_index + 1:03d}.png"
            bitmap.save(target)
            with Image.open(target) as image:
                image.thumbnail((tile_width - 18, tile_height - 30), Image.Resampling.LANCZOS)
                left = (slot % 3) * tile_width
                top = (slot // 3) * tile_height
                draw.text((left + 9, top + 2), f"PDF {page_index + 1}  |  {page.get_label()}", fill="black")
                sheet.paste(image, (left + 9, top + 20))
        first, last = group_start + 1, min(group_start + 6, len(document))
        sheet.save(directory / f"sheet-{first:03d}-{last:03d}.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--render", type=Path, help="Generate every page and six-page contact sheets")
    parser.add_argument("--dpi", type=int, default=126)
    parser.add_argument("--expect-chapters", nargs="+", type=int)
    args = parser.parse_args()
    with fitz.open(args.pdf) as document:
        pages, fonts = inspect(document)
        toc = document.get_toc()
        chapters = [
            int(match.group(1))
            for level, title, _ in toc
            if level == 1 and (match := re.match(r"^(\d+)(?:\s|$)", title))
        ]
        if args.render:
            render(document, args.render, args.dpi)
    unexpected = [page["page"] for page in pages if any(page["anomalies"].values())]
    outcomes = {
        "pdf": args.pdf.name, "sha256": hashlib.sha256(args.pdf.read_bytes()).hexdigest(),
        "pages": len(pages), "chapters": chapters, "font_records": fonts,
        "rendered_pages": len(pages) if args.render else 0,
        "outline": toc, "page_records": pages, "anomaly_pages": unexpected,
        "chapter_sequence_ok": args.expect_chapters is None or chapters == args.expect_chapters
    }
    outcomes["pass"] = outcomes["chapter_sequence_ok"] and not unexpected and all(
        font["embedded_bytes"] > 0 for font in fonts
    )
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(outcomes, indent=2) + "\n")
    summary = {k: outcomes[k] for k in ("pages", "chapters", "rendered_pages", "anomaly_pages", "pass")}
    print(json.dumps(summary, indent=2))
    return 0 if outcomes["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
