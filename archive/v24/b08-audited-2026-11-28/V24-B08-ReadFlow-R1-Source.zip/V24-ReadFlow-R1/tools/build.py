#!/usr/bin/env python3
"""V24 build adapter; pinned ReadFlow files remain unchanged.

Examples:
  python tools/build.py --sample /absolute/path/sample.tex --name b03
  python tools/build.py --chapter 305
  python tools/build.py --full --front frontmatter.tex --back backmatter.tex
"""
from pathlib import Path
import argparse, hashlib, json, os, re, shutil, subprocess
from xml.sax.saxutils import escape

HERE = Path(__file__).resolve().parent
V24 = HERE.parent
PINNED = V24
SHA = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    m = p.add_mutually_exclusive_group(required=True)
    m.add_argument('--fixture', action='store_true')
    m.add_argument('--sample', type=Path, action='append')
    m.add_argument('--chapter', type=int, choices=range(305,313))
    m.add_argument('--full', action='store_true')
    p.add_argument('--source', type=Path, default=V24/'chapters')
    p.add_argument('--name')
    p.add_argument('--start', type=int, choices=range(305,313), help='First chapter number in sample mode')
    p.add_argument('--output', type=Path, help='Override run root (e.g. temporary synthetic test directory)')
    p.add_argument('--front', type=Path)
    p.add_argument('--back', type=Path)
    p.add_argument('--preamble', type=Path)
    p.add_argument('--allow-diagnostics', action='store_true')
    a = p.parse_args()
    subprocess.run([os.sys.executable,str(V24/'verify.py')],check=True,capture_output=True,text=True)
    source = a.source.resolve()
    name = a.name or ('fixture' if a.fixture else 'sample' if a.sample else f'chapter-{a.chapter}' if a.chapter else 'full')
    if not re.fullmatch(r'[A-Za-z0-9_-]+',name): p.error('Invalid build name')
    if a.start and not a.sample:
        p.error('--start requires --sample')
    if a.fixture:
        paths=[V24/'fixtures/smoke.tex']
    elif a.sample:
        paths=[x.resolve() for x in a.sample]
    else:
        paths=[source/f'ch{n}.tex' for n in ([a.chapter] if a.chapter else range(305,313))]
    extras={}
    if a.full:
        a.front = a.front or V24/'frontmatter.tex'
        a.back = a.back or V24/'backmatter.tex'
    for k in ['front','back','preamble']:
        v=getattr(a,k)
        if v:
            q=v if v.is_absolute() else source/v if (source/v).is_file() else V24/v
            extras[k]=q.resolve()
    adapter=V24/'layout/v24-adapter.tex'
    if adapter.is_file():extras['adapter']=adapter
    for f in paths+list(extras.values()):
        if not f.is_file(): p.error(f'Missing explicitly requested input: {f}')
    root=a.output.resolve() if a.output else V24/'.build'/name
    if root.exists():
        # Retain older runs; unique suffix is recorded rather than overwriting evidence.
        n=2
        while (root.parent/f'{name}-{n}').exists(): n+=1
        root=root.parent/f'{name}-{n}'
    work=root/'layout/study';out=root/'build';runtime=root/'runtime'
    for d in [work,root/'layout/shared',out,runtime]:d.mkdir(parents=True,exist_ok=True)
    for f in ['layout/study/config.tex','layout/study/readflow-layout.tex','layout/shared/readflow-base.tex']:
        shutil.copy2(PINNED/f,root/f)
    snapshots=root/'inputs';snapshots.mkdir()
    copied=[]
    for i,f in enumerate(paths):
        q=snapshots/f'{i:02d}-{f.name}';shutil.copy2(f,q);copied.append(q)
    # Snapshot figure assets, including nested relative paths used by chapters.
    asset_records=[]
    figure_source=V24/'figures'
    if figure_source.exists():
        figure_snapshot=snapshots/'figures'
        shutil.copytree(figure_source,figure_snapshot)
        asset_records=[{'original':str(f),'snapshot':str(figure_snapshot/f.relative_to(figure_source)),'sha256':SHA(f)} for f in sorted(figure_source.rglob('*')) if f.is_file()]
    extra_copies={}
    for k,f in extras.items():
        q=snapshots/f'{k}-{f.name}';shutil.copy2(f,q);extra_copies[k]=q
    texinput=lambda f:r'\input{'+f.as_posix()+'}\n'
    pre=r'''\documentclass[11pt,oneside,openany]{book}
\usepackage{mathtools}
\input{config}
\providecommand{\square}{\mdlgwhtsquare}
\renewcommand{\CurrentVolume}{24}
\renewcommand{\EditionLabel}{V24 / ReadFlow R1}
\hypersetup{pdftitle={Riemann Surfaces},pdfsubject={Chapters 305--312; ReadFlow R1}}
'''
    pre+='\\graphicspath{{'+snapshots.as_posix()+'/}{'+(snapshots/'figures').as_posix()+'/}}\n'
    if 'adapter' in extra_copies:pre+=texinput(extra_copies['adapter'])
    if 'preamble' in extra_copies:pre+=texinput(extra_copies['preamble'])
    pre+='\\begin{document}\n'
    if 'front' in extra_copies:pre+='\\frontmatter\n'+texinput(extra_copies['front'])
    pre+='\\mainmatter\n\\setcounter{chapter}{'+str((a.start or a.chapter or 305)-1)+'}\n'
    pre+=''.join(texinput(f) for f in copied)
    if 'back' in extra_copies:pre+='\\backmatter\n'+texinput(extra_copies['back'])
    pre+='\\end{document}\n';(work/'entry.tex').write_text(pre)
    env=os.environ.copy()
    env['SOURCE_DATE_EPOCH']='1795824200'
    env['FORCE_SOURCE_DATE']='1'
    env['TEXMF']='{/usr/share/texmf,/usr/share/texlive/texmf-dist,/etc/texmf}'
    env['TEXMFDBS']='';env['TEXMFVAR']=str(runtime/'texmf-var');env['TEXMFCONFIG']=str(runtime/'texmf-config')
    env['TEXINPUTS']=os.pathsep.join([str(work),str(source),str(snapshots),*[str(f.parent) for f in paths],''])
    fonts=V24/'dependencies/fonts';env['OPENTYPEFONTS']=str(fonts)+'//'+os.pathsep
    cfg=runtime/'fonts.conf'
    cfg.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><include ignore_missing="yes">/etc/fonts/fonts.conf</include><dir>'+escape(str(fonts))+'</dir><cachedir>'+escape(str(runtime/'font-cache'))+'</cachedir></fontconfig>')
    env['FONTCONFIG_FILE']=str(cfg)
    fmt=runtime/'format';fmt.mkdir(exist_ok=True);env['TEXFORMATS']=str(fmt)+os.pathsep
    if not (fmt/'xelatex.fmt').exists():
        cmd=['xetex','-ini','-etex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-jobname=xelatex','-output-directory='+str(fmt),'xelatex.ini']
        s=subprocess.run(cmd,cwd=work,env=env,text=True,capture_output=True)
        (runtime/'format-generation.txt').write_text(s.stdout+s.stderr)
        if s.returncode:raise RuntimeError((s.stdout+s.stderr)[-7000:])
    prev=None
    for run in range(1,7):
        cmd=['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder','-output-directory='+str(out),'entry.tex']
        s=subprocess.run(cmd,cwd=work,env=env,text=True,capture_output=True)
        (out/f'pass-{run}.txt').write_text(s.stdout+s.stderr)
        if s.returncode:raise RuntimeError((s.stdout+s.stderr)[-7000:])
        state=[SHA(out/('entry.'+e)) if (out/('entry.'+e)).exists() else '' for e in ['aux','toc','out']]
        if state==prev and run>=2:break
        prev=state
    else:raise RuntimeError('Auxiliary state did not converge')
    log=(out/'entry.log').read_text(errors='replace')
    hard=re.findall(r'Missing character:.*|Undefined control sequence.*|LaTeX Warning: Reference.*|LaTeX Warning: Citation.*|LaTeX Warning: There were undefined.*|.*multiply-defined.*|.*destination with the same identifier.*',log)
    over=re.findall(r'Overfull \\[hv]box[^\n]*|Package fancyhdr Warning[^\n]*',log)
    rec={'build_root':str(root),'mode':'fixture' if a.fixture else 'sample' if a.sample else 'chapter' if a.chapter else 'full','passes':run,'hard_diagnostics':hard,'overfull_or_header_diagnostics':over,'underfull_diagnostics':re.findall(r'Underfull \\[hv]box[^\n]*',log),'template_files':[{'path':f,'sha256':SHA(root/f)} for f in ['layout/study/config.tex','layout/study/readflow-layout.tex','layout/shared/readflow-base.tex']],'assets':asset_records,'inputs':[{'original':str(f),'snapshot':str(q),'sha256':SHA(q)} for f,q in zip(paths,copied)],'extras':{k:{'original':str(extras[k]),'snapshot':str(q),'sha256':SHA(q)} for k,q in extra_copies.items()},'pdf':str(out/'entry.pdf'),'pdf_sha256':SHA(out/'entry.pdf'),'status':'ENGINEERING_DIAGNOSTICS' if hard or over else 'ENGINEERING_PASS','visual_status':'NOT_YET_INSPECTED','mathematical_status':'NOT_REVIEWED_BY_BUILD'}
    (root/'build-report.json').write_text(json.dumps(rec,indent=2)+'\n')
    print(json.dumps(rec,indent=2))
    if (hard or over) and not a.allow_diagnostics:raise SystemExit(1)

if __name__=='__main__':main()
