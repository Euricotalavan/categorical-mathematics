# V24 · Riemann Surfaces

Categorical Mathematics · Chapters 305–312 · ReadFlow R1

The reading PDF is in `paired/`. The eight editable chapter files
are in `chapters/`, and the front matter and bibliography are in their
own TeX files. Every exercise has a complete solution.

## Verify and rebuild

From this extracted directory, with Python 3.10+, XeLaTeX, standard
TeX Live LaTeX packages and fontconfig on Linux or WSL, run

```sh
python3 verify_release.py
python3 verify.py
python3 tools/build.py --full --name rebuild
```

The compiled PDF is at `.build/rebuild/build/entry.pdf`. The exact
packaged PDF is the copy under `paired/`. For optional page checks and
rendering, install PyMuPDF and Pillow and run

```sh
python3 tools/inspect_pdf.py .build/rebuild/build/entry.pdf \
  --report .build/rebuild/inspection.json --render .build/rebuild/pages \
  --expect-chapters 305 306 307 308 309 310 311 312
```

`RELEASE-MANIFEST.json` records the size and SHA-256 of each packaged
file. The dependency check verifies the three unmodified ReadFlow R1
template files and the bundled fonts and licences. See `provenance/`
for the exact adopted V0 template baseline and `review/` for scope,
source responsibility, chapter review, layout and final mathematical
audit. The approved reference PDFs can be obtained from the official
links in the source ledger. The archive contains only the edition's
original teaching text, build dependencies and review records.
