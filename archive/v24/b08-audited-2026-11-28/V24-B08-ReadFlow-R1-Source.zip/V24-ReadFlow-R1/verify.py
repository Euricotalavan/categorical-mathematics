#!/usr/bin/env python3
"""Verify the adopted ReadFlow R1 files and portable font dependencies."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "provenance/template-lock.json").read_text())
errors = []
for record in manifest["files"]:
    path = root / record["path"]
    if not path.is_file():
        errors.append(f"missing: {record['path']}")
        continue
    if path.stat().st_size != record["bytes"] or hashlib.sha256(path.read_bytes()).hexdigest() != record["sha256"]:
        errors.append(f"mismatched: {record['path']}")
print(json.dumps({"checked": len(manifest["files"]), "errors": errors, "verdict": "FAIL" if errors else "PASS"}, indent=2))
raise SystemExit(bool(errors))
