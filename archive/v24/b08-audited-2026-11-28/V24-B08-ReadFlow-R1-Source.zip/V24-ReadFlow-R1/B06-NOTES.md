# V24 B06 candidate source

The exact B05 input table is provenance/b05-CHAPTERS.csv, SHA-256
5ff664bbc26759825aa419d961c6dd645b6954cc32dcb0850e3267c5243f1d2a.
CHAPTERS.csv records this layout candidate instead. Mathematical source and
ordering are preserved exactly; removing the recorded 37 local short-unit
wrappers reproduces all original eight chapter byte strings. The wrappers
make only the verified short statements unbreakable. Long proofs and long
examples retain natural continuation. The source includes a local 13pt
contents leading adjustment at the original 9.4pt font size.

The three adopted R1 source files and all locked fonts/licenses are unchanged.
See provenance/b06 for receipt, mutations and exact content-preservation proof.
The sole mathematical final acceptance remains B07, separately signed.

Rebuild with python3 tools/build.py --full --name release; inspect the resulting
.build/release/build/entry.pdf using tools/inspect_pdf.py with expected chapters
305 306 307 308 309 310 311 312. All-page visual inspection remains part of B06.
