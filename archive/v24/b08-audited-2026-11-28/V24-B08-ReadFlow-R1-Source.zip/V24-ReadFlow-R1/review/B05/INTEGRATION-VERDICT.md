# V24 B05 independent source and proof-dependency integration

V24-B05-REFINE-305-312-20261128-v1 · 2026-11-28 · workflow B, single Work · independent refinement task `/root/readthrough61`.

**B05 source/refinement integration PASS for the eight exact files below.** The whole volume was actually read in order, Chapters 305 through 312, including every definition, assertion, proof, example, problem and solution. The final two B05 deltas were then read against that complete B04 text. No unresolved source-coverage, mathematical dependency, symbol-sign, or solution omission was found within the adopted scope. This is a B05 integration verdict, not the sole B07 mathematical final review, PDF/layout acceptance, publication or B08 archival authorization.

## Receipt and exact version

The coordinating parent identified `assembly/b05/chapters/` as the final source freeze candidate, with `assembly/b05/CHAPTERS.csv` SHA-256 `5ff664bbc26759825aa419d961c6dd645b6954cc32dcb0850e3267c5243f1d2a`. This role independently computed that checksum, every file checksum and byte count, and checked them against the table. Paths in this report are relative to `v24-work/`.

| File | Bytes | Lines | SHA-256 |
|---|---:|---:|---|
| `assembly/b05/chapters/ch305.tex` | 37574 | 822 | `9b6f0286f8ac909980d7c6a36b3fecb379c60a12ea5de486e6b0bae89bcdb534` |
| `assembly/b05/chapters/ch306.tex` | 36977 | 856 | `e29d85f0d37a3bf5b7dd35489d6fc125b3ab4f0a5dae980c57a1ffd7d906192e` |
| `assembly/b05/chapters/ch307.tex` | 46112 | 358 | `4a0c3b60dc05594775f62821fb06e0f9850756e21464acdcb7d40295e44ace93` |
| `assembly/b05/chapters/ch308.tex` | 49867 | 369 | `44f076070960e7f4d8147de457b08be8269fa1d0f5e8aa9b0fa83bbff4fb07da` |
| `assembly/b05/chapters/ch309.tex` | 40756 | 958 | `bff3cc03290f95f29c2f76292c08e00c3e60f7b1baa61eeba2ab8d63c9f1592f` |
| `assembly/b05/chapters/ch310.tex` | 46020 | 1035 | `b701037ecd5acdfd80960705136bc9e4e61f47a1e264d16e954f609447062e2b` |
| `assembly/b05/chapters/ch311.tex` | 44400 | 967 | `e68688642f89f11db5c59d7a83b24642ffddd146ce78f7e9221351dbaf5198ca` |
| `assembly/b05/chapters/ch312.tex` | 42589 | 932 | `674aaa183be1b4bcf947fd660f68c5e1e4206fc194b777473eb2075d651c6276` |

Actual inputs also read:

- `review/B01/SOURCE-LEDGER.md`, SHA-256 `65b01085c97ae9f9ff9083ce9feee773d2940d11f5369637d66b162697349cc2`; all 89 responsibility rows, five fixed source versions and the scope/open-boundary notes.
- `review/B02/DESIGN.md`, SHA-256 `f84e29397fc2258423c14b91f9029546e3503eb5c590ad75cc76a78deba9c544`.
- `review/B02/SOURCE-DEPENDENCY-REVIEW.md`, SHA-256 `2bca4eb2b992f865fe2da5f1591a49b727feaab796587b85f668ef11323d51fe`, including its final design supplement and direct Dolbeault scope choices.
- `roles/AUTHORING.md`; the B04 per-chapter refinement reports for 305–311; `review/B04/refinement/ODD-DEPTH.md`; `review/B04/thicken2/ch312-thickening.md`; `review/B04/thicken2/ch309-312-depth-merge.md`. No separate B04 refinement report for 312 existed in the inspected directory at read time; the present role read its entire actual manuscript and all solutions directly.
- Before handoff, also actually read `review/B05/thickening-followup.md`, SHA-256 `44464e32db895abd015aa97a94c05ef41a6e137c16f5499abead2e8cb1c209c7`, including its final `674aaa...6276` chart addendum. It independently accepts the exact two B05 amendments, agreeing with the direct rechecks here.

The B04 reports are historical evidence for their own hashes, not substitutes for actual B05 text. B05 differs from B04 in 309 and 312 only; those exact differences were independently read. Actual serving model and high-mode configuration remain **UNVERIFIED**; this report does not infer them from task names.

## Exact coverage result

`SOURCE-COVERAGE.md` and `SOURCE-COVERAGE.csv` replace prospective B01 destinations with 89 actual source destinations. Every destination anchor was independently resolved against the exact B05 files. The CSV keeps the original version-specific reference locators and separate D/T/P/E status columns; the prose records the concrete result and scope rationale. Table totals are 11, 11, 10, 11, 11, 10, 13 and 12 rows for Chapters 305–312.

The scope dispositions must remain attached to the map:

- 308.11 is optional in B01 but is actually included and proved. Compact finite-map hypotheses, meromorphic coefficient extension and the absence of an unsupported field-degree equality were checked.
- 310.09 is closed by the actual arbitrary-line-bundle argument in 311. Meromorphic-section existence is conditional where used earlier, then obtained from positive index of `L(nP)` before divisor representation is used. The optional placement of the operator in 310.10 is fulfilled at its actual first introduction in 311.
- 311.01, 311.03 and 311.08 follow the direct Dolbeault quotient and constructed six-term sequence explicitly accepted in B02. Abstract sheaf acyclicity, derived/Čech comparison, general skyscraper higher-cohomology statements and a sheaf `H²` comparison are not claimed proved. The direct two-term quotient and each exactness step needed for Riemann–Roch are actually proved.
- 312.09 follows the expressly permitted condensed route: smooth conic and specific Fermat cubic with directly calculated projection and Riemann–Hurwitz. The general plane degree-genus formula, a general quartic worked case and the Bézout/adjunction route are not claimed covered. General uniformization, general Jacobians/Abel inversion, GAGA and general singular normalization remain outside this volume's adopted boundary.

These are scope statements, not UNKNOWN entries silently upgraded to proof coverage. The bibliography's historical catalog-only sources were not used as premises for this review. This role reconciled manuscript coverage with the fixed B01 ledger and existing source dispositions; it did not independently re-extract or re-download the five reference PDFs.

## Whole-volume proof and dependency verdict

**No proof loop or contradictory cross-chapter assumption was found.** The following dependencies were checked in their actual reading order, not merely by their reference labels.

| Seam or risk | Actual evidence and verdict |
|---|---|
| 305 → 306 | Open chart images, nonempty connected Hausdorff second-countable surface, orientation and smooth structure are introduced before map, degree or integration arguments. Map-local constancy uses the already available identity theorem. Local power form proves chart-invariant local degree independently of divisors. |
| Properness and degree | The target is connected, the source nonconstant; compact-source properness is justified. The closed complement of selected local power disks excludes hidden preimages before a constant weighted degree is asserted. Poles are not automatically critical points. |
| 306 → 307 | Riemann–Hurwitz uses only the finite-sheet neighborhood argument already proved in 306, plus explicitly adopted surface triangulation/Euler facts. It does not depend on 307's later universal-cover classification or on Riemann–Roch. |
| 307 → 308 | Right monodromy, first-then concatenation, reversed ordinary transport composition and cosets `H\\G` remain consistent. Universal-cover and reachable-germ countability each keep selected overlap components in their codes. Finite filling verifies all surface conditions, compatibility, properness and uniqueness. |
| Local inverse versus covering | The exponential-strip and cubic-inverse examples actually lack global path lifting. 308's homotopy stability assumes every row lift exists. Its all-path hypothesis is transferred to every reachable starting germ before disks are shown evenly covered. No step infers covering merely from local biholomorphicity. |
| 308 → 309 | Meromorphic behavior is operationally explained before algebraic filling and proved by growth. The sphere-rationality fact needed in 308 is proved there in the symmetric-factor argument, so the more systematic 309 proof is not an unproved forward premise. |
| 309 → 310 | `D-E=div(h)` consistently means multiplication by `h` from `L(D)` to `L(E)`. Frame convention `e_j=g_ij e_i` gives coefficient `a_i=g_ij a_j`; `O(D)` uses `z^{-D(P)}` and its section represented by 1 has divisor `+D`. `K_X` the bundle and `K` the representative divisor remain distinct. |
| 309–310 → 311 existence | No universal nonzero differential or meromorphic bundle section is assumed early. Explicit sphere/torus/curve examples supply their own sections. 311 proves arbitrary-L finiteness, duality and point twists, obtains positive index, then meromorphic sections and a nonconstant function. |
| 311 local analysis | Cauchy-kernel sign is proved against tests; derivatives transfer to compact cutoff data. Nested disks precede Montel and Cauchy estimates. Orthogonality is the global finite-dimensional L² projection. Smooth completeness and closed range are justified before quotient separation. |
| 311 duality | `(0,1)` is wedged before `(1,0)`, yielding `+2i dA`. Supported annihilators give complex-linear distributions; radial smoothing plus a fixed radial mean kernel proves weak holomorphicity. The `b/(2i)` factor and dual transitions glue the right bundle. Finite continuous dual plus Hahn–Banach separation precede the identification with the algebraic dual. |
| 311 point twist | Inclusion coefficient is `z`, target fiber is the quotient. Every exactness position and final surjection is constructed. Smooth division is used only after neighborhood vanishing or a proved smooth multiple of `z`, never merely from a zero value at the point. |
| 311 genus comparison | `g_a=h⁰(K_X)` first; positive divisor index gives nonconstant `f`; `df` gives a canonical representative. Its degree from the independently proved Riemann–Hurwitz is compared with duality/index at `K`, only then identifying topological and analytic genus. |
| 311 → 312 | High-degree vanishing uses strict `>2g-2`; applications keep the correction at equality. Function principal parts test all holomorphic differentials; differential parts test constants. The cutoff/Stokes coefficient is consistently `-2πi` on clockwise inner circles. |
| 312 maps and examples | Large-divisor point/tangent separation uses the four actual dimension drops before compact embedding. Hyperelliptic bases check finite branch and both infinity parities before the dimension argument. Torus cubic smoothness follows from distinct half-period branch values before using its degree-one identification. The chord rule keeps its marked flex and inverse residual sign. |

Adopted analytical background is explicit at the start of 311: Cauchy estimates, Montel, Stokes, finite smooth partitions and the needed Hahn–Banach separation consequence. Local solvability, closed range and weak holomorphicity are proved rather than imported as unexplained advanced prerequisites. Repeated sphere/torus/order calculations agree and have different teaching roles; none produces contradictory assumptions or proof dependence.

## Defects, corrections and actual recheck

| Original text/location | Impact | Corrected exact text/location | Recheck evidence |
|---|---|---|---|
| B04 `ch309.tex` 294–296 invoked `L(np_infinity)` and its polynomial basis before the first definition of `L(D)`. | First-use notation and proof-order gap in the newly added conic example. | B05 removes the forward-use sentence and places the conic basis immediately after the sphere basis, following the definition and its dimension proof. | Direct diff read; conic coordinate `u=B/A`, inverse parameter `1/u`, bases `1,u,...,u^d`; current ch309 hash `bff3cc...592f`. |
| B04 `ch312.tex` had no explicit `n=0` monomial-system map, `n=1` identity case, or two-coordinate inverse verification for all `n>=2`, although general embedding was proved. | B01 312.07 requested these concrete edge cases; they were implicit rather than actual example coverage. | B05 `sec:312-embedding` explicitly gives `P⁰`, identity at degree one, homogeneous monomials, and recovery of `z` and `w` by the two coordinate ratios. | Direct final delta read; ratios are defined on their stated standard charts and are inverse local parameters; injectivity/derivative and compact embedding argument valid; current ch312 hash `674aaa...6276`. |
| B05 parent also added the explicit definition of `|D|` and basis-change rule. | Closes actual-definition and invariance coverage for B01 312.05. | Nonzero `f` maps to `(f)+D`; quotient by constants gives projective space, with empty system handled; matrix `A` changes the map by `[v]→[Av]`. | Read and checked the full delta. Divisor-zero quotient is a nonzero constant on compact connected X; base-point description agrees with coefficient vanishing. |

Both issues raised by this sequential review are **CLOSED for the exact B05 freeze**. This role changed no manuscript file; the coordinating parent applied the corrections and this role rechecked their mathematical content and placement.

## Problems, references and mechanical corroboration

All 108 problems and all 108 full solutions were actually included in the sequential read, including embedded depth problems and the separated solution sections of 309 and 310. Recomputed the local normal-form/root counts, rational infinity multiplicities, subgroup actions, primitive periods, divisor multiplier signs, Laurent-mode twists, principal-part residues, gap counts, torus cubic and chord examples. No missing problem solution or cross-chapter prerequisite for a solution remains identified.

| Chapter | Problems | Solutions |
|---|---:|---:|
| 305 | 12 | 12 |
| 306 | 13 | 13 |
| 307 | 14 | 14 |
| 308 | 14 | 14 |
| 309 | 14 | 14 |
| 310 | 14 | 14 |
| 311 | 13 | 13 |
| 312 | 14 | 14 |

`verification.json` independently records exact bytes/checksums, 235 unique source labels, no duplicate labels and no unresolved `ref`/`eqref` targets. Counts and resolved labels corroborate the read; they do not substitute for mathematical completeness. Source-line locators are established here; final PDF pages and paired PDF checksum are **UNKNOWN to this role** and remain B06 evidence.

## Pasteable handoff

- **Role / phase / scheme:** independent refinement, V24 B05, workflow B single Work; old A correspondence is whole-volume source/refinement integration after complete drafting/thickening and before layout, not the retired multi-role NO OBJECTIONS ending.
- **Adoption basis / chapter identity:** coordinating parent conveys existing user authorization for B01–B08 and eight chapters 305–312. V23 ends at 304, fixed predecessor commit `f134c70ebe7fe7af0143dd557d56ddd953a14c68`. B05 does not renumber or restart.
- **Unique manuscript:** the eight `assembly/b05/chapters/ch305.tex`–`ch312.tex` files at the full checksums above; `CHAPTERS.csv` checksum `5ff664...f1d2a`. No publication commit is asserted by this role.
- **Available files:** `review/B05/INTEGRATION-VERDICT.md`, `SOURCE-COVERAGE.md`, `SOURCE-COVERAGE.csv`, `verification.json`, plus the exact source files and upstream evidence listed above.
- **Actually established:** ordered whole-volume proof/definition/solution read, final delta recheck, 89 actual source-responsibility destinations, preserved optional/route boundaries, no remaining identified dependency loop, wrong multiplier sign, hidden section-existence premise or missing solution; 108/108 solutions and 235 label destinations mechanically corroborated.
- **Dependency-change impact:** B05 changes only ordering/clarity and explicit elementary complete-system examples. No theorem hypothesis, mathematical route, chapter order, fixed source version or breadth is changed. In particular the closed-range→duality→point twist→existence→genus chain is preserved.
- **OPEN:** B06 ReadFlow R1 layout/read-flow QA and actual source/PDF pairing; sole B07 strict whole-volume thickening final review and any required recheck; B08 only under existing authorization and required visibility/content checks by the coordinator. No unresolved B05 mathematical/source-integration defect is identified at these hashes.
- **UNKNOWN:** actual service model/high configuration; final PDF page locators and checksums; recipient read-in; any later file mutation or future archive commit. No previous V1/V2 or frozen volume acceptance is inferred.
- **Layout fields:** formally adopted V0 ReadFlow R1 baseline is recorded upstream at artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`; no template modification, PDF layout acceptance or learning-effect claim is made by this source review. S2.1 remains calibration history.
- **Next step / pass conditions:** coordinator reads these actual files and matches the exact table, proceeds to B06 using the same content, then returns the integrated paired edition to the sole B07 strict final reviewer. Any substantive later source delta must return for independent mathematical recheck; archive source checksum must match this edition or be explicitly superseded.
- **Prohibited redo:** no new volume or frozen work starts; no source-table/tool ZIP alteration; no automatic switch to C; no reuse of historical candidates as the unique B05 manuscript; no inference that prose creation equals delivery or receipt.
- **Delivery:** this evidence was written into the shared workspace and reported to the coordinating parent. The parent must acknowledge actual read-in/version checks. No external transmission or publication was performed by this role.

Signed source-level integration verdict: independent refinement task `/root/readthrough61`, exact freeze above, **B05 PASS**.
