# V24 B-05 independent thickening follow-up

Verdict **PASS** on the exact localized amendments below. The comparison
was made against the previously audited merged B-04 chapters. No chapter
source was modified in this follow-up.

| Chapter | B-04 base SHA-256 | Follow-up candidate SHA-256 |
|---|---|---|
| 309 | fc11e0f41c2afe7639b299717a47f4ab83155cf1d45c4ec238b8ff3fdcc5b652 | bff3cc03290f95f29c2f76292c08e00c3e60f7b1baa61eeba2ab8d63c9f1592f |
| 312 | 6e0f23d680a83b65b2d199e62b7e2f126552d56f6ae8009530b8c243d63f9089 | 0b62492bd591b2a2cf19bbfeadbfea6cac8612f17c509a30a9d3e33bb07be79c |

**Chapter 309, conic and pole-space placement.** The original conic
coordinates, biholomorphism and simple-zero/simple-pole proof remain
intact. The basis sentence now follows the definition of the pole
space and its sphere computation. On the conic the complement of
\(p_\infty\) is the \(u=B/A\) affine chart and \(1/u\) is a centered
coordinate at \(p_\infty\). The entire functions with pole order at
most \(d\) there are exactly the polynomials of degree at most \(d\)
by the preceding sphere argument. Those monomials are independent.

**Chapter 312, complete systems and the projective map.** Effective
divisors in the class of \(D\) arise from nonzero members of its
pole space by linear equivalence. Two members produce the same
divisor precisely when their quotient has divisor zero, which
gives the scalar equivalence by the earlier compact connected
result. The case of zero-dimensional section space correctly gives
an empty system. A nonzero section's vanishing order in the divisor
frame is its divisor coefficient, so the two base-point criteria
agree. Changing the basis acts on the coefficient column by one
invertible matrix and therefore postcomposes the map by the
associated projective automorphism. For the zero divisor on the
sphere the nonzero constant section gives the constant map to
\(\mathbb P^0\), and the positive-degree polynomial bases agree
with the previously checked examples.

Signed by the independent B-04 thickening reviewer for Chapters 309–312.
The source-side amendment check passes on the listed hashes.

**Chapter 312 chart addendum, exact snapshot PASS.** Compared SHA-256
674aaa183be1b4bcf947fd660f68c5e1e4206fc194b777473eb2075d651c6276
against the previously reviewed 0b62492bd591b2a2cf19bbfeadbfea6cac8612f17c509a30a9d3e33bb07be79c.
The only change is the monomial-map calculation. At degree one it
is the identity in the chosen coordinates. At higher degree the two
extreme coordinates cover the image, and the adjacent ratios recover
\(t/s\) and \(s/t\) on those charts. These holomorphic left inverses
give point separation and an injective derivative. Compactness of
the source and Hausdorffness of the target give the embedding.
Signed by the independent thickening reviewer on the stated hash.
