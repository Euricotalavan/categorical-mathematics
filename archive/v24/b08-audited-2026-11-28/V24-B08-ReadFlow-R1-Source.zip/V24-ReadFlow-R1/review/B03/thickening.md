# V24 B-03 independent thickening review

2026-11-28 · Calibration section 306.2, *The local power normal form*  
B workflow, single Work · thickening review for the primary coordinator  
Received and read all 140 lines of roles/design/calibration-306-2.tex. SHA-256 6ab6c25e629cf21956a634fe0d7c8b8ee5e8cc5f7817c5d7bb0225c90d172aaf. Compared the local power form with McMullen §3, printed pp. 15–17, and Teleman Lecture 4, PDF pp. 14–16. Agent role is independently assigned; service-side model and reasoning configuration are unverified.

**Mathematical and instructional review passed.** The section supplies a usable depth calibration for Chapters 305–312.

| Location | Independent check |
|---|---|
| Lines 6–28 | The source and target have centered coordinates. Connectedness and the identity theorem exclude a locally constant germ for the stated nonconstant map. |
| Lines 30–47 | The nonzero factor, choice of a root of its value at zero, convergent local binomial factor and nonzero derivative of the new coordinate are all explicit. The local inverse theorem applies exactly at this last step. |
| Lines 49–60 | Both coordinate changes preserve the first nonzero power. The transformed coefficient \(d a_e c^{-e}\) is nonzero and the higher terms have the stated orders, including \(e=1\). |
| Lines 63–97 | The local degree and the contribution \(e-1\) are distinct numerical objects. Counting roots on a specified disk establishes openness and discreteness of each fiber and identifies the local biholomorphism case. The discussion correctly limits the count to that disk. |
| Lines 99–123 | In the finite example the normalization, Taylor coefficient, degree and contribution all check. At infinity reciprocal target coordinate turns the affine pole into a local power of positive exponent. |
| Lines 125–140 | The exercise's fourth power, nonzero derivative and count of four distinct small nonzero roots are correct. The solution can be reconstructed from the earlier theorem and the stated computation. |

Labels are unique within the section and the local theorem reference resolves to the object used. No cross-chapter result is used before it is due apart from earlier chart definitions and standard single-variable prerequisites.

Line 112 can say “Every sufficiently close value different from \(2\) has three distinct preimages near \(\zeta=1\)” to make the punctured range explicit in the example. The general argument at lines 72–78 already makes the exception clear. An optional worked extension at the same spot computes \(f'(-2)=-27\), giving a fourth simple branch and a precise illustration of the difference between local and global fiber counts. Neither observation affects the validity of the calibration. No source text was edited in this review.

B-04 can reuse the scale of expansion here: state the chart or object, show the necessary local construction, and check the resulting hypothesis in a worked case. The manuscript and its paired PDF will receive their own reviews once fixed.
