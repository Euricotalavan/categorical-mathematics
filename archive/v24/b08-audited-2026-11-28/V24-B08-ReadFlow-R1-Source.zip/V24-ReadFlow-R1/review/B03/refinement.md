# V24 B-03 independent refinement review

2026-11-28 · B workflow · review61 · decision **PASS for this calibration section**.

## Actual receipt

Read all 140 lines of `roles/design/calibration-306-2.tex`, SHA-256 `6ab6c25e629cf21956a634fe0d7c8b8ee5e8cc5f7817c5d7bb0225c90d172aaf`, including theorem, complete proof, definition, corollary proof, both examples and exercise solution. Compared the fixed source text: Teleman §3.10–3.12 (PDF p.13; local-power theorem, invariant valency, local constancy) and McMullen Theorem 3.2 (PDF pp.17–18; root coordinate and finite local multiplicity). These are the B01 responsibilities 306.01–.03, with an illustrative infinity calculation from 306.07. This is no claim that all of 306.07 is covered.

## Semantic and reading evidence

| Lines | Actual mathematical check | Result |
|---|---|---|
| 8–16, 20–28 | Connected nonconstant source rules out local constancy. The proof's closed/open neighborhood-constant set uses continuity at a limit point and the identity theorem in a common target chart; it does not assume the local-power theorem to prove itself. | PASS |
| 30–47 | First nonzero Taylor coefficient has index e≥1. Write F=ζ^e u, choose b^e=u(0), make |u/u(0)−1|<1, use the binomial branch, then z=ζv. Its derivative is b≠0, so the inverse function theorem produces the required inverse coordinate. The equality is w∘f=z^e with the fixed target coordinate. | PASS |
| 49–60 | In centered source/target changes with coefficients c,d≠0, the new leading coefficient is da_e c^(−e)≠0. The target error O(w²) has order ≥2e≥e+1, including e=1. Therefore the order is coordinate independent. | PASS |
| 63–80 | Local degree e, contribution e−1, critical point in source and branch value in target are distinct and usable. The roots are counted in the specified z-coordinate disk, with radius matched to r^e in the target. The text explicitly avoids a global fiber claim. | PASS |
| 82–97 | Small power disks prove openness and isolated fiber points. For e=1, the map is the identity **in the two coordinates**, hence a local biholomorphism; this is not an assertion that f itself is globally the identity. For e>1, equal-image root sets shrink to p, precluding local injectivity on any neighborhood. | PASS |
| 101–114 | With s=ζ−1, the unit is 3+s. Cubing the stated coordinate gives s³(3+s). Binomial expansion gives 3^(1/3)(s+s²/9+O(s³)); derivative is nonzero. Local degree 3 and contribution 2 are correct. The far-away fourth polynomial preimage is excluded explicitly from the local count. | PASS |
| 117–123 | For the sphere power map at infinity, source s=1/ζ and centered target w=1/y yield w∘f=s³. The affine pole exponent −3 is correctly distinguished from local degree +3. | PASS |
| 125–140 | (s²+s³)²=s⁴(1+s)². The chosen z=s(1+s)^(1/2) has derivative 1 and fourth power equal to this factorization. Four nearby nonzero solutions follow in its coordinate disk; local degree 4 and contribution 3 are correct. | PASS |

The reading depth is appropriate: it exposes the nonvanishing-unit root, derivative, inverse coordinate, order invariance and radius control rather than asking the reader to reconstruct them. The example tests a nontrivial unit; infinity tests target coordinates; the independent exercise changes both exponent and root. No sentence needs deletion for calibration, and no missing nontrivial lemma needs repair. This section does not yet supply degree composition, properness, global finite fibers, global ramification finiteness or RH; those remain subsequent responsibilities.

## Handoff

B-03 representative §306.2; review result concerns the exact hash above. Chapter range remains 305–312, V23 baseline commit f134c70ebe7fe7af0143dd557d56ddd953a14c68. Unique sample body is the design role file; this reviewer made no competing body and no production edits. No PDF received, compiled or visually reviewed here. ReadFlow R1 layout remains for B-06, and B-07 final acceptance belongs only to thickening.

Model/reasoning: requested role configuration is not independently observable; actual configuration remains **unverified**. OPEN: B-04 actual chapters, chapter-level dependencies and precise eventual coverage destinations; engineering/PDF and whole-volume acceptance. Next action: read actual Ch305–306 after authoring and thickening input, inspect every claim and safe refinement need, then return localized repairs or acceptance. Do not restart B-01/02, renumber, modify frozen work or publish. This file's creation is review documentation; delivery and root's actual reading remain separate.
