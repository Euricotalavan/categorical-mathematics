# V24 B-03 representative section

V24-B03-306-2-20261128-v1 · V24 Riemann Surfaces · B single Work
· Chapters 305–312 · 2026-11-28, Taipei. Representative section §306.2
accepted by the coordinator for B-04 after independent expansion,
thickening and source/refinement checks.

The B-01 source ledger has 89 source responsibilities. B-02 has been fixed
at DESIGN.md SHA-256 f84e29397fc2258423c14b91f9029546e3503eb5c590ad75cc76a78deba9c544
and source/dependency review SHA-256
2bca4eb2b992f865fe2da5f1591a49b727feaab796587b85f668ef11323d51fe.
V23 publication f134c70ebe7fe7af0143dd557d56ddd953a14c68 supplies the
starting chapter 305. B-03 calibrates B's combination of original A
drafting, proof expansion and source verification before full chapter work.

| File | Status and identity |
|---|---|
| calibration-306-2.tex | Accepted body, 6620 bytes, SHA-256 6ab6c25e629cf21956a634fe0d7c8b8ee5e8cc5f7817c5d7bb0225c90d172aaf |
| sample-entry.tex | Build input with chapter wrapper, 6703 bytes, SHA-256 c5c846d760ac8742470327c292a677fa1fcdb1f8cb5d25575210eec6b9eb67c8 |
| V24-B03-Sample.pdf | Paired three-page PDF, SHA-256 585a843be20a9d2cddbb1593c802c1f0721483c41f61d7b01e6f3d4ab141ce29 |
| thickening.md | Independent reread of the fixed sample. Proof and depth pass. |
| refinement.md | Independent source and semantic check. All 140 lines and relevant sources checked. |
| build.json, inspection.json | XeLaTeX two passes, no hard or overfull diagnostics. Three pages rendered, correctly numbered and inspected by coordinator. |

The sample keeps the nonvanishing factor, root branch, coordinate
invertibility and transformation of leading coefficient separate. It
links the theorem to the exact disk in which multiplicity counts roots
and works an ordinary branch point, an example at infinity and an
exercise with a complete solution. This sets the proof and example
density used by the subsequent authors.

Use the sample with the exact pinned ReadFlow R1 scope in the included
scaffold. From its root run
`python3 tools/build.py --sample review/B03/sample-entry.tex --start 306 --name b03-calibration`.
The three template components, available fonts and compatibility audit
are pinned separately from the sample. No production full-volume PDF or
global cross-references exist at this checkpoint.

The next role is each chapter expansion author, starting B-04 within
the fixed eight chapters. Each chapter is reviewed by an independent
thickening role and then a source/refinement role before production
integration. The B-04 source locators, DOI author files, font licences
and inherited open boundaries remain in the included evidence.
No service routing is inferred from role titles. The refinement task was
configured GPT-6.1 Sol High; model-serving identity is unverified.
This is an internal Work handoff and the evidence is available in place.
