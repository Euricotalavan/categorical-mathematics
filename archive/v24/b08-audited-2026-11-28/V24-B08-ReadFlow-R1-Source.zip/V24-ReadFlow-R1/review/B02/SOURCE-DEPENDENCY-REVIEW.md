# V24 B-02 精修獨立複核

V24-B02-REFINE-20261128-v1 · B 方案單一 Work · 第 305–312 章。讀入 B-01 SOURCE-LEDGER.md v1，SHA-256 65b01085c97ae9f9ff9083ce9feee773d2940d11f5369637d66b162697349cc2，及 B-02 DESIGN.md v1，SHA-256 eaba17e2e8ba1a70e0881c121e3ab61f8765134dfd6d27021448eb9063e06601。精修任務與擴充稿分立，實際服務端型號和推理設定未核實。

**以設計通過。** 311 的閉值域、對偶、Euler 跳躍和 genus 對照具備可閉合依賴。文獻責任可沿 305–312 的固定章次落入主體，B-05 才能核對完成正文位置。下一階段依代表節 306.2 校準。

| 核查重點 | 結果 |
|---|---|
| 305–306 的定義／先備 | 先定圖，後定全純映射，再用 order 和局部 holomorphic root 得正規形。定義映射階數時用局部展開先述；309 再把整數 valuation 系統化。加權纖維恆定需 properness，Euler 計數與 RR 無前置依賴。 |
| 307–308 的拓撲分工 | 盤鏈在一般曲面交集可能不連通，需指定交集的分支，取各分支內固定交點代表。解析的平面圓盤交集則凸。兩組 countability 論證各自覆蓋。局部雙全純與覆蓋分別使用，三次多項式去臨界點是仍滿射的反例。 |
| 309–310 符號與型別 | 選擇 e_j=g_{ij}e_i，係數 f_i=g_{ij}f_j。O(D) stalk 以 z^{-D(P)} 為 frame，常數 1 的截面除子為 D。先證有 meromorphic section 下的同構，任意 bundle 的 meromorphic section 由 311 之後的 χ 增長證明。 |
| 311.01 的來源取捨 | 可採直接定義 H¹ 為 Dolbeault cokernel，原索引將 Čech/derived 和直接連接段列為備選。應保留局部 section gluing 與 stalk fibre 型別解釋。完整層上同調比較與 Čech refinement 做法超出已選主線，記為範圍排除。 |
| 311.03 的來源取捨 | 用 A^{0,2}(L)=0 及直接六項正合段。H^{0,2} 消失與抽象層上同調 H² 比較需要不同的證據，所以正文使用 Dolbeault 標記並避免無證等號。光滑分割統一仍用於選擇 metric、area、cutoff。 |
| 311.05–.07 的緊性與對偶 | 證明必須在有限組嵌套盤上先得到局部有界餘部，進而由 Cauchy estimates 得固定 C^k 收斂。取 kernel 的全局 L² 正交補。連續對偶的有限維和 Hahn–Banach 分離才給商空間代數有限維。 |
| 311.08 的正合性 | Inclusion 局部是乘 z。取固定 cut-off extension b of q，δ(q)=[i^{-1}∂̄b]。若 iα=∂̄u，先作局部 v 滿足 ∂̄v=α，使 u−iv 全純再讀 q=(u−iv)(P)。局部分子減去 b 的全純常數項後可除 z，證 ker(i*)⊂im δ。最後一項的滿射來自給 L(P) 的 (0,1)-代表減去局部 primitive 的 cutoff 導數，讓代表在 P 附近消失。 |
| 311.10 的 genus 閉合 | 先寫 g_a=h⁰(K_X)，以正除子維數推出非恆定 f。RH 計 df 除子得 2g_top−2，對偶給 h¹(K_X)=h⁰(O)=1，Euler 式得 2g_a−2。由此比對，再統一記 g。早章不使用未證的 meromorphic differential 普遍存在。 |
| 312 的應用邊界 | 正合段支持主部障礙。記積分配對排序和挖洞的邊界定向，使殘數公式的整體符號可追。大除子需確認 D−2P 的 jets，平面曲線可用由 RH 已能證的具體族。 |

**B-04 查核要保留。** 311.4 的 Weyl 證法可在同一小盤取固定徑向 bump，用 holomorphic mollification 的平均性反推分布是光滑全純函數。311.5 的除 z 證明須先造成 vanishing in a neighborhood 或 holomorphic vanishing。任意光滑函數在 P 取值 0 尚不能除 z。將上表風險連到固定稿的實際節號待 B-04、B-05。原文獻版本、章域與 ReadFlow R1 基線沿 B-01 交接。

## 最終設計補核

已回讀 DESIGN.md 的最終版本，18,214 bytes，SHA-256 f84e29397fc2258423c14b91f9029546e3503eb5c590ad75cc76a78deba9c544。接受以下三項補充，維持設計通過。

- 任意 holomorphic line bundle 已由同一解析證明取得有限維，點扭曲正合段可直接套用，故 $\chi(L(D))-\chi(L)=\deg D$。取足夠大的 $n$，$L(np)$ 的非零 holomorphic section 即 $L$ 的非零 meromorphic section。這項推導可在證明一切線叢由除子表示之前完成。
- 微分主部用 $L=K_X$ 的同一個 cutoff 障礙構造。其對偶全純截面空間為 $H^0(\mathcal O_X)=\mathbb C$，所以只需檢驗總留數。
- 配對固定先放 $(0,1)$ 型代表 $\eta$，再放對偶形式 $\omega$。在 annulus 有 $\eta\wedge\omega=d(\chi p_P\omega)$，內圈是負向邊界，故在正向圓周約定下殘數係數為 $-2\pi i$。同樣約定覆蓋函數和微分兩種主部問題。
