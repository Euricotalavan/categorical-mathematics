# V24 B-02 · 整卷設計

版本 v1 · 2026-11-28 台北 · B 方案單一 Work · 擴充角色提出，已納入精修 B-01 銜接複核與主控核定。
交接 ID V24-B02-305-312-20261128。授權為確認公開來源後自動執行 B-01–08，主控承接原使用者檢查，分開執行四角色任務。第 305–312 章固定，承接 V23 Git `f134c70ebe7fe7af0143dd557d56ddd953a14c68` 第 304 章。採 B-02 整卷依賴設計，銜接舊 A 的先備與邊界核對。讀入 `V24-Reference-Readiness-v1.md`，SHA-256 `31f93cbb679a5dc47db218a93823dc2af559227d394d28838635c9df256e487d`；文獻頁與各版本雜湊沿該表及 B-01 索引。實際讀入 `review/B01/SOURCE-LEDGER.md`，SHA-256 `65b01085c97ae9f9ff9083ce9feee773d2940d11f5369637d66b162697349cc2`。模型與推理：分立擴充任務，實際服務端型號與推理配置未核實。

## 敘事和先備

讀者先知道什麼叫曲面及全純映射，再經覆蓋與芽把多值函數變成曲面上的單值函數。接著問可以指定哪些零與極點，用除子量化，用線叢把局部極點限制變成全純截面的條件。最後由局部可解的 Cauchy–Green、緊性和對偶性推得全卷的維數公式，回頭解球面、環面、雙曲面與主部問題。

先備限定單變數複分析的冪級數、全純根的局部存在、Cauchy 積分、留數、極值原理與同一律；基本點集拓撲、基本群與路徑同倫；有限維線代、向量空間對偶、Stokes 定理及緊可定向曲面三角剖分和 Euler 特徵。中華教材常見的單變數先備可以作回顧條，不假設層上同調、Hodge 理論、Dolbeault 比較定理、橢圓算子理論、概形、一般 Riemann 存在定理。光滑分割統一、Montel/Cauchy、Hahn–Banach 的用法要在首次出現時標述；分布臨時定義成測試函數上的連續線性泛函即可，證明所需的局部規則在 311 引入。Gathmann §8 須維持光滑射影平面曲線前提，作例題另一條驗證路徑。

章級依賴，箭頭表示左端結果供右端使用：

- 305 → 306、307、308、309、310。
- 306 → 307 的分歧局部模型、308 的代數例、309 的局部階與留數、311 的 genus 比對、312 的映射例。
- 307 → 308 的單值性和穿孔填補。
- 308 → 309 的代數曲面例，為例題邊而非 Riemann–Roch 論證前提。
- 309 → 310 → 311 → 312。309 的全純函數常數事實也供 311 的 chi 基點使用。
- 306 的 Riemann–Hurwitz 證明只用拓撲 Euler 特徵，311 才把兩種 genus 對上。311 可依此比對，306 不援引 Riemann–Roch。

## 章節、證明、算例與反例

篇幅校準以 McMullen 的 183 頁作比照。預估成書以每章約 17–29 頁的自然展開形成主要篇幅。全卷約 170–210 頁是規劃參考，另按 ReadFlow 實測調整。需要增加的是可重現的證明、一步步計算、辨識錯誤假設的反例和足量詳解，不用拉大版面。各章上列 8 小節可因教學需要拆分，章號與章題維持固定。

### 305 · 複結構與曲面圖冊

1. **Topology of charts.** Hausdorff、第二可數、連通的共同約定。開集上的同胚、座標重疊、非連通重疊逐分支讀。
2. **Atlases and maximal compatibility.** 證相容是可擴至最大圖冊的等價關係。相容傳遞從中間圖冊逐點選圖；有標記的曲面和雙全純等價分清。
3. **The sphere and projective line.** 兩張圖 `z,w=1/z` 的完整檢查。齊次座標下推導同一轉換，補 `z=-1` 與 `z=∞` 的轉換例。
4. **Plane domains and orientation.** `dz/dw≠0` 的微分矩陣，Jacobian 為模平方。以共軛圖展示不相容的定向。
5. **Quotients with translation charts.** 離散格、基本平行四邊形、圓柱與環面。證選小盤使各平移不交；在商空間檢查 Hausdorff 和第二可數及章內使用的定向。
6. **Implicit analytic curves.** 由某一偏導非零得到圖冊，證交換投影時圖轉換全純。在 `w²=z` 與 `zw=1` 算不同有效圖，結節 `zw=0` 失敗。
7. **Gluing and separation.** 兩張圖沿開子集黏合，給黏合 Hausdorff 的具體判準；雙原點反例，診斷開局部圖不足以推出 Hausdorff。
8. **Functions and identity.** 局部定義、開集與連通性，證零點孤立和局部等式的傳播，用極值原理證緊曲面全純函數常數。引入兩個圖冊間的全純映射及其座標獨立性，做 Möbius 例。習題含換圖驗算、錯誤定向、環面搬移、曲線奇點。

### 306 · 全純映射與分歧

1. **Holomorphic maps.** 用始域、靶域雙圖定義；合成、雙全純，沿用 305 的座標獨立性，補目標中心和差值寫法。
2. **Power normal form.** 證非恆定映射局部 `w=z^e`，寫出非零因子、根與可逆性三步。區分發生階 `e` 與分歧貢獻 `e−1`。
3. **Open maps and discrete fibers.** 從 normal form 證開映射；緊或 proper 才使離散纖維有限。非 proper 指數例。
4. **Proper maps and sheet counts.** proper closed，對有限纖維選互斥盤後排除遺漏 sheets，同時證局部加權纖維數恆定。
5. **Finite maps of compact surfaces.** 值域連通下滿射。有限臨界點、正常值附近 sheets、離散例外，複合映射的指數乘法。
6. **Euler characteristic and branching.** 將臨界值列入頂點，提起邊和面的計數，逐纖維解釋頂點短缺 `∑(e−1)`，推 Riemann–Hurwitz。
7. **Worked maps.** `z^d` 在 0 和 ∞；`(z²−1)/z` 的臨界點與不同纖維。環面的自乘映射 `[z]↦[mz]` 具 `m²` sheet 且無分歧。
8. **Pullbacks and compatibility.** 光滑一形式 pullback 可先只描述局部公式，正規形對複合階數、反覆映射的分歧位置；詳解用 RH 排除不存在的指定分歧資料。

### 307 · 覆蓋與單值性

1. **Evenly covered neighborhoods.** 定義可數與有限 sheets，覆蓋的局部同胚須和只具局部逆者區分。指數和穿孔盤幂圖。
2. **Path and homotopy lifting.** 有限細分及選 sheet，唯一性證明。用方格重疊、起邊升舉及連續拼接證同倫升舉。
3. **Monodromy convention.** 首走 α 後走 β 的 `αβ`，右作用在纖維上。連通等價傳遞；明定商的左右 coset 和置換書寫規則。
4. **Path-space universal cover.** 在可局部單連通曲面中以路徑類建立，用小盤定義圖與覆蓋，證新空間 Hausdorff 和單連通。
5. **Subgroups and deck transformations.** 由路徑起點的升舉穩定子到覆蓋；相應共軛與基點差異。用穿孔盤算 `dℤ⊂ℤ`，做非正規三葉覆蓋反例的單值排列。
6. **Complex structure of topological covers.** 以提升圖由靶域曲面唯一拉回圖冊。可在小展開處檢查。
7. **Filling punctures.** 有限度形成穿孔盤覆蓋的有限週期，各成分等價 `u↦u^e`，添加一點、驗明緊性/可分離與唯一性，直到能把特例應用在 308。
8. **Examples and limits.** `log` 螺旋及有限 `d` 次根對比；非正規覆蓋的 deck 群不作全體 permutation；有限覆蓋用 monodromy 讀每個 puncture 的 `e`。

### 308 · 解析延拓的曲面

1. **Germs and compatible representatives.** 用鄰域相等定義芽；證芽等價關係與芽上運算。
2. **Continuation along a path.** 用路徑上由代表函數串接的局部連續芽提升，證唯一與反向接續。
3. **Étale space and reachable component.** 以全純元素的圖定義芽空間的局部雙全純投影。對分支必須有可達性，排除不相關的芽。
4. **Hausdorff and countability.** 同投影的不同芽選公共盤，用同一律證圖不相交。從固定芽出發，有限個有理盤鏈每條借連通重疊確定至多一套延拓；所有可達點落在這些可數圖。一般全體芽空間的第二可數性不可由同一論證推定。
5. **Pointed maximal continuation.** 定義 `(Y,y₀,π,F)` 且 π 局部雙全純，賦予唯一保持 π 與 F 的芽映射。由值映射是全純並由公式決定芽，證普遍性。
6. **Monodromy theorem.** 假設沿每條路徑可延拓；證兩條端點固定的同倫路徑的芽由相鄰同倫小段不變。局部雙全純性與遍歷可延拓條件需分寫。
7. **Algebraic germs.** 有限例外值外以互異根與隱函數得到覆蓋，puncture 局部填補和亞純延拓以成長估計或已知具體正規形完成。二次根、三次 `w³−3w` 分別算 sheet。
8. **Domain diagnostics.** `log` 在 C* 的無限覆蓋，平方根與 `w³−3w` 的分歧禁點。三次例留 regular preimages，投影可滿射到 C，仍在 ±2 丟失 sheets，故一般局部雙全純不是覆蓋。

### 309 · 亞純函數與除子

1. **Local order.** 零、極與可逆單位，換座標不改整數階，零函數不取有限階。算同階相消。
2. **Meromorphic functions and map degree.** 與到 sphere 的全純映射對應，零與極映射的纖維及加權次數。球面亞純函數的有理性與局部 principal parts。
3. **Divisors and degree.** 有限支撐整數形式和、有效、逐點偏序、principal divisor。寫乘法轉加法與 `deg(f)=0`。
4. **Differentials.** 由轉換律引入全純、亞純 1 形式，`ord_P(h(z)dz)` 和 `Res_P`。寫換座標的過程。
5. **Residue and pullback.** 小洞挖除後用 Stokes 證殘數總和；用 normal form 得 `ord_P f^*ω=e_P ord_Q ω+e_P−1`。
6. **Spaces of bounded poles.** `L(D)=0∪{f : div(f)+D≥0}`；線性性、負度數、`L(0)`、principal equivalence 的乘法方向。
7. **Principal parts as local data.** 幾個有限 jet 指定和 `L(D+P)/L(D)` 至多一維，算球面 Laurent 部分，不預先假定一般曲面可解。
8. **Canonical divisor and exercises.** 先對手上已有非零 meromorphic differential 的情況定典範類；一般存在性證明留 311。用邊界例 rational `df`、環面 `dz`、雙覆蓋 `dx/y` 找階。

### 310 · 線叢的基本例

1. **Holomorphic transitions.** frame 約定 `e_j=g_{ij}e_i`，截面 `s=f_i e_i=f_j e_j`，故 `f_i=g_{ij}f_j`；cocycle、拼接、frame 變更給同構。
2. **Sections and operations.** 無零截面的平凡化，同構條件，tensor、dual、秩 1 的 transition cocycles。
3. **Divisor bundle convention.** `O(D)` 作有界亞純函數局部模型，P 的局部 frame 是 `z^{-D(P)}`。常數 1 當有理截面，其 divisor 為 D。詳細核對 tensor 與 principal equivalence。
4. **Cotangent and canonical bundle.** 由 `dz_j=(dz_j/dz_i) dz_i` 確定 K；sphere `dz=-w^{-2}dw` 以及 torus 非零 holomorphic form 比對。
5. **Line bundles on the sphere.** 以 `O(k∞)` 定 `O(k)` 並驗證局部 frame，逐次掌握 poles 和截面多項式，給 `h^0` 的正、零、負情況；若用一般分類，待後文且給證明。
6. **Complex torus examples.** trivial K、degree 0 bundle、divisor `P−Q` 的非平凡性可用尚未引用 RR 的 degree-one map 排除（拓撲 genus）。不假設所有 flat bundles 皆由未明的唯一 character 給出。
7. **Meromorphic sections and zero divisors.** 已有顯式 meromorphic section 時證本身的 bundle 是 `O(div(s))`，任意 L 的 meromorphic section 存在放在 311 之後。
8. **Maps from sections.** 沒有共同零點時由齊次向量與轉換律決定 holomorphic map，matched basepoint cancellation、fixed system 的初等例和詳解。

### 311 · Riemann–Roch 的所選路線

1. **Smooth line-bundle operators.** 用 `A^{0,q}(L)` 和 holomorphic trivialization 定義 ∂̄，`H^0` 為 kernel、`H^1` 為 cokernel。因 complex dimension 1 無 `(0,2)`，先寫倒數構造所需的微分型別。
2. **Cauchy–Green and estimates.** `∂̄(1/πz)=δ₀` 用圓周 Stokes 積分核驗。對 smooth cutoff RHS 做 convolution，解、導數估計及較小盤上的 holomorphic remainder。
3. **Finite-dimensional kernel and closed range.** 固定 Hermitian bundle metric 與正 area form。有限套大小相嵌的盤上，Cauchy 估計使 sup 單位球緊，由單位球有限維判準得到 `H^0` 有限。若在其 L² 正交補上無 sup 估計，取正規化 sup=1 而 ∂̄u→0 的序列，局部解趨零、餘部 Montel、緊性下極限在 kernel 與正交補矛盾。Cauchy estimates 加 convolution 導數給每個 m 的全局 C^m 估計，從 Cauchy 序列證閉值域。
4. **Integral duality.** 配對 `(η,ω)↦∫ η∧ω`，固定 (0,1) 型 η 在前。用 Stokes 核對可下降。局部 distribution coefficient annihilates ∂̄，因此 locally mollify；固定徑向光滑單位質量 bump 的平均性使平滑化在小盤趨於光滑全純函數。檢 transition 與 dz Jacobian，黏成 `K⊗L⁻¹`。Hahn–Banach 分離的有限 dual 使 quotient 有限與 pairing perfect。
5. **Adding a point.** `0→L→L(P)→Q_P→0`，局部把 inclusion 寫成乘 z。holomorphic evaluation in twisting frame 的 coefficient 屬於一維 fiber。局部 ∂̄ primitive 與 cutoff 構造 connecting map，division by z 必須有 near P vanishing 或 holomorphic factor。逐點驗證 exact，最後 H¹ map 由 local vanishing 代表證滿射。
6. **Euler characteristic and classical formula.** χ(O)=1−h⁰(K)，對每個 holomorphic L，點添加與刪除給 χ(L(D))=χ(L)+deg D。令 L=O 得 χ(O(D))=deg D+1−g。拆開 `H^1` 零及 dual term，過高與負度數。
7. **Topological genus and consistency.** 從 `L(nP)` 量數增長獲 nonconstant f，`K=div(df)` 類比對。由 Riemann–Roch 算 `deg K=2g−2`，由 `df=f^*dw` 及 RH 回算 `2g_top−2`。寫 sphere 座標 w 的 `dw` 在 ∞ 的 `−2`，且 pullback 額外加 `e_P−1`。
8. **Dimension calculations and solvability.** 一點何時增加維數、特殊除子的 correction、對任意 L，找足夠大的 n 使 χ(L(nP))>0，再由非零截面得到 L 的非零 meromorphic section，證明 Picard 分類所需存在性、hard proof checklist 加詳解。

### 312 · 緊曲面上的整體應用

1. **Genus zero and the sphere.** `ℓ(P)=2`，nonconstant f with one simple pole，degree 1 及 inverse proof。算一般 degree 的球面空間。
2. **Genus one.** 非零 differential 由 degree K=0 無零，`ℓ(D)=deg D` 於正度。計環面 `ℓ(P)=1`、`ℓ(2P)=2`，平行對照 $\wp$ 具二階極點；一般 genus-one uniformization 不作主線前提。
3. **Double covers and genus.** `y²=P(x)` 的有限簡單分歧與 ∞ 奇偶；算 holomorphic differential basis 的階與線性獨立，再由 genus 維數檢完備性。
4. **Single-point gaps.** `ℓ(nP)−ℓ((n−1)P)∈{0,1}`，高階無缺，辨識 genus gaps 精確數；hyperelliptic branch point 的偶數 pole orders。
5. **Mittag–Leffler on a compact surface.** 有界 principal parts 到 `H¹(O)`，用 cutoff gluing 與 integral pairing、residue formula 算函數障礙 `∑Res(p_Pω)=0`。正向 local circles 之下 `∫∂̄(χp_P)∧ω=−2πi Res(p_Pω)`。對微分用 L=K_X，同一拼接，對偶的 H⁰(O) 只需測常數，等價總留數為零。檢 sphere 與 torus 的單一簡單極點差異。
6. **Large divisors and maps.** 以 RR 比較 `L(D), L(D−P), L(D−P−Q),L(D−2P)`，循序證 base-point free、point/tangent separation，界 `deg D≥2g+1`；稠密索引非 compact embedding 的替代。
7. **Canonical and plane examples.** 計 hyperelliptic canonical mapping factorization；在光滑 Fermat 平面族或光滑三次例逐 chart 追 `dx/F_y`，用射影過渡或已 proved RH 對照 genus。明分一般性與例子輸入。
8. **Synthesis problems.** 從曲面建構、分歧資料到 genus，最後算指定 D 的空間與主部是否可解；配三類題的全解，跨章引用已證結果。

## 全卷符號與查核關口

`X,Y` 為曲面，`P,Q` 為點，`z,w` 為局部參數；`f:X→Y` 支持含 compact/proper 條件後求 `deg f`。`e_P(f)` 是在 P 的 local degree，分歧用 `e_P−1`。`D=∑_P n_P P`，`O(D)` 是 divisor line bundle，`L(D)=H⁰(X,O(D))` 自然識別為亞純函數子空間。`K_X` 是 cotangent line bundle，`K` 作可用非零 meromorphic differential 的 divisor 代表。`g_a=h⁰(K_X)`，`g_{top}=1−χ_{top}(X)/2`，311 確認等式後可同記 g。`χ(L)=h⁰(L)−h¹(L)` 和 `χ_{top}(X)` 保持下標或引數。局部相等先指定開集；約定零函數不參與 divisor，零截面可以是全局截面的零向量。

- **第二可數與 Hausdorff。** 覆蓋 path model 對一般第二可數曲面，尚須證總空間第二可數。可選可數的連通可縮小盤基，任一路徑用有限條連通交集的盤鏈編碼。若盤交集非連通，選交集中的指定連通分支，其開分支至多可數，由第二可數保證。固定一條鏈和交點代表後，盤中的路徑段在端點固定的同倫類唯一，故從固定起點到固定終點的同倫類至多可數。各基盤升起的 sheets 亦至多可數。芽延拓使用複平面有理圓盤，交集天然連通。
- **進階先備。** Riemann–Hurwitz 的三角剖分固定各分歧值為頂點，提升各 simplex 的閉包時可用局部 `z^e` 保證閉合，計數使用開胞，避免把邊界不同 sheet 誤合。Hahn–Banach 可從母學科引入，章內要交代 closed subspace、Fréchet 局部凸及分離推導。
- **工序建議。** B-03 一節選 306.2，校準局部根建構、型別、證明必要展開與 worked example，不延後關鍵定義。B-04 小節以本稿列表供四角色依賴核對，允許合併相鄰小節或微調例序但維持每一責任。OPEN 大風險是 307.4、308.4、311.4–5 的證明，需獨立打厚和精修逐項對照；所有已審內容計入整卷唯一正文。
- **交接。** 根據 B-01 章級責任調整第 305 章映射入口與第 309 章球面有理性；已回應獨立精修對任意線叢點扭曲及微分主部的兩項意見，配對次序已與打厚重核一致。設計文件本身不含正式正文與配對 PDF，ReadFlow R1 採已定模板，編譯與讀流檢查於 B-06，B-02 不更動凍結卷和既有文獻表。使用者已授權正式輪次，待 B-01 證據合入後交 B-03 代表小節。傳遞至主控以代理訊息確認，接收回執由主控和複核精修記實際讀取及製作稿 hash。
