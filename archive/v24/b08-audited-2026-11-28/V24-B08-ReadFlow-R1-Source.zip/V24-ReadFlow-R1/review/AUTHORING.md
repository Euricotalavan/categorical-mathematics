# V24 manuscript conventions

Eight chapters remain 305–312. Each chapter file begins with the declared
chapter title and a label of the form `ch:305`. English prose. Drafts in role
directories become production source only after the thickening and source
reviews. Source inputs are the five PDF versions in the approved readiness
record. Use original prose, proofs, examples and exercises. Cite the original
source of a particular result or argument by author and section when useful.
The production preface and bibliography establish the edition-wide sources.

| File | Chapter title |
|---|---|
| ch305.tex | Complex Structures and Atlases |
| ch306.tex | Holomorphic Maps and Ramification |
| ch307.tex | Coverings and Monodromy |
| ch308.tex | The Surface of Analytic Continuation |
| ch309.tex | Meromorphic Functions and Divisors |
| ch310.tex | Basic Examples of Line Bundles |
| ch311.tex | The Riemann--Roch Theorem |
| ch312.tex | Global Applications on Compact Surfaces |

Use template environments `definition, theorem, proposition, lemma,
corollary, example, remark, problem, proof, psolution, motivation`.
Use conventional LaTeX. The template's `\C` denotes a category, so use
`\mathbb C`, `\mathbb P^1`, `\mathbb Z`, and `\mathcal O_X`.
Ordinary labels and references work. Prefix local labels with the chapter
number, e.g. `thm:306-local-power`. Reference chapters by the labels above.
State the source of a result if the preceding chapters do not establish it.
Use amsmath displays and allow breaks at logical points. Avoid oversized
tables and long unbroken equations. No manual page breaks in authored chapters.

## Agreed mathematical interfaces

- Riemann surfaces in this volume are Hausdorff, second countable, connected
  complex one-manifolds. State componentwise variants explicitly when needed.
  A disconnected covering space may still occur in the topological theory.
- Use $X,Y$ for surfaces, $p,q$ for points. Use $\pi$ for a covering or
  continuation projection, and $f$ for a holomorphic map or meromorphic function.
  For a nonconstant map, its local degree is $e_p(f)$. Critical points
  have $e_p(f)>1$. A branch value lies in the target. Use oriented topological
  genus $g_{\mathrm{top}}$ when it could be confused with $\dim H^0(K_X)$.
- Ch305 defines atlases, examples and orientation. Ch306 supplies the local
  power normal form, properness versus compactness, map degrees, ramification,
  Riemann--Hurwitz and examples. Its proof may use compact orientable surface
  triangulation/classification as an explicitly stated topological prerequisite.
  Euler characteristic proof must explain cell lifts and vertex corrections;
  independent of Ch307's formal covering classification.
- Ch307 develops covering classification and lifting. A covering is a
  surjective local homeomorphism with evenly covered neighborhoods. Explain
  monodromy action convention and orientation on punctured disk loops.
  Riemann existence means finite covers of the punctured target filled over
  finitely many punctures with local cyclic models, not GAGA.
- Ch308 develops the étalé germ component, its path/finite-chain countability,
  universal property and monodromy theorem. Explain analytic continuation along
  every admissible path before asserting single valuedness. Give a finite
  algebraic example with clear poles/branch treatment, and an infinite-sheet
  logarithm example. Whenever the projection can fail to be a cover explain
  exactly which hypothesis is missing.
- Ch309 defines principal divisors, divisors of meromorphic one-forms,
  residues, divisor arithmetic, and $\mathcal L(D)=
  \{f\in\mathcal M(X):\operatorname{div}f+D\ge0\}\cup\{0\}$
  on compact $X$. $K$ denotes a chosen canonical divisor. A principal
  divisor comes from a nonzero global meromorphic function. Degrees finite on
  compact $X$. The existence of meromorphic differentials on an arbitrary
  compact $X$ will follow once Ch311 produces a nonconstant $f$; give
  concrete examples in Ch309 and make conditional statements before Ch311.
- Ch310 builds $\mathcal O_X(D)$ with local frame $z^{-d_p}$, i.e. the
  holomorphic line bundle whose sections are the allowed meromorphic functions.
  $K_X$ is the holomorphic cotangent bundle. Use a consistent frame convention
  $e_j=g_{ij}e_i$, so coefficient vectors satisfy $s_i=g_{ij}s_j$, or
  explain every switch. Include dual/tensor, projective line, torus, and base
  points. Ch309–310 do not use Riemann--Roch to establish earlier statements.
- Ch311 uses direct Dolbeault spaces + local Cauchy--Green + Montel/compactness
  + closed range + continuous dual and mollifier Weyl lemma. Pairing with
  $H^0(K_X\otimes L^{-1})$ is non-degenerate before Euler characteristics.
  Prove point-addition by six-term exact sequence with cutoff local primitive
  so this chapter does not assume general sheaf cohomology. Compute large
  dimension to obtain a nonconstant meromorphic $f$ and compare genus via
  Riemann--Hurwitz and $(df)=R_f-2f^*(\infty)$. All notation and proof
  prerequisites exposed. State and derive the classical form with $K$.
- Ch312 gives complete calculations for genus zero and one, double covers,
  principal parts, and large-degree systems. Avoid unproved claims about
  classification of the complex torus or canonical maps if not needed.
  All examples must point at the correct hypotheses, especially compactness
  and smoothness.

Give every substantial section a reason for the construction and one place
to practice using it. Include worked examples near difficult transitions,
then varied exercises with complete independent solutions. Use optional
subsections at natural proof transitions only. Roughly seven to ten developed
sections per chapter and 10–14 exercises per chapter make a usable first
edition. Expand hard steps and actual computations, not paragraph repetition.
The main source has 183 PDF pages. Page count is a check after compilation;
the meaning of each section is the pass condition.
