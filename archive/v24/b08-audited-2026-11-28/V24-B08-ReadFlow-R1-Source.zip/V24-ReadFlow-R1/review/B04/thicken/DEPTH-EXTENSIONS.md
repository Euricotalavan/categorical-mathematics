# V24 B-04 · Depth extension review

2026-11-28 · V24 Chapters 305–312 · B single Work  
The frozen earlier thickening inputs are identified in ch305.md through ch308.md. The new content below follows their review, and the production source remains with the integration coordinator.

| File | Fixed SHA-256 | Placement |
|---|---|---|
| roles/thicken/extra305.tex | fbd4b28cfcbfe808154897e00002bd80428fa3ae0ff63837a489558584eb63fc | After the Möbius pole example and before descent through the translation quotient |
| roles/thicken/extra306.tex | 8e8f8fa84222b224915006918b522c985210c72e2eb466cba5bbde765e7a4dd0 | After Riemann–Hurwitz and before the compactified double-cover section |
| roles/thicken/ch307-expanded.tex | 4a0c3b60dc05594775f62821fb06e0f9850756e21464acdcb7d40295e44ace93 | Complete expanded candidate for ch307 |
| roles/thicken/ch308-expanded.tex | 44f076070960e7f4d8147de457b08be8269fa1d0f5e8aa9b0fa83bbff4fb07da | Complete expanded candidate for ch308 |

The 305 and 306 extensions total 1,125 whitespace words. The Möbius extension derives existence and uniqueness of the ordered triple normalization, checks the homogeneous determinant formula and all infinity cases, proves cross-ratio invariance and equivalence of ordered quadruples, and gives a reciprocal-chart check and a solved test. The rational-degree extension proves degree by homogenization and a nonexceptional weighted fiber, separates finite derivative tests from reciprocal pole charts, and tracks multiplicity at infinity. Its worked map has double local degree at all six critical points and two critical preimages at each of the three branch values. The solved rational example with an exceptional fiber at infinity has local degrees three at zero and infinity and unramified simple poles. The two detached extensions proceed to independent refinement.

The expanded chapter 307 was produced from the independently checked thickening candidate and read in full through the detached insertions. Both exact earlier hashes were verified. Intermediate maps use the subgroup inclusion and preserve the coordinate charts; their index and deck group are correctly computed over the intermediate base. A transitive right group set is realized by the stabilizer coset map, and a countable disjoint union gives the disconnected case. Positive peripheral loops satisfy the stated sphere relation. The index-six, index-three and index-two tower and the five-cycle filling were checked; both solutions use the appropriate group or ramification requirement.

The expanded chapter 308 likewise preserves the prior fixes and adds the primitive period proof and examples. Finite local primitive chains allow arbitrary continuous paths while periods may be integrated for piecewise smooth paths. Inverse tangent gains the periods \(\pi\) and \(-\pi\) at the two punctures; the commutator lifts to a noncontractible loop. Its parameterization by the exponential and fractional linear map has the stated deleted set. The normalized inverse equation is propagated in its pole-free exponential form before reading the inverse tangent germ. Checked the logarithm-product period homomorphism and comparison of two germs on one fixed base.

The new solved problems for chapters 307 and 308 were placed together with the existing solved problems in the chapter-end sections. Each expanded chapter has 14 matched problem/solution pairs, and all labels are unique within the chapter. The depth extensions pass the independent thickening verification in their present scope and return to source and semantic refinement. Whole-volume release still requires its own mathematical review.
