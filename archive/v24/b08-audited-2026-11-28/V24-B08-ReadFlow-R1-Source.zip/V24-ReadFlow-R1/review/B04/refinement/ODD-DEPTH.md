# V24 B04 independent refinement — odd-chapter depth additions

2026-11-28 · workflow B · refinement of the additions after the separate core reviews.

## Receipt and exact candidates

Actually read `roles/AUTHORING.md`, `review/B01/SOURCE-LEDGER.md`, the four detached additions below, and the exact merged deltas against their previously reviewed cores. Rechecked the relevant preceding definitions of Möbius maps, right monodromy, path-space quotient covers, local degree, differential order/residue, divisor pullback, divisor-bundle frames, Dolbeault quotient and point-twist connecting map. The separate core reports remain applicable only to their recorded hashes; this report accounts for the new deltas.

All paths below are relative to `v24-work/`.

| Exact merged candidate | SHA-256 | Inspected new locations |
|---|---|---|
| `assembly/b04/chapters/ch305.tex` | `9b6f0286f8ac909980d7c6a36b3fecb379c60a12ea5de486e6b0bae89bcdb534` | 580–659, `subsec:305-cross-ratio` |
| `roles/thicken/ch307-expanded.tex` | `4a0c3b60dc05594775f62821fb06e0f9850756e21464acdcb7d40295e44ace93` | 213–259, `prop:307-intermediate`, `prop:307-realize-action`; problems 13–14, 346–358 |
| `roles/thicken2/merged/ch309.tex` | `fc11e0f41c2afe7639b299717a47f4ab83155cf1d45c4ec238b8ff3fdcc5b652` | compactness warning 244–247; conic 268–300; differential pullback 325–498 |
| `roles/thicken2/merged/ch311.tex` | `e68688642f89f11db5c59d7a83b24642ffddd146ce78f7e9221351dbaf5198ca` | adopted background 18–32; sphere calculation 599–784 |

Detached inputs actually read:

| Input | SHA-256 |
|---|---|
| `roles/thicken/extra305.tex` | `fbd4b28cfcbfe808154897e00002bd80428fa3ae0ff63837a489558584eb63fc` |
| `roles/covers/ch307-depth-insertion.tex` | `3fc34522dcf4b9ce652b428bab7d18def25010c1007d1b52e3701808055792b9` |
| `roles/bundles/extra309.tex` | `06fcd81cf5d605db9c46a8fdcf297da0bec0f2fcece5a59bf95f54a90f3a4e31` |
| `roles/rochr/extra311.tex` | `67ab505166600082143ccf87d07d8ae072e2faa5ce9b7b8b12b8bd140a05c835` |

The merged texts were checked directly, including their small clarifications beyond the detached text: continuous based map and `r>=1` in 307; integer power parameters in 309; the global smooth-form hypothesis and actual closed subannulus for Stokes in 311. The conic and noncompact-kernel additions in merged 309 and analytical background in merged 311 were also inspected, rather than inferred from their authors' reports.

## Independent mathematical evidence

- **305:** Substitution gives all three prescribed values in every infinity case. The homogeneous determinants have no common zero and scale equally under changing any representative. Uniqueness uses the already proved Möbius inverse, followed by the elementary affine form of a map fixing infinity. The normalization and its inverse establish both directions of the quadruple test. For the worked example, `2/(1+i)=1-i` and swapping the first two marks gives `1-T`, hence `i`. The solved problem gives the unique candidate `1/z`; its fourth value is `1/2`, while `3/2` fails. No automorphism-classification theorem is being assumed.

- **307 subgroup/quotient action:** Recomputed the map `H[a] -> K[a]` and its well-definedness from `H subset K`; every sheet maps by the same base coordinate. Its distinguished fiber is `H\K`, and a fiber of `Hg -> Kg` consists of `Hkg`, proving the index product. Applying the existing normalizer theorem over `E_K` gives `N_K(H)/H`, with the previous right-action convention unchanged. The bijection `Hg -> a0.g` is injective because equality implies `gg'^{-1} in H`. Countability follows from the explicitly constructed universal cover. In the countable disconnected union one may choose a single simply connected coordinate disk downstairs: the subgroup-quotient constructions evenly cover every such disk, so the union is also a covering.

- **307 winding and solved problems:** Rechecked the preceding `ex:307-winding` and action convention, not merely their earlier review label: a positive loop sends `k` to `k+1`, and a logarithm gains `2 pi i`. At infinity positive orientation is in the reciprocal coordinate, so the fifth-power model has inverse peripheral cycle there. Problem 13 has degrees `2,3,6`, deck groups `C2,1,S3`; the point-stabilizer normalizer is itself. Problem 14 has fibers of sizes `1,5,1`, ramification sum `8`, and genus zero. The maps `u^3` followed by `v^2` and the fifth-power punctured model satisfy the actual subgroup and local-degree assertions.

- **309:** Differentiating `v=t^e u(t)` independently gives the unit factor `u^m b(v)(eu+tu')` and order `em+e-1`, including negative `m`. Separating `c dv/v+dH` gives residue `ec`; the exact term has residue zero, by the earlier local Laurent-primitive argument. This justifies the divisor identity and composition correction `(ed-1)=(e-1)+e(d-1)`. In the first example the divisor is `(d-1)(0)-sum(zeta)-(infinity)`, and the infinity coefficient is `-d/[w(1-w^d)]`. The second example simplifies to `(t+1)/(t-1)^3 dt`, has a triple pole with zero residue at 1 and a simple zero at -1, and is regular/nonzero at 0 and infinity. Both solved problems were recalculated: the logarithmic derivative is `(t^2+1)/(t(t^2-1)) dt`, with residues `1,1,-1,-1` and simple zeros at `+i,-i`; the power form is `m t^{m(r+1)-1}dt`, whose rational primitive for `r != -1` is `t^{m(r+1)}/(r+1)`. The additional conic charts are inverse and have `uv=1`; the homogeneous parametrization identifies the conic with the sphere, and its simple zero/pole divisors follow in these coordinates. The `exp(z)` noncompact kernel counterexample is valid.

- **311 definitions and cutoff:** The frames `e_infinity=z^k e0` agree with 310, so corrections have modes `n>=0` and `n<=k`. The omitted modes are exactly `k<n<0`. Splitting a Laurent series gives convergent holomorphic corrections on the full two disks, proving injectivity without assuming sheaf cohomology. The radial-cutoff primitives extend by zero at their respective centers and have difference exactly `b`, proving surjectivity in the previously defined smooth Dolbeault quotient. Local primitives exist on the specified disks by applying the proved Cauchy lemma on larger disks.

- **311 signs, pairing and solved problem:** For `k=-3`, converting `z^j dz tensor e0^{-1}` gives `-w^{1-j}dw tensor e_infinity^{-1}` for `j=0,1`. In the established `(0,1)`-then-`(1,0)` pairing order, the integrand is `d(chi z^{n+j}dz)` on the stated closed subannulus. Its outer boundary is counterclockwise and contributes `+2 pi i` precisely for `n+j=-1`. The twist inclusion is coefficient multiplication by `w` at infinity; its cohomology map preserves `b` and forgets `b_{k+1}`. Using the existing definition `delta(c)=[j^{-1} bar-d v]` yields representative `-z^{k+1}`, with the claimed sign. For the explicit first-twist example the corrected infinity coefficient is `chi`, so the local primitives agree with transition `z^{-3}` and uniqueness follows from `H0(L_-3)=0`. In the solved problem the `-2` mode survives twists 0, 1, 2 and disappears at twist 3; correction `-(w^2+1)` has the required sign. No genus or Riemann–Roch conclusion is used to prove this sphere obstruction calculation.

## Result and handoff

- **Result:** PASS for the new source-level mathematical additions at the four exact candidate hashes above. No actionable mathematical defect found; no source patch requested by this refinement review.
- **Already checked:** every new argument, both new 307 problems, both new 309 problems, the new 305 problem, the new 311 problem, and the worked transition examples were independently recalculated. The source-level delta comparison does not extend the old core reports to unrelated later edits.
- **Available evidence:** this report plus the four exact merged candidate files and four detached inputs listed above. No approved/frozen source was edited by this role.
- **OPEN:** B05 whole-volume sequential dependency and source-destination integration, final sole thickening review, compilation/PDF pairing and layout QA. This report is not any of those acceptances.
- **UNKNOWN:** final PDF page positions and actual model/high-mode setting; neither is inferable from source text or tool completion.
- **Next/pass condition:** use these hashes for B05, recheck any later substantive delta, and return the integrated volume to the sole thickening final reviewer. Keep workflow B and the adopted R1 layout authority; no publication or archival authorization is implied.
- **Prohibited redo:** do not restart another volume, alter frozen work, or infer another role's receipt from this file. This evidence has been reported to the coordinating parent; external delivery is outside this role.
