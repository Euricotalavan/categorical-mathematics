# B04 even-chapter refinement handoff

- Workflow/role: B, independent source refinement after expansion and thickening; no release verdict.
- Read-in receipt: AUTHORING, B01 SOURCE-LEDGER, four exact base candidates, all their formal statements/proofs/examples/exercise solutions, and all four supplied depth diffs actually read. Exact input SHA-256 values independently verified; no upstream edits.
- Base receipts and item-by-item source responsibility dispositions are in ch306.md, ch308.md, ch310.md and ch312.md in this directory.

| Chapter | Exact next candidate | SHA-256 | Refinement result |
|---|---|---|---|
|306|assembly/b04/chapters/ch306.tex|e29d85f0d37a3bf5b7dd35489d6fc125b3ab4f0a5dae980c57a1ffd7d906192e|Clear, including rational-degree addition and solved problem.|
|308|roles/thicken/ch308-expanded.tex|44f076070960e7f4d8147de457b08be8269fa1d0f5e8aa9b0fa83bbff4fb07da|Clear, including periods/arctangent/log-product additions and two solutions.|
|310|roles/thicken2/merged/ch310.tex|b701037ecd5acdfd80960705136bc9e4e61f47a1e264d16e954f609447062e2b|Clear, including annulus normalization and two solutions.|
|312|roles/refine_even/ch312.tex|0b62492bd591b2a2cf19bbfeadbfea6cac8612f17c509a30a9d3e33bb07be79c|Clear after explicit complete-system/basis-change/n=0 repair; thicken2 recheck PASS received.|

## Evidence and preserved boundaries

- The refined Ch312 candidate only adds 21 lines to the supplied merged input: complete linear system |D|, its projectivization proof and basepoint equivalence; basis matrix action; sphere degree-zero constant map. No other mathematical arguments changed.
- Ch308 OPEN/308-TOPOLOGY is resolved at source level by finite countable disk codes, Hausdorff sheets and all-row homotopy stability. Merely local biholomorphic projections are never promoted to coverings without all-path existence.
- Ch310 preserves conditional general meromorphic-section existence until Ch311; no circular use of RR in earlier bundle arguments.
- Ch312 general (g+1)P function bound and line-bundle meromorphic existence/kernel are located in earlier Ch311, not repeated as local proofs in Ch312. Integration should map those responsibilities to `cor:311-one-pole` and `prop:311-line-bundles-divisors`.
- Ch312 retains the authorized specific Fermat-cubic computation as its plane-curve route. No general smooth plane degree–genus/Bézout/adjunction or generic quartic coverage is certified by this refinement.
- Ch312 depth closes the explicit Weierstrass cubic smoothness/extension/biholomorphism and marked chord-and-tangent obligations. It does not claim a general Jacobian construction.

## Next step / limits

Next recipient should acknowledge actual candidate hashes and reports, then perform B05 dependency/source-map integration. Final PDF page positions, source/PDF pairing, adopted-template/layout QA and sole strict whole-volume thickening final review remain open. Actual model mode is UNKNOWN, not inferred from text. Preserve all old inputs, accepted calibration bytes and frozen sources; do not restart another volume or infer archive/publishing permission. Report creation and notification are not proof of recipient read-in.
