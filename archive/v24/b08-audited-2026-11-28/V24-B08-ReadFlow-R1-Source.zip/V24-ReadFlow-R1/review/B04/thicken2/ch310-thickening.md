# V24 B-04 independent thickening · Chapter 310

Read base roles/bundles/ch310.tex in full, 838 lines. SHA-256
11157957d491a50253d42f0fcca4de9e849ba9b81c97d58fb0d535e4d1df2681.
Surgical candidate roles/thicken2/ch310.tex, 857 lines and 38,376 bytes.
SHA-256 b8f8892aedec016b4ab0c9456c8be769fb960eeafc51d57d1b629bd584456804.
Reviewed as an independent role. Actual serving model configuration is unverified.

| Section | Mathematical checkpoints |
|---|---|
| Frames and transition functions | Coefficient transport a_i=g_ij a_j agrees with the frame convention and cocycle. The gluing relation is transitive, each product chart is open in the quotient, and Hausdorffness and second countability were proved. Frame rescaling factor h_j/h_i and trivial example e^{-z} checked. Specified the total space type in the definition. |
| Sections and their local coefficients | Nonzero meromorphic sections have intrinsic orders because frame factors are units. Their ratios are global meromorphic functions, so they define the same degree. A section of effective divisor zero is a global holomorphic frame. The partition-of-unity inner product is smooth and positive. Specified that a section is defined on an open domain. |
| Tensor products, duals, and pullbacks | Transitions multiply under tensor and invert under dual. Nonconstant holomorphic maps pull back genuine meromorphic sections because open local images avoid identically zero or infinite coefficients. Divisor pullback multiplies each order by local degree and yields the degree formula. |
| Divisor line bundles | Local equations give the correct transition ratio and reciprocal frame. A scalar function f corresponds to local coefficient φ_i f. The distinguished section has divisor +D, and canonical multiplication in changing D to E has the correct sign. Existence of some meromorphic section for an arbitrary bundle is deferred to Chapter 311. Checked the point twist, its fiber quotient, and the warning against dividing a smooth coefficient merely vanishing at a point by the coordinate. |
| The canonical bundle | The derivative of coordinate transition gives the cotangent cocycle. The sphere has degree −2, while dz trivializes the torus cotangent bundle. The map F^*K_Y→K_X has divisor R_F with coefficient e_p−1. |
| The bundles on the sphere | Verified transition e_∞=z^k e_0, the coefficient w^k a_0(1/w), tautological transition z^{-1}, and the homogeneous-polynomial identification. Infinity order k−deg(a_0) is correct. |
| Degree-zero examples on a torus | The simple-pole obstruction makes O(p−q) nontrivial. Character quotient is holomorphic in lifted charts. For unitary characters the candidate section descends in absolute value and Liouville excludes nonconstant entire sections. The smooth frame has the required equivariance. Added the winding-number proof that the degree of the unitary examples is zero once a meromorphic section exists, without assuming holomorphic triviality. |
| Projective maps from sections | Added compactness and Hausdorffness of projective space used by Chapter 312. In the existing proof evaluation from the dual fiber is nonzero and identifies it with the pulled-back tautological line. Removed base divisors divide by their canonical sections with nonnegative local orders. The conic and its local inverse match the pullback hyperplane degree. |
| Exercises and solutions | Recomputed all twelve. Checked gauges, two infinity orders 2 and 4, mixed divisor frame, twist scaling 1/2, jet basis, ramification at both 0 and infinity, distinctions of characters, common-base divisor, same-ratio scalar, the exceptional a=−1, and hyperplane divisors. Repaired the multiplication-isogeny exercise by requiring a positive integer m so scalar multiplication preserves Λ. |

Verdict on the fixed candidate is mathematical thickening pass for the
stated Chapter 310 scope. Full-volume typesetting and final independent
review remain separate.
