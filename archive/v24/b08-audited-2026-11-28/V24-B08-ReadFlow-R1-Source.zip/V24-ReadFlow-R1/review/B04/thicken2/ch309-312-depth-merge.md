# V24 B-04 independent depth review and merge · Chapters 309–312

The base files and the base wording outside the insertion points remain
byte-identical. Each independent candidate incorporates the corresponding
complete detached author supplement at the given insertion point. The
changes listed below affect only supplemental language. The four original
B-04 thickening receipts remain applicable to the preserved text.

| Chapter | Base SHA-256 | Author supplement SHA-256 | Merged bytes | Merged SHA-256 |
|---|---|---|---:|---|
| 309 | b0d3b9c819d6064f7076ba181ef936ba02cf9d2de2f6bca33725f6e22aefdb3c | 06fcd81cf5d605db9c46a8fdcf297da0bec0f2fcece5a59bf95f54a90f3a4e31 | 40651 | fc11e0f41c2afe7639b299717a47f4ab83155cf1d45c4ec238b8ff3fdcc5b652 |
| 310 | b8f8892aedec016b4ab0c9456c8be769fb960eeafc51d57d1b629bd584456804 | 43f577e42ff428583cce92f11df2c30b12e27f67fab56634dd46a4911068aca9 | 46020 | b701037ecd5acdfd80960705136bc9e4e61f47a1e264d16e954f609447062e2b |
| 311 | 8eeaeb3fa638e18997e4222d271e7b58b1b8424c4c53da90afc036f4c9e049a8 | 67ab505166600082143ccf87d07d8ae072e2faa5ce9b7b8b12b8bd140a05c835 | 44400 | e68688642f89f11db5c59d7a83b24642ffddd146ce78f7e9221351dbaf5198ca |
| 312 | f8bdfb5c304bfe9583c3048751d7aa6b1c271b8a3b6afa7738f4e57df7804570 | 397ba9f1d4c5a376c121cd08707b0778a2b09e01ef2017efe39ba19dc4adaf90 | 41068 | 6e0f23d680a83b65b2d199e62b7e2f126552d56f6ae8009530b8c243d63f9089 |

## Chapter 309

Inserted “Pulling back a differential” after scalar divisor pullback and
before “Functions subject to a divisor bound.” The earlier separately
suggested short proposition is not part of the merge. For the base additions,
the noncompact example e^z is nonconstant and nowhere zero, so it has empty
zero/pole support. The conic's two open charts are graph charts and glue
by reciprocal coordinate. Its stated map from the sphere is a
biholomorphism. The finite coordinate zeros and the single pole at the
other chart's origin are simple.

The new pullback calculation has exponent em+e−1, including negative m.
The derivative factor e u(0) is nonzero, and a local meromorphic primitive
has zero residue after pullback. The dlog term gives the residue factor e
with the stated sign. Local degrees multiply, establishing the additive
ramification formula under composition. In the first example the infinity
coefficient is −d/(w(1−w^d)). In the second, direct simplification yields
(t+1)/(t−1)^3, and the exact-form formula explains the zero residue.
Both solutions were recomputed, including the ramification points ±i of
t−1/t, both poles and their residues, and the primitive for the power
family when r≠−1. Added an explicit positive integer restriction on the
power exponents in the example and exercise.

## Chapter 310

Inserted “Normalizing an annulus transition” between the projective-line
bundle examples and the torus examples. Winding measures the logarithm
increment and is unchanged across the annulus. Subtracting the winding by
z^{-k} removes the Laurent obstruction to a primitive, so the residual
unit has a holomorphic logarithm. Its two Laurent tails extend to the
respective disks, and the opposite frame scalings give transition z^k.
The index for duality and tensor products follows from the logarithmic
derivative. Checked the coefficient scalings in both examples and both
exercises, including the ±n relation in the infinity coefficient and
which disk contains the unit factor of z−a or z−b. The statements assume
the two given trivializations, so no general trivialization theorem on
a disk is used. Supplemental wording is unchanged.

## Chapter 311

Inserted “Computing the obstruction on the sphere” before “Dimension
jumps and exercises.” The base background paragraph gives the analytic
prerequisites and accurately leaves Cauchy-kernel solvability, closed
range, and weak holomorphicity to this chapter.

For k<n<0 the Laurent modes survive changes of both local primitives and
adding global exact data. Splitting holomorphic positive and negative
tails proves injectivity, and the radial cutoff primitives glue their
derivatives and prove surjectivity. Checked the transformation of the
dual tests near infinity, including the sign from dz and the powers
1−j. Stokes on the support annulus gives +2πi at n+j=−1 with the chosen
outer orientation. Twisting at infinity acts by w on the infinity
frame coefficient, leaves the representative b unchanged, and forgets
the mode k+1. The cutoff lift of the unit has connecting representative
−z^{k+1}. The displayed unique primitive after twisting and the
three-twist exercise were checked by subtracting the explicit
holomorphic infinity coefficient. Localized edits specify that the
source form is smooth and bundle-valued, and give the domain of the
Stokes integral.

## Chapter 312

Inserted “The cubic model of a complex torus” and “A signed chord-and-tangent
calculation” before the exercise section. Verified the three nonzero
half-period classes are distinct and have different projective x-values
because each has local degree at least two in a degree-two map. This
proves all three roots of the cubic are simple. At its only point at
infinity, the local equation for b has derivative one in b, and b/a³ is
a unit taking value 4. The affine x-coordinate has order −2 in a,
so the compact smooth connected cubic has a degree-two projection.
The extension uses the nonzero middle coordinate z³ wp' at zero and
the degree-one argument proves biholomorphy. The local computation of
dx/y at infinity gives −2−a u'/u and is compatible with its pullback dz.

For the Fermat cubic, degree-one Riemann–Roch gives existence and
uniqueness of the effective point in each degree-one class. The
marked flex identifies the class of a projective line section with
3P_0. A tangent contributes two at its marked point, so the residual
point has the inverse class of the sum, with the flex handling
repetition at the identity. Recomputed the example exhibiting a
point of exact order three. The inverse-swap exercise includes all
fixed-point cases, with the line agreeing with the tangent when a=b
in the finite chart. The torus cubic exercise gives local degree
two at each of the three finite branch fibers and at infinity.
Supplemental wording is unchanged.

Independent mathematical thickening verdict: pass for these fixed
merges and scope. The additional seven solved exercises, expanded
examples, overlap calculations and proof interfaces were all checked.
The merged candidates are staged under roles/thicken2/merged for the
separate B-05 refinement step.
