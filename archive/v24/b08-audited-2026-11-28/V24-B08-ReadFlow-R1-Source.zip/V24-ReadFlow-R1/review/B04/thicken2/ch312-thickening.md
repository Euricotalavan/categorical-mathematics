# V24 B-04 independent thickening · Chapter 312

Read base roles/rochr/ch312.tex after the author's last update, 710 lines.
SHA-256 d8ff5e842db6bcfc94dcd722d8d8e28a7b4ac4f134c83557ef4387df8ea879fd.
Surgical candidate roles/thicken2/ch312.tex, 717 lines and 32,272 bytes.
SHA-256 f8bdfb5c304bfe9583c3048751d7aa6b1c271b8a3b6afa7738f4e57df7804570.
Reviewed as an independent role. Actual serving model configuration is unverified.

| Section | Mathematical checkpoints |
|---|---|
| Genus zero and the sphere | Riemann–Roch gives a nonconstant member of L(P) with an actual simple pole. Degree one then proves biholomorphicity by local inverses. Multiplier q moves the divisor in the stated direction. The basis and the signed example account for infinity. Clarified compact connected X and separated nonzero f's divisor from the zero vector. |
| Genus one and a torus calculation | Effective canonical divisor of degree zero gives K=0. Counted the dimensions and the degree-two projection. Verified absolute local uniform convergence of the lattice series, its evenness and the proof of periodicity from the derivative. Independently checked the coefficients of the equation: writing a=3G4 and b=5G6, (wp')²−4wp³ has terms −20az^{−2}−28b. The list of pole orders is 0,2,…,n, with all integers 2 through n represented. |
| Two-sheeted polynomial covers | Checked the current source boundary against Chapter 306's labeled compactification. The two parity equations give 2g+2 branch points, and infinity orders of x^j dx/y are g−1−j and 2g−2−2j. At simple roots dx/y=2dy/F'(x). The differentials are independent and exhaustive by genus, and the top form checks basepoint-freeness at infinity. The canonical map factors as claimed. |
| Pole orders and gaps | A leading-coefficient kernel gives a zero or one jump. The high-degree tail telescopes to exactly g gaps. In the odd-degree cover the functions x^k and x^k y supply all the other pole orders, and line-bundle evaluation in the shifted dual frame gives the independent differential criterion. |
| Prescribing principal parts | The cutoff derivatives extend by zero near the selected points. For functions the obstruction vanishes exactly when the class vanishes by the previously proved duality. With the established (0,1) wedge (1,0) order, clockwise inner circles give −2πi times the sum of residues. The rank computation tests the coefficient z^{k−1}dz. For differentials the dual bundle is trivial and the single scalar obstruction is the total residue. Specified a centered coordinate in the sample second-order differential. |
| Large divisors and projective embeddings | d≥2g+1 puts all four tested divisors above 2g−2, so their dimensions are d+1−g, one less, and two less where claimed. Evaluation gives no base points, the two-point difference gives separation, and t nonzero with s of exact order one yields a nonzero derivative of s/t. Compactness then makes the injective immersion a holomorphic embedding. |
| A plane cubic, from projection to complete system | Checked the projection has degree three with three affine ramification points of index three and no ramification at the three infinity points. Verified all three expressions of the nowhere-zero differential, the tangent section's order three at the flex, and pole orders 0,2,3 of the exhibited basis. Added explicit Euler-identity reasoning from the projective homogeneous gradient to smoothness in every affine chart, and named the flex from its tangent multiplicity. |
| Exercises and solutions | Recomputed all twelve. Checked signed sphere normalization; genus-one lower dimensions; five-function torus basis and evaluation kernel; even and odd hyperelliptic infinity calculations; the branch-point residue −2; both compact principal-parts solutions; the two-jet rank argument; the conic map; all three cubic infinity points; and the 2P versus 5P hyperelliptic comparison. |

Verdict on the fixed candidate is mathematical thickening pass for the
stated Chapter 312 scope. Full-volume typesetting and final independent
review remain separate.
