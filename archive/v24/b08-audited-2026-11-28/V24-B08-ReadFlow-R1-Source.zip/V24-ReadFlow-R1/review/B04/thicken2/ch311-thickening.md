# V24 B-04 independent thickening · Chapter 311

Read base roles/rochr/ch311.tex in full, 760 lines. SHA-256
a76c744ad559a8b840643f0326519adf61956c53048f63abd0970418450bf9f5.
Surgical candidate roles/thicken2/ch311.tex, 765 lines and 34,784 bytes.
SHA-256 b3fa2979b3a16daf4bb47cd6e273e15256b4a0d4bfd974e18c4d504cf82c0d91.
Reviewed as an independent role. Actual serving model configuration is unverified.

| Section | Mathematical checkpoints |
|---|---|
| The Cauchy–Riemann operator of a line bundle | Frame and coordinate chain rules agree. The smooth two-term Dolbeault quotient is defined explicitly. Finite chart sup norms give a complete metrizable smooth topology. The torus example tests a genuinely global obstruction by Stokes. No appeal is made to an identification with sheaf cohomology. |
| Local solution and estimates | On the punctured domain, d((φ/z)dz)=2i(∂̄φ/z)dA. The clockwise inner boundary gives ∂̄(1/(πz))=δ₀ in the complex-linear distribution convention. Compact support plus local integrability bounds every derivative by transferring differentiation to the input. Braced the blackboard-bold integral subscript to repair a Math TeX parse failure. |
| Finite-dimensional kernel and closed image | Nested relatively compact frame disks and a finite diagonal Montel extraction yield norm-compactness of the kernel unit ball. Orthogonal normalized sequences force the supremum estimate by contradiction. Local Cauchy estimates upgrade it to every C^m norm. Subtracting kernel projections and applying completeness gives a convergent smooth preimage of each limit in the image. |
| The integral pairing and duality | d(bar z) wedge dz equals +2i dA. For a holomorphic dual differential, the integrand from an exact class is d(sω) and integrates to zero. The radial mollifier argument converts the local annihilator distribution to a holomorphic density. The factors b/(2i), the dual frame, and transition derivatives yield a global section of the correct bundle. Hahn–Banach separates the Hausdorff locally convex quotient, so its finite-dimensional continuous dual forces the quotient itself to be finite-dimensional before taking an algebraic dual. |
| Adding one point | The map of bundles has coefficient z in twisting frames. For well-definedness, cutoff representatives agree in the fiber and are holomorphic there, so their difference divides by z holomorphically. At the first H^1 term, subtracting a local primitive first makes the adjustment holomorphic. For surjectivity onto the last H^1 term, the adjusted representative vanishes near P and hence extends after division by z. All kernels and images checked. |
| The index formula | The six-term exact sequence gives the sign +1 for a point twist; negative twists follow by applying the same result to L(−P). The trivial-bundle index uses duality and compactness. Positive index supplies a meromorphic section for any line bundle before its representation by a divisor is used. Local frames check the multiplication direction and independence of degree. |
| Classical Riemann–Roch and the two genera | The Euler inequality produces f before canonical divisors are used to identify the genera. The formula for div(df), weighted pole fiber, and previously established Riemann–Hurwitz compare 2g_top−2 with 2g_a−2, the latter using h¹(K_X)=1 from duality. The final strict inequality in the high-degree corollary correctly excludes the threshold case. |
| Dimension jumps and exercises | The dual evaluation rank gives the opposite jump in the obstruction dimension. Checked all twelve solutions, including the cutoff test against δ₀, local primitive ambiguity, g+m−1 formula, genus-zero degree-zero argument, degree −1 invertibility, and the dual point jump. In genus two, added D=K+P−Q for distinct P,Q to realize the lower dimension; a principal P−Q would give an impossible degree-one map to the sphere. |

Verdict on the fixed candidate is mathematical thickening pass for the
stated Chapter 311 scope. Full-volume typesetting and final independent
review remain separate.
