# V24 B-04 independent thickening · Chapter 309

Read base roles/bundles/ch309.tex in full, 730 lines. SHA-256
1320c559ccb64aa6e99561ace500ff2715e80311ad409f274e29d50d7a1f0a79.
Surgical candidate roles/thicken2/ch309.tex, 745 lines and 31,967 bytes.
SHA-256 f979dcf18c7186a40500b4f705509306c2b93891863942b242c40fd5fd2aa4d7.
Reviewed as an independent role. Actual serving model configuration is unverified.

| Section | Mathematical checkpoints |
|---|---|
| Local order | Factor a nonzero meromorphic germ in a coordinate; check change of parameter, negative powers, units, sum cancellation, and the connectedness needed for a global field. The infinity-chart example yields order minus one. |
| Divisor arithmetic | Pointwise equality, effectiveness, and finite support are separate. Compactness turns local finiteness of zeros and poles into finiteness; the zero function has no divisor. The explicit example has the stated degree and coefficients. |
| Meromorphic one-forms and residues | The derivative of a coordinate transition is a unit; integration of all Laurent terms other than the minus-first term proves residue invariance. Stokes subtracts each clockwise boundary circle with the correct sign. The torus test uses that the descended differential has no zero. Added an explicit nonzero hypothesis to the definition of a differential's divisor. |
| Principal divisors and linear equivalence | Logarithmic derivative and total residue give degree zero. Compactness and connectedness give the nonzero constant kernel. The linear-equivalence representative on the sphere has the declared sign. Pullback counts each point with its local degree and has the stipulated degree formula. |
| Functions subject to a divisor bound | The local holomorphy criterion is equivalent to the divisor inequality and includes zero. Multiplication by h in the claimed D-to-E direction preserves the inequality. The mixed sphere example has the stated basis and values at infinity. |
| Dimension bounds and elementary computations | The injection by d+1 Taylor coefficients uses a point outside the support and the degree of the effective divisor. The one-point quotient selects one coefficient. Degree-zero and sphere counts are derived without Riemann–Roch. |
| Differentials and the canonical divisor | Canonical divisor existence is conditional at this stage. Quotient of nonzero forms gives linear equivalence. Differentiation yields orders e−1 and −e−1 in the regular and pole cases. Riemann–Hurwitz then computes the degree. |
| Prescribed principal parts | The quotient definition is intrinsic. The finite-dimensional coordinate description applies to an effective pole divisor, and the residue obstruction is unchanged by representative. The explicit sphere construction treats finite poles and infinity separately. Added its direct consequence that every meromorphic function on the sphere is rational, supplying ledger item 309.03 and the rationality used by the last solution. |
| Exercises and solutions | Recomputed all twelve. Checked local coefficient and residue cancellations, multiplicities and infinity values, mixed divisor basis orders 3, 2, 1, non-surjectivity of torus jet evaluation, dF zeros ±1 and two double poles, constant −5 in the normalized principal-parts exercise, total residue interpolation, and the torus primitive obstruction. |

Verdict on the fixed candidate is mathematical thickening pass for the
stated Chapter 309 scope. Full-volume typesetting and final independent
review remain separate.
