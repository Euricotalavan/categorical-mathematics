# V24 ReadFlow R1 engineering preflight

The adopted V0 ReadFlow R1 artifact was fetched by its fixed file and version,
7,007,679 bytes with SHA-256
5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732.
ZIP CRC and its original verifier passed, covering 913 release files and 668
V0 frozen math inputs. No V0 mathematics was brought into the V24 edition.

The three official template source files are byte-identical to the adopted
artifact. The V24 adapter sets running context, volume metadata,
three-digit contents widths and five notation shorthands. The portable font
binaries and licenses match the fixed V23 release manifest. Both the original
V0 tool provenance and the adapted V24 build entry are retained.

The synthetic fixture reached a stable XeLaTeX auxiliary state after two
passes. It produced two 190 × 260 mm pages with zero hard, overfull, header
or underfull warnings. Both pages were rendered and visually inspected.
Outline numbers, glyphs, box separation, cross-references, formula alignment,
and footer separation were correct. The short final page is fixture-specific.
Fixture PDF SHA-256
d35baa4cb484c822b7715b3c420533c1dd86a1d4d66dcd01c62e8506f57b1f97.

For B-06, take the fixed B-05 source and preserve per-file input hashes.
Use the strict build, scan PDF coordinates, embedded faces and links, render
all physical pages in ascending order, and inspect formulas or anomalous
positions at full resolution. Use actual page-line positions as evidence
for any local adjustment, then verify source deltas and reflowed page
boundaries. Preserve the shared template and rerun on the final source.
