# V24 fixed inputs

V24 · Riemann Surfaces · Chapters 305–312 · B single Work · 2026-11-28

- The user approved the public set listed in V24-Reference-Readiness-v1.md and
  authorized B-01 through B-08, with four independent roles. The principal
  assistant exercises the user's ordinary review decisions. The independent
  thickening editor signs mathematical acceptance at B-07.
- The edition uses the five fixed PDFs identified by checksum in that record.
  Donaldson's 2004 copy, the subscribed publication, and the unavailable
  Forster and Miranda textbooks remain outside the adopted corpus.
- The predecessor's published index at Git commit
  f134c70ebe7fe7af0143dd557d56ddd953a14c68 ends V23 at Chapter 304. V24 has
  eight chapters under the git-aligned v4.1 planning table, module I03.
- Formal layout template is the fixed V0 ReadFlow R1 archive at commit
  8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3, SHA-256
  5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732.
- The user's approval authorizes the work and private delivery. A public
  GitHub publication is a separate action.
