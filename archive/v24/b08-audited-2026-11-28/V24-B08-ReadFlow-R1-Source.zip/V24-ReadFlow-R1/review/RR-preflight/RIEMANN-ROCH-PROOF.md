# V24 · Chapter 311 proof review

V24 Chapters 305–312 · B single Work · independent technical review  
2026-11-28 · Fixed reference McMullen, *Riemann Surfaces*, dated 2026-04-28, 183 PDF pages, 1,128,808 bytes  
SHA-256 1442374a6f3a389a426d966103adb689e5947e80efb4bcee34b6018383a30406

## Reference locations and responsibility

| Source | Printed pages | PDF pages | Use |
|---|---:|---:|---|
| McMullen §3 | 15–17, 23–24 | 16–18, 24–25 | Local normal form, ramification multiplicities and Riemann–Hurwitz |
| McMullen §6, Theorems 6.3–6.4 and Corollary 6.5 | 55–56 | 56–57 | Period bound on the dimension of holomorphic forms |
| McMullen §7 | 67–77 | 68–78 | Čech and sheaf language, fine-resolution comparison when taught |
| McMullen §8, Theorems 8.1, 8.4, 8.7, 8.10 | 78–82 | 79–83 | Local Cauchy solution, Dolbeault groups, closed range and basic duality |
| McMullen §9, Theorems 9.1, 9.4–9.6 and Corollaries 9.8–9.11 | 83–88 | 84–89 | Divisors, Euler formula, meromorphic functions, canonical degree and genus |
| McMullen §11, Theorems 11.1–11.2 and proof by dimension | 94–95 | 95–96 | Residue witness, full Serre duality and classical Riemann–Roch |
| McMullen §14 | 118–121 | 119–122 | Transition functions and divisor bundles |
| Taylor, *Dirac-type Operators on a Compact Riemann Surface* | 1–4 | 1–4 | Sign check for dual bundle and canonical factor in the pairing |

The source files and locations were checked locally. The route below supplies details for the analytic arguments and proves the point-step exact sequence directly on Dolbeault representatives. The latter proof is available before the reader studies arbitrary sheaf cohomology.

## Notation and prerequisites

Let \(X\) be compact and connected, with topological genus \(g\). Write \(K_X\) for the canonical holomorphic line bundle; reserve \(K\) for an actual canonical divisor after a nonzero meromorphic differential has been constructed. For a divisor \(D=\sum d_P P\), let \(L_D=\mathcal O(D)\), with local frame \(e_D=z^{-d_P}\) at \(P\) in a coordinate centered there. Let \(A^{0,j}(L_D)\) denote smooth \(L_D\)-valued forms of type \((0,j)\). The operator \(\bar\partial_D\) differentiates coefficients in holomorphic frames and is independent of the frame because transitions are holomorphic. Set \(H_D^0=\ker\bar\partial_D\), \(H_D^1=A^{0,1}(L_D)/\bar\partial_D A^{0,0}(L_D)\), \(\ell(D)=\dim H_D^0\), and \(a=\dim H^0(X,K_X)\). The connected maximum principle gives \(\ell(0)=1\).

Earlier chapters supply the compact-surface fundamental group or a triangulation with \(\operatorname{rank}H_1(X;\mathbb Z)=2g\), orientation and Stokes, local normal form of nonconstant holomorphic maps, Riemann–Hurwitz, meromorphic orders, line-bundle frames, smooth bump functions, and Cauchy estimates. Chapter 311 supplies the elementary distribution facts and states Hahn–Banach in its seminorm form.

## Proof sequence

### 1. Local right inverse to \(\bar\partial\)

For compactly supported smooth \(q\) on \(\mathbb C\), using \(dA=dx\,dy\), set
\[
 Tq(z)=\frac1\pi\int_{\mathbb C}\frac{q(w)}{z-w}\,dA(w).
\]
The kernel is locally integrable. Integration by parts in the complement of a disk of radius \(\epsilon\), whose inner boundary is clockwise, shows
\[
 -\frac1\pi\int_{\mathbb C}\frac{\partial_{\bar z}\phi}{z}\,dA=\phi(0)
\]
for each compactly supported smooth test function \(\phi\). Thus \(\bar\partial(1/\pi z)=\delta_0\) in distributions. Differentiation moves to \(q\) in the convolution, so \(Tq\) is smooth and \(\partial_{\bar z}Tq=q\). For supports in a fixed bounded disk, the integral of \(|z-w|^{-1}\) over those supports is bounded uniformly for \(z\) in any fixed disk. Moving derivatives to the input proves \(Tq_n\to0\) in every local \(C^k\) norm if \(q_n\to0\) in \(C^\infty\) with fixed support. Apply to a cutoff of the coefficient of a smooth local \((0,1)\)-form. A holomorphic bundle frame gives the corresponding line-bundle result.

The complex of global Dolbeault forms has length one, since \((0,2)\)-forms vanish. If the higher groups are stated as ordinary sheaf cohomology, first use local solvability to prove exactness of the Dolbeault resolution of the holomorphic sheaf by smooth sections and forms. Smooth forms admit multiplication by partitions of unity. Their sheaves are fine and acyclic on a paracompact surface, so the acyclic-resolution theorem gives the asserted comparison and \(H^j(X,\mathcal O(L))=0\) for \(j\ge2\). Real dimension two alone leaves \(H^2\) undecided. The subsequent proof uses only the concrete Dolbeault groups.

### 2. The period bound \(a\le g\)

Every form \(\omega+\overline\nu\), with \(\omega,\nu\) holomorphic, is closed and has a period homomorphism \(\pi_1(X)\to\mathbb C\). Trivial periods produce a global smooth primitive \(F\) by path integration and local primitives. Wedge \(dF=\omega+\overline\nu\) with \(\overline\omega\) and integrate. Stokes gives zero, since \(d\overline\omega=0\). The \((0,2)\) term vanishes, and \(i\omega\wedge\overline\omega\) is a nonnegative density, positive wherever \(\omega\ne0\). Thus \(\omega=0\). Conjugate the remaining exact form and use the same argument for \(\nu=0\). The period map on \(\Omega(X)\oplus\overline{\Omega(X)}\) is therefore injective. Its target factors through the abelianization, whose complex dual has dimension \(2g\). Consequently \(a\) is finite and \(2a\le2g\).

### 3. Scalar closed range and finiteness of \(H_0^1\)

Fix \(Q\in X\). If \(\bar\partial f_n\to\eta\) in \(C^\infty\), normalize \(f_n(Q)=0\). Choose finitely many charts with three nested disk radii, the smallest disks covering \(X\). On each chart choose a cutoff inside the largest disk, equal to one on the middle disk, and apply \(T\) to the cut-off coefficient of \(\bar\partial f_n\). This yields local corrections \(u_n\) converging smoothly on the middle disk, with \(f_n-u_n\) holomorphic there.

If \(\|f_n\|_\infty\) were unbounded, divide a subsequence by its supnorm, which tends to infinity. The normalized corrections tend to zero in \(C^\infty\). The normalized holomorphic differences are uniformly bounded on the middle disks. By Montel and Cauchy estimates a single subsequence converges smoothly on the finite cover by smallest disks. The local limits fit together, as the normalized functions agree on overlaps. The limit is holomorphic and vanishes at \(Q\), hence is zero, contradicting uniform supnorm one on \(X\). Thus the supnorms are bounded. For the unnormalized sequence, the holomorphic differences are now bounded and the corrections converge smoothly. The same finite-cover argument gives a global smooth subsequential limit \(f\) with \(\bar\partial f=\eta\). Since this smooth topology is metrizable, this proves the range closed.

The Hausdorff locally convex quotient \(H_0^1\) has separating continuous dual by Hahn–Banach. A continuous functional on it lifts to a functional on \(A^{0,1}(X)\). On a disk it acts on the coefficient of \(q\,d\bar z\) by a distribution, written as the pairing with a \((1,0)\)-current \(S\). The local coefficient distributions are compatible by invariance of the wedge pairing. Annihilating \(\bar\partial f\) for every smooth \(f\) makes the current coefficient distributionally holomorphic, by integration by parts against compactly supported tests.

For local weak Weyl, mollify a distribution \(u\) with \(\bar\partial u=0\) by a smooth approximate identity. On each interior disk the smooth mollifications \(u_\epsilon\) are holomorphic for sufficiently small \(\epsilon\). Fix a normalized smooth radial kernel \(\psi\) supported in a disk smaller than the distance from the working subdisk to the boundary. By the mean-value property \(u_\epsilon*\psi=u_\epsilon\) there. Let \(\epsilon\to0\) in distributions, yielding \(u=u*\psi\) on the working subdisk. Convolution with the fixed test function is smooth, so the coefficient is holomorphic. Conversely, each holomorphic \(1\)-form \(\omega\) pairs by \(\int_X\omega\wedge\eta\), and Stokes kills \(\bar\partial\)-exact input. This identifies the continuous dual with \(\Omega(X)\).

The evaluation map \(H_0^1\to(\Omega(X))^*\) is injective by separation. A proper image in this finite-dimensional dual would have a nonzero annihilator, contradicting the identification of the continuous dual. Hence \(h^1(0)=a\). The later argument needs closed range only for the trivial bundle.

### 4. The exact sequence for adding a point

At \(P\), put \(d=d_P\) and choose \(z(P)=0\). The inclusion \(j:L_D\to L_{D+P}\) takes \(e_D\) to \(z e_{D+P}\) and is an isomorphism off \(P\). Define \(q:H_{D+P}^0\to\mathbb C\) by evaluating the coefficient in \(e_{D+P}\) at \(P\). The chosen frame sets this coordinate on a one-dimensional quotient. Given \(c\in\mathbb C\), use a smooth cutoff \(\chi\) equal to one near \(P\) and with compact support in the chart. Extend \(s_c=\chi c e_{D+P}\) by zero and put \(\delta(c)=[j^{-1}\bar\partial s_c]\). This form is zero near \(P\) and extends smoothly. Changing the cutoff changes the representative by an exact form because the difference of cutoff sections divides smoothly through \(j\).

The sequence is
\[
 0\to H_D^0\xrightarrow{j}H_{D+P}^0\xrightarrow{q}\mathbb C
 \xrightarrow{\delta}H_D^1\xrightarrow{j}H_{D+P}^1\to0 .
\]
At \(H_{D+P}^0\), use holomorphic divisibility by \(z\) for functions vanishing at zero. If \(\delta(c)=0\), subtract the \(j\)-image of a primitive of its representative from \(s_c\) to obtain a holomorphic section with coefficient \(c\). Conversely such a section differs from \(s_c\) by a smooth \(j\)-image. This proves exactness at \(\mathbb C\). If \(j\eta=\bar\partial u\) globally, solve \(\eta=\bar\partial v\) near \(P\). Then \(u-jv\) is holomorphic there. Take \(c\) to be its coefficient at \(P\). Near \(P\), \(u-jv-s_c\) is holomorphic and vanishes at \(P\). Thus \(u-s_c\) divides smoothly through \(j\) globally, giving \([\eta]=\delta(c)\). The composite \(j\delta=0\) follows from the definition. For surjectivity at the last group, subtract the \(\bar\partial\) of a cutoff of a local primitive of any form in \(L_{D+P}\) and then divide the resulting form by \(j\), since it vanishes near \(P\).

Finiteness of \(H^0\) and \(H^1\) propagates through a point step in either direction by exactness, with the extra kernel or cokernel contributing at most one dimension. Every divisor is reached from zero by adding or subtracting finitely many points. Taking alternating dimensions gives \(\chi(D+P)-\chi(D)=1\), so
\[
 \chi(D)=\ell(D)-h^1(D)=\deg D+1-a .
\]

### 5. Canonical divisor and genus equality

Take \(D=(a+1)P\), so \(\ell(D)\ge2\). A nonconstant \(f\in H_D^0\) is a meromorphic function, and \(df\ne0\) because a holomorphic function with zero derivative is locally constant. Its divisor \(K=\operatorname{div}(df)\) gives \(L_K\simeq K_X\) by multiplication by \(df\). Orders of differentials are local-chart independent because the chart coefficient changes by a holomorphic unit. Their divisor support is discrete and finite on \(X\).

Viewed as a map \(f:X\to\mathbb P^1\), at \(f(P)\ne\infty\) local degree \(e_P\) contributes \(e_P-1\) to the order of \(df\), while a pole of order \(e_P\) contributes \(-e_P-1\). Thus
\[
 K=R_f-2f^*(\infty),\qquad \deg K=\deg R_f-2\deg f=2g-2
\]
by Riemann–Hurwitz. Integration of a smooth \((1,1)\)-form induces a nonzero functional on \(H_K^1\), using the bundle isomorphism. Exact inputs are exterior derivatives of smooth \((1,0)\)-forms and integrate to zero, while a positive smooth area form has positive integral. Hence \(h^1(K)\ge1\). Now \(\ell(K)=a\) and the Euler formula yields \(h^1(K)=1+2(a-g)\). Together with \(a\le g\) this forces \(a=g\) and \(h^1(K)=1\). The trace by integration then identifies \(H_K^1\) with \(\mathbb C\).

### 6. Full duality and classical formula

For \(\omega\in H^0(X,K_X\otimes L_D^{-1})\) and \(\eta\in A^{0,1}(L_D)\), contraction and wedge produce an ordinary \((1,1)\)-form \(\omega\wedge\eta\). The integral kills \(\bar\partial\)-exact representatives by holomorphicity and Stokes. This defines \(H^0(X,K_X\otimes L_D^{-1})\to(H_D^1)^*\).

For injectivity take a nonzero \(\omega\) and pick \(P\) away from the support of \(D\) and the zeros of \(\omega\). Locally \(\omega=h(z)\,dz\) with \(h(0)\ne0\), using the divisor bundle frame \(1\). With \(\chi=1\) on a smaller disk and zero near the outer boundary, let \(\eta=(\bar\partial\chi)/z\), extended by zero. Stokes on the annulus gives
\[
 \int_X\omega\wedge\eta=-\int_{\mathrm{annulus}}d(\chi\,\omega/z)
 =2\pi i h(0)\ne0.
\]
Therefore \(d(D)=h^1(D)-\ell(K-D)\ge0\). Applying the same inequality to \(K-D\) gives
\[
 d(D)+d(K-D)=-\chi(D)-\chi(K-D)=-\deg K-2+2g=0 .
\]
Both differences vanish, proving the pairing perfect and \(\ell(D)-\ell(K-D)=\deg D+1-g\).

## Integration checks for drafting

- Put compactness and connectedness at the first global lemma. Riemann–Hurwitz depends on constant degree and counting the points in \(f^{-1}(\infty)\) with their multiplicities.
- Reserve an actual differential \(df\) for existence of a canonical divisor. The canonical bundle is available in Chapter 310.
- State the local coefficient in the point step once, namely the coefficient of \(z^{-d_P-1}\). The divisor bundle has local frame \(z^{-d_P}\), and the pairing uses \(K_X\otimes L_D^{-1}\).
- For base duality, spell out continuity, separation and why a finite-dimensional continuous dual forces a finite-dimensional original space in the Hausdorff quotient. For general duality, retain the cutoff witness and the paired Euler calculation.
- Suggested checks after the theorem include \(\mathbb P^1\) with \(D=n\infty\) for every integer \(n\), a torus with canonical section \(dz\) and \(\ell(nP)=n\) for \(n\ge1\), an explicit high-degree example with \(\deg(K-D)<0\), and interpolation at finitely many points by comparing \(\ell(D)\) with \(\ell(D-E)\). Derive \(\ell(D)=0\) for \(\deg D<0\) from degree zero of principal divisors.
