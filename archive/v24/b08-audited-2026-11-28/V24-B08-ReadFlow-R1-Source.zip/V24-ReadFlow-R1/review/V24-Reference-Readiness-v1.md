# V24《Riemann 曲面》文獻準備與交接

版本 v1 · 2026-11-28（台北時間）  
交接 ID `V24-PRE-B01-REFERENCES-20261128`  
主控 → 本 Work 的精修角色 · B 方案單一 Work · 文獻準備完成，待使用者確認後啟動 B-01。

前卷 V23 已發布第 291–304 章。本卷依現行分卷表的八章順延為 **第 305–312 章**。章號的 Git 基線固定在 `f134c70ebe7fe7af0143dd557d56ddd953a14c68`，見 [V23 發布紀錄](https://github.com/Euricotalavan/categorical-mathematics/blob/f134c70ebe7fe7af0143dd557d56ddd953a14c68/archive/v23/b08-audited-2026-11-28/README.md)。已有四位作者的五份公開全文可供八章查考。以下是原文定位及取得狀態，逐項覆蓋和證明審查留待 B-01。

## 可讀全文

五份 PDF 均直接從作者或開課單位的公開入口取回，核對 PDF 格式、頁數和 SHA-256，並抽讀下列原文。頁碼以檔案的第 1 頁起算，另列印刷頁碼差異。各官方入口供取回同版全文。

| 作者與固定版本 | 入口 | 已抽讀的正文與用途 | 檔案 |
|---|---|---|---|
| Curtis T. McMullen，*Riemann Surfaces*，Harvard Math 213b，2026-04-28 | [Harvard 課程](https://people.math.harvard.edu/~ctm/math213b/) · [PDF](https://people.math.harvard.edu/~ctm/math213b/home/course/course.pdf) | §2–5 抽讀曲面例子、局部正規形、分歧覆蓋及解析延拓。§9 PDF pp. 84–89 查除子、歐拉示性數形式的 Riemann–Roch、典範除子次數及兩種 genus 的比較。§11 PDF pp. 95–98 查 Serre 對偶與經典形式。§12–14 抽查整體應用、轉移函數及除子線叢。正文印刷頁碼比 PDF 頁碼少一。 | `mcmullen-2026.pdf` · 183 頁 · 1,128,808 bytes |
| Constantin Teleman，*Riemann Surfaces*，Cambridge Lent Term 2003，James Lingard 排錄 | [Cambridge 課程資源](https://www.maths.cam.ac.uk/undergrad/studentreps/tripos-specific-resources) · [作者 PDF](https://math.berkeley.edu/~teleman/math/Riemann.pdf) | 第 3–8 講抽讀圖冊、局部映射、分歧與 Riemann–Hurwitz。第 9–11 講抽查橢圓函數及週期格。第 15–16 講查覆蓋、解析延拓曲面及單值性。第 16 講為 PDF pp. 64–69，印刷 pp. 63–68。 | `teleman-2003.pdf` · 69 頁 · 2,047,176 bytes |
| Michael Taylor，*Introduction to Complex Analysis*，UNC 作者站公開稿 | [作者書目](https://mtaylor.web.unc.edu/books-and-monographs/) · [PDF](https://mtaylor.web.unc.edu/wp-content/uploads/sites/16915/2018/04/complex.pdf) | §10 PDF p. 118 起查解析延拓，§22 p. 270 起查球面座標，§25 p. 291 起查覆蓋與提升。§30–34 PDF pp. 335–369 間抽讀橢圓函數、Weierstrass ℘ 與平方根曲面。以作者站 PDF 的頁序定位。 | `taylor-complex.pdf` · 478 頁 · 1,351,941 bytes |
| Michael Taylor，*Dirac-type Operators on a Compact Riemann Surface*，UNC 作者站公開節錄 | [作者 PDF](https://mtaylor.web.unc.edu/wp-content/uploads/sites/16915/2018/04/rroch.pdf) | PDF pp. 1–5 抽讀全純線叢的轉移函數、除子線叢、Riemann–Roch 指標公式及低 genus 應用。指標觀點用來對照；本卷候選主證明取自 McMullen。 | `taylor-rroch.pdf` · 6 頁 · 127,091 bytes |
| Andreas Gathmann，*Plane Algebraic Curves*，RPTU SS 2026，2026-07-20 更新 | [作者課程](https://agag-gathmann.math.rptu.de/de/pac.php) · [PDF](https://agag-gathmann.math.rptu.de/class/pac-2026/pac-2026.pdf) | §5 抽查光滑複平面曲線的 genus 公式，§6 PDF pp. 47–49 查除子、主除子與 Picard 群，§8 PDF pp. 61–67 抽讀線性系統、典範除子與 Riemann–Roch。這條代數證明的設定為書內的光滑射影平面曲線，供第 312 章例題與第 311 章比較。 | `gathmann-pac-2026.pdf` · 71 頁 · 1,047,579 bytes |

```text
1442374a6f3a389a426d966103adb689e5947e80efb4bcee34b6018383a30406  mcmullen-2026.pdf
7f536e4c3643d589d98fa1cb4abfd0a28b455730313072e1883e40c12630dc5c  teleman-2003.pdf
04fcfafba8efd4977ce2f81627ba0930979b56eeb7b1702943f8ebcad675bc31  taylor-complex.pdf
ead0533899cdbed731ea4e9bca5b7057f07c9bcb6b11736b193426f24f6d82bb  taylor-rroch.pdf
b6c67e53d81356c34ee0fe5e63d5681d274a323190dad83315bf3e48676cb39e  gathmann-pac-2026.pdf
```

## 八章的文獻定位

| 章 | 分卷表章題 | 可供核讀的原文 |
|---|---|---|
| 305 | 複結構與曲面圖冊 | McMullen §2、§3 起首，Teleman 第 3 講，Taylor §22。 |
| 306 | 全純映射與分歧 | McMullen §3 的局部正規形與 proper maps，Teleman 第 4–8 講的分歧及 Riemann–Hurwitz。 |
| 307 | 覆蓋與單值性 | McMullen §3 的覆蓋構造，Teleman 第 15–16 講，Taylor §25 的提升。 |
| 308 | 解析延拓的曲面 | McMullen §4–5 的芽、延拓曲面與代數函數，Teleman 第 16 講，Taylor §10、§34。 |
| 309 | 亞純函數與除子 | McMullen §9，Teleman 第 4、14 講，Gathmann §6。 |
| 310 | 線叢的基本例 | McMullen §14，Taylor 指標講義 PDF pp. 1–3。 |
| 311 | Riemann–Roch 的所選路線 | McMullen §6–9、§11。候選主線為層上同調、增加一點的短正合列、Serre 對偶。B-01 先核有限維性、$H^2$ 消失、兩種 genus 的對照及證明依賴。 |
| 312 | 緊曲面上的整體應用 | McMullen §10、§12–13 的主部問題與映射，Teleman 第 9–11 講的環面，Gathmann §5、§8 的光滑平面曲線。 |

## 原規劃三本專書的取得狀態

| 專書 | 本輪可讀證據與限制 | 有需要納入原書時的入口 |
|---|---|---|
| Otto Forster，*Lectures on Riemann Surfaces*，GTM 81 | 已核 Springer 1981 版書目、章目和訂閱提示，也找到作者頁所列 1999 年第 4 次校訂印刷的細目。Springer 全書 PDF 入口回到 HTML 預覽。本輪未取得專書正文。專案館藏快照記有清大紙本。 | [Springer](https://link.springer.com/book/10.1007/978-1-4612-5961-9) · [作者版目錄](https://www.mathematik.uni-muenchen.de/~forster/books/riem/riemsurf.html) · [清大館藏](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990007631720206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw)。優先 §§1–8、12–18，線叢參照 §29。 |
| Rick Miranda，*Algebraic Curves and Riemann Surfaces*，AMS GSM 5，1995 | 核到 KIT 館藏與 UNAM 章目。AMS 入口回 403。本輪未取得專書正文。專案館藏快照記有清大紙本。 | [KIT 書目](https://katalog.bibliothek.kit.edu/bib/1027851) · [UNAM 章目](https://uib.nucleares.unam.mx/bulletines_files/adquisitions/48_Enero2026Parte1.pdf) · [清大館藏](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990008615590206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw)。優先第 I–III、V–VII、XI 章。 |
| Simon Donaldson，*Riemann Surfaces*，OUP 2011 | 核到 Oxford Academic 書目與目錄摘要。2026-11-14 專案館藏快照標示清大有電子版。本輪無法從 Primo 公開入口實開校方授權全文。 | [Oxford Academic](https://academic.oup.com/book/27393) · [清大館藏](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990021346680206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw) · [清大校外存取說明](https://www.lib.nthu.edu.tw/en/use/faq/q_a5.html)。優先第 3–4、7–9、12 章。 |

### 待確認的轉載

Donaldson 2004 年稿的轉載授權仍待核。本卷採已核准的公開文獻組合。

## 續作核對

- **專案基線。** 分卷表與書目表均為 git-aligned v4，修訂 `v4.1-interface-and-open-coverage-review`。分卷表 2,167,706 bytes，SHA-256 `098aaacab85e330cb0493fc928916361c3fba09c0d36b3964f61c74ad2a2e1df`。文獻表 3,482,004 bytes，SHA-256 `4b3e0af09024a799744ee6fbb76ad68b95d82baeb020e5a6b8033cf00361a59d`。已讀兩表的現行 V24 條目及 V23 章號基線。
- **文獻擷取與輸入。** `math-extractor-v0.4.zip` 1,021,262 bytes，SHA-256 `c2d47e097447a836bcad63d5a030106b1ec261bac4ffe32a6aecc783aca244f3`。已核 ZIP 完整性，並讀用法、定位欄位及限制。預備查核用 PDF 文字層定位，正式索引及定義／命題／證明／例題責任表待 B-01 建立。
- **編輯與正文基線。** 後續採正式 ReadFlow R1，固定來源 [Git artifact commit 8b9dc7f](https://github.com/Euricotalavan/categorical-mathematics/tree/8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3/archive/v0/readflow-r1-editorial-2026-11-17)，正式模板 SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732` 沿專案導覽。V24 正文、PDF、模板局部補丁、整合與編譯驗證尚未產生。前卷發布紀錄作章號依據。其他卷與凍結稿保持原版。
- **決策與待核。** OPEN 1 是公開書目組合的使用者確認，暫停 B-01。OPEN 2 是原三本專書正文與 Rutgers 轉載授權，採公開組合即無須等待。OPEN 3 是論證細項與整卷逐條覆蓋，由精修在 B-01 負責。主控已完成本次準備，精修子任務尚未派發，其模型與推理設定待派工時核實。
- **唯一下一步。** 收到使用者確認後，精修先核本交接、章界、來源版本與檔案指紋，建立合法可讀固定版本的逐項來源索引，逐項核對定義、命題、證明與必要例子及其適用條件，記未知及後置理由。B-01 對應 A 共同工作中的逐項文獻索引與定界準備。沿用本次已核書目與 Git 章界。
- **傳遞與回執。** 本版交付使用者確認。精修接手回執待 B-01 啟動後填寫，列實際讀入檔及雜湊、版本差異、缺檔與受影響範圍、可續作與下一步。
