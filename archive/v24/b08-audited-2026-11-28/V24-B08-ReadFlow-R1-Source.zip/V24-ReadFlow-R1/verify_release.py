#!/usr/bin/env python3
"""Verify every file of the extracted V24 release against its manifest."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "RELEASE-MANIFEST.json"


def verify():
    entries = json.loads(MANIFEST.read_text(encoding="utf-8"))["files"]
    seen = set()
    errors = []
    for entry in entries:
        relative = Path(entry["path"])
        if relative.is_absolute() or ".." in relative.parts or relative in seen:
            errors.append(f"Invalid or duplicate manifest path: {relative}")
            continue
        seen.add(relative)
        path = ROOT / relative
        if not path.is_file():
            errors.append(f"Missing: {relative}")
            continue
        contents = path.read_bytes()
        if len(contents) != entry["bytes"]:
            errors.append(f"Size differs: {relative}")
        if hashlib.sha256(contents).hexdigest() != entry["sha256"]:
            errors.append(f"Checksum differs: {relative}")
    if errors:
        raise SystemExit("\n".join(errors))
    print(f"PASS: {len(seen)} release files match their recorded sizes and SHA-256.")


if __name__ == "__main__":
    verify()
