# V25 B-04 Ch.322 內容交接 v1

交接 ID `V25-B04-322-GEOMETRY-v1`；2026-11-28；B 單一 Work；擴充／打厚展開副本 → 主控合入、精修與整卷核查。角色任務彼此隔離；本件不作 B-07 整卷終審簽核。實際模型及 High runtime 設定無可查證資料，記未核實。

已實讀 B02 `Book-Design.md`、B03 `Authoring-Contract.md`／`Calibration.tex`／`Thickness-Review.md`；源責任見 B01 `geometry.md`，SHA-256 `09477a7dbc14736669a2bad18d6859ede4af82f1bee1f93179425e83b1c99d81`。主控批准 B04 範圍322–324，無須逐節等使用者批准。正文只在本章指定副本製作，未動共享巨集、工具 ZIP、既有卷或 Git。

## 固定基線與主控所有權

可合入來源為 `v25-work/book/manuscript/ch322.tex`。本角色完成並修補的基線 SHA-256：`c0710f404d0eac2c7ecdad66c9124968b40235952df46bedf794339faa7526f6`。對應獨立章工程 PDF `v25-work/book/.build/chapter-322/volume25.pdf`：123,567 bytes，SHA-256 `d31b42c9df76269b3237e4ae50acf8f633afdb55b7bb24da306789857ed89786`；2 passes，diagnostics=[]。這是主控 Hartogs enrichment 合入前配對。

主控現接管本章，將 `v25-work/b04/hartogs-kernel322.tex` 的模型應用在 `% OPTIONAL HARTOGS KERNEL` 合入；其 punctured-product lemma引用既有 `prop:322-puncture`，避免重複。本角色在接管後不再修改322。最新主控補丁的來源／PDF hash及頁數由主控重建後記錄，以上 hash不得冒充其新版本。

## 實際覆蓋落點

| B01責任 | 本章穩定 label／實際內容 | 證明責任／來源 |
|---|---|---|
| G322-01 | 卷首B^n、D^n、內積／測度；`prob:322-topology` | 範數徑向 homeomorphism及逆完整算；O01 p32–33、O04印31/PDF33。 |
| G322-02 | `def:322-bergman`、`lem:322-evaluation` | A²代表、共同半徑、平均值、C–S、閉性；O01 p160–161。 |
| G322-03–04 | `def:322-kernel`、`prop:322-extremal`、`ex:322-entire` | Riesz約定與最小化短證、再生、對稱、極值、bounded positivity與C^n反例；O01 p162–164，自行展開。 |
| G322-05 | `prop:322-kernel-series` | 正交展開＋有限和Bessel界＋Montel唯一極限證局部一致，補原來源uniform tail短步；O01 p163–164。 |
| G322-06–08 | `lem:322-monomials`、`lem:322-simplex`、`prop:322-ball-norms`、`ex:322-norms` | angular Parseval＋Tonelli證完備；simplex beta積分逐次算；球／多圓盤所有monomial norm；O01 Ex5.2.8–9，自行完整展開。 |
| G322-09 | `thm:322-model-kernels`、`ex:322-reproduce` | multinomial／幾何級數求核，明示∑|z_j||w_j|界支援重排與全域積分；O01 p164–165。 |
| G322-10 | `thm:322-covariance`、`ex:322-scaling` | 實Jacobian平方、unitary pullback、ONB核變換、各向不同半徑；O01 Ex5.2.7及O04 Ex17。 |
| 新補G322-06 | `prop:322-puncture` | 一變數Laurent角平均排除所有負係數，product Fubini＋參數全純係數證joint extension，unitary restriction；O01 Ex5.2.3(a)責任及自行product推導。 |
| G322完整應用 | `prop:322-projection`、`ex:322-leastnorm`、`ex:322-nonconstant-projection` | orthogonal projection積分、distributional dbar與最小範數；|z1|²及z1|z1|²完整校正量及residual norm算。依Ch319弱全純定理，主控須核對實際標號。 |
| G322-11–12 | `def:322-proper`、`lem:322-proper-boundary`、`lem:322-sphere`、`thm:322-inequivalence` | 不借邊界延拓；proper sequence criterion、sphere no-disc、Montel slices、full boundary derivative limit、最大模全證；O01 p33–36、O04印31–32/PDF33–34。 |
| G322-13 | `prob:322-disc`至`prob:322-centers`，共10題各緊接psolution | 核常數、mixed norm、ellipsoid、extremal、兩projection、proper target、topology、growth、中心值誤證；皆有實算解。 |

## 獨立核與修補

獨立打厚任務 `/root/thickness` 在來源 `85e2113b2a435b705bf958eec3437cb45012a49c8a0847c7bdbafdb9960bab50` 核主要數學後回覆主體sound，確認Montel尾項修補、covariance、proper slices、residual norms。其小改已落入上述c071基線：conjugate domain改U^*避closure歧義；明示absolute monomial sum；squared norm措辭；Riesz k=conj(L(e))e。這是章級獨立意見，不代替B05/B07整卷核。

## OPEN／UNKNOWN／下一步

- 主控 Hartogs enrichment 的獨立數學核、合入與配對PDF新hash待主控記錄。
- Ch319 distributional holomorphy目前以明示Chapter引用，主控整合時須核其真實定理落點；本章未自稱已有跨章label核驗。
- 本角色只有工程編譯，尚未全頁視檢或正式B06排版；ReadFlow R1巨集未改，配對PDF供工程核。
- 下一步由精修對主控固定新版獨立核來源／語意，主控全卷依賴與記號整合；通過條件為新正文來源責任落點及所有估計／量詞無缺，工程與語意分列。
- 禁止重做已核來源取得、覆寫其他章或凍結卷、因本章已編譯而標整卷通過、公開教材或推Git。本角色未作外部保存或發布，檔案由主控續存。
