# Ch313 B04 expansion handoff v1

ID V25-B04-313-EXP-v1 · 2026-11-28 · expansion → controller → independent thickening/refinement.

Input: B02 Book-Design.md, B03 Authoring-Contract.md and Calibration.tex, B01 local.md (hash f2279df2a19eae8318c94a1d0cac76c42e719ff16d54c7b6d6ae16cc6405a665). Only output manuscript/ch313.tex; source SHA-256 `379621a9a2b63c89695db999c9e4882815c21c10e1d2181a0b0ae739e6790045`. Actual model and High setting unverified by this worker.

The chapter contains CR/real differential equivalence in both directions, product Cauchy and closed-boundary limit, Taylor coefficient uniqueness without circular differentiation, normal differentiation, identities and limits, scalar open mapping/maximal modulus, bounded separate holomorphy and a full n-dimensional unrestricted theorem. Ten exercises have worked solutions. No forward result from317/319 is a prerequisite.

Sources actually read and pinned in B01: O01 printed/PDF13–24, O02 printed2–4,8–18/PDF8–10,14–24, O04 printed23–26/PDF25–28. Strong Hartogs proof follows Boas but expands Baire slab selection and provides an n-variable induction using positive root submeans proved in the text; the polydisc Fatou argument is independently adapted. All example/solution calculations are independently expanded from definitions or these source facts. The calibrated mixed coefficient and anisotropic Liouville exercise are integrated once.

Engineering: chapter-only R1 build requested with --allow-diagnostics; result pending at initial handoff. No claim of final layout or B07 acceptance. Need independent source/semantic review, then defects handled by the assigned role. Particular review focus: Baire sets on a closed disc, recentered large-disc inclusion, uniform root bound on the base, both directions in the definitions, compact set finite covering, factorials. Cross references only internal labels at this stage. Source/PDF pairing and layout diagnostics will be appended after build. No Git/publication/Library action by this worker; controller manages durable saving.

Next: review313 while expansion writes314. Do not rewrite frozen volumes or change typography for page count. This is an expansion draft, not unique whole-volume mathematical signoff. Shared source file available; receipt remains to be acknowledged by controller/reviewer.

Build completion: `.build/chapter-313/volume25.pdf`, 15 PDF pages (14 content + 1 references). Paired PDF SHA-256 `2233deadb88535a4a963267212b6b811f74113278f6250b094e58f019a3ef966`; source hash above unchanged; two passes. One overfull hbox 2.17365pt at source369–376, technical repair pending layout role. Natural length is below18–22 target; controller notified, with proposed bounded substantive addition (quantitative remainder/Cauchy compactness/Montel) rather than changing typography. No visual acceptance claimed.
