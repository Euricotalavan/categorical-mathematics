# Ch317 expansion handoff v1

Source SHA256 `0e977802c6efd4544f3ba7840576c6ceeaf169bb1278880f9ea3c65ff3370909`. Fixed B02/B03 inputs read. Implements psh line-submean/Hessian tools; convolution and pullback; interior equivalents via directional radii; holomorphic convexity necessity; global locality; full KW9.2.1 growth/flat growth using locally finite shell pieces with explicit negative-Hessian control; C² Levi invariance via tangent curves (avoids C¹ multiplier second derivative); C² signed-distance holomorphic-curve proof of Levi criterion; exponential defining function and Narasimhan convexification with normal positivity supplied first. Ten worked exercises.

Stable downstream labels: thm:317-flat-growth, thm:317-smooth-growth, cor:317-smooth-exhaustion, thm:317-interior, prop:317-locality, thm:317-levi-criterion. Sourceguide carries printed/PDF locators. Main sources KW9.2.1 pp177–178/PDF183–184 and Demailly I7.7/7.12 pp58–60. Full independent audit pending. Build running; actual pages/engineering diagnostics pending. No final mathematical approval or public writes. Next: independent thickening/refinement; expansion continues318.

Specific audit points: shell lemma use five strictly separated sublevels, smooth convolution sees no outer cutoff on inner region; flat induction starts in N where m=μ=0; prescribed-growth version separately creates positive first core. General USC pullback uses bounded truncation then convolution/pointwise convergence and dominated disc means. Signed distance chart is C² on both sides; distance lower bound first proves h(t) is in Ω, then signed composition gives negative tangent.

## Current source checkpoint

SHA256 `ddbb6db4816d7bf31494fc05e01e525acc6dab98a87725fb80c4729f37966110`; expansion authoring frozen pending independent review. Ch316 small typing/branch/interpolation fixes incorporated. Ch317 strong-real-convex terminology and weak ellipsoid counterexample incorporated. Ch318 bounded support/peak/high-contact/scaling/polyhedron-face enrichment and review precision fixes incorporated.

## Engineering checkpoint

Fixed build has 19 PDF pages including references; paired source SHA `ddbb6db4816d7bf31494fc05e01e525acc6dab98a87725fb80c4729f37966110`; PDF SHA `ef7c896a6ac64c8ae00112819a3e142dc382055ec6fb41ccd9d3ed82d99e9509`. Diagnostics: []. Cross-chapter refs in standalone318 are expected and require whole-volume resolution; no overfull/missing-character diagnostics. This is engineering only. 317 p13 dense Levi proof rendered and visually inspected, no clipping seen; formal full-page QA not claimed.
