# V25 B-04 Ch316 expansion handoff v1

Input: B02 Book-Design.md, B03 Authoring-Contract.md and Calibration.tex read; B01 responsibility b01/convex.md fixed. Output: `v25-work/book/manuscript/ch316.tex`; SHA256 `fe66a7915b0b2ad94b1d206f9ba6c232b5c106ac90d5a36e138fe6ba68070189`.

Scope: local extension pairs and branch quantifiers; explicit plane/product/convex examples; relative holomorphic hull with disc and annulus examples; amplified separation; uniform and holomorphically varying Taylor radii; full Cartan–Thullen using KW increasing-zero-order product with dense maximal balls; biholomorphic/product/deletion operations; 9 varied exercises with worked solutions including discrete interpolation.

Sources: precise printed/PDF locators are at sourceguide and b01/convex.md. Main full CT proof KW §6.4 printed115–118/PDF121–124; local definition Lebl2.1 pp47–49; hull examples KW6.3 pp113–115/PDF119–121; interpolation Demailly I6.11 pp48–49; polynomial examples Boas pp39–40/PDF41–42. All prose independently composed. C^n exceptional case handled separately. No Levi reverse direction used.

QA requested: branch-sensitive nonextendibility of product, normal convergence/nonzero product, higher-zero orders; interpolation compact exhaustion and small-tail/exact-value split. No mathematical independent approval yet. Build running; actual pages/diagnostics to append. No public writes; no master/template changes. Next: independent thickening/refinement audit on this fixed source while expansion continues317. Scope does not restart frozen volumes.

## Current source checkpoint

SHA256 `0b4d285367a2864e2f7a2959cd2745b7f5b0ede1b287a93afe9418edd672ef87`; expansion authoring frozen pending independent review. Ch316 small typing/branch/interpolation fixes incorporated. Ch317 strong-real-convex terminology and weak ellipsoid counterexample incorporated. Ch318 bounded support/peak/high-contact/scaling/polyhedron-face enrichment and review precision fixes incorporated.
