# Ch315 B04 expansion handoff v1

ID V25-B04-315-EXP-v1 · 2026-11-28 · expansion → controller → independent thickening/refinement.

Input B02/B03 and B01 local.md SHA f2279df2a19eae8318c94a1d0cac76c42e719ff16d54c7b6d6ae16cc6405a665. Output manuscript/ch315.tex SHA-256 `3170f7236ee8f8a71aaf41679c1a5e1d22330a0f22249cb3787ff1596203606f`. Actual model/High not verified by worker.

Content: product-contour review without duplicating313's proof; explicit interleaved forms and outward-first orientation; Cauchy–Pompeiu with puncture and local integrability; direct area computation for barζ; BM kernel's wedge identity, closedness, normalization and scale invariant total variation; full Stokes representation; exterior formula; real normal boundary density; sphere/ball averages and local L2 estimate; smooth nonholomorphic boundary-transform counterexample;12 varied exercises with worked solutions.

Sources O01 printed/PDF15–17,130–132,157–160; O02 printed198–205/PDF204–211. Source interleaved/grouped orientation discrepancy is explicitly resolved: eta_k=contraction of interleaved Theta and boundary restriction eta_k=(2i)^n nu_k dσ/2. The density, counterexample derivative (n−1)/n, direct area integrals, local L2 and all worked solutions are independent derivations from established formulas. C2 domain/C1 neighborhood data chosen as safe common theorem assumptions; no unjustified rough-boundary or boundary-limit claim.

Review focus: type(n,n−1), eta_k omission of dbarζ_k only, small-ball sign, normalization constants, Cauchy–Pompeiu area sign, ∂bar acting in parameter versus dbar in integration variable, nonholomorphic example derivative and exercise11 correction derivative. No general dbar existence invoked or claimed. No full Bergman/Szego proof imported from322. Standalone chapter build in progress; expected cross-chapter references are mostly literal313/319. This is an expansion draft, not final mathematical acceptance/B07; controller manages durable storage/publication.


Review/update: independent thickening task audited complete first draft3c82607c and found no mathematical blocker, including constants, density and both transform derivatives. Applied its two explicitness fixes (planar Green scope and density parameter off boundary); final source hash above. This does not replace refinement/integration/B07. Final chapter-only build:16 PDF pages (15 content+1references), two passes, paired PDF `.build/chapter-315/volume25.pdf` SHA-256 `2bdb85489cb6d266c7af84f11e305343c280ed8c7197d7ac23d95552995e89e7`. One overfull7.6424pt in normalization proof paragraph295–299 remains for layout role. No undefined refs or missing characters. No full page visual acceptance claimed.
