# V25 B-04 Ch.324 內容交接 v1

交接 ID `V25-B04-324-GEOMETRY-v1`；2026-11-28；B 單一 Work。擴充／打厚展開副本 → 主控整合、精修獨立核。非 B-07 整卷終審；實際模型及 High runtime 未核實。

已讀B01 `geometry.md`（SHA-256 `09477a7dbc14736669a2bad18d6859ede4af82f1bee1f93179425e83b1c99d81`）、B02 `Book-Design.md`、B03 `Authoring-Contract.md`／`Calibration.tex`／`Thickness-Review.md`。主控授權B04，只改本人指定322–324來源及handoff；322／323已交主控接管，324本版至此固定。無Git／公開／Library寫入，無修改工具ZIP、巨集、分卷表或凍結卷。

## 固定來源與配對工程輸出

- `v25-work/book/manuscript/ch324.tex`：SHA-256 `0952d71d5436a0c4f02630c6dd2503eeeb87f34ce394d7f5104d35e1e2969b9b`。
- `v25-work/book/.build/chapter-324/volume25.pdf`：127,712 bytes，SHA-256 `8fd50f8dc4b50a5acdd54788a6f0ce93bf0c80fd46152933be55c1514ebde049`。
- `v25-work/book/.build/chapter-324/build-report.json`：2 passes；無overflow、missing glyph或undefined command。Standalone預期3個跨章引用未解：`prop:323-germ-algebra`、`prob:323-crossing-ideal`、`ex:323-cusp`，皆確實在Ch323有定義，待整卷編譯解決。
- 18頁含references；局部視讀工程PDF p8／p11，盒文、sheaf定義、pullback與analytic-space definition未見溢出。不是全頁視檢或B06正式排版驗收。

## 逐項源責任及正文落點

| B01責任 | 實際 label／段落 | 已展開內容／來源 |
|---|---|---|
| G324-01 | `def:324-local`、`lem:324-maximal` | 評值／唯一極大理想／座標生成／商局部環及residue完整證；O01 p180、O03 p70。 |
| G324-02 | `def:324-noetherian`、`lem:324-module`、`thm:324-noetherian`、`ex:324-not-principal` | finite-free submodule induction完整證，再以Weierstrass remainder coefficient module證R_n Noetherian；不用未證Hilbert basis。m=(z,w)非principal反證；O03 p81，O01 p181。 |
| G324-03 | 刻意不採一般UFD理論 | Ch323有限投影用Hankel/Vandermonde避免UFD/resultant。商環非domain例完整列在crossing。一般UFD不是後文暗中前提。 |
| G324-04–05 | `def:324-sheaf`、`ex:324-constant`、`def:324-stalk`及相鄰段 | restrictions、gluing、constant presheaf反例／locallyconstant sheaf、stalk相等量詞、surjective-on-stalks說清；O03 p65–69。 |
| 新補G324-05 | `ex:324-log` | holomorphic exponential是abelian-group sheaf morphism（明示不是ring map），local log series、kernel underline Z、C*上無global log；sheaf quotient及global section quotient差別完整證。自行holomorphic改寫，對照O03 II§1的quotient distinction。 |
| G324-06–07 | `def:324-structure`、`eq:324-local-quotient`及ideal／quotient段、`ex:324-lifts` | locally ambient extendable functions的sheaf及stalk quotient；I_X stalk；subspace restriction／stalk surjection／section kernel明示；不假設global lift。O03 p99及p67–69。 |
| G324-08 | `ex:324-graph`、`ex:324-crossing`、`eq:324-fiber-product`、`ex:324-cusp-ring` | smoothgraph degree1 division；node pair ring及kernelzw；cusp division余式even/odd證vanishing ideal，皆不用general Nullstellensatz。來源概念O01 p184–186、195／O03 p99，計算獨立展開。 |
| G324-09 | `prop:324-cusp-bijection`、`eq:324-cusp-image` | continuous inverse t=w/z不在structure ring（linear term obstruction），holomorphic bijection≠isomorphism。 |
| 新補G324-09 | `ex:324-cusp-integral` | fractionfield相同；所有C{t}由even/odd拆分滿足monic quadratic；integral meromorphic germ不能有pole，故精確integral closure=C{t}，自證單例而非general normalization theorem。 |
| 解析幾何辨識 | `def:324-cotangent`及後段 | m/m²、ambient quotient線性Taylor項、m² iff無constant/linear term完整證；graph 1維、node/cusp 2維，smooth obstruction。 |
| G324-10 | `def:324-morphism`、`eq:324-pullback`及composition段 | local ambient map定義、代表元良定、local stalkhom、contravariant composition、general ringedspace sections map source/target明示；O03 p70–71、101–102。 |
| G324-11–12 | `def:324-space`、`ex:324-double-point` | reduced convention，Hausdorff/secondcountable、local analytic subset models；dual number units／nilpotent／reduction完整算。O03 p102及122–123。 |
| G324-13–14 | `def:324-coherence`、`ex:324-relations`、finite presentation段 | locallyfinite「同一鄰域每個stalk」量詞；relations of(z,w)=(−w,z)整個附近全證；general Oka／idealcoherence明列V158接口，不冒稱本卷已證。O03 p86–90、99–105。 |
| G324-15–16 | 章末接口段，10個`problem`各接`psolution` | ringquotient basis、sheaf gluing、nodevalues、cuspdescent、pullback kernel、doublepointmaps、cotangent、annihilator、exactpresentation、stalkidentity，皆完整解。 |

## 獨立核證與修補

`/root/thickness` 對82f77a50初稿全章核讀，確認Noetherian induction、crossing/cusp rings、sheaf/stalk、reduced/nonreduced、relations無核心數學block。建議已採：m²精確線性Taylor說明；一般F# source/target；structure quotient的subspace/stalk解釋；cotangent題明說smooth curve；positive power措辭。

對ee21b072增補版，該獨立任務再核cusp integral closure的fractionfield／pole-order全證及exponential local/global例，確認正確；最後tiny typing已採：underline Z在quotient前定義、ambient m_Cn/m_Cn²明示。這些局部修補後的來源／工程配對為上列0952版。未把章級review稱整卷終審。

## OPEN／UNKNOWN與下一步

唯一工程OPEN是3個standalone跨章引用，整卷應解析，不應刪去必要數學依賴。本章不依賴general Nullstellensatz、Oka coherence、normalization existence、Remmert或sheaf cohomology；一般結果明列V158繼續，具體cusp normal closure本卷全證。精修須在主控唯一正文再核實這些界線及實際覆蓋，不只信標籤。

下一步：主控核0952基線、配對PDF和独立回執，再合入唯一主稿；B05整卷順讀後才B06 ReadFlow R1排版／全頁視檢，唯一B07打厚終審及修後複核仍必需。禁止重啟凍結工作、改章號、拿hash／頁數當數學驗收或公開推Git。外部保存續由主控依既授權位置辦理；本角色本次只保存可恢復工作檔。
