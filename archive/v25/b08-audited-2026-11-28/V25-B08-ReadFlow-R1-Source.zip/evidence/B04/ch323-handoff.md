# V25 B-04 Ch.323 內容交接 v1

交接 ID `V25-B04-323-GEOMETRY-v1`；2026-11-28；B 單一 Work；擴充／打厚展開副本 → 主控、精修獨立語意核。非B-07整卷簽核。實際模型／High runtime 未核實。輸入為B01 geometry源表、B02全卷設計及B03固定authoring contract／calibration；章號323依V24末章312續接。

## 可合入基線與接管

可改來源 `v25-work/book/manuscript/ch323.tex`；本角色完成之穩定SHA-256 `a772fbb26e865161daa4b063a8fe67fd7e076c41202cd86d429af20a6c1835b0`。此版之後主控接管，預備合入一參數monic quadratic的normal form、discriminant order、sheets/monodromy／branch幾何；本角色不再修改323。

獨立工程PDF在修小措辭前的來源hash `6211a872f48c32d0cf73a5e6888716dc120842e5168dc66bd7703f13bea21635` 已2 passes、zero diagnostics，PDF 115,037 bytes、SHA-256 `9724427b508e4980198bbbd34152243eadda0175e119e77fb220141100aad19a`，16頁含references。小改後重編由主控接管並可能同時加入新段，因此必由主控為最新固定稿再配對；此舊PDF不能冒充a772或enrichment新版。

## 本章實際逐項落點

| 源責任 | 穩定label／正文 | 原文頁與補足責任 |
|---|---|---|
| G323-01–02 | `def:323-germ`、`prop:323-germ-algebra` | O01 p167–168；O02印72/PDF78。等價關係、和積良定性、Taylor germs、domain、units、unique maximal逐一證，不延後到324先用後定。 |
| G323-03 | `def:323-order`、`lem:323-direction`、`ex:323-direction` | O01 p169、174；O02印66/PDF72。lowest homogeneous term選v／invertible A完整證，兩明算shears。 |
| G323-04–06 | `def:323-weierstrass`、`thm:323-preparation`、`ex:323-roots`、`ex:323-unit` | O01 p169–174；O02印69–71/PDF75–77；O03 p79–80。fixed contour與root count、Newton recursion、joint unit+inverse、germ uniqueness全證；不假設root labeling continuous。 |
| G323-07–08 | `thm:323-division`、`ex:323-division`、`ex:323-exponential` | O01 p175–176、O02印71/PDF77、O03 p80–81。contour q、difference quotient degree、multiplicity uniqueness；e^w remainder包含quotient normal convergence核。 |
| G323-11–12 | `def:323-analytic-set`、`ex:323-ideal`及相鄰vanishing ideal段 | O01 p182–184、O03 p91。finite local equations、ambient closure、unions/intersections、germs、radical與equations≠vanishing ideal。 |
| G323-09–10 | `prop:323-projection`、`ex:323-discriminants` | O01 §6.3、O02印75–76/PDF81–82，獨立power-sum Hankel determinantΔ=Vandermonde²證明，明假設Δ非零才dense simple-sheet；proper無條件證。免用未證UFD/resultants。 |
| G323-13–14 | `def:323-regular`、`ex:323-smooth`、`ex:323-crossing`、`ex:323-cusp` | O01 p185–186、190、195；O03 p98–99。graph/submanifold定義、dimension chart invariance、crossing tangent contradiction、cusp order2q=3r contradiction，三模型全核。 |
| G323-15 | `prob:323-prime`＋完整解 | O01 Ex6.7.1、O03 p91–92：nonempty irreducible germ iff proper prime vanishing ideal，兩方向全證。一般finite decomposition不在必需正文暗用。 |
| G323-16 | regular／singular段末之V158接口 | 一般density、dimension、analytic singular locus明說留V158，不借O01略證冒充本卷已全證；local projection僅在其明示假設使用。 |
| G323-17 | 10個`problem`各接`psolution` | units、prep product、coordinate change、division、multiplicity、Δ、bad gradient、node ideal、prime、local/global branch；均含實算或證明。 |

## 已核與修補

獨立打厚 `/root/thickness` 對6211a872版完整審讀，確認fixed-contour/Newton、division counting multiplicity、Hankel/Vandermonde discriminant、properness/density與三模型證明。其必要typing建議已落入a772：base是connected polydisc、P於V'×closed D鄰域全純、properness先於Δ非零條件、multiplicity counterexample註k≥2。沒有其他未回修數學blocker留給本角色。

## OPEN與下一步

主控quadratic enrichment未在本角色基線內；需要新固定hash、獨立核與PDF配對。正式排版、全頁視檢、全卷B05/B07尚未做；B01源表只作source responsibility，實際落點如上，不等於全卷驗收。ReadFlow R1安全巨集沿主控配置，未改模板。語意通過／hash／PDF工程分列。

接收方須回執實際使用的基線、root enrichment版本與來源配對；基線變更不得盲套舊補丁。下一步為精修核最新固定整章及主控整卷整合，禁止重做凍結卷、重排章號、把general algebra/geometry移入本卷而未補先備、公開／推Git。本任務未作外部保存，交主控既授權續存。
