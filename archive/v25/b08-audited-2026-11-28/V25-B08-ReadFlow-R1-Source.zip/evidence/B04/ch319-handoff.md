# V25 B-04 Ch319 expansion handoff

ID: V25-B04-CH319-v1 · 2026-11-28 · B single Work · expansion → controller / independent refinement.

## Fixed source

Canonical source: `v25-work/book/manuscript/ch319.tex`

SHA-256: `e4e77b193cb9b60dee0c807413561c97da46c0cb89d3eff4fa1f210e24fa0129`

Title: Formulating the d-bar equation. Inputs: `b01/dbar.md`, `b02/Book-Design.md`, `b03/Authoring-Contract.md` and `Calibration.tex`; four approved pinned public PDFs only. No R01–R03 uninspected full-text claims. Fixed previous volume commit remains `20e626496c24518f133af6eb892c620ea52a3c59`; chapter number is not reset.

## Coverage, sources and inspected evidence

D319-01–10; all planned q=1 core responsibilities covered. Added explicit nonexact closed form on C²\{0}, its S³ period, a boundary jump distribution, and 11 complete exercise solutions. General higher-degree local solvability is intentionally not claimed.

Lebl §§4.1–4.4, printed/PDF130–145; KW §§11.1–11.2, printed216–220/PDF222–226; Boas printed75–77/PDF77–79; Demailly363–369.

Weak equation and local smooth primitive precede weak holomorphy; compact solver uses n≥2 only to kill its tail. Cauchy transform sign is +1/π times1/(z−ζ). Nonexact-form period computed directly as4π² with outward orientation.

Dependencies and downstream impact: Ch315 Stokes and Cauchy–Pompeiu conventions; Ch320 imports thm:319-local, thm:319-weyl, cor:319-regularity, thm:319-compact, lem:319-mean.

## Review, build and limitations

Thickness independently inspected main proofs and later substantive additions in separate task. All returned corrections were applied. This is chapter-level B04 evidence, not B07 whole-volume approval. Root is the serial integrator; source has been delivered in the shared workspace. Actual model/mode evidence remains controller-owned; this file does not treat a role name as model verification.

17 chapter pages +1 references; slightly below the suggested18–22 chapter-page range. No padding or type changes.

Build command: `python v25-work/book/tools/build.py --chapter 319 --allow-diagnostics`. Artifact paths: `v25-work/book/.build/chapter-319/volume25.pdf` and `build-report.json`. Chapter builds deliberately report unresolved references to other chapters; final resolution requires whole-volume build. Source/PDF hash below must match final report. No formal B06 page-by-page QA or B07 strict whole-volume pass is asserted.

OPEN: independent B05 refinement and chapter-seam checks; full-build references and source/PDF pairing; formal layout/visual QA and whole-volume strict review. UNKNOWN: any claims beyond selected theorem versions (higher-form estimates, arbitrary singular weights, boundary regularity); not inferred from tools completing.

Next: receiver records actual read/hash receipt; B05 fixed-volume refinement, B06 layout, B07 thickness-only full audit. Return semantic changes to responsible content role. Do not redo frozen volumes, change tool ZIP/source tables, publish Git, or archive as approved without the later required authority.

Final engineering pair: source `e4e77b193cb9b60dee0c807413561c97da46c0cb89d3eff4fa1f210e24fa0129`; PDF `a1a1b2a36991c314775194e470f83d308564f5fd605543c7b39e5dd32587fc19`; 17 chapter pages +1 references; 2 converged passes. Non-reference diagnostics: 0. External chapter reference diagnostics are retained for full-volume resolution.
