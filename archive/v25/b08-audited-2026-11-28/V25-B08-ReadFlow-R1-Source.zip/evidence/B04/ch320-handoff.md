# V25 B-04 Ch320 expansion handoff

ID: V25-B04-CH320-v1 · 2026-11-28 · B single Work · expansion → controller / independent refinement.

## Fixed source

Canonical source: `v25-work/book/manuscript/ch320.tex`

SHA-256: `0c021da23dcfa434d0c52eb1a1f2030ad5ee3f1b1b5b1ef57c68bd825c68b17e`

Title: Weighted solutions and estimates. Inputs: `b01/dbar.md`, `b02/Book-Design.md`, `b03/Authoring-Contract.md` and `Calibration.tex`; four approved pinned public PDFs only. No R01–R03 uninspected full-text claims. Fixed previous volume commit remains `20e626496c24518f133af6eb892c620ea52a3c59`; chapter number is not reset.

## Coverage, sources and inspected evidence

L320-01–14 covered to the deliberately selected scope; 10 complete exercises. Complete modified-weight projection, separate boundary/infinity cutoff derivative bounds, conditional graph-core lemma, local weak limit, point/jet penalty and minimum-norm operator.

KW §§11.3–11.6 printed220–230/PDF226–236; growth theorem printed177–178/PDF183–184; exhaustion/weak limits §11.7 printed231–232/PDF237–238; Boas75–79/PDF77–81; Demailly363–365,376–379.

Main thm:320-weighted: Ω psh exhaustible, β smooth strictly psh, f distributionally closed (0,1), finite ∫|f|²e^{−β}/b; constant exactly1 with b=min Hessian eigenvalue. No boundary regularity. Conditional graph approximation requires additional e^{σ} integrability; never asserts unrestricted compact-core. Gaussian examples attain1/a. lemma:320-log-penalty uses smooth regularization and full local weak/monotone passage; for exponentc≥n forces u(a)=0.

Dependencies and downstream impact: Requires thm:317-smooth-growth, thm:317-flat-growth, cor:317-smooth-exhaustion, and Ch319 weak regularity. Exports thm:320-weighted, lemma:320-log-penalty and prob:320-log-order to321.

## Review, build and limitations

Thickness independently inspected main proofs and later substantive additions in separate task. All returned corrections were applied. This is chapter-level B04 evidence, not B07 whole-volume approval. Root is the serial integrator; source has been delivered in the shared workspace. Actual model/mode evidence remains controller-owned; this file does not treat a role name as model verification.

18 chapter pages +1 references; within suggested range.

Build command: `python v25-work/book/tools/build.py --chapter 320 --allow-diagnostics`. Artifact paths: `v25-work/book/.build/chapter-320/volume25.pdf` and `build-report.json`. Chapter builds deliberately report unresolved references to other chapters; final resolution requires whole-volume build. Source/PDF hash below must match final report. No formal B06 page-by-page QA or B07 strict whole-volume pass is asserted.

OPEN: independent B05 refinement and chapter-seam checks; full-build references and source/PDF pairing; formal layout/visual QA and whole-volume strict review. UNKNOWN: any claims beyond selected theorem versions (higher-form estimates, arbitrary singular weights, boundary regularity); not inferred from tools completing.

Next: receiver records actual read/hash receipt; B05 fixed-volume refinement, B06 layout, B07 thickness-only full audit. Return semantic changes to responsible content role. Do not redo frozen volumes, change tool ZIP/source tables, publish Git, or archive as approved without the later required authority.

Final engineering pair: source `0c021da23dcfa434d0c52eb1a1f2030ad5ee3f1b1b5b1ef57c68bd825c68b17e`; PDF `217dd06bcca575b1b97f52a6c4b0da9ae4a4addc87776e93cc699c1ecef240a7`; 18 chapter pages +1 references; 2 converged passes. Non-reference diagnostics: 0. External chapter reference diagnostics are retained for full-volume resolution.
