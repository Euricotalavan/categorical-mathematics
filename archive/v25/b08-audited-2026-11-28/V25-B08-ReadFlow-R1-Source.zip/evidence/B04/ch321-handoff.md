# V25 B-04 Ch321 expansion handoff

ID: V25-B04-CH321-v1 · 2026-11-28 · B single Work · expansion → controller / independent refinement.

## Fixed source

Canonical source: `v25-work/book/manuscript/ch321.tex`

SHA-256: `f8eab64484c31c42c073ee7bc7b70449f6958a7b38e1bfffb2bb00d521cddb13`

Title: Extension and approximation. Inputs: `b01/dbar.md`, `b02/Book-Design.md`, `b03/Authoring-Contract.md` and `Calibration.tex`; four approved pinned public PDFs only. No R01–R03 uninspected full-text claims. Fixed previous volume commit remains `20e626496c24518f133af6eb892c620ea52a3c59`; chapter number is not reset.

## Coverage, sources and inspected evidence

A321-01–06 and coordinated Levi sufficiency covered; 10 expansion exercises plus2 independently authored Levi exercises, all complete solutions. Compact-hole theorem, explicit scalar zero-set consequence, bounded exterior maps, finite-separator relative approximation, polynomial Oka–Weil, Runge sufficient condition and independently inserted Levi proof.

Lebl §4.3 printed/PDF135–136; Boas Thm19 printed72–74/PDF74–76 and Thm10 printed44/PDF46. Finite-separator weighted proof is an independent synthesis from316 and320, rather than Boas’s original polyhedron/extra-variable proof. Levi supplement source responsibility remains levi321-handoff.md.

Hartogs assumes n≥2 and connected Ω\K; agreement on a nonempty outer open set then identity theorem, no false assertion that correction is supported inΩ. Relative theorem assumes Ω pseudoconvex and K O(Ω)-convex; ψ≤1 nearK, ψ≥2 on error support, β=tψ+|z|² has Hessian≥I; weighted error≤C0e^{−2t}, final sup error≤C1e^{−t/2}. Empty transition case handled. Levi has logarithmic point penalty from320 and uses Cartan–Thullen in316, without using relative approximation in its proof.

Dependencies and downstream impact: Imports lem:316-finite-separators, Ch316 Cartan–Thullen, Ch317 smooth exhaustion, thm:319-compact, thm:320-weighted, lemma:320-log-penalty. Exports no-isolated-scalar-zero interface to323; general analytic-space theory remains324/V158.

## Review, build and limitations

Thickness independently inspected main proofs and later substantive additions in separate task. All returned corrections were applied. This is chapter-level B04 evidence, not B07 whole-volume approval. Root is the serial integrator; source has been delivered in the shared workspace. Actual model/mode evidence remains controller-owned; this file does not treat a role name as model verification.

Final chapter build is recorded below; page target is descriptive and not an acceptance criterion.

Build command: `python v25-work/book/tools/build.py --chapter 321 --allow-diagnostics`. Artifact paths: `v25-work/book/.build/chapter-321/volume25.pdf` and `build-report.json`. Chapter builds deliberately report unresolved references to other chapters; final resolution requires whole-volume build. Source/PDF hash below must match final report. No formal B06 page-by-page QA or B07 strict whole-volume pass is asserted.

OPEN: independent B05 refinement and chapter-seam checks; full-build references and source/PDF pairing; formal layout/visual QA and whole-volume strict review. UNKNOWN: any claims beyond selected theorem versions (higher-form estimates, arbitrary singular weights, boundary regularity); not inferred from tools completing.

Next: receiver records actual read/hash receipt; B05 fixed-volume refinement, B06 layout, B07 thickness-only full audit. Return semantic changes to responsible content role. Do not redo frozen volumes, change tool ZIP/source tables, publish Git, or archive as approved without the later required authority.

Final engineering pair: source `f8eab64484c31c42c073ee7bc7b70449f6958a7b38e1bfffb2bb00d521cddb13`; PDF `3547ae632a70c238cc8ad84d01e708616c688595874901cf8c933841a4a6ca63`; 17 chapter pages +1 references; 2 converged passes. Non-reference diagnostics: 0. External chapter reference diagnostics are retained for full-volume resolution.
