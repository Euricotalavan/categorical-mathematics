# V25 B-04 authoring handoff

Write each chapter in v25-work/book/manuscript/chNNN.tex. Include its \chapter{...} and \label{ch:NNN}. Add stable chapter-specific statement and equation labels. Existing environments include definition, theorem, proposition, lemma, corollary, example, remark, proof, problem and psolution. \ProofStep{...} can separate proof milestones. Invokable commands include \CC, \RR, \NN, \OO, \dbar, \dd, \supp, \dist, \RePart, \ImPart, \Vol and \sourceguide. Reserve \C for the template. Bibliography keys are Lebl, KW, Demailly and Boas.

Write direct English. State the motivating goal and introduce objects before use. Every key technique should have a worked case. Include counterexamples when needed to test a hypothesis. Use align or multline for long calculations within the 136 mm width and keep steps readable.

Aim for four to six substantial sections per chapter and around eight to twelve varied exercises with worked solutions when the topic supports it. Favor rigorous and pedagogically necessary material. Avoid duplicated proofs, forced page breaks and typography changes for page targets.

Record source responsibility and review notes for each chapter in v25-work/b04/chNNN-handoff.md. Use printed/PDF locators or identify independent derivations. Mention unresolved points and downstream effects. Notify the controller as each chapter is ready so independent review can begin. Only edit your chapter files and corresponding handoffs.
