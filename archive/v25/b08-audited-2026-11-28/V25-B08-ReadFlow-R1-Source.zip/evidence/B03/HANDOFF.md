# V25 B-01 through B-03

V25-B03-CALIBRATION-v1 · 2026-11-28, Taipei · B workflow, single Work.

The owner approved using four public author sources and running B-01 through B-08. The controller performs the checkpoints formerly assigned to the owner. This checkpoint records a reviewed calibration and the chapter assignments for B-04. The official template is ReadFlow R1. The independent B-07 whole-volume review follows B-06.

## Frozen references and bounds

V24 ends at chapter 312 at Git commit 20e626496c24518f133af6eb892c620ea52a3c59. V25 takes chapters 313–324 from the v4 curriculum without moving general coherent-sheaf and analytic-space theory from V158. Check the source definitions and version-specific locators in the B-01 records. The literature baseline is V25-Literature-Review-v1.zip version 0, 8,506,101 bytes, SHA-256 7254f01617d2f79356bf84fc84450a95a78820ec9a158ba7f4671dc24033c258.

- Literature baseline
- [V24 chapter-number baseline](https://github.com/Euricotalavan/categorical-mathematics/blob/20e626496c24518f133af6eb892c620ea52a3c59/archive/v24/b08-audited-2026-11-28/README.md)

## B-01 and B-02

Each original PDF in the approved set was checked against its hash and passed through math-extractor v0.4. The tool produced 885, 797, 850 and 274 candidates from Lebl, Korevaar–Wiegerinck, Demailly and Boas, respectively. These are machine candidates. The source-responsibility records distinguish entries actually located and read, proof obligations, hypotheses, limitations and out-of-scope developments. Source texts and extracted long windows are recovered through the literature baseline.

The four chapter groups have assigned sources and prerequisites in Book-Design.md. The planned analytic spine is a weighted L² solution built on justified graph approximation. The boundary-distance and outer-radius cutoff terms are controlled independently. The Cartan–Thullen criterion is used with its quantified extension-pair definition. General sufficiency of pseudoconvexity follows the weighted theorem.

## B-03 verification

Calibration.tex is the approved representative section, with its compiled Calibration.pdf. The proof uses iterated Cauchy integrals on a product of circles, an explicit absolute uniform bound, and uniqueness on smaller tori. The first independent scan found that uniqueness was needed before moving radii in the exercise. The controller added its proof and clarified the boundary and iteration language. The amended PDF compiled in two passes without unresolved references, missing glyphs, or overfull blocks. All four sample pages were rendered and viewed. The short continuation on sample page 3 results from ending the isolated sample while the solution continues, so this is a cue to check solution splits in the full chapter, not a model for a forced break.

Three unmodified style files are from the adopted ReadFlow R1 source, version 3, 7,007,679 bytes, SHA-256 5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732, artifact commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3. Matching font dependencies came from the fixed V24 public source ZIP (SHA-256 4e1087ff01dcaac0689f403b41416945a32dfd00c7edb96f0ae64af0ff7414ca). The V25 build adapter changes chapter numbering, entry, metadata and notational aliases only.

## B-04 continuation and receipts

Expansion was dispatched by chapter groups 313–315, 316–318, 319–321 and 322–324. GPT-6.1 Sol High was requested for expansion and page layout. The agents report no independent model introspection. The independent thickness reviewer and technical layout agent returned real task receipts.

Next, each group submits a LaTeX chapter with its evidence. The controller records the fixed input hash and onset of review, then requests thickening/repairs and source-sensitive exactness review before accepting it into the one main manuscript. Directly and transitively affected downstream statements are rechecked whenever hypotheses or dependencies change. The specific weighted estimate and full-volume proof acceptance remain open until their actual manuscript and precise hypotheses have been checked.

No specimen chapter extends the published chapter numbering beyond the twelve fixed chapters. The book needs a complete mathematical and visual review before B-08. Preserve the exact calibration source, B-01 receipts and template hashes. Use only the approved public sources for manuscript derivation.
