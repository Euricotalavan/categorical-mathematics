# V25 Several Complex Variables

Chapters 313–324 continue the V24 edition at commit 20e626496c24518f133af6eb892c620ea52a3c59. The titles follow the curriculum outline. The sources are the four approved public texts pinned in the literature packet and B-01.

The guiding question is deciding when holomorphic functions have to extend and constructing ones that do not. Local techniques (313–315) lead to geometric tests (316–318), a weighted existence proof (319–321), worked models and analytic sets (322–324).

| Chapter | Prerequisites within the volume | Developments and proof goals | Examples and practice |
|---:|---|---|---|
| 313. Holomorphic functions and power series | One-variable Cauchy theorem, real differentiation | Coordinates, Wirtinger derivatives, analytic and CR characterizations, product Cauchy formula, Taylor series and normal convergence, identity and compact convergence. Separate holomorphy with explicit hypotheses. | Distinguish real and complex differentiability, coefficient calculations, convergence domains, local limits. |
| 314. Hartogs phenomena | 313, Laurent coefficients | Figure and shell by direct arguments, uniqueness on overlaps. General compact-hole proof follows in 321. | Slice coefficients, extension on figures, one-dimensional failure, hypersurface obstructions. |
| 315. Integral formulas in several variables | 313, Cauchy–Pompeiu, Stokes with fixed orientation | Product formula, form conventions, Bochner–Martinelli kernel and proof on punctured domains. | Normalize constants, compare contours, distinguish representation and extension. |
| 316. Domains of holomorphy | 313–314, Baire if recalled | Extension pairs, holomorphic hull, distance and Taylor continuation, Cartan–Thullen and nowhere extendibility. | Half-spaces, polydiscs, Hartogs holes and hull computations. |
| 317. Pseudoconvexity and the Levi form | 313, 316, real Hessians | Line-submean definition, complex Hessian, tangential Levi form and its transformation, boundary tests, smooth strictly psh exhaustion. Prove necessity here and sufficiency after estimates. | Defining-function changes, strong versus weak Levi behavior, smoothing. |
| 318. Model domains and boundaries | 313, 316–317 | Ball, polydisc and Reinhardt geometry, complete versus logarithmically convex sets, smooth faces and corners, defining functions and supporting maps. | Ellipsoids, model power domains, exposed points, radial tests. |
| 319. Formulating the d-bar equation | 313–315, test functions and Hilbert spaces | Type decomposition, weak differentiation and compatibility, Cauchy-transform solver, compact support, distributional holomorphy and graph domains. | Closed data, explicit solutions, weak tests, compact support and dimension. |
| 320. Weighted solutions and estimates | 317, 319, Riesz representation | Weighted L² route through a priori inequality, graph approximation with loss of weight, dual existence, removal of auxiliary weights and exhaustion. | Quadratic weights and constants, role of closed data, minimum-norm solution. |
| 321. Extension and approximation | 314, 316–317, 319–320 | Compact-hole Hartogs via cutoff, relative approximation via finite holomorphic separators, Oka–Weil via polynomials, Levi sufficiency via a logarithmic penalty. | Hulls, cutoff placement, error conversion by a local mean-value bound. |
| 322. A complete model-domain application | 313, 318, Hilbert spaces | Ball and polydisc Bergman kernels and Jacobian covariance, geometry of inequivalence and a complete proof. | Monomial integrals, reproducing computation, diagonal kernel growth, lower-dimensional checks. |
| 323. Interface with analytic sets | 313, 314 | Weierstrass preparation and division, analytic sets and submanifold regular points, local projection. | A crossing, cusp and graph, repeated roots and coordinate choices. |
| 324. Prerequisites for analytic spaces | 323, basic rings recalled | Sheaves, restrictions and stalks, local rings and residue fields, reduced structure sheaf and analytic spaces interface. | Cusp and crossing functions, quotients by vanishing ideals, gluing and a nonreduced comparison. |

## Notation and boundaries

Use real Lebesgue measure \(dV=dx_1\,dy_1\cdots dx_n\,dy_n\), \(z_j=x_j+iy_j\), open polydiscs \(P(a,r)\), the unit ball \(B^n\), and the unit polydisc \(\mathbb D^n\). A domain is nonempty, connected and open. \(\mathcal O(U)\) denotes holomorphic functions on \(U\). Inner products are linear in their first variable. Distinguish the full complex Hessian from its restriction to the complex tangent space.

Recall differential forms, test functions and weak derivatives where used. Use an explicit model before abstract definitions of a stalk or analytic space. The general coherent-sheaf theory and nonreduced geometry remain with V158. Higher-degree boundary regularity and the various integral solution methods beyond the selected treatment need their own hypotheses and are outside this book. Public sources support a single weighted L² proof with clear assumptions.

## Length

The main comparators are Lebl's 248 pages and Korevaar–Wiegerinck's 274. Demailly's 455 pages encompass more geometry, and Boas's 81 pages provide a companion. Aim near 235–280 natural pages, concentrating depth in proof dependencies, calculations and worked exercises. Maintain fixed ReadFlow R1 typography and natural page breaks. Record actual length and any disparity at delivery.

