# V25 B06 回修後實際視檢｜159至末頁責任範圍

回執 ID：`V25-B06-REPAIR-VISUAL-159-END-v1`；2026-11-28。

**判定：本次地圖指定範圍的12頁全部實際視檢通過。未發現文字／公式裁切、字型缺字方框、證明或例題遺失、續框錯接、頁腳碰撞。** 另實看範圍兩端相鄰197、210頁，接續正常。本件是B06版面回修複檢，不是B07數學簽核。

## 最終版本核對

| 項目 | 核對結果 |
|---|---|
| Ready標記 | `v25-work/qa/B07-Revision-Ready.json`，SHA-256 `18852c22256c708c59dbfd094d59ace13228bd5bf9f0565cb8e4aa19e48a9802` |
| 最終PDF | `v25-work/qa/b07-final/volume25.pdf`，953,359 bytes，212實體頁 |
| PDF SHA-256 | `78001ce0336b5520060fd886c92d688d82b80d269a9672e44c2ec7b5f6ef9147` |
| 最終視檢地圖 | `v25-work/qa/B06-Repair-Visual-Map.json`，SHA-256 `c27053451e46ebc060d2a2af46a99c76f89f0907c9f990faec702729c399962c` |
| 一致性 | Ready的sha256、map的revised_sha256及實讀PDF重新計算的SHA完全相同。核讀結尾再算一次，仍相同。沒有使用暫定PDF。 |
| 本人責任頁 | 將map的`changed_pages_requiring_visual_review`限制至159–212，恰為198、199、200、201、202、203、204、205、206、207、208、209。 |
| 其他頁 | 159–197及210–212列在map的144-dpi逐頁相同清單；沒有把它們一律冒稱本輪重新實看。197、210為本輪額外兩端接續核頁，確有實看。 |

## 方法與實際逐頁回執

由上述固定PDF用Poppler逐頁產生PNG（全頁長邊1500px），每頁個別開圖實看，未以文字抽取、編譯成功或像素相同表代替視檢。檢查正文左右邊界、上下標／希臘字母／花體及黑板字、公式／式號、證明與QED、定義與續框、標題、頁首與頁腳、跨頁句子接續。

圖片為本輪暫存核讀證據，位於`/tmp/v25-b06-repair-159-end/`；下表記其hash以辨認實際查看的render，不把PNG本身當正式PDF或永久保存副本。

| PDF實體頁 | 印刷頁 | 判定 | 實看重點 | 本輪PNG SHA-256 |
|---:|---:|---|---|---|
| 198 | 192 | 通過 | §324.2、smooth graph及crossing起段；修補ambient rho映射／目標兩函數環與kernel文字清楚。Example 324.8末句跨至次頁，未被裁切。 | `9299889069920178cec4cee10c7d739697edd161196a7cb8cd0518fe147a46c1` |
| 199 | 193 | 通過 | Example 324.8 continued接上「isomorphism」，quotient map zero kernel可見；cusp remainder、even/odd式及式(324.3)完整，右邊式號未撞文。 | `01d15010a89e8853b8a662916d5b210285c3ffeeca7a58040ed7e78261192daa` |
| 200 | 194 | 通過 | Proposition 324.10、證明及QED均分明；integral-element例的二次式及monic equation未溢寬，末句正常續下頁。 | `a43e9bdd87520f190b866864fbbb5aa5f6b249f86945100b39bed105ae0e0e51` |
| 201 | 195 | 通過 | Example 324.11 continued接完fraction field句；cotangent定義框與m/m²公式清楚，§324.3及起段同頁，無孤立標題。 | `e2541145e1fc537e344878863fb1b30459a1428788abc66c2996831f3b2ff115` |
| 202 | 196 | 通過 | Presheaf/sheaf整框、restriction composition式、constant presheaf例、stalk框完整；底部sheaf morphism段至次頁接續正常。 | `f6c9a760169473cd6a41e92627fbaa157450c45d490672037b478892b241bdb8` |
| 203 | 197 | 通過 | 接續stalk-surjectivity句；exponential sheaf例、log series、underlined integer sheaf與導數式可辨，框邊及頁腳分離。 | `174ccba987b593ac2185a70e2254b18c936d6bcd9ab2106ee7eb90b0bdfbcbae` |
| 204 | 198 | 通過 | Example 324.16 continued、§324.4及structure-sheaf定義框完整；ideal sheaf、quotient式及subspace段未裁切。 | `b50d117735dcaffc293ee19028d367f98a8c873c9e48f0b9ad3a1214c1bd606e` |
| 205 | 199 | 通過 | 接續global ambient lift說明；maps定義框、pullback式(324.4)、composition方向式及其證明文字正常，無字型缺框。 | `e5f6b509d573100810b96587a227da18ab98cccd6d48f9edc43d5948a449ff22` |
| 206 | 200 | 通過 | Reduced space定義框、dual-number例及乘法式清楚；general ringed-space source/target箭頭可見，頁末句正常續207。 | `2d8fa35e0b0d09723831a2f6300211e316c24bfbf2d50340b2492bf237025c1e` |
| 207 | 201 | 通過 | 頁首接完point-valued functions句；§324.5、relations核公式、coherence定義及relations例起段正常，continued跨框有足夠邊距。 | `517fc7a699542d1649c09ea8c17aba23357c550f8dc1db69e6999fc60c433245` |
| 208 | 202 | 通過 | Example 324.23 continued、finite presentation式、V158接口段與§324.6起題均可讀；第一題solution頁末為max-，次頁續imal，無漏文。 | `1652bc61b520a59c1a04a15bf332ca8fb2b8ddc61c0fa0ee8ed6f4f8aeabd7db` |
| 209 | 203 | 通過 | 頁首imal ideal接208斷詞；Exercise 324.2–324.5及其solutions、QED均完整，頁腳203不碰正文；324.5題目於底部結束，解在210。 | `e654a4f6887eff3b887a0f04b4c73d31ae1b76c3b5d0b75731e01e10612f8009` |

## 兩端與上下接續

- 額外實看PDF197（印191）：Noetherian證明完整收尾，Example324.6在頁末完整結束；198起新§324.2，無前文遺失。
- 198→199：修補段落「Thus rho induces the」接「isomorphism in (324.2)…」，ReadFlow續框標為Example324.8 (continued)，ambient kernel及quotient zero kernel兩句均完整可見。
- 200→201：Example324.11末尾「common fraction」接「field」，continued標題正確。
- 202→203：sheaf morphism段的stalk maps句接上surjective定義，無段落重覆或漏接。
- 203→204：logarithm例先收反證，再continued完成local lifts／quotient段；續框不與新§324.4碰撞。
- 206→207：point-valued functions跨頁接完再進§324.5，無孤立公式或標題。
- 207→208：relation例「Taylor expansion in z, or」接「division by z…」，續框及證明文字可讀。
- 208→209：第一題解答`max-`接`imal ideal`，正常英語跨頁斷字；QED位於209並未丟失。
- 額外實看PDF210（印204）：承接209底部Exercise324.5的Solution，local pullback型別／kernel([w])可辨；同頁後續double-point、cotangent及annihilator解也完整。無需修改。

## 範圍與交接限制

本輪沒有修改正文、模板、PDF、`qa/b07-fixed`或最終map；唯一正式輸出為本回執。未重編，未公開／推Git。PDF hash／版面視檢與數學語意通過分列；本回執不可替代獨立B07整卷回修複核，亦不擴張至本輪未指定的頁面或其他卷。

下一步由主控將本回執與其他頁段B06回執合併，對同一`78001ce0336b5520060fd886c92d688d82b80d269a9672e44c2ec7b5f6ef9147`最終PDF及來源清單完成版本核對，再依既授權流程處理B07／B08。
