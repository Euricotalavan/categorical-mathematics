# V25 B-06 行文排版與全頁視檢交接

交接 ID：V25-B06-LAYOUT-v1。日期：2026-11-28。發出：V25 排版角色；接收：主控及唯一打厚 B-07 終審角色。同一 Work，對話 URL UNKNOWN。

**B-06 排版放行，可交 B-07。** 固定來源為 `v25-work/book`；固定 PDF 為 `book/.build/b06-units/volume25.pdf`，212 實體頁，950,608 bytes，SHA-256：

`3f24323b9e1b1a1366789714ae73d59be3e6f0fd88f2f536a0c260015e316f9f`

構建指令：`python v25-work/book/tools/build.py --full --name b06-units`。兩次收斂，缺字、未解引用、重複標籤、overfull／header diagnostics 均為空。B-06 放行只表示下列排版與視檢工作完成，不是 B-07 數學終審通過。

## 接收、方案及固定版本

本卷採 B 方案單一 Work 變體，B-06 接 B-05 四組交叉全文審讀及主控整合後正文。先等 `book/.build/b05-cleared/build-report.json` 產出，再逐章實算 12 個 SHA 並核配對 PDF；全部一致。B-05 固定 PDF 為214頁，SHA `84f58bfaf2476e13af1d793e99e6b434a8c2bc2a62aa315118ba2ba3413ca766`。收件證據在 `b06-baseline/receipt.json`。

前卷有效 Git commit：`20e626496c24518f133af6eb892c620ea52a3c59`，V24 末章312；V25 Ch313–324，不重置章號。分卷／文獻表 v4 及既有邊界沿主控固定版本。本角色未改分卷表、文獻表、來源 PDF 或 extractor ZIP。

正式模板為已採納的 V0 ReadFlow R1，artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，原 ZIP SHA `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。三原樣式逐位元與固定模板相同：

| 樣式 | SHA-256 |
|---|---|
| layout/study/config.tex | fdccf765bbb70ff9f8b178a81af841d721cb4f962c9d90ddb476d5728e1c0424 |
| layout/study/readflow-layout.tex | b04bf2f5bb7611b8a4899c9a582050681d36d71fba8b0c44a31f8d87d2924f69 |
| layout/shared/readflow-base.tex | cc9cc678504651f8f1baa196a714a70de1331684589d71b14353c77ec6f6f63b |

字體／編譯依賴沿固定 R1 的 PagellaX、Asana、STIX two-glyph fallback、Noto Sans、DejaVu，依賴及 licenses 隨 `book/dependencies`；工程恢復證據見前階段 `layout-planning/LAYOUT-TECHNICAL-HANDOFF.md`。沒有縮字、改全局行距／紙張／邊界或升版共用樣式。模型及推理模式未由本角色獨立核實，未冒稱已切換特定模式。

**B-04 手上舊獨章 PDF 僅 checkpoint。** 它們不代表後續 canonical 定稿。B-05 整卷及本次 B-06 已重編現版 Ch318，其 SHA 為 `8e7db57790a4a689403cf82b46b4affd8b87d00076c2afb7dbbe4826cd5b33d6`；不以舊 checkpoint 推測現版已核或未核。

## 本次最小修改與缺陷處置

| ID／類別 | 原位置與讀者障礙 | 最終修法／保留義務 | 重核 |
|---|---|---|---|
| B06-L01／L | Ch315 正規化證明後的 inline Gaussian identity 造成7.6424pt overfull；原 log 指向295–299 | Gaussian identity 改為 display。原詞句、公式所有數學項及次序不變；曾嘗試拆前一個 align，確認不是成因後已回復 | final物理48放大核，式完整、無 overfull；去掉排版定界／空白後原章數學文字相同 |
| B06-E02／E | 原物理125只餘 Ch319 Further reading 末兩行 | 只精簡文獻導讀的重複播報，保留每筆 cite、章節、印刷／PDF頁碼與來源責任 | 導讀完整留在124；sourceguide之前正文逐位元未改 |
| B06-E03／E＋L | 原物理143只餘 Ch320 Further reading 末兩行 | 同樣精簡文獻播報，保留來源定位、邊界／無窮遠截斷分工和 logarithmic penalty 由 smooth weights 的局部弱極限取得且未假定 singular-weight theorem 的界線；只在本章末 guide 前局部擴一個 baselineskip | final141整段同頁；正文與頁腳間距實量且實看，見下表 |
| B06-L04／L | TOC3–6的單位數章欄寬使313／313.1／313.5.1與題名黏合，三位頁碼亦需保留空間 | 僅 `v25-setup.tex` 設章／節／小節編號欄及頁碼保留寬度；R1三檔未改 | 最終3–6全頁放大實看，編號、題名與頁碼清楚分離；導航鏈有效 |
| B06-L05／L | Example313.7 在11只留開頭兩行，計算續12 | 單元前 `Needspace{12 baselineskip}`，無文字或數學更動 | final11–12實看；完整例子在12，後文無新增斷裂 |
| B06-L06／L | Corollary313.20 在19→20只有一行續框 | 單元前 `Needspace{8 baselineskip}` | final19–20實看，完整陳述在20 |
| B06-L07／L | Proposition314.1 的係數定義在25、結論在26 | 單元前 `Needspace{10 baselineskip}` | final25–26實看，定義及結論在26，證明可順讀 |
| B06-L08／L | Exercise315.4 題幹最後一句在53→54續一行 | 單元前 `Needspace{6 baselineskip}` | final53–54實看，完整短題在54，解答接續正常 |

所有原文／改文在 `b06-baseline/ch313-B06.patch`、`ch314-B06.patch`、`ch315-B06.patch`、`ch319-B06.patch`、`ch320-B06.patch`、`v25-setup-B06.patch`。`B06-Changes.json` 列六個改檔前後 SHA；其他七章未改。sourceguide 的全部 cite 參數逐字相同；313／314／315 除註記、Needspace、Gaussian inline/display 定界外，數學與行文 tokens 相同。沒有 N／M 類自行裁決或補證。

### 320 頁腳實量

| final物理頁 | 最低正文 bbox 底 | 左頁腳 bbox 頂 | 垂直淨距 | 右頁碼 |
|---|---:|---:|---:|---|
|141|695.99pt|702.55pt|6.56pt|頁碼頂699.84pt，但 x=443.33–462.05；最後正文行 x=76.14–223.18，無相交 |

已另開整頁放大圖實看，非只靠文字座標判斷。單一局部正向擴頁明列保留；沒有批量擴／縮頁。

## 實際全頁視檢與最終版本銜接

先對固定212頁 PDF `42c5070f56dff48023ce0beefe1f472ec7781fd9b08c0b880cc97b5527599a04` 執行 Poppler120dpi全頁渲染。本角色實際開啟並看過物理1–54的14張四頁聯絡圖，每頁均看過低倍率完整畫面，另查48、57、124、141整頁／放大。**渲染成功與已看畫面分列，沒有用工程輸出冒稱看過。**

| 本角色實看頁組 | 主要觀察 |
|---|---|
|1–4、5–8|封面、讀法、目錄、開章與初次定義；發現並修復TOC數字欄寬 |
|9–12|Cauchy／Taylor長式與證明續頁正常；短例子後於final12完整保留 |
|13–16|compact convergence、root bound及分步證明正常續接，頁尾安全 |
|17–20|log-convexity、誤差界及Montel；短corollary後於final20完整保留 |
|21–24|習題與詳解順序正常；24整段來源導讀KEEP，無漏印 |
|25–28|章314開章、參數命題、Hartogs figure；final26命題成套 |
|29–32|孤立點、Laurent與shell公式完整；長證明依推理續接 |
|33–36|circular filling、長例子與compact-hole邊界，continued清楚 |
|37–40|interpolation與truncation公式、完整短題及續頁解答，無裁切 |
|41–44|章314結尾／來源與315開章／形式約定，章縫清楚 |
|45–48|orientation、Cauchy–Pompeiu、kernel及Gaussian修補；無公式／頁尾碰撞 |
|49–52|representation、boundary density、球均值與反例，長例續頁可辨 |
|53–54|習題及詳解；final54短題幹完整同頁，未引入新孤尾 |

三份分段實視回執均固定原 `42c5070f…`，沒有改寫其 hash：

| 回執 | 實看頁數 | 結果 |
|---|---:|---|
|B06-Visual-055-108.md|54|全頁實看；57極短章末導讀需排版判斷、99公式放大已排除疑慮 |
|B06-Visual-109-162.md|54|全頁實看；113自然短證明續頁、134／162密式放大無缺陷 |
|B06-Visual-163-end.md|50|全頁實看；177／194自然章末、212完整書目；179／196／202放大無缺陷 |

最終 `3f24323b…` 仍212頁。新舊同物理頁108dpi逐頁 raster／text／links 比對在 `b06-unit-final/comparison.json`；主控另獨立144dpi逐頁比對在 `b06-units-visual-comparison.json`。兩者均確認200頁畫面完全相同；只有 **3–6、11–12、19–20、25–26、53–54共12頁**不同。本角色和主控均已重新實看這12個最終頁面，確認修補有效、無新裁切／碰撞／不明接續。

**55–212全部同物理頁 raster、文字及 links 相同**，故三份原hash實視回執可藉明確映射沿用。1–54其餘頁同畫面，12個變更頁已補看。這是全卷212頁視檢證據的完成方式，不冒稱由同一人直接開啟新版全部212頁。新舊 links 差異只在3–6、20、26、27、54，包含目錄與移動單元的目標座標；最終工程掃描沒有壞內鏈。

## KEEP／警告及工程結果

* **物理24：**Ch313完整Further reading獨頁。前23末正文至643.73pt；將完整導讀硬塞回去會逼近頁腳。保持完整單元，不追省頁。
* **物理57：**Ch315完整來源導讀約五至六行獨頁。本角色另實看整頁，確認是自然章末來源單元，沒有漏印／裁切，KEEP。已回應055–108回執的注意項。
* 其他分段回執所記章末／短續頁均保留其具體判定，不以字元或留白門檻自動判錯。
* 最終 `b06-units-engineering/engineering-and-render.json` 為212頁工程scan：沒有近白正文、頁外spans、正文／頁腳碰撞、壞內鏈的flag。字體嵌入與各頁尺寸亦有逐頁記錄。工程scan及編譯日誌不代替上述實際視檢。

## 三層狀態、清單及唯一下一步

| 層次 | 狀態與證據 |
|---|---|
|內容保留|五章局部patch及v25-setup差異已列，數學正文未改；標籤／cite保留。最終12章 SHA 與 build-report 再次實算一致。B-05數學審讀與本次排版權責分列 |
|PDF工程|212頁、2次收斂、0選定diagnostics、0幾何／壞鏈flag；正式R1三檔相同 |
|閱讀視檢|1–54本角色實看、55–212三分段實看，最終200頁同畫面及12頁補視；全卷證據完成 |
|數學終審／使用者理解|B-07尚須由唯一打厚角色對固定源／PDF獨立整卷審；沒有本次真人理解或偏好測試聲明 |

完整機讀總報、最終source hashes、修改前後 hashes及實視圖檔索引見 `B06-Layout.json`。關鍵配對文件為 `book/.build/b06-units/build-report.json`、同目錄 `volume25.pdf`、唯一 `book/manuscript/ch313.tex` 至 `ch324.tex`；每檔bytes／SHA另列 `B06-MANIFEST.json`。最終永久可取入口由主控併入正式交付，目前是共享工作區實際可讀文件，不預填尚未發生的發布／保存。

OPEN／UNKNOWN：本次無未處置的排版阻塞；KEEP與非阻塞觀察如上。B-07數學結論尚未產生；全局歷史未知、凍結卷及舊v8頁尾問題不因本報告清零。本次模型／推理實際檔位未獨立核實。初次TOC重編曾啟動在舊b06-release目錄，已中止並恢復其原PDF hash；其受影響暫存日誌不再當原版工程證據，保留在 `b06-baseline/interrupted-toc-build`。最終b06-units有獨立完整日誌，不受此事影響。

唯一下一階段：打厚 B-07 對 `3f24323b…` 固定整卷源／PDF作嚴格終審。若有回修，依L/E/N/M責任修正，再回打厚複核，不以兩份無異議結案。B-08僅於通過及授權內由主控封存；本角色沒有發布、Git變更、Library寫入或凍結卷改動。

待使用者決策：無。禁止重做：不重開其他卷、不重做已核文獻、不重建正文或模板、不把B04 checkpoint當現版。本次B-06放行已透過同Work協作訊息送達主控；主控已核最終PDF並固定B07副本。此完整文案送達後的實讀回執另列，文案產出本身不冒稱對方已讀。
