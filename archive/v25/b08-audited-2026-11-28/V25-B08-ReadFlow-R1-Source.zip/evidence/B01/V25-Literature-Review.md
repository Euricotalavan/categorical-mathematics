# V25 多複變分析｜文獻核對與開工前交接

2026-11-28（台北） · B 方案單一 Work 變體 · 等待使用者確認文獻。

原書目三本已有清大數學分館紙本紀錄。正式全文的取得仍待確認。四份作者公開全文已收齊。正式稿所據版本與公開下載入口列在下方。

## 原書目與可取得版本

| ID | 書名與優先版本 | 已核資料與可取得入口 | 若採紙本，優先補的內容 |
|---|---|---|---|
| R01 | Lars Hörmander, *An Introduction to Complex Analysis in Several Variables*，North-Holland 修訂第 3 版，1990，ISBN 9780444884466 | 已核出版社目錄及清大紙本 QA300 H782 1990。1973 修訂第 2 版有書目、目錄與 Google Books 預覽，屬不同版次。第 3 版合法電子全文待確認。[Elsevier 第 3 版](https://shop.elsevier.com/books/an-introduction-to-complex-analysis-in-several-variables/hormander/978-0-444-88446-6) · [清大 1990 紙本](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990007282620206774&context=L&vid=886UST_NTHU:886UST_NTHU&lang=zh-tw) · [1973 版預覽](https://books.google.com/books?id=MaM7AAAAQBAJ) | 第 IV 章的 \(L^2\) 估計與存在性（第 3 版公開目錄起於印刷頁 77）。其次第 II 章的基本理論、第 V 章的 Stein／全純凸性及第 VI 章的局部解析結構。掃描起訖以手邊版次目錄為準。 |
| R02 | Steven G. Krantz, *Function Theory of Several Complex Variables*，修訂第 2 版，AMS Chelsea 紙本 ISBN 9780821827246、電子版 ISBN 9781470429911。清大紙本標 2000，AMS 電子版紀錄為 2001 | 已核清大紙本 QA331.7 .K74 2000 與公開目錄／預覽。AMS DOI 已定位，當前入口拒絕存取，清大電子權限與合法電子全文待確認。[AMS DOI](https://doi.org/10.1090/chel/340) · [清大 2000 紙本](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990008914340206774&context=L&vid=886UST_NTHU:886UST_NTHU&lang=zh-tw) · [公開預覽](https://books.google.com/books?id=bL8jDwAAQBAJ) | 先提供版權頁與目錄。按 AMS Chelsea 公開目錄，印刷頁 19–80 積分公式、175–242 \(L^2\) 解法與 Levi 問題、293–320 零點集、403–428 積分解與範數估計。典型域應用可從 429 起依目錄選相關段落。 |
| R03 | R. Michael Range, *Holomorphic Functions and Integral Representations in Several Complex Variables*，Springer GTM 108，1986，電子 ISBN 9781475719185 | Springer 頁列目錄、前後置資料連結及正文試閱入口，整本 PDF 入口導回訂閱／機構登入。清大紙本 QA331 R163 可借，Springer Book Archive 的本書校內權限未核。[Springer](https://link.springer.com/book/10.1007/978-1-4757-1918-5) · [清大紙本](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990007639200206774&context=L&vid=886UST_NTHU:886UST_NTHU&lang=zh-tw) | 優先印刷頁 144–190 多複變積分表示、191–213 嚴格偽凸域的 Levi 問題與 \(\bar\partial\) 解法。若納入逼近或邊界應用，再依正式範圍從 214–272、273–355 擇段。 |

若用實體書，先給版權頁、目錄及所需章節。校外電子入口可由清大機構認證核對是否有該版全文。[清大電子資源利用](https://www.lib.nthu.edu.tw/research/guide.html)

## 文獻選擇

正式稿採用 O01–O04 四份作者公開版本。原書目保留作館藏定位。

## 已取得的作者公開全文

| ID | 來源、版本與檔案 | 已確認的章節入口 |
|---|---|---|
| O01 | Jiří Lebl, *Tasty Bits of Several Complex Variables* v4.4，2026-05-31，248 PDF 頁。CC BY-SA 4.0 或 CC BY-NC-SA 4.0 可擇一遵循。[作者頁](https://www.jirka.org/scv/) · [全文](https://www.jirka.org/scv/scv.pdf) | §1.1–1.4 全純、冪級數、球與多圓盤；§2.1–2.6 全純域、延拓、Levi 形式與多重次調和；§4.1–4.5 \(\bar\partial\) 與一般 Hartogs；§5.1–5.3 積分核；§6.1–6.7 函數芽、Weierstrass 與解析集合。 |
| O02 | Jaap Korevaar、Jan Wiegerinck, *Several Complex Variables*，2017-08-23，274 PDF 頁，阿姆斯特丹大學作者課程稿。[作者課程](https://staff.fnwi.uva.nl/j.j.o.o.wiegerinck/edu/scv/) · [全文](https://staff.fnwi.uva.nl/j.j.o.o.wiegerinck/edu/scv/scvboek.pdf) | Ch. 1–3 全純、Cauchy 與延拓；Ch. 4 解析局部結構；Ch. 6、8、9 全純凸、psh 與偽凸；§10.5–10.8 積分表示；§11.4–11.6 加權 \(L^2\) 方法，印刷頁 222–231 附近、PDF 頁 228–237 附近。 |
| O03 | Jean-Pierre Demailly, *Complex Analytic and Differential Geometry*，2012-06-21，455 PDF 頁，作者公開稿。[作者與授權說明](https://www-fourier.univ-grenoble-alpes.fr/~demailly/documents.html) · [全文](https://www-fourier.univ-grenoble-alpes.fr/~demailly/manuscripts/agbook.pdf) | Ch. I §§6–7 全純域、Stein 和偽凸；Ch. II §§1–5 層、解析局部環、解析集合與解析空間；Ch. VIII §§1、4–6 提供算子和估計的進階對照。 |
| O04 | Harold P. Boas, *Lecture Notes on Several Complex Variables*，2013-12-03，81 PDF 頁，Texas A&M 作者本人課程稿。[作者課程](https://haroldpboas.gitlab.io/courses/650-2013c/) · [全文](https://haroldpboas.gitlab.io/courses/650-2013c/notes.pdf) | §3.2 球與雙圓盤不等價，§4.2.1 Oka–Weil 敘述（印刷頁 44／PDF 頁 46），§4.3.2 證明（印刷頁 72／PDF 頁 74）。§4.3.3 提供光滑偽凸域估計的第二讀法。 |

以上四份的封面、版本、目錄、PDF 文字層與部分正文位置已核。檔案大小與 SHA-256 見 `SHA256SUMS.txt`。O02／O04 為作者公開可讀參考稿，另行引用或轉載仍須依適用條件處理。書稿若使用這些資料，採自行撰寫、核對與引註的方式。

## 12 章的文獻定位

章名沿用分卷表，章號根據 V24 已發布末章接續。以下位置用於取得材料和後續續接。

| 章 | 分卷表主題 | 已可讀的定位 | 指定原書待補定位 |
|---:|---|---|---|
| 313 | 多變數全純與冪級數 | O01 Ch. 1，O02 Ch. 1 | R01 II、R03 I |
| 314 | Hartogs 現象 | O01 §§2.1、4.3，O02 §§2.6–2.8、3.4 | R01 II、R03 I–II |
| 315 | 多變數積分公式 | O01 §§4.1、5.1，O02 §§10.4–10.8 | R02 19 頁起、R03 144–190 |
| 316 | 全純域 | O01 §§2.1、2.6，O02 Ch. 6 | R01 II、R03 42–103 |
| 317 | 偽凸與 Levi 形式 | O01 §§2.3–2.5，O02 Chs. 8–9 | R02 81／117 頁起、R03 42–103 |
| 318 | 典型域與邊界 | O01 §§1.4、2.3，O02 §9.4 | R02 邊界與映射段、R03 273–355 依定界 |
| 319 | \(\bar\partial\) 方程的設定 | O01 Ch. 4，O02 §§10.4、11.1–11.2 | R01 IV、R03 104–143 |
| 320 | 所選解法與估計 | O02 §§11.4–11.6；O03 Ch. VIII 作進階對照 | R01 IV、R02 175 頁起；若選積分核解法核 R03 191–213 |
| 321 | 全純函數的延拓與逼近 | O02 Chs. 2–3，O04 §§4.2.1、4.3.2 | R01 V、R03 214–272 |
| 322 | 典型域的完整應用 | O01 §§1.4、4.4、5.2–5.3，O04 §3.2 | R02 429 頁起、R03 273–355 依應用取用 |
| 323 | 與解析集合的接口 | O01 Ch. 6，O02 Ch. 4，O03 Ch. II §4 | R01 VI、R02 293 頁起 |
| 324 | 解析空間所需先備 | O01 §§6.1–6.4，O03 Ch. II §§1–5 | R01 VI–VII 依接口取用，凝聚層與解析空間由 V158 承接 |

第 320 章的解法責任仍待正式定界。資料已備妥可比較加權 \(L^2\) 解法與積分核解法。估計須各自核對域的正則性、權重、閉性、形式的次數及範數。第 324 章只定位 V25 所需先備，V158 的正式範圍沿分卷表。

## 可貼交接

**交接 ID／版本／日期**　V25-PRE-B01-LITERATURE-v1 · 2026-11-28（台北）

**發出與接收**　V25 主控 → 同一 Work 的精修角色。對話為本串。待取得使用者對採用文獻的確認後交接。

**卷與狀態**　V25 多複變分析；B 方案單一 Work 變體。階段為 B-01 前的文獻取得。使用者明確要求先準備所有文獻並確認。B-01 尚未啟動，未發子代理任務；製作角色模型及推理設定待實際派工後核對。

**有效基線**　分卷表 v4 之 V25 12 章與文獻表 v4 之 V25 三本原書目。Git 固定前卷 commit `20e626496c24518f133af6eb892c620ea52a3c59`，V24 Ch. 305–312。V25 暫定 Ch. 313–324，正式邊界待後續定界。B-01 對應原 A-01 的來源索引與覆蓋責任。[固定的 V24 索引](https://github.com/Euricotalavan/categorical-mathematics/blob/20e626496c24518f133af6eb892c620ea52a3c59/archive/v24/b08-audited-2026-11-28/README.md)

**檔案清單與核驗**　`SHA256SUMS.txt` 記四份公開來源原檔及本交接的 bytes／SHA-256。分卷、文獻表分別取專案固定檔。分卷表固定入口 · 文獻表固定入口

| 基線檔 | bytes | SHA-256 | 本階段核對 |
|---|---:|---|---|
| math-curriculum-v4-git-aligned.html | 2167706 | `098aaacab85e330cb0493fc928916361c3fba09c0d36b3964f61c74ad2a2e1df` | V25 12 章、I04 內容責任及 V158 接口。 |
| math-references-v4-git-aligned.html | 3482004 | `4b3e0af09024a799744ee6fbb76ad68b95d82baeb020e5a6b8033cf00361a59d` | V25 三本候選書、版次與原館藏紀錄。 |
| math-extractor-v0.4.zip | 1021262 | `c2d47e097447a836bcad63d5a030106b1ec261bac4ffe32a6aecc783aca244f3` | CRC 通過，已讀 README 的輸入輸出與限制。待 B-01 才跑逐項索引。 |

**正式模板／編譯／視檢**　採 ReadFlow R1 基線 `V0-ReadFlow-R1-Source.zip`（版本 3、7,007,679 bytes、SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`；artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`）。本階段核對該固定入口之規格。V25 正式正文、索引、逐項覆蓋表、局部排版修補、編譯證據、配對 PDF 與全頁視檢尚未產生，等各階段依權責建立。模板入口

**OPEN／UNKNOWN 與下一步**

| ID | 影響 | 責任與下一步 | 阻塞 |
|---|---|---|---|
| R01–R03 | 原書目所需正文未核為可用 | 主控接已確認的機構版、適用的紙本頁段或獲准以 O01–O04 取代相應責任。固定每份來源的版次與可用範圍。 | 本輪 B-01 待使用者確認採用組合。 |
| Q01–Q03 | 第三方副本授權待查 | 使用者判定。不可用即排除。 | 只影響選用該副本。 |
| OPEN-320 | 來源覆蓋取決於選定的解法及定理範圍 | 精修建立來源責任，B-02 核先備和選法。 | 阻正式定界中的對應結論。 |
| UNKNOWN-LOCATORS | 尚未逐項通讀定義、命題、證明及例題 | B-01 讀固定原文並建立原文位置、條件、跨書差異與覆蓋責任。 | 本準備交付可完成，逐項覆蓋驗收仍待。 |

**續接條件**　使用者確認來源組合後，唯一下一階段是 B-01。精修先核收件，從已確認且實際可讀的固定版本建立索引與責任表，區分原書版次及已讀範圍。使用者未確認前維持文獻準備。已核館藏與可讀原稿可直接沿用，凍結卷和原分卷表保留，這次不做 Git 發布。

**傳遞與回執**　本文已交使用者核對。精修收件回執待下一階段，須列實取檔、版本／SHA-256、可讀或缺檔情形、章號／凍結限制和下一步。
