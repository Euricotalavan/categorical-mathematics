# V25 B-01｜Ch.322–324 來源責任與證明規劃

版本：V25-B01-GEOMETRY-v1；日期：2026-11-28。範圍：Ch.322「典型域的完整應用」、Ch.323「與解析集合的接口」、Ch.324「解析空間所需先備」。

本件是實讀來源的逐項責任表及後續證明規劃，不是正文、B-04 合入補丁或數學通過書。主控明示僅先做 B-01，故停於來源與依賴交接，待 B-04 clearance 才起稿。沒有修改工具 ZIP、分卷／文獻表或凍結卷，沒有 Git／Library 發布。

## 收件回執與固定輸入

實際讀入 `v25-prep/V25-Literature-Review.md`（SHA-256 `4f9b1af5f9b07f2a4bacd933ccd41d3004ace68398c7ab804a34215d4f7fad30`）及 `project_sources/15-B-Work-v1.txt`（`c16755a48b868b6ae1dd1704ccca1a0a61289ab8e81d32835c36acc155379e6b`）。接受主控回執：四份 O01–O04 已獲使用者批准；準備交接中「等待確認」屬歷史狀態。R01–R03、Q01–Q03 未作本文證據。

| ID | 實取 PDF／版本 | SHA-256 | 本次印刷頁 ↔ PDF 實體頁（1 起算） |
|---\|---\|---\|---|
| O01 | `v25-prep/Lebl-SCV-v4.4.pdf`；v4.4，2026-05-31 | `729cdb8a00685da581c0a67408b06fa2a375e02317e4937d363c70ca43718f77` | 本次段落印頁與 PDF 頁相同。實讀 32–36、160–165、167–190、193–196；191–192 為補助來源，後續若用其完整證明須再核。 |
| O02 | `v25-prep/Korevaar-Wiegerinck-SCV-2017.pdf`；2017-08-23 | `46ac273899b346422ae3a86fa0969308bc104c05d5a673ad15be2577772f58f1` | 印頁 66–76 ↔ PDF 72–82，offset +6。逐頁核 §§4.1–4.6。 |
| O03 | `v25-prep/Demailly-CADG-2012.pdf`；2012-06-21 | `d7c7654a7417e8322e5dcf8fe8ec818b4c1a18cf280b41f2df5a871b776d89a1` | 本次印頁與 PDF 頁相同。實讀 65–71、79–83、86–105、122–123；84–85 只作局部免費層背景，不作必要證明責任。 |
| O04 | `v25-prep/Boas-SCV-Fall2013.pdf`；2013-12-03 | `ee29cb6c8a557ad63e25785ce4433b4099e46c87f16e2ce7a9c6697c69d5870f` | 印頁 31–32 ↔ PDF 33–34，offset +2；§3.2 完整讀。 |

另從固定分卷表 HTML 的 JSON 實讀 V25、V158 的 scope/end/pre/chapters：V25 在全純、Hartogs、偽凸、選定 ∂̄ 方法及典型域完整應用後只交解析空間先備；V158 承接解析集合、局部環、解析空間、奇異點、凝聚層和標準局部工具。V158 尚未發布或已驗收的正文、章號均未推測。本次全域章號 322–324 依主控已核 V24 末章 312 續接，不另從 Chapter 1 排號。

文字實讀以固定 PDF 的文字層逐頁核對；額外視覺核對 O01 p164、O02 印76/PDF82、O03 p102、p122。對應圖片在 `v25-work/b01/geometry-evidence/`。這是來源局部視檢，非成書 PDF 全頁 QA。

## 分工、順讀與符號邊界

Ch.318 已負責球、多圓盤及邊界的基礎。Ch.322 以一條完整 Bergman 計算作主案例，再證明球與多圓盤不等價；不能只列公式、只說邊界不同或借用未證的邊界延拓。Ch.323 需在 Weierstrass 前先定義「芽、環、單位、正規變數、Weierstrass 多項式」，因它們不應等到 Ch.324 才出現。Ch.324 接續芽的層化、商局部環與解析空間語言，提供 V158 可直接接收的接口。

統一以 `dV` 表未歸一化的 ℝ^{2n} Lebesgue 體積，`dA` 為平面面積；Hilbert 內積第一變數線性，`K_U(z,w)` 對 z 全純、對 w 反全純。來源 O01 寫 `K_U(z,barζ)` 的雙重記法在正文可改寫，但必須逐式核共軛。`O_{C^n,p}` 是環，`O_U` 是層，`O(U)` 是全域函數環；三者不可混用。`I_{X,p}` 是所有在集合芽上消失的芽，不等同任取方程生成的理想 `J`。

狀態字：**實讀**只指來源位置與內容已核；**必證**指後續正文責任；**接口敘述**指必須明示證明留在 V158、不作本卷後續論證的暗中前提；**選配**須 B-02 定界後才收。

## Ch.322：完整典型域應用

| 責任 ID／落點 | 定義／結果、精確條件 | 來源：印頁／PDF頁／標號 | 必要證明、例題與核點 | 狀態／差異 |
|---\|---\|---\|---\|---|
| G322-01 基準域與等價 | `B^n={sum \|z_j\|²<1}`、`D^n={\|z_j\|<1 all j}`；biholomorphism 要求雙射、映射與反映射均全純；比較定理 n≥2。 | O01 32–33／32–33，Def1.4.1、§1.4；O04 31／33，§3.2。 | 回扣 Ch.318 的定義，示範 n=1 兩域相同。解題：徑向 homeomorphism `x -> (\|\|x\|\|_2/\|\|x\|\|_∞)x`（x≠0、0↦0）在球到多圓盤，反映射交換兩範數；證連續且不藉此主張全純。 | 實讀；基礎不整節重寫，只保留案例必要回顧。 |
| G322-02 Bergman 空間 | 對任意域 U⊂C^n，`A²(U)=O(U)∩L²(U,dV)`；函數類採其唯一全純代表。內積 `<f,g>=∫ f bar g`。 | O01 160–161／160–161，§5.2、Lem5.2.1。 | 證每個 K⊂⊂U 有 `sup_K \|f\|≤C_K \|\|f\|\|₂`：在 K 上取共同半徑的多圓盤，用平均值及 Cauchy–Schwarz，常數可取 `(π^{n/2}r^n)^{-1}`。若 L²-Cauchy，局部一致 Cauchy、全純極限且與 L² 極限 a.e. 相同，故空間閉。 | 實讀／必證。不能把 a.e. 等價類未選代表便代入 f(z)。 |
| G322-03 評值與核 | 評值 `ev_z:A²(U)→C` 有界；Riesz 得 k_z，`K_U(z,w)=overline{k_z(w)}`，`f(z)=∫_U K_U(z,w)f(w)dV(w)`。 | O01 162／162，式(5.1)、Prop5.2.2。 | 先說 Riesz 及 Hilbert 空間先備是否已核；逐一證 kernel section 的 A² 性、共軛對稱、對 z 全純／w 反全純及唯一性。不能僅憑「滿足一個積分」宣稱是 Bergman 核。 | 實讀／必證。Hilbert 先備實際正文覆蓋 UNKNOWN，由 B-02 主控核。 |
| G322-04 核的正性與極值 | 若 U 有界，常數 1∈A²(U)，故 `K_U(z,z)>0`；`K_U(z,z)=sup{ \|f(z)\|²:\|\|f\|\|₂≤1 }`。 | O01 162、164／162、164，Riesz 構造、Ex5.2.4；極值式由 Riesz 自行推出。 | Cauchy–Schwarz 給上界，取正規化 k_z 給等號；K=0 時分開處理。算 `K_U(0,0)≥1/Vol(U)`；平衡域核計算後取等號。反例 A²(C^n)={0}，不要把有界假設刪去。 | 實讀／必證；極值等式屬本卷推導，不假稱來源原定理。 |
| G322-05 正交展開 | 任意 complete ONB `{φ_α}` 給 `K(z,w)=Σφ_α(z)overline{φ_α(w)}`，在 U×U 的緊集上一致。 | O01 163–164／163–164，Prop5.2.5。 | Riesz section 作 L² 展開→固定 w 的緊上一致；用尾核 `Σ_{α>N}\|φ_α(z)\|²`，Dini 或局部 Cauchy 控制證雙變數一致。正文要補「有共同有界上界」不足以單獨推出一致尾和這一細節。模型域也可直接從顯式冪級數證緊上一致，避免泛化過頭。 | 實讀／必證；來源最後 C–S 界需展開尾項論證。 |
| G322-06 圓盤單項式 | `\|\|z^k\|\|²_{A²(D)}=π/(k+1)`，`φ_k=sqrt((k+1)/π) z^k`；完備性不是只有正交性。 | O01 162–164／162–164，Ex5.2.3、Prop5.2.5、Ex5.2.6。 | 角積分先證正交；若 f 與全部單項式正交，徑向截斷／Taylor 配對給每個係數零。求和 `Σ(k+1)t^k=(1-t)^{-2}` 得 `K_D(z,w)=1/[π(1-z bar w)²]`。驗證 f=1,z,z² 三個再生積分。 | 實讀／必證完整 worked example。來源主例走 Stokes，這裡改 ONB 路線以統一 n 維。 |
| G322-07 多圓盤核 | `\|\|z^α\|\|²_{D^n}=π^n/∏(α_j+1)`，`K_{D^n}(z,w)=π^{-n}∏(1-z_j bar w_j)^{-2}`。 | O01 164／164，Ex5.2.8；前列 ONB。 | Tonelli/Fubini 與旋轉正交；用 Taylor 和截斷證完備。完整算 D² 的 α=(1,2) 範數 `π²/6`；求積核與常數再生。可追加半徑 r_j 的尺度公式，Jacobian 平方要保留。 | 實讀／必證。積公式中的 π 不可因測度歸一化混淆。 |
| G322-08 球上單項式積分 | `\|\|z^α\|\|²_{B^n}=π^n α!/(n+\|α\|)!`；ONB 為此範數倒數乘 z^α。 | O01 164／164，Ex5.2.9；165／165，Ex5.2.10。 | 展開每座標極座標，t_j=r_j²，單純形積分 `∫_{Σt<1}∏ t_j^{α_j}dt=α!/(n+\|α\|)!`；用反覆一變數 beta 積分作完整證明，不把 beta 當未講黑箱。角積分證正交；Taylor 係數及徑向截斷證完備。驗 α=0 得 Vol(B^n)=π^n/n!；n=2,α=(1,0) 得 π²/6。 | 實讀／必證。視讀 p164 確認來源寫 z^α/c_α，`c_α=範數`；不是乘數，不報成勘誤。 |
| G322-09 球核閉式 | `K_{B^n}(z,w)=n!/[π^n(1-Σz_j bar w_j)^{n+1}]`。 | O01 165／165，Ex5.2.10。 | 依總次數 m 分組，用 multinomial `Σ_{\|α\|=m} z^α bar w^α/α! = <z,w>^m/m!`，再用 `(1-t)^{-n-1}` 的導數級數。明示 `\|<z,w>\|<1` 與緊集上的一致絕對收斂。完整算 B² 核、原點值2/π²並用體積驗常數項。 | 實讀／必證，主案例計算落點。 |
| G322-10 核的變換 | F:U→V biholomorphism，`K_U(z,w)=J_F(z)K_V(Fz,Fw)overline{J_F(w)}`；J 是複 Jacobian。 | O01 164／164，Ex5.2.7；O04 32／34，Ex17（實 Jacobian = \|複 Jacobian\|²）。 | 定義 `Tg=J_F(g∘F)`，換元證 unitary；由再生與唯一性得式。範例縮放 rD、rB^n，結果具有 r^{-2n}，不直接套到非一一全純映射。 | 實讀／必證；一頁可完成的運算例，不延伸到 Bergman metric 曲率。 |
| G322-11 正確區分邊界直觀與證明 | 球面不包含非恆定解析圓盤；多圓盤邊界含 `{e^{iθ}}×D` 等。 | O01 34／34，Def1.4.5、Prop1.4.6；O04 31／33。 | 任 g:D→∂B^n 全純，unitary 使 g(0)=e₁，由 g₁ 最大模知 g₁≡1，其餘≡0。這只說邊界性質，未自動推出域不等價，必須接 G322-12。 | 實讀／必證。避免假設任意 biholomorphism 連續延到閉域。 |
| G322-12 proper 與不等價 | bounded domains U,V、continuous F proper iff every boundary-approaching sequence has only target-boundary cluster points；沒有 proper holomorphic D²→B²，故無 biholomorphism。n≥2 的 D^n→B^n 同法。 | O01 33–36／33–36，Def1.4.3、Lem1.4.7、Thm1.4.4、1.4.8；O04 31–32／33–34，§3.2。 | 先嚴格證序列判準（compact K⊂V；不能只取任意 closed E）。固定一變數靠邊界的切片，Montel 取子列，proper 使極限在球面，G322-11 使常數；Cauchy 估計保證導數局部一致趨0。任意邊界序列的每子列可再取0極限，推出完整極限0；最大模逼每個偏導恆0，矛盾 proper（常值映射反像單點為整個非compact域）。 | 實讀／必證完整結案。一般 product→no-disc-boundary 是可選延伸，不須取代主證明。 |
| G322-13 自編練習與解答責任 | 至少 4 題：尺度核、原點極值、球與多圓盤單項式比較、proper 映射的目標改變。 | O01 Ex1.4.3、5.2.4、5.2.7–10 的責任，自編題面。 | 解答需完整算式。可用 `D→D,z↦z²` proper、同公式 D→C 非proper；展示 proper 依賴 codomain。核的常數項不同不能單獨證不等價（Jacobian 可補償），此陷阱要設題並解。 | 必有解答，不能把來源習題「留給讀者」替代本卷 worked depth。 |

## Ch.323：Weierstrass 與局部解析幾何

| 責任 ID／落點 | 定義／結果、精確條件 | 來源：印頁／PDF頁／標號 | 必要證明、例題與核點 | 狀態／差異 |
|---\|---\|---\|---\|---|
| G323-01 芽與共同鄰域 | `(f,p)~(g,p)` iff 某共同開鄰域 W∋p 上 f=g；和積先縮到共同鄰域，再取芽。 | O01 167–169／167–169，Def6.1.1–3、Ex6.1.1、6.1.6–9；O02 72／78，§4.5。 | 核自反對稱傳遞，核和積與代表元選擇無關；`O_{C^n,p}≅C{z-p}` 以 Taylor 唯一與收斂證。區分「點值相同」「所有 Taylor 係數同」「芽相同」。不要無限次縮鄰域後假稱還有共同開鄰域。 | 實讀／必證。Ch.324 只回顧，不延遲這個先備。 |
| G323-02 單位與環性質 | 全純芽環為 integral domain；單位 iff f(p)≠0；唯一極大理想 m_p 為在 p 消失的芽。 | O01 168、180／168、180，Ex6.1.3–4、6.4.1；O02 72／78，§4.5。 | identity theorem 用連通小球證無零因子；倒數局部全純；`f-f(p)=Σ(z_j-p_j)g_j` 由 Taylor 或沿線積分證 m_p 由座標生成，並證任何 proper ideal⊂m_p。 | 實讀／必證；這些是解析空間商局部環的真正前提。 |
| G323-03 vanishing order 與正規變數 | `ord_p f` 為第一個非零 homogeneous Taylor 部次數；在 z_n 正規 iff f(0,z_n)非零芽，其零階 k 未必等於 ord₀f。 | O01 169–170、174／同頁，Def6.2.1；O02 66／72，Def4.1.1–2、Lem4.1.4。 | 取最低 homogeneous P_m 的向量 v 且 P_m(v)≠0，再選 last column v 的 invertible linear A，得沿新末座標零階 m。例 f=z₁²+z₂³ 原 z₂ 階3、總階2；小 shear 得正規階2。 | 實讀／必證；不准把「換座標」寫成沒有構造和可逆性的一句話。 |
| G323-04 Weierstrass polynomial | `P(z',w)=w^k+a₁(z')w^{k-1}+…+a_k(z')`，係數全純且 a_j(0)=0；monic；k≥1，零階情形 P=1 可另說。 | O01 169–170／169–170，Def6.2.2；O02 69–70／75–76，Def4.3.2；O03 80／80，II(2.1)。 | 逐個核「係數在哪個域」「在0消失」「w 是多項式、z' 是函數」；反例 remainder 不必 monic／係數消失。先用 P=w²-z，區分兩根分支與整體多項式。 | 實讀／必定義。 |
| G323-05 preparation 假設與結論 | f 於0鄰域全純，f(0)=0，f(0,w)非零芽且 exact order k；縮 product polydisc 得唯一 f=uP，u nowhere zero，P degree k，所有纖維根位於固定 w-disc。唯一是 germ／適當共同鄰域意義。 | O01 170–172／同頁，Thm6.2.3；O02 71／77，Thm4.4.1；O03 79–80／同頁，II(2.1)。 | 小 w 圓上 f(0,w)無零→compactness 取 uniform collar；argument principle 的根數 integer-continuous 故恆 k。禁止未核使用「根可以全純排列」。 | 實讀／必證全程；O03 有閉 polydisc 鄰域與估計較強版本，正文採局部版本。 |
| G323-06 preparation 證明的代數步 | power sums `s_m(z')=(2πi)^{-1}∮w^m f_w/f dw` 全純；Newton 遞推將 elementary symmetric coefficients 寫為 s_j 的多項式。 | O01 171–173／同頁；O02 69–70／75–76，Lem4.3.1、式4.3.5–7。 | 不依賴未證的 symmetric-polynomial 大定理：直接從 `∏(1-α_jt)` 的 logarithmic derivative 對係數，得 `j a_j=−Σ_{r=1}^j a_{j-r}s_r`。再對 f/P 與 P/f 用 fixed contour Cauchy，證 u 與 inverse 共同全純。唯一以所有 roots及multiplicity固定 monic P，u=f/P。 | 實讀／必證；來源 O01 Newton 放習題，本卷須展開。 |
| G323-07 division 定理 | 任 f 全純芽，P distinguished degree k≥1，唯一 `f=qP+r`，q全純芽、`r=Σ_{j=0}^{k-1}r_j(z')w^j`。 | O01 175–176／同頁，Thm6.2.5；O02 71／77，Thm4.4.2；O03 80–81／同頁，II(2.3)。 | q 用 `∮ f(z',ζ)/[P(z',ζ)(ζ-w)]`；r 的 integrand 為 `f[P(ζ)-P(w)]/[P(ζ)(ζ-w)]`，括號差商 degree<k。唯一：對固定 z'，r₁−r₂ 被 P 整除，必須按 roots **multiplicity** 計 k 個，degree<k 故0，再得 q相同。 | 實讀／必證；O03 額外 bounded f 的 sup estimate可作選配，不能把常數無依賴地搬到任意域。 |
| G323-08 worked division | P=w²−z；f=w³+z²，可直接得 q=w、r=zw+z²。另源例 P=w²+z³、f=e^z+z⁴e^w+zw²e^w+zw，q=ze^w、r=zw+e^z。 | O01 176／176，Thm6.2.5後例；第一例自編。 | 兩例均把 qP+r 展開核原 f；r₀、r₁ 的環與degree要明寫；參數 z 固定的除法不是任意分母 Laurent 展開。解題：e^w 除 w²−z，r=A(z)+wB(z)，A=Σ z^m/(2m)!，B=Σ z^m/(2m+1)!，解釋在 z=0 無假奇點。 | 實讀／必例＋自編完整解；最後級數可後續求 q 收斂並核代入。 |
| G323-09 分支、分歧與奇異不相同 | P=w²−z 的判別式4z、兩分支不能在 punctured z-disc全域連續排列，但曲線為 z=w² 的 smooth graph；P=w²−z³ 的0為 cusp singular。 | O01 172–174、190／同頁，Ex6.2.4、Ex6.6.4；O02 75–76／81–82，Thm4.6.2、Ex4.6.3。 | 對 simple root 用 implicit function theorem 得局部全純根。`discriminant zero ⇒ projection may branch`，不是 `⇒ underlying analytic set singular`。必完整比較兩個 Jacobian：w²−z 的 z偏導−1，w²−z³ 的梯度於0消失並另證非smooth。 | 實讀／必例。 |
| G323-10 squarefree 多項式的局部圖像 | reduced/squarefree monic P degree k（作全純芽或 O_{n−1}[w] 意義明確）；resultant `Res_w(P,P_w)` 非零芽；在其零集以外 k個單根、投影局部 biholomorphism。 | O02 73–76／79–82，Properties4.5.5、Thm4.6.2；O01 176–180／同頁，§6.3。 | 若採 resultant，需先交 algebra lemma／UFD；更淺替代是只對 quadratic/cusp案例明算 Δ。本卷建議證 simple-root圖像和二次判別式，general reduced-hypersurface theorem以精確接口敘述，避免暗加完整 elimination machinery。 | 實讀／B-02選定深度。O01 distinct-root「集合判別式」與計multiplicity的 polynomial discriminant不同，見差異表。 |
| G323-11 analytic set 與閉性 | X⊂U開域：在 ambient U 的每個點附近為有限個全純函數共同零集；或 X relatively closed 且只在 X每點局部零集。兩個敘述等價。 | O01 182–183／同頁，Def6.5.1；O03 91／91，II(4.1)。 | 定義採 finite families，避免先用 Noetherian 才回來證finite；證相對閉、finite intersections及 finite unions（products of equations）仍analytic。例 `z=0,\|w\|<1` 是在適合小 ambient 域解析，非整 C² 的閉analytic subset。 | 實讀／必證；「local analytic subset」和 ambient closed analytic subset 要區分。 |
| G323-12 ideal 與方程不同 | 定 `I_{X,p}={f germ:f在(X,p)上消失}`；對有限生成 J，V(J) 作集合芽且不依生成元；`J⊂I(V(J))`、`V(I(X))=X` 在定義合法範圍成立。 | O01 183–184／同頁，Ex6.5.1–3、Ex6.5.4；O03 91／91，II(4.3)。 | 必證 representative independence 與 inclusions。例 X={0}⊂C²，J=(z²,w²)，I_X=(z,w)，不同；`z∉J` 可用 Taylor degree檢查。`I_X` radical 是直接逐點證，不需 Nullstellensatz。 | 實讀／必證；不把「同零集」和「同商環」混為一談。 |
| G323-13 regular point、dimension | regular iff 局部為 holomorphic graph／complex submanifold；singular其餘。regular點維數由 graph base維數；general germ維數取接近的regular分支之最大。 | O01 185–187／同頁，Def6.5.5、6.5.7；O03 98／98，II(4.23)–(4.25)。 | 至少證graph維數不依座標（切映射rank）；regular locus open。不得單用「homeomorphic to C^k」定regular，cusp topologically disc 但解析奇異。一般 regular dense theorem要接口標示或補足所用範圍；本卷例不靠未證一般定理。 | 實讀／必定義、局部證明；general density留 V158。 |
| G323-14 three worked local models | smooth parabola w²=z；node zw=0；cusp w²=z³。分別核 equations、regular/singular、局部branches、理想／局部環初樣。 | O01 185–186、193、195／同頁，Ex6.5.6、Ex6.7.5；O03 98–99，II(4.27)。 | node在0兩branch，punctured小鄰域不連通，故不為complex curve manifold；cusp參數t↦(t²,t³)單射，0導數為0。證其不smooth不能僅因這個參數的導數0；應用若smooth則有局部全純座標，其參數合成的 order導出矛盾，或商環 m/m² dimension2 與曲線dimension1比較（須先證所用criterion）。 | 實讀／必例，cusp的具體證路由打厚決定後展開。 |
| G323-15 irreducible germ 的接口 | 非空 analytic germ irreducible iff不能分成兩個proper analytic subgerms；iff I_X prime。有限分解、唯一到排序屬局部定理。 | O01 193–194／同頁，Def6.7.1、Ex6.7.1、Prop6.7.3；O03 91–92／同頁，II(4.4)–(4.7)。 | prime⇔irreducible 可短證，需prime定義含proper。分解存在證用 Noetherian descending chains 並補finite-branching termination，不能只寫沒有infinite chain所以所有split必有限而不解釋。唯一用每irreducible component包含於某對方component。 | 實讀／選配必證（若採）；不能把 global irreducible 當每點locally irreducible。 |
| G323-16 一般大定理的邊界 | general local parametrization（irreducible germ、generic linear projection、proper finite covering off discriminant）、analytic Nullstellensatz、singular locus analytic。 | O01 184、187、194／同頁（多處明示不證）；O03 92–100／同頁，II(4.8)–(4.31)，有證明。 | 源有證明不等於本卷已證。建議只作 V158接口地圖，精確交代來源與先備，不在之後推導中以它們壓過缺口。若B-02要求本卷全證，須增加有限整環擴張、primitive element、discriminant、radical=prime intersection的先備責任。 | 實讀／接口敘述；不把 O01「略證」塗成已覆蓋。 |
| G323-17 自編題及解答 | 至少 4題：判正規座標、實作除法、根的monodromy、方程與理想區分；node/cusp 比較題附解。 | 前列源責任，自編題。 | 解答應有 explicit matrices／q,r／path root continuation／Taylor degree反證，不能只答「由準備定理」。 | B-04必交。 |

## Ch.324：層、局部環、解析空間接口

| 責任 ID／落點 | 定義／結果、精確條件 | 來源：印頁／PDF頁／標號 | 必要證明、例題與核點 | 狀態／差異 |
|---\|---\|---\|---\|---|
| G324-01 local ring 與 residue | local ring是有唯一maximal ideal的commutative unital ring；`O_{C^n,p}` 的m_p同G323-02，residue field C；商局部環的極大理想與residue要核。 | O03 70／70，II(1.18)c；O01 180／180，Ex6.4.1。 | f↦f(p)是surjective ring map，kernel m_p；若 J⊂m_p，R/J local且maximal m_p/J；證商中a class unit iff原a∉m_p。空集／unit ideal另外處理，不把零環默認為有唯一maximal ideal。 | 實讀／必證（簡潔回扣）。 |
| G324-02 Noetherian 芽環 | 每個 ideal I⊂O_{C^n,p} finite generated。n=1所有非零ideal為(z−p)^k，n≥2一般非PID。 | O01 181／181，Thm6.4.1；O02 74／80，Thm4.5.9；O03 81／81，II(2.7)。 | 完整 induction：非零I選g，coordinate change+preparation使P∈I；J=I∩O_{n−1}[w] finite generated（Hilbert basis lemma須正文有短證／既有已核先備）；f∈I division f=qP+r，r∈J，故有限生成I。選 O03 remainder coefficient submodule proof則需證 Noetherian module lemma，不能省到來源附一句。 | 實讀／必證；B-02確認採Hilbert-basis還是module route。 |
| G324-03 UFD 僅按需 | O_{C^n,p} factorial，但商O_{X,p}不保證domain或UFD。 | O01 182／182，Thm6.4.2；O02 72–74／78–80，Prop4.5.3、Thm4.5.6；O03 82–83，II(2.8)–(2.10)。 | 若G323-10採general reduced polynomial theorem，UFD須前移Ch323，附Gauss lemma、irreducibility transfer完整證明；若不採，這裡僅接口陳述及node商有zero divisors反例。 | 實讀／依依賴選配；不能默默以ambient UFD推quotient UFD。 |
| G324-04 presheaf／sheaf | 每個open U給ring F(U)、restriction identity及composition；sheaf有compatible local sections的唯一gluing（包含empty open convention）。 | O03 65–67／同頁，II(1.1)–(1.7)。 | 先以 O_U(V)=O(V) 檢restriction／glue；證holomorphic為local property。例不連通U上的constant presheaf不能glue不同常數，locally constant sheaf可。這是讀者能實際辨識定義的最小例。 | 實讀／必定義及例；不擴展完整étalé-space equivalence。 |
| G324-05 stalk 與sections的量詞 | `F_p=lim_{U∋p}F(U)` 即共同小鄰域相等的classes；s_p=t_p對所有p∈U可推出s=t；只在一點相等只保證局部同。 | O03 67–69／同頁，II(1.8)及sheaf-space說明；O01 167–169／同頁。 | 具體核O_U,p等於Ch323的芽環；sheaf identity axiom拼起所有局部相等。surjective sheaf map指all stalk maps surjective，不能據此宣稱每個U的section map onto。 | 實讀／必證；先定義再使用商層。 |
| G324-06 ideal sheaf | 對closed analytic X⊂U，`I_X(V)={f∈O(V):f\|_{X∩V}=0}`，為O_U-submodule／ideal sheaf；stalk=I_{X,p}，p∉X時stalk=O_p。 | O03 99／99，II §4.4、式4.28；O01 183–184／同頁。 | 證sheaf gluing及stalk equality，包含p∉X可縮到避X；切勿將V上某個方程ideal自動同所有vanishing sections。 | 實讀／必證。 |
| G324-07 structure sheaf與商 | reduced analytic subset的 `O_X=(O_U/I_X)\|_X`，這裡商是**quotient sheaf**；每個stalk `O_{X,p}=O_{U,p}/I_{X,p}`。sections是 locally ambient-extendable functions，未保證一個global ambient extension。 | O03 67–69、99／同頁，II(1.7)–(1.11)、(4.28)；O01 184／184。 | 直接定 locally extendable函數的sheaf，證restriction map的kernel是I_X且stalk surjective，得stalk quotient；這樣避免未講sheafification也可嚴格定O_X。不得把 `O_X(V)=O_U(V)/I_X(V)` 對任意V寫成定義。 | 實讀／必證；商層與商sections是核心易錯點。 |
| G324-08 三種local rings | smooth graph→C{t_1,…,t_d}；node X={zw=0}→C{z,w}/(zw)；cusp→C{z,w}/(w²−z³)。 | O01 184–186、195；O03 99、101，II(4.28)、(4.32)。 | graph商由restriction／Hadamard factor得；node vanishing ideal=(zw)：在兩軸消失迫使power series每項含z與w。cusp ideal用division by monic w²−z³，餘A(z)+wB(z)，代t²,t³後偶／奇powers分離，A=B=0。這同時完整核cusp quotient，不借general Nullstellensatz。 | 實讀源概念＋自行推導／必worked例。 |
| G324-09 cusp normalization 例接口 | `ν:t↦(t²,t³)` 為cusp的holomorphic bijection到局部像，pullback將local ring嵌入C{t}，image為C{t²,t³}，不含t。 | O01 195–196／同頁，Ex6.7.5、Ex6.7.5（例／練習標號並存需區分）；O03 98–99，II(4.27)。 | 證單射及逆連續：t=w/z於z≠0且\|t\|²=\|z\|；t非image因非constant最低order至少2。故holomorphic bijection未必isomorphism of analytic spaces；逆t作集合函數連續卻非O_X-section。不把本例封成general normalization theorem。 | 實讀／必完整例，承接V158動機。 |
| G324-10 ringed／locally ringed space | (X,O_X)含topological space與sheaf of rings；morphism含continuous f及sheaf map `f^{-1}O_Y→O_X`，stalk方向反轉；locally ringed要求stalk maps local。 | O03 70–71／同頁，II(1.19)–(1.22)；101–102，§5.1、(5.1)。 | 對analytic subsets先用局部ambient-extendable F，定 `F_p^#:O_{Y,Fp}→O_{X,p},[g]↦[g∘F]`；證代表元無關、消失ideal送入、local且composition逆序。例node兩branch與cusp ν直接算image。 | 實讀／必定義與證；f^{-1}O_Y與f^*O_Y模的張量概念不可混叫，後者未需求。 |
| G324-11 reduced complex space | 採本卷最小範圍：Hausdorff且可數可窮／局部緊的locally ringed space，局部同構至(reduced analytic X,O_X)；complex manifold是smooth特例。 | O03 102／102，II(5.2)；123／123，(9.8)後明說reduced scheme與Def5.2等價。 | 以two charts在overlap保structure sheaf的holomorphic transition作可操作版本；強調空間含structure，不只是零點集合。O03這個「complex space」專指reduced；正文標「約化複解析空間（本章約定）」以防與V158的一般術語混淆。 | 實讀／接口定義；不展開gluing存在定理。 |
| G324-12 nilpotents 的必要辨識例 | 一點X={0}有兩種local model：C{z}/(z)≅C與C{z}/(z²)≅C[ε]/(ε²)；同底集合、不同structure；後者非reduced。 | O03 70、122–123／同頁，II(1.18)e–f、(9.4)–(9.9)。 | 完整計算class a+bz，z≠0 class但z²=0，units iff a≠0；reduction除nilradical回C。不把C{z}/(z²)當「所有一點上值函數環」，值函數看不到ε。 | 實讀／必worked接口例。一般nonreduced analytic spaces留V158；Demailly稱analytic schemes。 |
| G324-13 coherence 的真正意思 | F為O-module sheaf；locally finite generated須同一neighborhood的一組sections生成**其上每個stalk**。coherent另要求任finite family的relations sheaf locally finite generated。 | O03 86–89／同頁，II(3.8)–(3.12)、(3.19)。 | 不准說「all stalks Noetherian⇒coherent」；兩者量詞不同。先證例relations of(z,w)在C²為O·(−w,z)：za+wb=0，z=0得b(z=0,w)=0，故b=zc，a=−wc。此例只證此relations，她不能代替一般Oka theorem。 | 實讀／必定義及計算；Oka完整證留V158。 |
| G324-14 finite presentation與Oka接口 | Oka：complex manifold的O_M coherent；analytic subset的I_X coherent；O_X coherent。由coherence局部有finite presentation `O^p→O^q→F→0`。 | O03 87–90／同頁，II(3.11)–(3.20)；99–100，(4.29)；105，§5.2。 | 本卷只給準確定義、relation例和將來用途；三個general coherence結果明列為V158承接，無需在本卷依賴其證明。若使用「analytic model由coherent ideal」的一般nonreduced定義，只作接口宣告。 | 實讀／接口敘述。不得寫作本卷已證Oka／Cartan。 |
| G324-15 可交V158的knowledge contract | 已知：芽／單位／local／maximal／residue；Weierstrass prep/division（本卷全證）；concrete vanishing ideals及quotients；sheaf gluing/stalk；analytic pullback；reduced/nonreduced差別；coherence定義及一個relations例。 | 上列逐項。 | 尚未在V25證：general analytic Nullstellensatz、general local parametrization、singular-locus analytic、general coherence／Cartan A/B、normalization／resolution／Remmert、sheaf cohomology。V158接收不能標這些已通過。 | B-02正式卷界承接點。 |
| G324-16 自編題及解答 | 至少4題：查sheaf gluing、node zero divisors／units、cusp pullback不是onto、double point nilpotent；可加relations kernel題。 | 前列源責任，自編題。 | 各題需literal rings、maps、kernel/image與代表元良定性；答「顯然」不算。層題給可貼compatible sections並完成唯一gluing。 | B-04必交。 |

## 跨書差異與不得自動繼承的斷言

| 差異 ID | 原文位置／差異 | 本卷處理與影響 |
|---\|---\|---|
| VAR-REG | O02印76/PDF82將regular描述為鄰域homeomorphic to C^k的域；O01 p185與O03 p98要求holomorphic graph／complex submanifold。 | 只採後者作正式定義。cusp t↦(t²,t³)是topological disc的反例，說明topological criterion不足。O02之sheet／simple-root證法仍可用，不據其topological措辭判regular。 |
| VAR-RED | O03 II(5.2) p102 的complex spaces為sheaf of actual functions，II§9 p122–123才放nonreduced quotient；現代「analytic space」常可含nonreduced。 | 本卷明寫reduced約定並列double-point例。V158的一般定義待該卷定界，不能拿本卷reduced定義去限制V158。 |
| VAR-DISC | O01 Thm6.3.3 p178–180之Δ是按geometrically distinct roots的set discriminant；一般 polynomial discriminant把multiplicity算入，P=Q²時可恆零。 | 書稿優先只用squarefree polynomial discriminant，或具體二次式，先說明squarefree。不能從任意P的discriminant≡0推全部點singular。 |
| VAR-EMPTY | O01 Thm6.3.3文字令m∈N，但沒有明列至少一根；f≡1使空root case需m=0或另加非空假設。 | 若泛用須加「某纖維有根」或允許m=0。本卷Weierstrass degree≥1的local setting自動有根；不原樣推廣。 |
| VAR-PRIME | O03 II(1.18)a措辭未明列I≠R；II(4.5)配irreducible nonempty germ時proper隱含。O01 Ex6.7.1有I≠O_p。 | 正文prime明列proper；empty germ、zero ring獨立處理。 |
| VAR-KERNEL | O01把核寫成K(z,barζ)，Hilbert inner product第一slot線性；若轉寫K(z,w)必同時移動共軛。p164 Ex5.2.9寫z^α/c_α，c_α為norm而非multiplier。 | 所有變換公式、ONB norm現算，不靠文字抽取的overbar；已視讀p164確認。 |
| VAR-PROOF | O01 Prop5.2.5 p164最後只展示全和C–S上界便說uniform convergence。 | 展開uniform-tail證明，或model domains用explicit absolutely convergent series，不把此短步當已完整核過。 |
| VAR-DIV | O01 division uniqueness放Ex6.2.10；O02也放習題；O03 p80直接以k roots及degree證。 | 本卷完整證multiplicity版本，不能把重根當不同點數。 |
| VAR-BOUND | O03 II(2.3)有固定adapted polydisc的bounded division estimates；O01／O02主要是germ existence+uniqueness。 | G323主定理採germ版本。除非需求明示，不把C不依f的估計擴成不依domain／P。 |
| VAR-GLOBAL | O01 p193例 `w²=z(z−1)²`、O03 p102例 `y²=x²(1+x)`：globally irreducible但node處local reducible。 | 若引irreducibility，先標local/global；不在本卷例子里自動以local branches判global可約。 |
| VAR-LIMIT | 來源O01明示許多general analytic-set／Puiseux結果不證；O03則有較長代數證明。 | source-read≠成書proved；依V25/V158分流，只在本卷所需具體範圍內全證，general results可精確列接口，不偷作既有正文前提。 |

## B-02／B-03 待主控固定的最小選擇

1. Ch.322 建議主線固定「Bergman space→正交單項式→D^n/B^n核完整計算→biholomorphic transformation→proper/normal-family不等價」。Szegő/Hardy boundary kernels不在本表必需範圍，若加會新增smooth boundary、boundary trace與Poisson先備。
2. Ch.323 不等 Ch.324才定germs；建議在Ch.323起首一次定義，Ch.324沿用。反之必須整卷重排依賴，不能正文先用後定。
3. 決定general squarefree hypersurface／UFD證明是否採。若採，UFD/Gauss/resultant先備前移Ch.323；若不採，保留Weierstrass full proof及quadratic/node/cusp完整例，general local parametrization等明列V158接口。
4. Noetherian proof選Hilbert-basis route（短證附本卷）或finite module route（需lemma）；不可未核依賴既有交換代數卷的已通過標籤。
5. Ch.324 reduced-analytic-space接口＋nonreduced double-point例；general coherence理論留V158。此分流由分卷表支持，不等於取消本卷local-ring／sheaf定義責任。

## OPEN／UNKNOWN、通過條件與交接

| ID | 已核與未核 | 責任／下一步 | 是否阻B-01交付 |
|---\|---\|---\|---|
| OPEN-GEOM-B02 | 來源可完整支援三章；general analytic-set theorem深度、UFD/resultant採否未正式定界。 | 主控B-02固定上列選項並交獨立精修核。 | 否；阻相應B-04起稿。 |
| UNKNOWN-PRIOR-HILBERT | Riesz、Hilbert-space completeness、Tonelli、Cauchy/Montel、Hilbert basis/Gauss的既有正文逐項覆蓋未由本任務核。 | 主控提供實際落點；不足則在本卷補足真正需要的短lemma，不重啟凍結卷。 | 否；阻暗中依賴。 |
| OPEN-SOURCE-VARIANTS | regular definition、reduced convention、discriminant、uniform convergence細節已列。 | 打厚／精修後續核新正文確實採修正量詞，不能只標「已讀source」。 | 否。 |
| UNKNOWN-BODY-LOCATORS | 唯一正文尚未生成；表中落點為章內計劃，非已覆蓋證據。 | B-04 patch固定後追加實際definition/theorem/example/exercise/solution IDs與來源行／頁，逐一實核。 | 否；不可當B-05通過。 |
| UNKNOWN-MODE | 任務為獨立 geometry 擴充子任務；runtime model與High設定未見可核元資料。 | 主控記未核實，不以角色名／文字自稱切換。 | 否；正式角色模型適用性由主控照授權核。 |

交接 ID：`V25-B01-GEOMETRY-v1`。發送角色：Ch.322–324 來源責任／擴充準備 → 主控、B-02依賴設計與精修獨立核。方案：B 單一 Work；B-01相當來源逐項責任，未進B-04。唯一輸出本檔；附局部PDF視讀圖與機器文字抽取在source-text，只是核讀證據，不是正文。

B-01本範圍完成的標準：四來源hash與頁碼對上；每個擬納入的定義、命題、必要證明、worked例與練習有責任行；差異與unknown可恢復。此標準已達可送獨立核的程度，**尚無獨立數學簽核**。B-04 clearance前禁止起稿；之後也只改主控指定角色副本，不覆寫唯一主稿。禁止重做已核文獻取得、改章號、發布／推Git、解除其他卷凍結、以本表代替完整正文覆蓋或B-07唯一打厚終審。

排版欄位：ReadFlow R1為正式模板；本件僅Markdown來源責任報告，沒有成書LaTeX、配對PDF、版面修補或全頁視檢，不冒稱B-06完成。保存與送達由主控依既授權位置處理；本任務未作外部保存／傳送。
