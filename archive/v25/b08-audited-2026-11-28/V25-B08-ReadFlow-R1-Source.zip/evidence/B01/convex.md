# V25 B-01｜Ch.316–318 來源責任與依賴核讀

交接 ID：V25-B01-CONVEX-v1；2026-11-28。角色：擴充；本檔是來源責任紀錄及 B-02 建議，不是正文、精修通過或 B-07 終審。收到主控授權：本輪只做 B-01，等 B-04 clearance 才起稿。唯一可改路徑為本檔。未改主稿、模板、工具 ZIP、分卷表、文獻表、Git 或任何凍結卷。

## 1. 收件回執與固定輸入

已實讀 `v25-prep/V25-Literature-Review.md` 與 `project_sources/15-B-Work-v1.txt`。主控告知使用者已批准 O01–O04，故準備交接中「待確認」是歷史狀態，這次採四份公開稿；R01–R03、Q01–Q03 均未讀，也不宣稱其責任已核。章號依主控固定為 316–318，不重新從 1 起算。角色實際模型／推理設定：本任務工具未提供可獨立查證欄位，記未核實；不以角色名稱當模型證據。

| ID | 實取檔／版本 | SHA-256 | 本職責實讀範圍與頁碼規則 |
|---|---|---|---|
| O01 | `v25-prep/Lebl-SCV-v4.4.pdf`；v4.4，2026-05-31，248 PDF 頁 | `729cdb8a00685da581c0a67408b06fa2a375e02317e4937d363c70ca43718f77` | §1.4 印刷/PDF 32–36；§2.1 47–53；§2.2 54–62 作定義支援；§2.3 62–78；§2.4 相關定義與結果 78–88；§2.5–2.6 90–103。這些阿拉伯印刷頁與 PDF 頁相同。 |
| O02 | `v25-prep/Korevaar-Wiegerinck-SCV-2017.pdf`；2017-08-23，274 PDF 頁 | `46ac273899b346422ae3a86fa0969308bc104c05d5a673ad15be2577772f58f1` | Ch.6 印刷109–123／PDF115–129；§8.1–8.4 相關定義與結果，印刷145–155／PDF151–161；Ch.9 印刷175–188／PDF181–194。這些阿拉伯頁一律 PDF=印刷+6。 |
| O03 | `v25-prep/Demailly-CADG-2012.pdf`；2012-06-21，455 PDF 頁 | `d7c7654a7417e8322e5dcf8fe8ec818b4c1a18cf280b41f2df5a871b776d89a1` | Ch.I §6B–6D 印刷/PDF46–53；§7A–7C 53–60。這些頁印刷=PDF。§7B Kiselman 僅辨識定界，擬不納基本責任。 |
| O04 | `v25-prep/Boas-SCV-Fall2013.pdf`；2013-12-03，81 PDF 頁 | `ee29cb6c8a557ad63e25785ce4433b4099e46c87f16e2ce7a9c6697c69d5870f` | §3.2 印刷31–32／PDF33–34；§4.1–4.2.1 印刷37–41／PDF39–43。PDF=印刷+2。 |
| 流程 | `project_sources/15-B-Work-v1.txt` | `c16755a48b868b6ae1dd1704ccca1a0a61289ab8e81d32835c36acc155379e6b` | 本次只核單 Work 任務隔離、B-01–08 門檻與交接，未據此啟動 B-04。 |

核讀方法：以 PyMuPDF 逐頁抽取本地固定 PDF 正文，核對頁首印刷數字、節號、命題/習題編號與相鄰證明；下表的「隱含」是正文證明真正使用但未另立編號的命題。表中寫「證」代表來源有證明且已核到其路線；寫「題」代表來源僅出題，後續書稿仍須自行給完整解答，不能冒稱來源已給解答。

## 2. 全卷介面與共同記號（供 B-02 固定）

- 全卷先用 domain = 非空連通開集；不連通開集的結果逐連通分支說明。O02 有時把 domain 當 open set，不能無聲搬用。
- `O(Ω)` 是 Ω 上單值全純函數。`K ⊂⊂ Ω` 表示閉包為 Ω 內緊集；涉及 hull 的基礎定理先明說 K 是非空緊集。
- `δΩ(z)=dist(z,∂Ω)`，Ω≠C^n 時是正的連續有限函數；Ω=C^n 分開處理，不寫未定義的 −log∞。`δΩ(K)=inf_K δΩ`。
- 固定內側為 `r<0`，邊界 `r=0`，`dr≠0`。局部定義函數至少 C²；用三階 Taylor 餘項則明加 C³ 或 smooth。`T_p^{1,0}∂Ω={v∈C^n:Σr_{z_j}(p)v_j=0}`，複維 n−1。
- 固定 `H_r(p;v)=Σ r_{z_j bar z_k}(p)v_j bar v_k` 為全複 Hessian；`L_{r,p}=H_r|T^{1,0}` 為未正規化邊界 Levi 形式。Demailly 邊界形式除以 `|∇r|`，必須注明才可比較「值不變」；本卷預定不除，故只說正負慣性不變。
- psh 使用上半連續、值域 `[-∞,∞)`、每條複直線限制次調和的定義；是否允許恆 −∞須明說。嚴格 psh 於本卷需要的 smooth 函數採 Hessian 正定。局部平滑化只在縮域上做。
- 本卷 pseudoconvex 預定指有**連續實值 psh exhaustion**；Levi pseudoconvex 僅對 C² 邊界定義。兩者等價須證，不把邊界測試當非光滑域定義。
- strong/strict 邊界偽凸與「有嚴格 psh exhaustion」不同：所有 C^n 中偽凸域可有嚴格 psh exhaustion，並非都具強偽凸邊界。
- Ch.316 用 313 的 Cauchy 導數估計、局部一致收斂與恆等定理，以及 314 的 Hartogs。Ch.317 承接 hull 但 psh 應在本章自給必要定義/證明。Ch.318 用 317 的 Levi 測試，給 319–320 的域與權重幾何，並向 322 提供球、多圓盤、Hartogs 三角形的已算模型。不得在 316/317 提前用 320 才證的 Levi 問題逆向來支撐本章證明。

## 3. Ch.316 全純域：逐項來源責任

| ID／預定落點 | 原文精確定位（印刷；PDF） | 原文內容、條件、證明與需覆蓋責任 |
|---|---|---|
| 316-D01 局部延拓的正確量詞 | O01 Def.2.1.1、Rem.2.1.3 pp47–49；PDF47–49。O02 Def.6.1.1 p109；PDF115 | 不存在共同的 W,V：W 連通開、W 不包含於 Ω、空≠V⊂Ω∩W 開，使**每個** f∈O(Ω) 可在 W 找 F 與 f 在 V 相合。O02 逐交集分支的表述作交叉核對。需把「函數依 f 而選；V,W 共用」寫清。 |
| 316-E01 裂平面 log 的警戒 | O01 Rem.2.1.3 pp48–49；O02 §6.1 p109；PDF115 | 主支 log 可從裂口單側局部延拓，但不能讓上下兩側同時在同一較大平面域拼合。責任是說明為何不能以「所有函數不共同延拓到 Ω 的真超域」當定義。不是聲稱裂平面非全純域。 |
| 316-E02 C 與產品域 | O01 Exer.2.1.1、2.1.3–4 p48；O02 Ex.6.1.2(i–ii) p110；PDF116 | 平面任意域、各平面域之有限 Cartesian product 均為全純域；邊界 b 的某座標 b_j 在對應域邊界，用 1/(z_j−b_j) 阻斷。C^n 無邊界另說。來源題須給解，不能只列結論。 |
| 316-E03 球 | O01 Ex.2.1.2 p47；PDF47 | 每個球面 p 以酉變換化為 (1,0,…,0)，用 1/(1−z_1)。證明要取 W 中跨邊界路徑之首出點，在對應 Ω∩W 分支上沿路逼近；不能說邊界 p「屬於」開交集分支。 |
| 316-E04 任意凸域 | O02 Ex.6.1.3 pp110–111；PDF116–117；O01 Exer.2.1.7 p48 | 分離/支撐實超平面 `Re ℓ(z−b)=0`，域在嚴格一側，故 `1/ℓ(z−b)` 全純且在 b 發散。需交代 ℓ 是複線性、Re ℓ 是該實線性泛函，以及 ℓ 零集不碰域。不依賴 Levi 問題。 |
| 316-E05 非例與 Hartogs 介面 | O01 Thm2.1.4/Cor2.1.5 pp49–50；O02 Ex.6.1.2(iii)、6.1.4 pp110–111；PDF116–117 | n≥2 中穿孔域、連通的 D\K（K 非空緊、位於 D 內）非全純域；一般 compact-hole 用 314 已證版本並列連通條件。Hartogs figure 的填充與「全純凸包」不同，記號不能都用無下標帽子。 |
| 316-D02 holomorphic hull | O01 Def.2.6.1 p98；O02 Def.6.3.1 p113/PDF119；O03 I(6.5) p47/PDF47 | `Khat_Ω={z∈Ω: |f(z)|≤sup_K|f|,∀f∈O(Ω)}`；hull 所在域不可省。全純凸即每個緊 K 的 hull 在 Ω 緊。不是所有 K 都等於 hull。 |
| 316-H01 hull 基礎代數 | O02 Prop.6.3.4 p114/PDF120；O03 I(6.6)a,b,e p47 | K⊂Khat；相對 Ω 閉；單調、冪等；Khat⊂實凸包(K)，故有界；全純映射 h 有 h(Khat_X)⊂h(K)hat_Y，雙全純為等號。證：定義逐項、exp ℓ 分離。相對閉+有界不足保證 Ω 內緊。 |
| 316-H02 分離放大（隱含核心） | O02 (6.3.4) p114/PDF120；O01 Exer.2.6.14 p102 | a∉Khat，可取 g(a)=A，sup_K|g|<ε：挑分離 f，取高次方並常數縮放。要處理 A=0 和 sup_K=0。此為後續插值、單一不可延拓函數的動力。 |
| 316-E06 analytic disc hull | O02 Def.6.3.2、Ex.6.3.3(i–ii) p114/PDF120；O03 I(6.6)c,d p47 | φ 連續於閉盤、內部全純、閉盤像⊂Ω，則 φ(閉盤)⊂φ(圓周)hat_Ω，由 f∘φ 最大值原理。定義的邊界是參數圓周像，不必等於像集合的拓樸邊界；本節可允許常值映射作退化盤並說明。 |
| 316-E07 同一圓不同 hull | O02 Exer.6.12 p122/PDF128；Ex.6.3.3(i) p114/PDF120 | 圓 K={|z|=r} 在盤中 hull 是閉盤；在環域 ρ<|z|<R 中，用 z 與 1/z 得 hull=K。說明 hull 是相對函數代數，並為 321 的 Runge 區別預備。 |
| 316-E08 非緊 hull | O02 Ex.6.3.3(iii) p114/PDF120；O03 I(6.6)e p47 | Hartogs 域 D=({|z1|<1,|z2|<3}∪{|z1|<3,1<|z2|<3})；K={z1=2,|z2|=2}，Khat_D={z1=2,1<|z2|≤2} 非緊。需用延拓到 3-雙圓盤給包含，座標函數排除其餘點。替代例：C^n\{0} 的球面 hull 是閉球去原點。 |
| 316-L01 Taylor 半徑沿 hull 傳遞 | O02 Prop.6.4.1 pp115–116/PDF121–122；O01 Thm2.6.3 證 pp100–101 | K 緊、a∈Khat_Ω、f∈O(Ω)：Taylor 展開至少在 B(a,δΩ(K)) 收斂。以 K 的 λ-鄰域共同上界 M，所有最大內接多圓盤上 Cauchy 估計；導數仍全純，故估計傳到 a；取各 polyradius 聯集為球。證需交代局部一致收斂、λ<δ 與 compact neighborhood。 |
| 316-L02 帶權半徑版 | O02 Prop.6.4.1 第二半 p115–116/PDF121–122 | g∈O(Ω)、|g|≤δΩ 於 K；`D^α f ·g^{|α|}` 為全純，估計傳 hull，得 Taylor 半徑至少 |g(a)|。g 有零也有效；估計應用乘法式而非除以 g，避免除零。為 Cartan–Thullen 加強項保留。 |
| 316-T01 Cartan–Thullen | O02 Thm6.4.3 pp116–118/PDF122–124；O01 Thm2.6.3 pp100–101；O03 I(6.9),(6.11) pp48–49 | Ω⊂C^n：全純域 ⇔ 對緊 K 有 δ(Khat)=δ(K) ⇔ 全純凸 ⇔ Ω 為某一 f 的最大存在域。O02 另有 `|g|≤δ on K ⇒ on Khat` 加強等價。正文完整證明，不把逆向留成黑箱。C^n 與不連通情形另拆。 |
| 316-P01 正向證明 | 同上；O03 I(6.9) p48 | 全純域→距離相等：L01 若 hull 點更靠邊界，所有函數 Taylor 同時越界，違反 D01；距離相等→緊：hull 相對閉、有界、離邊界正距離。不能由有界相對閉直接跳緊。 |
| 316-P02 單一不可延拓函數 | O02 Thm6.4.3(iii⇒iv) pp117–118/PDF123–124 | 密集內點 a_ν，最大內球 B_ν；標準 exhaustion E_ν；取 ζ_ν∈B_ν\Ehat_ν；分離 g_ν(ζ_ν)=1、||g_ν||Eν<2^−ν；無窮乘積 Π(1−g_ν)^ν。需證 compact 上 log tail 收斂、非恆零（E1 上無零）、ζ_ν 零階≥ν；假設分支延拓 F 時選 a_νk 在該分支逼近 b，B_νk 留於分支，所有 F 的導數在 b 零，矛盾。這個「每一分支」步驟不可刪。 |
| 316-P03 可選插值證明補充 | O03 I(6.8),(6.11)b⇒c pp47–49 | 全純凸 compact exhaustion；離散點 z_j 配任意值 a_j；P_j 使前面點零且本點1，高次分離函數控制 compact tail，正常收斂。需先要求 z_j 互異，P_j 存在證明可用逐對線性泛函相乘；適合作完整證明型習題。 |
| 316-C01 雙全純不變性及運算 | O01 Exer.2.6.7–11 p99、2.1.2/4/5 p48；O03 I(6.20),pp52–53 | 用 hull 的雙全純等號得全純凸不變，再用 T01 得全純域不變；不可假設內部雙全純映射自動延到邊界。產品、有限交集分支、刪去非恆零全純 f 的零集亦給證。後者 hull 用 1/f 排除逼近刪除集，再靠原域全純凸排除原邊界。 |
| 316-X01 Levi 逆向的狀態 | O01 Thm2.6.2 p99/PDF99 明言略去逆向；O03 I(6.18) p51 明言證明後置 VIII；O02 §6.5 p118/PDF124 | 316 只能宣布後續問題與依賴箭頭。O01 不能當逆向已有證明的證據。應由 Ch320 的既定 L² 路線承擔一般偽凸⇒全純域；若 320 未承擔，必標外部定理/OPEN，不冒稱本卷已證。 |

## 4. Ch.317 偽凸與 Levi 形式：逐項來源責任

| ID／預定落點 | 原文精確定位（印刷；PDF） | 假設、證明與需要展開的責任 |
|---|---|---|
| 317-D01 USC／subharmonic | O01 Def.2.4.1 pp78–79、Prop2.4.3–6 pp81–82；O02 Def.8.1.1 p145/PDF151、Prop8.3.1 p150/PDF156 | USC、允許 −∞、局部圓均值不等式、比較原理；C² 時 Δu≥0 ⇔次調和。不是所有光滑函數皆可用 Hessian 測試而不說實值。必要證明要有：Poisson 比較→均值；Δ 條件→最大值原理；反向用二階 Taylor。 |
| 317-D02 psh | O01 pp83–85 Def.2.4.8 後續及 Prop2.4.9；O02 Def.8.4.1、Prop8.4.4 pp152–153/PDF158–159 | USC 且每複直線限制次調和；C² 實值時 `Δζ u(a+ζv)=4H_u(a+ζv;v)`，故 H_u≥0。需給這條鏈式法則完整計算；全 n 維實 Laplacian≥0 只保證實次調和，遠弱於 psh。 |
| 317-E01 可用 psh 與反例 | O01 Exer.2.4.18–24 pp84–85；O02 Ex.8.4.2 p152/PDF158 | |z|² 嚴格 psh；Re f、Im f pluriharmonic；log|f| 在 f=0 定義 −∞，psh，零外 pluriharmonic；|f|^η 對 η>0 psh。`|z1|²−|z2|²` 在 C² 實調和卻非 psh。需區分 log|f| 局部全純 log 只在無零的小單連通域。 |
| 317-H01 封閉操作 | O01 Prop2.4.7 p83、Exer2.4.15/24 pp83,85；O02 Properties8.4.3 pp152–153/PDF158–159 | 非負線性組合、有限 max、decreasing limit、凸非遞減 φ∘u；sup 家族須局部一致上有界並用 USC 正規化，未正規化一般不成立。有限 max 直接用均值，複合用 Jensen。要標 −∞ 相加/極限慣例。 |
| 317-P01 平滑化 | O01 Thm2.4.10 pp85–88；O02 Thm8.4.7 p154/PDF160 | 非負 radial mollifier、單位積分、support ε-ball；u_ε 在 Ω_ε={δ>ε} smooth psh，u_ε≥u、ε↓0 點態回 u；非局部有界下限先 truncation max(u,−1/ε)，或使用非恆 −∞的局部可積性。不可把縮域平滑化冒充 Ω 上單一全局平滑化。 |
| 317-P02 全純 pullback | O01 Cor2.4.11 p88；O02 pp153–154/PDF159–160 | 全純 F:U→V、u psh 於 V，則 u∘F psh，容許在某分支恆 −∞。smooth 時 `H_{u∘F}(v)=H_u(DFv)`；一般用縮域平滑化後 decreasing/pointwise合適極限。此證明先於所有 analytic-disc psh 最大值論證。 |
| 317-D03 exhaustion | O01 Def2.5.3 p92；O02 Def6.2.3 p112/PDF118；O03 I(6.12) p49 | 連續實函數 ψ、每個 {ψ<t}⊂⊂Ω；要同時控制有限邊界與 infinity。單有 ψ→∞於有限邊界不能處理無界域。C^n 例 |z|²，球例 −log(1−|z|²)。 |
| 317-D04 pseudoconvex／psh hull | O01 Def2.5.1 p90、Def2.5.3 p92；O02 Def9.3.1 p178/PDF184 | psh exhaustion 定義；psh hull 用 u(z)≤sup_K u 對所有 psh。Khat_psh⊂Khat_hol（|f| 或 log|f| psh）；psh hull 未必閉，定義只要求相對緊，不可照抄 hol hull「閉故緊」。一般兩 hull 相等是更深命題，不在此無證引用。 |
| 317-T01 內在幾何等價 | O01 Thm2.5.2/2.5.6 pp90–93；O02 Thm9.3.5 pp179–180/PDF185–186；O03 I(7.2) pp54–55 | proper Ω：連續 psh exhaustion ⇔−log δ psh ⇔psh convex ⇔ 任意閉 analytic discs 在 Ω 且邊界聯集⊂⊂Ω，則全盤聯集⊂⊂Ω。證明 exhaustion 控制 hull、最大值控制盤、用 directional radius 及 harmonic-majorant disc family 證 −logδ。不得把「單獨一個碰外部的盤、圓周在域」當違反此定理：必須有域內盤族或連續移動初始盤。 |
| 317-H02 directional radius | O01 Thm2.5.6 證 pp92–93；O03 I(7.2)d–e p54 | δ_c(z)=sup{r:z+ζc∈Ω, |ζ|<r}，|c|=1，δ=inf_c δ_c。−logδ=sup_c(−logδ_c)，最終函數連續故不用未正規化 sup 的錯誤一般結論。閉性步驟利用 compact rim 與 hull 控制，然後半徑可再增一點。 |
| 317-T02 hol convex⇒psh exhaustion | O01 Exer2.6.1 p99；O03 I(6.14) pp49–50 | 用 holomorphically convex K_ν exhaustion，各 annulus Lν 有有限分離函數 gν,a，取高冪令 Σ|g|^(2pν) 在 Kν≤2^−ν、在 Lν≥ν，求和 smooth/real analytic psh exhaustion。需對各階導數收斂給 Cauchy 估計或用 O02 Thm6.5.5 的 −logδ 路線，不只由函數一致收斂聲稱 smooth。 |
| 317-T03 全純域⇒偽凸 | O02 Thm6.5.5 pp120–121/PDF126–127；O01 Exer2.6.1 p99 + Cartan–Thullen | 主選 T02 或 O02 盤族+Cartan–Thullen加強距離版本；必可追到316結果，不依賴 Levi 問題逆向。無界域 exhaustion 加 |z|²，例如 `|z|²+max{−logδ,0}`。 |
| 317-T04 局部性與運算 | O01 Lem2.5.7 pp94–95；O02 Thm9.1.3 p177/PDF183、Thm9.3.5 pp179–180；O03 I(7.3),(7.7) pp55,58 | 任意交集之內部（逐分支）、遞增聯集、有限產品、全純逆像、雙全純不變。局部邊界偽凸⇒全局：−logδ 在邊界 collar psh，挑徑向凸增長 χ 大於內部壞集合上的 −logδ，取 max 拼全局 exhaustion。無界域不能只用緊邊界選共同 ε。 |
| 317-T05 smooth strict psh exhaustion | O02 Thm9.2.1 pp177–178/PDF183–184；O03 I(7.2)e⇒a p55 | O02 有 β≥m 且最小 Hessian eigenvalue≥μ 的加強構造，m,μ 局部有界；以 compact annuli 上平滑積木、局部有限和、係數逐級支配負 Hessian。供320權重責任；若320只需基本存在性，正文至少完整基本構造，強化項可列明用法後移附證，不能僅引用 Richberg（另需大量先備）。 |
| 317-D05 實/複 tangent | O01 Def2.2.1–3 pp54–56、§2.3 pp62–66；O02 Def9.4.1–5 pp181–183/PDF187–189 | 定義函數、實切空間 ker dr、複切空間 ker∂r；複維n−1／實維2n−2；T^c 與複化的 T^{1,0} 需識別說明，不能相加空間維數混淆。IF theorem 得局部圖 `Im w=φ(z,bar z,Re w)`。 |
| 317-H03 定義函數換元 | O01 Exer2.2.2–3 p56、Prop2.3.6 p68；O02 Lem9.4.3 p181/PDF187 | 同一內側 r,s，s=a r、a>0；對切 v 有 L_s=aL_r。C² 的商可能僅 C¹（O02明言），不能無聲二次微分 a；可在固定邊界點用二階 Taylor 及沿切曲線，或先在 smooth 版證再補 C²。 |
| 317-D06 Levi 分類 | O01 Def2.3.5 pp66–67；O02 Def9.4.7 p183/PDF189；O03 I(7.10),(7.13) pp58,60 | 實值 C² r、r<0內側、切向 Hermitian 二次形式；半正/正定/存在負向/全零。weak 在本卷指半正而非正定的點；Demailly weak manifold 是另一用語。n=1 複切空間零維、邊界 Levi 條件空泛，需免得分類造成誤解。 |
| 317-P03 不變性 | O01 Thm2.3.8 pp70–72；O03 正規化形式 I(7.10) p58 | `H_{r∘F}(v)=H_r(DFv)`，F 全純；局部雙全純把複切空間同構，正負慣性不變。定義函數正縮放亦然；數值/特徵值非不變。這是**有邊界鄰域的局部雙全純 F**，與316只在域內的雙全純不變性證法不同。 |
| 317-P04 凸⇒偽凸 | O01 Exer2.3.7/9 p68；O02 pp182–184/PDF188–190 | 對實向量 v 對應複向量，`4H_r(v)=D²r(v,v)+D²r(Jv,Jv)`；若複切則兩實向量均實切，故實凸邊界測試推出 Levi≥0，strict亦然。不可只以複 Hessian 為 real Hessian 的「主子矩陣」草率比較。 |
| 317-L01 二階正規形 | O01 Lem2.3.9 pp73–74（smooth）；O02 (9.4.9–11) p184/PDF190 | 消去純全純/反全純二次項，用 w 的 holomorphic quadratic correction；混合 Hermitian 块用 *-congruence 化為±1,0；smooth時餘項O(3)，C²只保證o(|z|²)。需真算局部逆與內側方向，不把二階形等同實際邊界。 |
| 317-L02 Narasimhan | O01 Lem2.3.10 p75（題15提示）；O02 Lem9.4.8 p184/PDF190 | 在強 Levi 偽凸點可局部雙全純化為實強凸。證明要補法向實二階正性（例如先把 r 換 e^{Mr}−1 使全 H 正定，再消純項），不能僅消純項便由切向正定冒稱全 H 正定。弱 Levi 只有單點二階可半正，不能推出一鄰域可凸化。 |
| 317-T06 負 Levi→延拓 | O01 Thm2.3.11 pp75–77 | smooth邊界有負切向方向，正規化後 `Imw>−|z1|²+…+O(3)`，小 analytic disc 觸邊界、正法向平移盤在域內，凍結 rim 建 Hartogs figure 及額外變數厚化；共同延拓到邊界鄰域（對相應交集分支）。須處理來源2.1.7的 continuation vs single-valued 警語，主證用實際 Hartogs figure。 |
| 317-T07 Levi criterion（一般 C²） | O03 I(7.12) pp59–60；O01 Thm2.5.8 pp96–98（smooth）；O02 pp182–183只給必要與strong充分 | Ω C²邊界：內在偽凸⇔各邊界 L≥0。必要：用 signed distance r=−δ，H_(−log(−r))=H_r/|r|+|∂r|²/r²，限制切向取極限。充分主取 O03 的 C² 路線或先 O01 smooth 再清楚限制本卷定理正則性；不可用 O02 strong corollary冒稱已證弱一般版。 |
| 317-P05 smooth 充分的估計細節 | O01 Thm2.5.8 pp96–98、Exer2.5.16 p98 | graph定義函數使 Levi 半正沿水平層傳進內部；任意 v 分 tangent a+normal b，`H_r(v)≥−C|v||∂r(v)|`；`H_{−log(−r)+A|z|²}(v)≥x²−C x|v|+A|v|²`，A≥C²/4；再加小球邊界 barrier 使局部交集有真正 exhaustion。任意 r 的乘子必 a>0 才能 log(−ar)。 |
| 317-C02 strong 的 psh 定義函數 | O02 Thm9.4.10 pp185–186/PDF191–192 | bounded C² strong domain，`rtilde=(e^{Mr}−1)/M`，H=e^{Mr}(H_r+M∂r⊗bar∂r)；切向正下界+compact boundary吸收交叉項，得 collar 上全方向嚴格 psh。全域延伸用 convex cutoff與compact補正。未 bounded時單一 M 的存在需另證。 |
| 317-C03 Levi-flat | O01 pp77–78及Exer2.3.20–24；O03 I(7.13–15) p60 | 全零⇒兩側局部均 Levi半正；real hyperplane、Im f=0且df≠0、V×C^(n−1) 例。foliation equivalence需要 Frobenius+CR，擬作與CR/解析集合接口補註，不能當未證主幹。 |

## 5. Ch.318 典型域與邊界：逐項責任及算例來源

本章不是再講一遍317：每個模型都須實際算定義函數、複切空間、限制後 Levi，並說清楚非光滑處不能套用。球與多圓盤的映射結果只證本章幾何主題需要的版本；積分核/函數空間的完整應用交322。

| ID／預定落點 | 精確來源 | 假設、結果、證明與算例責任 |
|---|---|---|
| 318-M01 球 | O01 Ex.2.1.2 p47、§2.3 pp66–67；O02 Ex.9.4.2 p181/PDF187 | `r=|z|²−1`，∂r(v)=Σbar p_jv_j，H_r=I，所以每個非零複切向 L=|v|²>0；內部 barrier `−log(1−|z|²)` 的 Hessian 為 I/(1−|z|²)+rank-one/(1−|z|²)²，真給正性計算。 |
| 318-M02 polydisc、角點與 distinguished boundary | O01 §1.4 pp32–36、Exer2.6.4 p99；O02 Ex.9.4.2/Def9.4.7 pp181,183/PDF187,189 | D^n 的一般邊界是某些 |zj|=1，distinguished boundary 是全部 |zj|=1；只有一座標在圓周處是光滑face，可取r=|zj|²−1，切向vj=0使L=0。多座標同時飽和處非C¹，不可計為「Levi零」。explicit psh exhaustion可用Σ[−log(1−|zj|²)]。 |
| 318-M03 analytic discs 與球面 | O01 Def1.4.5、Prop1.4.6 p34；O04 §3.2 p31/PDF33 | 球面不含非恆常 analytic disc：||φ||²=1，酉變換令φ(0)=(1,0,…)，第一分量達最大⇒常值，餘零。bidisc face 有 `{p}×D`。這個對比本身不能直接證域內雙全純不等價，必補 properness+normal family。 |
| 318-T01 ball≠bidisc（強版） | O01 Thm1.4.4 pp33–36、Lem1.4.7 pp34–35；O04 §3.2 pp31–32/PDF33–34 | 無proper全純 F:D²→B²。bounded continuous map proper iff任意趨來源邊界序列之像cluster只在目標邊界。固定一變數近圓周，用Montel得disc maps極限落球面⇒常；導數局部一致趨零。要從「任意序列可選子序列導數趨0」提升全序列趨0，才可最大值推出偏導全零、F常值、違proper。無需假設 F 延到邊界。 |
| 318-C01 product generalization | O01 Thm1.4.8 p36（Exer1.4.5） | bounded U=U′×U″、兩因子複維≥1；bounded V 的邊界不含 analytic discs ⇒無proper F:U→V。擬作進階習題完整解；必保留 bounded 與目標no-disc條件，不能任意用在unbounded Siegel model。 |
| 318-M04 Cayley／Siegel上半空間 | O01 Ex.2.3.7 pp69–70；Exer2.3.11 p70 | `ζj=Zj/(1−Zn)`，`w=i(1+Zn)/(1−Zn)`；ball→S={Imw>|ζ|²}；`|ζ|²−Imw=(|Z|²−1)/|1−Zn|²`。必寫逆`Zn=(w−i)/(w+i), Zj=2iζj/(w+i)`，說 w≠−i 與丟掉球面北極。S unbounded，但有限邊界每點strong；不用「bounded strong domain」全域術語含混套此例。 |
| 318-M05 弱退化模型 | O01 Exer2.3.17(a) p77、Lem2.3.9 pp73–74；O02 Exer9.11 pp187–188/PDF193–194 支援高階邊界討論 | 主要題例 `Ωm={Imw>|z|^(2m)}`，m正整數。r=|z|^(2m)−Imw，r_w=i/2非零；H只有z項m²|z|^(2m−2)，切向v_w由∂r(v)=0決定；m=1處處strong，m>1於z=0 weak、其餘strong。需說此m族是對來源m=2題的自行推廣，未冒稱來源明列全m。 |
| 318-M06 bounded weak ellipsoid | O01 Exer2.3.17(a)及基本Hessian責任317-D02；O02 boundary criterion pp182–183/PDF188–189 | 自行衍生`Em={|z|²+|w|^(2m)<1}`，m≥2。dr在邊界不為0；H=diag(1,m²|w|^(2m−2))。w≠0時strong；w=0時|z|=1、切向vz=0，只餘w方向所以weak。這是smooth全局偽凸但非strong的有界例，適合承接319。完整計算由本卷負責，來源只供方法。 |
| 318-M07 mixed signature／shell | O01 Thm2.3.11 pp75–77；O01 p51殼域例；O02 Ex.6.1.2(iii) p110/PDF116 | `r=|z1|²−|z2|²−Imw` 於C³，原點複切vw=0，L=|v1|²−|v2|²，負向阻全純域。shell `a<|z|<b`（n≥2）：外球面用|z|²−b²，內球面為a²−|z|²，內L負定，方向必依域內側。不能拿同一符號r在內外邊界使用。 |
| 318-M08 Hartogs triangle | O01 Exer2.1.9 p51、Exer2.6.10 p99、Exer2.5.13 p94；O02 Exer6.4 p121/PDF127 | 按來源固定T={|z2|<|z1|<1}；映射 (z1,z2)↦(z1,z2/z1) 是T→D*×D雙全純，逆(a,b)=(a,ab)。故全純域與psh exhaustion由產品/雙全純不變得；origin不在T且邊界非smooth，不能套smooth負Levi tomato論證。`T∪Bε(0)`會讓全函數延拓到D²，需有Hartogs/Cauchy證，不以直覺判斷「補點更好」。 |
| 318-M09 Reinhardt完備／log-convex | O01 pp102–103 Exer2.6.17–21/Prop2.6.4；O02 Ex.6.3.6(ii) p115/PDF121；O03 I(7.4)d p56 | 定義旋轉不變、complete（閉座標多圓盤在域內）、log indicatrix用非零座標。complete Reinhardt：log-convex⇔全純域⇔某原點power series收斂域⇔偽凸；證需要單項式分離與完整條件。一般Reinhardt只log-convex不充分：C^n\{0}（n≥2）log圖R^n卻非全純域。 |
| 318-M10 analytic polyhedra | O03 I(7.4)a p55；O02 Exer6.3 p121/PDF127；O04 p41/PDF43 | 全域entire fj的`{|fj|<1}`逐分支偽凸/全純凸，可實加座標界組成有界例 `{|z1|<1,|z2|<1,|2z1z2|<1}`。一般僅在某ambient Ω上定義fj時，需Ω既有全純凸/偽凸與合適相對緊邊界條件，不可把任意開集都寫成analytic polyhedron而結論錯擴。 |
| 318-M11 Hartogs域 | O03 I(7.4)b pp55–56；O02 Exer9.6 p187/PDF193 | pseudoconvex baseω、u:ω→R連續，D_u={(z,w):z∈ω, |w|<e^(−u(z))}：若u psh則D_u偽凸；反向由方向半徑u=−logδ_D((z,0);w方向)得psh。選u=|z|²，實算r=log|w|+|z|²只在w≠0光滑，w=0不能套r；domain可用|w|²e^(2|z|²)−1描述側邊界。基本責任先限finite continuous u；u=−∞版本需額外控制無限fiber。 |
| 318-M12 tube域 | O02 Ex.9.1.1/Thm9.1.2 pp175–176/PDF181–182；O03 I(7.4)c p56 | connected D=H+iR^n：全純域⇔H凸。必要：−logδ只依x，psh⇔x局部凸；δ_D(x+iy)=dist(x,∂H)，用實域的邊界距離凸判準得到H凸。充分凸域。更強Bochner tube envelope=convex tube不是本章已證，來源只轉引。 |
| 318-E01 實凸性非雙全純不變 | O01 Exer2.3.13 p72及Thm2.3.8；O04 Ch4開頭p37/PDF39 | 自行衍生shear F(z,w)=(z,w+Az²)，A>1；F(B²)={|z|²+|w−Az²|²<1}，global polynomial inverse，smooth bounded strong。取(z,w)=(±t,At²)，兩點在域內；中點(0,At²)在At²>1時在域外，選1/A<t²<1。提供完整非凸例；不得只稱『shear通常不保凸』。 |
| 318-E02 強偽凸無boundary analytic disc的局部證明 | O01 Exer2.3.18 p77；O02 Def9.4.7後p183–184/PDF189–190 | 若強點附近有非恆常holomorphic disc落邊界，r∘φ=0；其二階 mixed derivative給H_r(φ′)=0且φ′切向，與strong矛盾。需處理φ′可能在中心零：非恆常映射在附近有非零導數點，strong開性讓矛盾有效。 |

## 6. 書深度的實際責任：例題、習題與解答設計（B-02提案，未起正文）

下面是可核的解答路線，不是以題數充當完整性的指標。每道若採用，B-04 必須完整計算/證明，B-05 實核正文落點。

| 組／難度 | 題目責任 | 解答必含的關鍵，來源 |
|---|---|---|
| 316基本1 | 圓在盤、環域的相對hull | 最大值給盤填充；z、1/z同時約束模等於r；316-E07。 |
| 316基本2 | distinguished torus在D^n的hull | 反覆一變數最大值原理填滿閉polydisc；座標函數給反向；O01 Exer2.6.4 p99。 |
| 316基本3 | U\{f=0}的全純凸 | hull相對U落在某U內compact，1/f阻止靠近零集，閉性封口；O01 Exer2.6.7 p99。需f非恆零且先證連通或逐分支。 |
| 316中階1 | hol hull與polynomial hull的差別 | 圓與環域；entire hull=polynomial hull由Taylor在compact一致近似，不依賴Runge黑箱；O01 Exer2.6.9 p99；O04 p39/PDF41。 |
| 316中階2 | 實圓與複圓的polynomial hull | C²中K1={(e^it,0)}填複盤；K2={(cos t,sin t)}自身polynomial凸，因hull先在實convex hull，1−z1²−z2²分離內部；O04 Ex.3 p40/PDF42。同拓樸不同複嵌入。 |
| 316證明1 | 任意compact K⊂R^n的polynomial凸 | entire Gaussian exp(−Σ(zj−Re qj)²)分離q；再用entire Taylor逼近化polynomial；O04 Ex.4 p40/PDF42。不必引Stone–Weierstrass。 |
| 316證明2 | 全純凸域離散插值 | 寫出P_j的有限乘積、分離高冪、compact正常收斂與每個值只由有限前項影響；O03 I(6.11) pp48–49。 |
| 317基本1 | u=|z1|²−|z2|²的調和/非psh | Δ_R4 u=0；複Hessian diag(1,−1)，限制z2線顯負Laplacian；317-E01。 |
| 317基本2 | log|f|在零點的定義與psh | 無零小盤局部log；有零分解f=(ζ−a)^m g，均值/局部可積控制；多變數沿複線，包括整條線f≡0；O01 Exer2.4.23 p85。 |
| 317基本3 | 正確交換定義函數 | 算s=ar在邊界切向的H，交叉項因∂r(v)=0消失；說a>0；若僅C²說明Taylor版處理；317-H03。 |
| 317中階1 | 未限制Hessian可負但邊界仍strong | 在sphere附近把r0=|z|²−1改r=r0−A r0²，A大、縮小collar保同側；切向H不變，法向H可負。實際在p=(1,0,…)算H=I−2Abar p⊗p；A>1/2負法向。直接拆掉「r一定psh」誤解。 |
| 317中階2 | psh pullback不要求F可逆 | F(z,w)=(z,zw)等、取u=|ζ|²，算Gram matrix正半；若F秩不足嚴格性可掉；317-P02。 |
| 317證明1 | 盤族的開閉性 | 先固定compact rim聯集K，所有域內盤落Khat_psh相對compact；參數極限盤仍在域；故E開且閉。不能只靠連續性說域內性對極限封閉；O02 Prop9.3.3 p179/PDF185。 |
| 317證明2 | 無界域局部偽凸的gluing | 額外徑向凸函數χ使壞內部集合上χ(|z|²)>−logδ；max在接縫鄰域恰為χ，因而psh；同時控制infinity；O03 I(7.7)p58。 |
| 317證明3 | smoothing annulus 的真正工作 | 展開KW9.2局部有限積木，逐層選M_j，不把cutoff乘積宣稱全局psh；逐compact有限性與最小Hessian下界完整核驗；317-T05。 |
| 318基本1 | Siegel變換正反與邊界失點 | 輸出正反公式、分母非零、norm identity；318-M04。 |
| 318基本2 | Em全部weak點定位 | 先驗dr≠0，再解切條件，不只檢H有零eigenvalue；318-M06。 |
| 318中階1 | 三個圖域的Levi分類 | O01 Exer2.3.17 p77的(a)Imw>|z|⁴、(b)Imw>|z|²Rew、(c)Imw>(Rez)(Rew)。每例用切向generator `(r_w,−r_z)`帶入完整2×2 H；不可只對z二次微分就把w混合項漏掉。需完整解，來源未給。 |
| 318中階2 | Hartogs三角形與外接球 | T≅D*×D；T∪Bε(0) Taylor/Laurent負項因小球消失，加Hartogs拼接填D²。對照一個圓周在T而中心原點不在T的盤，說明沒有域內盤族不能誤用continuity principle；318-M08。 |
| 318中階3 | nonlinear shear 的非凸strong例 | 318-E01中兩點與中點數值可取A=4,t²=1/2；算中點|w|=2>1，兩端原球點長t<1，再以局部Levi invariance證strong。 |
| 318證明1 | 產品域不能proper入球 | 在D²→B²版本完整寫normal family+cluster+derivative+maximum；一般產品版本作延伸題；318-T01/C01。 |
| 318證明2 | logarithmic凸性的必要完整假設 | 比較complete Reinhardt與C^n\{0}；後者log indicatrix全R^n但漏原點，Hartogs延拓直接否決；318-M09。 |

## 7. 跨書差異、原文短步驟及禁止直接照搬的地方

| QA ID | 原文／位置 | 影響、修正責任與後續核證 |
|---|---|---|
| Q316-01 | O01 p47球例說component「contains p」 | p是邊界，不能屬於Ω∩W開分支。正文寫p屬該分支的closure且有域內路徑逼近。此為敘述精度修補，不改球例結論。 |
| Q316-02 | O01 Thm2.6.3逆向p101以給定邊界p的發散序列結案 | 要拒絕任意局部續接分支，發散序列必在該分支；不能從「任選某序列趨p」跳到所有分支。採O02 pp117–118的dense balls及高階零乘積作主證，精修核對量詞。 |
| Q316-03 | O03 I(6.11)d pp48–49的「每個邊界點附近無界」簡短判準 | 存在性與量詞容易被誤讀成任意局部交集分支已處理；只取其確切離散插值構造，不以弱的『任意鄰域上無界』單獨代替316-D01。 |
| Q317-01 | O01 p66 footnote批評全H叫Levi；O02 Prop8.4.4 p153/PDF159叫complex Hessian or Levi form | 純術語差異，本卷固定H與邊界L的不同作用域，不宣稱其中一書命名無效。 |
| Q317-02 | O03 I(7.10)p58除以|∇r| | 其L在相同內側定義函數替換下值不變；O01未正規化L僅正縮放，數值不變的句子不得混用。 |
| Q317-03 | O03 I(6.13)p49「strongly pseudoconvex manifold」 | 這是smooth strict psh exhaustion存在性；C^n中與一般psh exhaustion等價，不等於strong邊界。正文每次說明對象是域內函數或邊界點。 |
| Q317-04 | O01 Def2.3.5 p66 bounded strong domain限制；O02 strong用strict | 本卷可對每個有限邊界點說strong。若稱whole strong domain，另註bounded或明定義，Siegel域不強塞進O01 bounded術語。 |
| Q317-05 | O02 Lem9.4.3 p181/PDF187商a只有C^(p−1) | C²情形不能對C¹乘子不加理由二次微分。先smooth證式再提供二階Taylor/切曲線處理C²；或定理明限smooth後在補註說C²需額外證。 |
| Q317-06 | O02 Lem9.4.8 p184/PDF190消純二次項後直接稱strict convex | 假設只給切向H正，法向H正性仍需補。可先用9.4.10的局部exponential trick再正規化；不能沿來源短證省略法向控制。順序不能形成循環。 |
| Q317-07 | O01 Thm2.5.8 pp96–98 | 這是smooth路線。graph r內部切向半正傳遞要明說導數不依Im zn；最後local f只吹原邊界，另加ball barrier才是真正局部交集exhaustion。不能簡寫f本身已對人工球邊界吹起。 |
| Q317-08 | O01 Exer2.5.16 p98乘子φ(p)≠0 | 要有φ>0（同內側）才使log(−φr)有實值意義；φ<0不合式。正文採正乘子。 |
| Q317-09 | O02 §9.2 pp177–178/PDF183–184 cutoff construction | vτ在外cutoff不psh，regularized βτ僅在較小sublevel psh。需逐層用下一塊strict Hessian支配舊塊在外層可能負值，局部有限性不能代替正性證明。原文t_i重標/省略索引也須自行一致化。 |
| Q317-10 | O02 Theorem9.3.5最後p180/PDF186 | 盤公式有e^(−p)，後文球半徑印成|e^p(0)|，與結論符號不一致；應全程|e^(−p(0))|，得d(a)≥e^(−Re p(0))⇒−logd(a)≤Re p(0)。採O01 pp92–93或O03 p54的符號重算。 |
| Q318-01 | O02 p183/PDF189「polydisc在其餘邊界點complex Hessian vanishes」 | 面上r=|zj|²−1的**全Hessian不零**，只是限制到vj=0的L零。多個座標飽和角點亦非C²，不只distinguished boundary才不光滑（n>2尤須區分）。正文以318-M02精確表述。 |
| Q318-02 | O02 Exer9.6 p187/PDF193把log|w|+h稱bounded psh exhaustion | 於w=0值−∞，未直接控制base邊界，不能當本卷連續實值exhaustion。使用O03正確的base exhaustion與fiber barrier拼合，先限h有限連續。 |
| Q318-03 | O03 I(7.4)b的u=−∞一般值域版本 | 無限fiber需額外|w|²控制與approximation細節。基本模型先限continuous finite u；若採一般版本必另列來源證明/依賴，不能把有限情況公式直接套。 |
| Q318-04 | O01 Exer2.6.19 p102關於power-series精確收斂域 | 「域」是正常/絕對收斂的內部域，不保證每個邊界點都發散（某座標零時尤需辨）。本卷Reinhardt結論採domain-of-convergence之標準內部意義，不擴稱逐點收斂集合。 |
| Q318-05 | O02 Exer9.11–13 pp187–188/PDF193–194 | 高階切向展開的非零leading polynomial及有限type須說明；flat/infinite type不能自動選有限k。符號Rew−Pk與前題Rew+Pk的subharmonic號也要重核。這組來源擬不作主幹結論，只提供進階閱讀界線。 |

## 8. 覆蓋邊界、依賴與 OPEN（不以表列當已完成正文）

### 8.1 已核內容如何落位

316 以「延拓定義→可辨識例/非例→相對hull→Taylor半徑傳遞→Cartan–Thullen全證→不變/產品/刪零運算」組成可獨立使用的核心。317 先建立psh工具，再給內在偽凸及全純域必要性，最後介紹C²邊界與Levi的可算性。318把同一套測試落到球、多圓盤、Siegel域、弱退化模型、殼、Hartogs與Reinhardt，不以『常見的例子』四字跳過算式。

**主控2026-11-28補充定界：** Ch320採KW global L²並需要smooth strict psh exhaustion；故317-T05必完整自給，不能後置。主控擬把Levi充分性放321；需明確區分(1)邊界Levi≥0⇒psh exhaustion與(2)psh exhaustion⇒全純域。兩者來源及依賴如317-T07/316-X01；本B01保留證據，不自行起稿或決定後置範圍。317若只證必要，318模型之全純域/偽凸結論用直接exhaustion、產品、hull及雙全純，不偷用尚後置定理。

### 8.2 明列的範圍排除／待B-02確認

| 來源項 | 處置及理由 |
|---|---|
| O01 §2.2完整實微分幾何、Hessian慣性全部練習 | 只保留定義函數、切空間、圖表示、實凸與複凸比較所需部分。完整實切叢形式不作本卷另章；必要轉換均在317說明。 |
| O01 §2.4 Radó Thm2.4.12 pp88–89、Dirichlet完整Poisson核推導 | Radó非本三章主幹，移313/解析集合組判定；Poisson/一變數次調和先備需先卷核可用，若無則317補必要均值證明，不能只稱『熟知』。 |
| O01 §2.1 Thm2.1.7 pp52–53 Kontinuitätssatz第一版 | 主要歸314延拓組；316引用時保留局部continuation與整個limit disc鄰域單值延拓的差別。此組不重證整段，但可用Hartogs版本建立317負Levi必要性。 |
| O02 §8.5–8.8 capacities、Green、Monge–Ampère | 不屬316–318基本責任；不假稱已逐項讀完或已覆蓋。 |
| O03 I§7B Kiselman minimum原理 pp56–57 | 原文已辨識：凸tube fibers、v不依Imz的特殊minimum仍psh；任意inf不成立。非主幹，若318要超出tube/Reinhardt基本例須重新定界，不默認納入。 |
| O03 I(6.15)非hol-convex weak manifold例p50、(6.16–19)Stein manifold | 只作術語範圍警戒與V158接口。一般complex manifold的weak pseudoconvex≠Stein，不把C^n定理推全體流形。本例原稿角度有排印疑點，不作正文主例。 |
| O03 I(7.11),(7.14–15) Levi-flat foliation | 可作讀者後續接口；若要完整證，必補Lie bracket/Frobenius先備與C^k正則性，不以一段話宣稱全證。 |
| O01 Exer2.6.17–21的完整Reinhardt Levi問題解鏈 | 原理與必要完整條件列入318；是否全部給構造power series的證明由B02定深度。若不採全部，必將未證等價方向明確標引用/後證，非說「以上已證」。 |
| O02 Bochner更強tube envelope、Kohn–Nirenberg型例 | 已定位源頭但原文只轉引或練習，不能聲稱本卷已有證明。基本tube iff convex可完整證；一般envelope與finite type列進階界線。 |
| O04 polynomially convex discs與Wermer引用p41/PDF43 | 不作本三章承諾；polynomial凸不保於任意域內雙全純影像，勿與holomorphic hull不變性混淆。 |

### 8.3 OPEN／UNKNOWN 與責任

| ID | 目前狀態 | 責任／解法與通過條件 |
|---|---|---|
| OPEN-316-PROOF | 已核KW完整Cartan–Thullen，未有正文 | 擴充B04完整起稿、打厚證所有乘積/分支步驟、精修核來源條件；唯一正文覆蓋落點與簽核待後階段。 |
| OPEN-317-SMOOTH | KW9.2來源足夠，但尚無本卷重索引完整證明 | 317承擔基本smooth strict psh exhaustion；需逐個compact處理局部有限和與Hessian負項吸收，先核最小核心，再各annulus。不可只引用Richberg而不給其先備。 |
| OPEN-LEVI-LOCATION | 主控擬將充分放321；兩義仍待清楚固定 | 主控B02固定邊界criterion充分是否也後置。一般Levi問題逆向依320 L²且321閉合；316–318不可循環。 |
| OPEN-REGULARITY | 主要來源O01用smooth，O03 C² theorem可補最低正則性 | B02固定全卷主statement取smooth或C²；若C²則充分用O03路線，三階normal form另加smooth，不混用O(3)；簽核時核每句條件。 |
| OPEN-REINHARDT | 基本完備log-convex責任明確；全部power-series構造深度未定 | 擴充提出完整章綱，精修核必要/充分及零座標；主控合稿確認不與313 convergence domain、322應用重複/斷裂。 |
| UNKNOWN-R01-03 | 原三本指定書全文未讀 | 不聲稱與Hörmander/Krantz/Range逐項比較已完成；本輪依使用者批准O01–04做責任；若新增原書不自動重啟、擴卷或改凍結。 |
| UNKNOWN-PREREQ | 本任務未實讀V24或前卷psh/實凸性先備 | 主控/精修在B02核固定先卷；必要內容本卷自給。不能因卷號大就假定所有先備已教。 |
| UNKNOWN-MODE | 工具無可核模型/推理欄位 | 如實保留未核實，不中斷核讀、不文字冒稱設定切換。 |

## 9. 交接與下一步

發送→接收：擴充／Ch316–318來源分工 → 主控與精修B-01合核。輸入固定如§1；可取檔為本檔與四份原PDF，已知本地路徑；hash見主控manifest/本檔末核驗。已核證據：三章核心定義、named/hidden lemmas、逐步證明路線、算例、最低假設、跨書差異與來源自身短步驟。沒有任何正文覆蓋落點已經驗收，沒有數學通過、排版通過、配對PDF或全卷終審。

唯一下一步：主控合B-01責任與B-02依賴定界；按已授權B流程推進，不逐節新增用戶批准。此代理**等候明確B-04 clearance**才起正文。若收到cleared，先收固定章綱/共同記號/稿件路徑及hash，回執後擴充→打厚→精修→主控合入。不得重寫313–315、319–324，不接管共享巨集、模板或唯一主稿。

通過條件：B-01僅代表來源責任可交下一步，須經精修實際核收；後續每一項應在正文找到定義/必要證明/算例或有界引用，所有OPEN有明示負責人與落點。禁止以本檔條目數、頁數、工具完成或來源名氣替代完整性。無外傳工具動作；此交接送達主控不等於使用者已讀或別角色已核收。
