# V25-B05-Integration-v1

Completed 2026-11-28. Content integration hands the fixed edition to layout in
this Work. B-05 includes the ordered read and the integration checks of the
shared A/B specification. The user selected the single-Work B variant, approved
the four public texts and authorized autonomous B-01–B-08.

## Baseline, responsibilities and freeze

Volume 25, *Several Complex Variables*, canonical chapters 313–324. The
Git-aligned curriculum SHA-256 is
`098aaacab85e330cb0493fc928916361c3fba09c0d36b3964f61c74ad2a2e1df` and the
reference table SHA-256 is
`4b3e0af09024a799744ee6fbb76ad68b95d82baeb020e5a6b8033cf00361a59d`.
Git baseline `20e626496c24518f133af6eb892c620ea52a3c59`, V24, ends at chapter
312. The sole editable V25 manuscript is `book/manuscript/ch313.tex` through
`book/manuscript/ch324.tex`. Earlier standalone chapter builds are historical
checkpoints. No earlier volume, tool ZIP, source/curriculum table or adopted
template was changed.

The four public source hashes and read locators are in B01. The volume design
and notation are in B02. The retained four-page calibration checkpoint fixes
the proof and exercise format. Four chapter authors and a separate B04
mathematics reviewer worked on the single canonical manuscript. API role
configuration requested the documented models and High where specified.
Independent execution-model inspection was unavailable.

## Fixed B05 output and inspection

| Evidence | SHA-256 or fixed locator |
|---|---|
| `b05-local.md`, full independent Ch313–315 read | `ec8651ec3491d67d402e9330b5120d23bb4885485d2bd62d494d2477db6413d6` |
| `b05-convex.md`, full independent Ch316–318 read | `b15b827ba100a4136c5961106d896b29156284e43c6d41f71ab5d7e49d3151bb` |
| `b05-analysis.md`, full independent Ch319–321 read | `a06f50f94888ccd3429432b4786726411c42ca10ae442c2294c4be3c7dc11a22` |
| `b05-geometry.md`, full independent Ch322–324 read | `f13c958d5d1879901fc34c0b0534f8d270762e0e40d71d4a5e82614be233264f` |
| `b05-cleared-structure.json`, chapter counts and labels | `d0922f339fbbf5d4a6e4e6c19a4795605b5b55c29e92970d347aeabd9f3f47dd` |
| `book/.build/b05-cleared/build-report.json`, 12 current source hashes | `e2dd9dbc4f573300aa55a8bcf392a232805190e24c383555e0f1fceb1566e10a` |
| `book/.build/b05-cleared/volume25.pdf`, 953302 bytes, 214 pages | `84f58bfaf2476e13af1d793e99e6b434a8c2bc2a62aa315118ba2ba3413ca766` |

The cross-reads covered complete chapter text including exercises and checked
the actual interfaces they depend on. Selected dependency checks include
product Cauchy before Taylor and Hartogs, Bochner–Martinelli orientation and
the Cauchy-transform sign before weak `d-bar` solvers, exhaustion and flat
growth before weighted solvability, then weighted solvability before Levi
sufficiency and approximation. The source audit has 81 numbered sections,
92 worked examples, 131 exercises and 131 solutions. Its structural report
records no duplicate label, unresolved cross-reference or uncited reference.
The mathematical checks are recorded separately in the four cross-reads.

The precise local-solvability conclusion and both late symbol definitions in
319, the explicit tube-domain equivalence in 318, the Hartogs triangle
coordinate convention in 322 and the scope of nearby regular pieces in 323
are the integrated versions. The printed statement of 318 was built from
`8e7db57790a4a689403cf82b46b4affd8b87d00076c2afb7dbbe4826cd5b33d6` in this
exact assembly. The previous chapter-only 318 pairing remains historical.

## OPEN and next handoff

The B05 PDF is the build for B06 to inspect. Its one overfull display in Ch315
and the short chapter-end pages are layout review items. The integrated
mathematics screen found no remaining blocking finding in the four
cross-reads. General coherence and analytic-space geometry remain V158
responsibilities. Higher-degree boundary regularity is outside the selected
route. Both limitations travel to B07.

The controller sent the fixed build path and hash to the layout agent in
this Work. The agent acknowledged the adopted R1 baseline and agreed to
check pairing before editing. The unique next phase is B06: linebreak and
geometry repair with style hashes retained, compile with converged
references and zero blocking diagnostics, and visually check every page.
Use `python tools/build.py --full --name b06-release` from the source
root with the stated XeLaTeX and font dependencies. Any mathematical change
returns to the content owners. No additional user decision is pending.
