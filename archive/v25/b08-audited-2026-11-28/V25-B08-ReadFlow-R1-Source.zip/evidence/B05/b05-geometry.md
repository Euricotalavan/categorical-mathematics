# V25 B-05 independent cross-read｜geometry role → Ch322–324

2026-11-28. Reviewer previously authored 316–318, not 322–324. Root requested read-only canonical cross-read, including root quadratic-normal-form addition in323 and late integral-closure/exponential-sheaf additions in324. All three chapter sources were read in full, in connected order; split outputs were followed by explicit reads of the truncated322 projection segment. This is a source-semantic B05 report, not paired-PDF QA, not the unique B07 final audit. No reviewed chapter was edited.

## Fixed sources actually read

| Chapter | Canonical source | SHA-256 at completion and repeat check |
|---|---|---|
|322|`v25-work/book/manuscript/ch322.tex`|`6c9c83dcd9e044674635e445f34ab7dbe37e8407c941399e5088f15673b6cf69`|
|323|`v25-work/book/manuscript/ch323.tex`|`c5decf73ae26c9f1384e87cd4b35673734aef2403d1de44dd23169b9029d3fb1`|
|324|`v25-work/book/manuscript/ch324.tex`|`0952d71d5436a0c4f02630c6dd2503eeeb87f34ce394d7f5104d35e1e2969b9b`|

Any later source change requires a bounded recheck of its actual delta; the listed whole-source reading does not automatically extend to a different hash.

## Findings

No blocking mathematical defect found in the read sources. Three low-impact integration/text issues remain for controller/author judgment:

| ID | Original and location | Effect | Suggested bounded change | Recheck criterion |
|---|---|---|---|---|
|GEO-B05-01|322 `lem:322-sphere`, line596 onward, repeats318 `prop:318-sphere-disc` with essentially the same full proof.|Logical result is correct; repeated proof does not add a new technique, and322 is described as using the geometry already prepared in318.|Replace lemma/proof by a recall and explicit ref to `prop:318-sphere-disc`, then use that reference in inequivalence proof. Keep322 properness/normal-family/whole-sequence derivative proof in full.|Both dependency label and proof text resolve;322 no longer implies boundary extension of a proposed biholomorphism. Optional editorial consolidation, not a math blocker.|
|GEO-B05-02|322 generalized triangle opening around line678 defines `H_m={|z|<|w|^m,0<|w|<1}` while316/318 use `T={|z2|<|z1|<1}`.|The domains coincide at m=1 only after swapping coordinate names. All formulas are correct internally; a reader following the old named model may transfer the Jacobian to the wrong coordinate.|Add one sentence: “For m=1 this is the Hartogs triangle of Chapters316 and318 after exchanging the two coordinates.”|Later Jacobian remains w^(-m), with map(z,w)→(z/w^m,w), rather than incorrectly borrowing z1^(-1).|
|GEO-B05-03|323 paragraph around line537 says “For these curves, the local dimension at their singular point is one, because every nearby regular piece has dimension one,” before general local-dimension theory is deferred to V158.|The worked loci and dimensions of regular graph pieces were proved. “Local dimension at a singular point” has not yet received a formal definition here; using the deferred general characterization as though it were already available blurs the boundary.|Replace first sentence by “In both examples every nearby regular piece has complex dimension one.” Then retain the following explanation of what general local-dimension theory in V158 adds. Alternatively explicitly declare the convention used only for these examples.|No general local-dimension theorem is used to prove singularity or cotangent calculations; both direct curve proofs remain intact. Low-priority definition precision.|

## Independent verification evidence

### 322: normalization, covariance, and connected applications

1. **First-slot convention:** `f(z)=<f,k_z>`; Riesz representative `k=overline{L(e)}e` is correct. Kernel definition `K(z,w)=overline{k_z(w)}` yields reproduction without a conjugate on f. Orthogonal-basis expansion of k_z has coefficients `overline{φ_j(z)}`, so K has φ_j(z)overline{φ_j(w)}. Conjugation direction remains consistent through covariance and projection.
2. **Evaluation/Hilbert closure:** repeated area mean is normalized by π^n r^(2n); Cauchy–Schwarz gives π^(-n/2)r^(-n). Compact convergence + local L² convergence identifies the global equivalence class correctly by a countable cover. Whole-space A²={0} is checked and prevents an unjustified always-positive kernel claim.
3. **Monomial completeness:** angular Parseval is first justified on an inner torus with a larger closed polydisc in the complete ball/polydisc. Nonnegative radial integration gives the exact norm series by Tonelli. Tail norms then prove completeness; orthogonality alone is not being mistaken for completeness.
4. **Constants:** polydisc norm π^n/Π(α_j+1), ball norm π^n α!/(n+|α|)! and simplex Jacobian factors are correct. Kernel sums give π^(-n)Π(1-z_jbarw_j)^(-2) and n!/π^n(1-<z,w>)^(-n-1), respectively. n=1 agrees. Grouping ball terms has absolute majorant Σ|z_j||w_j|<1, stronger than relying only on |<z,w>|<1.
5. **Jacobian:** real determinant |detF′|² gives unitary pullback J_F(g∘F). Covariance has J_F(z) and overline{J_F(w)}, not inverse or unsquared determinant. Scaled center checks agree with reciprocal volume.
6. **Punctured polydisc:** negative Laurent coefficients fail L² including exponent−1's logarithmic divergence. Fubini only gives almost-everywhere slice integrability; holomorphic parameter coefficients then promote their vanishing to every parameter. Fixed-contour Cauchy extension supplies joint holomorphy and preserves norm across the volume-zero hyperplane. No false claim that arbitrary holomorphic functions extend over a hypersurface.
7. **Least norm:** h−P_Uh solves the same distributional datum. Chapter319's distributional holomorphy is exactly the needed input to make the difference of any two L² solutions an A² function. The explicit examples give ball correction1/(n+1), polydisc1/2; nonconstant correction2/(n+2) vs2/3. The residual average2n/[(n+1)(n+2)²(n+3)] is correct and reduces to1/36 at n=1.
8. **Inequivalence:** bounded properness ensures all slice limits land on the sphere. The proof upgrades “every subsequence has a further subsequence with derivative→0” to full boundary convergence before invoking the maximum principle. No hidden extension of F to ∂D^n. n≥2 explicitly permits a different coordinate ℓ.
9. **H_m:** map(z,w)→(z/w^m,w), determinantw^(−m), kernel leading factor(wbarη)^(−m) are consistent. Central diagonal blows as|w|^(−2m), and this is explained by the Jacobian over a removable product puncture, not by an ordinary polydisc boundary limit. Monomial normπ²/[(p+1)(k+m(p+1)+1)] finite iff k+m(p+1)>−1 is correct. With integer k, q=k+m(p+1)≥0 precisely matches the displayed transformed basis. L^s threshold sℓ<2m+2 and equality divergence checked.

### 323: preparation, projection, and quadratic additions

1. Ambient germs are explicitly defined, ring operations typecheck under common restriction, and units/nonunits/maximal ideal are established before local-ring use in324. Total order versus chosen slice order is distinguished with computed coordinate changes.
2. Preparation fixes one contour uniformly in nearby parameters. Integer-valued zero count is constant; no labeling of individual roots is assumed. Power sums and the Newton recursion `j a_j=−Σ_(m=1)^j a_(j−m)s_m` correctly construct holomorphic coefficients. Joint holomorphy and nonvanishing of the unit use both contour quotients f/P and P/f rather than a fiberwise assertion alone.
3. Division's difference-quotient formula gives the degree bound on the remainder and joint holomorphy. Uniqueness counts root multiplicities; w^k example explicitly illustrates why distinct roots alone would fail. Exponential remainder has a normally convergent quotient justification.
4. Analytic subsets require equations around every ambient point, hence relative closedness follows. Ideals of chosen equations versus full vanishing ideals are separated; no general Nullstellensatz silently used.
5. Discriminant `det(s_(a+b))=(detV)^2` gives the root-collision locus. Nonzero-discriminant hypothesis is explicit; proper projection is established by a compact-base root-free vertical collar. Rouché establishes density near arbitrary points, so generic sheets suffice only under the declared hypothesis.
6. Smooth graph, crossing and cusp singularity arguments are direct. Cusp topological parameter has continuous inverse but nonzero-derivative submanifold parameter would contradict2q=3r. No inference from “gradient of this arbitrary equation vanishes” to singularity.
7. Root quadratic addition: D=a1²/4−a2 has finite positive orderm for a nonzero germ; local square root of its unit is justified by a convergent binomial series. Coordinate inverse w=b(z)η−a1/2 is holomorphic and invertible. Evenm gives two graphs, oddm gives injective normalization t→(t²,t^m), and the odd-order square obstruction correctly detects singularity form≥3. m=1 is smooth despite nontrivial sheet exchange. The original-coordinate m=4 and m=5 computations agree with their normal forms.
8. Irreducible analytic germ⇔prime vanishing ideal is proved with finite local equations and proper nonempty germ conditions. It does not assume factorization of all analytic sets.

### 324: quotient rings, sheaf distinction, and late additions

1. Coordinate ideal proof via f(z)−f(0)=Σz_j∫_0^1f_zj(tz)dt gives maximal ideal and residue field without assuming generators. Noetherian proof uses preparation/division plus a fully proved submodule lemma; it does not assume global or neighborhood coherence.
2. Smooth graph kernel(z−w²), crossing kernel(zw), and cusp kernel(w²−z³) are established directly. The cusp even/odd remainder proof yields exactlyC{t²,t³}={convergent series with no t term}; convergence, rather than merely formal grouping, is discussed. The matching pair crossing ring correctly permits zero divisors while remaining reduced.
3. Cusp parametrization gives a bijective continuous map but its inverse t cannot descend. Later integral-closure addition is sound: S=C{t} lies inFracR by even/odd splitting andt=t³/t²; both fields coincide. Everya+tb is integral by(T−a)²−t²b²=0. Conversely a pole in a monic integral equation has uniquely largest pole order in its leading term, so integrality forces holomorphy. No general normalization theorem used without proof.
4. Cotangent quotient m/(m²+I) has the required linear-term computation. Crossing/cusp tangent dimensions two and graph dimension one follow without invoking the general regular-local-ring criterion. Nilpotent double point has cotangent dimensionone but underlying reduced point dimensionzero, correctly distinguishing structures.
5. Presheaf and sheaf gluing definitions, stalk equivalence and equality conditions are explicit. The new exponential example is a morphism of abelian-group sheaves, not falsely of rings. Local logarithms are constructed, kernel is locally constant integers, and global sectionz onC* is excluded by integrating1/z. The sheaf quotient versus quotient of global sections distinction is thereby demonstrated with actual local lifts.
6. Structure sheaf consists of actual locally ambient-extendable functions; quotient formula is explicitly sheaf-theoretic, not every-open-set surjectivity. Holomorphic map pullbacks are well defined modulo vanishing ideals and contravariant with local stalk homomorphisms. The reduced-space definition states Hausdorff/second-countable and local analytic-subset models; nonreduced maps correctly require additional sheaf homomorphism data.
7. Coherence is defined with one finite list on a neighborhood working at every point, and relation sheaves for every finite family. The explicit relation(−w,z), finite exact sequence, and stalk/global-surjectivity distinction are proved locally; general coherent ideal sheaf/Nullstellensatz/singular-locus theorems remain declared V158 work.

## Dependency and verification limits

Actual matching labels exist for313 log-convexity,317 interior test,323 germ algebra/division/cusp/crossing ideal and324 cusp bijection. The source-semantic read does not replace full-volume crossref compilation, chapter314/319 theorem proofs, PDF pagination, all-page visual inspection or B07. This report does not authorize archival publication. The three optional text fixes above may be applied by root or the owning author; any application needs exact new hashes and a delta recheck.
