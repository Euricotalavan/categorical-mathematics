# V25 B-05 independent cross-read: Ch313–315

Review ID: V25-B05-LOCAL-DBAR-v1 · 2026-11-28. Reviewer: the separate dbar task, which authored Ch319–321 and did not author Ch313–315. Scope: read-only semantic and dependency review of the three canonical chapter sources. No manuscript edit was made in this review. This report is B05 evidence, not B07 whole-volume approval or PDF/visual approval.

## Actual inspected versions

| Chapter | Canonical path | SHA-256 at start and end of complete read |
|---|---|---|
| 313 | `v25-work/book/manuscript/ch313.tex` | `5487a18b8c06ef15d1e2503534f23de6967da2b5803afe69da110859b77080ce` |
| 314 | `v25-work/book/manuscript/ch314.tex` | `ce6a061dad0129db9d8ac9e3598ceb7b4fef9950c6855429453e37776768602e` |
| 315 | `v25-work/book/manuscript/ch315.tex` | `3170f7236ee8f8a71aaf41679c1a5e1d22330a0f22249cb3787ff1596203606f` |

Read all chapter sections, statements, proofs, examples and exercise solutions, including the added root-bound/separate-holomorphy argument, circular filling and annular interpolation, and all BM volume/boundary calculations. Re-read exact source segments: Lebl §5.1 pp157–160 (PDF same), KW §§10.5–10.6 pp201–204 (PDF207–210), Boas §2.7 pp23–26 (PDF25–28), and the author-selected Laurent/shell responsibility from KW §§2.6–2.8. Four approved source PDFs remain the ones pinned in B01; no uninspected original-book edition was substituted.

## Result and inspected evidence

No actionable mathematical defect found in these fixed versions. The conclusion is based on the following actual checks, not their prior status labels.

| Area / exact labels | Check performed | Result |
|---|---|---|
| `def:313-holomorphic`, `thm:313-cauchy` | Complex linear differential implies separate holomorphy and continuity; product formula initially uses joint continuity on a neighborhood of the closed polydisc. Every mixed boundary slice remains in that neighborhood. The later closed-polydisc version uses smaller radii and uniform continuity, avoiding boundary slice holomorphy. | Correct hypotheses and order. |
| `thm:313-taylor`, `lem:313-abel`, `thm:313-limits` | Coefficients first obtained on an interior torus; summable geometric majorants justify rearrangement. Radius independence follows coefficient extraction. Derivative estimates preserve factorials and positive smaller radii. Converse normal-series theorem uses continuity + separate limit holomorphy. | No circular use of unrestricted separate holomorphy. |
| `lem:313-root` | Checked positive regularization Hessian formula, submean in each coordinate, Fatou applied to nonnegative B−u_k, enlarged centered polydisc containing the original Q, excess-volume bound and finite compact cover. | The pointwise-to-local-uniform root bound is proved; not inferred just from Baire or separate continuity. |
| `thm:313-separate` | Baire E_j are closed on a complete closed disc and cover it by induction in the base variables. The bounded slab gives holomorphic coefficients; one-variable radius2s and root uniformization extend the series to the chosen point. k=0 is harmless and only k≥1 is used in roots. | Complete induction, no unstated local boundedness. |
| `thm:313-logconvex`, `thm:313-montel` | Positive radius enlargement handles zero coordinates; Hölder gives interior logarithmic convexity after enlargement; finite neighborhood majorants give normal convergence. Cauchy derivative bounds, finite equicontinuity cover, compact exhaustion and diagonal subsequence give Montel. | Correct. |
| `prop:314-parameter`, `lem:314-multilaurent` | Negative/positive coefficients use separate inner/outer contour radii. Product-annulus formula uses2^n sign patterns; minus inner kernel gives the correct negative powers. Coefficients are identified on actual admissible tori. | Normal convergence and contour choices justified. |
| `prop:314-radii`, `thm:314-shell`, `prop:314-circular-fill` | Connected positive radius set makes locally constant coefficient functions globally constant; small product annuli really lie in the domain by Reinhardt invariance. Disc-through-hyperplane test kills a negative exponent only after the full slice is in the domain. Each target point is strictly inside a positive-radii polydisc with torus in the source. | No general compact-hole theorem used prematurely. No incorrect claim that arbitrary Reinhardt holes fill. |
| `prop:314-moving`, `thm:314-figure` | Distinct checks for holomorphy of integral, agreement on wall/plug, and compatibility as contours increase. The 1/w example correctly demonstrates that an integral can be holomorphic yet fail agreement. | Correct gluing and uniqueness. |
| `thm:314-isolated`, `cor:314-zeros` | The figure is exactly the punctured polydisc, with positive-dimensional base and nonempty open plug. Extension glues even when ambient U is disconnected. Scalar zero-set statement does not claim a vector-valued zero cannot be isolated. | Correct. General compact-hole theorem explicitly deferred to321. |
| `thm:314-three-circles`, `eq:314-vertex-bound` | Rational slopes p/q may be negative; annular maximum principle applied to h^q w^(−p). Separate logarithmic convexity yields the stated vertex interpolation, without claiming it alone proves joint convexity. | Correct; sample truncation arithmetic also checked. |
| `eq:315-volume`, `eq:315-wedge-id`, `def:315-bm` | Real volume is interleaved dx₁dy₁…; Θ=∧(dbarζ_j∧dζ_j)=(2i)^n dV. Each omitted barred slot has even preceding degree, so dbarζ_j∧η_k=δ_jkΘ. | All integration signs match the stated orientation. |
| `thm:315-pompeiu`, `eq:315-pompeiu-area` | Positive outer/minus inner circle, integrable1/r singularity, dζ∧dbarζ=−2i dA. The area term is −π⁻¹∫f_bar/(ζ−z), equivalent to +π⁻¹∫f_bar/(z−ζ), the Ch319 solver. | Exact downstream sign agreement. |
| `lem:315-closed`, `lem:315-normalization`, `thm:315-bm` | Closedness uses cancellation n r^(−2n)−n r²r^(−2n−2); small-sphere normalization uses Stokes on the smooth numerator, then radial scaling and total variation for the error. Singular volume integral is absolutely integrable. | No unjustified differentiated singular kernel. C² boundary and C¹ neighborhood data stated. |
| `lem:315-density`, `ex:315-nonhol` | Contraction η_k=(2i)^nν_k dσ/2 yields constant(n−1)!/(2π^n). On unit sphere, barred parameter derivative at0 equals(n−1)ζ₁, giving(n−1)/n after multiplying barζ₁. | Correct distinction between reproducing holomorphic data and arbitrary boundary transformation. |
| Ch315 ↔ Ch319 period | In dimension2, Σbarζ_kη_k=−(barζ₁dbarζ₂−barζ₂dbarζ₁)∧dζ₁∧dζ₂. Since(2πi)⁻²=−1/(4π²), BM is +1/(4π²) times the Ch319 period form. Its S³ integral4π² therefore gives normalized BM integral1. | Apparent opposite constants are resolved by the actual wedge ordering; no semantic patch needed. |
| `cor:315-means`, `eq:315-l2` ↔ Ch319–321 | At ball center density equals reciprocal sphere area; radial integration yields ball mean. Square-root volume constant is(n!/π^n)^(1/2)r^(−n), agreeing with mean-value conversions used in320–321. | Correct and sufficient local norm-to-sup dependency. |

## Actionable findings

None on the inspected fixed source versions. No implementation patch is proposed. This does not certify versions with changed SHA; controller should recheck any later semantic edits against this report.

## Open boundaries and handoff

- This read did not claim independent full-source coverage of later chapters or the full volume; it checked the exact dependencies needed for the stated313–315 chain and downstream equation conventions.
- No source/PDF semantic pairing or page-by-page visual QA was performed here. Full-volume compilation must resolve external references; B06 owns final layout/visual evidence.
- B07 remains the clean thickness-only strict whole-volume review; this B05 report cannot replace it.
- Receiver should record actual read/hash receipt. Existing frozen volumes, table versions, source PDFs, and tool ZIP remain unchanged. No publication or archive action was taken.
