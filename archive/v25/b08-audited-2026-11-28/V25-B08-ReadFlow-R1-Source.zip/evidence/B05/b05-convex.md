# V25 B-05 獨立精修｜Ch.316–318

交接 ID `V25-B05-CONVEX-GEOMETRY-v1`；2026-11-28；B單一Work。執行者為原Ch.322–324內容角色，依主控新派工作本次316–318獨立順讀／精修。316–318不是本人起稿內容；此任務只讀，不修改其正文。此報告不是B-07打厚唯一整卷終審，也不代簽整卷通過。

## 實取固定版本與核讀範圍

| 檔案 | SHA-256 | 實際核讀 |
|---|---|---|
| `book/manuscript/ch316.tex` | `0b4d285367a2864e2f7a2959cd2745b7f5b0ede1b287a93afe9418edd672ef87` | 全806行，定義、證明、所有例／解；尤其extension-pair的branch量詞、Taylor-radius、CT infinite product、polyhedral新節與interpolation。 |
| `book/manuscript/ch317.tex` | `ddbb6db4816d7bf31494fc05e01e525acc6dab98a87725fb80c4729f37966110` | 全883行，psh工具、general USC pullback、interior tests、shell/flat/smooth growth、C² Levi criterion、strong defining function與local convexification、所有解。 |
| `book/manuscript/ch318.tex` | 最終實讀 `8e7db57790a4a689403cf82b46b4affd8b87d00076c2afb7dbbe4826cd5b33d6` | 全847行，包括specialist Hartogs/tube、零座標monomial enclosure、weak peak/no-disc/contact/scaling/polyhedron-face新節及10題解。讀取初期hash為120f21ff…；途中tube theorem改為三項equivalent的清楚措辭，最後已重讀該段，數學意思一致。 |
| `book/manuscript/ch313.tex` | `5487a18b8c06ef15d1e2503534f23de6967da2b5803afe69da110859b77080ce` | 局部實讀line511–565，`thm:313-logconvex`完整證，核318的先備接口；不稱313整章已核。 |
| `book/manuscript/ch320.tex` | `0c021da23dcfa434d0c52eb1a1f2030ad5ee3f1b1b5b1ef57c68bd825c68b17e` | 局部實讀line350–410的growth calls、line571–600 smooth global solvability；只核317接口，非全章L²估計。 |
| `book/manuscript/ch321.tex` | `f8eab64484c31c42c073ee7bc7b70449f6958a7b38e1bfffb2bb00d521cddb13` | 局部核relative/polynomial hull definitions、finite separator gap proof及其actual label；非全章Levi反向證明。 |

再次讀取結尾hash，316／317未變；318最終8e7版已反映於上表。B04章級handoff同讀，但歷史hash與後續正文hash分開，不憑「frozen」文字假設檔案未變。本次是獨立語意／依賴核讀，不是重新逐頁核四份來源PDF或成書全頁視檢；這兩項證據另由既有source responsibility及B06記錄承擔。

## 最重要的依賴與量詞核對

| 位置／接口 | 核對結果及其影響 |
|---|---|
| 316 `def:316-extension` → `prop:316-obstruction` | W連通且越出Ω，V非空open只需同一branch局部相等；first-exit path給Ω∩W中對應component，沒有錯把所有intersection components強迫一致。slit-log例能辨識這一差別。 |
| 316 `def:316-hull` | 真正型別為`widehat K_Ω ⊂ Ω`，測試函數全為`O(Ω)`。relative closed＋bounded並不自動compact，原文明示；compactness需距邊界下界或域holomorphically convex。不是「多項式凸包」的同義字。 |
| 316 hull／321 approximation | finite-separator lemma只需要L∩widehat K_Ω=empty及compact；321在K=widehat K_Ω且S disjoint K時正確套用，嚴格gap q<1<Q經compactness保留，powers能同時降K／升S。polynomial hull只在C^n與entire Taylor approximation證明後互換，沒有任意Ω中偷換。 |
| 316 `prop:316-radius` | 先用D^αf的holomorphic hull inequalities，再由所有unit-radius-vector polydiscs蓋Euclidean ball；varying g時測試的是D^αf·g^{|α|}，零點情形另列，故未除0。Taylor sum只與中心branch一致，符合extension定義。 |
| 316 CT product | Eν exhaustion、ζν位於dense maximal ball但在compact hull外，amplification給gν(ζν)=1及Eν小；log-tail含νfactor仍summable，E1非零證與zeros orderν相容。任何extension branch有aνk→b且maximal balls最終在同W/component，所有complex derivatives於b為0，無跳過branch reachability。 |
| 316 product/deletion/intersection | relative compact hull先落在ambient compact，再用components在deleted/intersection open set中相對閉性。1/h下界排除消失集合；沒有假設deleted set必連通。 |
| 316 polyhedral新節 | 用∂A finite separators排除人工boundary，得closed P compact⊂A；hull的cj<1把component hull限於P內compact，所有空間與closure均在正確ambient。exhaustion corollary先用connected compact E_j再取含它component，沒有假設整個polyhedron連通。 |
| 317 `widehat K^{psh}_Ω` | USC函數sublevel未必閉，原文明示只要求relative compact hull／compact closure。與316以holomorphic continuous tests所得relative closed hull有意區分；interior theorem用exhaustion bounded sublevel足夠，沒有錯用閉性。 |
| 317 USC pullback | bounded truncation u_N、nonnegative radial mollification、psh averages≥center及usc reverse limit給pointwise recovery；在disc compact image有共同上下界，DCT可用；最後decreasing psh limit。沒有以未證general local integrability為先備。 |
| 317 interior tests | δ_c lower-semicontinuous，−logδ_c USC；moving analytic disc參數open/closed以compact edge union套condition(3)，再harmonic comparison得directional psh。sup_c恰等continuous−logδΩ，continuous-sup lemma可用。∞ directional radius與whole-space例外有處理。 |
| 317 shell／flat growth | 五層嚴格分離保卷積在inner region看不到outer cutoff；b_j可在outer region非psh，但第j階段在S_j壓住前面可能負Hessian，已處理inner區域後加項均psh，不會倒毀。sum locally finite；flat初始core落於m=μ=0的N。沒有把compactly supported nonzero bump誤稱全域psh。 |
| 317 labels → 320 | `thm:317-flat-growth` line382、`thm:317-smooth-growth` line447、`cor:317-smooth-exhaustion` line470都實際存在。smooth-growth結論允許locally bounded obstacles，不強迫obstacles smooth；320用b=λ_min(Hβ) continuous為合法。 |
| 320第一次flat call | α₀=max(h−a₂,0)非負continuous psh exhaustion，zero set{h≤a₂}；m=2log⁺(c/d)選c使它在此zero-set鄰域為0，μ=0，compact core{h≤a₁}有a₁<a₂故α₀近core為0。滿足flat theorem所有額外前提。 |
| 320第二次flat call | σ在{h≤a₁}鄰域為0；η近{h≤a₀}為0，故m₂=σ+ηlog⁺b及μ₂=A|∂σ|²同時近{h≤a₀}為0。取sup_Kh<a₋₁<a₀後α=max(h−a₋₁,0)的zero-set有這個零鄰域；coreK也合法。沒有把flat theorem錯用於只在K單點為0的obstacle。 |
| 317 C² Levi invariance | 以boundary tangent curves證D²s=aD²r在real tangent上，不二次微分僅C¹ quotient；再取X,JX得Levi factor。full Hessian與tangential restriction分明。 |
| 317 Levi sufficiency | signed distance於兩側C²；若−logδ無psh boundary collar，以positive mixed coefficient構造h(t)；先用ball gap證h(t)∈Ω，再用signed r∘h負quadratic得到negative tangent Hessian，沒有在boundary直接微分unsigned distance或擅用C³/Lipschitz second derivatives。 |
| 317 strong／local convexification | 先用exp(Mr)令full Hessian positive，再pure quadratic cancellation；若只用tangential positivity便消pure terms是不夠的，此版已先補normal positivity。strict set convexity和positive real second fundamental form也分清。 |
| 318 specialist models | Cayley identity／inverse／pole點正確；E_m的w=0弱圈只在m>1；unbounded power exhaustion有quadratic term控制infinity；shell inner boundary負側sign正確；shear例明確兩inside點midpointoutside。 |
| 318 complete Reinhardt | enclosure用finite radii及convex simplex得compactS⊂U；p含零座標時先投影至J，分離functional非負、rational近似保strict gap再clear denominators，未使用log0。power-series converse真正用313已證normal absolute domain與Hölder，CT single-function extension排除更大D；沒有把pointwise boundary convergence當domain。 |
| 318 Hartogs radii | base先明pseudoconvex，u finite continuous使D_u真open connected；α−log(1−|w|²e^{2u})在zero section連續psh且控fiberboundary；necessity由317 proof已證directional radius在zero sectionpullback。C² Gaussian Levi calculation只在w≠0boundary使用，與continuous general theorem分開。 |
| 318 tubes | psh independent imaginary variables⇔locally convex real函數經local smoothing證；real locallyconvex exhaustion sublevel compact，component有polygonal path，Arzelà–Ascoli最短路local chords迫global line。故convexbase necessity不借未證Bochner tube theorem或Levi reverse direction。 |
| 318新support/contact節 | weak peak equality唯一點、E_m no-disc用nonnegative derivative identity、contact只斷言該特定曲線order2m、不冒稱完整finite-typeclassification；D_t Jac=t^{4m+2}核正；polyhedron face Hessian要先restrict∂f(v)=0才稱Levi-flat，multi-active points不聲稱smooth。 |
| 318 two specialist graph exercises | r=|z|²u−v的mixed entries給u(1−|z|⁴)/(1+|z|⁴)；r=xu−v給−ux/[2(x²+1)]，都保留mixed terms及tangency。不只看r_zbarz。 |

## 需主控處理的發現

| ID／等級 | 原文／位置 | 影響 | 建議修後文字／動作 | 重核證據與狀態 |
|---|---|---|---|---|
| B05-CVX-01／版本工程OPEN | `b04/ch318-handoff.md` current source及paired build仍記120f21ff…／PDF9a5d7316…；canonical318已8e7db577…，tube statement於核讀途中改為三項equivalent。 | 不能將舊PDF或「authoring frozen」說明當成8e7版的配對。數學措辭改動無新問題，但來源/PDF配對未由本次證明。 | 由主控或原內容owner追加8e7目前唯一source checkpoint，依固定新稿重編／核report並記PDFhash；保留120f歷史，不覆寫成假配對。 | 已重核新tube statement與完整proof，結論一致；本報告不改其檔案，版本配對由主控完成。 |
| B05-CVX-02／小幅接口改善 | 318的T={|z₂|<|z₁|<1}；322新H_m={|z|<|w|^m,0<|w|<1}。 | m=1是同一模型交換座標，沒有數學矛盾；讀者若沿章連讀，兩種坐標慣例可誤認是不同triangle。 | 在322 H_m定義後加一句：For m=1, exchanging the two coordinates gives the Hartogs triangle of Chapter 318. | 已核兩個forward/inverse maps；純界面typing，不阻數學。 |
| B05-CVX-03／可選行文整合 | 318 `prop:318-sphere-disc` 的sphere no-disc proof在322 `lem:322-sphere`重做；318 radialhomeomorphism也在322 solvedexercise再作。 | 不影響正確性，屬跨章重複；B03 contract避免duplicate proofs。完整應用仍可回顧已證工具，不需要第二次同證。 | 可保留322lemma statement及「proved in Proposition…」短回顧，將其proof改為reference；homeomorphism習題可明說Recall/recover，保留作主案例練習由主控選擇。 | 兩處定義完全相容。主控可依讀流保留有意recall，屬optional非退回。 |
| B05-CVX-04／可選定義typing | 317 `prop:317-locality`寫holomorphic inverse images，pseudoconvex起初定義為domain；inverse image本身可能空或不連通。 | proof在整個preimage有exhaustion，各nonempty component繼承；結論數學明確但type措辭可更精準。 | 在statement寫「each nonempty connected component of a holomorphic inverse image between pseudoconvex domains」。 | proof與subsequent318polyhedron使用可逐component解釋；無counterexample，typing小修即可。 |

本次未找到需要退回重證的核心數學blocker。以上版本工程OPEN仍應在封存前結清；optional文字不等於新增授權或自動改稿。

## 交接與下一步

B方案／階段：B05獨立精修局部整合；原A步號映射為精修的來源／語意與順讀核（不是A式排版後雙NO OBJECTIONS）。唯一正文仍由主控持有；本角色只產出本報告。actual source hashes如上；mathematical semantic checks和hash/PDF工程證據分列。排版沿ReadFlow R1，不改字體、頁寬、盒子或分頁，本次未做B06全頁視檢。

主控下一步：更新318版本配對；按判斷合入小typing；核新的全卷固定source/PDF後由唯一打厚角色作B07clean whole-volume終審。通過條件是全卷依賴、來源逐項落點、所有引用及paired工程閉合；本局部報告不能當六全局門檻已知或整卷通過。禁止重做來源取得、改章號、重啟凍結卷或公開Git。輸出已保存在工作路徑，外部持久保存由主控依授權續辦。
