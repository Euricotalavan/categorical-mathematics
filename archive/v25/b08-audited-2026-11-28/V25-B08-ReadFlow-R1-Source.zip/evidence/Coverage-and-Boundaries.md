# V25 source responsibility and chapter boundaries

The four fixed public sources are Lebl v4.4, Korevaar–Wiegerinck 2017, Demailly 2012 and Boas 2013. The B-01 responsibility sheets give original printed and PDF page locators, the level at which they were read, and the proof and example obligations. The following map records where the integrated manuscript carries these obligations.

| Chapters | Integrated obligations | Main verification point |
|---|---|---|
| 313 | Wirtinger characterization; product Cauchy and Taylor uniqueness; convergence geometry; identity, limits and Montel; unrestricted separate holomorphy. | A common contour exists before differentiating. Baire supplies one slab; a root submean estimate extends its reach. |
| 314 | Parameter Laurent coefficients; Hartogs figure and shell; isolated points; coordinate filling and negative coefficients; three-circle and two-tail estimates. | Every extension agrees on its overlap. For general compact holes use the proof in 321. |
| 315 | Product Cauchy, orientation and Cauchy–Pompeiu; normalized Bochner–Martinelli kernel, its volume and exterior identities; mean-value and a nonholomorphic boundary integral. | The sign of the inner sphere comes from Stokes. Singular integrability and normalization are separate steps. |
| 316 | Extension pairs, boundary distance and holomorphic hulls; single-function Cartan–Thullen; analytic polyhedra and fixed-edge continuity. | Use compactness in the domain and preserve the exact overlap component. |
| 317 | Plurisubharmonicity, analytic-disc tests, locality, smooth flat growth and signed-distance Levi criterion. | The flat growth input vanishes near the zero set. The \(C^2\) criterion uses signed distance, so signed differentiation at the boundary is justified. |
| 318 | Ball/polydisc geometry, ellipsoids, complete Reinhardt and tube criteria, Hartogs fibers, strong and weak models. | Include zero coordinates in monomial separation and separate the complex tangent from the full real tangent. |
| 319 | Weak and ordinary closedness, iterated local primitives, distributional holomorphy, compact support, closed graph and adjoint domains. | Solvability needs compatibility; integration by parts and domains are used with precise test functions and supports. |
| 320 | Test-form weighted identity, graph approximation with loss of weight, exact dual estimate, least-norm solution and logarithmic penalty. | The two cutoff derivatives have different bounds. The projected form is approximated in the stated graph norms. |
| 321 | Compact-hole extension, relative Oka–Weil and its polynomial case, Runge condition, Levi sufficiency and jet interpolation. | Cutoff correction agrees on a real open exterior portion of the punctured domain, and then throughout the connected complement. Weight gaps and singular limits have distinct roles. |
| 322 | Bergman space and kernel, complete monomial systems, Jacobian covariance, model inequivalence, generalized Hartogs triangle. | Reproducing inner-product order is fixed. Boundary growth along the shrinking section includes the Jacobian. |
| 323 | Germs, Weierstrass preparation and division, finite projection and discriminants, graphs, crossings, cusps, quadratic branches. | One contour for nearby fibers, multiplicities retained, isolated roots and submanifold tests stated separately. |
| 324 | Noetherian induction, computed local rings, sheaves and stalks, reduced analytic spaces, concrete relations and nilpotents. | The quotient is sheaf-local. Local ring information and general coherence theorems have different proof obligations. |

The full theory of coherent analytic sheaves and analytic spaces is assigned to V158. V25 includes the local algebra and examples needed to enter it. Boundary smoothness of \(\bar\partial\) solutions, estimates in higher bidegrees, and general normalization theorems lie beyond the selected proof route. The \(L^2\) result stated here is for distributionally closed \((0,1)\)-forms with the stated weight, with an interior smooth representative for smooth data.

The extractor's automated candidates, source responsibility readings, chapter manuscript checks, all-page visual review and final independent mathematical audit have separate records. The statements in this map refer to the approved in-volume scope.
