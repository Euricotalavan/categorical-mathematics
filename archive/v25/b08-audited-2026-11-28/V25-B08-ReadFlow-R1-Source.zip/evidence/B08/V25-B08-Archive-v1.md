# V25 · B-08 archive record

V25-B08-ARCHIVE-v1 · 2026-11-28T16:04+08:00, Taipei. Controller → reader and future
archivist. Volume 25, *Several Complex Variables*, chapters 313–324.
The user chose the single-Work B variant, approved the public references
and authorized execution of the eight stages and internal reviews.
The production mapping and earlier receipts are in the paired source.
The independent thickness role owns the B-07 approval.

## Fixed pairing

| File | Identity and purpose |
|---|---|
| `V25-B08-ReadFlow-R1.pdf` | ReadFlow R1 reading edition, 212 pages, 953359 bytes, SHA-256 `78001ce0336b5520060fd886c92d688d82b80d269a9672e44c2ec7b5f6ef9147`. |
| `V25-B08-ReadFlow-R1-Source.zip` | Editable LaTeX, paired PDF, typesetting dependencies and evidence. `MANIFEST.json` declares file sizes and hashes. Run `python verify.py` after extraction. |
| `evidence/B06/build-report.json` | Exact compiler run, chapter hashes and matching PDF hash. |
| `evidence/B07/B07-Final-Audit.md` | Independent final semantic decision and scope. |
| `evidence/B07/Defect-Ledger.md` | Integrated defect trail and links to repair evidence. |

The one main manuscript is `manuscript/ch313.tex` through
`manuscript/ch324.tex`. Build with `python tools/build.py --full --name rebuild`
from the extracted source directory using XeLaTeX, TeX Live and fontconfig.
The paired PDF is checked against its exact shipped hash. The separate
reconstruction check records the build environment and which characteristics
of the new PDF match the paired edition.

An independent rebuild reproduced all 212 rendered pages, extracted text,
page sizes, bookmarks and link destinations. The PDF differs byte-for-byte
only in the identification values of the cross-reference stream.

The fixed published chapter-number baseline is commit
`20e626496c24518f133af6eb892c620ea52a3c59`. V24 ends at chapter 312.
The adopted V0 ReadFlow R1 style files retain the hashes from artifact commit
`8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, source version 3. Its archive hash
and the font donor's hash are in `evidence/ReadFlow-baseline.json`. The only
volume adapter changes are in the V25 entry, metadata, symbols, front matter,
bibliography and the number-column widths in the contents.

## Completion and provenance

B-01 located the mathematical responsibilities in the four public sources.
B-02 fixed the 12 chapters' dependency order. B-03 exercised the shared
Taylor-calibration specimen. B-04 drafted, expanded and refined the single
manuscript. B-05 independently cross-read the full chapter sequence. B-06
compiled, corrected and visually inspected the paired output. B-07's
independent acceptance is retained with the exact edition identity.
B-08 seals the approved pair and its evidence.

The final book has 81 numbered sections, 92 worked examples,
and 131 exercises with 131 complete solutions. The central
comparators have 248 and 274 pages. The book keeps its proof and practice
sequence within the selected volume rather than taking on those texts' other
topics. The confirmed references and precise responsibilities appear in
`evidence/B01` and at the ends of the relevant chapters.

API task configurations requested the role models and High where specified.
Independent introspection of the execution models was unavailable. Prior
versions, frozen volumes, the source and curriculum tables, and reference
PDFs remain outside the archive mutation scope. The four public source
locators and exact hashes are given in the B-01 records.

## Scope and continuation

General analytic-space theory, coherence and general normalization remain
V158 work. Ch323–324 prove selected local results supporting that interface.
The weighted existence route covers distributionally closed ((0,1))-forms
under its stated weights and explains interior smooth representatives.
Boundary estimates and higher bidegrees remain outside the treatment.

Two complete chapter reading guides retain short pages. Visual signoff
records their page locations, the final contents fit and the local
reinspection after the B07 corrections.

This is the B-08 archive for V25. Restore from the exact editable pair and
check the manifest before taking any new action. Any later Git publication
has its own authorization and verification. No reader decision is required
for the current delivery.
