# B07 follow-up on directly affected mathematical wording

## Chapter 318

Before SHA-256: `d7b8eb60f6d86e39ca92503bd6ff675b4789943129f2e5ccf4878a3222477861`.
After SHA-256: `23d5ebe12d63edd2c6c1e4b174152fb79e973942b53a738fc5a192215b87768d`.

```diff
--- ch318.tex
+++ ch318.tex
@@ -329,9 +329,9 @@
 Thus the normal absolute convergence domain \(D\) of the series
 contains \(U\). The domain \(D\) is complete Reinhardt and
 logarithmically convex by the power-series result in Chapter 313, hence
-connected. If it strictly contained \(U\), the series sum on \(D\)
-would give an extension pair for \(f\), contradicting its domain of
-existence. Therefore \(D=U\), proving (4).
+connected. If \(U\subsetneq D\), the series sum would extend this fixed
+\(f\) with \(W=D\) and \(V=U\), contradicting its domain of existence.
+Therefore \(D=U\), proving (4).
 Finally a power-series convergence domain is logarithmically convex by
 the H\"older argument of Theorem~\ref{thm:313-logconvex}. This gives
 (4) implies (1) without a second proof here.
```

## Chapter 320

Before SHA-256: `98ee590e8620ac2fcf370271d1d95edd1e767cced5c6cb5b7a533b34f5ee8463`.
After SHA-256: `a6d7f3adcf1a2f0f47da0e2ad04d532bd202205647e542b95ae5d848aadc6162`.

```diff
--- ch320.tex
+++ ch320.tex
@@ -219,7 +219,7 @@
 \section{Graph approximation with an extra weight}
 
 When \(\Omega\ne\CC^n\), put
-\(d(z)=\dist(z,\partial\Omega)\). For \(c>0\), write
+\(d(z)=\dist(z,\partial\Omega)\). For \(t>0\), write
 \(\log^+t=\max(\log t,0)\). A loss of weight will control the
 extra derivatives created by a cutoff near the boundary.
 
@@ -514,10 +514,10 @@
           \left(\int b|p|^2e^{-\gamma-\sigma}\right)\\
  &\le M^2(1+\theta)\|\delta_\beta v\|_\beta^2,
 \end{align*}
-because \(\gamma-\sigma\ge\beta\). The resulting bound involves
-neither \(p\), \(\gamma\), nor \(\sigma\). Although those objects
-depend on \(\theta\) and \(v\), the final constants do not.
-Let \(\theta\downarrow0\) to obtain the stated estimate.
+because \(\gamma-\sigma\ge\beta\). By the projection identity above,
+the left side equals \(|(f,v)_\beta|^2\). The data norm \(M\) and the form norm
+\(\|\delta_\beta v\|_\beta\) are fixed, so the only remaining dependence
+on \(\theta\) is \(1+\theta\). Let \(\theta\downarrow0\) to finish.
 \end{proof}
 
 \begin{theorem}[Weighted solution theorem]
```

The first clarification uses the specific fixed-function definition in Chapter 316. The second gives the correct positive input for the logarithm and makes the use of the projection identity explicit. The theta limit uses only the bound with fixed M and fixed test form v. The chapter repairs do not alter any formulas or theorem labels.
