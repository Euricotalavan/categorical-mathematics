# B07 有界修補｜Ch316

2026-11-28。只修改 canonical `v25-work/book/manuscript/ch316.tex`；未碰 `qa/b07-fixed`、其他章、PDF或模板，也未編譯。依主控轉交的乾淨終審意見，先核定義、量詞、證明與 hull 定義作用域後作最小語意修補。本紀錄是修補證據，不代替打厚複核。

## 固定版本

- 修前 SHA-256：`0b4d285367a2864e2f7a2959cd2745b7f5b0ede1b287a93afe9418edd672ef87`。
- 修後 SHA-256：`97445d81654cc0a09e71eb1b085678c49f29f6142949a861c2e1bac5fec0fe38`。
- 修前/修後逐行差異完整列於末段；行號依各自版本。

## 實際修補與核驗

1. **固定函數的 domain of existence。** 原292–296行以「W,V as in Extension pair」回指，可能連同「every f」一起導入。現直接列出幾何條件：W連通開、W不包含於Ω、非空開V⊂Ω∩W，再對這個固定的 f 排除存在F∈O(W)且F=f於V。沒有要求其他函數也延拓。
2. **Cartan–Thullen的3⇒1。** 不再稱固定函數「blocks all extension pairs」作省略；明說共同延拓若存在，必延拓這個固定f，正與其domain of existence矛盾。一般 extension-pair 定義的共同∀f保持原樣，兩個量詞層次現在分開。
3. **分支敏感的乘積證明。** 假設F存在的段首先明列同一W,V幾何條件，且只涉及所構造f；之後由恆等定理在Ω∩W中與V相交的分支Ω1上相等。從Ω1到W\Ω的路徑提供b∈∂Ω1∩W∩∂Ω。密集最大球序列最終留在這一分支，故高階零迫使F所有導數於b為零。這套證明實際建立新的固定函數定義，沒有偷用「所有函數都延拓」。
4. **非空 hull 輸入。** 基礎定義使用max_K並明限非空compact，故只在會取hull、max或距離最小值的泛稱輸入補上nonempty：OO(Ω)-convex compact定義；boundary-distance段K；amplification lemma；產品/刪零證明中的K；polyhedral exhaustion的起始compacts；torus解答中泛稱L；指定的三道hull習題與finite-intersection解答；interpolation起始exhaustion。明列圓、torus、sphere等已構造非空例不加冗詞；普通compact neighborhood、support及closure等未取hull輸入者也不亂加。
5. **相鄰作用域精度。** amplification需在a評估O(Ω)函數；明寫a∈Ω\KhatΩ，避免a僅寫“不在hull”時包含Ω外點。與指定nonempty typing修補同屬此lemma作用域，未改其放大構造。

## 依賴回核

- `def:316-extension`仍是共同延拓對：同一W,V，對每個f各有F。新domain-of-existence定義不回指其∀f性質。
- `thm:316-cartan-thullen`的三個條件與label未變。1⇒distance、distance⇒hol-convex不受修補影響；2⇒3的branch proof確實排除固定f的全部局部延拓；3⇒1已展開直接邏輯。
- Ω=C^n例仍獨立：不存在W⊄Ω，固定函數存在域條件與全純域條件均空泛成立；不使用−log∞或空邊界距離。
- `def:316-hull`的max_K定義沒有擴大到空集，未引入空集max的約定。每個補入nonempty的compact測試，恰符合hol-convex定義的量詞範圍；無須處理空測試。
- 產品投影K1,K2因K非空仍非空；刪零1/h的max>0有意義；有限交集証明只需非空K；polyhedral E_j含非空C_j，故其hull有定義；interpolation hull exhaustions每階非空，正常收斂與有限早期點安排保持原樣。
- 下游從Cartan–Thullen取單一不可延拓函數的用途（本章運算/後續Reinhardt power-series構造）仍取得更清楚的固定f性質；未改定理可用範圍、label或記號。未編譯，工程與配對PDF核驗留主控統一重建後作。

## 精確位置對照

| 修前起行 | 修後起行 | 修補項 |
|---:|---:|---|
|124|124|非空OO-convex compact|
|213|213|distance的K非空compact|
|223|224|amplification輸入及a∈Ω|
|293|295|固定f存在域定義|
|380|384|固定f分支延拓假設|
|403|408|Cartan–Thullen3⇒1|
|437|443|產品K非空|
|447|453|刪零K非空|
|572|578|polyhedral非空compact exhaustion|
|664|671|torus解答L作用域|
|670|677|ambient hull monotonicity題|
|684|691|entire/polynomial hull題|
|721|728|real-subspace compact題|
|741|748|finite-intersection解答K|
|771|778|interpolation非空compact exhaustion|

## 完整最小差異

```diff
--- ch316.tex BEFORE 0b4d285367a2864e2f7a2959cd2745b7f5b0ede1b287a93afe9418edd672ef87
+++ ch316.tex AFTER 97445d81654cc0a09e71eb1b085678c49f29f6142949a861c2e1bac5fec0fe38
@@ -121,7 +121,7 @@
 \]
 The domain \(\Omega\) is holomorphically convex if
 \(\widehat K_\Omega\) is a compact subset of \(\Omega\) for every such
-\(K\). A compact set is \(\OO(\Omega)\)-convex if its hull equals itself.
+\(K\). A nonempty compact set is \(\OO(\Omega)\)-convex if its hull equals itself.
 \end{definition}
 
 The ambient domain matters because it determines which functions can be
@@ -210,7 +210,8 @@
 
 \section{Taylor series carry information along the hull}
 
-Assume \(\Omega\ne\CC^n\). Write
+Assume \(\Omega\ne\CC^n\), and let \(K\subset\Omega\) be nonempty
+and compact. Write
 \[
  \delta(z)=\dist(z,\partial\Omega),\qquad
  \delta(K)=\min_{z\in K}\delta(z)>0.
@@ -220,7 +221,8 @@
 same notation means an infimum, rather than a minimum.
 
 \begin{lemma}[Separation with amplification]\label{lem:316-amplify}
-If \(a\notin\widehat K_\Omega\), then for any \(A\in\CC\) and
+Let \(K\subset\Omega\) be nonempty and compact. If
+\(a\in\Omega\setminus\widehat K_\Omega\), then for any \(A\in\CC\) and
 \(\varepsilon>0\) there exists \(g\in\OO(\Omega)\) such that
 \(g(a)=A\) and \(\max_K|g|<\varepsilon\).
 \end{lemma}
@@ -290,10 +292,12 @@
 \section{Cartan--Thullen and a single function that stops everywhere}
 
 \begin{definition}[Domain of existence]
-A domain \(\Omega\) is the domain of existence of \(f\in\OO(\Omega)\)
-if there are no \(W,V\) as in Definition~\ref{def:316-extension} for
-which \(f|_V\) extends holomorphically to \(W\). This is a condition on
-one function and on every possible local branch of continuation.
+A domain \(\Omega\) is the domain of existence of a fixed function
+\(f\in\OO(\Omega)\) if there do not exist a connected open set
+\(W\subset\CC^n\) with \(W\not\subset\Omega\), a nonempty open set
+\(V\subset\Omega\cap W\), and a function \(F\in\OO(W)\) such that
+\(F=f\) on \(V\). Only this fixed \(f\) is quantified here; the
+condition concerns every possible local branch of its continuation.
 \end{definition}
 
 \begin{theorem}[Cartan--Thullen]\label{thm:316-cartan-thullen}
@@ -377,9 +381,10 @@
 factor; the product of all remaining factors is holomorphic there.
 
 \ProofStep{A branch extension would have every derivative zero}
-Suppose \(f\) extended to \(F\in\OO(W)\), agreeing on a nonempty
-open \(V\subset\Omega\cap W\), with \(W\) connected and crossing
-\(\partial\Omega\). Let \(\Omega_1\) be a component of
+Suppose there were a connected open set \(W\subset\CC^n\) with
+\(W\not\subset\Omega\), a nonempty open \(V\subset\Omega\cap W\),
+and \(F\in\OO(W)\) satisfying \(F=f\) on \(V\).
+Let \(\Omega_1\) be a component of
 \(\Omega\cap W\) meeting \(V\). Then \(f=F\) on \(\Omega_1\).
 A path from this component to \(W\setminus\Omega\) gives a point
 \(b\in\partial\Omega_1\cap W\cap\partial\Omega\).
@@ -400,8 +405,9 @@
 \(\Omega\), a contradiction. Thus \(f\) has \(\Omega\) as its
 domain of existence.
 
-Finally a single function that blocks all extension pairs certainly
-blocks common extension of every function. If \(\Omega=\CC^n\), hulls
+Finally, an extension pair for all functions would in particular extend
+this fixed \(f\) to its \(W\) with equality on \(V\), contradicting
+its domain of existence. If \(\Omega=\CC^n\), hulls
 are compact by the basic lemma and no set crosses its empty boundary;
 the assertions hold without using boundary distance.
 \end{proof}
@@ -434,7 +440,7 @@
 \(\Omega\setminus\{h=0\}\) is a domain of holomorphy.
 \end{proposition}
 \begin{proof}
-For a compact \(K\subset\Omega\times\Omega'\), let \(K_1,K_2\) be
+For a nonempty compact \(K\subset\Omega\times\Omega'\), let \(K_1,K_2\) be
 its coordinate projections. Testing by functions of one block of
 variables gives
 \[
@@ -445,7 +451,7 @@
 closed, proving compactness.
 
 Let \(G\) be a component of the deleted domain and \(K\subset G\)
-compact. Restrictions of functions on \(\Omega\) show that
+nonempty and compact. Restrictions of functions on \(\Omega\) show that
 \(\widehat K_G\subset\widehat K_\Omega\). The additional test function
 \(1/h\in\OO(G)\) yields
 \[
@@ -569,7 +575,8 @@
 of analytic polyhedra constructed in this way.
 \end{corollary}
 \begin{proof}
-Start with a compact exhaustion \(C_1\subset C_2\subset\cdots\)
+Start with an exhaustion by nonempty compact sets
+\(C_1\subset C_2\subset\cdots\)
 of \(\Omega\). If \(P_{j-1}\) has already been constructed,
 enclose \(\overline{P_{j-1}}\cup C_j\) in a connected compact
 subset \(E_j\subset\Omega\). To do so, cover the compact set by
@@ -661,13 +668,13 @@
 \(\prod_j\{|z_j|\le r_j\}\subset\widehat K\). Each coordinate
 function imposes \(|z_j|\le r_j\), giving the reverse inclusion.
 This argument also proves holomorphic convexity of \(\mathbb D^n\):
-for any compact \(L\), its coordinate maxima are strictly less than one,
+for any nonempty compact \(L\subset\mathbb D^n\), its coordinate maxima are strictly less than one,
 and its hull is a relatively closed subset of the resulting compact
 polydisc.
 \end{psolution}
 
 \begin{problem}[Hull monotonicity in the ambient domain]
-If \(K\subset U\subset W\) with \(K\) compact and \(U,W\) domains,
+If \(K\subset U\subset W\) with \(K\) nonempty compact and \(U,W\) domains,
 prove \(\widehat K_U\subset\widehat K_W\cap U\). When every function
 on \(U\) extends to \(W\), prove equality.
 \end{problem}
@@ -681,7 +688,7 @@
 \end{psolution}
 
 \begin{problem}[Entire and polynomial hulls]
-For compact \(K\subset\CC^n\), define its polynomial hull by using
+For nonempty compact \(K\subset\CC^n\), define its polynomial hull by using
 holomorphic polynomials in place of \(\OO(\CC^n)\). Prove that the two
 hulls coincide.
 \end{problem}
@@ -718,7 +725,7 @@
 \end{psolution}
 
 \begin{problem}[Compact subsets of a real subspace]
-Show that every compact \(K\subset\RR^n\subset\CC^n\) is
+Show that every nonempty compact \(K\subset\RR^n\subset\CC^n\) is
 polynomially convex.
 \end{problem}
 \begin{psolution}
@@ -738,7 +745,7 @@
 of \(U\cap W\) is a domain of holomorphy.
 \end{problem}
 \begin{psolution}
-For compact \(K\subset G\), restrictions give
+For nonempty compact \(K\subset G\), restrictions give
 \(\widehat K_G\subset\widehat K_U\cap\widehat K_W\), a compact
 subset of \(U\cap W\). Components are relatively closed in
 \(U\cap W\). Intersecting that compact set with \(G\), then using the
@@ -768,7 +775,7 @@
 \(F(p_j)=c_j\) for every \(j\).
 \end{problem}
 \begin{psolution}
-Choose a compact exhaustion \(L_\nu\) with
+Choose an exhaustion by nonempty compact sets \(L_\nu\) with
 \(L_\nu\subset\operatorname{int}L_{\nu+1}\), and replace it
 inductively by its holomorphic hull, enlarging the next compact before
 taking that hull. This gives holomorphically convex compacts \(K_\nu\)
```

下一步：主控收集各章有界修補後統一重編，固定新來源與配對PDF，再交打厚乾淨複核。不把本修補紀錄主動傳給 final_audit；本輪只回報主控。
