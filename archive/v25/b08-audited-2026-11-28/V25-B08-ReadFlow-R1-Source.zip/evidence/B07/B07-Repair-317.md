# B07 有界修補｜Ch317

2026-11-28。只修改 canonical `v25-work/book/manuscript/ch317.tex`，未改其他章、`qa/b07-fixed`、PDF、模板，未編譯。這是修補回執，數學通過仍待打厚獨立複核。

## 版本

修前 SHA-256：`ddbb6db4816d7bf31494fc05e01e525acc6dab98a87725fb80c4729f37966110`。修後 SHA-256：`345109bad68f3a151ae3ce71349cf980a818ce0952c7026c9516153808c8456c`。

## 實核後的最小修補

- 原779–792行 flat-boundary題：固定原方程Im f=0，補Im f(p)=0，使p真正位於所述level set。df(p)≠0依連續性在縮小鄰域仍非零，Cauchy–Riemann使dIm f非零；原解的r=Im f、H_r=0與切向限制皆仍正確。具體f=z_n例另明取p=0。沒有把假設只解讀成『附近可能有別處的level』。
- 原292–307行 inverse-image命題：明列U⊂C^n、G⊂C^m為偽凸domain，F:U→C^m全純，結論只對F^(-1)(G)的每個連通分支。預像可以空或不連通，故不再直接把整個預像稱domain。
- 相同證明先給整個開預像的continuous psh exhaustion α_U+α_G∘F；再說每個分支在預像相對閉，所以其受限sublevel仍相對緊，得到各分支的domain結論。α皆可先非負；空預像無分支而不造成額外例外。既有intersection、biholomorphic與boundary-locality結論及labels保留。

## 直接依賴回核（唯讀）

- Ch317對應的『Deleting a zero set preserves pseudoconvexity』題與解，本來已逐connected component作結論，並在解答指出分支相對閉；與修後規範一致，無須改。『Checking a pullback』只斷言函數psh並計算Gram Hessian，不斷言其預像連通，亦不受影響。
- Ch318 analytic-polyhedron段（當前唯讀hash `8e7db57790a4a689403cf82b46b4affd8b87d00076c2afb7dbbe4826cd5b33d6`，原516–530行）已說“consider its connected components when a domain is required”，用entire f的polydisc預像，且另給直接exhaustion；完全符合修後inverse-image結論。該段未改。
- Ch318 Hartogs domain段明證纖維可縮到zero section再沿連通base移動，故D_u連通有獨立證據，不倚賴錯誤的預像連通推論；其psh exhaustion構造不變。
- Ch320（當前唯讀hash `711b5c5317af631bac463fcc09bd5a6eb2e006fb7aa579a7acd15b826e4f04c2`）用317的smooth-growth、flat-growth與smooth-exhaustion三個穩定labels；本修補不改其陳述、假設或證明。Ω在weighted theorem明為pseudoconvex domain。證明中的h-sublevels只是compact cores，不被當作連通domains，inverse-image補註沒有改變這些用法。
- 本修補不把一般holomorphic pullback的psh函數定理與預像domain連通性混同。沒有移動充分性證明、未新增一般Levi問題循環。

## 修前／修後位置

| 修前起行 | 修後起行 | 內容 |
|---:|---:|---|
|293|293|inverse-image陳述|
|303|305|inverse-image分支證明|
|780|784|flat題補level條件|
|790|795|flat具體例p=0|

## 完整差異

```diff
--- ch317.tex BEFORE ddbb6db4816d7bf31494fc05e01e525acc6dab98a87725fb80c4729f37966110
+++ ch317.tex AFTER 345109bad68f3a151ae3ce71349cf980a818ce0952c7026c9516153808c8456c
@@ -290,9 +290,11 @@
 \end{proof}
 
 \begin{proposition}[Locality and elementary operations]\label{prop:317-locality}
-Pseudoconvexity is preserved by finite products, holomorphic inverse
-images between pseudoconvex domains, components of finite intersections, and
-increasing unions. It is invariant under biholomorphism. If every
+Pseudoconvexity is preserved by finite products, connected components of
+finite intersections, and increasing unions. If \(U\subset\CC^n\) and
+\(G\subset\CC^m\) are pseudoconvex domains and \(F:U\to\CC^m\) is
+holomorphic, every connected component of \(F^{-1}(G)\) is pseudoconvex.
+Pseudoconvexity is invariant under biholomorphism. If every
 boundary point of a domain has a neighborhood whose intersection with the
 domain is pseudoconvex, the domain is pseudoconvex.
 \end{proposition}
@@ -300,12 +302,14 @@
 Exhaustions can be made nonnegative by adding a constant: a continuous
 exhaustion is bounded below, since outside a compact sublevel it is
 bounded below by that level, and on its closure it attains a lower
-bound. For products add nonnegative exhaustions. For
-\(F:U\to W\) and pseudoconvex open \(G\subset W\), the function
-\(\alpha_U+\alpha_G\circ F\) exhausts \(F^{-1}(G)\). A bounded
-sublevel confines points to a compact subset of \(U\) whose image
-lies in a compact subset of \(G\). Pullback preserves psh. This also
-proves biholomorphic invariance.
+bound. For products add nonnegative exhaustions. For \(U,G,F\) as in
+the statement, the continuous psh function
+\(\alpha_U+\alpha_G\circ F\) exhausts the open set \(F^{-1}(G)\).
+A bounded sublevel confines points to a compact subset of \(U\) whose
+image lies in a compact subset of \(G\). Its restriction to any
+connected component is still an exhaustion, because that component is
+closed relative to \(F^{-1}(G)\). Each such component is therefore a
+pseudoconvex domain. This also proves biholomorphic invariance.
 
 For intersections, the distance to the complement is the infimum of the
 individual distances; their negative logarithms have continuous supremum
@@ -777,7 +781,8 @@
 \end{psolution}
 
 \begin{problem}[A smooth flat boundary]
-Let \(f\) be holomorphic near \(p\), with \(\dd f(p)\ne0\).
+Let \(f\) be holomorphic near \(p\), with \(\ImPart f(p)=0\) and
+\(\dd f(p)\ne0\).
 Show that \(\{\ImPart f=0\}\) is a smooth Levi-flat hypersurface near
 \(p\). Give a concrete example.
 \end{problem}
@@ -787,7 +792,7 @@
 equations. Thus \(r=\ImPart f\) has nonzero differential and its zero
 set is a hypersurface. Its complex Hessian is zero because
 \(r=(f-\overline f)/(2i)\). Its restriction to any complex tangent is
-zero as well. Take \(f(z)=z_n\) to obtain the real hyperplane
+zero as well. Take \(f(z)=z_n\) and \(p=0\) to obtain the real hyperplane
 \(\ImPart z_n=0\), pseudoconvex from either side.
 \end{psolution}
 
```

只回報主控；不主動把既往修補歷史傳給final_audit。主控統一重編後，固定新版來源/PDF再交打厚複核。
