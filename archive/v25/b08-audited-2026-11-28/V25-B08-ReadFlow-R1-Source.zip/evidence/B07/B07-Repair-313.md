# V25 B07 return repairs｜Ch313–314

Receipt ID V25-B07-REPAIR-313-v1 · 2026-11-28. Expansion owner received the independent B07 return, inspected the precise canonical text, and made the bounded repair below. No compilation was run. Only canonical `book/manuscript/ch313.tex`, `book/manuscript/ch314.tex`, and this receipt were written. The separate auditor baseline under `qa/b07-fixed` was not changed. This receipt reports a repair, not a final mathematical acceptance.

## Fixed input and resulting hashes

| Object | SHA-256 |
|---|---|
| Canonical Ch313 before repair | `17cb217fb24f288275f3e6835e02aa5d60d67aaf39fcd0a78cbe59a7df5d1bb6` |
| Canonical Ch313 after repair | `258f8e590a2fdc862a0793e36fdd88f48c71a03709f2f20158e0ff73971d98cb` |
| Auditor fixed copy before and after, unchanged | `17cb217fb24f288275f3e6835e02aa5d60d67aaf39fcd0a78cbe59a7df5d1bb6` |

## Defect and minimum repair

Filing point: canonical Ch313, exercise “Zero data on a real patch,” original lines784–797. Original assumptions did not locate the real cube at the origin or in the relevant connected component. The solution needed precisely an origin-centered cube on which all real coordinates may vary independently. The repaired assumption explicitly gives that cube inside the stated open holomorphy neighborhood. Only the opening of the solution is changed to choose a correspondingly centered smaller polydisc; the identity-theorem argument is preserved.

### Exact before snippet

```tex
\begin{problem}[Zero data on a real patch]
Suppose \(f\) is holomorphic on a neighborhood of the origin in
\(\CC^n\), and \(f(x_1,\ldots,x_n)=0\) on a small real cube.
Prove \(f=0\) near the origin.
\end{problem}
\begin{psolution}
Choose a polydisc inside that neighborhood whose real cube lies in the
given cube. Hold the last \(n-1\) coordinates real. The first-variable
function vanishes on a real interval, so the one-variable identity
theorem makes it zero on its whole disc. Now hold the first coordinate
arbitrary complex and the remaining \(n-2\) coordinates real; apply
the same argument to the second variable. Repeating through all
coordinates proves zero on the polydisc. A real patch of this shape is
a uniqueness set; an arbitrary set with accumulation points need not be.
\end{psolution}
```

### Exact after snippet

```tex
\begin{problem}[Zero data on a real patch]
Suppose \(f\) is holomorphic on an open neighborhood \(U\) of
\(0\in\CC^n\). Assume that for some \(\varepsilon>0\),
\((-\varepsilon,\varepsilon)^n\subset U\cap\RR^n\) and
\(f(x_1,\ldots,x_n)=0\) for every real point of this cube.
Prove \(f=0\) near the origin.
\end{problem}
\begin{psolution}
Choose \(0<r<\varepsilon\) so that the polydisc
\(P=P(0,(r,\ldots,r))\) has closure in \(U\).
Hold the last \(n-1\) coordinates real in \((-r,r)\). The first-variable
function vanishes on a real interval, so the one-variable identity
theorem makes it zero on its whole disc. Now hold the first coordinate
arbitrary complex and the remaining \(n-2\) coordinates real; apply
the same argument to the second variable. Repeating through all
coordinates proves zero on the polydisc. A real patch of this shape is
a uniqueness set; an arbitrary set with accumulation points need not be.
\end{psolution}
```

## Actual recheck and downstream effect

1. Since U is open and contains0, there is r>0 with the closure of P(0,(r,…,r)) in U; shrink r further to r<epsilon. Its entire real cube is in the assumed zero set. This supplies the exact polydisc claimed by the solution and avoids any reliance on connectedness of the whole U.
2. Fix the last n−1 coordinates real in(−r,r). The first-variable restriction is holomorphic on D(0,r), and zero on the interval(−r,r); the one-variable identity theorem makes it zero on that disc. Then keep the first coordinate arbitrary complex in its disc and the remaining n−2 coordinates real, and repeat for coordinate2. Induction gives zero on all of P, an open neighborhood of0. For n=1 the first application already concludes the proof.
3. Direct dependencies are the polydisc/open-neighborhood definitions and one-variable identity theorem, already available before this exercise. No appeal to a later result or to the ambiguous “small cube” remains. No theorem, notation, label or mathematical claim elsewhere was changed.
4. Searched all canonical manuscript chapters for the exercise title, “real patch,” “real cube,” and the apparent numbered citation “313.6.” No downstream citation to this exercise was found. The bounded hypothesis repair does not affect the proof of the chapter's identity theorem or any later chapter's assumptions. No other exercise or solution was modified.
5. Exact source change is confined to the statement and first three solution lines of this one exercise. After source write, the auditor copy's SHA was recomputed and matched its before hash. No source or PDF under qa/b07-fixed was written; no previous defect history was sent to the final auditor.

Next: controller collects this source with other B07 returns, makes the one authorized paired build, and hands the fixed new version for independent recheck. PDF pairing and layout after reflow are pending that build. No B07 pass is claimed by this author.


## Additional return: Ch314 first use of biholomorphism and punctured-disc notation

Filing point: original canonical Ch314 lines497–502, in the Hartogs triangle example. Actually searched the entire preceding Ch313 and frontmatter: neither “biholomorphism” nor the punctured-disc symbol was defined there. Ch314's introductory phrase “punctured disc” does not define the later symbol D*. The first precise usage was original499–500. The following local repair defines both notions in place; the map, inverse and mathematical claims are preserved. The adjacent grammatical agreement “cross-sections has” is corrected to “cross-sections have.”

| Object | SHA-256 |
|---|---|
| Canonical Ch314 before repair | `83432e1242291fee3f063b2005654efb5bc18c0ac140ee27e916ff0fc86bd5e2` |
| Canonical Ch314 after repair | `bff92a2fe9e2b486d5ead953c68fc50523923cbf0404b71e46957c0a6410792a` |
| Auditor fixed Ch314 before and after, unchanged | `83432e1242291fee3f063b2005654efb5bc18c0ac140ee27e916ff0fc86bd5e2` |

### Exact Ch314 before snippet

```tex
Since \(z\ne0\) throughout \(T\), the function \(1/z\) is
holomorphic there and prevents extension across the origin. The coordinates
\((z,w)\mapsto(z,w/z)\) identify this domain biholomorphically with
\(\mathbb D^*\times\mathbb D\), with inverse
\((z,\eta)\mapsto(z,z\eta)\). Thus the narrowing cross-sections
has not removed the one-variable puncture obstruction.
```

### Exact Ch314 after snippet

```tex
Since \(z\ne0\) throughout \(T\), the function \(1/z\) is
holomorphic there and prevents extension across the origin.
Write \(\mathbb D^*=\mathbb D\setminus\{0\}\).
A biholomorphism is a bijective holomorphic map with holomorphic inverse.
The map \((z,w)\mapsto(z,w/z)\) is a biholomorphism from \(T\) to
\(\mathbb D^*\times\mathbb D\), with inverse
\((z,\eta)\mapsto(z,z\eta)\). Thus the narrowing cross-sections
have not removed the one-variable puncture obstruction.
```

### Actual mathematical and downstream recheck

- T has z≠0 and |w/z|<1, so the displayed map is defined, holomorphic, and maps T into D*×D. Conversely, for (z,eta) in D*×D, (z,z eta) satisfies |z eta|<|z|<1 and is holomorphic. Both composites are the identity by direct substitution. Thus it is a bijection with holomorphic inverse under the added general definition.
- The new D*=D minus0 matches exactly this image and all subsequent punctured-disc uses. No shared symbol or label was changed, so later domain-of-holomorphy and model-domain arguments retain their original mathematical inputs.
- This clarification changes no hypothesis or conclusion in the triangle-filling proposition. The “tiny ball implies bidisc extension” proof is untouched. No other chapter or fixed auditor file was modified.
- Both repairs were made without compilation. Controller owns the single collected build, new PDF pairing and any needed visual recheck after line reflow. This author has not sent these repair notes or earlier defect history to the final auditor.
