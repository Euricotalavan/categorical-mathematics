# V25 final mathematical review remit

Volume 25 is *Several Complex Variables*, chapters 313–324, immediately
after chapter 312 in the published V24 fixed at
`20e626496c24518f133af6eb892c620ea52a3c59`. The sole reading edition is
the paired ReadFlow R1 PDF. Use the adjacent fixed identity record for
every exact manuscript hash and the PDF hash.

The volume's prerequisites are one-variable complex analysis, real
multivariable calculus, measure and integration, the Hilbert projection
and representation theorems, and the standard tools explicitly
introduced in the chapters. The chapter entry for local rings recalls
the algebra it uses. A new definition should be usable when it appears.

The mathematical route is local holomorphy and estimates, Hartogs
extension and integral forms, holomorphic hulls and pseudoconvexity,
local and weighted `d-bar` solutions, Oka–Weil and Levi sufficiency,
Bergman models, then Weierstrass and analytic local examples. The
coverage map identifies the obligations without supplying author or
earlier-review conclusions. Ch323–324 form an interface to V158.
General coherence, analytic-space and normalization theorems remain
in that later volume. Higher (0,q) estimates and boundary regularity
are outside the selected weighted ((0,1))-form route.

The references are the approved fixed public versions only:

| Public source | Scratch path |
|---|---|
| Lebl, *Tasty Bits of Several Complex Variables*, v4.4 | `v25-prep/Lebl-SCV-v4.4.pdf` |
| Korevaar–Wiegerinck, *Several Complex Variables*, 2017 | `v25-prep/Korevaar-Wiegerinck-SCV-2017.pdf` |
| Demailly, *Complex Analytic and Differential Geometry*, 2012 | `v25-prep/Demailly-CADG-2012.pdf` |
| Boas, *Lecture Notes on Several Complex Variables*, 2013 | `v25-prep/Boas-SCV-Fall2013.pdf` |

The published V24 and other volumes, original references and
curriculum tables, supplied extractor, and adopted template are
frozen. The reviewer reads the V25 manuscript and PDF as fixed
artifacts. Return any issue with its original wording, exact
chapter/lines or label, impact, responsible role, repair condition,
and any downstream dependencies to recheck.

Read the volume sequentially in the first pass. Check statements as
written, including type, quantifiers, equality and operations,
hypotheses, named or implicit prerequisites and proof dependencies,
all worked examples and exercises. Independently diagnose the fixed
text before reading the earlier defect history. Report the lines and
hashes actually read. Engineering and semantic results have separate
evidence. If further repairs are necessary, recheck the corrected
version and all affected downstream use before final signature.
