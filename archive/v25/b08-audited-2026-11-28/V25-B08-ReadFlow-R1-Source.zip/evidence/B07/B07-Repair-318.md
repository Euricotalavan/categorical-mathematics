# B07 有界修補｜Ch318

2026-11-28。只修改 canonical `v25-work/book/manuscript/ch318.tex`；未改`qa/b07-fixed`、PDF、其他章或模板，未啟動編譯。依主控轉交的I318-01及peak來源指向意見，實核後作有界修正。此回執不是打厚終審通過。

## 版本

- 修前 SHA-256：`8e7db57790a4a689403cf82b46b4affd8b87d00076c2afb7dbbe4826cd5b33d6`。
- 修後 SHA-256：`d7b8eb60f6d86e39ca92503bd6ff675b4789943129f2e5ccf4878a3222477861`。

## 修補與知識核對

1. **Unbounded power model參數。** 例題原158行只寫m≥1，可能包含實數m=3/2，此時|z|³在z=0不具有C∞正則性。改為“a positive integer m”。並補|z|^(2m)=(z bar z)^m是real polynomial；因此defining function C∞且r_w=i/2≠0才足以推出smooth boundary。Levi計算m²|z|^(2m−2)|a|²、m=1處處strong、整數m>1在z=0 weak的分類維持正確。
2. **Scaling一致作用域。** 原608–621行明回指同一positive integer m與Example `ex:318-power`；沒有讓跨節出現的m重新變成未限定實參數。t仍real且t>0，D_t=(tz,t^(2m)w)的全純性是對(z,w)而言，逆D_(1/t)、r∘D_t=t^(2m)r與real Jacobian t^(4m+2)全部不變。
3. **Local peak來源。** 原“by Chapter317”會讓讀者誤以為317已有peak構造。現精確指向317 `prop:317-narasimhan`的local convexification，再指本章新穩定label `prob:318-strong-peak`的完整構造。該題解也改成同一convexification label。計算仍由2Reℓ+Q+o(|z|²)、Q正定推出Reℓ≤−c|z|²/2，再取expℓ；這是真正的local peak證明，未聲稱整域全局peak。

## 相鄰與下游回核

- 本章E_m在原132行已取positive integer，sphere/no-disc ellipsoid證明也明寫integer m≥1，不須擴大重寫。後續弱點peak及contact-order例都在同一E_m整數族上，未改。
- `ex:318-power`及其他既有labels保持；新增 `prob:318-strong-peak`唯一次定義，兩處引用均指其真正內容。`prop:317-narasimhan`在canonical317仍存在，正則性C²及局部雙全純結論吻合。
- 未將本文模型變成一般實m的C²版本；因此不新增邊界正則性例外或單獨定理。後續拿這個smooth模型做Levi測試仍有足夠假設。
- 此次未改316/317或其他章。316/317的獨立有界修補各有自己receipt；本檔不作跨版本編譯或PDF通過聲明。

## 精確行號對照

| 修前起行 | 修後起行 | 項目 |
|---:|---:|---|
|158|158|power model整數m|
|165|165|smooth的polynomial理由|
|542|543|peak依賴兩個精確label|
|608|611|scaling重申同一m|
|816|820|peak exercise新增穩定label|
|823|827|題解精確引用convexification|

## 完整差異

```diff
--- ch318.tex BEFORE 8e7db57790a4a689403cf82b46b4affd8b87d00076c2afb7dbbe4826cd5b33d6
+++ ch318.tex AFTER d7b8eb60f6d86e39ca92503bd6ff675b4789943129f2e5ccf4878a3222477861
@@ -155,14 +155,15 @@
 definite Levi form.
 
 \begin{example}[An unbounded power model]\label{ex:318-power}
-For \(m\ge1\), let
+For a positive integer \(m\), let
 \(\Omega_m=\{(z,w):\ImPart w>|z|^{2m}\}\). Here
 \[
  r=|z|^{2m}-\ImPart w,\quad
  \partial r(a,b)=m|z|^{2m-2}\overline z a+(i/2)b,
  \quad H_r(a,b)=m^2|z|^{2m-2}|a|^2.
 \]
-The boundary is smooth everywhere since \(r_w=i/2\ne0\). A nonzero
+Here \(|z|^{2m}=(z\overline z)^m\) is a real polynomial, so the boundary
+is smooth everywhere since \(r_w=i/2\ne0\). A nonzero
 complex tangent must have \(a\ne0\), since otherwise the tangency
 equation also gives \(b=0\). For \(m>1\), precisely the points with
 \(z=0\) are weak; the others are strong. A psh exhaustion is
@@ -539,8 +540,10 @@
 A supporting real hyperplane of a convex set becomes a holomorphic
 linear functional by taking its real part. A local peak function turns
 this geometric separation into a function whose modulus singles out
-one boundary point. Strong pseudoconvexity supplies local peak functions
-by Chapter 317, but some weak points have them too. The models make the
+one boundary point. The local convexification in
+Proposition~\ref{prop:317-narasimhan} yields local peak functions at
+strong points; Problem~\ref{prob:318-strong-peak} below gives the
+construction. Some weak points have them too. The models make the
 logical differences explicit.
 
 \begin{proposition}[Peaking at a weak ellipsoid point]
@@ -605,8 +608,9 @@
 conclusion.
 \end{example}
 
-The unbounded model \(\Omega_m\) exhibits the corresponding scaling.
-For real \(t>0\), put
+The unbounded model \(\Omega_m\), with the same positive integer
+\(m\) as in Example~\ref{ex:318-power}, exhibits the corresponding
+scaling. For real \(t>0\), put
 \[
  D_t(z,w)=(tz,t^{2m}w).
 \]
@@ -813,15 +817,15 @@
 boundary constraint.
 \end{psolution}
 
-\begin{problem}[Local peak functions at strong points]
+\begin{problem}[Local peak functions at strong points]\label{prob:318-strong-peak}
 Show that at a strongly pseudoconvex \(C^2\) boundary point \(p\),
 there is a holomorphic function on a neighborhood of \(p\) with value
 one at \(p\) and modulus strictly less than one on the nearby closed
 domain except at \(p\).
 \end{problem}
 \begin{psolution}
-Use the local convexification from Chapter 317 and translate \(p\) to
-zero. In the resulting coordinates the defining function has expansion
+Use the local convexification in Proposition~\ref{prop:317-narasimhan}
+and translate \(p\) to zero. In the resulting coordinates the defining function has expansion
 \(2\RePart\ell(z)+Q(z)+o(\|z\|^2)\), where \(\ell\ne0\) is
 complex linear and \(Q\) is positive definite as a real quadratic
 form. Shrink so that \(Q(z)+o(\|z\|^2)\ge c\|z\|^2\).
```

下一步只由主控收集修補並統一重編，再以固定新版source/PDF交打厚複核。本代理未將歷史修補資訊傳給final_audit。
