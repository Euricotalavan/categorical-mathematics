# B07 bounded repair: Ch319 ambient types and support exercise

Repair ID: V25-B07-REPAIR-319-v1 · 2026-11-28. Responsible content task: dbar expansion. Controller requested exactly two bounded typing changes following the clean B07 first-pass review. This repair does not declare either the chapter or volume passed; the controller collects it for rebuilding and the final auditor rechecks the fixed new pair.

## Exact file and hashes

Only canonical `v25-work/book/manuscript/ch319.tex` was edited. `v25-work/qa/b07-fixed` was not edited. No compile was run, no PDF was changed, and no other manuscript was edited.

- Before SHA-256: `bf170a96104555ff44265674d22eb8dfddb7b9bac230362e73ac1dec2f35f0ac`
- After SHA-256: `caeec9bc002f0aab6e8f021d456c450f53e7f1866a071cb0aa48304ef91d3117`
- Ch320 inspected read-only, SHA-256: `711b5c5317af631bac463fcc09bd5a6eb2e006fb7aa579a7acd15b826e4f04c2`

## Repair319-TYPE-01: ambient degree range before graph-domain use

Location: section “The operators that a norm estimate will use”, first definition of H_q (formerly source line576). Original:

```tex
Set \(H_q=L^2_{(0,q)}(\Omega,\dd V)\), with
```

Replacement:

```tex
Set \(H_q=L^2_{(0,q)}(\Omega,\dd V)\) for \(0\le q\le n\), and
\(H_q=\{0\}\) for \(q>n\). In the first range, use
```

Impact and recheck: the coefficient inner product remains the existing one for increasing tuples of degrees0 throughn. The zero space for degrees above n is now defined before the displayed maximal-domain definition calls H_(q+1), including q=n. For n=1, S=dbar_1 has source H_1 and target H_2={0}, with S zero on all H_1. This matches the already explicit later sentence identifying H_2={0} for n=1, and it does not change the closed-graph or kernel proofs. No symbol was repurposed and no estimate changed.

## Repair319-TYPE-02: right-hand-side type in the support exercise

Location: problem “Support and a connected complement” (formerly source lines734–740). Original:

```tex
\(\CC^n\setminus K\) is connected, and a smooth closed form \(f\)
```

Replacement:

```tex
\(\CC^n\setminus K\) is connected, and a smooth closed \((0,1)\)-form \(f\)
```

Impact and recheck: the problem now explicitly invokes exactly the smooth closed compactly supported(0,1) data of Theorem\ref{thm:319-compact}, with a scalar compactly supported primitive. Its assumptions n≥2, compactK and connected complement, and its proof/localization conclusion remain unchanged. No higher-degree compact-support theorem is asserted.

## Direct dependency check in Ch320

Read the weighted-space setup, test-form identity, closed-subspace projection, weighted graph approximation, weighted existence theorem and compact-support exercise in canonical Ch320. The principal data and test forms there are explicitly(0,1); dbar v is(0,2). In n=1 the antisymmetric coefficient sum overj<k is empty, so its value and norm are zero in the newly explicit zero target space. The commutator identity then reduces to the one-variable identity already proved. The closed-subspace projection N=ker dbar and the use of Proposition\ref{prop:319-closed} retain the same meaning; N is all weighted(0,1) forms in the one-dimensional case. The graph-approximation statements also remain valid with their zero dbar term. The compact-support reference in Ch320 distinguishes its pseudoconvex weighted solution from the all-space n≥2 compact-support result and does not require a new theorem variant.

No downstream theorem or proof patch is necessary for these two repairs. One analogous wording point is retained for the controller: the Ch320 compact-support exercise still says “smooth closed form”; the weighted theorem it explicitly invokes supplies type(0,1). This report records that wording rather than editing it outside the authorized Ch319 scope. The controller can separately request the same explicit type if desired. No claim about a newly compiled layout or paired PDF is made. Pass condition: controller fixes source/PDF pair after collecting repairs, then final auditor checks the two replacements and direct uses in that exact pair. Reports were not sent to the final-audit task; controller receives this record.
