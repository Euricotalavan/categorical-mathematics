# Several Complex Variables

Categorical Mathematics · Volume 25 · Chapters 313–324

This source bundle can be built with Python 3.10+, XeLaTeX, the TeX Live packages loaded by the ReadFlow style, and fontconfig. The supplied font files and notices are in dependencies. The source ZIP manifest and engineering evidence distinguish template, manuscript, and paired output.

Run the following commands from the extracted source directory.

    python verify.py
    python tools/build.py --full --name rebuild

The compiled reading PDF is .build/rebuild/volume25.pdf. The paired PDF shipped with the source is checked by verify.py as recorded in MANIFEST.json. A single chapter can be built with python tools/build.py --chapter 313 --allow-diagnostics. References to chapters outside that single-chapter build resolve in the full volume.

The reference rebuild was performed under Linux with TeX Live. To build with an existing TeX installation on another system, install or expose the exact font files in dependencies/fonts, then use XeLaTeX on volume-25.tex from layout/study. Run it until the table of contents and references settle. The fonts remain subject to their accompanying notices.

The three ReadFlow R1 style files are exact copies from the adopted V0 edition, fixed at commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3. The entry, front matter, bibliography, and notation adapter are specific to this volume. The source references and selected PDF page locators are documented in the evidence directory.
