# V25 font dependency notice

These font files are redistributed unmodified with their existing filenames
and internal names. Their immediate donor was the licensed dependency subtree
of the fixed V24 source ZIP at commit `20e626496c24518f133af6eb892c620ea52a3c59`.
The hash of that ZIP and the adopted template hashes are recorded in
`../evidence/ReadFlow-baseline.json`. The adopted V0 R1 source ZIP itself
does not include the fonts.

PagellaX uses the included newpx/LPPL notices; Asana and STIX use their included
OFL notices; Noto uses its included copyright/OFL notice; DejaVu uses its
included copyright/license. See `licenses/` for the notices and the release
`MANIFEST.json` for the exact bundled file hashes. The template's historical
technical notices in `../licenses/` document separate Study dependencies.
