#!/usr/bin/env python3
"""Compile a V25 chapter, calibration sample, or the entire ReadFlow edition."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / "layout" / "study"
DIAGNOSTIC = re.compile(
    r"Missing character:.*|Undefined control sequence.*|"
    r"LaTeX Warning: (?:Reference|Citation|There were undefined).*|"
    r".*multiply-defined.*|.*destination with the same identifier.*|"
    r"Overfull \\[hv]box[^\n]*|Package fancyhdr Warning[^\n]*"
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command, directory, environment, log_file):
    result = subprocess.run(command, cwd=directory, env=environment,
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log_file.write_text(result.stdout)
    if result.returncode:
        raise SystemExit(result.stdout[-6000:])


def prepare_environment(runtime):
    fonts = ROOT / "dependencies" / "fonts"
    format_dir = runtime / "format"
    format_dir.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env.update(
        SOURCE_DATE_EPOCH="1795824200",
        FORCE_SOURCE_DATE="1",
        TEXMFVAR=str(runtime / "texmf-var"),
        TEXMFCONFIG=str(runtime / "texmf-config"),
        TEXFORMATS=str(format_dir) + os.pathsep,
        OPENTYPEFONTS=str(fonts) + "//" + os.pathsep,
        TEXINPUTS=str(STUDY) + os.pathsep,
    )
    if Path("/usr/share/texlive/texmf-dist").is_dir():
        env.update(TEXMF="{/usr/share/texmf,/usr/share/texlive/texmf-dist,/etc/texmf}", TEXMFDBS="")
    font_config = runtime / "fonts.conf"
    font_config.write_text(
        '<?xml version="1.0"?>\n<!DOCTYPE fontconfig SYSTEM "fonts.dtd">\n'
        '<fontconfig><include ignore_missing="yes">/etc/fonts/fonts.conf</include>'
        f"<dir>{escape(str(fonts))}</dir>"
        f"<cachedir>{escape(str(runtime / 'font-cache'))}</cachedir></fontconfig>\n"
    )
    env["FONTCONFIG_FILE"] = str(font_config)
    if not (format_dir / "xelatex.fmt").exists():
        run(["xetex", "-ini", "-etex", "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "-jobname=xelatex", f"-output-directory={format_dir}", "xelatex.ini"],
            STUDY, env, runtime / "format-generation.txt")
    return env


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument("--full", action="store_true")
    selection.add_argument("--chapter", type=int, choices=range(313, 325))
    selection.add_argument("--sample", type=Path)
    parser.add_argument("--name")
    parser.add_argument("--allow-diagnostics", action="store_true")
    args = parser.parse_args()

    name = args.name or ("full" if args.full else f"chapter-{args.chapter}" if args.chapter else "sample")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
        parser.error("Build name must contain only ASCII letters, numbers, underscores, or hyphens.")
    output = ROOT / ".build" / name
    output.mkdir(parents=True, exist_ok=True)
    env = prepare_environment(output / "runtime")

    if args.full:
        entry = STUDY / "volume-25.tex"
        sources = sorted((ROOT / "manuscript").glob("ch*.tex"))
    else:
        chapter = args.chapter or 313
        source = args.sample.resolve() if args.sample else ROOT / "manuscript" / f"ch{chapter}.tex"
        if not source.is_file():
            parser.error(f"Missing chapter source {source}.")
        sources = [source]
        entry = output / "entry.tex"
        opening = r"\chapter{Calibration: Taylor coefficients}" if args.sample else ""
        entry.write_text("\n".join((
            r"\documentclass[11pt,oneside,openany]{book}",
            r"\usepackage{mathtools}", r"\input{config}", r"\input{v25-setup}",
            r"\begin{document}", r"\mainmatter", rf"\setcounter{{chapter}}{{{chapter - 1}}}",
            opening, rf"\input{{{source.as_posix()}}}",
            r"\backmatter", r"\input{references}", r"\end{document}",
        )) + "\n")

    before = {str(source.relative_to(ROOT)) if source.is_relative_to(ROOT) else source.name: digest(source)
              for source in sources}
    previous = None
    for attempt in range(1, 7):
        run(["xelatex", "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "-recorder", "-jobname=volume25",
             f"-output-directory={output}", str(entry)],
            STUDY, env, output / f"pass-{attempt}.txt")
        state = tuple(digest(file) for suffix in ("aux", "toc", "out")
                      if (file := output / f"volume25.{suffix}").is_file())
        if state == previous:
            break
        previous = state
    else:
        raise SystemExit("Reference and contents files did not converge after six passes.")

    after = {str(source.relative_to(ROOT)) if source.is_relative_to(ROOT) else source.name: digest(source)
             for source in sources}
    if before != after:
        raise SystemExit("A chapter changed during build. Run again on a fixed source.")
    diagnostics = DIAGNOSTIC.findall((output / "volume25.log").read_text(errors="replace"))
    output_pdf = output / "volume25.pdf"
    report = {
        "sources": after, "passes": attempt, "diagnostics": diagnostics,
        "pdf_bytes": output_pdf.stat().st_size, "pdf_sha256": digest(output_pdf),
    }
    (output / "build-report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(output_pdf)
    if diagnostics and not args.allow_diagnostics:
        raise SystemExit("\n".join(diagnostics))


if __name__ == "__main__":
    main()
