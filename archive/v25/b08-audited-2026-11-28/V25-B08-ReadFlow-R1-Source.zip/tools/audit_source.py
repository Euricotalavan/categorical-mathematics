#!/usr/bin/env python3
"""Check chapter coverage, label resolution, and exercise/solution counts."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
CHAPTER = re.compile(r"\\chapter\{")
LABEL = re.compile(r"\\label\{([^}]+)\}")
REFERENCE = re.compile(r"\\(?:ref|eqref|autoref|pageref)\{([^}]+)\}")
CITATION = re.compile(r"\\cite(?:\[[^\]]*\])?\{([^}]+)\}")
BIBITEM = re.compile(r"\\bibitem\{([^}]+)\}")
BEGIN = re.compile(r"\\begin\{([^}]+)\}")


def read_tex(path):
    return re.sub(r"(?<!\\)%[^\n]*", "", path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    numbers = range(313, 325)
    labels = Counter()
    references = set()
    citations = set()
    problems = []
    chapters = {}
    expected_files = {f"ch{number}.tex" for number in numbers}
    actual_files = {p.name for p in (ROOT / "manuscript").glob("*.tex")}
    if actual_files != expected_files:
        problems.append(f"Missing chapter files: {sorted(expected_files - actual_files)}")
        problems.append(f"Extra chapter files: {sorted(actual_files - expected_files)}")
    for number in numbers:
        name = f"ch{number}.tex"
        if name not in actual_files:
            continue
        file = ROOT / "manuscript" / name
        source = read_tex(file)
        found_labels = LABEL.findall(source)
        if len(CHAPTER.findall(source)) != 1 or f"ch:{number}" not in found_labels:
            problems.append(f"Chapter {number} does not have exactly one required heading and label.")
        labels.update(found_labels)
        references.update(REFERENCE.findall(source))
        for group in CITATION.findall(source):
            citations.update(key.strip() for key in group.split(","))
        envs = Counter(BEGIN.findall(source))
        if envs["problem"] != envs["psolution"]:
            problems.append(f"Chapter {number} has a different count of exercises and solutions.")
        chapters[number] = {
            "sections": len(re.findall(r"\\section\{", source)),
            "examples": envs["example"],
            "exercises": envs["problem"],
            "solutions": envs["psolution"],
            "proofs": envs["proof"],
        }
    bibliography = read_tex(ROOT / "layout" / "study" / "references.tex")
    for key in sorted(citations - set(BIBITEM.findall(bibliography))):
        problems.append(f"Unknown bibliography key: {key}")
    for key in sorted(references - set(labels)):
        problems.append(f"Unresolved source label: {key}")
    for key, count in sorted(labels.items()):
        if count != 1:
            problems.append(f"Repeated label ({count}): {key}")
    report = {
        "chapters": chapters,
        "totals": dict(sum((Counter(values) for values in chapters.values()), Counter())),
        "source_diagnostics": problems,
        "scope": "Structural source checks.",
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if problems:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
