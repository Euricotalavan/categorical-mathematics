# Categorical Mathematics · V0–V2 Chapter-by-chapter revision · complete V0–V2 · v8

The PDFs in `reading/` are the linked reading set. Open them from the same folder and keep the three filenames `volume-0.pdf`, `volume-1.pdf`, and `volume-2.pdf`. Volume 1 links to Volume 0, and Volume 2 links to Volume 1.

## Build

Use Python 3 with XeLaTeX and the existing ReadFlow R1 TeX packages and fonts. The build resolves TeX Gyre Pagella X (Regular, Italic, Bold, BoldItalic), Noto Sans, DejaVu Sans Mono, Asana Math, and STIX Two Math from the local installation. Install the named font files and make them visible to XeLaTeX before building. The reference build used XeTeX 0.999996, TeX Live 2025/dev.

```sh
python verify.py
python build-edition.py --entry volume
python build-edition.py --entry print
```

The build runs V0 → V1 → V2, updates the cross-volume reference indexes, and puts the outputs in `rebuilt-reading/` or `rebuilt-print/`. Keep the three linked PDFs together in either output directory. Build artifacts and refreshed indexes belong in a working copy of the source tree.

`source/V0`, `source/V1`, and `source/V2` contain the LaTeX sources, illustrations, and build dependencies used by both outputs. `MANIFEST.json` identifies the packaged files.

This is the v8 editorial candidate. The body uses the adopted ReadFlow R1 10.4 pt type and 16 pt baseline spacing. Independent mathematical final review and the inherited open items remain pending.
