#!/usr/bin/env python3
"""Verify byte counts and SHA-256 hashes for the delivered source and PDFs."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text())
failures = []
for item in manifest['files']:
    path = root / item['path']
    if not path.is_file():
        failures.append(f"Missing: {item['path']}")
        continue
    data = path.read_bytes()
    if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
        failures.append(f"Changed: {item['path']}")
if failures:
    raise SystemExit('\n'.join(failures))
print(f"Verified {len(manifest['files'])} delivered files.")
