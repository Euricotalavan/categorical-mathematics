#!/usr/bin/env python3
"""Build the three volumes in dependency order and assemble their linked PDFs."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--entry', choices=('volume', 'print'), default='volume')
mode = parser.parse_args().entry
destination = root / ('rebuilt-reading' if mode == 'volume' else 'rebuilt-print')
destination.mkdir(exist_ok=True)
for volume in range(3):
    source = root / 'source' / f'V{volume}'
    (source / ('qa/editorial' if volume == 1 else 'qa')).mkdir(parents=True, exist_ok=True)
    subprocess.run([sys.executable, 'build.py', '--entry', mode], cwd=source, check=True)
    generated = source / '.build' / mode
    stem = f'volume-{volume}-study' if mode == 'volume' else 'print'
    shutil.copyfile(generated / f'{stem}.pdf', destination / f'volume-{volume}.pdf')
    for recipient in range(volume + 1, 3):
        external = root / 'source' / f'V{recipient}' / 'layout' / 'external'
        external.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(generated / f'{stem}.aux', external / f'volume-{volume}.aux')
print(f'PDFs: {destination}')
