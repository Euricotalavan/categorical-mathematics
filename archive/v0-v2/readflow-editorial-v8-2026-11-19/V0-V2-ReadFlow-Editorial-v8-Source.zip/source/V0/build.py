#!/usr/bin/env python3
"""Build only the F1 Volume 0 editorial Study candidate, using persistent auxiliaries."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess
ROOT=Path(__file__).resolve().parent
WORK=ROOT/'layout/study'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--draft',action='store_true');p.add_argument('--entry',choices=['volume','print','notebook','template'],default='volume');a=p.parse_args()
 stem={'volume':'volume-0-study','print':'print','notebook':'notebook','template':'template'}[a.entry]
 out=ROOT/'.build'/a.entry;out.mkdir(parents=True,exist_ok=True);env=os.environ.copy()
 env['TEXINPUTS']=str(WORK)+os.pathsep+str(ROOT/'upstream/source')+os.pathsep+env.get('TEXINPUTS','')
 previous=None;records=[]
 for run in range(1,7):
  cmd=['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder','-output-directory='+str(out),stem+'.tex']
  s=subprocess.run(cmd,cwd=WORK,env=env,text=True,capture_output=True)
  (out/f'pass-{run}.txt').write_text(s.stdout+s.stderr)
  if s.returncode:print((s.stdout+s.stderr)[-6500:]);raise SystemExit(s.returncode)
  state=[sha(out/(stem+'.'+ext)) if (out/(stem+'.'+ext)).exists() else '' for ext in ['aux','toc','out']]
  if state==previous and run>=2:break
  previous=state
 else:raise RuntimeError('Auxiliary state did not converge')
 log=(out/(stem+'.log')).read_text(errors='replace')
 hard=re.findall(r'Missing character:.*|Undefined control sequence.*|LaTeX Warning: Reference.*|LaTeX Warning: There were undefined.*|.*multiply-defined.*|.*destination with the same identifier.*',log)
 over=re.findall(r'Overfull \\[hv]box[^\n]*|Package fancyhdr Warning[^\n]*',log)
 under=re.findall(r'Underfull \\[hv]box[^\n]*',log)
 rec={'entry':a.entry,'converged_passes':run,'hard_diagnostics':hard,'overfull_or_header_diagnostics':over,'underfull_diagnostics':under,'pdf_sha256':sha(out/(stem+'.pdf'))}
 (ROOT/'qa'/f'build-{a.entry}.json').write_text(json.dumps(rec,indent=2)+'\n')
 shutil.copyfile(out/(stem+'.log'),ROOT/'qa'/f'{a.entry}.log')
 if hard or (over and not a.draft):raise RuntimeError('Final build diagnostics require correction; see qa')
 if a.entry in ('volume','print'):
  name = 'V0_ReadFlow_R7_Reading.pdf' if a.entry=='volume' else 'V0_ReadFlow_R7_Print.pdf'
  shutil.copyfile(out/(stem+'.pdf'), ROOT/name)
 print(json.dumps(rec,indent=2))
if __name__=='__main__':main()
