# Volume 2 F1 / Study L2 — first editorial candidate

This independent English edition implements workflow Steps8–10 in four consolidated batches. It is ready for the two separate concentrated Step11 replies. It is not EN-STABLE, a final-volume certificate, an exhaustive-reference claim or closure of the common-foundation programme.

The matching compiled PDF has **181 physical pages**: six front pages,174 body pages (Chapters29–51), and one optional working-notes page. The original147-page author checking PDF is a different presentation, not this edition and not a page-count target. Extra layout pages are not new mathematics.

Open `categorical-mathematics-volume-2-f1-study-l2-editorial-candidate.pdf`. For the exact source pin and received reports see `provenance/inputs.json`. Full frozen F1 payload is retained under `upstream/`; its725-item manifest remains historical evidence. The current editing layer is `layout/`, mapped to89 source inputs by `provenance/source-map.json`; it is not a new canonical source. The accepted Study style,config,fonts match `provenance/template-map.json` exactly. V0/V1 were neither rebuilt nor changed.

See `BUILD-AND-RECOVERY.md`, `QA.md`, `DESIGN.md`, `editorial/REVIEW-SUMMARY.md`, exact reversible ledgers and `qa/`. `MANIFEST.json` inventories this package; the separate final delivery receipt records actual saved versions/hashes and readback because a package cannot contain its own final ZIP hash.

All532 labels and original statement/exercise/equation numbers,138 explicit proofs,136 complete inline answer containers and5,565 original mathematical expressions are preserved. Formal text is exact after reversing only the declared typography; all ordered math payloads and original source/view relationships pass the guards. No general proof was replaced by numerical examples.

Six global gates remain OPEN. Designated Tao4,Burton7,Abbott2 and Lawvere–Rosebrugh bodies remain UNKNOWN. Stated data-supply/state/invariant/zero-one qualifications and the internal/external model boundary remain in the manuscript. The existing formal V2 boundary/expansion agreement is accepted without reopening it; the separate broad planning/literature line does not substitute for that agreement.
