#!/usr/bin/env python3
"""Exact V2 F1 source/layout guards; not mathematics/foundation certification."""
from pathlib import Path
import json,hashlib,re,argparse,sys,subprocess,unicodedata
from editorial_tools import protected_regions
from aux_labels import labels as aux_labels
R=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
J=lambda n:json.loads((R/n).read_text())
def maths(s):
 return re.findall(r'\\begin\{equation\*?\}.*?\\end\{equation\*?\}|\\\[.*?\\\]|\\\(.*?\\\)|(?<!\\)\$[^$]*?(?<!\\)\$',s,flags=re.S)
def mathnorm(s):
 s=s.replace(r'\begin{tikzcd}[column sep=7em, row sep=3em]',r'\begin{tikzcd}[column sep=large]') # exact declared diagram spacing, not math payload
 s=re.sub(r'\\begin\{(?:equation\*?|gathered|aligned)\}|\\end\{(?:equation\*?|gathered|aligned)\}|\\\[|\\\]|\\\(|\\\)|\$', '', s)
 s=re.sub(r'\\(?:allowbreak|quad|qquad|enspace)\b|\\[,;!]','',s)
 s=s.replace(r'\text{and }','').replace('\\\\','').replace('&','')
 return re.sub(r'[\s,.;:]','',s)
def answers(s):
 # Exact inline Solution paragraphs through the next unit boundary.
 out=[]
 for m in re.finditer(r'\\paragraph\{Solution\.\}',s):
  e=re.search(r'\\begin\{problem\}|\\Needspace|\\(?:subsection|section)\*?\{',s[m.end():]);out.append(s[m.start():m.end()+e.start() if e else len(s)])
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pdf',action='store_true');a=ap.parse_args()
 m=J('upstream/MANIFEST-REFINEMENT.json');assert len(m)==725
 for x in m:
  p=R/'upstream'/x['path'];assert p.stat().st_size==x['bytes'] and H(p)==x['sha256'],x['path']
 c=subprocess.run([sys.executable,str(R/'upstream/refinement/verify-F1.py')],capture_output=True,text=True);assert c.returncode==0,c.stdout+c.stderr
 mapping=J('provenance/source-map.json');assert len(mapping)==89
 en=J('editorial/edits.json');le=J('editorial/layout-edits.json');local=[];refs=[];proofs=0;byteproofs=0;forms=0;byteforms=0;acs=0;mathcount=0
 for x in mapping:
  base=(R/x['frozen_presentation']).read_text();live=(R/x['derived']).read_text();assert hashlib.sha256(base.encode()).hexdigest()==x['derived_initial_SHA256']
  reverse=live
  for e in reversed([e for e in en+le if e['path']==x['derived']]):
   assert reverse.count(e['after'])==1,e['id'];reverse=reverse.replace(e['after'],e['before'],1)
  assert reverse==base,('Unrecorded mutation',x['derived'])
  stripped=live
  for e in reversed([e for e in le if e['path']==x['derived']]):
   assert stripped.count(e['after'])==1,e['id'];stripped=stripped.replace(e['after'],e['before'],1)
  # Every formal region, proof and answer is exact after undoing only declared typography.
  aa=protected_regions(base);bb=protected_regions(stripped);cc=protected_regions(live);assert [z for _,_,z in aa]==[z for _,_,z in bb],('Formal words changed',x['derived']);assert len(aa)==len(cc)
  forms+=len(aa);byteforms+=sum(u[2]==v[2] for u,v in zip(aa,cc))
  pattern=r'\\begin\{proof\}.*?\\end\{proof\}'
  aa=re.findall(pattern,base,re.S);bb=re.findall(pattern,stripped,re.S);cc=re.findall(pattern,live,re.S);assert aa==bb
  proofs+=len(aa);byteproofs+=sum(u==v for u,v in zip(aa,cc))
  aa=answers(base);assert aa==answers(stripped),('Answer content change',x['derived']);acs+=len(aa)
  assert mathnorm(''.join(maths(base)))==mathnorm(''.join(maths(live))),('Math token change',x['derived']);mathcount+=len(maths(base))
  ls=re.findall(r'\\label\{([^}]+)\}',live);assert ls==re.findall(r'\\label\{([^}]+)\}',base);local+=ls
  rs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',live);assert rs==re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',base);refs+=rs
 assert len(local)==len(set(local))==532 and proofs==138 and forms==421 and acs==136
 # Canonical/once-converted relations remain the original F1 facts; derived files are not canonical.
 for x in mapping:
  if 'view' in x:assert H(R/'upstream'/x['canonical'])==x['canonical_sha256'] and H(R/'upstream'/x['view'])==x['view_sha256']
 orig=(R/'upstream/source/volume-2.tex').read_text();body=orig[orig.index('\\mainmatter'):orig.index('\\end{document}')]
 expected=re.findall(r'\\input\{([^}]+)\}',body);entry=(R/'layout/study/volume-2-study.tex').read_text();body=entry[entry.index('\\mainmatter'):entry.index('\\backmatter')];actual=re.findall(r'\\input\{([^}]+)\}',body)
 assert actual==[s.replace('author-volumes/views/v2/','../views/v2/').replace('author-volumes/expansion-v2/','../expansion-v2/') for s in expected]
 assert re.findall(r'\\chapter\{([^}]+)\}',body)==re.findall(r'\\chapter\{([^}]+)\}',orig)
 for x in J('provenance/template-map.json'):assert H(R/x['path'])==x['SHA256']
 external={v:aux_labels(R/f'layout/external/volume-{v}.aux') for v in [0,1]};ext={k for d in external.values() for k in d};assert set(refs)<=set(local)|ext
 report={'frozen_manifest':725,'frozen_source_files':sum(p.is_file() for p in (R/'upstream/source').rglob('*')),'upstream_verifier':json.loads(c.stdout),'selected_canonical_once_converted_views_unchanged':60,'current_presentation_inputs':89,'inherited_labels':512,'new_expansion_labels':20,'all_unique_labels':532,'all_original_chapter_and_body_input_order_preserved':True,'explicit_proofs':proofs,'proofs_byte_equal':byteproofs,'proofs_equal_after_reversing_only_declared_typography':True,'formal_regions':forms,'formal_regions_byte_equal':byteforms,'all_formal_words_retained':True,'complete_inline_answer_containers':acs,'all_answer_words_and_order_retained':True,'original_math_expressions':mathcount,'ordered_math_payload_equal_ignoring_declared_layout_and_sentence_punctuation':True,'English_edits':len(en),'presentation_edits':len(le),'all_edits_exactly_reversible_to_frozen_source':True,'accepted_style_config_fonts_exact':True,'external_labels':sorted(set(refs)-set(local)),'mathematics_reproof_or_completeness_claim':False}
 if a.pdf:
  import fitz
  p=R/'categorical-mathematics-volume-2-f1-study-l2-editorial-candidate.pdf';d=fitz.open(p);names=d.resolve_names();auxp=R/'.build/volume/volume-2-study.aux';aux=aux_labels(auxp if auxp.exists() else R/'qa/build-evidence/volume-2-study.aux');author=aux_labels(R/'upstream/refinement/F1-volume-2.aux')
  for k in local:
   assert k in aux and aux[k]['destination'] in names,k
   assert aux[k]['value']==author[k]['value'],('Numbering semantics',k)
   assert aux[k]['page']==d[names[aux[k]['destination']]['page']].get_label(),('Label folio mismatch',k)
  counts={'internal':0,'remote_V0':0,'remote_V1':0,'URI':0};fonts=set();lines=[]
  for pg in d:
   assert '??' not in pg.get_text() and '\ufffd' not in pg.get_text(),pg.number+1
   for bl in pg.get_text('dict')['blocks']:
    for line in bl.get('lines',[]):
     bb=line['bbox'];assert -1<=bb[0] and -1<=bb[1] and bb[2]<=pg.rect.width+1 and bb[3]<=pg.rect.height+1,(pg.number+1,bb)
     spans=line['spans'];t=unicodedata.normalize('NFKC',''.join(s['text'] for s in spans));body=[s for s in spans if 'Schola' in s['font'] and 'Math' not in s['font'] and abs(s['size']-11.5*72/72.27)<.2]
     if len(t)>=30 and sum(len(s['text']) for s in body)>=.55*len(t):lines.append(len(t))
   for lk in pg.get_links():
    if lk['kind'] in [fitz.LINK_GOTO,fitz.LINK_NAMED]:assert 0<=lk['page']<len(d);counts['internal']+=1
    elif lk['kind'] in [fitz.LINK_GOTOR,fitz.LINK_LAUNCH]:
     file=lk['file'].split('#',1)[0];assert file in ['volume-0.pdf','volume-1.pdf'];v=int(file[7]);target=lk.get('to') or lk['file'].split('#nameddest=',1)[-1];obj=d.xref_object(lk['xref']);assert '/S /GoToR' in obj and '/F ('+file+')' in obj;assert target in {x['destination'] for x in external[v].values()},lk;counts[f'remote_V{v}']+=1
    elif lk['kind']==fitz.LINK_URI:counts['URI']+=1
    else:raise AssertionError(lk)
   fonts.update((f[0],f[3]) for f in pg.get_fonts(full=True))
  for x,n in fonts:assert d.extract_font(x)[3],n
  assert any('ScholaMath' in n for _,n in fonts)
  pct=lambda q:sorted(lines)[round((len(lines)-1)*q)]
  report['PDF']={'file':p.name,'SHA256':H(p),'bytes':p.stat().st_size,'physical_pages':len(d),'bookmarks':len(d.get_toc()),'links':counts,'all532_labels_and_author_statement_exercise_equation_number_values_preserved':True,'embedded_fonts':sorted(n for _,n in fonts),'prose_line_sample_count':len(lines),'characters_p50':pct(.5),'characters_p90':pct(.9),'characters_max':max(lines)}
 (R/'qa/source-and-pdf.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
