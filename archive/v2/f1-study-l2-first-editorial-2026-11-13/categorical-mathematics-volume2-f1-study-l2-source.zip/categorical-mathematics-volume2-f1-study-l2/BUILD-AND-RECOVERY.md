# Build and recovery

Extract the ZIP into a new directory. Keep its entire tree. Requirements: Python3, a complete XeLaTeX/TeX Live environment with fontspec,unicode-math,babel English,book,mathtools,amsthm,geometry,tikz-cd,fancyhdr,hyperref,xr-hyper,needspace and normal dependencies. The seven project OTFs and their licenses are included. For verification install PyMuPDF (`fitz`); the source-only invariant checks use the Python standard library. Poppler is needed only to regenerate page renders. Actual tool versions are in qa/toolchain.json.

From the extracted package root:

```
python3 verify.py --pdf
python3 build.py
python3 verify.py --pdf
python3 build.py --entry print
python3 build.py --entry notebook
python3 build.py --entry template
```

`build.py` runs only this V2 entry, without shell escape, retains incremental auxiliaries under `.build/`, and stops at converged AUX/TOC/OUT (up to six passes). The main PDF is copied to the package root only after a successful final build. White output is `.build/print/print.pdf`; blank outputs are `.build/notebook/notebook.pdf` and `.build/template/template.pdf`. The prebuilt main PDF and qa/build-evidence permit verification of a freshly restored package without rebuilding it. TeX timestamps/IDs/font subsets may make later compiler bytes differ; compare content and rendering rather than assuming byte-identical builds.

The driver derives directly from `upstream/source/volume-2.tex`, preserving its23 chapters,89 content inputs and original order. All complete book dependencies are included in `upstream/source/`; relative paths in the source map are authoritative. Current sibling AUX files are read-only context under `layout/external/`. Eight actual remote links target the delivered V1 PDF; place that accepted PDF beside this one as `volume-1.pdf` if supported by the viewer. Actual sibling IDs/hashes and named target checks are in `provenance/sibling-remote-targets.json`. Browser and mobile viewers may restrict external-file links. No sibling PDF is duplicated or rebuilt here.

Rollback: leave `upstream/` untouched. Every editable-content change in the89 mapped files has an exact before/after guard in `editorial/edits.json` or `layout-edits.json`. `verify.py` reverses these in memory and requires exact original bytes. The derived patch is for controlled review, not automatic application to a newer upstream. Original refinement rollback/patch tools remain under `upstream/refinement/`. Earlier independent checkpoints are listed in `provenance/checkpoints.json`; no original author/refiner package is overwritten. New upstream content requires a separate controlled mapping and authorization; never turn generated views into canonical sources.

The portable source does not bundle a TeX distribution, scratch caches, historical ZIP/PDF copies or rendered contact-sheet images. The actual page-render hashes and per-page visual coverage are retained; those images can be regenerated from the included matching PDF.
