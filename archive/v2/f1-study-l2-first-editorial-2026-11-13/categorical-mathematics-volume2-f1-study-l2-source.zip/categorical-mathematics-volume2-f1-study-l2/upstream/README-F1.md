# Volume 2 content F1 — current child source

Ready for editorial Steps8–10 within the agreed seven-strand, finite supplied-data and external EC scope. Start at refinement/VOLUME2-CONTENT-F1-HANDOFF.md. The current checksum manifest is MANIFEST-REFINEMENT.json. The old expansion manifest in refinement/parents/ and Step4 reports in evidence/ are historical; the exact input-PDF corrigendum is retained separately.

Build source/volume-2.tex directly. Do not run the shared all-volume generator or overwrite other volumes. The60 inherited canonical units/maps/views are unchanged. The two new mathematical supplement files carry the necessary repairs; other differences are local V2 routing/stage text. SOURCE-VERSION-MAP.json and EXACT-CHANGES.patch identify all11 source changes; their before bytes are retained. The guarded reconstruction helper accepts only matching old hashes.

The paired147-page author checking PDF, its actual delivered SHA256, and the distinction from the compiler's pre-delivery bytes are in the handoff/readback record. This is not a Study edition, EN-STABLE, a no-omissions certificate, or closure of any global gate. The original418 IDs,107 textbook rows and1882 registry remain intact; current review/implementation outcomes are separate derived tables.
