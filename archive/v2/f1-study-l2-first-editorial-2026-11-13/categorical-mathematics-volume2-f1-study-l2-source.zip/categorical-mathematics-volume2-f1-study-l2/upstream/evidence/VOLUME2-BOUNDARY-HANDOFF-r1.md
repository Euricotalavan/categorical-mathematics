# Volume 2 — boundary and coverage proposal r1

13 November 2026. Book-workflow-v1, Step 1. **Same r1 proposal, common-textbook consolidation; for expansion consensus, not yet adopted.**

Read `COMMON-TEXTBOOK-CONSOLIDATION.md` with this handoff. It records the authorized new sources, actual named-item comparisons and the revised four-supplement recommendation. This is not a second consensus return or a new mathematical-review round.

The existing draft is substantial enough to retain as the working manuscript. Recommend the seven routes below, with the four concentrated supplements specified in the consolidation, rather than a restart or a new number-theory course. This is a finite boundary proposal for the existing Volume 2, not a claim that every item in an unread reference has been included.

## Actual input and continuity

The exact retained F1 source v2 ZIP was hashed again: Library `libfile_fde3_f-e36f85c867988191a6acc33591ebe74c_383d682b1c388191a1961becbec9fb77`, file `file_0000000066b882069d4a87076dffa38d`, 2,307,983 bytes, SHA256 `925a60f1b853ed9d67806dbca7e6253a34e268106145bebe703912015cb59e13`. Its V2 maps select **60 existing canonical files in Chapters 29–51**. Each selected file matches its recorded current hash; none was edited.

The existing live matrix supplies 418 V2 rows in their original order: 23 chapter allocations and 395 formal-environment rows. These include eight definitions, 127 propositions, 127 explicit proof bodies, one explicit example and 132 problems. They are inventory counts, not coverage percentages or all forms of mathematics. Numerous definitions, calculations, examples and proofs are prose; the 60-unit section/interface index preserves their locations as well.

`v2-live-boundary-view.json` and `v2-boundary.csv` project the existing IDs; they are not a competing master. The 1882-ID registry and historical row states are preserved. Current canonical/hash/line fields are separate from historical CP38 fields, particularly for the already adopted EC122 navigation change. No historical reading window has been silently attached to a different hash.

This phase read all explicit proposition/definition statements, the explicit example, the exercise names, section routes and the necessary assumption/interface paragraphs. It did **not** re-prove 127 proofs or certify 132 full answers. Historical review states remain attributed to their original scopes. The later concentrated refinement must make its own completeness/rigor judgment and reuse valid evidence.

## Proposed finite route

| Route | Existing chapters | Required learning result and named content | Supply boundary |
|---|---|---|---|
| V2-S1 | 29–31 | Parameter monic/equality induction; addition, multiplication, powers and semiring laws; monoid iteration, primitive recursion, invariants, predecessor, truncated difference and cancellation | (A): supplied NNO, finite constructions and required exponentials; equations on products/arbitrary common sources |
| V2-S2 | 32–33 | Unique-gap order, positive gaps, comparison source decomposition, min/max; bounded indices, concatenation and folds; triangular, square and geometric identities; factorial | (S) for stable disjoint source cases and strict initial object; no global-point detection, object of all finite sequences or unproved division |
| V2-S3 | 34–36 | Witnessed divisibility, positive cancellation, parity; Boolean folds versus predicates; bounded least successful index, binary reconstruction; positive-divisor quotient/remainder and congruence compatibility | Classifier/image assumptions only at their stated predicate results; positive divisor means a supplied successor factor; failed bounded search is not unbounded failure |
| V2-S4 | 37–38 | Common-divisor witness transport in both directions; source-stable gcd test; Euclidean state, explicit countdown/stopping bound and constructed gcd | (A)+(S), without silently imposing classifier/(R) on these chapters; include zero boundaries and parameter change |
| V2-S5 | 39–44 | One effective integer difference quotient; additive/ring operations and universal tests; sign, order, magnitude; extended Euclid and Bézout coefficients; Diophantine tests, coprime cancellation, lcm, integer remainders, all linear-congruence solutions and compatible CRT; proposed prime-factorization and residue/fast-power supplements | (R)+(Z) added explicitly; only the indicated integer quotient is supplied. Moduli positive; actual whole-source witnesses and exact period conditions retained |
| V2-S6 | 45–46 | Reduced positive-denominator fractions and uniqueness; normalization as a proved effective quotient; ring/inverse/order/universal tests; finite rational bounds, Bernoulli, exact bisection and the rational square-root/completeness obstruction | Fraction quotient derived from finite constructions and arithmetic; do not assume it separately or infer an internal completion from finite approximants |
| V2-S7 | 47–51 | Ordinary external Cauchy/null data and quotient test; ring/order/inverses; Archimedean density, rational codes, canonical approximants; limits, sequential completeness and unique completion comparison; suprema, cuts, monotone completeness and floor; proposed small supremum-calculus supplement | Supplied ordinary-set (EC) function/subset/quotient data. Distinguish proved properties of this model from a realization inside a common structural foundation |

Exact names or statements for each definition, proposition, proof obligation and problem are in `NAMED-ITEMS.md`, `v2-named-items.json` and the existing-ID view. `v2-source-index.json` binds each to its actual selected canonical path/hash and line range. `unit-and-prose-interface-index.json` retains the section route, including prose-only definitions and worked calculations. A supplied statement being present does not imply its proof or external answer has been newly checked.

## Earlier designated references retained

The five newly required common textbooks, their fixed originals/access limits and107 added comparison rows are in `COMMON-TEXTBOOK-CONSOLIDATION.md` and the same `references.json` / `reference-to-manuscript.json`. The earlier35 rows below remain in order.

| Designated source | Fixed original and actual current use | Limit |
|---|---|---|
| Richard Hammack, *Book of Proof*, third edition, file edition 3.4, 2018 | Existing author PDF, SHA256 `e0e471ca794ddda7bc46704b22885e1582350b7fc5881f8ba9a61b3747ec79fd`; [author URL](https://richardhammack.github.io/BookOfProof/Main.pdf). Named material in §1.9, definitions 4.4–4.6, Proposition 7.1, Chapter 7 exercises 28–29, §§10.1–10.5 and §§11.2–11.5 was inspected at the exact pages in the reference table | Statement/definition/example correspondence, not new certification of external proofs or answers. This text accepts much ordinary arithmetic rather than constructing all number systems |
| Emily Riehl, *Category Theory in Context*, existing author-hosted revised PDF of the Dover 2016 text | SHA256 `e4779f34ff0432508f1105912f39a84af3c64799b969507325c80e27c2d994dd`; [author URL](https://emilyriehl.github.io/files/context.pdf). Example 2.1.1/footnotes, Example 3.1.19, Example 4.1.7 and relevant clauses of Example 4.1.10 | Only the named universal-property interfaces are relevant here. General monoid completion, arbitrary limits or a whole adjunction course are not V2 obligations |
| F. William Lawvere and Robert Rosebrugh, *Sets for Mathematics*, Cambridge University Press, 2003, DOI 10.1017/CBO9780511755460 | Bibliography and previous access limitation inherited | **Body UNKNOWN.** No chapter/page/theorem list reconstructed from metadata. Seven explicit correspondence-unknown rows remain visible |
| J. P. May, *Finite spaces and larger contexts*, existing fixed author draft | Original hash and precise previously read finite-space windows retained in `references.json` | Those windows do not supply a required V2 arithmetic/completion reference. No new May reading or downgrade of previous evidence |

The 142 reference-first rows stay visible even when no exact manuscript counterpart exists. Their statuses distinguish written coverage, partial scope, optional absence, and UNKNOWN. Exact proof/answer reading is separate. Reference targets have actual canonical paths/hashes/labels; missing items are not dropped simply because the old matrix started from manuscript environments.

The authorized common-textbook consolidation adds actual Stein/Lebl originals and named comparisons; Tao/Burton/Abbott remain contents-only. Lebl now supplies target-statement comparison for real fields and completeness, but explicitly omits the construction of R. LR correspondence, unavailable construction-text details and exhaustive literature coverage remain UNKNOWN. No new planning-line files were consulted or changed.

## Material condition differences

- **Induction:** Hammack permits a starting index of zero as well as other bases. The important distinction is ordinary arbitrary statements versus V2's represented monic/equality conditions and stored-state arrows, not zero versus one. Do not add an unrestricted internal predicate schema.
- **gcd/lcm:** Hammack Definition 4.6 excludes gcd(0,0) and restricts lcm to nonzero inputs. V2 uses greatest/leastness in divisibility order, with G(0,0)=0 and zero lcm boundaries. These are deliberate scope/convention differences; they do not establish a mathematical contradiction.
- **Bernoulli:** Hammack's example covers real x > -1. The existing V2 statement is the finite nonnegative-fraction version, including zero counter. Mark the broader statement partial; the extra negative-input/real version is not required by this proposed route.
- **Group completion:** Riehl's arbitrary commutative-monoid relation has an extra common summand. Natural cancellation removes it in the selected N case. V2's one supplied effective quotient must not be advertised as arbitrary-monoid or arbitrary-equivalence quotient existence.
- **Choices and completion:** Local representatives, a finite decision/search and the later canonical rational-code section are different constructions. The EC block states ordinary unique-value formation and classical predicates explicitly; this does not prove internal decidability or arbitrary global choice.

## Concentrated additions proposed for consensus

**GAP-V2-01 — whole-volume route and assumption map (P1, small synthesis).** The local A/S/R/Z/EC interfaces already exist and are substantive. What is missing is one concise map joining them into a reader's route: N versus Z versus F versus the ordinary EC number sets; arithmetic powers versus exponential objects; whole-source versus local-image witnesses; the switch at Chapter 47; V1 prerequisites and V4 continuation. Add a short opening route and one closing or transition map. Reuse the existing statements/proofs; add no policy, global axiom or new gate.

**GAP-V2-02 — residue representatives and the ring of classes (P2, compact mathematical bridge).** Remainder algorithms, congruence compatibility, signed witnesses and bounded CRT representatives are written. Hammack Definition 11.6 and its representative-independence discussion expose the missing consolidated number-system interpretation. Recommend including the following tightly bounded statements after the signed remainder interface, without rewriting CRT:

1. For one fixed positive modulus d, normalize integers into the already available bounded-index object of representatives below d, and state the retraction and equality-iff-congruence equations.
2. Prove the full effective quotient/factor test using that normalization; then descend addition, multiplication, zero, one and negation and prove their unital commutative-ring laws.
3. Include d=1, which gives the zero ring; do not allow d=0 through a positive-divisor theorem or promise a field without additional hypotheses.
4. Give one small numerical example and a short representative-independence/factorization exercise with full answer. Reuse the existing congruence calculations and supplied constructions; no new general quotient-existence or choice axiom is needed.

Add a bounded repeated-squaring correctness/termination result using the existing binary, power and congruence interfaces, as detailed in the consolidation. This is a named teaching/construction gap, not a discovered false congruence theorem. It is proposed for the one consensus decision, not silently added to the already agreed V1 scope. The consolidated proposal adds GAP-V2-03 (finite prime factorization) and GAP-V2-04 (small supremum calculus). Their precise statement/proof/data requirements are in the concentration report and JSON. The existing60 units remain; no wholesale replacement is requested.

**Earlier prime exclusion superseded:** prime definitions and finite unique factorization are now proposed core GAP-V2-03, not yet adopted.

**Still not selected:** a full prime-field/residue-field course; general monoid group completion; an initial-rig theorem; every odd-sum/factorial exercise in Hammack; p-adic/formal-series developments; arbitrary internal real completions; complex numbers. Exact absence/partial rows for optional reference items remain, but they are not compulsory gaps. No later-volume destination for these is invented.

## Earlier and later boundaries

V1 remains the supplied universal-construction prerequisite, especially NNO/parameter recursion in Chapter 28, regular images in Chapter 23, effective relations in Chapter 25, and stable/disjoint coproducts in Chapter 26. Do not reconstruct V1 or reopen its completed editorial cycle. Current F1 V1 canonical hashes are the compatible context here, not a claim to supersede its separately delivered second editorial edition.

V2 ends after the real ordered-field completion and its stated completeness comparisons. Nested intervals and root results are already selected in V4 Chapter 52 (`prop:ec-nested-intervals`); Bolzano–Weierstrass is there (`prop:ec-bolzano-weierstrass`); continuity appears in V4 Chapter 55 (`sec:ec-continuity-definition`). These locations are verified from the actual selection maps/labels, not suggestions presented as written. The full analysis/calculus course stays in V4. V3 remains reserved for Linear Algebra I; no work is assigned to it here. The current V2 is not a complete complex-number construction.

Six global framework gates remain OPEN. Their existing concrete limitations are inherited, not six new mini-tasks or fresh barriers to ordinary conditional refinement. LR body correspondence remains UNKNOWN. The current volume's proposed conditional/external structure is not formal adoption of a common foundation or a claim to full reference completeness.

## Handoff and continuation

Dot should route this one boundary package to the correct new expansion receiving line; do not restart the stopped old author or send work to a length-exhausted conversation. Expansion should confirm the seven routes, the four consolidated additions and the exclusions in one consolidated reply. At most one consolidated return is allowed; only a remaining disagreement then goes through dot to the user. No consensus is presumed by this file.

After consensus, preserve the 60 existing selections and stable IDs. A practical four-batch expansion plan is: (1) Chapters29–35 and route disclosure, (2)36–42 plus the prime block after coprime cancellation, (3)43–46 plus the residue/repeated-squaring bridge, (4)47–51, the small supremum calculus and joined assumption map. These are continuity/editing batches over an existing manuscript, not orders to rewrite127 proofs or expand every optional reference example. Checkpoints do not interrupt the workflow. The later refinement stage decides rigor/completeness within the agreed scope; no premature proof PASS is asserted here.

Recovery: the package preserves all60 exact V2 canonical files, current maps, necessary interface sources, existing418 rows, the unchanged1882 registry, reference locators/hashes, named items, reading scope and this handoff. The pinned full F1 archive remains the complete buildable ancestor. This boundary capsule is not itself a newly built V2 edition/PDF. No historical ZIP is nested; no manuscript, Study layout, GitHub archive or cloud file was modified/deleted.

## Same-proposal semantic consolidation (after durable version3)

Read MERGED-CONCEPT-BOUNDARY.md or its editable CSV/JSON for the deduplicated execution view. It covers every existing reference-first row without discarding provenance; the original107 added textbook rows and418 manuscript IDs/order are preserved. Closely synonymous definitions/results/example objectives are grouped while hypotheses, roles and source verdicts stay visible. FTA existence and uniqueness remain separate proof obligations; arbitrary member selection is not merged with tolerance-wise approximation. Unknown-body topics remain unmerged as content-UNKNOWN, not confirmed equivalent statements.

Read LEGAL-ACCESS-OUTCOME.md and access-attempts-consolidated.json for the actual legal retrieval attempts and concrete NTHU/ebook barriers. Nine necessary Tao author-sample interfaces were located at the retained unversioned DVI, separately from the still-UNKNOWN fourth edition. This does not add a new core demand, change the four concentrated recommendations, or upgrade any proof or exact-answer field.

Expansion handoff: confirm the seven routes and GAP-V2-01–04 together; use the merged checklist to write original explanations and necessary examples. Cite the fixed version and item at each borrowing of a mathematical statement; do not reproduce the textbook's prose or imply identical foundations. Existing proofs/answers and genuinely later V4 locations are reused, not reassigned. No new manuscript, policy adoption or third boundary review has occurred.
