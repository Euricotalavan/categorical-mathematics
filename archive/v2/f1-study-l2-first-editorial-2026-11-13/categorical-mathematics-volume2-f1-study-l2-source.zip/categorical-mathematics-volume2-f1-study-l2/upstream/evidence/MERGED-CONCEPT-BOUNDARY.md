# V2 merged concept boundary — same Step1 proposal

This is a semantic projection of the same live table, not a new registry or a third boundary round. All 418 manuscript IDs and all 107 v3 textbook rows remain byte-for-byte in their source JSON; the 142 reference rows retain their order and statuses. The 560-row CSV adds only concept links. The concept count is not a coverage percentage.

Read each source verdict at its actual hypothesis and example role. A reference example with different numbers can meet a teaching objective without certifying the exact external answer. UNKNOWN bodies are routed by topic only and are never merged as confirmed synonymous theorems. The nine author-sample aliases are explicitly not fourth-edition Tao evidence.

## Expansion decision

Keep the seven strands and consider the existing four concentrated supplements GAP-V2-01–04 as one proposal. No manuscript was changed. Definitions, statements and necessary example objectives are mapped below; complete proofs, literal external answers and global foundations are not certified by this boundary work. The six gates remain OPEN and LR body correspondence remains UNKNOWN.

## Deduplicated checklist

### V2-C:DIVISIBILITY — Divisibility means existence of a multiplication witness; specify natural or signed input and witness domains.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Same relational objective, not an identification of natural arrows with all signed integers.

- REF:V2:H04 — HAMMACK, Definition4.4, printed116 / PDF128; definition; 部分涵蓋. Hammack quantifies integer coefficients. V2 initially uses arrows into N and explicit whole-source witnesses; arbitrary signed-divisor conventions are not silently identified with this relation. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:STEIN:1.1.1 — STEIN, Definition 1.1.1; printed2; PDF9; Definition; 部分涵蓋. Natural whole-source witnesses and signed positive-modulus multiples are written; general signed-divisor wording is a domain extension. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch34 sec:witnessed-divisibility | incremental-revisions/completion-v1/adopted/sections/90-divisibility-and-parity.tex | SHA256 1e567817e93e1716c89d7d76f398c620f366b99797de311a230a7e95859e2f9c | lines 59–59
- V2 Ch43 prop:integer-congruence-multiple | incremental-revisions/euclidean-v1/final/sections/110-integer-remainders.tex | SHA256 90693ea33be70ce0aa6d5620ae2c41359e8014ed58e16ba4ed21aa144110241f | lines 86–91

### V2-C:DIVISION — For an integer dividend and positive divisor d, give unique q,r with a=qd+r and 0<=r<d.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Stein permits a negative divisor using |d|. V2 explicitly supplies the positive-divisor algorithm; a named algorithm is not a new existence proof.

- REF:V2:H03 — HAMMACK, Fact1.5, printed30 / PDF42; existence discussion printed31 / PDF43; §7 exercises28, printed156 / PDF168 (exact answer not read); theorem/proof obligation; 已涵蓋. Natural algorithm and signed extension have explicit existence and uniqueness statements. Hammack's positivity requirement agrees; divisor zero is not an omitted case. External uniqueness answer remains UNKNOWN. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:STEIN:1.1.11 — STEIN, Proposition 1.1.11; printed4; PDF11; Proposition; 部分涵蓋. V2 treats positive divisors explicitly; Stein allows negative divisors using absolute value. No division by0. Negative-divisor extension is a routine convention, not an error in the positive theorem. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:1.1.12 — STEIN, Algorithm 1.1.12; printed5; PDF12; Algorithm; 部分涵蓋. Current positive-divisor state construction is explicit; reference names long division without listing its steps. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch36 prop:division-existence | incremental-revisions/arithmetic-v1/final/sections/94-division-by-a-positive-divisor.tex | SHA256 f9b76c0cae85958e5441c8c2efdec702b4be922e171c17e0e5549d554ed35807 | lines 42–50
- V2 Ch36 prop:division-unique | incremental-revisions/arithmetic-v1/final/sections/94-division-by-a-positive-divisor.tex | SHA256 f9b76c0cae85958e5441c8c2efdec702b4be922e171c17e0e5549d554ed35807 | lines 101–110
- V2 Ch43 prop:integer-division | incremental-revisions/euclidean-v1/final/sections/110-integer-remainders.tex | SHA256 90693ea33be70ce0aa6d5620ae2c41359e8014ed58e16ba4ed21aa144110241f | lines 32–37

Necessary proof/specification obligations:
- Existence with actual supplied data
- Uniqueness at the stated type
- Stopping/correctness for the implemented positive-divisor transition

### V2-C:GCD — A gcd divides both inputs and receives every common divisor; state normalization and the zero-pair convention.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Hammack excludes (0,0); Stein and V2 permit gcd(0,0)=0. Greatestness in divisibility order differs from a largest signed-number definition.

- REF:V2:H05 — HAMMACK, Definition4.6 and zero-pair discussion, printed116 / PDF128; definition; 部分涵蓋. Hammack uses largest ordinary integer common divisor and excludes (0,0). V2 uses greatestness in divisibility order, stable under source change, and G(0,0)=0. Do not label either convention a contradiction. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:STEIN:1.1.8 — STEIN, Definition 1.1.8; printed3; PDF10; Definition; 部分涵蓋. Both permit gcd(0,0)=0. Reference signed inputs normalize by magnitude; compare V2 natural divisibility-greatestness, not its incidental signed example wording. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:1.1.18 — STEIN, Lemma 1.1.18; printed6; PDF13; Lemma; 已涵蓋. This is the manuscript source-stable greatest test; signed ordinary specialization uses magnitude conventions. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch37 def:stable-gcd | incremental-revisions/euclidean-v1/final/sections/97-greatest-common-divisor-tests.tex | SHA256 9ad098759645f5ffa9d528c58c3878538bda1e25bd6c19aa2315a6c85543c822 | lines 48–55
- V2 Ch38 prop:euclidean-gcd | incremental-revisions/euclidean-v1/final/sections/100-constructed-gcd.tex | SHA256 b09bafe76ba25b18d770431d7a39cc9bb9124341a646195b0238d3b2c57bb60b | lines 19–24
- V2 Ch37 ex:gcd-zero-zero | incremental-revisions/euclidean-v1/final/sections/97-greatest-common-divisor-tests.tex | SHA256 9ad098759645f5ffa9d528c58c3878538bda1e25bd6c19aa2315a6c85543c822 | lines 147–151

### V2-C:GCD-REDUCTION — Replacing a dividend by its remainder preserves the common-divisor test and gcd.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

V2 supplies witnesses along a given natural division equation. Stein additionally treats symmetry/sign normalization; the unrestricted signed formula remains a distinct specialization.

- REF:V2:STEIN:1.1.9 — STEIN, Lemma 1.1.9; printed3; PDF10; Lemma; 部分涵蓋. Natural witness reduction and symmetry are explicit; signed sign-normalization is a separate interpretation. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:1.1.10 — STEIN, Lemma 1.1.10; printed4; PDF11; Lemma; 部分涵蓋. The manuscript supplies both witness routes through a given natural division equation; it does not literally state the unrestricted signed formula. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch38 prop:gcd-identities | incremental-revisions/euclidean-v1/final/sections/100-constructed-gcd.tex | SHA256 b09bafe76ba25b18d770431d7a39cc9bb9124341a646195b0238d3b2c57bb60b | lines 52–63
- V2 Ch37 prop:common-divisor-reduction | incremental-revisions/euclidean-v1/final/sections/96-common-divisor-reduction.tex | SHA256 c647b4b683d61d5b9f8c81dede5fa3e327f883b17b05adb83458078f289194a7 | lines 76–87
- V2 Ch37 prop:gcd-reduction-test | incremental-revisions/euclidean-v1/final/sections/97-greatest-common-divisor-tests.tex | SHA256 9ad098759645f5ffa9d528c58c3878538bda1e25bd6c19aa2315a6c85543c822 | lines 119–123

### V2-C:GCD-SCALING — Scaling inputs scales their normalized gcd.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

The second alias is a worked illustration. V2 uses natural scale, including zero; the signed reference formula needs absolute value.

- REF:V2:STEIN:1.1.17 — STEIN, Lemma 1.1.17; printed6; PDF13; Lemma; 部分涵蓋. V2 natural scale k includes0; Stein signed scale uses absolute value. Preserve that distinction. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:1.1.15 — STEIN, Example 1.1.15; printed6; PDF13; Example; 部分涵蓋. Current scaled gcd example covers the pedagogical role, not identical printed numbers. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch42 prop:gcd-scaling | incremental-revisions/euclidean-v1/final/sections/108-coprime-cancellation.tex | SHA256 96f781a8a6e1f36a6996dbd426694cf247b44dfc07dd337ea0293b9228a10192 | lines 105–109
- V2 Ch42 ex:gcd-scale-example | incremental-revisions/euclidean-v1/final/sections/108-coprime-cancellation.tex | SHA256 96f781a8a6e1f36a6996dbd426694cf247b44dfc07dd337ea0293b9228a10192 | lines 148–152

### V2-C:EUCLIDEAN — Euclidean remainder iteration stops and returns a gcd.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Merge the worked-computation objective, not its literal numerical answer.

- REF:V2:STEIN:1.1.13 — STEIN, Algorithm 1.1.13; printed5; PDF12; Algorithm; 已涵蓋. Natural magnitude inputs, total transition and proved stopping bound cover the algorithmic core; signed inputs first use magnitudes. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:1.1.14 — STEIN, Example 1.1.14; printed6; PDF13; Example; 部分涵蓋. Different numerical inputs; same worked reduction objective. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch38 prop:euclidean-stops | incremental-revisions/euclidean-v1/final/sections/99-euclidean-stopping-bound.tex | SHA256 d7dfab7a9178a6dd23bace75f3a31946488822953084e59141749c433245d9b2 | lines 80–84
- V2 Ch38 prop:euclidean-gcd | incremental-revisions/euclidean-v1/final/sections/100-constructed-gcd.tex | SHA256 b09bafe76ba25b18d770431d7a39cc9bb9124341a646195b0238d3b2c57bb60b | lines 19–24
- V2 Ch37 ex:gcd-twenty-one-six | incremental-revisions/euclidean-v1/final/sections/97-greatest-common-divisor-tests.tex | SHA256 9ad098759645f5ffa9d528c58c3878538bda1e25bd6c19aa2315a6c85543c822 | lines 161–166

Necessary proof/specification obligations:
- Decrease/stopping bound
- Preservation of the common-divisor invariant
- Final greatest-divisor test

### V2-C:BEZOUT — Construct signed coefficients expressing the gcd as a linear combination of the two inputs.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Numerical back-substitution examples serve one role. The zero pair must not be handled by dividing by its gcd.

- REF:V2:H07 — HAMMACK, Proposition7.1, printed152 / PDF164; theorem/proof obligation; 已涵蓋. V2 constructs coefficient arrows uniformly from the proved Euclidean bound, rather than assuming a nonunique global selection of solutions. The printed existence statement is covered by specialization. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:STEIN:2.3.1 — STEIN, Proposition 2.3.1; printed32; PDF39; Proposition; 已涵蓋. Signed coefficients, magnitudes and exact current state invariants provide the indicated route. The reference proof divides by gcd and needs a separate zero-pair case; do not copy that omission. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.3.3 — STEIN, Example 2.3.3; printed32; PDF39; Example; 部分涵蓋. Current signed-coefficient example covers the task with different input. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.3.4 — STEIN, Example 2.3.4; printed32; PDF39; Example; 部分涵蓋. No demand to duplicate every numerical example. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch41 prop:bezout-arrows | incremental-revisions/euclidean-v1/final/sections/106-extended-euclidean-coefficients.tex | SHA256 823eab4be421f44f550754427fd3bef4a6fd3a350b61162ba6698e8d2c4e0d9f | lines 86–94
- V2 Ch41 prop:extended-euclidean-invariant | incremental-revisions/euclidean-v1/final/sections/106-extended-euclidean-coefficients.tex | SHA256 823eab4be421f44f550754427fd3bef4a6fd3a350b61162ba6698e8d2c4e0d9f | lines 43–52
- V2 Ch41 sec:signed-linear-coefficients | incremental-revisions/euclidean-v1/final/sections/107-linear-diophantine-tests.tex | SHA256 610a9b47fa76bd2f365be1b50473753fa0de120615e367c2bbc21bc4d61196e8 | lines 60–60
- V2 Ch41 ex:bezout-eighty-four | incremental-revisions/euclidean-v1/final/sections/106-extended-euclidean-coefficients.tex | SHA256 823eab4be421f44f550754427fd3bef4a6fd3a350b61162ba6698e8d2c4e0d9f | lines 142–147

### V2-C:EXTENDED-EUCLIDEAN — Track coefficient rows through Euclidean iteration to obtain the Bezout witnesses.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

The state invariant and stopping argument are obligations distinct from the Bezout existence statement. Stein omits part of its algorithm proof; existing manuscript proof status is not downgraded.

- REF:V2:STEIN:2.3.7 — STEIN, Algorithm 2.3.7; printed33; PDF40; Algorithm; 已涵蓋. The manuscript states full signed state invariants and a stopping bound. The reference explicitly omits part of its inductive correctness proof; that is not a reason to remove the manuscript proof. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.3.5 — STEIN, Example 2.3.5; printed33; PDF40; Example; 部分涵蓋. The current invariant is explicit; the reference notation is another representation. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch41 prop:extended-euclidean-invariant | incremental-revisions/euclidean-v1/final/sections/106-extended-euclidean-coefficients.tex | SHA256 823eab4be421f44f550754427fd3bef4a6fd3a350b61162ba6698e8d2c4e0d9f | lines 43–52
- V2 Ch41 prop:bezout-arrows | incremental-revisions/euclidean-v1/final/sections/106-extended-euclidean-coefficients.tex | SHA256 823eab4be421f44f550754427fd3bef4a6fd3a350b61162ba6698e8d2c4e0d9f | lines 86–94

### V2-C:INDUCTION — Use a base value and a successor-closed condition to prove all represented natural cases.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Hammack ordinary-property induction is broader than the manuscript equation/monic representation interface; this is a scope qualification, not an unproved arbitrary internal schema.

- REF:V2:H08 — HAMMACK, §10.1 induction outline, printed182–183 / PDF194–195; proof method; 部分涵蓋. Hammack treats arbitrary ordinary statements, typically starting at1, and explicitly permits other bases including0. V2 proves equations/represented monic parts with parameters. The material distinction is the predicate/representation scope, not a supposed prohibition on starting at0. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- TAO-SAMPLE:induction — Axiom 2.5; sample printed 21; DVI page 31; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch29 prop:parameter-mono-induction | volume-revisions/author-recovery-r2/adopted/incremental-revisions/arithmetic-v1/final/sections/77-parameter-induction.tex | SHA256 e2258688dfc609324ca64e4b0bdfbabc1263e62d1d5e2de698e02b3396387f76 | lines 48–57
- V2 Ch29 prop:parameter-equality-induction | volume-revisions/author-recovery-r2/adopted/incremental-revisions/arithmetic-v1/final/sections/77-parameter-induction.tex | SHA256 e2258688dfc609324ca64e4b0bdfbabc1263e62d1d5e2de698e02b3396387f76 | lines 86–94

### V2-C:LEAST-INDEX — A nonempty ordinary subset of the natural numbers has a least member.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Smallest-counterexample reasoning is an application. EC ordinary least-index formation and internal bounded Boolean search are related but different capacities.

- REF:V2:H02 — HAMMACK, §1.9, printed30 / PDF42; principle; 部分涵蓋. Bounded Boolean search and EC ordinary least-index formation are explicit; they are not representation/decidability of every internal predicate. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:H14 — HAMMACK, §10.3 outline, printed191 / PDF203; proof method; 部分涵蓋. The ordinary least-index rule is available under EC; no internal arbitrary-property counterexample object is promised. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch49 sec:ec-least-index-rule | incremental-revisions/completion-v1/final/sections/129-rational-codes.tex | SHA256 f5a57a836ab2af2da9650959b6d7c382843e88c23ab4e0438a6f0169a35586dd | lines 83–83
- V2 Ch35 prop:bounded-search-correct | incremental-revisions/arithmetic-v1/final/sections/92-bounded-search.tex | SHA256 76d8e49b74b8ba8420144d8649a24c95fb43fa889f9aa283dd00c73245fc0c04 | lines 134–144

### V2-C:PRIME-DIVISOR — A prime dividing a finite product divides a factor.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Do not identify this with the already proved coprime cancellation theorem until primality and its dichotomy have been supplied.

- REF:V2:H12 — HAMMACK, Proposition10.1, printed186 / PDF198; theorem; 部分涵蓋. Coprime cancellation is explicit and sufficient for the current route. A definition of prime and the finite prime-product corollary are not written as such; do not mistake coprime cancellation for already having the entire prime course. The earlier optional disposition is superseded by this same-proposal consolidation; see change log. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:STEIN:1.1.19 — STEIN, Theorem 1.1.19; printed7; PDF14; Theorem; 部分涵蓋. Coprime cancellation is present; prime dichotomy/finite-factor consequence must be stated as part of the newly recommended prime block. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch42 prop:euclid-lemma | incremental-revisions/euclidean-v1/final/sections/108-coprime-cancellation.tex | SHA256 96f781a8a6e1f36a6996dbd426694cf247b44dfc07dd337ea0293b9228a10192 | lines 33–39
- V2 Ch42 prop:coprime-powers | incremental-revisions/euclidean-v1/final/sections/108-coprime-cancellation.tex | SHA256 96f781a8a6e1f36a6996dbd426694cf247b44dfc07dd337ea0293b9228a10192 | lines 71–75

Necessary proof/specification obligations:
- Prime definition and exclusions 0,1
- Prime-divides-two-factors consequence of coprime cancellation
- Finite-product consequence with a genuine finite record

### V2-C:FTA-EXISTENCE — Every positive integer greater than one has a finite product representation by primes; one has the empty product.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **缺漏**.

The combined fundamental theorem is split into two proof obligations without adding or renumbering a raw reference row. No object of all finite words is assumed.

- REF:V2:H15 — HAMMACK, Theorem10.1, printed192 / PDF204; theorem; 缺漏. No explicit prime-factorization development in the selected sources; not required for Euclidean gcd, reduced-fraction normalization or Cauchy completion. No invented later-volume destination. The earlier optional disposition is superseded by this same-proposal consolidation; see change log. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:STEIN:1.1.6 — STEIN, Theorem 1.1.6; printed3; PDF10; Theorem; 缺漏. No explicit finite prime-factorization existence/uniqueness theorem; include1 as empty product, exclude0; proof appears in the reference section1.1.4 on printed10. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:1.1.20 — STEIN, Proposition 1.1.20; printed7; PDF14; Proposition; 缺漏. Bounded search/folds are tools, not an already proved prime factorization. A represented finite-data construction and termination proof are required. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch42 prop:euclid-lemma | incremental-revisions/euclidean-v1/final/sections/108-coprime-cancellation.tex | SHA256 96f781a8a6e1f36a6996dbd426694cf247b44dfc07dd337ea0293b9228a10192 | lines 33–39
- V2 Ch33 sec:factorial-as-fold | incremental-revisions/arithmetic-v1/final/sections/89-finite-sums-and-identities.tex | SHA256 48855e225ad4498612836161e3b6c2b67d379426dc0fad49c2bced1f63cc67a4 | lines 156–156
- V2 Ch35 prop:bounded-search-correct | incremental-revisions/arithmetic-v1/final/sections/92-bounded-search.tex | SHA256 76d8e49b74b8ba8420144d8649a24c95fb43fa889f9aa283dd00c73245fc0c04 | lines 134–144
- V2 Ch33 prop:fold-concatenation | incremental-revisions/arithmetic-v1/final/sections/88-finite-folds.tex | SHA256 8493320771293cbbbb0fa1d53862af9ad21e42b924efbd9fa0cec107a72abdd7 | lines 66–73

Necessary proof/specification obligations:
- Construct actual finite prime-factor data
- Prove termination/existence, including 1 and excluding 0

### V2-C:FTA-UNIQUENESS — Two prime factorizations have the same factors with multiplicity, up to a finite permutation.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **缺漏**.

Separate uniqueness from existence; the same source theorem legitimately has two concept links.

- REF:V2:H15 — HAMMACK, Theorem10.1, printed192 / PDF204; theorem; 缺漏. No explicit prime-factorization development in the selected sources; not required for Euclidean gcd, reduced-fraction normalization or Cauchy completion. No invented later-volume destination. The earlier optional disposition is superseded by this same-proposal consolidation; see change log. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:STEIN:1.1.6 — STEIN, Theorem 1.1.6; printed3; PDF10; Theorem; 缺漏. No explicit finite prime-factorization existence/uniqueness theorem; include1 as empty product, exclude0; proof appears in the reference section1.1.4 on printed10. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch42 prop:euclid-lemma | incremental-revisions/euclidean-v1/final/sections/108-coprime-cancellation.tex | SHA256 96f781a8a6e1f36a6996dbd426694cf247b44dfc07dd337ea0293b9228a10192 | lines 33–39
- V2 Ch33 sec:factorial-as-fold | incremental-revisions/arithmetic-v1/final/sections/89-finite-sums-and-identities.tex | SHA256 48855e225ad4498612836161e3b6c2b67d379426dc0fad49c2bced1f63cc67a4 | lines 156–156

Necessary proof/specification obligations:
- Prime-divisor step
- Cancellation/finite induction
- Explicit multiplicity/permutation formulation

### V2-C:RESIDUE-RING — For fixed positive modulus, construct canonical residue representatives and descended unital commutative ring operations.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Combine the quotient/reduction construction and its representative-independence checks, keeping worked-example aliases separate by role. Congruence compatibility alone is not an effective quotient.

- REF:V2:H19 — HAMMACK, Definition11.6, printed219 / PDF231; setup printed218 / PDF230; definition/construction; 部分涵蓋. Remainder operations and bounded representatives exist, but there is no explicit consolidated residue-ring object with effective quotient/universal factor statement and descended ring laws. This is a named teaching/construction gap, not an error in current congruence theorems. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:H20 — HAMMACK, §11.5 representative-independent multiplication, printed220 / PDF232; proof obligation; 部分涵蓋. Congruence compatibility supplies the calculation. The explicit ring/quotient bridge should package it with addition, negation and the full quotient factor test; do not assume a quotient solely from a commuting equation. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.
- REF:V2:STEIN:2.1.4 — STEIN, Definition 2.1.4; printed22; PDF29; Definition; 部分涵蓋. Remainders/congruences are present; explicit ring normalization, quotient test and laws are the proposed bridge. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.1.8 — STEIN, Definition 2.1.8; printed23; PDF30; Definition; 部分涵蓋. Canonical remainder already exists; packaging it as reduction to a proved residue ring is pending. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.1.11 — STEIN, Definition 2.1.11; printed24; PDF31; Definition; 部分涵蓋. Use the existing bounded representative object; no arbitrary representative choice is needed for the canonical list. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.1.5 — STEIN, Example 2.1.5; printed22; PDF29; Example; 部分涵蓋. Explicit classes belong in the residue bridge; current congruence calculations are not a quotient-set construction. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:H21 — HAMMACK, §11.5 modulo-five example and tables, printed218–219 / PDF230–231; worked example; 部分涵蓋. Current numerical congruence/inverse examples are present. A short residue-ring example can complete the selected bridge without copying all reference tables. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch36 prop:congruence-operations | incremental-revisions/arithmetic-v1/final/sections/95-remainder-calculus.tex | SHA256 b10967a0db051980d096b11375f0a5d38792d5faff1a13797fd8c530468e07f3 | lines 130–138
- V2 Ch43 prop:integer-congruence-multiple | incremental-revisions/euclidean-v1/final/sections/110-integer-remainders.tex | SHA256 90693ea33be70ce0aa6d5620ae2c41359e8014ed58e16ba4ed21aa144110241f | lines 86–91
- V2 Ch43 prop:bounded-congruence-solutions | incremental-revisions/euclidean-v1/final/sections/112-classifying-congruence-solutions.tex | SHA256 8e9d9f7f199a9956b5489a79c7b87fdcbce9259a538013602ebea999a570d0d5 | lines 56–66
- V2 Ch43 prop:integer-division | incremental-revisions/euclidean-v1/final/sections/110-integer-remainders.tex | SHA256 90693ea33be70ce0aa6d5620ae2c41359e8014ed58e16ba4ed21aa144110241f | lines 32–37
- V2 Ch33 prop:bounded-index-basechange | incremental-revisions/arithmetic-v1/final/sections/87-bounded-index-objects.tex | SHA256 2571c6daf6db0da3835676d14e670eb93ed597059156a5bf2c6033ca387cc5ba | lines 37–41
- V2 Ch36 ex:congruence-product-five | incremental-revisions/arithmetic-v1/final/sections/95-remainder-calculus.tex | SHA256 b10967a0db051980d096b11375f0a5d38792d5faff1a13797fd8c530468e07f3 | lines 197–202
- V2 Ch43 ex:inverse-five-seventeen | incremental-revisions/calculus-v1/adopted/sections/111-solving-linear-congruences.tex | SHA256 480055148a0fb3cb05eb98feedb0b5a157b748e8c084be2a15acde73136172e4 | lines 86–90

Necessary proof/specification obligations:
- Canonical remainder and range
- Effective quotient/factor test at all admissible sources
- Descended operations and ring laws
- Modulus 1 zero ring; modulus 0 excluded
- One representative calculation

### V2-C:COPRIME-CONGRUENCE — A scalar coprime to the fixed positive modulus can be cancelled, and the associated linear congruence has one residue solution.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

These are equivalent uses of a supplied inverse only after the coefficient and target are normalized; no cancellation by a nonunit.

- REF:V2:STEIN:2.1.10 — STEIN, Proposition 2.1.10; printed23; PDF30; Proposition; 已涵蓋. The supplied inverse and exact period formulas provide this core test; no cancellation by a nonunit is inferred. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.1.13 — STEIN, Proposition 2.1.13; printed24; PDF31; Proposition; 已涵蓋. Normalize signed coefficients/targets to the indicated natural representatives when invoking the manuscript version. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch43 sec:coprime-modular-inverse | incremental-revisions/calculus-v1/adopted/sections/111-solving-linear-congruences.tex | SHA256 480055148a0fb3cb05eb98feedb0b5a157b748e8c084be2a15acde73136172e4 | lines 50–50
- V2 Ch43 prop:linear-congruence-period | incremental-revisions/euclidean-v1/final/sections/112-classifying-congruence-solutions.tex | SHA256 8e9d9f7f199a9956b5489a79c7b87fdcbce9259a538013602ebea999a570d0d5 | lines 17–22
- V2 Ch43 prop:linear-congruence-existence | incremental-revisions/calculus-v1/adopted/sections/111-solving-linear-congruences.tex | SHA256 480055148a0fb3cb05eb98feedb0b5a157b748e8c084be2a15acde73136172e4 | lines 16–22

### V2-C:MODULAR-INVERSE — Obtain a modular inverse from the supplied Bezout coefficients and demonstrate it numerically.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Literal external answers remain UNKNOWN; the manuscript uses different representative integers.

- REF:V2:STEIN:2.3.8 — STEIN, Algorithm 2.3.8; printed33; PDF40; Algorithm; 已涵蓋. Current Bezout construction yields the inverse witness with fixed positive modulus. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.1.14 — STEIN, Example 2.1.14; printed24; PDF31; Example; 部分涵蓋. Current example uses different integers; exact external answer not certified. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.3.9 — STEIN, Example 2.3.9; printed34; PDF41; Example; 部分涵蓋. Representative example, not a claim that the literal17/61 answer was independently checked. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch43 sec:coprime-modular-inverse | incremental-revisions/calculus-v1/adopted/sections/111-solving-linear-congruences.tex | SHA256 480055148a0fb3cb05eb98feedb0b5a157b748e8c084be2a15acde73136172e4 | lines 50–50
- V2 Ch43 ex:inverse-five-seventeen | incremental-revisions/calculus-v1/adopted/sections/111-solving-linear-congruences.tex | SHA256 480055148a0fb3cb05eb98feedb0b5a157b748e8c084be2a15acde73136172e4 | lines 86–90

### V2-C:CRT — For coprime positive moduli, construct the unique bounded representative satisfying the two congruences.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Combine theorem, explicit Bezout construction, and one worked objective; the unit-group counting refinement remains separate.

- REF:V2:STEIN:2.2.2 — STEIN, Theorem 2.2.2; printed29; PDF36; Theorem; 已涵蓋. Current bounded unique representative and signed period cover the test after normalizing targets. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.2.3 — STEIN, Algorithm 2.2.3; printed29; PDF36; Algorithm; 已涵蓋. Explicit current formulas construct the same compatible solution; no choice of a congruence class is assumed. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.2.4 — STEIN, Example 2.2.4; printed30; PDF37; Example; 部分涵蓋. Current hand calculation covers the task; Sage commands are not required. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch44 prop:coprime-crt | incremental-revisions/euclidean-v1/final/sections/113-two-coprime-moduli.tex | SHA256 e17a9371994e38fafac5845ed53a3a64766c36a443d77b20982bf004a35a5bdc | lines 30–37
- V2 Ch41 prop:bezout-arrows | incremental-revisions/euclidean-v1/final/sections/106-extended-euclidean-coefficients.tex | SHA256 823eab4be421f44f550754427fd3bef4a6fd3a350b61162ba6698e8d2c4e0d9f | lines 86–94
- V2 Ch44 ex:crt-four-five | incremental-revisions/euclidean-v1/final/sections/113-two-coprime-moduli.tex | SHA256 e17a9371994e38fafac5845ed53a3a64766c36a443d77b20982bf004a35a5bdc | lines 116–121

Necessary proof/specification obligations:
- Existence formula
- Both reductions
- Uniqueness/period
- One worked calculation

### V2-C:FAST-POWER — Use binary data and repeated squaring to compute a modular power, with a finite halving bound and correctness invariant.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

The example is a task variant; Euler/totient exponent reduction is outside the proposed core. Binary expansion remains a distinct prerequisite.

- REF:V2:STEIN:2.3.13 — STEIN, Algorithm 2.3.13; printed35; PDF42; Algorithm; 部分涵蓋. Power laws and binary data are present, but the combined algorithm/invariant is not written. Add one bounded correctness result, including exponent0. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:STEIN:2.3.14 — STEIN, Example 2.3.14; printed35; PDF42; Example; 部分涵蓋. One repeated-squaring example is recommended; using Euler exponent reduction additionally would enter the unselected totient route. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch35 prop:binary-reconstruction | incremental-revisions/arithmetic-v1/final/sections/93-finite-binary-reconstruction.tex | SHA256 de7dc0ca6189b83eaa97aed21c52fad577626cb3888538ad07d3eeddbdb51201 | lines 47–56
- V2 Ch30 prop:power-product-laws | incremental-revisions/arithmetic-v1/final/sections/80-arithmetic-powers.tex | SHA256 1f2c5fe5280afed26c544823f139acd780be3a8df7b979688464db5466655fd9 | lines 74–81
- V2 Ch36 prop:congruence-operations | incremental-revisions/arithmetic-v1/final/sections/95-remainder-calculus.tex | SHA256 b10967a0db051980d096b11375f0a5d38792d5faff1a13797fd8c530468e07f3 | lines 130–138

Necessary proof/specification obligations:
- Actual finite state supply
- Guaranteed halving termination
- Invariant/correctness
- Exponent 0 and modulus 1

### V2-C:FIELD — A commutative unital ring with 0 distinct from 1 has inverses for every nonzero element.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Keep commutativity and nontriviality explicit rather than adopting abbreviated group/ring wording from another source.

- REF:V2:STEIN:2.1.7 — STEIN, Definition 2.1.7; printed23; PDF30; Definition; 已涵蓋. Keep the manuscript commutativity and0-not-equal1 hypotheses. Do not import ambiguity from the abbreviated reference definition or call the modulus1 zero ring a field. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:LEBL:1.1.5 — LEBL, Definition 1.1.5; printed25; PDF25; Definition; 已涵蓋. Keep nontriviality and all field operations; do not infer inverses for zero. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch45 prop:fraction-inverse | incremental-revisions/euclidean-v1/final/sections/117-fraction-inverses-and-universal-test.tex | SHA256 c7d4e9527e2a5243a24b8d630dbe4826c099daea9c283a15375368162ca1e2e7 | lines 28–35
- V2 Ch48 prop:ec-field | incremental-revisions/completion-v1/final/sections/127-completion-inverses.tex | SHA256 800f691dacf0298af85da1159d6000406d816a7d28a7cb657c4bc0bb733ee937 | lines 10–15
- V2 Ch39 def:commutative-ring-object | incremental-revisions/euclidean-v1/final/sections/102-integer-ring-operations.tex | SHA256 b51651d0467286979a935c1a6b1aa0c267a656f20a204e6c3a87a748d2bec2c5 | lines 37–47

### V2-C:SUP-APPROXIMATION — For each positive tolerance, some member of a nonempty bounded set lies within that tolerance below its supremum.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

This quantified statement is distinct from simultaneously selecting a sequence of such members.

- REF:V2:LEBL:1.2.8 — LEBL, Proposition 1.2.8; printed33; PDF33; Proposition; 已涵蓋. The exact quantifier-level approximation is written; it does not by itself select a sequence of members. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 eq:ec-supremum-witness | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 67–67

### V2-C:CAUCHY-BOUNDED — A Cauchy sequence is bounded after combining a tail estimate with its finite prefix.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Separate rational input data from the real-field version even when the same elementary argument applies.

- REF:V2:LEBL:2.4.4 — LEBL, Proposition 2.4.4; printed84; PDF84; Proposition; 已涵蓋. Rational and ordinary field tail-plus-finite-prefix versions are present. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch47 prop:ec-cauchy-bounded | incremental-revisions/completion-v1/final/sections/123-cauchy-estimates.tex | SHA256 473e6003a4b52433f791591e2e19fe587105feddf95ac1acb7b21b4a60949cbc | lines 10–14
- V2 Ch51 sec:ec-completeness-equivalences | incremental-revisions/completion-v1/final/sections/136-monotone-completeness.tex | SHA256 08627fc3a5d773b9d0e4574c590ca0def138cfa431d6aa935ecf995213e24f31 | lines 35–35

### V2-C:ALTERNATING-COUNTEREXAMPLE — Alternating separated values violate the Cauchy condition and hence do not converge.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Same diagnostic example in convergence and Cauchy language; do not claim the exact external answer was checked.

- REF:V2:LEBL:2.1.5 — LEBL, Example 2.1.5; printed53; PDF53; Example; 已涵蓋. Current non-Cauchy counterexample plus convergent-implies-Cauchy provides the same task. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:LEBL:2.4.3 — LEBL, Example 2.4.3; printed84; PDF84; Example; 已涵蓋. Exact counterexample objective present. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch47 ex:ec-cauchy-quantifiers | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/122-external-completion-interface.tex | SHA256 35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3 | lines 130–134
- V2 Ch50 prop:ec-basic-limits | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 28–34

### V2-C:RECIPROCAL-SEQUENCE — Reciprocals of positive natural integers tend to zero and are Cauchy.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Convergence and Cauchy are two stated outcomes; rational and real interpretations remain explicit.

- REF:V2:LEBL:2.1.4 — LEBL, Example 2.1.4; printed53; PDF53; Example; 已涵蓋. The explicit small reciprocal scale is present. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:LEBL:2.4.2 — LEBL, Example 2.4.2; printed84; PDF84; Example; 已涵蓋. The current rational reciprocal example is explicit and convergence also gives the field version. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch49 prop:ec-archimedean | incremental-revisions/completion-v1/final/sections/128-archimedean-density.tex | SHA256 2373587cf72b26489379f8882936c09918ff47568909f501996a8aff4efccfac | lines 21–27
- V2 Ch47 def:ec-rational-cauchy | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/122-external-completion-interface.tex | SHA256 35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3 | lines 54–68

### V2-C:TAIL — Removing a finite prefix preserves sequence convergence and its limit.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

The tail definition and its equivalence theorem are one interface; arbitrary subsequences are not merged into it.

- REF:V2:LEBL:2.1.14 — LEBL, Definition 2.1.14; printed57; PDF57; Definition; 已涵蓋. Current finite-prefix invariance is the equivalent tail interface. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:LEBL:2.1.15 — LEBL, Proposition 2.1.15; printed57; PDF57; Proposition; 已涵蓋. No new all-subsequence theorem is needed to justify finite-tail changes. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 prop:ec-basic-limits | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 28–34

### V2-C:CAUCHY-COMPLETENESS — For the constructed ordinary real field, a sequence converges exactly when it is Cauchy; relate sequential and order completeness.

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

This merges the criterion and explicit comparison remark, not a certification of the real-construction proof. Lebl omits completion-construction details.

- REF:V2:LEBL:2.4.5 — LEBL, Theorem 2.4.5; printed85; PDF85; Theorem; 已涵蓋. The manuscript proves both directions without requiring Lebl's limsup/liminf proof route. Different proofs do not establish a content gap. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- REF:V2:LEBL:2.4.6 — LEBL, Remark 2.4.6; printed85; PDF85; Remark; 已涵蓋. The manuscript proves the equivalences under explicit data. Lebl omits completion-construction details; this row does not certify them externally. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 prop:ec-sequential-completeness | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/132-sequential-completeness.tex | SHA256 7eab903dd389e522c3d7054586aeb99fccaf63f0a61236b9cf2bf1ea42120282 | lines 21–26
- V2 Ch50 prop:ec-basic-limits | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 28–34
- V2 Ch51 sec:ec-completeness-equivalences | incremental-revisions/completion-v1/final/sections/136-monotone-completeness.tex | SHA256 08627fc3a5d773b9d0e4574c590ca0def138cfa431d6aa935ecf995213e24f31 | lines 35–35

Necessary proof/specification obligations:
- Convergence implies Cauchy
- Cauchy implies convergence under the stated EC construction
- Named equivalence directions and supplied formation assumptions

### V2-C:H01 — Ordinary number systems and accepted arithmetic ground rules

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H01 — HAMMACK, §1.9, printed30–31 / PDF42–43; scope/definitions; 部分涵蓋. Hammack accepts familiar arithmetic/order; V2 constructs earlier internal operations conditionally and switches to ordinary external data only at Chapter47. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch30 def:commutative-semiring-object | incremental-revisions/arithmetic-v1/final/sections/79-multiplication-semiring.tex | SHA256 83696741b482a39e4e454ac481df39bc68df86264e4e3cd14cd6fcfdb84b2013 | lines 152–163
- V2 Ch39 def:commutative-ring-object | incremental-revisions/euclidean-v1/final/sections/102-integer-ring-operations.tex | SHA256 b51651d0467286979a935c1a6b1aa0c267a656f20a204e6c3a87a748d2bec2c5 | lines 37–47
- V2 Ch47 sec:ec-external-interface | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/122-external-completion-interface.tex | SHA256 35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3 | lines 10–10

### V2-C:H06 — Least common multiple

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H06 — HAMMACK, Definition4.6, printed116 / PDF128; definition/theorem; 部分涵蓋. Hammack restricts to nonzero integer inputs and a positive least multiple. V2 has a divisibility-order least test and L(n,0)=0, including L(0,0)=0. Compare the nonzero natural specialization, not the unmatched boundary. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch42 def:stable-lcm | incremental-revisions/euclidean-v1/final/sections/109-least-common-multiples.tex | SHA256 29ebd1b8bc75a8edbae55cfdb3c4995df763765dd0fab34016b9b054b098cda1 | lines 37–44
- V2 Ch42 prop:lcm-construction | incremental-revisions/euclidean-v1/final/sections/109-least-common-multiples.tex | SHA256 29ebd1b8bc75a8edbae55cfdb3c4995df763765dd0fab34016b9b054b098cda1 | lines 54–59
- V2 Ch42 ex:lcm-zero-boundary | incremental-revisions/euclidean-v1/final/sections/109-least-common-multiples.tex | SHA256 29ebd1b8bc75a8edbae55cfdb3c4995df763765dd0fab34016b9b054b098cda1 | lines 133–138

### V2-C:H09 — Sum of the first n odd natural numbers is n squared

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H09 — HAMMACK, §10.1 unnamed odd-sum proposition, printed182 / PDF194; worked example; 缺漏. The exact odd-sum example was not found in the selected V2 source. General folds and other finite identities are present; adding every reference exercise is not required. Bounded-search absence only. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch33 prop:triangular-sum | incremental-revisions/arithmetic-v1/final/sections/89-finite-sums-and-identities.tex | SHA256 48855e225ad4498612836161e3b6c2b67d379426dc0fad49c2bced1f63cc67a4 | lines 52–55
- V2 Ch33 prop:square-geometric-sums | incremental-revisions/arithmetic-v1/final/sections/89-finite-sums-and-identities.tex | SHA256 48855e225ad4498612836161e3b6c2b67d379426dc0fad49c2bced1f63cc67a4 | lines 90–102

### V2-C:H10 — Sum of i times i factorial through n equals (n+1) factorial minus one

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H10 — HAMMACK, §10.1 unnamed telescoping factorial proposition, printed184 / PDF196; worked example; 缺漏. The exact telescoping identity is not an explicit selected item. Existing factorial and folds are the necessary tools; this is not a core number-system omission. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch31 sec:factorial-recursion | incremental-revisions/arithmetic-v1/final/sections/82-primitive-recursion-and-invariants.tex | SHA256 c0ccc95c79d57395f500032b1f527e9783485f370c52aceb907e278357c1fc82 | lines 106–106
- V2 Ch33 sec:factorial-as-fold | incremental-revisions/arithmetic-v1/final/sections/89-finite-sums-and-identities.tex | SHA256 48855e225ad4498612836161e3b6c2b67d379426dc0fad49c2bced1f63cc67a4 | lines 156–156

### V2-C:H11 — Bernoulli inequality

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H11 — HAMMACK, §10.1 Bernoulli example, printed185–186 / PDF197–198; theorem/proof example; 部分涵蓋. Hammack states real x > -1 for positive n. Current V2 states nonnegative fraction t and includes zero counter. The stronger real/negative-input formulation is not claimed or made a required expansion. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch46 prop:bernoulli-finite | incremental-revisions/euclidean-v1/final/sections/119-finite-rational-estimates.tex | SHA256 36cbc04307b005ff0dff87186c0a0a7758a36517b897b578f1e1fea4b4f8f4c8 | lines 96–104

### V2-C:H13 — Strong induction

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H13 — HAMMACK, §10.2 outline, printed187 / PDF199; proof method; 部分涵蓋. Stored-state recursion/invariants are present. A general strong-induction schema for arbitrary internal predicates is not established and is not needed by the selected constructive route. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch31 prop:primitive-recursion | incremental-revisions/arithmetic-v1/final/sections/82-primitive-recursion-and-invariants.tex | SHA256 c0ccc95c79d57395f500032b1f527e9783485f370c52aceb907e278357c1fc82 | lines 12–20
- V2 Ch31 prop:state-invariant | incremental-revisions/arithmetic-v1/final/sections/82-primitive-recursion-and-invariants.tex | SHA256 c0ccc95c79d57395f500032b1f527e9783485f370c52aceb907e278357c1fc82 | lines 64–74

### V2-C:H16 — Fibonacci as a two-state recurrence

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H16 — HAMMACK, §10.5 opening recurrence, printed193 / PDF205; definition/example; 已涵蓋. Hammack lists F1=F2=1. V2 uses F0=0,F1=1 and proves uniqueness for the corresponding recurrence. Record the compatible starting-index convention rather than invent a gap. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch31 prop:fibonacci-unique | incremental-revisions/arithmetic-v1/final/sections/82-primitive-recursion-and-invariants.tex | SHA256 c0ccc95c79d57395f500032b1f527e9783485f370c52aceb907e278357c1fc82 | lines 144–148

### V2-C:H17 — Equivalence relation

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H17 — HAMMACK, Definition11.3, printed210 / PDF222; definition; 已涵蓋. V1 supplies the represented internal relation calculus; EC gives an actual ordinary equivalence relation. Neither item says arbitrary internal quotients exist. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V1 Ch25 sec:internal-equivalence-relation | incremental-revisions/quotients-v1/final/sections/67-equivalence-relations-and-effective-quotients.tex | SHA256 d987e4a451b0b620e5d788df89f52c67e3ab6a5e9a9a9c5dd610c3ae4611a956 | lines 8–8
- V2 Ch47 prop:ec-equivalence | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/124-null-equivalence.tex | SHA256 5c7545569530c57862f77f42fca8ff4e9c183f9a8deaf183c685b6e7d46e7711 | lines 10–14

### V2-C:H18 — Class equality iff representatives are related

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H18 — HAMMACK, Definition11.4, printed211 / PDF223; Theorem11.1, printed215 / PDF227; definition/theorem; 已涵蓋. The manuscript has exact all-source/effective tests or the ordinary EC fibre equation. This is not construction of every quotient set or all equivalence classes in every category. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch47 prop:ec-quotient-test | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/122-external-completion-interface.tex | SHA256 35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3 | lines 95–102
- V2 Ch45 prop:fraction-quotient | incremental-revisions/euclidean-v1/final/sections/115-reduced-fraction-object.tex | SHA256 d69e1ce0fd72c1648173807466f9648a08321656c071dd72e91ba4ac3e84c3ca | lines 90–96
- V2 Ch39 sec:integer-quotient-interface | incremental-revisions/euclidean-v1/final/sections/101-supplied-integer-completion.tex | SHA256 58ca6811fb1071fe49f391709ce6bb3ac4182e02d975e8347d8e4cc2eab0cd32 | lines 11–11

### V2-C:H22 — Coprime cancellation in a divisibility test

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:H22 — HAMMACK, Chapter7 exercise29, printed156 / PDF168; original question only; exercise/proof obligation; 部分涵蓋. The V2 proposition gives an explicit natural-arrow witness under coprimality. The textbook question uses the standing ordinary-integer context; arbitrary signed-divisor extensions are not silently treated as the same typed theorem. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch42 prop:euclid-lemma | incremental-revisions/euclidean-v1/final/sections/108-coprime-cancellation.tex | SHA256 96f781a8a6e1f36a6996dbd426694cf247b44dfc07dd337ea0293b9228a10192 | lines 33–39

### V2-C:R01 — Natural numbers as the universal discrete dynamical system

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:R01 — RIEHL, Example2.1.1 and diagram(2.1.2), printed54 / PDF74; footnote3; definition/example; 已涵蓋. Riehl presents ordinary-set recursion and a categorical footnote. The V1 NNO remains supplied; V2 derives its parameter/state consequences under A. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V1 Ch28 def:given-NNO | incremental-revisions/quotients-v1/final/sections/76-given-natural-number-objects.tex | SHA256 ac3b7032389fb84548c4efbb3e92e7d639019efccbd113c744e5fa6fbe997f46 | lines 17–17
- V1 Ch28 prop:NNO-parameter-recursion | incremental-revisions/quotients-v1/final/sections/76-given-natural-number-objects.tex | SHA256 ac3b7032389fb84548c4efbb3e92e7d639019efccbd113c744e5fa6fbe997f46 | lines 133–133
- V2 Ch31 prop:primitive-recursion | incremental-revisions/arithmetic-v1/final/sections/82-primitive-recursion-and-invariants.tex | SHA256 c0ccc95c79d57395f500032b1f527e9783485f370c52aceb907e278357c1fc82 | lines 12–20

### V2-C:R02 — Natural numbers as initial rig

Optional/not selected; no invented later-volume destination; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:R02 — RIEHL, Example2.1.1 footnote2, printed54 / PDF74; universal-property aside; 部分涵蓋. The semiring operations/laws are explicit, but initiality among all supplied rig objects is not a named theorem. The reference footnote does not automatically impose this extra universal-property course. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch30 def:commutative-semiring-object | incremental-revisions/arithmetic-v1/final/sections/79-multiplication-semiring.tex | SHA256 83696741b482a39e4e454ac481df39bc68df86264e4e3cd14cd6fcfdb84b2013 | lines 152–163

### V2-C:R03 — Group completion of a commutative monoid

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:R03 — RIEHL, Example4.1.10(x), printed136 / PDF156; example heading printed135 / PDF155; construction/universal property; 部分涵蓋. Riehl's general relation allows an extra common summand c; cancellation in N removes it. V2 supplies one effective quotient and proves its extension test. Do not generalize to all monoids or all effective quotients. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch39 prop:integer-group-completion | incremental-revisions/euclidean-v1/final/sections/103-integer-universal-property.tex | SHA256 c8d95495a058ba070228897a4c5c53e89d394be529d7e5e12286509e319bcc66 | lines 17–22

### V2-C:R04 — Unique unital integer-ring map

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:R04 — RIEHL, Example4.1.10(xiii), printed136 / PDF156; example/interface; 已涵蓋. The reference uses the unique Z-to-ring map as an example; V2 states and proves the conditional universal ring test. No new external proof-reading claim is made. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch39 prop:integer-initial-ring | incremental-revisions/euclidean-v1/final/sections/103-integer-universal-property.tex | SHA256 c8d95495a058ba070228897a4c5c53e89d394be529d7e5e12286509e319bcc66 | lines 62–67

### V2-C:R05 — Least common multiple through a pullback of integer scalar maps

Optional/not selected; no invented later-volume destination; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:R05 — RIEHL, Example3.1.19, printed87–88 / PDF107–108; diagram(3.1.20) and footnote4; example; 部分涵蓋. The lcm construction and greatest/least tests are explicit, but the full Ab-category pullback example is not a V2 obligation. Riehl's compatible sign ambiguity must not be replaced with literal uniqueness of signed generators. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch42 prop:lcm-construction | incremental-revisions/euclidean-v1/final/sections/109-least-common-multiples.tex | SHA256 29ebd1b8bc75a8edbae55cfdb3c4995df763765dd0fab34016b9b054b098cda1 | lines 54–59

### V2-C:R06 — Floor and ceiling as adjoints to the integer inclusion

Optional/not selected; no invented later-volume destination; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:R06 — RIEHL, Example4.1.7, printed134 / PDF154; example/interface; 部分涵蓋. V2 proves floor uniqueness, its inequalities and integer-shift law. It does not explicitly name ceiling or the full adjoint triple; no new adjunction chapter is requested. Read extent: Named statement/definition/example body inspected in the fixed PDF; no exact proof/answer certification Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch51 sec:ec-floor-function | incremental-revisions/completion-v1/final/sections/136-monotone-completeness.tex | SHA256 08627fc3a5d773b9d0e4574c590ca0def138cfa431d6aa935ecf995213e24f31 | lines 86–86

### V2-C:LR-S1 — Parameterized recursion and algebra on the supplied NNO — LR correspondence

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LR-S1 — LR, UNKNOWN — readable body not obtained; no chapter/page/theorem assigned; correspondence unknown; 未知. Only bibliography/known access limitation is inherited. Neither exhaustive omission nor agreement can be judged. Read extent: UNKNOWN: readable body not obtained; no page/theorem reconstructed from metadata Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch29 prop:parameter-mono-induction | volume-revisions/author-recovery-r2/adopted/incremental-revisions/arithmetic-v1/final/sections/77-parameter-induction.tex | SHA256 e2258688dfc609324ca64e4b0bdfbabc1263e62d1d5e2de698e02b3396387f76 | lines 48–57
- V2 Ch29 prop:parameter-equality-induction | volume-revisions/author-recovery-r2/adopted/incremental-revisions/arithmetic-v1/final/sections/77-parameter-induction.tex | SHA256 e2258688dfc609324ca64e4b0bdfbabc1263e62d1d5e2de698e02b3396387f76 | lines 86–94

### V2-C:LR-S2 — Order and finite assembly — LR correspondence

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LR-S2 — LR, UNKNOWN — readable body not obtained; no chapter/page/theorem assigned; correspondence unknown; 未知. Only bibliography/known access limitation is inherited. Neither exhaustive omission nor agreement can be judged. Read extent: UNKNOWN: readable body not obtained; no page/theorem reconstructed from metadata Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch32 prop:zero-sum | incremental-revisions/completion-v1/adopted/sections/84-order-by-a-unique-gap.tex | SHA256 474637b5bde19ab3cd8a7b68ec24be3e040f378d63e391d62609b8b5f2c6fca8 | lines 35–38
- V2 Ch32 prop:natural-order-laws | incremental-revisions/completion-v1/adopted/sections/84-order-by-a-unique-gap.tex | SHA256 474637b5bde19ab3cd8a7b68ec24be3e040f378d63e391d62609b8b5f2c6fca8 | lines 64–69

### V2-C:LR-S3 — Witnessed divisibility, bounded decisions and division — LR correspondence

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LR-S3 — LR, UNKNOWN — readable body not obtained; no chapter/page/theorem assigned; correspondence unknown; 未知. Only bibliography/known access limitation is inherited. Neither exhaustive omission nor agreement can be judged. Read extent: UNKNOWN: readable body not obtained; no page/theorem reconstructed from metadata Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch34 prop:positive-multiplication-cancel | incremental-revisions/completion-v1/adopted/sections/90-divisibility-and-parity.tex | SHA256 1e567817e93e1716c89d7d76f398c620f366b99797de311a230a7e95859e2f9c | lines 19–25
- V2 Ch34 prop:parity-decomposition | incremental-revisions/completion-v1/adopted/sections/90-divisibility-and-parity.tex | SHA256 1e567817e93e1716c89d7d76f398c620f366b99797de311a230a7e95859e2f9c | lines 107–116

### V2-C:LR-S4 — Euclidean witnesses, termination and gcd — LR correspondence

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LR-S4 — LR, UNKNOWN — readable body not obtained; no chapter/page/theorem assigned; correspondence unknown; 未知. Only bibliography/known access limitation is inherited. Neither exhaustive omission nor agreement can be judged. Read extent: UNKNOWN: readable body not obtained; no page/theorem reconstructed from metadata Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch37 prop:arithmetic-disjoint-copair | incremental-revisions/euclidean-v1/final/sections/96-common-divisor-reduction.tex | SHA256 c647b4b683d61d5b9f8c81dede5fa3e327f883b17b05adb83458078f289194a7 | lines 27–32
- V2 Ch37 prop:common-divisor-reduction | incremental-revisions/euclidean-v1/final/sections/96-common-divisor-reduction.tex | SHA256 c647b4b683d61d5b9f8c81dede5fa3e327f883b17b05adb83458078f289194a7 | lines 76–87

### V2-C:LR-S5 — Integers, signed certificates and congruences — LR correspondence

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LR-S5 — LR, UNKNOWN — readable body not obtained; no chapter/page/theorem assigned; correspondence unknown; 未知. Only bibliography/known access limitation is inherited. Neither exhaustive omission nor agreement can be judged. Read extent: UNKNOWN: readable body not obtained; no page/theorem reconstructed from metadata Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch39 prop:integer-additive-group | incremental-revisions/euclidean-v1/final/sections/101-supplied-integer-completion.tex | SHA256 58ca6811fb1071fe49f391709ce6bb3ac4182e02d975e8347d8e4cc2eab0cd32 | lines 83–89
- V2 Ch39 prop:integer-ring | incremental-revisions/euclidean-v1/final/sections/102-integer-ring-operations.tex | SHA256 b51651d0467286979a935c1a6b1aa0c267a656f20a204e6c3a87a748d2bec2c5 | lines 55–59

### V2-C:LR-S6 — Reduced fractions and the finite completeness boundary — LR correspondence

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LR-S6 — LR, UNKNOWN — readable body not obtained; no chapter/page/theorem assigned; correspondence unknown; 未知. Only bibliography/known access limitation is inherited. Neither exhaustive omission nor agreement can be judged. Read extent: UNKNOWN: readable body not obtained; no page/theorem reconstructed from metadata Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch45 prop:reduced-fraction-unique | incremental-revisions/euclidean-v1/final/sections/115-reduced-fraction-object.tex | SHA256 d69e1ce0fd72c1648173807466f9648a08321656c071dd72e91ba4ac3e84c3ca | lines 65–69
- V2 Ch45 prop:fraction-quotient | incremental-revisions/euclidean-v1/final/sections/115-reduced-fraction-object.tex | SHA256 d69e1ce0fd72c1648173807466f9648a08321656c071dd72e91ba4ac3e84c3ca | lines 90–96

### V2-C:LR-S7 — Externally supplied Cauchy completion and completeness comparisons — LR correspondence

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LR-S7 — LR, UNKNOWN — readable body not obtained; no chapter/page/theorem assigned; correspondence unknown; 未知. Only bibliography/known access limitation is inherited. Neither exhaustive omission nor agreement can be judged. Read extent: UNKNOWN: readable body not obtained; no page/theorem reconstructed from metadata Proof: UNKNOWN / not upgraded in this boundary phase.

Current destinations:
- V2 Ch47 prop:ec-quotient-test | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/122-external-completion-interface.tex | SHA256 35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3 | lines 95–102
- V2 Ch47 prop:ec-cauchy-bounded | incremental-revisions/completion-v1/final/sections/123-cauchy-estimates.tex | SHA256 473e6003a4b52433f791591e2e19fe587105feddf95ac1acb7b21b4a60949cbc | lines 10–14

### V2-C:STEIN-1-1-3 — Prime and composite

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:1.1.3 — STEIN, Definition 1.1.3; printed2; PDF9; Definition; 缺漏. Prime/composite and the exclusions0,1 are not explicitly defined in the selected manuscript. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch42 prop:euclid-lemma | incremental-revisions/euclidean-v1/final/sections/108-coprime-cancellation.tex | SHA256 96f781a8a6e1f36a6996dbd426694cf247b44dfc07dd337ea0293b9228a10192 | lines 33–39

### V2-C:STEIN-2-1-1 — Group

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.1 — STEIN, Definition 2.1.1; printed22; PDF29; Definition; 部分涵蓋. V2 needs abelian group objects; arbitrary noncommutative groups are not a new required V2 course. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch39 def:abelian-group-object | incremental-revisions/euclidean-v1/final/sections/101-supplied-integer-completion.tex | SHA256 58ca6811fb1071fe49f391709ce6bb3ac4182e02d975e8347d8e4cc2eab0cd32 | lines 72–79

### V2-C:STEIN-2-1-2 — Abelian group

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.2 — STEIN, Definition 2.1.2; printed22; PDF29; Definition; 已涵蓋. Object equations specialize to ordinary set groups; source/target data remain explicit. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch39 def:abelian-group-object | incremental-revisions/euclidean-v1/final/sections/101-supplied-integer-completion.tex | SHA256 58ca6811fb1071fe49f391709ce6bb3ac4182e02d975e8347d8e4cc2eab0cd32 | lines 72–79
- V2 Ch39 prop:integer-additive-group | incremental-revisions/euclidean-v1/final/sections/101-supplied-integer-completion.tex | SHA256 58ca6811fb1071fe49f391709ce6bb3ac4182e02d975e8347d8e4cc2eab0cd32 | lines 83–89

### V2-C:STEIN-2-1-3 — Unital ring and commutative ring

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.3 — STEIN, Definition 2.1.3; printed22; PDF29; Definition; 部分涵蓋. V2 explicitly uses the commutative unital case and both distributive laws; do not weaken its definition to shorter reference wording. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch39 def:commutative-ring-object | incremental-revisions/euclidean-v1/final/sections/102-integer-ring-operations.tex | SHA256 b51651d0467286979a935c1a6b1aa0c267a656f20a204e6c3a87a748d2bec2c5 | lines 37–47
- V2 Ch39 prop:integer-ring | incremental-revisions/euclidean-v1/final/sections/102-integer-ring-operations.tex | SHA256 b51651d0467286979a935c1a6b1aa0c267a656f20a204e6c3a87a748d2bec2c5 | lines 55–59

### V2-C:STEIN-2-1-9 — Decimal digit-sum divisibility by3

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.9 — STEIN, Proposition 2.1.9; printed23; PDF30; Proposition; 缺漏. The exact decimal checksum example is not written; it is not necessary for binary reconstruction or number-system construction. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch36 prop:congruence-operations | incremental-revisions/arithmetic-v1/final/sections/95-remainder-calculus.tex | SHA256 b10967a0db051980d096b11375f0a5d38792d5faff1a13797fd8c530468e07f3 | lines 130–138
- V2 Ch35 prop:binary-reconstruction | incremental-revisions/arithmetic-v1/final/sections/93-finite-binary-reconstruction.tex | SHA256 de7dc0ca6189b83eaa97aed21c52fad577626cb3888538ad07d3eeddbdb51201 | lines 47–56

### V2-C:STEIN-2-1-12 — Multiplication by a unit permutes residues

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.12 — STEIN, Lemma 2.1.12; printed24; PDF31; Lemma; 部分涵蓋. Inverse/uniqueness calculations are present, but a residue-ring permutation formulation awaits its object bridge. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch43 sec:coprime-modular-inverse | incremental-revisions/calculus-v1/adopted/sections/111-solving-linear-congruences.tex | SHA256 480055148a0fb3cb05eb98feedb0b5a157b748e8c084be2a15acde73136172e4 | lines 50–50
- V2 Ch43 prop:bounded-congruence-solutions | incremental-revisions/euclidean-v1/final/sections/112-classifying-congruence-solutions.tex | SHA256 8e9d9f7f199a9956b5489a79c7b87fdcbce9259a538013602ebea999a570d0d5 | lines 56–66

### V2-C:STEIN-2-1-15 — Gcd criterion for a linear congruence

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.15 — STEIN, Proposition 2.1.15; printed25; PDF32; Proposition; 已涵蓋. Selected natural representatives have exactly the stated criterion and full bounded solution family; signed inputs use integer remainder first. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch43 prop:linear-congruence-existence | incremental-revisions/calculus-v1/adopted/sections/111-solving-linear-congruences.tex | SHA256 480055148a0fb3cb05eb98feedb0b5a157b748e8c084be2a15acde73136172e4 | lines 16–22
- V2 Ch43 prop:bounded-congruence-solutions | incremental-revisions/euclidean-v1/final/sections/112-classifying-congruence-solutions.tex | SHA256 8e9d9f7f199a9956b5489a79c7b87fdcbce9259a538013602ebea999a570d0d5 | lines 56–66

### V2-C:STEIN-2-1-16 — Multiplicative order of a unit

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.16 — STEIN, Definition 2.1.16; printed25; PDF32; Definition; 缺漏. Not in the selected construction/Euclidean route; visible optional absence, not a compulsory finite-group course. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- No confirmed current/later destination; do not invent one.

### V2-C:STEIN-2-1-18 — Euler totient

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.18 — STEIN, Definition 2.1.18; printed26; PDF33; Definition; 缺漏. Not a theorem needed by existing CRT or rational normalization. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- No confirmed current/later destination; do not invent one.

### V2-C:STEIN-2-1-20 — Euler congruence

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.20 — STEIN, Theorem 2.1.20; printed26; PDF33; Theorem; 缺漏. Requires an additional unit-counting/finite-group development; not selected automatically because it shares the section. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- No confirmed current/later destination; do not invent one.

### V2-C:STEIN-2-1-22 — Wilson prime criterion

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.1.22 — STEIN, Proposition 2.1.22; printed27; PDF34; Proposition; 缺漏. The prime-factorization core does not require Wilson. No primality-test course requested. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- No confirmed current/later destination; do not invent one.

### V2-C:STEIN-2-2-5 — CRT bijection on unit groups

Optional/not selected; no invented later-volume destination; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.2.5 — STEIN, Lemma 2.2.5; printed30; PDF37; Lemma; 部分涵蓋. The bounded CRT isomorphism is present; a full unit-group restriction is an optional corollary, not already named. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch44 prop:coprime-crt | incremental-revisions/euclidean-v1/final/sections/113-two-coprime-moduli.tex | SHA256 e17a9371994e38fafac5845ed53a3a64766c36a443d77b20982bf004a35a5bdc | lines 30–37

### V2-C:STEIN-2-2-6 — Multiplicative arithmetic function

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.2.6 — STEIN, Definition 2.2.6; printed31; PDF38; Definition; 缺漏. Not required; its complex codomain does not authorize a complex-number construction in V2. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- No confirmed current/later destination; do not invent one.

### V2-C:STEIN-2-2-7 — Multiplicativity of totient

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.2.7 — STEIN, Proposition 2.2.7; printed31; PDF38; Proposition; 缺漏. Depends on the optional totient/unit-group route; not a missing prerequisite of current CRT. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- No confirmed current/later destination; do not invent one.

### V2-C:STEIN-2-3-11 — Binary expansion by repeated halving

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:STEIN:2.3.11 — STEIN, Algorithm 2.3.11; printed34; PDF41; Algorithm; 部分涵蓋. V2 reconstructs at a given stopping bound; the explicit guaranteed halving bound should accompany the fast-power bridge. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch35 prop:binary-reconstruction | incremental-revisions/arithmetic-v1/final/sections/93-finite-binary-reconstruction.tex | SHA256 de7dc0ca6189b83eaa97aed21c52fad577626cb3888538ad07d3eeddbdb51201 | lines 47–56

### V2-C:LEBL-1-1-1 — Strict linear order

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.1 — LEBL, Definition 1.1.1; printed23; PDF23; Definition; 已涵蓋. Internal source cases and ordinary external trichotomy must remain distinct. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.
- TAO-SAMPLE:order — Definition 2.2.11; sample printed 31; DVI page 41; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch32 prop:comparison-decomposition | incremental-revisions/completion-v1/adopted/sections/85-trichotomy-and-comparison.tex | SHA256 5bad42ba51fbbb145e6ec1d10e44bb0c8b938172f35ed81b55269f39fca1166b | lines 59–62
- V2 Ch40 prop:integer-order-laws | incremental-revisions/euclidean-v1/final/sections/104-integer-sign-and-order.tex | SHA256 ed561bebaa1eb76a974d165732659a264982b7ccce5058a9f3af8e52538b36c0 | lines 81–88
- V2 Ch48 prop:ec-order-laws | incremental-revisions/completion-v1/final/sections/126-order-from-tails.tex | SHA256 2c4b4c22a1447e214da84ddc89e54ff083dee53e26027a119cc881456b189b81 | lines 58–65

### V2-C:LEBL-1-1-2 — Bounds, supremum and infimum

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.2 — LEBL, Definition 1.1.2; printed23; PDF23; Definition; 已涵蓋. The source definition continues onto printed24; only nonempty appropriately bounded real sets receive finite extrema. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 sec:ec-supremum-definition | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 10–10
- V2 Ch51 sec:ec-supremum-approximation | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 63–63

### V2-C:LEBL-1-1-3 — Least-upper-bound property

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.3 — LEBL, Definition 1.1.3; printed24; PDF24; Definition; 已涵蓋. The property is proved for the supplied EC completion, not postulated for every category. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 prop:ec-supremum-existence | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 21–25

### V2-C:LEBL-1-1-7 — Ordered field

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.7 — LEBL, Definition 1.1.7; printed25; PDF25; Definition; 已涵蓋. Ordinary EC definition and proved quotient order agree with the intended typed scope. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch47 sec:ec-external-interface | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/122-external-completion-interface.tex | SHA256 35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3 | lines 10–10
- V2 Ch48 prop:ec-order-laws | incremental-revisions/completion-v1/final/sections/126-order-from-tails.tex | SHA256 2c4b4c22a1447e214da84ddc89e54ff083dee53e26027a119cc881456b189b81 | lines 58–65

### V2-C:LEBL-1-1-8 — Elementary ordered-field inequalities

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.8 — LEBL, Proposition 1.1.8; printed26; PDF26; Proposition; 部分涵蓋. Translation, positive multiplication and inverse comparisons are explicit; the full seven-rule list is distributed rather than named. Consolidate only the rules used in supremum transport. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch48 prop:ec-order-laws | incremental-revisions/completion-v1/final/sections/126-order-from-tails.tex | SHA256 2c4b4c22a1447e214da84ddc89e54ff083dee53e26027a119cc881456b189b81 | lines 58–65
- V2 Ch48 sec:ec-division-order | incremental-revisions/completion-v1/final/sections/127-completion-inverses.tex | SHA256 800f691dacf0298af85da1159d6000406d816a7d28a7cb657c4bc0bb733ee937 | lines 54–54

### V2-C:LEBL-1-1-9 — Signs of factors of a positive product

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.9 — LEBL, Proposition 1.1.9; printed26; PDF26; Proposition; 已涵蓋. Follows through the explicit ordinary sign cases; not a new global-point rule. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch48 prop:ec-sign-trichotomy | incremental-revisions/completion-v1/final/sections/126-order-from-tails.tex | SHA256 2c4b4c22a1447e214da84ddc89e54ff083dee53e26027a119cc881456b189b81 | lines 17–21
- V2 Ch48 prop:ec-order-laws | incremental-revisions/completion-v1/final/sections/126-order-from-tails.tex | SHA256 2c4b4c22a1447e214da84ddc89e54ff083dee53e26027a119cc881456b189b81 | lines 58–65

### V2-C:LEBL-1-1-11 — Infimum by negating a supremum

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.11 — LEBL, Proposition 1.1.11; printed27; PDF27; Proposition; 已涵蓋. The current section defines inf S using -sup(-S) and gives the dual test. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 sec:ec-supremum-approximation | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 63–63

### V2-C:LEBL-1-2-1 — Unique complete ordered real field

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.2.1 — LEBL, Theorem 1.2.1; printed29; PDF29; Theorem; 已涵蓋. Lebl explicitly omits the existence/construction proof and means uniqueness up to isomorphism. It is a target-statement comparator, not evidence validating the current Cauchy construction. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch48 prop:ec-field | incremental-revisions/completion-v1/final/sections/127-completion-inverses.tex | SHA256 800f691dacf0298af85da1159d6000406d816a7d28a7cb657c4bc0bb733ee937 | lines 10–15
- V2 Ch50 prop:ec-completion-uniqueness | incremental-revisions/completion-v1/final/sections/133-completion-comparison.tex | SHA256 289c772dbdf6650e410b064cce28c2c71c33fa5782174c0ee995678f96242603 | lines 29–36
- V2 Ch51 prop:ec-supremum-existence | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 21–25

### V2-C:LEBL-1-2-2 — Arbitrarily small upper bounds force a nonpositive value

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.2.2 — LEBL, Proposition 1.2.2; printed29; PDF29; Proposition; 部分涵蓋. The idea is used in order/limit bounds but lacks a compact named elementary lemma; can be included in the small supremum-calculus consolidation. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 prop:ec-limit-order | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 100–105
- V2 Ch51 sec:ec-supremum-approximation | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 63–63

### V2-C:LEBL-1-2-4 — Archimedean property and rational density

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.2.4 — LEBL, Theorem 1.2.4; printed31; PDF31; Theorem; 已涵蓋. Both statements have explicit manuscript targets. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch49 prop:ec-archimedean | incremental-revisions/completion-v1/final/sections/128-archimedean-density.tex | SHA256 2373587cf72b26489379f8882936c09918ff47568909f501996a8aff4efccfac | lines 21–27
- V2 Ch49 prop:ec-rational-density | incremental-revisions/completion-v1/final/sections/128-archimedean-density.tex | SHA256 2373587cf72b26489379f8882936c09918ff47568909f501996a8aff4efccfac | lines 83–88

### V2-C:LEBL-1-2-5 — Infimum of reciprocals of positive integers is zero

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.2.5 — LEBL, Corollary 1.2.5; printed32; PDF32; Corollary; 部分涵蓋. Reciprocal decay and infimum exist; the explicit corollary is not named. A brief consequence is enough, not a new sequence chapter. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch49 prop:ec-archimedean | incremental-revisions/completion-v1/final/sections/128-archimedean-density.tex | SHA256 2373587cf72b26489379f8882936c09918ff47568909f501996a8aff4efccfac | lines 21–27
- V2 Ch51 sec:ec-supremum-approximation | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 63–63

### V2-C:LEBL-1-2-6 — Translation and signed scaling of suprema/infima

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.2.6 — LEBL, Proposition 1.2.6; printed32; PDF32; Proposition; 部分涵蓋. The negative-set duality is explicit; the six affine transport formulas are not written as a package. Add the finite set of universal-bound arguments, with x=0 treated separately. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 sec:ec-supremum-approximation | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 63–63

### V2-C:LEBL-1-2-7 — Separated sets have supremum below infimum

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.2.7 — LEBL, Proposition 1.2.7; printed33; PDF33; Proposition; 部分涵蓋. The universal bounds supply the short argument, but it is not an explicit collected result. Include with supremum calculus. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 sec:ec-supremum-definition | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 10–10

### V2-C:LEBL-1-2-9 — Extended-real conventions for empty/unbounded extrema

Optional/not selected; no invented later-volume destination; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.2.9 — LEBL, Definition 1.2.9; printed33; PDF33; Definition; 部分涵蓋. Current V2 stays in R and explicitly declines infinite values. This is a convention boundary, not an error or a required extension. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 sec:ec-supremum-boundaries | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 91–91

### V2-C:LEBL-2-1-1 — Sequence and bounded sequence

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.1 — LEBL, Definition 2.1.1; printed51; PDF51; Definition; 已涵蓋. Ordinary function sequences are part of EC; starting at0 versus1 is a harmless reindexing. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 sec:ec-field-sequence-definitions | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 10–10
- V2 Ch50 prop:ec-basic-limits | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 28–34

### V2-C:LEBL-2-1-2 — Epsilon-tail convergence

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.2 — LEBL, Definition 2.1.2; printed52; PDF52; Definition; 已涵蓋. One threshold controls all later indices; no uniformity across unrelated sequences is inferred. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 sec:ec-field-sequence-definitions | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 10–10

### V2-C:LEBL-2-1-6 — Uniqueness of a sequence limit

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.6 — LEBL, Proposition 2.1.6; printed53; PDF53; Proposition; 已涵蓋. Exact statement target present; no proof rereview. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 prop:ec-basic-limits | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 28–34

### V2-C:LEBL-2-1-7 — A convergent sequence is bounded

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.7 — LEBL, Proposition 2.1.7; printed54; PDF54; Proposition; 已涵蓋. The finite prefix and tail bound are part of the manuscript result. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 prop:ec-basic-limits | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 28–34

### V2-C:LEBL-2-1-9 — Increasing and decreasing sequences

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.9 — LEBL, Definition 2.1.9; printed55; PDF55; Definition; 已涵蓋. Both directions are used; weak monotonicity, not strict growth. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 sec:ec-monotone-convergence | incremental-revisions/completion-v1/final/sections/136-monotone-completeness.tex | SHA256 08627fc3a5d773b9d0e4574c590ca0def138cfa431d6aa935ecf995213e24f31 | lines 7–7

### V2-C:LEBL-2-1-10 — Bounded monotone convergence and supremum/infimum limit

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.10 — LEBL, Theorem 2.1.10; printed55; PDF55; Theorem; 已涵蓋. The two manuscript results cover both implications in their ordinary model. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 prop:ec-monotone-convergence | incremental-revisions/completion-v1/final/sections/136-monotone-completeness.tex | SHA256 08627fc3a5d773b9d0e4574c590ca0def138cfa431d6aa935ecf995213e24f31 | lines 10–15
- V2 Ch50 prop:ec-basic-limits | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 28–34

### V2-C:LEBL-2-1-13 — Monotone sequences inside an arbitrary bounded set approach its extrema

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.13 — LEBL, Proposition 2.1.13; printed56; PDF56; Proposition; 部分涵蓋. Only tolerance-wise member existence is supplied. The stronger sequence-of-members claim is not imported without an actual selection family or extra principle; Lebl leaves its proof as an exercise. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch51 eq:ec-supremum-witness | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 67–67
- V2 Ch51 ex:ec-supremum-choice | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 118–122

### V2-C:LEBL-2-1-16 — Strictly indexed subsequence

Actual later location V4; **後卷**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.16 — LEBL, Definition 2.1.16; printed58; PDF58; Definition; 後卷. Actual V4 Chapter52 location; do not duplicate a subsequence course in V2. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V4 Ch52 sec:ec-subsequences | incremental-revisions/completion-v1/final/sections/138-bounded-subsequences.tex | SHA256 4f00026b048551bad575e5861496e552906a4c7786d9b6a1ef07711828643b0e | lines 8–8

### V2-C:LEBL-2-1-17 — A subsequence of a convergent sequence has the same limit

Actual later location V4; **後卷**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.17 — LEBL, Proposition 2.1.17; printed58; PDF58; Proposition; 後卷. The necessary subsequence interface is already selected in V4 Chapter52. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V4 Ch52 sec:ec-subsequences | incremental-revisions/completion-v1/final/sections/138-bounded-subsequences.tex | SHA256 4f00026b048551bad575e5861496e552906a4c7786d9b6a1ef07711828643b0e | lines 8–8

### V2-C:LEBL-2-4-1 — Cauchy sequence

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.4.1 — LEBL, Definition 2.4.1; printed84; PDF84; Definition; 已涵蓋. Rational Cauchy data and real-field Cauchy tests are distinguished. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch47 def:ec-rational-cauchy | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/122-external-completion-interface.tex | SHA256 35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3 | lines 54–68
- V2 Ch50 sec:ec-field-sequence-definitions | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 10–10

### V2-C:LEBL-1-1-4 — Rationals lack the least-upper-bound property

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.4 — LEBL, Example 1.1.4; printed24; PDF24; Example; 部分涵蓋. Current rational nested obstruction has the same motivation; the exact subset-supremum example is not a separate internal cut construction. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch46 prop:no-rational-root-two | incremental-revisions/euclidean-v1/final/sections/121-rational-completeness-boundary.tex | SHA256 fdbb628ed645ea45a8ce78a31dfd256383e661a855497cc09805308a5c6e1487 | lines 23–28
- V2 Ch46 prop:rational-nested-no-point | incremental-revisions/euclidean-v1/final/sections/121-rational-completeness-boundary.tex | SHA256 fdbb628ed645ea45a8ce78a31dfd256383e661a855497cc09805308a5c6e1487 | lines 87–92

### V2-C:LEBL-1-1-6 — Fields versus the integer ring

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.6 — LEBL, Example 1.1.6; printed25; PDF25; Example; 已涵蓋. Compare constructions, without treating a ring as a field. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch39 prop:integer-ring | incremental-revisions/euclidean-v1/final/sections/102-integer-ring-operations.tex | SHA256 b51651d0467286979a935c1a6b1aa0c267a656f20a204e6c3a87a748d2bec2c5 | lines 55–59
- V2 Ch48 prop:ec-field | incremental-revisions/completion-v1/final/sections/127-completion-inverses.tex | SHA256 800f691dacf0298af85da1159d6000406d816a7d28a7cb657c4bc0bb733ee937 | lines 10–15

### V2-C:LEBL-1-1-10 — Complex numbers are not an ordered field

Optional/not selected; no invented later-volume destination; **缺漏**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.1.10 — LEBL, Example 1.1.10; printed27; PDF27; Example; 缺漏. Optional illustration; complex numbers remain outside V2 and no later location is invented. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- No confirmed current/later destination; do not invent one.

### V2-C:LEBL-1-2-3 — Existence and uniqueness of a positive square root of2

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:1.2.3 — LEBL, Example 1.2.3; printed29; PDF29; Example; 已涵蓋. Specific root is proved in V2; general positive roots are in V4. This is not a missing real-number construction. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch48 sec:ec-root-two-value | incremental-revisions/completion-v1/final/sections/127-completion-inverses.tex | SHA256 800f691dacf0298af85da1159d6000406d816a7d28a7cb657c4bc0bb733ee937 | lines 81–81

### V2-C:LEBL-2-1-3 — Constant sequence limit

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **已涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.3 — LEBL, Example 2.1.3; printed53; PDF53; Example; 已涵蓋. Current theorem covers the example; no need to duplicate its literal number. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 prop:ec-basic-limits | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 28–34

### V2-C:LEBL-2-1-8 — A rational-expression sequence limit

V2 proposed core/application, with prerequisites or later variants separately qualified in source items; **部分涵蓋**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.8 — LEBL, Example 2.1.8; printed54; PDF54; Example; 部分涵蓋. Same limit-estimate skill with a different problem; the exact example need not be copied. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V2 Ch50 ex:ec-limit-quotient | incremental-revisions/completion-v1/final/sections/131-limits-and-estimates.tex | SHA256 75b1b4bdc0132c460f4ad5265ac9c25c98443cf339a7933431379129d2783888 | lines 126–130

### V2-C:LEBL-2-1-11 — Reciprocal square roots form a decreasing null sequence

Actual later location V2,V4; **後卷**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.11 — LEBL, Example 2.1.11; printed56; PDF56; Example; 後卷. General root existence is selected in V4 Chapter52; monotone theorem itself is already V2. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V4 Ch52 prop:ec-positive-roots | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/137-intervals-and-roots.tex | SHA256 bd189590ebde19c16d3432583f46bd6186fac102e64a9103a240a6fedc14fef1 | lines 63–63
- V2 Ch51 prop:ec-monotone-convergence | incremental-revisions/completion-v1/final/sections/136-monotone-completeness.tex | SHA256 08627fc3a5d773b9d0e4574c590ca0def138cfa431d6aa935ecf995213e24f31 | lines 10–15

### V2-C:LEBL-2-1-12 — Harmonic partial sums are unbounded

Actual later location V2,V4; **後卷**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.12 — LEBL, Example 2.1.12; printed56; PDF56; Example; 後卷. V4 Chapter53 explicitly proves nonconvergence by the Cauchy tail test. Its positive partial sums are increasing, so unboundedness follows with the existing V2 monotone theorem; do not claim the V4 answer literally starts with unboundedness. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V4 Ch53 ex:ec-harmonic-tail | incremental-revisions/completion-v1/final/sections/140-series-and-tail-tests.tex | SHA256 9a2da5ec2ed1f3305c7d5049b0d91a3edf485bff6a9b4c657bc1ed59004c490b | lines 117–117
- V2 Ch51 prop:ec-monotone-convergence | incremental-revisions/completion-v1/final/sections/136-monotone-completeness.tex | SHA256 08627fc3a5d773b9d0e4574c590ca0def138cfa431d6aa935ecf995213e24f31 | lines 10–15

### V2-C:LEBL-2-1-18 — Convergent subsequences need not imply sequence convergence

Actual later location V4; **後卷**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:LEBL:2.1.18 — LEBL, Example 2.1.18; printed58; PDF58; Example; 後卷. V4 supplies an actual unbounded counterexample with a constant subsequence. Lebl uses bounded alternation; that stronger illustrative detail is not asserted to be the same printed example. Read extent: Actual named statement/definition/algorithm or identified example opening inspected in fixed author PDF; complete proof and exact answer not certified Proof: UNKNOWN / no new full-proof certification.

Current destinations:
- V4 Ch52 ex:ec-unbounded-cluster | incremental-revisions/completion-v1/final/sections/138-bounded-subsequences.tex | SHA256 4f00026b048551bad575e5861496e552906a4c7786d9b6a1ef07711828643b0e | lines 104–104
- V4 Ch52 sec:ec-subsequences | incremental-revisions/completion-v1/final/sections/138-bounded-subsequences.tex | SHA256 4f00026b048551bad575e5861496e552906a4c7786d9b6a1ef07711828643b0e | lines 8–8

### V2-C:TAO-Ch2 — Starting at the Beginning: The Natural Numbers

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:TAO:Ch2 — TAO, Publisher contents pp11–26; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch29 prop:parameter-equality-induction | volume-revisions/author-recovery-r2/adopted/incremental-revisions/arithmetic-v1/final/sections/77-parameter-induction.tex | SHA256 e2258688dfc609324ca64e4b0bdfbabc1263e62d1d5e2de698e02b3396387f76 | lines 86–94

### V2-C:TAO-Ch4 — Integers and Rationals

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:TAO:Ch4 — TAO, Publisher contents pp63–79; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch39 prop:integer-ring | incremental-revisions/euclidean-v1/final/sections/102-integer-ring-operations.tex | SHA256 b51651d0467286979a935c1a6b1aa0c267a656f20a204e6c3a87a748d2bec2c5 | lines 55–59
- V2 Ch45 prop:fraction-quotient | incremental-revisions/euclidean-v1/final/sections/115-reduced-fraction-object.tex | SHA256 d69e1ce0fd72c1648173807466f9648a08321656c071dd72e91ba4ac3e84c3ca | lines 90–96

### V2-C:TAO-Ch5 — The Real Numbers

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:TAO:Ch5 — TAO, Publisher contents pp81–107; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch48 prop:ec-field | incremental-revisions/completion-v1/final/sections/127-completion-inverses.tex | SHA256 800f691dacf0298af85da1159d6000406d816a7d28a7cb657c4bc0bb733ee937 | lines 10–15

### V2-C:TAO-Ch6 — Limits of Sequences

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:TAO:Ch6 — TAO, Publisher contents pp109–133; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch50 prop:ec-sequential-completeness | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/132-sequential-completeness.tex | SHA256 7eab903dd389e522c3d7054586aeb99fccaf63f0a61236b9cf2bf1ea42120282 | lines 21–26

### V2-C:ABBOTT-Ch1 — The Real Numbers

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:ABBOTT:Ch1 — ABBOTT, Publisher contents pp1–37; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch51 prop:ec-supremum-existence | incremental-revisions/completion-v1/final/sections/134-supremum-by-bisection.tex | SHA256 219972d4a4414760ae3e9835e4da2feeb943127e3f0d32f8ae300191f5f20dca | lines 21–25

### V2-C:ABBOTT-Ch2 — Sequences and Series

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:ABBOTT:Ch2 — ABBOTT, Publisher contents pp39–84; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch50 prop:ec-sequential-completeness | volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/132-sequential-completeness.tex | SHA256 7eab903dd389e522c3d7054586aeb99fccaf63f0a61236b9cf2bf1ea42120282 | lines 21–26

### V2-C:BURTON-S1-1 — Mathematical Induction

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:BURTON:S1.1 — BURTON, Publisher section heading; body page/theorem UNKNOWN; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch29 prop:parameter-equality-induction | volume-revisions/author-recovery-r2/adopted/incremental-revisions/arithmetic-v1/final/sections/77-parameter-induction.tex | SHA256 e2258688dfc609324ca64e4b0bdfbabc1263e62d1d5e2de698e02b3396387f76 | lines 86–94

### V2-C:BURTON-S2-2 — The Division Algorithm

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:BURTON:S2.2 — BURTON, Publisher section heading; body page/theorem UNKNOWN; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch36 prop:division-unique | incremental-revisions/arithmetic-v1/final/sections/94-division-by-a-positive-divisor.tex | SHA256 f9b76c0cae85958e5441c8c2efdec702b4be922e171c17e0e5549d554ed35807 | lines 101–110

### V2-C:BURTON-S2-3 — The Greatest Common Divisor

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:BURTON:S2.3 — BURTON, Publisher section heading; body page/theorem UNKNOWN; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch37 def:stable-gcd | incremental-revisions/euclidean-v1/final/sections/97-greatest-common-divisor-tests.tex | SHA256 9ad098759645f5ffa9d528c58c3878538bda1e25bd6c19aa2315a6c85543c822 | lines 48–55

### V2-C:BURTON-S2-4 — The Euclidean Algorithm

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:BURTON:S2.4 — BURTON, Publisher section heading; body page/theorem UNKNOWN; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch38 prop:euclidean-gcd | incremental-revisions/euclidean-v1/final/sections/100-constructed-gcd.tex | SHA256 b09bafe76ba25b18d770431d7a39cc9bb9124341a646195b0238d3b2c57bb60b | lines 19–24

### V2-C:BURTON-S2-5 — The Diophantine Equation

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:BURTON:S2.5 — BURTON, Publisher section heading; body page/theorem UNKNOWN; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch41 prop:linear-diophantine-criterion | incremental-revisions/euclidean-v1/final/sections/107-linear-diophantine-tests.tex | SHA256 610a9b47fa76bd2f365be1b50473753fa0de120615e367c2bbc21bc4d61196e8 | lines 19–26

### V2-C:BURTON-S4-2 — Basic Properties of Congruence

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:BURTON:S4.2 — BURTON, Publisher section heading; body page/theorem UNKNOWN; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch36 prop:congruence-operations | incremental-revisions/arithmetic-v1/final/sections/95-remainder-calculus.tex | SHA256 b10967a0db051980d096b11375f0a5d38792d5faff1a13797fd8c530468e07f3 | lines 130–138

### V2-C:BURTON-S4-3 — Binary and Decimal Representations of Integers

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:BURTON:S4.3 — BURTON, Publisher section heading; body page/theorem UNKNOWN; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch35 prop:binary-reconstruction | incremental-revisions/arithmetic-v1/final/sections/93-finite-binary-reconstruction.tex | SHA256 de7dc0ca6189b83eaa97aed21c52fad577626cb3888538ad07d3eeddbdb51201 | lines 47–56

### V2-C:BURTON-S4-4 — Linear Congruences and the Chinese Remainder Theorem

UNKNOWN body; topic routing only, not a confirmed same theorem; **未知**.

Unmerged: retain its distinct mathematical claim, example objective, or body-UNKNOWN candidate. A shared chapter topic is insufficient evidence of synonymy.

- REF:V2:BURTON:S4.4 — BURTON, Publisher section heading; body page/theorem UNKNOWN; Contents-level candidate ONLY; 未知. Readable body not obtained. Target names indicate where a later comparison would start; they do not certify coverage or infer missing propositions. Read extent: Official publisher table of contents/metadata only Proof: UNKNOWN.

Current destinations:
- V2 Ch43 prop:linear-congruence-existence | incremental-revisions/calculus-v1/adopted/sections/111-solving-linear-congruences.tex | SHA256 480055148a0fb3cb05eb98feedb0b5a157b748e8c084be2a15acde73136172e4 | lines 16–22
- V2 Ch44 prop:coprime-crt | incremental-revisions/euclidean-v1/final/sections/113-two-coprime-moduli.tex | SHA256 e17a9371994e38fafac5845ed53a3a64766c36a443d77b20982bf004a35a5bdc | lines 30–37

### V2-C:TAO-SAMPLE-ADDITION — Addition is recursively specified by zero and successor equations.

V2 existing interface; not a new expansion obligation; **部分涵蓋**.

Supplementary readable sample interface; no raw master/reference row created.

- TAO-SAMPLE:addition — Definition 2.2.1; sample printed 27; DVI page 37; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch29 prop:addition-right-successor | incremental-revisions/arithmetic-v1/final/sections/78-addition-and-translations.tex | SHA256 77a1b2812632e5b509c0c0f348bd1c5e914b6f5e67fba8cef7fc6a57ed8f882a | lines 23–30

### V2-C:TAO-SAMPLE-CANCELLATION — Addition by the same natural number is cancellable.

V2 existing interface; not a new expansion obligation; **部分涵蓋**.

Supplementary readable sample interface; no raw master/reference row created.

- TAO-SAMPLE:cancellation — Proposition 2.2.6; sample printed 29; DVI page 39; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch31 prop:difference-undoes-addition | incremental-revisions/completion-v1/adopted/sections/83-predecessor-and-truncated-difference.tex | SHA256 7d278a319c56fe86aaa75bb4a0e1a039ab2d24455960e6569400830ca6c78c01 | lines 91–98

### V2-C:TAO-SAMPLE-MULTIPLICATION — Natural multiplication is recursively specified from addition.

V2 existing interface; not a new expansion obligation; **部分涵蓋**.

Supplementary readable sample interface; no raw master/reference row created.

- TAO-SAMPLE:multiplication — Definition 2.3.1; sample printed 33; DVI page 43; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch30 prop:multiplication-right-successor | incremental-revisions/arithmetic-v1/final/sections/79-multiplication-semiring.tex | SHA256 83696741b482a39e4e454ac481df39bc68df86264e4e3cd14cd6fcfdb84b2013 | lines 54–60

### V2-C:TAO-SAMPLE-INTEGER-PAIRS — Formal natural differences are identified by equality of the cross sums.

V2 existing interface; not a new expansion obligation; **部分涵蓋**.

Supplementary readable sample interface; no raw master/reference row created.

- TAO-SAMPLE:integer-pairs — Definition 4.1.1; sample printed 86; DVI page 96; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch39 sec:integer-quotient-interface | incremental-revisions/euclidean-v1/final/sections/101-supplied-integer-completion.tex | SHA256 58ca6811fb1071fe49f391709ce6bb3ac4182e02d975e8347d8e4cc2eab0cd32 | lines 11–11

### V2-C:TAO-SAMPLE-INTEGER-OPERATIONS — Pair formulas define addition and multiplication independently of the integer representative.

V2 existing interface; not a new expansion obligation; **部分涵蓋**.

Supplementary readable sample interface; no raw master/reference row created.

- TAO-SAMPLE:integer-operations — Definition 4.1.2 and Lemma 4.1.3; sample printed 87; DVI page 97–98; printed 87–88; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch39 prop:integer-ring | incremental-revisions/euclidean-v1/final/sections/102-integer-ring-operations.tex | SHA256 b51651d0467286979a935c1a6b1aa0c267a656f20a204e6c3a87a748d2bec2c5 | lines 55–59

### V2-C:TAO-SAMPLE-RATIONAL-PAIRS — Fractions have integer numerator, nonzero denominator and cross-product equality.

V2 existing interface; not a new expansion obligation; **部分涵蓋**.

Supplementary readable sample interface; no raw master/reference row created.

- TAO-SAMPLE:rational-pairs — Definition 4.2.1; sample printed 94; DVI page 104; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch45 prop:fraction-quotient | incremental-revisions/euclidean-v1/final/sections/115-reduced-fraction-object.tex | SHA256 d69e1ce0fd72c1648173807466f9648a08321656c071dd72e91ba4ac3e84c3ca | lines 90–96

### V2-C:TAO-SAMPLE-RATIONAL-OPERATIONS — The fraction operations respect replacement by equivalent representatives.

V2 existing interface; not a new expansion obligation; **部分涵蓋**.

Supplementary readable sample interface; no raw master/reference row created.

- TAO-SAMPLE:rational-operations — Definition 4.2.2 and Lemma 4.2.3; sample printed 94; DVI page 104–105; printed 94–95; UNIDENTIFIED author-hosted sample; not certified fourth edition. Ordinary-set sample statement; V2 supplies typed operations/quotient data under A/S/R/Z or EC. Sample is not evidence of fourth-edition wording or of a common adopted foundation.

Current destinations:
- V2 Ch45 prop:fraction-quotient | incremental-revisions/euclidean-v1/final/sections/115-reduced-fraction-object.tex | SHA256 d69e1ce0fd72c1648173807466f9648a08321656c071dd72e91ba4ac3e84c3ca | lines 90–96

