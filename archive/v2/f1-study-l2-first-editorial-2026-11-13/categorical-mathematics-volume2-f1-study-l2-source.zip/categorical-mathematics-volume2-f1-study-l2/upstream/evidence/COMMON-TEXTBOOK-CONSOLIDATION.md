# V2 common-textbook consolidation of the same r1 proposal

13 November 2026. This is the user's requested single consolidation **before** expansion consensus. It is not a second mathematical review, a new agreed boundary, or a rewrite of the existing60 units.

## Actual sources and limits

| Candidate | What was actually obtained | Exact bounded use |
|---|---|---|
| William Stein, *Elementary Number Theory: Primes, Congruences, and Secrets*, author PDF dated23 January2017 | Complete172-page author original,2,771,146bytes, SHA256 `7edaf4fbab6e738f7ef7298a620a05afbac35fe9b24c2cbd1ace51013d9f436f` | §1.1, printed2–10 / PDF9–17, stopping before §1.2; §§2.1–2.3, printed22–35 / PDF29–42. Definitions, named statements and algorithm specifications compared; selected example openings inspected |
| Jiri Lebl, *Basic Analysis I*, v6.3,15 May2026 | Complete312-page author original,1,901,622bytes, SHA256 `9c204ae1f1ee1641fa604a6456c0d13db4390db44633ee2df9c9d97b5486b7a6` | §§1.1–1.2, printed/PDF23–35; §2.1,51–60; §2.4,84–86. Named statements and representative examples compared;63 exercise headings/openings catalogued only |
| Terence Tao, *Analysis I*, fourth edition,2022 | Official publisher metadata/contents only | Ch2 Natural Numbers,11–26; Ch4 Integers and Rationals,63–79; Ch5 Real Numbers,81–107; Ch6 Limits of Sequences,109–133. **Body and individual statements UNKNOWN** |
| David M. Burton, *Elementary Number Theory*, seventh edition, ebook ISBN9780077145088 | Official publisher section contents only | §1.1; §§2.2–2.5; §§4.2–4.4. **Body pages, propositions and proofs UNKNOWN** |
| Stephen Abbott, *Understanding Analysis*, second edition,2015 | Official publisher metadata/contents only | Ch1 Real Numbers,1–37; Ch2 Sequences and Series,39–84. **Body and individual statements UNKNOWN** |

Exact URLs/bibliography are in `references.json`. Both unchanged author originals are recoverable under `reference-originals/`, including their original notices. The three commercial books have fourteen contents-level candidate rows; matching their headings to the manuscript is a search starting point, not a coverage result. No unauthorized mirror, purchase, access-control workaround or fabricated body inventory was used.

The same table now has the418 original V2 IDs in their original order, the35 earlier reference-first IDs in their original order, and107 added comparison rows:49 Stein items,44 Lebl items,14 contents-only candidates. The107 are not107 completed proof checks. The original1882-ID mother registry and manuscript sources are unchanged. `history/r1/` retains the prior proposal/tables, and its persistent version1 remains available. No archive is nested.

## What the comparisons actually establish

Stein supplies a conventional elementary-number-theory comparator for divisibility, Euclidean reduction, gcd, linear congruences, CRT, Bezout coefficients, inverses and binary modular computation. Those present manuscript topics have actual label/hash/line targets. Positive-divisor algorithms and natural-arrow witnesses are not silently relabelled as arbitrary signed-input statements. Stein uses a signed magnitude normalization and gcd(0,0)=0; this clarifies the earlier contrast with Hammack's exclusion of the zero pair rather than making the manuscript change convention.

The current manuscript already supplies explicit Euclidean stopping and signed coefficient invariants. Stein's algorithm2.3.7, printed33, explicitly omits part of its inductive correctness proof. Its shorter presentation is not permission to remove the current invariant or infer that an external full proof was read. Likewise, textbook examples/abbreviated ring and field definitions do not override explicit commutativity, nontriviality or zero-boundary assumptions in the manuscript.

Lebl gives a substantive comparator for order/field properties, completeness, bounds, Archimedean density, convergence, monotone limits and the Cauchy criterion. These statements mostly have actual V2 targets. The manuscript's Cauchy quotient route need not reproduce Lebl's limsup/liminf proof of the criterion; both implications are already named in V2. Subsequence definitions/limits and harmonic-series examples have verified existing V4 locations, so they are not classified as missing V2 work.

Lebl Theorem1.2.1, printed29, states real-field existence and uniqueness up to isomorphism but **explicitly does not prove the construction**. Its Remark2.4.6 also omits completion details. It is therefore evidence for target statements, not an external certificate for the manuscript's quotient construction. The now-readable comparator improves the prior reference boundary; Tao's construction chapters and LR body correspondence still remain unknown.

## One concentrated supplement recommendation

The seven existing routes remain. Four named additions are proposed for the one expansion-consensus reply:

1. **GAP-V2-01: reading/assumption synthesis, retained.** Join the existing A/S/R/Z/EC interfaces and the V1/V4 handoffs. No new foundation or global choice policy.
2. **GAP-V2-02: residue-ring bridge, strengthened.** Retain the fixed-positive-modulus normalization/effective quotient, descended ring operations, modulus1/zero-ring and excluded-modulus0 cases. Add binary repeated squaring with an actual halving stopping bound and correctness invariant. Existing binary reconstruction/power/congruence laws are tools, not an already written combined algorithm. One worked example must avoid assuming Euler exponent reduction unless that separately unselected theorem is introduced.
3. **GAP-V2-03: finite prime factorization, now recommended core.** This revises r1's blanket optional treatment in light of the requested common-textbook comparison. Add prime/composite definitions, the prime-divisor consequence of existing coprime cancellation, and existence/uniqueness of a finite prime product. State the0/1, positivity and nontriviality boundaries. Supply represented finite data/coding and a termination/witness invariant using the available recursion/search/fold interfaces; do not assume an object of all finite words or prove an ordinary point statement and advertise it as an unrestricted arrow theorem. Place it after the coprime-cancellation interface so gcd computation is not made circularly dependent on prime factorization. Include a worked factorization and one full-answer uniqueness/boundary problem. The old optional rows remain identifiable; their proposed scope disposition is updated, not deleted.
4. **GAP-V2-04: small supremum calculus.** Add one short lemma or exercise with full solution collecting affine transport of extrema and comparison of separated nonempty sets. Use actual supplied sets/affine images and the existing universal upper/lower-bound tests; distinguish positive, negative and zero scalar. Relevant Lebl statements are1.2.6–1.2.7, printed32–33. The basic small-error order rule can be recorded here without a new analysis chapter.

These recommendations supplement an already substantial manuscript; they do not justify restarting it. They are proposed, not declared agreed. Optional/unselected material remains visible in the table: totient, multiplicative order, Euler/Wilson, full unit-group counting, cryptography, generic monoid/rig completion, all Sage demonstrations and arbitrary decimal/checksum variations. A textbook's containing these topics does not by itself make them obligations. Complex numbers remain outside this V2 proposal, with no invented later destination.

## A real assumption boundary, not another gate

Lebl Proposition2.1.13, printed56, asserts monotone sequences **inside an arbitrary nonempty bounded set** approaching its extrema, and leaves the proof as an exercise. The current V2 instead explicitly gives one near-supremum member for each tolerance while warning that this does not itself supply a simultaneous sequence of members.

Keep that distinction. A proof selecting a member for every accuracy must justify the family formation, not merely repeat tolerance-wise existence. We do not adopt an extra choice principle, assert a new independence theorem here, or launch another realization task. The stronger sequence-of-members claim is not selected unconditionally; it can be compared under an actually supplied selection family if later required. This does not close or add to the six existing gates.

Lebl's extended-real convention also differs from the current real-valued one: it assigns infinite extrema to empty or unbounded sets, whereas V2 deliberately has no infinite values. Preserve the current convention and label this a scope difference, not a contradiction.

## Receiver action

Dot should send this **same consolidated boundary package** to the correct active expansion receiving line, together with `VOLUME2-BOUNDARY-HANDOFF-r1.md`. Request one consolidated acceptance/objection covering the seven routes, four supplement specifications and the named exclusions. At most one return remains the contract; no consensus is presumed by this report. Do not restart a stopped or length-exhausted author conversation.

No manuscript or Study changes, new PDF, source proof rereview, GitHub operation or cloud deletion occurred. The six global gates remain OPEN, LR body and unavailable textbook details remain UNKNOWN, and no no-omission or whole-volume certificate is claimed.

## Same-proposal semantic consolidation (after durable version3)

Read MERGED-CONCEPT-BOUNDARY.md or its editable CSV/JSON for the deduplicated execution view. It covers every existing reference-first row without discarding provenance; the original107 added textbook rows and418 manuscript IDs/order are preserved. Closely synonymous definitions/results/example objectives are grouped while hypotheses, roles and source verdicts stay visible. FTA existence and uniqueness remain separate proof obligations; arbitrary member selection is not merged with tolerance-wise approximation. Unknown-body topics remain unmerged as content-UNKNOWN, not confirmed equivalent statements.

Read LEGAL-ACCESS-OUTCOME.md and access-attempts-consolidated.json for the actual legal retrieval attempts and concrete NTHU/ebook barriers. Nine necessary Tao author-sample interfaces were located at the retained unversioned DVI, separately from the still-UNKNOWN fourth edition. This does not add a new core demand, change the four concentrated recommendations, or upgrade any proof or exact-answer field.

Expansion handoff: confirm the seven routes and GAP-V2-01–04 together; use the merged checklist to write original explanations and necessary examples. Cite the fixed version and item at each borrowing of a mathematical statement; do not reproduce the textbook's prose or imply identical foundations. Existing proofs/answers and genuinely later V4 locations are reused, not reassigned. No new manuscript, policy adoption or third boundary review has occurred.
