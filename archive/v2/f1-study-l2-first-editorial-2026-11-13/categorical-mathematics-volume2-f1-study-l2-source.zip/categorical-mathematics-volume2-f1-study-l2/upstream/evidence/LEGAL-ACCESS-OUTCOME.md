# V2 legal-access outcome and coordination

This is the access supplement to the existing boundary, not another boundary round. Sources are used only at the actual readable version and item scope. Search failure is not evidence that a book is absent from the user's holdings or NTHU.

| Source | Actual result | Use in this boundary |
|---|---|---|
| Stein, author PDF23 January2017 | Fixed complete original already obtained | Existing49 named statement/representative-example rows reused, with exact locators and hash |
| Lebl, Basic Analysis I6.3 | Fixed complete original already obtained | Existing44 definition/statement/example rows reused; construction of the reals is not proved by this source |
| Hammack / Riehl | Fixed legal author bodies and historical reading evidence | Existing28 exact-reference rows reused; no proof/answer status upgrade |
| Tao, Analysis I fourth edition | Publisher contents; designated body still UNKNOWN | Four original candidates retain UNKNOWN |
| Tao, author DVI sample | Actually obtained and nine necessary interfaces read | Supplementary version-qualified alias evidence only; its edition and fourth-edition identity are UNKNOWN |
| Burton seventh edition | Publisher contents/product pages; no readable body | Eight original candidates remain UNKNOWN |
| Abbott second edition | Publisher subscription preview, institutional-login requirement | Two original candidates remain UNKNOWN |
| Lawvere–Rosebrugh | No authorized body resolved through new searches; prior obstacles inherited | Seven original strand rows remain UNKNOWN |

The NTHU homepage led to genuine OneSearch catalogue and advanced-search URLs; both returned HTTP403. Bounded indexed title searches returned no record. These observations do not establish holdings or absence. NTHU's own guide describes EZproxy login and, for some licences, a campus/VPN route. The next useful coordination is a user-controlled title/ISBN entitlement check through NTHU or an existing authorized electronic purchase. It is not a request to scan a paper book. We neither requested credentials nor inferred entitlement from student status.

Library and connected Drive searches did not resolve the designated titles. Unrelated files were not read, copied, or made part of the evidence capsule. No purchase was made and no access restriction was bypassed.

Tao's public page links a DVI sample. It is retained at SHA25671895800d616b6846293b63d6f89d176bdaf2d630e17cda2a25616a8186e151a. The sample TOC uses different page starts from the requested fourth edition, so its statements are cited as author-sample statements, never as fourth-edition theorems. The nine locators are recoverable from the original DVI and the named extractor. Mathematical glyph loss in plain extraction and unavailable local TeX font metrics are recorded; no unverified sample PDF is supplied.

No access issue caused a guessed theorem list or a claim of no omissions. The existing readable mature books carry the actual item comparison; inaccessible designated bodies remain visible UNKNOWN candidates in the same live table.
