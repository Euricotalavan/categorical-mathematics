#!/usr/bin/env python3
"""Reapply a guarded V2 expansion overlay after author-volumes/generate.py.

Run from any directory: python source/tools/reapply-v2-expansion.py
This only edits volume-2.tex. Existing canonical math and V0/V1/V3/V4 are untouched.
"""
from pathlib import Path
import hashlib, json
R=Path(__file__).resolve().parents[1]
tex=R/'volume-2.tex'; contents=tex.read_text(encoding='utf-8')
source_sha=hashlib.sha256(contents.encode()).hexdigest()
contents=contents.replace('\\input{author-volumes/reading-guide}', '\\input{author-volumes/expansion-v2/reading-guide-v2}')
chapters=contents.splitlines(keepends=True)
if len([x for x in chapters if x.startswith(r'\chapter{')])!=23:
 raise SystemExit('Unexpected volume-2 chapter count; no edit')
for n in range(29,52):
 anchor=f'\\input{{author-volumes/expansion-v2/chapter-{n:02d}-route}}\n'
 if anchor in chapters:continue
 pos=[i for i,x in enumerate(chapters) if x.startswith(r'\chapter{')][n-29]+1
 chapters.insert(pos,anchor)
contents=''.join(chapters)
for base, insert in [
 ('author-volumes/expansion-v2/reading-guide-v2','route-and-assumptions'),
 ('author-volumes/views/v2/sections/108-coprime-cancellation','prime-factorization'),
 ('author-volumes/views/v2/sections/110-integer-remainders','residue-ring-and-squaring'),
 ('author-volumes/views/v2/sections/134-supremum-by-bisection','supremum-calculus'),
 ('author-volumes/views/v2/sections/136-monotone-completeness','closing-map'),
]:
 after=f'\\input{{{base}}}'
 extra=f'\\input{{author-volumes/expansion-v2/{insert}}}'
 if contents.count(after)!=1:raise SystemExit('Missing/duplicate anchor: '+base)
 if extra not in contents:contents=contents.replace(after,after+'\n'+extra)
contents=contents.replace('12 November 2026\\par Draft; independent review of additions pending.\\par',
'13 November 2026\\par Expansion rough draft; mathematical review pending.\\par')
if contents.count('\\input{author-volumes/expansion-v2/')!=29:raise SystemExit('Overlay insertion count mismatch')
for f in (R/'author-volumes/expansion-v2').glob('*.tex'):
 if not f.is_file():raise SystemExit('Missing overlay: '+str(f))
tex.write_text(contents,encoding='utf-8')
print(json.dumps({'original_sha256':source_sha,'result_sha256':hashlib.sha256(tex.read_bytes()).hexdigest(),
                  'insertions':29,'other_volumes_edited':False}))
