# Build the content source

Compile source/volume-2.tex from source/ with XeLaTeX. The provided sibling V0/V1 .aux files support cross-volume references; sibling PDFs may be needed for clickable external links. The147-page author checking PDF belongs to this source, not to the earlier144-page rough source and not to a final Study layout.

Use the delivered driver directly. Do not run the shared all-volume generator during editorial integration: it recreates base drivers and would need the retained expansion overlay and the guarded F1 patch reapplied. No common generator, layout, theme or other-volume source was edited here. A restored expansion source can instead apply refinement/EXACT-CHANGES.patch with the before-hash guards in SOURCE-VERSION-MAP.json.

In this runner, the installed TeX tree had no working filename database or cached format. The local-only build used TEXMF={/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}, generated xelatex.fmt from the installed tex/latex/tex-ini-files/xelatex.ini into a separate build directory, then supplied that directory in TEXFORMATS. These are environment repairs, not book-source changes. A normal configured XeLaTeX installation needs no such repair. Only V2 was compiled; no prerequisite PDF was rebuilt.
