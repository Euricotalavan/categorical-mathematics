"""Apply the exact F1 diff only to a matching isolated expansion source copy."""
from pathlib import Path
import json,hashlib,subprocess,sys
E=Path(__file__).resolve().parent
T=Path(sys.argv[1]).resolve()
rows=json.loads((E/'SOURCE-VERSION-MAP.json').read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()if p.exists()else None
states=[h(T/x['path'])for x in rows]
if states==[x['after_sha256']for x in rows]:print('Already at exact F1; no write');raise SystemExit(0)
if states!=[x['before_sha256']for x in rows]:raise SystemExit('Before-hash mismatch; compare/merge separately. No files changed.')
subprocess.run(['patch','--batch','--forward','-p1','-d',str(T),'-i',str(E/'EXACT-CHANGES.patch')],check=True)
assert [h(T/x['path'])for x in rows]==[x['after_sha256']for x in rows]
print('Exact F1 source restored; all after hashes match.')
