"""Integrity/scope verification, not an automatic mathematical proof checker."""
from pathlib import Path
import hashlib,json,re,csv
R=Path(__file__).resolve().parents[1]
def J(n):return json.loads((R/n).read_text())
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=J('MANIFEST-REFINEMENT.json')
for x in manifest:
 p=R/x['path'];assert p.is_file()and p.stat().st_size==x['bytes']and H(p)==x['sha256'],x['path']
index=J('evidence/v2-source-index.json');assert len(index)==60
for x in index:assert H(R/'source'/x['selected_source'])==x['canonical_sha256']
old=J('evidence/existing-v2-rows.json');live=J('evidence/v2-live-boundary-view.json');assert len(old)==len(live)==418
assert [x['row_id']for x in old]==[x['row_id']for x in live]
refs=J('evidence/reference-to-manuscript.json');assert len(refs)==142 and len(refs[-107:])==107
assert len({x['row_id']for x in refs+live})==560
registry=J('refinement/inherited/row-id-registry.json');assert len(registry)==1882
assert all(x['row_id']in registry for x in old)
for w in J('refinement/CHANGED-LABEL-WINDOWS.json'):
 p=R/w['canonical'];assert H(p)==w['canonical_sha256'];text=''.join(p.read_text().splitlines(True)[w['line_start']-1:w['line_end']]);assert hashlib.sha256(text.encode()).hexdigest()==w['text_sha256']
for x in J('refinement/SOURCE-VERSION-MAP.json'):
 assert H(R/x['path'])==x['after_sha256']
 b=R/'refinement/before'/x['path'];assert H(b)==x['before_sha256']
labels=[]
for p in (R/'source/author-volumes/expansion-v2').glob('*.tex'):labels+=re.findall(r'\\label\{([^}]+)\}',p.read_text())
assert len(labels)==len(set(labels))==20
assert len(J('refinement/CURRENT-V2-INPUTS.json'))==89
assert len(J('refinement/READING-SCOPE.json')['inherited_units'])==60
print(json.dumps({'manifest':len(manifest),'canonical_units':60,'old_IDs':418,'textbook_additions':107,'registry':1882,'expansion_labels':20,'direct_math_and_route_inputs':89,'source_changes':len(J('refinement/SOURCE-VERSION-MAP.json')),'status':'PASS_INTEGRITY_NOT_FOUNDATION_OR_LITERATURE_COMPLETENESS'}))
