"""Finite numerical regression of exposed formulas, not a proof of arrow equations."""
import json,math,random
from pathlib import Path
out={}
def prime(n):return n>=2 and all(n%d for d in range(2,math.isqrt(n)+1))
for n in range(1,151):
 r,C,P,U=n,0,1,1;B=n+1;digits=[]
 for i in range(n):
  a=next((d for d in range(2,r+1)if r%d==0),1)
  r,C,P,U=r//a,C+a*U,P*a,B*U
  digits.append(a)
  assert P*r==n and 0<=C<U and U==B**(i+1)
 assert r==1 and P==n
 assert all(a==1 or prime(a)for a in digits)
 assert all((C//B**j)%B==digits[j]for j in range(n))
 active=[x for x in digits if x!=1]
 other=active[:];random.Random(n).shuffle(other)
 used=[False]*len(other);h=[];w=[None]*len(other)
 for i,a in enumerate(active):
  j=next(j for j,b in enumerate(other)if not used[j]and b==a)
  used[j]=True;h.append(j);w[j]=i
 assert all(used)and all(w[h[i]]==i for i in range(len(h)))
 assert all(h[w[j]]==j for j in range(len(w)))
out['factor_code_and_matching']={'ordinary_inputs':'1..150','assertions':'product, place value, digit recovery, padding/primality, finite inverse matching','result':'PASS'}
for d in range(1,10):
 for a in range(16):
  for n in range(51):
   r,b,e=1%d,a%d,n
   for k in range(n+1):
    assert e==n//(2**k)
    assert (r*pow(b,e,d))%d==pow(a,n,d)
    if e==0:break
    t,bit=divmod(e,2)
    if bit:r=r*b%d
    b=b*b%d;e=t
   assert e==0 and r==pow(a,n,d)
out['residue_power']={'moduli':'1..9','bases':'0..15','exponents':'0..50','oracle':'Python integer modular pow','result':'PASS'}
out['scope']='Finite model regression only; does not replace the supplied-data/source-stable proofs or close any global gate.'
Path(__file__).with_name('FINITE-SANITY.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
