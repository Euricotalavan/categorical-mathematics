from pathlib import Path
import json,hashlib,difflib,zipfile,shutil
P=Path(__file__).resolve().parent;W=P/'work';F=P/'frozen-input'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
parents=W/'refinement/parents';parents.mkdir(exist_ok=True)
if (W/'MANIFEST-EXPANSION.json').exists():shutil.move(str(W/'MANIFEST-EXPANSION.json'),str(parents/'MANIFEST-EXPANSION-historical-input.json'))
changes=[];diffs=[]
for p in sorted((W/'source').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(W);q=F/rel
 if not q.exists() or p.read_bytes()!=q.read_bytes():
  old=q.read_text() if q.exists() else '';new=p.read_text()
  if q.exists():
   b=W/'refinement/before'/rel;b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,b)
  changes.append({'path':str(rel),'before_sha256':h(q)if q.exists()else None,'after_sha256':h(p),'before_lines':len(old.splitlines()),'after_lines':len(new.splitlines())})
  diffs.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='before/'+str(rel),tofile='after/'+str(rel)))
(W/'refinement/EXACT-CHANGES.patch').write_text(''.join(diffs))
(W/'refinement/SOURCE-VERSION-MAP.json').write_text(json.dumps(changes,indent=2)+'\n')
manifest=[{'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':h(p)}for p in sorted(W.rglob('*'))if p.is_file()and p!=W/'MANIFEST-REFINEMENT.json']
(W/'MANIFEST-REFINEMENT.json').write_text(json.dumps(manifest,indent=2)+'\n')
z=P/'categorical-mathematics-volume2-content-F1-source.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as a:
 for p in sorted(W.rglob('*')):
  if p.is_file():a.write(p,p.relative_to(W))
with zipfile.ZipFile(z)as a:assert a.testzip()is None
rec={'path':str(z),'bytes':z.stat().st_size,'sha256':h(z),'manifest_records':len(manifest),'source_changes':len(changes)}
(P/'CURRENT-LOCAL-PACKAGE.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec))
