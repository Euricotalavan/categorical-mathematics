from pathlib import Path
import json,hashlib,re,csv,shutil
P=Path(__file__).resolve().parents[1];W=P/'work';S=W/'source';E=W/'refinement'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
I=E/'inherited';I.mkdir(exist_ok=True)
for n in ['row-id-registry.json','current-F1-remaining-gates.json','gate-closure-register.json','assumption-dependency-manifest.json']:
 shutil.copy2(P.parent/'volume2-boundary/deliverable/inherited'/n,I/n)
index=json.loads((W/'evidence/v2-source-index.json').read_text());inputs=[];labelsets=[]
for x in index:
 c=S/x['selected_source'];v=S/'author-volumes/views/v2'/x['logical'];old=P/'frozen-input/source'/x['selected_source']
 assert h(c)==h(old)==x['canonical_sha256']
 rawlab=re.findall(r'\\label\{([^}]+)\}',c.read_text());assert rawlab==re.findall(r'\\label\{([^}]+)\}',v.read_text())
 labelsets+=rawlab
 inputs.append({'role':'inherited_selected_canonical_and_once_converted_view','chapter':x['chapter'],'canonical':str(c.relative_to(W)),'canonical_sha256':h(c),'view':str(v.relative_to(W)),'view_sha256':h(v),'lines':[1,len(c.read_text().splitlines())]})
oldlab=[];newlab=[]
for p in sorted((S/'author-volumes/expansion-v2').glob('*.tex')):
 old=P/'frozen-input/source'/p.relative_to(S)
 a=re.findall(r'\\label\{([^}]+)\}',old.read_text());b=re.findall(r'\\label\{([^}]+)\}',p.read_text());assert a==b
 oldlab+=a;newlab+=b
 inputs.append({'role':'V2_direct_author_overlay_not_a_reconverted_view','canonical':str(p.relative_to(W)),'before_sha256':h(old),'canonical_sha256':h(p),'lines':[1,len(p.read_text().splitlines())],'labels':[{ 'label':x,'line':next(i for i,l in enumerate(p.read_text().splitlines(),1)if '\\label{'+x+'}'in l)}for x in b]})
assert len(newlab)==len(set(newlab))==20 and not(set(newlab)&set(labelsets))
(E/'CURRENT-V2-INPUTS.json').write_text(json.dumps(inputs,indent=2)+'\n')
with(E/'READING-SCOPE.csv').open('w',encoding='utf-8-sig',newline='')as f:
 fields=['canonical','canonical_sha256','chapter','lines','extent','check_focus','verdict'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for x in json.loads((E/'READING-SCOPE.json').read_text())['inherited_units']:w.writerow(x)
# Exactly bounded modified/new-source locator evidence for the editor.
windows=[]
for p in sorted((S/'author-volumes/expansion-v2').glob('*.tex')):
 text=p.read_text();old=P/'frozen-input/source'/p.relative_to(S)
 if h(p)==h(old):continue
 for m in re.finditer(r'\\label\{([^}]+)\}',text):
  start=text.count('\n',0,m.start())+1
  nxt=re.search(r'\\(?:label\{|section\{|paragraph\{)',text[m.end():]);end=text.count('\n',0,m.end()+(nxt.start() if nxt else len(text)-m.end()))+1
  lines=text.splitlines(True);end=min(end,len(lines));body=''.join(lines[max(0,start-3):end])
  windows.append({'canonical':str(p.relative_to(W)),'canonical_sha256':h(p),'label':m.group(1),'line_start':max(1,start-2),'line_end':end,'text_sha256':hashlib.sha256(body.encode()).hexdigest(),'purpose':'Local precise locator; full proof/source remains in the editable file, not implied by this window alone.'})
(E/'CHANGED-LABEL-WINDOWS.json').write_text(json.dumps(windows,indent=2)+'\n')
log=(P/'build/volume-2.log').read_text(errors='replace')
assert not re.search(r'Overfull|undefined references|Reference .* undefined|multiply defined|Missing character|^! ',log,re.M)
import fitz
pdf=P/'build/volume-2.pdf';d=fitz.open(pdf);assert len(d)==147
paper=(250,247,239);pix=d[87].get_pixmap(matrix=fitz.Matrix(1,1),alpha=False)
actual=tuple(pix.pixel(5,5));assert all(abs(a-b)<=1 for a,b in zip(actual,paper))
qa={'engine':'XeLaTeX','pages':len(d),'PDF_sha256':h(pdf),'PDF_bytes':pdf.stat().st_size,'source_driver_sha256':h(S/'volume-2.tex'),'last_log_sha256':h(P/'build/volume-2.log'),'fatal_errors':0,'unresolved_references':0,'multiply_defined_labels':0,'missing_characters':0,'overfull_boxes':0,'warm_background_requested_RGB':paper,'warm_background_raster_RGB':actual,'text_color':'#20262C inherited','theme_changed':False,'visually_inspected_contact_physical_pages':[85,86,87,88,89,90,94,95,96,97,98,140,141,142,143],'detail_pages':[87,88,96,97,142,143],'visual_result':'No clipped math, missing glyphs, overlapping text or unreadable formulas observed in these windows. Long84/180 state chains displayed to remove the reported overflow. Full editorial147-page QA is not claimed.','build_environment':'Initial system TeX filename databases/formats were absent; a local format was generated using installed files and a scoped TEXMF path. No project theme/config/generator was changed.','proof_scope':'Compilation/numerical regression supplement the actual source proof reading; neither is a proof verifier.'}
(E/'BUILD-AND-VISUAL-QA.json').write_text(json.dumps(qa,indent=2)+'\n')
for n in ['volume-2.log','volume-2.aux','volume-2.toc']:
 shutil.copy2(P/'build'/n,E/('F1-'+n))
# Reproduction instructions: the delivered source already has all input overlays.
(E/'BUILD-REPRODUCTION.md').write_text('''# Build the content source

Compile source/volume-2.tex from source/ with XeLaTeX. The provided sibling V0/V1 .aux files support cross-volume references; sibling PDFs may be needed for clickable external links. The147-page author checking PDF belongs to this source, not to the earlier144-page rough source and not to a final Study layout.

Use the delivered driver directly. Do not run the shared all-volume generator during editorial integration: it recreates base drivers and would need the retained expansion overlay and the guarded F1 patch reapplied. No common generator, layout, theme or other-volume source was edited here. A restored expansion source can instead apply refinement/EXACT-CHANGES.patch with the before-hash guards in SOURCE-VERSION-MAP.json.

In this runner, the installed TeX tree had no working filename database or cached format. The local-only build used TEXMF={/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}, generated xelatex.fmt from the installed tex/latex/tex-ini-files/xelatex.ini into a separate build directory, then supplied that directory in TEXFORMATS. These are environment repairs, not book-source changes. A normal configured XeLaTeX installation needs no such repair. Only V2 was compiled; no prerequisite PDF was rebuilt.
''')
print(json.dumps({'inputs':len(inputs),'inherited_labels_preserved':len(labelsets),'new_labels_preserved':len(newlab),'changed_label_windows':len(windows),'PDF':qa['PDF_sha256'],'pages':147}))
