# One-off evidence construction scripts

These exact execution scripts record how the capsule was produced in the original volume2-refinement/ workspace, where frozen-input/, work/ and build/ were siblings. They are provenance, not commands to run inside a recovered capsule. The fixed input archive and its hash are in INTAKE.json. A recovered capsule already contains the complete source and all emitted evidence; use verify-F1.py for integrity and apply-F1-patch.py only on a separate matching expansion source root. A configured XeLaTeX installation builds source/volume-2.tex directly.
