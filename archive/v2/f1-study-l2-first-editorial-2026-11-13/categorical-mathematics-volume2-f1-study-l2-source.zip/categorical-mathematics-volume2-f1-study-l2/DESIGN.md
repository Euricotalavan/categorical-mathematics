# Accepted Study presentation — V2 implementation

The accepted v0.2-r1 Study direction is retained: A4,147mm text width, margins left27/right36/top23/bottom23mm,11.5TeXpt body with15.8TeXpt leading,4pt paragraph spacing and7pt standard display spacing. TeX Gyre Schola text and Schola Math, with Heros headings, use the bundled exact font files. Proof heading `pf.` and problem/inline Solution conventions are retained. No font shrinking, tracking expansion or webpage hero/card/CTA decoration was introduced.

Warm paper `#F5F1E7`, body `#242A28`, secondary `#454D49`, accent `#2D5660`. Recomputed sRGB luminance contrast: body 12.95796601:1; secondary 7.72296107:1. Contrast is one measurable reading check, not medical eye protection or a guarantee of comfort for everyone on every screen. White print capability is retained and tested; no redundant extra print deliverable is required.

Fresh actual181-page line sample: 4,420 lines (NFKC,>=30characters,>=55%from near11.5pt nonmath Schola spans), character count median76,90th percentile80, maximum89. This sample includes mixed math/prose and is not a proof that every line has a fixed length. Actual baseline mode is15.741PDFpt, corresponding to15.8TeXpt. Definitions and dense calculations remain somewhat denser than prose; full-page review, not those statistics alone, assessed the result.

Long reconstructions and operation formulas were placed in readable rows; core states retained every coordinate. Two long proofs have four descriptive stages each. The diagram at physical149 now has adequate horizontal/vertical separation without changing any node,arrow or label. The final short question at physical108 remains whole. Chapter openings retain intentional end-of-chapter space rather than stretching short complete exercises or deleting content; several short chapter tails therefore have visible white space.

Babel English is explicit, with left/right minimum2/3 and existing penalties150/100. No exception list was introduced. Two flagged explicit compounds (`change-of-state`,`zero-to-one`) were visually checked and are legitimate breaks, not single-letter automatic word fragments.

The historical template design/English rules,source acknowledgments and font licenses are preserved under design/ and licenses/. Their third-party website analysis is not an official brand specification; only its method of explicit tokens,hierarchy,consistency and QA is translated into book/LaTeX decisions. Website UI components were not transplanted. Historical Book/v0.1 measurements remain identified as history, not current V2 metrics.
