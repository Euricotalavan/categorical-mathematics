"""Cross-check a few exact calculations used to review the volume."""

import sympy as s


def sinc(x):
    return s.S.One if x == 0 else s.sin(s.pi * x) / (s.pi * x)


def deletion_matrix(r, missing):
    return s.Matrix(
        [[s.simplify(r * sinc(r * (j - k))) for k in missing] for j in missing]
    )


def check_finite_deletion():
    r = s.Rational(1, 2)
    adjacent = deletion_matrix(r, [0, 1])
    separated = deletion_matrix(r, [0, 2])
    assert adjacent == s.Matrix([[r, 1 / s.pi], [1 / s.pi, r]])
    assert separated == r * s.eye(2)
    assert (s.eye(2) - adjacent).det() == s.Rational(1, 4) - s.pi**-2
    assert deletion_matrix(s.S.One, [0, 1, 4]) == s.eye(3)


def check_linear_spline_element():
    a, b, h = s.symbols("a b h", real=True)
    t = s.symbols("t", real=True)
    segment = (1 - t) * a + t * b
    mass = s.integrate(segment**2, (t, 0, 1)) * h
    stiffness = s.diff(segment, t)**2 / h
    assert s.expand(mass - h * (a**2 + a * b + b**2) / 3) == 0
    assert s.factor(12 * mass / h**2 - stiffness) == 3 * (a + b)**2 / h


def check_small_observation_matrix():
    observation = s.Matrix([[1, 0, 1], [0, 1, 1]])
    assert observation.nullspace() == [s.Matrix([-1, -1, 1])]
    assert observation * s.Matrix([0, 0, 1]) == observation * s.Matrix([1, 1, 0])
    for omitted in range(3):
        support = [j for j in range(3) if j != omitted]
        assert abs(observation[:, support].det()) == 1


if __name__ == "__main__":
    check_finite_deletion()
    check_linear_spline_element()
    check_small_observation_matrix()
    print("Exact finite-deletion, spline element, and sparse-observation checks passed.")
