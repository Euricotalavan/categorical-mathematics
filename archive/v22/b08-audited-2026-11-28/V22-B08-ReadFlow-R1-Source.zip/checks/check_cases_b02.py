"""Exact arithmetic evidence for B-02 case design; no manuscript acceptance."""
import sympy as s

pi = s.pi
rt2 = s.sqrt(2)


def sinc(x):
    return s.S.One if x == 0 else s.sin(pi*x)/(pi*x)


def check_periodic():
    A = s.Matrix([[1, rt2, 0], [1, 0, rt2],
                  [1, -rt2, 0], [1, 0, -rt2]])
    c = s.Matrix([1, rt2, -1/rt2])
    noise = s.Matrix([1, 0, -1, 0])/50
    v = s.Matrix([1, -1, 1, -1])
    y = A*c+v/10+s.ones(4, 1)/20+noise
    assert y == s.Matrix([317, -5, -87, 195])/100
    assert A.T*A == 4*s.eye(3)
    assert A.rank() == 3
    ch = A.T*y/4
    assert ch == s.Matrix([s.Rational(21, 20), 101*rt2/100, -1/rt2])
    assert y-A*ch == v/10
    assert A.T*(y-A*ch) == s.zeros(3, 1)
    assert (ch-c).dot(ch-c) == s.Rational(27, 10000)
    err2 = s.Rational(1, 800)+s.Rational(1, 200)+(ch-c).dot(ch-c)
    assert err2 == s.Rational(179, 20000)


def check_erasure():
    Q = lambda j, k: sinc(s.Rational(j-k, 2))/2
    U, W, J = [0, 2], [-1, 1, 3], [-1, 0, 1, 2, 3]
    SU = s.Matrix([[Q(j, k) for k in U] for j in U])
    assert SU == s.eye(2)/2
    vals = s.Matrix([sinc(s.Rational(j, 2)) for j in W])
    KUW = s.Matrix([[Q(j, k) for k in W] for j in U])
    bw = s.simplify(KUW*vals)
    assert bw == s.Matrix([s.Rational(38, 9)/pi**2, s.Rational(2, 3)/pi**2])
    noisy = vals+s.Matrix([0, 1/(100*pi), 0])
    uh = s.simplify(2*KUW*noisy)
    assert uh == s.Matrix([s.Rational(3809, 450)/pi**2,
                           s.Rational(203, 150)/pi**2])
    a = s.Matrix([noisy[0], uh[0], noisy[1], uh[1], noisy[2]])
    sj = s.Matrix([sinc(s.Rational(j, 2)) for j in J])
    G = s.Matrix([[Q(j, k) for k in J] for j in J])
    actual2 = s.factor(2-2*(sj.T*a)[0]+(a.T*G*a)[0])
    target = (1080000*pi**4-15992373*pi**2+59517448)/(540000*pi**4)
    assert s.simplify(actual2-target) == 0
    d2 = 1-s.Rational(76, 9)/pi**2+1/(10000*pi**2)
    # The exact inequality follows from projection contraction in the memo.
    assert s.N(2*d2-actual2) > 0
    assert s.N(d2-(uh-s.Matrix([1, 0])).dot(uh-s.Matrix([1, 0]))) > 0
    return actual2


def check_sparse():
    A = s.Matrix([[1, 0, -1], [0, 1, -1]])
    assert A.nullspace() == [s.ones(3, 1)]
    assert (A.T*A).eigenvals() == {0: 1, 1: 1, 3: 1}
    truth = s.Matrix([0, 0, 1])
    delta = s.symbols('delta', positive=True)
    y = s.Matrix([delta-1, delta-1])
    sparse = s.Matrix([0, 0, 1-2*delta])
    dense = s.Matrix([-(1-2*delta)/3, -(1-2*delta)/3, 2*(1-2*delta)/3])
    assert A*sparse-y == s.Matrix([delta, delta])
    assert A*dense-y == s.Matrix([delta, delta])
    assert dense.dot(s.ones(3, 1)) == 0
    d100 = dense.subs(delta, s.Rational(1, 100))
    assert (d100-truth).dot(d100-truth) == s.Rational(417, 1250)
    assert A.pinv()*s.Matrix([-1, -1]) == s.Matrix([-s.Rational(1, 3),
                                                   -s.Rational(1, 3),
                                                   s.Rational(2, 3)])
    bad = s.Matrix([[1, 0, 3], [0, 1, 1]])
    assert bad*s.Matrix([0, -s.Rational(1, 3), s.Rational(1, 3)]) == s.Matrix([1, 0])


if __name__ == '__main__':
    check_periodic()
    error2 = check_erasure()
    check_sparse()
    print('PASS: exact periodic, finite-window/erasure, and sparse/dense checks.')
    print('Projected-sinc actual L2 error:', s.N(s.sqrt(error2), 12))
