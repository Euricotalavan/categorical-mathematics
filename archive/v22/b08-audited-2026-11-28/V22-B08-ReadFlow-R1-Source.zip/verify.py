"""Verify the exact delivered source tree and paired PDF."""

from hashlib import sha256
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main():
    manifest = ROOT / "SHA256SUMS"
    names = set()
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        path = ROOT / name
        if name in names or not path.resolve().is_relative_to(ROOT):
            raise ValueError(f"Unsafe or duplicate manifest entry: {name}")
        names.add(name)
        digest = sha256(path.read_bytes()).hexdigest()
        if digest != expected:
            raise SystemExit(f"SHA-256 mismatch: {name}")
    required = {f"chapters/ch{number}.tex" for number in range(282, 291)}
    required.update({"frontmatter.tex", "bibliography.tex", "README.md"})
    missing = required - names
    if missing:
        raise SystemExit(f"Manifest is missing: {', '.join(sorted(missing))}")
    pdfs = sorted(name for name in names if name.endswith("-ReadFlow-R1.pdf"))
    if len(pdfs) != 1:
        raise SystemExit(f"Expected one paired ReadFlow PDF, found {len(pdfs)}")
    print(f"Verified {len(names)} files, including {pdfs[0]}.")


if __name__ == "__main__":
    main()
