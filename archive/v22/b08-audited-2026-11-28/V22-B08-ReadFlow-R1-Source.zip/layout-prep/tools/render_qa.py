#!/usr/bin/env python3
"""Rasterize every page for sequential visual inspection; flag geometry only.

Image generation and text extraction are not visual acceptance.
"""
from pathlib import Path
import argparse, hashlib, json
import fitz
from PIL import Image, ImageDraw

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('pdf',type=Path)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--dpi',type=int,default=120)
a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=True)
doc=fitz.open(a.pdf); rows=[]; thumbs=[]
for i,page in enumerate(doc):
    target=a.output/f'page-{i+1:04d}.png'
    pix=page.get_pixmap(dpi=a.dpi,alpha=False);pix.save(target)
    outside=[];light=[];footer=[]
    for b in page.get_text('dict')['blocks']:
        for line in b.get('lines',[]):
            for s in line['spans']:
                r=fitz.Rect(s['bbox']);txt=s['text']
                if r.x0 < -1 or r.y0 < -1 or r.x1>page.rect.width+1 or r.y1>page.rect.height+1:
                    outside.append({'text':txt,'bbox':s['bbox']})
                if s['color']==0xffffff and txt.strip():light.append(txt)
                if r.y1>page.rect.height-45 and r.y0<page.rect.height-22 and txt.strip():
                    footer.append({'text':txt,'bbox':s['bbox']})
    rows.append({'page':i+1,'png':str(target.resolve()),'png_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'out_of_bounds':outside,'white_text':light,'footer_region_spans':footer,'visual_status':'UNINSPECTED'})
    im=Image.open(target).convert('RGB'); im.thumbnail((315,432)); thumbs.append(im.copy())
for start in range(0,len(thumbs),6):
    canvas=Image.new('RGB',(990,920),'#d5d5d5');draw=ImageDraw.Draw(canvas)
    for j,im in enumerate(thumbs[start:start+6]):
        x=(j%3)*330+7;y=(j//3)*460+22;canvas.paste(im,(x,y));draw.text((x,y-17),f'Physical page {start+j+1}',fill='black')
    canvas.save(a.output/f'contact-{start+1:04d}-{min(start+6,len(thumbs)):04d}.png')
report={'pdf':str(a.pdf.resolve()),'pdf_sha256':hashlib.sha256(a.pdf.read_bytes()).hexdigest(),'pages':len(doc),'dpi':a.dpi,'toc':doc.get_toc(),'rows':rows,'status':'RASTERIZED_NOT_VISUALLY_ACCEPTED'}
(a.output/'render-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'pages':len(doc),'report':str(a.output/'render-report.json'),'status':report['status']}))
