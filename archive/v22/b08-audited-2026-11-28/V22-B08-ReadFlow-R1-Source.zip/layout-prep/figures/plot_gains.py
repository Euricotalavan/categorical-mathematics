"""Regenerate the theoretical one-erasure gain comparison."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


output = Path(__file__).with_name("one-erasure-gains.pdf")
r = np.linspace(0.001, 0.95, 500)
fig, ax = plt.subplots(figsize=(5.1, 2.49), layout="constrained")
ax.plot(r, 1 / (1 - r), color="#1b385d", linewidth=1.8,
        label=r"Right-hand side: $(1-r)^{-1}$")
ax.plot(r, np.sqrt(r / (1 - r)), color="#7d2c23", linewidth=1.8,
        linestyle="--", label=r"Known samples: $\sqrt{r/(1-r)}$")
ax.scatter([0.5, 0.5], [2, 1], marker="o", s=22, color=["#1b385d", "#7d2c23"],
           zorder=3)
ax.set(
    xlabel=r"Normalized bandwidth $r=2BT$",
    ylabel="Error gain",
    xlim=(0, 0.95),
    ylim=(0, 21),
    xticks=[0, 0.25, 0.5, 0.75, 0.95],
    yticks=[0, 5, 10, 15, 20],
)
ax.spines[["right", "top"]].set_visible(False)
ax.grid(visible=True, axis="y", color="#d8dde3", linewidth=0.5)
ax.legend(loc="upper left", frameon=False, fontsize=8.7)
fig.savefig(output, metadata={"CreationDate": None, "ModDate": None})
plt.close(fig)
