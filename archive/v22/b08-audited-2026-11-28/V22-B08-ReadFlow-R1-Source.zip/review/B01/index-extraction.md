# Supplemental machine-assisted source localization

The project copy of math-extractor-v0.4.zip was extracted to a temporary
tool directory and run on approved PDF windows with PyMuPDF 1.26.6.
The invocation was `python extract.py SOURCE -o OUTPUT --pages RANGE
--batch-size 3 --max-calls 0`. PDF page numbers in this record are physical.

| Source | Pages | Candidates | Exit status |
| --- | --- | --- | --- |
| P1 | 35–41 | 3 | 0 |
| P5 | 1–8 | 17 | 0 |
| P6 | 33–39 | 11 | 0 |
| P10 | 1–8 | 18 | 0 |
| P12 | 1–9 | 10 | 0 |

These are machine location candidates. Exact conditions, unnumbered
assertions, proofs, and examples were tracked by the source-reading roles
in the adjacent chapter responsibility files. The candidate pass did not
make any model calls. The included record preserves locators and source
identity through the role tables. Working captures of third-party material
are referenced by URL and version instead of being embedded in distribution
files.
