# V22 B-01 — source responsibility for Chapters 288–290

Version: recovery-b01-v1, 2026-11-28 UTC. Role: source/semantic indexing subtask. Status: **B-01 indexing complete for the selected scope; ready for B-02 dependency/design review. No textbook draft has been written.**

## Receipt and fixed scope

Read `V22-Reference-Review-v1.md` in full, plus the current navigation (`project_sources/21-v2.1.txt`), B single-Work execution (`15-B-Work-v1.txt`), literature workflow (`19-v3.txt`), and the applicable B-01/02 and handoff requirements in `13-A-B-v4.txt`. The parent assigned only Chapters **288–290**, within V22 Chapters 282–290. The preceding V21 endpoint 281 and commit `880969bd1ca5e64e3f0d34fb01d25c54562b94e6` are received from the reference review, **not independently re-audited by this subtask**. Existing volumes, the curriculum/references tables, extractor ZIP, and template are KEEP.

The parent's message reports user approval of the public source set and autonomous B-01–08 with independent agents. This receipt authorizes this indexing work. It does not certify any later stage. Model/mode: inherited execution; the requested actual GPT-6.1 Sol/High setting is **not independently observable or verified** here. No claim of changing model is made.

**Excluded evidence:** Q1/Q2 were not downloaded, transcribed, or used. R1–R4 remain bibliography-only: their unreadable book chapters support no definitions, proof claims, theorem numbering, or completion claims in this index.

## Readable source ledger

Page numbers below are physical author-PDF pages, unless explicitly called printed pages. Readable source windows were actually read, including surrounding assumptions and unnumbered mathematical assertions. Text extraction aids location only. This is a selected-scope index, not a claim to have read the whole of every work.

| Code | Fixed readable object and actual read window | Responsibility and boundary |
|---|---|---|
| P4 | Driscoll–Braun, Python online FNC, [§3.3](https://fncbook.com/python/qr/): Definitions 3.3.1–4; Theorems 3.3.1–3; §3.3.3, equations 3.3.7–8, Algorithms 3.3.1–2; Examples 3.3.1–2; Exercise 3.3.4 and 3.3.6. Accessed 2026-11-28. | Thin QR and full-column-rank least squares. P4 is real-matrix presentation; complex use needs conjugate transpose and an explicit separate justification. QR does not create missing rank. |
| P6 | DeVore, *Nonlinear Approximation*, author PDF, §2 printed pp.56–60 (physical pp.6–10), especially (2.1)–(2.3), (2.18)–(2.19); §5 printed pp.95–96 (physical pp.45–46), (5.1)–(5.2), Theorem 4. | Best-term versus fixed-order approximation. Finite-vector hard thresholding and tail identities are the selected entrance; Lorentz-space interpolation theorem is read for context and excluded from the selected Chapter 289 proof burden. |
| P7 | Osgood, EE261 Fall 2007; §§5.6–5.8 printed pp.225–236 (physical pp.231–242), with §5.7 orthogonality and §5.8 finite periodic sampling, example cos(2πt). | Distinguish infinite real-line sampling from finite-dimensional trigonometric-polynomial recovery. Use a finite DFT/orthogonality derivation in Chapter 290, avoiding unjustified regrouping of infinite sinc sums. |
| P10 | Ferreira, *The Stability of a Procedure for the Recovery of Lost Samples in Band-Limited Signals*, author PDF, physical pp.1–8: §§I–II, (1)–(2), Figs.1–6, §III integral (3), Theorems 1–6 and their arguments, §IV iteration (5), §V limitations. | Finite erasures in an otherwise known two-sided oversampling grid; strict spectral gap; geometry of erasures; finite-window and noise limitations. The selected theorem burden uses the integral proof, single/two-erasure cases, and rational-spacing diagonal case. General Theorems 4–6 are not imported wholesale. |
| P11 | Foucart, *Flavors of Compressive Sensing*, physical pp.2–3 (§1), pp.16–20 (§5 and §5.1): (16)–(22), NSP equivalence, RNSP, Theorems 4–6 and the proof printed for Theorem 5, Lemma 1. | Definitions and distinctions among sparse identifiability, BP, NSP, robust NSP, tail stability, and measurement robustness. Theorem 4 is stated with a book reference rather than proved there; an original complete proof would be needed if adopted as a proved textbook result. The sharper RIP route of Theorem 5 is not combined with P12's hypothesis. |
| P12 | Candès–Romberg–Tao, arXiv `math/0503066v2`, 2005-12-07, physical pp.1–4 (§§1.1–1.3 and Theorems 1–2), pp.6–9 (§§2.1–2.2, equations (9)–(16)); p.10 introductory numerical discussion read only to distinguish experiments from guarantees. | Selected main fully proved robust theorem route: condition δ_{3s}+3δ_{4s}<2, tube/cone/block decomposition, exact-sparse and near-sparse conclusions. Random measurement probabilities, image experiments, and TV are outside the proof scope. |

P10's author PDF has 8 pages and states journal pp.195–205. These are not assumed to have a one-to-one page mapping. P7 printed/physical mapping was checked from extracted page breaks. P4 is a live online page, frozen locally at access time rather than assigned an invented edition date.

### File identity

All paths here are relative to the shared workspace. Public author PDFs are research inputs, not material to republish in the final source package without a separate license check.

| File | Bytes | SHA-256 |
|---|---:|---|
| `V22-Reference-Review-v1.md` (input) | 16,832 | `def4341349a906942e92b1d954b4bab1c77b45fa3d88a369a6b335b5394dd215` |
| `work-v22/sources/P4-qr.html` | 813,581 | `a0cb3e724627974fc20c8c4ccc2f487977f6227024f3bf688f9f15e691ab460f` |
| `work-v22/sources/P6.pdf` | 1,029,212 | `ad293caf57959566ddaf0cc5fb1df92145c0aa74f2d849a8480caff4cdb0d4f6` |
| `work-v22/sources/P7.pdf` | 31,520,130 | `93579ff2ac4082a38240db3eef7dbd6f3354e58db720ad052692b5b6179c5be1` |
| `work-v22/sources/P10.pdf` | 118,217 | `8b07b2cd8c6ff1091bacdcb320e63ec25f496af566edad913f1169ae6ce958ca` |
| `work-v22/sources/P11.pdf` | 290,583 | `165926195d873b597cf07b46a7c6e9b3a4be1d1da64ac0a0a6db0e51b40665b3` |
| `work-v22/sources/P12.pdf` | 473,886 | `8d58bc40026054dfc5ec3137e338bfab2904f434a1e07cfc822d8bc2a1bcadcf` |

The matching `.txt` files are pdftotext location aids; only the PDFs fix mathematical typography. P10 initially returned a web-tool 403, but direct retrieval of the same public author URL succeeded; no sign-in or restriction was bypassed. Source URLs are exactly those in the approved reference review. P12's first PDF page independently displays the fixed v2 identifier/date.

## Evidence states

- **V = verified source:** the displayed source window and mathematical assumptions were read. This does not mean a not-yet-written textbook item is covered.
- **A = independently audited mathematical route:** the proposed argument was checked here; still requires actual drafting and independent subsequent review.
- **C = candidate:** design/example proposal, not an adopted textbook theorem or finished computation.
- **U = unknown/open:** exact upstream dependency, missing proof, or subsequent verification not completed here.

All responsibility IDs below remain **textbook coverage pending** until B-04 supplies actual formal-body locations. Definition, assertion, proof, and example burdens are separated so source readability cannot be mistaken for coverage.

## Chapter 288 — Incomplete Data

Fixed boundary: real-line L² bandlimited signals and finitely many erased samples from an otherwise known infinite uniform grid; explicit finite-acquisition obstruction and explicitly conditional finite-window approximation. General irregular sampling, infinite erasure sets, stochastic missingness, analytic continuation from a finite interval, and general inverse-problem regularization are excluded.

| ID | Kind and individual responsibility | Evidence / source | Proposed formal-body location |
|---|---|---|---|
| 288-D01 | Define PW_Ω via frequency support and its continuous point-value representative; state chosen transform units. | V P10 p.1; upstream Ch.286 exact reference U. | §288.1 model contract |
| 288-D02 | Define grid spacing T>0, normalized bandwidth r=ΩT/π, sinc(0)=1, strict oversampling 0<r<1. | V P10 p.1; A unit conversion. | §288.1 |
| 288-D03 | Define finite distinct erasure set U={i₁,…,i_q}, unknown vector u, complete known complement Z\U. | V P10 p.1. | §288.1 |
| 288-D04 | Separately define finite acquired index set K, data error η, omitted tail, and window approximation h_K. | V P10 pp.1–2,8; A formal separation. | §288.2 / §288.5 |
| 288-T01 | Derive (I−S)u=h with S_ab=r sinc(r(i_a−i_b)); h uses all known complement samples. | V P10 (1)–(2); A absolute convergence by Cauchy–Schwarz from ℓ² samples and kernel rows. | §288.2 |
| 288-P01 | Prove the coefficient formula from the previously proved sampling projection identity, including all T/r factors. | V P10 (1); upstream Ch.287 exact lemma U. | proof of T01 |
| 288-T02 | For every finite nonempty distinct U and 0<r<1, prove 0<S<I as quadratic forms. | V P10 pp.3–4 (3); A direct proof below. | §288.3 |
| 288-P02 | Establish strictness using a nonzero finite trigonometric polynomial on both passband and complementary open intervals; finite distinct exponents are essential. | A; no assumption that positive S alone implies invertibility. | proof of T02 |
| 288-T03 | Deduce unique erasure recovery, γ=1−λ_max(S)>0, ∥(I−S)⁻¹∥₂=γ⁻¹, κ₂(I−S)=(1−λ_min(S))/γ. | V P10 §§II–III; A spectral consequences. | §288.3 |
| 288-T04 | Perturbation and residual bounds: ∥ũ−u∥₂≤∥h̃−h∥₂/γ and ∥ũ−u∥₂≤∥h−(I−S)ũ∥₂/γ. | A direct spectral estimate. | §288.4 |
| 288-T05 | Fixed-point iteration u^{j+1}=Su^j+h; prove error ≤λ_max(S)^j times initial error; residual certificate. | V P10 §IV (5); A geometric convergence. | §288.4 |
| 288-T06 | Finite arbitrary acquired point values cannot identify every member of infinite-dimensional PW_Ω. | A finite-dimensional-kernel argument below; not an attribution to P10. | §288.2 warning theorem |
| 288-T07 | Finite-window omitted-sum error and noisy-known-data error remain separate. Bound each by explicit kernel operator/tail norms. | V P10 pp.2,8; A Cauchy–Schwarz. No universal numerical tail rate asserted. | §288.5 |
| 288-E01 | One erasure: S=[r], gap=1−r; amplification diverges as r↑1. | A hand-computable specialization. | §288.3 worked example |
| 288-E02 | Two erasures separated by d: eigenvalues r±|r sinc(rd)|; gap 1−r−|r sinc(rd)|. | A explicit 2×2 diagonalization. | §288.4 example |
| 288-E03 | Rational r=p/q and U⊂qZ give S=rI; contrast contiguous erasures and explain position dependence. | V P10 Theorem 1 pp.4–5; A specialization. | §288.5 example |
| 288-E04 | At critical r=1, S=I; a missing sinc coefficient cannot be recovered from the other critical samples. | A direct counterexample. | §288.6 failure case |
| 288-E05 | Compare finite-window recovery of P10's shifted-sinc signal, with noise and truncation separately reported. | V P10 pp.2–3 Figs.1–6; C own reproducible calculation, no numerical result yet claimed. | §288.6 case / handoff to Ch.290 |

### Mathematical audit: the strict gap comes from the model

For c∈C^q set p_c(θ)=Σ_a c_a exp(i i_a θ). Distinct integer exponents give (1/2π)∫_{−π}^{π}|p_c|²=∥c∥₂². The entries of S are (1/2π)∫_{−πr}^{πr}exp(i(i_a−i_b)θ)dθ, with a harmless conjugation convention in the quadratic form. Therefore

`c* S c = (1/2π) ∫[-πr,πr] |p_c(θ)|² dθ`, and

`c* (I−S)c = (1/2π) ∫([-π,π]\[-πr,πr]) |p_c(θ)|² dθ`.

If c≠0, p_c cannot vanish throughout any nonempty open interval: multiply by a suitable integer exponential to obtain an ordinary nonzero polynomial in exp(iθ), which has only finitely many roots. Both integration domains contain an open interval when 0<r<1. Both forms are strictly positive. On the finite-dimensional unit sphere the latter form attains a positive minimum, which is exactly γ. This proves the required strict gap without assuming an unproved uncertainty principle or inferring invertibility from S>0.

P10 p.1 informally links positive S with uniqueness, but §II itself warns that positivity alone is insufficient. The textbook must use this stronger proof. There is no dimension-independent gap asserted for arbitrary U, r, or q.

For finite acquisition at points t₁,…,t_m, take any m+1 linearly independent members of PW_Ω (for example distinct orthogonal critical sinc translates). Evaluation on their span is a map to C^m and has a nonzero kernel. Thus two different bandlimited signals give identical finite observations. Finite deletion and finite acquisition are different hypotheses even if their plots show the same finite window.

## Chapter 289 — A Selected Entrance to Sparse Reconstruction

Fixed boundary: finite-dimensional **real** vectors, fixed known linear measurement matrix, sparse/near-sparse coefficient models, exact sparse identifiability, BP/NSP, and one complete deterministic robust recovery proof. Complex extensions, random-matrix sample complexity, OMP/IHT, general dictionary learning, low-rank matrices, TV, Bayesian inference, and statistical risk are excluded. A sparsifying basis may be described as a model change x=Bc, but a basis theorem must not silently become a theorem for redundant dictionaries.

| ID | Kind and individual responsibility | Evidence / source | Proposed formal-body location |
|---|---|---|---|
| 289-D01 | Define support, ∥x∥₀ as count rather than norm, Σ_s, restriction x_T, ordered magnitudes with a tie rule. | V P11 §1, P12 §1.1. | §289.1 |
| 289-D02 | Define σ_s(x)_p as best s-term error; prove keeping largest magnitudes is optimal for p=1,2. | V P6 §2 (2.19), P11 §1; A finite exchange proof. | §289.1 |
| 289-E01 | Fixed-order versus best-term approximation, including a large coefficient at a high index. | V P6 pp.59–60; C original finite vector. | §289.1 worked comparison |
| 289-D03 | Define y=Ax or y=Ax+e, A∈R^{m×N}, ∥e∥₂≤ε; state coefficient and data spaces. | V P11 §1, P12 §1.1–1.2. | §289.2 |
| 289-T01 | Uniform s-sparse identifiability iff ker A contains no nonzero vector supported on at most 2s indices. Equivalently all column sets of size ≤min(2s,N) are independent. | A difference-of-sparse-vectors proof; P11 §1 supplies context, not full proof. | §289.2 |
| 289-P01 | Prove both directions by splitting a ≤2s support into two ≤s supports. Distinguish known-support full column rank from uniform unknown-support uniqueness. | A original elementary proof. | proof T01 |
| 289-D04 | Define equality BP and noise-constrained BP; prove a minimizer exists when x is feasible, using coercivity/closedness and compact sublevels. | V P11 (16)–(17), P12 (1),(4); A existence proof. | §289.3 |
| 289-D05 | NSP_s: for every 0≠v∈ker A and |T|≤s, ∥v_T∥₁<∥v_{Tᶜ}∥₁. | V P11 §5 p.16. | §289.3 |
| 289-T02 | NSP_s iff every s-sparse x is the unique equality-BP minimizer for Ax. | V P11 p.16; A both-directions triangle/feasible-competitor proof. | §289.3 |
| 289-E02 | Column-rank sparse uniqueness can hold while BP fails. Explicit A=[[1,0,3],[0,1,1]], x=e₁, competing z=(0,−1/3,1/3). | A: every pair of columns independent, Az=Ax, ∥z∥₁=2/3<1. | §289.3 failure case |
| 289-D06 | Define RNSP_s(ρ,τ): ∥v_T∥₂≤ρ∥v_{Tᶜ}∥₁/√s+τ∥Av∥₂ for all v and |T|≤s, 0<ρ<1. | V P11 §5.1 p.17. | §289.4 |
| 289-T03 | RNSP implies strict NSP by setting Av=0 and using ∥v_T∥₁≤√s∥v_T∥₂. Explain dependence on quantitative constants. | A direct implication. | §289.4 |
| 289-D07 | Define restricted isometry constants δ_k through every support of size ≤min(k,N), fixed normalization, and squared Euclidean inequalities. | V P12 (2); P11 §5.1. | §289.4 |
| 289-T04 | Main exact-sparse robust theorem under δ_{3s}+3δ_{4s}<2 and feasible ε. Bound holds for every minimizer, every s-sparse x, and every allowed error. | V P12 Theorem 1 p.3, proof pp.6–8. | §289.5 |
| 289-P02 | Derive tube bound ∥Ah∥₂≤2ε and exact-sparse cone bound; all notation defined before use. | V P12 (9)–(10). | proof T04 first lemmas |
| 289-P03 | Sort complement into blocks of size M=3s, allowing last smaller/empty block. Prove block-tail sum ≤∥h_{Tᶜ}∥₁/√M. | V P12 p.8 proof of (12); A end-block details. | proof T04 |
| 289-P04 | Derive positive denominator d=√(1−δ_{4s})−√((1+δ_{3s})/3)>0 and full-vector bound. | V P12 (11)–(14); A use s as an upper bound even if support is smaller. | proof T04 |
| 289-T05 | Near-sparse theorem with distinct ε and σ_s(x)₁/√s contributions under the same P12 condition. | V P12 Theorem 2 p.4, proof p.9. | §289.6 |
| 289-P05 | Cone defect 2σ_s(x)₁; repeat block argument; exhibit finite explicit constants in d, δ_{3s}, s. | V P12 (15)–(16); A algebra to be written/rechecked. | proof T05 |
| 289-E03 | Noiseless/exact-sparse, noisy/exact-sparse, noiseless/near-sparse, noisy/near-sparse: compute which error terms vanish. | A specialization, no random assumptions. | §289.6 diagnostic table |
| 289-E04 | Small matrix with NSP and explicitly provable RNSP; A=[[1,0,−1],[0,1,−1]], s=1. | A candidate certificate below; C hand solution/noise experiment. | §289.4 / Chapter 290 |
| 289-E05 | Rank deficiency and support ambiguity counterexamples; underestimated ε may make x infeasible. | A elementary examples, C exact numbers to choose. | §289.7 failure audit |

### Mathematical audit: keep three assertions separate

1. **Identifiability** only says two admissible sparse vectors cannot have the same measurements. It makes no promise about BP.
2. **NSP** characterizes uniform exact recovery by equality BP. It is a strict nullspace inequality, not the statement that A or one submatrix has full rank.
3. **Robustness/stability** needs quantitative control away from the nullspace and a model/data error bound. Exact uniqueness alone does not supply a useful noise constant.

The rank criterion is stated through sparse null vectors, without a careless `spark(A)>2s` assertion outside the usual range 2s≤N. The zero vector, s=0, N<4s, and smaller actual support need explicit conventions in drafting. The principal robust proof can simply assume 1≤s and define δ_k for k>N by δ_N. If N≤4s and A is underdetermined, the P12 hypothesis will generally be impossible; that is a meaningful failed hypothesis, not a contradiction.

P11's sufficient condition δ_{2s}<1/√2 and P12's δ_{3s}+3δ_{4s}<2 are different theorems. This index selects P12's complete block proof as the main route; the sharper P11 theorem can be a precisely attributed orientation remark, without promising its more advanced polytope proof. P11 Theorem 4 must not be treated as proved solely because it is printed in the survey.

For the proposed 2×3 matrix A=[[1,0,−1],[0,1,−1]], write w=Av=(v₁−v₃,v₂−v₃). Identities `2v₁=v₂+v₃+2w₁−w₂`, `2v₂=v₁+v₃−w₁+2w₂`, `2v₃=v₁+v₂−w₁−w₂` prove RNSP_1 with ρ=1/2, τ=√5/2. This is an independently audited small example; no RIP hypothesis is asserted for it. Its usefulness is precisely that a hand-checkable RNSP certificate can apply while the selected sufficient RIP criterion fails.

## Chapter 290 — Complete Reconstruction Cases

Fixed boundary: a small set of reproducible case studies that use the preceding theory. Every case must include object/model, observations, assumptions, algorithm, computed solution, residual, actual error when ground truth is available, certified bound, and at least one failed assumption. This chapter is not a new source of unproved general theory.

| ID | Kind and individual responsibility | Evidence / source | Proposed location/status |
|---|---|---|---|
| 290-D01 | Case contract: distinguish truth available only to a simulation from information available to reconstruction. Define data/model/algebra/truncation errors separately. | A editorial/mathematical responsibility. | §290.1 fixed |
| 290-T01 | Finite periodic trigonometric model: 2n+1 distinct frequencies in a fixed band; DFT matrix has orthogonal columns on a sufficiently fine uniform period grid. | V P7 §5.8; A finite geometric-sum proof. | §290.2 |
| 290-P01 | Prove finite reconstruction through DFT column orthogonality, not by applying an L²(R) theorem to a periodic function. Show real sine/cosine version and its coefficient convention. | A independent proof. | §290.2 |
| 290-D02 | Real full-column-rank design matrix and thin QR; QᵀQ=I, R invertible; least-squares solve Rĉ=Qᵀy. | V P4 §3.3.2–3. | §290.2 |
| 290-T02 | Prove least-squares minimization by orthogonal residual decomposition and perturbation ∥ĉ−c∥₂≤σ_min(A)⁻¹∥e∥₂ under the exact finite model. | V P4 §3.3.3; A singular-value estimate. | §290.2 |
| 290-E01 | Main finite-acquisition case: f(t)=a+b cos(2πt)+c sin(2πt), explicit distinct grid samples, a small overdetermined QR fit, controlled error and alias failure. | V P7 finite periodic concept, P4 QR; C exact data fixed at B-02. | §290.2–3 |
| 290-E02 | Finite-erasure case: r=1/2 and U={0,2} gives S=(1/2)I; compare U={0,1}, gap 1/2−1/π; reconstruct using an explicitly computable bandlimited truth. | A matrix calculation; C truth/data and finite-tail certificate to fix. | §290.4 |
| 290-E03 | Finite-window version of E02: show truncation inside h and subsequent gap amplification. Never label finite-window output exact real-line recovery. | V P10 pp.1–3,8; A tail estimate responsibility. | §290.4 |
| 290-E04 | Sparse success case: the explicit RNSP 2×3 matrix from Ch.289, exact BP hand solution, controlled noisy measurements and error bound from its certified property. | A certificate above; C numerical/analytic solution. | §290.5 |
| 290-E05 | Sparse failure case: A=[[1,0,3],[0,1,1]], rank-based unique 1-sparse answer but lower-ℓ¹ competitor. | A exact arithmetic already checked. | §290.5 |
| 290-E06 | Optional larger deterministic matrix with a genuinely checked P12 RIP condition; enumerate support spectra and compare actual noisy recovery with the theorem bound. | C only; no matrix yet chosen. May omit if E04 supplies the complete small case. | §290.6 optional |
| 290-T03 | Translate a proved coefficient-error bound to signal error only through the declared basis normalization/operator norm. | A finite-dimensional norm computation; must identify norm interval/measure. | §290.6 synthesis |
| 290-E07 | Final diagnosis: finite acquisition with/without finite model, erasure complement versus window, sparse rank criterion versus BP criterion, valid versus invalid noise radius. | A consolidation, no new theorem. | §290.7 |

The small RNSP example is **not** to be presented as an instance of P12 Theorems 1–2 unless its P12 RIP hypothesis is actually checked and found true. A passing numerical recovery or low residual does not certify RIP, NSP, a global noise constant, or correctness outside the declared model.

## Design depth and dependencies

The selected responsibilities support substantial exposition without adding unrelated theory: Chapter 288 has three data contracts, a full integral proof, explicit spectral/iteration analysis, four counterexamples or exact special cases, and window error accounting; Chapter 289 has independently proved identifiability and NSP equivalences, existence of minimizers, the cone/tube/block argument in two versions, and exact hand checks; Chapter 290 carries several complete computations with failures and evidence. A 25–40 page design per chapter is plausible but **not a mathematical completion test** and not a commitment to padding.

Required upstream handoffs before B-04:

| Dependency | Exact required content | State / owner |
|---|---|---|
| Ch.286 | Continuous representative for L² bandlimited objects; transform normalization; units | U exact formal-body ID; sampling agent / parent |
| Ch.287 | L²/pointwise sampling identity at step T and sample energy identity, with convergence that justifies finite-row h | U exact formal-body ID; sampling agent / parent |
| Existing linear algebra | finite-dimensional spectral theorem, orthogonal projection, singular-value lower bound; finite rank-nullity | Mathematical facts identified; upstream V/chapter IDs U, parent integration |
| Ch.285 / P6 | fixed-order versus adaptive/best-term approximation as a conceptual bridge | Exact narrative bridge U, approximation agent / parent |
| All three chapters | common notation for band edge and physical/angular frequency, q versus sparsity s versus window size, adjoint | B-02 common symbol table required; no global symbols changed here |

Potential symbol collision: reserve Ω for angular band edge, T for spacing, r for normalized bandwidth, U for erasures, s for sparsity, A for measurement matrix, S_U for erasure matrix, and ε for data error. Do not use the same S for erasure matrix and sparsity count in P12's original notation.

## OPEN / UNKNOWN register

| ID | Position / impact | Responsibility / blocking status / next step |
|---|---|---|
| REC-U01 | Exact upstream theorem IDs and V21 dependency addresses have not been independently recovered. | Parent + sampling agent; blocks final crossreferences, not B-02 design. |
| REC-U02 | Formal manuscript body/coverage locations do not exist yet. | B-04 expansion → thickening → independent refinement; blocks any coverage-complete or acceptance claim. |
| REC-U03 | P11 Theorem 4 proof is not printed in the read survey window. | Main theorem route uses the fully read P12 proof. If adopted as proved, assign an original proof before B-04 acceptance. |
| REC-U04 | Full numerical data and computations for Chapter 290 remain candidates. | B-02 choose small examples; B-04 derive/reproduce and check with independent residual/bound calculations. |
| REC-U05 | Source extractor tool has not been executed by this subtask; no completeness claim for automated source candidates. | Parent owns fixed tool invocation; this selected scope was manually read. Do not modify tool ZIP. |
| REC-U06 | Mathematical review of the eventual textbook, compilation, page inspection, and sole B-07 final audit are not performed here. | Later independent roles. All required; no partial-stage pass substitutes. |
| REC-U07 | Public author availability is verified, but bundling complete source PDFs for redistribution is not authorized by this index. | Parent packaging: distribute original manuscript/source manifest with public links; keep author PDFs research inputs unless license permits. |

## Handoff

- Handoff ID/version/time: `V22-B01-RECOVERY-288-290-v1`, 2026-11-28 UTC.
- Sender → receiver: recovery source-indexing agent → parent controller, then B-02 expansion/dependency design.
- Volume/stage/status: V22 *Approximation, Sampling, and Reconstruction*, B single Work, B-01 selected Chapters 288–290 indexing complete; all textbook coverage remains pending.
- Authorization/KEEP: parent-reported public-source approval; only own index and readable source inputs created. No manuscript, frozen volume, chapter baseline, shared macro, extractor, source table, or formal template changed.
- Model/mode: actual inherited model configuration/High setting not independently verified.
- Baseline: reference review v1 read; V22 282–290 and this subtask 288–290 accepted. Git endpoint received as above; independently rechecking it is parent scope.
- Manifest: readable source identities above; own index path `work-v22/b01/recovery.md`. Parent should add this file's final hash to its combined manifest. No paired chapter PDF, build, or formal template output yet exists at B-01.
- Evidence: source windows and individual responsibilities listed; strict positivity and rank/NSP distinctions independently audited. No unseen book or stopped source supports a proof claim.
- Change/retention: new B-01 source responsibility ledger only. Existing approved sources and reference-review mappings remain unchanged.
- Open items: REC-U01–07, with owners and impact above. No known source-access blockage remains for the selected route.
- Next unique stage: B-02 fixes narrative, dependencies, exact case data, and coverage-to-section mapping. Acceptance requires each responsibility to receive a concrete planned location, upstream normalization agreement, and explicit treatment of all open proof/example obligations.
- Prohibited rework: do not restart V21 or other volumes; do not revive unavailable R1–R4 or Q1/Q2 as evidence; do not replace finite deletion by finite acquisition; do not claim final mathematical or page acceptance from this index.
- User decision required: none identified within the approved public-source boundary.
- Delivery: produced in shared workspace and reported through the collaboration channel; receiver's actual read/hash receipt remains pending. Parent controls durable save and the combined user-facing handoff.
