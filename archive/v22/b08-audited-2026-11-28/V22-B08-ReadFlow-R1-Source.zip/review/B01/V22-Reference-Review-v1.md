# V22 逼近、取樣與重建｜文獻確認稿

2026-11-28（臺灣時間）｜B 方案單一 Work｜B-01 前文獻準備

九章已有公開可讀的正文來源。建議以這套公開來源開卷，並保留分卷書目原列三本供比對。原列三本的指定正文尚未取得。本稿列出可讀證據、原始書目取得途徑和需確認的外部連結，供使用者批准這組文獻後交精修官接 B-01。

## 原列三本與稀疏重建補書

| 書籍及固定辨識 | 本輪實見 | 可走的正式入口與所需範圍 |
| --- | --- | --- |
| R1 · E. W. Cheney, *Introduction to Approximation Theory*，McGraw-Hill 1966，ISBN 9780070107571 | 1966 初版館藏來源記錄及書目。另查到 Chelsea 第二版目錄資料，可定位最佳多項式逼近、Jackson、最佳有理逼近的存在與刻畫。初版實際正文及段落頁碼待核。 | [清大數學分館紙本紀錄](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990007562590206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw&search_scope=NTHU_holding&tab=LibraryCatalog) · [1966 版書目](https://books.google.com/books/about/Introduction_to_Approximation_Theory.html?id=9uZQAAAAMAAJ) · [德州大學作者著作紀錄](https://web.ma.utexas.edu/CNA/DMY/ewc-books.html) · [第二版目錄線索](https://www.kinokuniya.co.jp/f/dsg-02-9780821813744) |
| R2 · R. A. DeVore、G. G. Lorentz, *Constructive Approximation*，Springer 1993，ISBN 9783540506270 | 出版說明及少量公開目錄。DeVore 另著的公開論文把插值空間指向書中第 6 章、逼近空間反向估計指向書中第 7 章 Theorem 5.1。已試 Springer DOI 頁及正式 PDF 入口，正文待核。 | [Springer 書頁](https://link.springer.com/book/9783540506270) · [書本 DOI](https://doi.org/10.1007/978-3-662-02888-9) · [清大數學分館紙本紀錄](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990008174900206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw&search_scope=NTHU_holding&tab=LibraryCatalog) · [有限目錄預覽](https://books.google.com/books/about/Constructive_Approximation.html?id=XsOpzwEACAAJ) |
| R3 · J. R. Higgins, *Sampling Theory in Fourier and Signal Analysis: Foundations*，Oxford/Clarendon 1996，線上 ISBN 9781383031065 | 讀到 Oxford 第 6、11、17 章摘要及目錄。清大既有紀錄列 2023 線上資源，Oxford 列 1996 出版。公開頁尚未取得章文，清大頁本次未能讀取。另有同系列 *Advanced Topics*，本次選的是 *Foundations*。 | [Oxford 書頁](https://academic.oup.com/book/53157) · [清大電子書紀錄](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma9957806885106774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw&search_scope=NTHU_holding&tab=LibraryCatalog) · [第 6 章](https://academic.oup.com/book/53157/chapter-abstract/421998821) · [第 11 章](https://academic.oup.com/book/53157/chapter-abstract/421998846) · [第 17 章](https://academic.oup.com/book/53157/chapter-abstract/421998876) |
| R4 · S. Foucart、H. Rauhut, *A Mathematical Introduction to Compressive Sensing*，Birkhäuser 2013，DOI 10.1007/978-0-8176-4948-7 | 補充核對書。已看 Springer 書頁與作者書目及勘誤入口，此書正文待核。第 289–290 章先有下列作者綜述和作者預印本可用。 | [Springer 書頁](https://link.springer.com/book/10.1007/978-0-8176-4948-7) · [作者書目](https://foucart.github.io/#publications) · [作者勘誤](https://foucart.github.io/publi/Errata.pdf) |

R1 的 Chelsea 第 2 版及其後印本另列。專案舊書目連到 Google Books 的 2026 年記錄，掃描時以實體書版權頁和目錄為準，避免跨版誤配頁碼。R2 的 2010 平裝重印另有 ISBN 9783642080753。以上清大館藏取自專案留存的 2026-11-14 館藏紀錄，11-28 嘗試重開時未能獨立取得館藏網頁內容。若採用原書，可優先試 R3 清大機構存取。若需用手邊實體書補 R1 或 R2，請先給版權頁、目錄及指定章節，再按實際版次定頁。公開方案現有資料可涵蓋九章，確認公開方案即可先接 B-01。

## 建議採用的公開正文

「實見」欄列出本次實際定位的正文窗口，其餘段落的逐項語意核讀留待 B-01。整書、講義、作者論文及預印本各以自身版本引用。

| 代碼與來源 | 可讀範圍與實見位置 | 指定用途 |
| --- | --- | --- |
| P1 · L. N. Trefethen, *Approximation Theory and Approximation Practice* | 作者放出的前六章 PDF，已見第 6 章 Theorem 6.1。另有作者全系列課程影片索引，已定位第 10、23–24、26–28 章的影片入口。2019 延伸版由 SIAM 提供，本次取用作者放出的樣章。 | Chebyshev 節點與多項式逼近、Weierstrass。後段有理逼近有 P3 的正文可對照。[作者書頁](https://people.maths.ox.ac.uk/trefethen/ATAP/) · [前六章 PDF](https://people.maths.ox.ac.uk/trefethen/ATAP/first6.pdf) · [作者課程](https://people.maths.ox.ac.uk/trefethen/atapvideos.html) |
| P2 · R. Hiptmair, *Numerical Methods for Computational Science and Engineering*，ETH Zürich，AT’25 | 第 6 章講義公開。已見 §6.4.0.1–3，包含最佳一致逼近、交錯定理及 Remez 的設定。§6.2–6.3 的 Chebyshev 與平方誤差為延伸核讀位置。 | 多項式逼近的存在、唯一性、誤差刻畫及計算例的主參照。[ETH 第 6 章](https://people.math.ethz.ch/~grsam/NumMeth/Parts/NCSEFL_handout_chapter_6.pdf) |
| P3 · S. Filip、Y. Nakatsukasa、L. N. Trefethen、B. Beckermann，*Rational Minimax Approximation via Adaptive Barycentric Representations*，2018 | 作者系所公開 PDF。已見 §1 的有理型別、約分後缺陷數、交錯式 (1.3)，及 `abs(x)` 的算例位置。 | 有理逼近的分母條件及誤差刻畫。區分多項式的交錯點數與有理逼近缺陷數。[Oxford 作者 PDF](https://people.maths.ox.ac.uk/trefethen/minimax_published.pdf) |
| P4 · T. A. Driscoll、R. J. Braun, *Fundamentals of Numerical Computation*，作者公開 Python 線上版 | 整書可讀。已見 §5.2 的帽函數及其條件性定位、§5.3 的三次樣條端點條件，以及第 3 章 QR 正文入口。 | 分段線性插值、三次樣條算例、最小平方計算。[全書](https://fncbook.com/python/) · [分段線性插值](https://fncbook.com/python/pwlin/) · [三次樣條](https://fncbook.com/python/splines/) · [QR](https://fncbook.com/python/qr/) |
| P5 · T. Lyche、C. Manni、H. Speleers, *B-Splines and Spline Approximation*，CIME 課程作者稿 | 作者系所公開 PDF。已見 §1 開頭與 §2.2.1 Definitions 28–29，確認局部性由係數泛函的支撐控制，誤差估計另用多項式再現與有界性。 | B-spline 的節點與支撐、局部擬插值、樣條逼近誤差。[作者稿](https://www.mat.uniroma2.it/~speleers/cime2017/material/notes_lyche.pdf) |
| P6 · R. A. DeVore, *Nonlinear Approximation*，*Acta Numerica* 7（1998），51–150 | 作者系所公開全文。已見 §4.1 的 dyadic 定義 (4.4)、§4.2 的 $K$-泛函、§4.3 Jackson–Bernstein 假設及 Theorem 1 的等價結論；§6 的固定分割與變動分割是後續核讀窗口。 | 明確定義由最佳誤差生成的逼近空間，連到光滑度或插值空間。也提供第 289 章最佳項逼近先備。[作者 PDF](https://people.math.sc.edu/devore/publications/nlacta.pdf) |
| P7 · B. Osgood, *The Fourier Transform and Its Applications*，Stanford EE261 Fall 2007 講義版 | Stanford 公開全稿。已見第 5 章 §5.5–5.6 的取樣與 sinc 重建正文，及同章有限和、週期情形的段落；固定用 2007 講義的節碼。 | 頻帶限制、等距取樣、實線與週期的重建差異。[Stanford 課程](https://see.stanford.edu/Course/EE261) · [全稿 PDF](https://see.stanford.edu/materials/lsoftaee261/book-fall-07.pdf) |
| P8 · M. D. Adams, *Signals and Systems*，第 3.0 版，2020，PDF ISBN 9781550586749 | 作者正式公開整書，CC BY-NC-ND 3.0。已定位 §§6.20.1–6.20.3，印刷頁 209–216。作者也公開第 6.0 版，本表所列節碼與頁碼屬第 3.0 版。 | 取樣、內插、重建的工程例；保留版本、引註與授權條件。[作者書頁與授權](https://www.ece.uvic.ca/~frodo/sigsysbook/) · [第 3.0 版正文](https://www.ece.uvic.ca/~frodo/sigsysbook/downloads/signals_and_systems-3.0.pdf) |
| P9 · M. Unser, *Sampling—50 Years After Shannon*，*Proceedings of the IEEE* 88（2000），569–587 | EPFL 實驗室與機構典藏提供全文。已見導論的頻域、有限支撐與實作差異，以及 Appendix A 的公式定位。 | 混疊、理想重建限制、逼近與樣條連接。[EPFL 書目](https://infoscience.epfl.ch/entities/publication/722c13d8-d7f5-4cb9-ae8d-ab471d74a44f) · [作者 PDF](https://bigwww.epfl.ch/publications/unser0001.pdf) |
| P10 · P. J. S. G. Ferreira, *The Stability of a Procedure for the Recovery of Lost Samples in Band-Limited Signals*，*Signal Processing* 40（1994），195–205 | 作者系所公開全文。已見導論 (1)–(2) 的缺樣線性系統、缺樣位置及最大特徵值的案例。 | 超取樣後有限缺樣，追蹤 $I-S$ 的可逆性和逆算子放大，從缺樣位置讀出穩定性差異。[作者 PDF](https://sweet.ua.pt/pjf/PDF/Ferreira94h.pdf) |
| P11 · S. Foucart, *Flavors of Compressive Sensing*，2017，61–104 | 作者首頁直接連到公開 PDF。已見 §5 的零空間性質及 §5.1 的 robust 版本和帶誤差限制的 basis pursuit。 | 稀疏性、零空間條件、資料有噪時的穩健性。[作者稿](https://foucart.github.io/publi/FlavorsOfCS.pdf) |
| P12 · E. Candès、J. Romberg、T. Tao, *Stable Signal Recovery from Incomplete and Inaccurate Measurements*，arXiv:math/0503066v2，2005-12-07 | 作者預印本全文。已見 §1 模型、Theorem 1 的 RIP 假設與有噪恢復界，並定位 Theorem 2 的近稀疏誤差項。 | 擇一稀疏重建穩健定理，核對近稀疏尾項與資料誤差分工。[作者文獻頁](https://math.ucla.edu/~tao/preprints/sparse.html) · [固定 v2 PDF](https://arxiv.org/pdf/math/0503066v2) |

## 九章的來源對照

V21 的 301 頁交付 PDF 卷首、目錄和已推送的 Git 版本均確認第 270–281 章。V22 依同一章號順序接第 282–290 章。

| 章 | 主題 | 公開來源與 B-01 首讀位置 |
| --- | --- | --- |
| 282 | 多項式與有理逼近 | P1 Chs. 2–6、P2 §6.2、P3 §1。核多項式次數、區間、分母在區間內無零點及所用的誤差範數。 |
| 283 | 樣條與局部逼近 | P4 §§5.2–5.3、P5 §§1、2.2。核分段次數、節點處連續階、B-spline 局部支撐及擬插值條件。 |
| 284 | 最佳逼近與誤差刻畫 | P2 §§6.3–6.4、P3 §1。核一致範數交錯判準與平方誤差投影所需的不同假設，並核有理型別缺陷數。 |
| 285 | 逼近空間 | P6 §§4.1–4.3、§6，搭配 P5 §2。優先以固定分割的樣條逼近誤差定義一個具體空間，再核其與光滑度或插值空間的關係、容許指數與端點。 |
| 286 | 頻帶限制與取樣 | P7 §§5.5–5.6、P8 §6.20.1、P9 Appendix A。核 $L^2$ 對象的點值代表、頻率單位、取樣間距與混疊。回指 V21 的 Plancherel 和頻帶投影。 |
| 287 | 重建公式與穩定性 | P7 §5.6 起、P8 §§6.20.2–6.20.3、P9 Appendix A。核 sinc 級數、Parseval 或 frame 界的適用假設，及有限截斷與資料噪聲的不同誤差項。 |
| 288 | 不完整資料 | P10 (1)–(2)、譜分析及圖 1–6。核定取樣格、完整已知樣本集合、有限缺樣的唯一性與最小譜間隔；有限窗資料另列其條件。 $I-S$ 的可逆性要另核 $\lambda_{\max}(S)<1$，因此要查超取樣及有限缺樣的條件。 |
| 289 | 稀疏重建的選定入口 | P6 §5、P11 §§5–5.1、P12 §1。核稀疏度、量測算子、無噪唯一性與有噪誤差，保留兩論文不同的定理假設。 |
| 290 | 完整重建案例 | P4 第 3 章 QR、P7 §5.6 後的取樣案例、P10 缺樣條件數案例、P12 Theorems 1–2。可在 B-02 選一個規模小而可手算的案例，明列模型、資料、條件、重建、誤差與失敗情形。 |

分卷表要求的 J06、J09 均有讀源入口。I13「近似與正則化」在局部第 1–2 章保留概念橋接，完整的反問題正則化和統計風險理論由各分支承擔。上表是文獻位置及初讀順序，正式章節邊界與逐項證明責任由 B-01 固定。

## 兩個授權待確認的外部連結

| 代碼 | 發現的入口及疑點 | 目前安排 |
| --- | --- | --- |
| Q1 | Carl de Boor, *A Practical Guide to Splines* 修訂版。CMU 課程目錄外露的 PDF 檔名含 `pdfcookie.com`，尚無 Springer 或作者授權證明。[待確認連結](https://www.stat.cmu.edu/~brian/valerie/617-2022/week07/spline%20references/pdfcookie.com_a-practical-guide-to-splines.pdf) · [Springer 正式入口](https://link.springer.com/book/9780387953663) | 候選停用。P4、P5 可涵蓋本卷樣條責任。 |
| Q2 | Trefethen 教材的 StudyLib 轉載頁，搜尋結果無可核的授權或上傳者身分。[待確認連結](https://studylib.net/doc/28274978/lloyd-n.-trefethen---approximation-theory-and-approximati...) · [SIAM 延伸版](https://epubs.siam.org/doi/10.1137/1.9781611975949) | 候選停用。用 P1 樣章、P2 ETH 講義、P3 作者論文。 |

兩個連結都只供判斷來源，沒有下載、轉存或拿來做正文證據。如果你判定來源不可用，就排除該入口。若你仍指定相應實體書作依據，可用你提供的版權頁、目錄及所需章節。

## 主控交接

- **交接 ID／日期／階段**　V22-REF-20261128 v1。V22《逼近、取樣與重建》，B 單一 Work 前置文獻準備已形成待核清單。正式 B-01 待使用者說 OK。
- **發出／接收**　同一 Work 主控交使用者核文獻。放行後由獨立精修任務接 B-01（對應 A 的文獻逐項表及定界）。此稿交付時尚無接手回執。準備由主控執行，推理模式未獨立核實。
- **有效章號基線**　[Git 固定提交 880969b](https://github.com/Euricotalavan/categorical-mathematics/tree/880969bd1ca5e64e3f0d34fb01d25c54562b94e6/archive/v21/b08-audited-2026-11-28) 的發布索引列第 270–281 章。另實讀 [V21 交付 PDF v0](https://chatgpt.com/library?file_id=libfile_fde3_f-525177bd63588191b9ca283a3854c971_383d682b1c388191a1961becbec9fb77&account_id=personal) 物理頁 1–8，卷首與目錄一致。V22 接續第 282–290 章。V21 發布版 PDF 為 1,574,084 bytes，Git 所列發布 SHA-256 為 `0c2c26f442dcb494fb75de233a386cb6d66a38a55f82109819732edf368b81ec`。
- **檔案清單**　現行分卷 [math-curriculum-v4-git-aligned.html](https://chatgpt.com/library?file_id=libfile_fde3_f-7cde2d5c5e2c8191bb7a19b896abd14a_383d682b1c388191a1961becbec9fb77&account_id=personal)，2,167,706 bytes，SHA-256 `098aaacab85e330cb0493fc928916361c3fba09c0d36b3964f61c74ad2a2e1df`。現行書目 [math-references-v4-git-aligned.html](https://chatgpt.com/library?file_id=libfile_fde3_f-4683fcc885b48191a466b68be151d22b_383d682b1c388191a1961becbec9fb77&account_id=personal)，3,482,004 bytes，SHA-256 `4b3e0af09024a799744ee6fbb76ad68b95d82baeb020e5a6b8033cf00361a59d`。兩份均以專案附檔實算指紋，兩表九個局部章名及原列書目一致。擷取工具 `math-extractor-v0.4.zip` 1,021,262 bytes，SHA-256 `c2d47e097447a836bcad63d5a030106b1ec261bac4ffe32a6aecc783aca244f3`，已覽 README 的輸入輸出及限制，B-01 再依正式需要擷取。
- **正式模板與編譯**　ReadFlow R1 固定來源組為 `V0-ReadFlow-R1-Source.zip` v3、7,007,679 bytes，SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。[固定提交](https://github.com/Euricotalavan/categorical-mathematics/tree/8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3/archive/v0/readflow-r1-editorial-2026-11-17)。此為規範所固定的恢復入口。V22 的正文、配對 PDF、本卷排版調整、依賴配置、編譯與全頁視檢均尚未產生。
- **待決項**　O1 使用者批准來源組，阻 B-01。O2 R1–R4 指定版正文未取得，影響其原文引用與逐項聲明；若批准公開來源，這些書先保留為書目信息。O3 Q1–Q2 授權待使用者判斷，停用期間可走公開方案。O4 逐項定義、定理、證明、必要例題仍待精修官核對。
- **下一階段唯一入口**　使用者同意後，精修官先回執本稿、固定書目與實際可讀正文，再做 B-01 原文定位、定義／命題／證明／例題責任、跨書假設差異、既有先備與缺口處置。保留本次已核版本及位置，僅補讀有實質依賴的正文。保護 V21 及其他上游版本，加工只在 V22。
