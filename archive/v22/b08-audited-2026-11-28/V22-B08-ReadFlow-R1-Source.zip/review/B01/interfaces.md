# V22 B-01 independent scope and prerequisite audit

2026-11-28 · Expansion role · version 1 · B single Work · Chapters 282–290

Status: this is adjacent scope evidence for the refinement lead's B-01. It is not the B-01 source responsibility table, B-02 design, an approved mathematical manuscript, or a finding of full source coverage. No earlier volume or other role's file was modified.

## Read-in receipt and authority

The parent reports the user's approval of the public source set and autonomous B-01–B-08, including named independent roles. The parent's current assignment limits this task to a scope/prerequisite audit until the B-01 handoff. I accept that limitation.

Actual reads: the B rules and common handoff provisions in `project_sources/13-A-B-v4.txt`; all of `V22-Reference-Review-v1.md`; the V21/V22 records in the embedded JSON of the official curriculum; P5 opening definitions and degree-one example; P6 §4.1–4.3, including (4.4)–(4.13). The remainder of the public source set is not claimed read here. Model identity is inherited from the task environment; actual requested GPT-6.1 Sol / High settings are not independently verifiable here.

| Input | Bytes | SHA-256 |
| --- | ---: | --- |
| `project_sources/13-A-B-v4.txt` | 39172 | `bb095f08c70f79ecfb84abbabf3f1350ee7f53ba9de707c917a412301bac4fea` |
| `project_sources/02-math-curriculum-v4-git-aligned.html` | 2167706 | `098aaacab85e330cb0493fc928916361c3fba09c0d36b3964f61c74ad2a2e1df` |
| `V22-Reference-Review-v1.md` | 16832 | `def4341349a906942e92b1d954b4bab1c77b45fa3d88a369a6b335b5394dd215` |
| `work-v22/sources/P5.pdf` | 304521 | `2e5345b72a6dfccdfa2adc9917d18f7d8066e52d66b20b6fff8d30c42dcc9095` |
| `work-v22/sources/P6.pdf` | 1029212 | `ad293caf57959566ddaf0cc5fb1df92145c0aa74f2d849a8480caff4cdb0d4f6` |

## Frozen numbering and incoming interfaces

Official curriculum V22 has nine local chapters, modules J06/J09, prerequisites “Fourier core, linear algebra, functional core,” and endpoint “analysis from approximation error to reconstruction stability.” Its chapter numbers 1–9 are local planning indexes, not permission to restart global numbering. The reference review fixes V21 at global 270–281 and V22 at 282–290.

The parent supplies its actual-read evidence from V21 published commit `880969bd1ca5e64e3f0d34fb01d25c54562b94e6`, path `archive/v21/b08-audited-2026-11-28/`: forward transform `exp(-2π i x·ξ)`, linear-first inner product, and Lp objects as almost-everywhere classes; §270.7 finite coordinates, §274.4 unitary L2 transform, §274.6 spectral projections. These locations are parent-reported evidence, not an independent reread by this role. No V21 local manuscript was available to this role at this audit time.

For V22, restate the one-dimensional normalization where used: inverse kernel `exp(2π i xξ)`, `sinc(t)=sin(πt)/(πt)` with value 1 at zero; no mixing angular frequency Ω with cycles-per-unit B. A frequency band `[-B,B]` permits sampling spacing `T≤1/(2B)` in the L2 setting. Point evaluation must use the continuous inverse-integral representative: on a finite band L2 Fourier data belong to L1 by Cauchy–Schwarz. The equivalence class itself has no point samples.

The incoming finite-dimensional interfaces needed later are adjoint, positive semidefinite Gram matrices, spectral norm, singular values, orthogonal projection, and least squares. The curriculum's “linear algebra” label alone is not evidence that their exact hypotheses were established. Restate each usable finite-dimensional fact with domains and a short proof when needed; do not reopen upstream volumes.

## Distinct boundaries and targets

The following is a scope audit, not a fixed B-02 section list. The refinement lead must assign each definition, theorem, proof, and necessary example an actual source position and later a manuscript landing point.

| Global chapter | Required mathematical target | Boundary that prevents duplication or overclaim |
| --- | --- | --- |
| 282 Polynomial and rational approximation | Finite-degree polynomial spaces, interpolation as a construction, existence of accurate polynomial approximation, admissible rational functions and pole restrictions; at least one explicit comparison/example | Builds approximation families. Best-approximation existence, uniqueness, and alternation belong to 284. Do not silently identify interpolation with minimax approximation. Rational functions of type (m,n) have degrees at most m,n after a clearly stated representation convention. |
| 283 Splines and local approximation | Partition, piecewise degree, continuity at knots, nodal hats, local support, one explicit error estimate; selected B-spline recurrence/endpoint convention and a genuine local approximation operator | Establishes concrete spaces usable in 285. Local support alone proves no approximation order. Locality of coefficients, boundedness, and polynomial reproduction are separate conditions. Distinguish interpolation, quasi-interpolation, and orthogonal projection. |
| 284 Best approximation and error characterization | Finite-dimensional existence; Hilbert least-squares projection and residual orthogonality; real uniform polynomial alternation with existence/uniqueness and proof; computable upper/lower error certificates | Uniform minimax and L2 projection use different geometry. Rational minimax, if included as a theorem, needs its actual defect convention and sufficient source proof; do not copy the polynomial n+2 alternation count. |
| 285 Approximation spaces | A specific approximation scheme, explicit best-error sequence, a norm/quasinorm with the ambient norm included, and a proved connection to a function/interpolation space | The official mandatory J06 assessment is not satisfied by a generic name or an isolated decay bound. Choose a concrete fixed-partition spline or polynomial scheme. State allowed smoothness/exponents and excluded endpoints. Free-knot nonlinear rates are not fixed-grid spline rates. |
| 286 Band limitation and sampling | Paley–Wiener L2 class, continuous representative, sampling operator and units, Nyquist condition, aliasing/nonuniqueness outside the model | Establishes what data mean and when uniqueness is possible. Detailed reconstruction/perturbation estimates belong to 287. Pure sinusoids illustrate aliasing but are not L2(R); supply an L2 counterexample if the claim is about that class. |
| 287 Reconstruction formulas and stability | Sinc reconstruction, precise mode(s) of convergence, sample energy identity or specified frame bounds, bounded recovery, truncation and sample-noise estimates | Separate infinite exact recovery from finite-window computation. ℓ2 noise and bounded per-sample noise are distinct hypotheses. L2 convergence does not alone imply pointwise convergence; use the bandlimited evaluation bound if uniform convergence is asserted. |
| 288 Incomplete data | One specified missing-data model, finite missing sample system, invertibility/uniqueness and quantitative conditioning, a failure example | Strict oversampling with finitely many erased samples is different from arbitrary finite observation windows. State what all remaining known samples are. At critical Nyquist sampling a missing sinc basis coefficient is unrecoverable. A positive spectral gap must be proved, not inferred from a numerical plot. |
| 289 Selected entrance to sparse reconstruction | Finite-dimensional sparsity and best-s-term tail, measurement model, unique sparse representation versus ℓ1 recovery, a selected null-space condition and a stability/robustness result with proof | A finite sparse-vector model is distinct from continuous-time band limitation. `spark>2s`/injectivity on 2s-sparse vectors addresses uniqueness, NSP addresses ℓ1 recovery, RIP is a sufficient route to robustness. Keep P11 and P12 constants/assumptions separate. |
| 290 Complete reconstruction case | A complete small model-to-data-to-reconstruction-to-error calculation, with an observed failure when a needed hypothesis is removed | Integration must use established results and contain actual calculations. It cannot replace the general responsibilities of 285, 288, or 289. A second short contrast is useful if the main case uses only one of the approximation/sampling/sparsity branches. |

I13 applies at local chapters 1–2, hence global 282–283, as a conceptual bridge: approximation, smoothing/discretization, regularization, and risk should not be conflated. A short explanation can compare model bias with perturbation amplification. Full inverse-problem regularization and statistical risk theory remain outside this volume's selected entrance; the bridge adds no full-volume hard prerequisite.

## Dependency constraints for the later design

* 282 supplies approximation-family notation to 284; 283 supplies nested fixed-grid spaces and local estimates to 285. The selected 285 result depends on both the approximation error definition in 284 and explicit direct/inverse estimates, not only on spline terminology.
* 286 must settle the L2 representative and Fourier units before any sample is written as `f(kT)`. V21 §274.4 and §274.6 can be cited at this precise interface.
* 287 should prove the full-lattice sampling map and recovery bounds before 288 restricts the data. Then 288 can derive its missing-sample matrix from a fixed established kernel.
* 289 should introduce its finite matrix and vector norms explicitly. It may reuse least squares, orthogonality, and conditioning from 284/288, but its ℓ1 proof needs its own tail inequality and null-space argument.
* 290 may compare errors using the same three-way accounting: model mismatch/approximation, finite-data or truncation effect, and propagated measurement noise. These terms require distinct assumptions and must not be combined into an unexplained “error.”

## Concrete safe route for the mandatory approximation-space responsibility

This is a feasibility witness for B-01; it remains a choice for B-02 after source responsibility is fixed. In `X=L2(0,1)`, use continuous piecewise affine spaces `V_j` on uniform dyadic partitions, with no endpoint boundary constraint. They are nested finite-dimensional subspaces. Let `E_j(f)=inf_{v∈V_j}||f-v||_2`. For `0<α<1`, one economical complete target is

`A^α_∞={f∈L2: ||f||_2+sup_{j≥0}2^{jα}E_j(f)<∞}`

and its equality, with equivalent norms, to the real interpolation space `(L2,H1)_{α,∞}`. Define `H1(0,1)` in a usable one-dimensional form (absolutely continuous representative with derivative in L2) and use its full norm in the K-functional. Prove the spline Jackson estimate `E_j(g)≤C2^{-j}||g||_{H1}` and inverse estimate `||v||_{H1}≤C2^j||v||_2`; both have short elementary interval proofs. Prove the equivalence by near-best dyadic approximants and a telescoping sum, rather than assuming an infimum is attained in a K-functional. This provides a genuine function-space connection without unsupported endpoint or Besov identification. More general q or smoothness claims create extra proof obligations and are optional.

Actual P6 read evidence: §4.1 (4.4) is dyadic approximation error; §4.2 (4.5)/(4.9) defines the K-functional/real interpolation; §4.3 requires Jackson plus Bernstein and restricts `0<γ<r` in Theorem 1 (4.13). P6 explicitly says it suppresses an epsilon in selecting a K-functional minimizer; the textbook must restore that rigor. The fixed-grid specialization and its explicit inequalities require the manuscript's own proof. P5 actual read confirms Definition 1 nondecreasing knots, Definition 2 recurrence with zero-denominator terms zero, and Example 3 degree-one hats; these definitions alone do not prove the specialization above.

## OPEN/UNKNOWN and handoff

| ID | Issue / impact | Owner / next action | Blocks what |
| --- | --- | --- | --- |
| EXP-O1 | Full B-01 item-level responsibility table not yet delivered to this role | Refinement lead fixes source objects, actual positions, assumptions, exclusions | B-02 final design |
| EXP-O2 | V21 precise interface text is parent-reported; no independent reread by this role | Parent preserves its source-read record; later manuscript restates exact needed conventions/results | No block to this adjacent audit; source attribution must remain honest |
| EXP-O3 | Rational defect theorem can be accidentally overstated, including point count and denominator hypotheses | Refinement fixes exact P3 theorem responsibility or limits rational portion to admissibility/constructions and certified comparisons | Any rational minimax theorem |
| EXP-O4 | Approximation-space scheme and exponent not yet selected | B-02 chooses scheme after checking B-01 responsibility; prove actual direct/inverse estimates | Chapter 285 design |
| EXP-O5 | P10 missing-data theorem must have strict-oversampling and finite-erasure assumptions aligned with chosen kernel | Refinement source audit; B-02 fixes model, normalization, and conditioning example | Chapter 288 theorem |
| EXP-O6 | P11/P12 robust theorem needs one exact hypothesis/constant package and complete proof responsibility | Refinement selects source route; do not blend results | Chapter 289 robustness |
| EXP-O7 | Corpus-level historic UNKNOWNs (16-topic/22-chapter mapping and six global gates) are not resolved by V22 | Preserve historic status; not an instruction to reopen frozen manuscripts | No new V22 work outside scope |

Expansion readiness: adjacent audit complete; available for B-02 after the refinement lead's B-01 handoff. The next unique action is to read that fixed responsibility/boundary/difference table, acknowledge exact files/versions, and then produce the whole-volume narrative/dependency design. No B-02 design or B-03 calibration is declared started by this document. No textbook/PDF exists in this role's output; no compilation, page review, or semantic final audit is claimed. Formal ReadFlow R1 remains the later B-06 baseline, fixed artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`; this audit changes no template.

Handoff identity: `V22-EXP-B01-interfaces-v1`; sender expansion → parent/refinement, B-01 adjacent audit complete (maps to original A boundary/prerequisite preparation). Delivered as a local role artifact and direct parent message; parent must include it in the recoverable stage package. It is not itself a persistent upload or a user-delivery receipt. Frozen upstream volumes, tools ZIP, curriculum and bibliography, other roles' files, and all chapter numbering are protected. Next-stage acceptance requires actual source-responsibility coverage and no unexplained prerequisite gap; hash and this readiness statement do not establish mathematical acceptance.
