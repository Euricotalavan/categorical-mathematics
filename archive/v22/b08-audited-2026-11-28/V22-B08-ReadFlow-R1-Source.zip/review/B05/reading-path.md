# V22 B05 integrated reading-path review

Version 1 · 2026-11-28 UTC · Expansion lead → parent and group refinement reviewers

**Disposition:** the fixed mathematical reading path is coherent. No cross-chapter mathematical blocker was found in this seam review. Three small, explicit reader-facing corrections are recommended before B06: two prefatory descriptions and the incoming terminology at the comb calculation. Exact patches are below. Chapters remain unchanged by this role. This review is not a second proof audit, full source-coverage acceptance, all-page visual QA or the sole B07 whole-volume final audit.

## Read-in and fixed version

Parent assigned B05 after the B04 freeze. All nine chapter files matched `qa/b04/chapter-hashes.txt` when actually rehashed for this review. Fixed source hashes:

Additional actual inputs: `frontmatter.tex`,2910 bytes, SHA-256 `6dbef735524f4d652ff3927fecfdedec84b3946d8f346e794d6015ad989f8c02`; `bibliography.tex`,3524 bytes, SHA-256 `18fcbcb45f97e54360710e69e5ee0e35a52b5c41f4519d45a9fe18eb78917639`; `qa/b04/chapter-hashes.txt`,846 bytes, SHA-256 `c5030667ef184d6e653a101ea947d8b38c5b2fe70eae90fc1cc308fbf01f4f4b`.

| Chapter | SHA-256 |
| --- | --- |
| 282 | `a97ead2e82f6ad4d90bd3f6ef9619e9bc2e49da342b6ee784d2ec5f00cd72d3c` |
| 283 | `a8b7c82b248c9ee5c6272a58dd27f240c6ffe424e15da953c09c756dd67302e6` |
| 284 | `9ad7973dfbb4ca2b84cc4160d187246553c6d70521625f05a1f303672cb4ca82` |
| 285 | `32dc6af4cf9267029727370f49b02fe2d28817cacf83f7e0f8234d3189b03955` |
| 286 | `08fbe90754eb0c9d8dc4e337ff2f95cd9e7c80b5968980c96ea069fe378bfcd8` |
| 287 | `a1c5be1a9d7bba8deb7848bc283cb12680c326dbfe62c228233df40d0c237bc8` |
| 288 | `fa46f4adf8ed6496dee16adba193eedf1280b38030ea143e794627b1fe3feba0` |
| 289 | `2f24044ac84ce75f93561ece82611539fe040c18afb9e75f4231c81a7b18717d` |
| 290 | `8d1a26516743c4899daf91d2f47f9003db050e2c97c83bc6256ae0e36e44dfbc` |

Actual scope: front matter and bibliography; chapter openings, section structure, relevant closing passages and conceptual/definition interfaces; actual projection/space/normalization passages; incoming Schwartz/comb terminology; error-budget and sparse-case interfaces. The author had previously fully read and written283 and the transition-band addition in287. For B05 this role did **not** reread and reprove every interior theorem; separate group reviewers own that task. No upstream frozen volume was reopened. V21 convention evidence remains the parent's actual read at commit `880969bd1ca5e64e3f0d34fb01d25c54562b94e6`, not a new claim of independent upstream reading.

The frozen-body static scan found 350 distinct labels and161 references, no duplicate labels, no unresolved ref/eqref/autoref targets and no labels with another chapter's prefix. Six forward cross-chapter references are explicit orientation rather than hidden proof prerequisites:282→284 best/projection/rational characterization,282→283 spline preview,284→285 rate-space preview and284→290 QR example. The actual proofs do not depend on these previews. Extra enrichment shifted section numbers safely because operative references use labels.

No `notation.tex` exists. This is not itself a defect: the chapters use explicit local definitions and standard LaTeX notation. The absence of that optional preamble file should not cause a false build-input requirement or a duplicate notation policy. The production build should pass only actual existing inputs.

## Actual seams and contracts

| Seam | Actual text checked / result |
| --- | --- |
| Preface→282 | Forward Fourier normalization, a.e. Lp classes and linear-first inner product agree with286–290.282 explicitly chooses continuous real functions and full-interval maximum, distinguishing a finite node maximum. The intended question is clear. Preface locality wording requires G1 below. |
| 282→283 |282's family-choice passage sends piecewise polynomials and matching conditions to283;283 defines strict breakpoints, degree upper bound, smoothness and endpoint values. Interpolation data gain in282 is distinguished from approximation error;283 proves local hats with gain1 and later a global natural cubic coefficient solve. No interpolant is silently called best. |
| 283→284 |283 closes by distinguishing explicit stable maps from minimization over a space.284 defines best error/attainment, proves existence and then treats separate geometries. The natural spline's bending-energy theorem is not passed off as sup/L2 best approximation to an arbitrary target. |
| 284→285 |285 names X=L2(0,1), defines continuous affine S_j with **no endpoint condition**, and explicitly rederives the projection formula and Pythagoras. Thus natural-cubic endpoints from283 do not contaminate S_j.284's main projection proof is real, whereas285 permits complex scalars but supplies the needed conjugate formula and argument. This interface does not leave a complex Gram convention gap. |
| 285→286 |285's closing passage says its L2 rate theorem does not by itself give pointwise convergence and previews a common-band evaluation bound.286 first defines PW_B, proves a continuous representative and bounded evaluation, then samples. This is an effective conceptual transition, not a change of equality convention left to the reader. |
| 286→287 |286 establishes the no-aliasing condition in cycles, including critical equality only in the L2 model.287 explicitly fixes C=1/(2T), B≤C, r=2BT, normalized sinc, canonical point values and the linear-first convention. Its ONB coefficient sqrt(T)s_k and raw synthesis norm sqrt(T) are consistent. Periodic examples remain separate from nonzero L2(R) objects. |
| 287→288 |287 exports sample energy T||s||²=||f||², P_B, and the precise sequence projection Q.288 recalls them, defines finite U and full known complement C, and derives the compressed system. C is now explicitly a set, replacing287's local scalar cutoff C; this local rebinding is clear. RHS, complement-data, completed-sequence and function error norms remain distinguished. |
| 288→289 |289 opens by explicitly changing the unknown from an infinite bandlimited signal to a real finite vector in a known coordinate basis. It separates sparse injectivity, equality-BP uniqueness and robustness. It does not treat strict oversampling as an RIP or NSP hypothesis. |
| 289→290 |The 2×3 RNSP matrix, rho1/2 and tau sqrt5/2, and bound9 sigma1+7sqrt5 eta agree.290 invokes that route for the small case and does not claim that matrix meets P12's RIP condition. Every-minimizer guarantees remain separate from uniqueness of individual solved examples. Periodic coefficient error is converted to signal error using a stated synthesis norm. |
| Earlier models→290 |290 explicitly switches between finite periodic acquisition, infinite complement with one deletion, finite-window approximation and sparse vectors. Its spectral/model/truncation/noise budgets do not infer a tail bound from a finite recording, or a pointwise defect bound from an arbitrary L2 defect. The worked window case genuinely adds finite-tail calculations rather than repeating288.4 only. |

## Actionable corrections, exact text and affected checks

### B05-G1 — Preface overstates locality

**Location:** `frontmatter.tex`, “The path through the book”, first paragraph.

**Original:** `Splines localize the calculation.`

**Reader impact:** sounds as though every spline interpolation algorithm uses only nearby data.283's explicit natural cubic counterexample proves otherwise; its local basis and local data operator are deliberately separated.

**Replace only that sentence with:**

```tex
Splines provide polynomial pieces with local support. We distinguish
that support from locality of the data used to choose their coefficients.
```

**Owner:** parent/front matter. **Recheck:** front matter agrees with `ch283:hats`, `ch283:natural-cubic` and `ch283:local-operator`. No theorem proof or chapter body is invalidated by this wording correction.

### B05-G2 — Preface misdescribes the final two chapters' data models

**Location:** `frontmatter.tex`, final paragraph under “The path through the book”.

**Original paragraph:**

```tex
Chapters 289--290 address finite data and sparse coefficients. In that
setting a linear system can have many solutions while a sparse model or a
minimum-norm rule still selects one. The last chapter follows concrete
data through a reconstruction and checks where the corresponding error
bounds apply.
```

**Reader impact:**290 includes an infinite known complement and its finite-window approximation, rather than only finite sparse coefficients. “Minimum-norm rule” also leaves the L1/L2 distinction vague just where the case study compares them.

**Replacement paragraph:**

```tex
Chapter 289 changes the unknown to a finite vector with sparse coordinates.
It separates sparse identifiability, recovery by minimum $\ell^1$ norm,
and stability under noise. Chapter 290 follows three models through complete
calculations: a finite periodic fit, lost samples and a finite observation
window, and sparse coefficients. Its sparse case also compares $\ell^1$
and Euclidean selection on the same data, so that the choice of criterion
remains part of the reconstruction problem.
```

**Owner:** parent/front matter. **Recheck:**290 opening and sections `ch290:periodic-fit`, `ch290:erasure-window`, `ch290:sparse-case`; no changed mathematical assumptions.

### B05-G3 — State the comb terminology locally or supply a verified prerequisite

**Location:** `ch286:comb`, first paragraph, currently starts “A sampling comb is a distribution ... For the Schwartz space S(R), define ...”.

**Issue:** the preface's listed prerequisites are linear algebra, integration, Hilbert geometry, interval Fourier series and L2 Fourier transform. This paragraph additionally uses Schwartz space, tempered distribution and a Schwartz seminorm without a local definition or an exact verified incoming location. A V21 chapter may provide them, but that exact coverage was not verified by this review and is not needed to make the text self-contained at this seam.

**Small local addition, before `For the Schwartz space ...`:**

```tex
Here $\mathcal S(\mathbb R)$ consists of smooth functions $\varphi$ for
which $\sup_t(1+|t|)^m|\varphi^{(n)}(t)|$ is finite for every pair of
nonnegative integers $m,n$. These quantities are its defining seminorms.
A tempered distribution is a complex-linear functional on this space
continuous for those seminorms. Equivalently, its absolute value is bounded
by a constant times a finite sum of them. Pairings with test functions
are bilinear; they are not Hilbert inner products.
```

The existing nearby bilinear-pairing sentence can then be shortened to avoid duplicate explanation. This does not change the Poisson proof or introduce a new result; it defines the already-used objects. A verified exact upstream reference plus clear prerequisite notice is an alternative, but must not invent an unverified V21 theorem number.

**Owner:**286 author/group reviewer or parent via traceable patch. **Recheck:** distribution transform duality paragraph and Schwartz Poisson statement remain unchanged; no effect on the later direct L2 folding/uniqueness proof. This is a terminology/reading-path repair, not a claim the existing formula is false.

## I13, exclusions and depth interactions

I13 has an actual conceptual thread, not just a heading:282 separates model approximation and propagated sample error, quantifies a denominator margin and explicitly distinguishes deterministic errors from statistical risk;283 proves the local error+noise split and contrasts local versus global coefficient dependence;285 uses a declared H1 penalty and disclaims statistical/inverse optimality.288 later gives a **finite-dimensional** spectral damping calculation with explicit truth/noise assumptions. Its text says no general inverse-problem theory is claimed, so it is a bounded continuation of the same interface, not a silent expansion to a general regularization course.

The mathematical exclusions remain respected: no general Padé/AAA convergence or Newman/Stahl rate; no transfer of unproved not-a-knot order4 to natural cubic; no general Besov/free-knot/endpoints classification; no irregular/Kadec/Landau sampling theorem; no probability or random RIP sample complexity; no dictionary-learning/TV/low-rank theory. The named P13 title in the bibliography is narrow defect corroboration, not coverage of Padé theory. Design's core285 remains q=infinity and0<alpha<1; finite-q sequence remarks explicitly distinguish an abstract error sequence until an actual detail-series construction is supplied in the exercises.

The enrichments contribute different mathematical work at the seams.282's equispaced-data gain prepares the distinction between fitting and stable recovery.285's orthogonal-detail identity adds an exact multiscale reading of rates; its jump example separates class membership from H1 regularity.286's folding operator supplies the observation map under aliasing and distinguishes a minimum-energy selection from truth.287's transition-band kernel changes synthesis while preserving the data model; its faster **local pointwise tail** is not used as a global L2 rate or as a universal ordering of actual errors.288's geometry and spectral damping distinguish inverse margin, perturbation space and useful prior information.290 then computes their consequences with actual data. These are complementary developments; none of the later chapters silently supplies a proof missing from a mandatory earlier theorem.

Some diagnostic examples intentionally recur with a new purpose: x² distinguishes interpolation, uniform minimax and L2 projection; the same one-erasure signal moves from an ideal complement check in288 to an explicit finite-window certificate in290; the same small sparse matrix supports NSP/RNSP proof in289 and a selection-criterion comparison in290. The surrounding text names the changed purpose. Removing every recurrence would damage these bridges. There is no recommendation to add prose or repeat calculations for a page count.

The most demanding local passages are the general rational theorem in284 and B-spline dual/Marsden proof in283. Their hypotheses and auxiliary lemmas are supplied before use; the three group reviewers still own correctness and proof completeness. This seam review does not infer a “reference-level depth” pass merely from word/page totals, nor does it call the present scope a full treatment of every source.

## Handoff and limits

Handoff `V22-B05-READING-PATH-v1`: expansion → parent. Authorized scheme B single Work, current B05; original-A mapping is chapter/whole-volume structural integration before layout. Fixed chapter sources stayed read-only. Parent may apply G1–G3 as small, traceable patches; G3 needs its content-owner check. Rehash affected inputs and update the freeze manifest before B06. If anything substantive changes the operative hypotheses, invalidate and repeat the affected downstream checks rather than redoing untouched chapters.

OPEN RP-1: the three scoped corrections have not been applied by this role. OPEN RP-2: group semantic integration and final body freeze remain parent's combined B05 decision. OPEN RP-3: full-volume source/PDF pairing, engineering, actual all-page independent visual inspection and sole B07 whole-volume audit remain later stages. Historic 16-topic/22-chapter mapping and six global gates remain UNKNOWN and untouched. Actual model/reasoning settings remain UNVERIFIED. No source, template, frozen upstream volume, tool ZIP or official curriculum/reference table was modified.

No user decision is requested: these are routine repairs within the existing authorized volume. Next unique action is parent disposition of G1–G3 plus group-review findings, then B06 only on the fixed integrated body. Internal report and parent notification are delivery evidence; this file is not itself a durable upload or a user-receipt claim. Parent retains packaging/save responsibilities and final authority to combine the independent review outcomes.
