# B05 independent refinement — integrated Chapters 285–287

2026-11-28 UTC · recovery agent as independent refinement reader · B single Work.

**Finding:** the supplied three-chapter mathematical path passes independent whole-reading. The three small Chapter287 contract repairs below were subsequently applied by the controller and independently closed on the newer hashes recorded at the end. No mathematical objection remains from this scoped refinement. No chapter redesign, proof replacement, or reopening of earlier volumes is indicated. This reviewer did not edit chapter files. This is B05 refinement, not the sole B07 whole-volume audit and not PDF/page acceptance.

## Fixed read receipt

Read all 848 lines of Chapter285, 846 of Chapter286, and 974 of Chapter287 directly from the integrated bodies. Independently calculated the proof steps and exercise results rather than adopting author logs or earlier core-review verdicts as evidence. Actual hashes match `qa/b04/chapter-hashes.txt`:

| Body | SHA-256 |
|---|---|
| `chapters/ch285.tex` | `32dc6af4cf9267029727370f49b02fe2d28817cacf83f7e0f8234d3189b03955` |
| `chapters/ch286.tex` | `08fbe90754eb0c9d8dc4e337ff2f95cd9e7c80b5968980c96ea069fe378bfcd8` |
| `chapters/ch287.tex` | `a1c5be1a9d7bba8deb7848bc283cb12680c326dbfe62c228233df40d0c237bc8` |

The fixed B02 design read has SHA-256 `661a4e8d6ab0454120f54e98df0b96c7e3beb5255a34f38af63e4202dc46fb14`; B01 source-responsibility ledger `b01/sampling.md` has SHA-256 `083fc10e778a2f653d4fe4cf143bcef614071128e5e6bbebea32276bf1579e49`. These were used to identify required coverage, not to certify the body proofs. `bibliography.tex` read has SHA-256 `18fcbcb45f97e54360710e69e5ee0e35a52b5c41f4519d45a9fe18eb78917639`.

Also inspected the actual upstream operative bodies at `ch283:hats`/`hat-stability` and `ch284:projection`/`projection-theorem`. The latter is explicitly real, and Chapter285 itself supplies the complex ONB formula and Pythagorean argument, so it does not silently apply an unextended real matrix formula to complex inputs.

Actual model/reasoning-mode setting is not independently observable; no model-switch or High-setting verification is claimed.

## Concrete repairs and exact proposed text

### B05-REC-01 — integer cutoff missing from the off-grid theorem

**Location:** `chapters/ch287.tex:443`, proposition `ch287:offgrid`.

**Current:**

```tex
Let $f\in PW_C$ with samples $s$, and retain exact samples $|k|\leq N$.
```

**Replace with:**

```tex
Let $N$ be a positive integer, let $f\in PW_C$ have samples $s$,
and retain the exact samples with $|k|\leq N$.
```

**Reason/impact:** the proof rewrites the omitted indices as `k=N+1,N+2,…` and starts its integral comparison at N. Those steps require an integer. If the unstated domain is read as allowing an arbitrary real N, the theorem can fail, not just its notation: at T=1, t=A=1/2 and N=1.99, the omitted sinc-square row mass is `1−76/(9π²)`, whereas the asserted bound squares to `2/(1.49π²)`, which is smaller. Choose the omitted sample vector proportional to that sinc row and use cardinal synthesis to realize it as an actual PW_{1/2} input. Thus explicitly stating the discrete cutoff closes a real quantifier gap.

**Recheck:** existing proof and exercises then apply unchanged. No new bound or source is needed. This is a local statement repair; it does not affect the later transition-tail proposition, which already requires N to be a positive integer.

### B05-REC-02 — specify the signal class in the transition-tolerance problem

**Location:** `chapters/ch287.tex:728`, problem “A certified window for a local tolerance.”

**Current:**

```tex
Assume $T=1$, $B=1/4$ and $\|f\|_2\leq1$. Give a sufficient integer
```

**Replace with:**

```tex
Assume $T=1$, $B=1/4$, $f\in PW_{1/4}$, and $\|f\|_2\leq1$.
Give a sufficient integer
```

**Reason/impact:** the solution invokes the exact transition synthesis identity `A_Hs=f`, which requires the spectrum of f to lie in the plateau band, not merely an energy bound. The problem is placed in the appropriate section, but its standalone contract should state the class that licenses this operative identity. With only an arbitrary L² input, samples may be undefined; even a larger-band continuous input need not be fixed by H.

**Recheck:** the supplied solution is correct for this explicit class, with `E_N≤1`, K=`4√(2/3)/π²`, and the stated sufficient integer windows. No solution formula changes.

### B05-REC-03 — specify the signal class in the interior-truncation problem

**Location:** `chapters/ch287.tex:891`, problem “Interior versus global truncation.”

**Current:**

```tex
Let $T=1$, $\|f\|_2\leq1$, and retain exact samples $|k|\leq100$.
```

**Replace with:**

```tex
Let $T=1$, $f\in PW_{1/2}$, and $\|f\|_2\leq1$,
and retain the exact samples with $|k|\leq100$.
```

**Reason/impact:** the conclusion uses the sample-energy identity and the critical cardinal formula, both on PW_{1/2}. An energy bound alone neither defines point sampling of an L² class nor controls interpolation between finite observations. The explicit class also makes the solution's omitted-cardinal-function counterexample belong to exactly the unit ball named in the question.

**Recheck:** the solution's bound `√(2/(90π²))` and its global counterexample remain correct unchanged. This repairs the reader's selection of the theorem, not its proof.

All three proposed changes are narrow clarifications within the existing thesis and section boundaries. The reader-contract exercises should receive the repairs before final reader acceptance; the core derivations have no remaining mathematical defect identified in this pass.

## Independent proof-path and coverage findings

This table records actual body evidence and its approved source responsibility. “Verified” concerns the selected B02 specialization, not all general results in each source or every optional item in the earlier candidate ledger.

| Source/responsibility | Actual operative body and independent check |
|---|---|
| P6 §§4.1–4.3; 285-D01–03, D06, P01/P02 as narrowed by B02, P06 | `ch285:dyadic-spaces`, `best-error`, `approximation-class`: continuous affine S_j, dimension2^j+1, nesting/density, actual orthogonal attainment, error Lipschitz bound, full norm/completeness and exponent inclusion. The general finite-q/nondyadic classification is not promised by B02; its omission is not a coverage gap. The sequence-versus-function distinction is explicitly resolved later by an actual orthogonal-detail construction. |
| P6 §4.2, especially (4.5), (4.9), (4.11); 285-D04–05, P03–05 | `ch285:k-functional`, `k-facts`, `k-dyadic`: full H¹ norm, no boundary condition, no assumed minimizing competitor. Independently verified min(1,t)||f|| lower bound; K(f,1)=||f||; monotonicity/concavity; dyadic constants; separate M0/M1 operator scaling. Full H¹ is an explicit adopted convention, not an unnoticed copy of a seminorm formulation. |
| P6 §4.3 framework, selected elementary proof; 285-T01–03 | `ch285:jackson`, `bernstein`, `main-theorem`: nodal interpolation acts only on H¹ representatives; local integral inequality and removal of the mean derivative give h/√2; affine completion of the square gives √12 and full √13 inverse constants. The reverse theorem uses actual P_j increments and a geometric sum only for0<α<1, retaining the ambient term. The forward/reverse statements are proved in the body, not delegated to unread DeVore–Lorentz. |
| 285-E01–03 and original enrichment | `ch285:quadratic`, `detail-rate`, `endpoint-failure`, `step-rate`: independent moment integration checks errors h²/√30 versus h²/√180. Orthogonal tail identity gives both exact sharp detail constants. Disjoint tent example has each derivative energy4 and summable mass; jump adjacent-cell completion gives h/8 lower and h/6 upper squared errors, hence exponent1/2. Every exercise solution was read, including the actual rank-one failure of a merely L²-bounded operator. No unproved Besov identity or interpolation endpoint was inserted. |
| P7 §§5.5–5.9; P8 §§6.20.1–3; 286-D01–04, P01, T01–02, E01–05 | `ch286:pw-definition`, `representative`, `evaluation`, `units`, `poisson`, `periodization`, `alias-packet`, `nyquist-theorem`: a.e. support is separated from canonical point values; cycles versus angular factors are consistent; Schwartz Poisson is proved before its distribution use. The real L² alias packet has two disjoint spectral intervals and energyδ. Critical equality is justified by Fourier completeness and a.e. endpoints; endpoint tones are explicitly excluded from L². |
| Original exact fold extension, built from the same canonical inverse integral and Fourier basis | `ch286:fold-definition`, `fold-theorem`, `fold-energy`, `fold-nullspace`, `fold-minimum`: sheet multiplicity has essential maximumceil(2BT), including integer overlaps. The Parseval coefficient is√T s_n. Sharpness uses equal sheets on positive-measure maximal-multiplicity fibers. The supported range condition is G=0 where m=0; fiberwise equal division gives the unique minimum-energy preimage and exact orthogonal split. Independently checked energies3/2→5/2 and1→2 in overlap witnesses, and minimum energy3/4/distance1/2 for the unit-sequence example. |
| P9 §II projection viewpoint; 286-D05/P02 and selected periodic bridge | `ch286:model-selection`: P_B projection and removed-energy norm are proved; instrument data are samples of the filtered target. Finite-window nonuniqueness uses a genuine nonzero L² spectrum, and the preview explicitly changes to a finite-dimensional periodic model. The full finite periodic calculation is assigned to290 by B02, so it is not a missing theorem here. |
| P7 §5.7; 287-D01, P01/P02, T01–03 | `ch287:onb`, `sample-energy`, `kernel`: the scaled sinc transform is√T times an exponential indicator. Completeness precedes the expansion, avoiding circularity. Both sample-energy factors T and raw synthesis gain√T are verified. The common-band evaluation bound converts L² to global uniform convergence. Pointwise absolute convergence has its own sinc-square proof. |
| P7 oversampling allowance and P9 projection model; 287-D02/D03 and exported operator interface | `ch287:band-projection`, `frame`, `sequence-projection`: filtered kernel has factorr=2BT; Parseval frame vectors have norm²r; Q is constructed by unitary conjugation before row algebra. The raw and normalized sequence ranges are the same subspace by scalar multiplication. Matrix entries, absolute row sums, exact row massr, and fixed-point characterization are proved in the body. This exactly supplies Chapter288's consumed domain and norm facts. |
| Derived stability from the proved ONB; 287-T04–06, E01–03, E05 | `ch287:noise`, `window-identity`, `offgrid`, `model-budget`: exact raw error versus projected contraction, noise/tail disjoint supports, local versus global error, bounded amplitude versus ℓ² energy, and correct orthogonal model/data split. The square-root-T and square-root-r factors are consistent. The projection output remains in PW_B; the raw output may be in the larger band, where the text correctly declines the orthogonal split. The displaced-interval argument gives δ||f'||² for disjoint intervals and identifies common-shift output separately. |
| P9 §II filter freedom as motivation; independently proved smoothing extension | `ch287:trapezoid`, `transition-kernel`, `transition-synthesis`, `transition-tail`: the convolution rectangle widths give plateauB and supportC; inverse product has coefficient2B+d and denominatorπ²dt². Exact valid-target synthesis is proved through H=1 on the target band, with sharp L² gain√T and absolute/uniform convergence. Cauchy–Schwarz plus the fourth-power tail gives √(2/3)/(π²dT)(N−a)^−3/2. The text does not claim actual-error ordering or a global tail rate; it explicitly records the output shoulders and loss of uniform constant as d→0. The numerical example and all three new smoothing solutions check. |

## Actual sources and reference types checked

Read the public source windows themselves for the current check: P6 §§4.1–4.3, especially printed pp.82–87; P7 §5.7 printed pp.229–230; P8 §3.5.9 sinc convention and §§6.20.1–6.20.3 printed pp.209–214. P8's formula is sin(u)/u and its general-signal strict Nyquist condition has the endpoint-impulse qualification; the body converts both correctly.

Independently rendered and visually inspected P9 physical PDF page15/printed583, Appendix A. The intermediate line of(A.8) indeed displays a positive shift phase inconsistent with substituting y=x−k in the stated negative Fourier kernel. The body's negative-phase derivation is correct, and its restrained “apparent misprint” source note is supported. Screenshot check saved at `qa/b05/source-checks/P9-appendix-A.png`; this is a source-formula check, not manuscript page QA.

All cited keys P6/P7/P8/P9 resolve to actual bibliography entries with the expected versions; no excluded Q1/Q2 or unread R1–R4 is used as proof evidence. All named internal reference types were checked against the actual targets: the dyadic K result is a lemma, the main/detail results are theorems, endpoint failure is an example, representative is a theorem, evaluation/derivative are propositions, and fold-minimum is a proposition. References to hats/projection/K-functional are correctly called sections. No named type correction is needed in these three bodies.

The exact V21 §274.4/§274.6 authority remains the controller's separately read upstream evidence. This subtask has not independently reopened the V21 fixed PDF and does not manufacture that receipt. The supplied Plancherel normalization is internally consistent throughout this three-chapter path.

## Handoff

ID `V22-B05-REC-285-287-v1` · independent recovery refinement → parent controller. Scope is only frozen285–287; no chapter file edits, no changed chapter title/boundary, no source-table or template mutation. Exact proposed repairs above are ready for owner/controller application. Recheck only those literal changes and new chapter hash, then continue whole-volume B05 integration; do not redo the proved mathematical developments or restart B04. Compilation, all-page visual QA, source/PDF pairing, B07 final strict audit and B08 authorization remain distinct later evidence. Parent owns durable save and combined handoff. No user decision is needed within this scope.

## Independent closure on the controller's B05 repairs

While this report was being completed, the controller supplied newer Ch286/287 bodies. Recovered the exact frozen starting versions from `layout-prep/tools/runs/b04-integrated-preview/inputs/04-ch286.tex` and `05-ch287.tex`, independently verified that their hashes match the initial receipt above, and compared their full textual deltas against the current bodies.

| Current body | SHA-256 | Closure |
|---|---|---|
| `chapters/ch285.tex` | `32dc6af4cf9267029727370f49b02fe2d28817cacf83f7e0f8234d3189b03955` | Unchanged from whole-read input |
| `chapters/ch286.tex` | `1bb0d28876825027f7e73b8e481992e17f186af7a5290aeab9598bdd39e14fcc` | Only the comb/Schwartz reader prerequisites changed; checked below |
| `chapters/ch287.tex` | `39025ba733703e830227e712e47461947e65f6f4b08ac36fd7e26190062175c6` | Exact three local statement repairs; B05-REC-01/02/03 closed |

Ch286 now explicitly defines the Schwartz seminorms, tempered linear functionals and the Dirac evaluation, bounds the comb by `p_{2,0}(φ)Σ_n(1+|nT|)^−2`, and explains the differentiation/integration-by-parts route showing that Fourier transforms preserve Schwartz class. All are correct under the already declared T>0 and bilinear distribution pairing. They remove a reader prerequisite gap without changing the periodization/folding operators or any constants.

Ch287 now states N is a positive integer in `ch287:offgrid`; gives `f∈PW_B` with B=1/4 in the transition-tolerance problem; and gives `f∈PW_{1/2}` in the interior-truncation problem. These are the exact logical repairs requested above. Proofs and solutions remain unchanged and valid. No new defect was introduced by these deltas. This closes the current scoped B05 refinement; proceed to integrated layout and the separate B07 audit without redoing the proven body.
