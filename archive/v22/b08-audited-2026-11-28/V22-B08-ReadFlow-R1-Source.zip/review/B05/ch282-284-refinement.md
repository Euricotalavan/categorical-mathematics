# B05 independent refinement and reading-path review — Chapters 282–284

2026-11-28 UTC · reviewer case_study · B single Work. Parent assigned independent full reading of these three chapters; none was authored by this role. No chapter file was edited. Actual requested runtime model/High setting remains independently unverified.

## Exact read-in receipt

All three complete TeX bodies were actually read, including every proof, worked example and complete exercise solution. The one tool-output truncation in Chapter282's middle was recovered by an explicit overlapping read of lines450–650. Reads were checked against `qa/b04/chapter-hashes.txt`; hashes were unchanged at the final check.

| Unique source | Bytes | SHA-256 | Read scope |
|---|---:|---|---|
| `chapters/ch282.tex` | 44,705 | `a97ead2e82f6ad4d90bd3f6ef9619e9bc2e49da342b6ee784d2ec5f00cd72d3c` | Full1035 lines, all9 problems and solutions |
| `chapters/ch283.tex` | 53,168 | `a8b7c82b248c9ee5c6272a58dd27f240c6ffe424e15da953c09c756dd67302e6` | Full1266 lines, all10 problems and solutions |
| `chapters/ch284.tex` | 46,449 | `9ad7973dfbb4ca2b84cc4160d187246553c6d70521625f05a1f303672cb4ca82` | Full1098 lines, all10 problems and solutions |

Also consulted fixed B02 responsibilities/exports, authoring conventions, B01 approximation source-window/scope ledger, and the actual-body/source maps in `contributions/approx.md` and `contributions/splines.md`. This is a direct manuscript mathematical/reading review; it does not claim a new independent read of every source PDF or the frozen V21 PDF. Source-window access claims are inherited only as explicitly identified in those records. Source/body scope was checked against those fixed boundaries, not inferred from citations alone.

For the outgoing interface, actually read Chapter285 lines1–140 as well: its S_j has no endpoint constraints, its complex-valued option supplies the correct conjugated orthonormal projection formula explicitly, and its use of hats/projection is consistent with283–284. This is an interface read, not a full review of285.

## Disposition

**No blocking mathematical defect or material reading-path defect found in the three exact bodies. No mandatory repair is requested.** Definitions needed for the operative theorems precede use; hypotheses are available on entry; complete solutions justify result selection and constants. The conservative gate is semantic readiness of this block for continued B05 integration, not whole-volume final acceptance.

One small optional wording repair is supplied below because it makes a central distinction clearer. It changes no theorem, proof, assumption or interface. Do not delay integration or restart a passed construction to perform cosmetic rewrites.

| Position / original | Reading effect | Exact optional replacement | Recheck needed |
|---|---|---|---|
| Ch283, `ch283:problem-point-evaluation`, final solution paragraph: “Restricting to continuous representatives removes the second ambiguity for that subspace” | The problem lists class-definedness before boundedness, whereas the solution discusses boundedness before class-definedness. “Second ambiguity” can therefore be read as the boundedness failure, which the next clause correctly says persists. | “Restricting to continuous representatives removes the representative ambiguity for that subspace, but the spike example still prevents an $L^2$ boundedness estimate there.” | Read the two closing sentences together; no formula or downstream proof changes |

## Chapter 282 — what was independently checked and should be kept

| Actual location | Independent check / reading conclusion |
|---|---|
| `models` and interval scaling | Real C[a,b], a<b, degree-at-most convention, zero-degree convention, max existence and data-vs-between-node errors are stated before use. The spike and x³−x examples distinguish norms and finite data. Affine scaling retains the derivative factor h^k |
| `lagrange`, `remainder` | Distinct-node/empty-product conditions explicit. Construction, uniqueness, partition and reproduction are proved before perturbation analysis. The remainder handles nonnodes by n+2 distinct zeros and Rolle, then nodes separately; derivative order is correct |
| `lebesgue-gain`, `equispaced-amplification` | Exact gain and sign-pattern sharpness correct. Small Λ2=5/4 verified. Equal-grid product bound at t1/2, telescoping lower bound1/[2(n+1)], binomial maximum, affine invariance and worst-case perturbation construction are connected. Numeric n20/n32 comparisons retain lower-bound vs upper-bound directions and do not claim all perturbations or all targets diverge |
| `chebyshev-properties`, `monic-chebyshev` | Recurrence, leading coefficient, roots/extrema, parity, roots vs Lobatto and reversed ordering are explicit. Strict improvement/root count proves the monic lower bound without a weak-sign shortcut. Scaled node polynomial factor h^(n+1)2^−n correct; no targetwise-best interpolation claim |
| `barycentric-formula` | Denominator identity established before division. Node values separately specified; common weight scaling and arbitrary-weight pole examples correct. O(n) evaluation count is separated from floating-point stability |
| `bernstein-moments`, `weierstrass` | n1 factorial edge handled. Near/far proof keeps positive weights and uniform constants; epsilon/delta/n order correct. x² exact error1/(4n), nonsmooth B1/B2 values and Lipschitz bound1/(2√n) verified |
| `rational-type`, `defect`, `rational-difference`, `choice` | Allowed/exact type, reduction, positivity, cancellation/poles and zero defect convention precede use. Difference degree bound uses the reduced candidate and treats zero separately. P3 correction is stated with independent source identity. Explicit polynomial sequence has exact error2^(−N−1); denominator perturbations are typed and remain in the same admissible family |
| Nine complete solutions | Repeated-node/derivative distinction; quartic actual/remainder bounds; spike energy; scaled monic cubic; bad barycentric poles; third Bernstein moment; cancellation/defect; N9/degree18 tolerance distinction; and noisy-data bound all checked. No solution infers function error from zero nodal residual |

Source-to-body scope remains compatible with fixed P1a Ch2–6, P1c Ch24, P2 Bernstein/Chebyshev/approximation sections and the narrow P3/P13 correction. Added remainder, equal-grid lower bound, budget and representation examples give their own proofs. No unread Chebyshev-series, Padé, AAA or rational-rate theorem is asserted as core content.

## Chapter 283 — what was independently checked and should be kept

| Actual location | Independent check / reading conclusion |
|---|---|
| `spaces`, `dimension` | Right-value/left-endpoint conventions remove arbitrary jump values. Truncated-power expansion, independence and dimension handle r_i=−1 and r_i=p. Degree/order and actual cell width are defined before use |
| `hats`, `hat-stability`, `linear-error-theorem` | End hats include n1. Convexity, exact gain1, local data support and modulus convergence are proved. Rolle argument gives sharp h_i²/8 bound; x² signed residual, unequal cells and noise corollary correct |
| `natural-cubic`, `cubic-piece`, `cubic-system`, `natural-existence` | Endpoint problems distinguished; cubic reconstruction, endpoint slopes and positive-length tridiagonal system derived. Diagonal-dominance nonsingularity is actually proved. n1 explicit. Three-node C2 spline and1/54 error correct; bending-energy integration by parts valid for C2 competitors; remote-datum first-cell change ε(x−x³)/15 correct |
| `bspline-recursion`, `bspline-support` | Open knot indices, multiplicity≤p+1, whole zero-denominator term, half-open initial indicators and final b left value specified. New knot mesh explicitly replaces unrelated earlier Δ. Pointwise supremum for possibly discontinuous splines is not falsely asserted attained |
| `marsden`, `bspline-derivative` | Local dual affine recurrence, finite active indices and positive active denominators checked. Monomial coefficient comparison gives local basis and dual independence before derivative comparison; no circular assumption of global basis or partition |
| `bspline-smoothness`, `bspline-basis-theorem`, `partition-greville` | Local multiplicity p central/support-end cases and lower-multiplicity induction supply promised matching; derivative and right-value conventions align. Every global basis function contains a positive span; local independence plus actual dimension proves global basis. p0 and final endpoint partition handled separately. Greville reproduction uses p≥1 |
| `local-error`, `greville-error` | Domain C[a,b], compact data supports, independent uniform functional bound, reproduced degree and J⊂[a,b] are explicit. Taylor estimate follows local polynomial comparison. Greville continuity at full multiplicity is proved from matching repeated sampling points; C2 error follows affine reproduction and actual support-length bound, not basis degree alone |
| Ten complete solutions | Mixed-smoothness dimension/vector, noisy unequal-cell error, tolerance condition, clamped uniqueness, natural lower-rate obstruction, remote dependence, explicit quadratic recurrence, active/data supports, L2 point-value failures, and reproduction counterexample all checked. Natural lower bound2h²/81 follows a correct cubic finite-difference identity |

Source scope is fixed P4 §§5.2–5.3 and P5 local dual/Marsden/derivative/multiplicity/basis/local-operator windows. `contributions/splines.md` explicitly records source-access closure and its original proof expansions. The body supplies those prerequisite arguments itself rather than presuming source labels are proofs. The not-a-knot fourth-order assertion remains excluded from the natural problem; no unproved general Lq/derivative-approximation theorem has been imported into the selected sup-norm statement.

## Chapter 284 — what was independently checked and should be kept

| Actual location | Independent check / reading conclusion |
|---|---|
| `finite-compactness`, `finite-existence` | Coordinate norm bounds precede compactness and closedness; minimizing sequence bounded then convergent subsequence used. No unnecessary completeness or arbitrary closed-set existence assumption. Nonuniqueness example and distance Lipschitz inequality correct |
| `sign-blocks`, `uniform-improvement` | Opposite compact extremal sets have positive separation; greedy sign blocks are finite and give actual extremum-free gaps. Perturbation proves a strict uniform margin both near extrema and on the compact complement, with sign/non-crossing and denominator bounds explicit |
| `polynomial-alternation` | Existence, strict-root sufficiency, signed-direction necessity and midpoint uniqueness are separate and valid. Exact-zero and n0 cases preserved; full P_n distinguished from arbitrary finite subspaces |
| `lower-certificate`, `remez-system` | Fixed-node system square and nonsingular; positive alternating residual lower bound separated from global upper certificate. x³→3x/4, T3/4 error and failed initial grid example correct. No unproved Remez convergence or grid upper-bound assertion |
| `projection-theorem`, `orthonormal-projection` | Real genuine inner product and arbitrary candidate explicit. Positive-definite Gram, normal/orthogonality/minimization equivalence, conditional Pythagoras, linearity, contraction and V0 case correct. Weighted sampled forms remain semidefinite globally and positive definite only after rank check on chosen space |
| `removable-ratio`, `rational-existence-theorem` | Positive normalized q prevents zero denominator limit. Bounded pair gives polynomial limits; ratio limits are used only off denominator zeros. Full vanishing orders, including one-sided endpoints, remove poles and continuous error inequality extends across. Example correctly denies uniform quotient convergence to the cancelled limit |
| `rational-directions`, `weak-sign`, `rational-alternation-theorem` | Candidate defect gives degree bound. Coprime kernel(ph,qh), rank-nullity surjectivity and p0 case correct. Exact rational difference t(qu−pv)/[q(q+tv)] preserves type and positive denominator. Weak-sign leading-coefficient identity handles zeros without shared-endpoint double counting. Uniqueness uses cross multiplication, not an invalid rational arithmetic midpoint |
| Rational certificates and ten complete solutions | c/(1−d0t) stationary point/global error verified; t=x² gives correct five-point alternant and defect table; zero numerator case retained. Quartic certificate, cubic L2 error8/175, weighted sampled Gram solve/error1/16, incomplete exponential Remez, rational direction, family-change, weak signs, pole-order and noisy projection solutions all checked |

Source/body scopes agree with P1b Ch10, P1c Ch24, P2 §§6.3–6.4 and P3 statement with explicit correction. Finite compactness, margin and weak-sign arguments are written out rather than delegated to unread sources. No complex rational uniqueness, universal rational Remez theorem or arbitrary Banach-space projection claim is asserted.

## Integrated reading path and verification evidence

The path282→283→284 works in order. Chapter282 defines polynomial/rational types and records the defect-dependent difference bound before284 uses it. Chapter283 independently derives pieces and operators without needing best approximation; it closes by distinguishing explicit maps from later minimization. Chapter284 then proves existence/geometry. Early forward references are signposts, not premises needed for earlier proofs. Both283 and284 hand the later dyadic analysis a continuous affine space with no cubic boundary condition, and a genuinely normed finite-dimensional projection theorem. No natural endpoint restriction leaks into that interface.

Static integrated-source check:21/41/22 unique labels in282/283/284 respectively, no duplicates in these chapters, every ref/eqref target in this block exists in current integrated sources, and problem/psolution counts agree9/9,10/10,10/10. Counts supplement the actual reads; they do not establish completeness by themselves.

Independent exact symbolic spot-checks passed for the three-node natural spline's values/C2 joins/error1/54, Bernstein cubic moments for n1–8, rational certificate endpoint/stationary values, and weighted sampled Gram solve(−1/8,1). The first symbolic run used structural equality on two equivalent factorized expressions and failed that comparison; replacing it with simplification produced zero exactly. This was a checker-expression issue, not a manuscript defect. The rest of the calculations above were rederived from the stated formulas during the full read.

No PDF was read in this B05 assignment. Compilation, page fitting, source/PDF pairing and all-page visual QA remain separate B06 work; sole strict whole-volume B07 acceptance remains pending. This report neither changes nor unfreezes earlier volumes, source files, extractor, curriculum or template. Parent receives this shared-file report and may apply the optional one-sentence clarification; substantive future changes require checking their actual new hashes and affected dependencies. No user decision or approval is needed for the present report.
