# B05 independent refinement: integrated Chapters 288–290

V22-B05-RECOVERY-REFINE-v1 · 2026-11-28 UTC · `/root/sampling` → parent coordinator. This reviewer authored Chapters285–287, not the reviewed Chapters288–290. Full sequential read covered all current lines in each of the three chapters, including every problem and solution; no chapter file was changed. This is a B05 refinement finding, not the sole B07 whole-volume mathematical audit.

## Exact received body

Read `qa/b04/chapter-hashes.txt` first, then checked the actual files before and after the read.

| File | Bytes | Lines read | SHA256 |
|---|---:|---:|---|
| chapters/ch288.tex |49120|1–1106|`fa46f4adf8ed6496dee16adba193eedf1280b38030ea143e794627b1fe3feba0`|
| chapters/ch289.tex |41094|1–936|`2f24044ac84ce75f93561ece82611539fe040c18afb9e75f4231c81a7b18717d`|
| chapters/ch290.tex |55402|1–1142|`8d1a26516743c4899daf91d2f47f9003db050e2c97c83bc6256ae0e36e44dfbc`|

Also read fixed B01 recovery responsibilities/source windows, B02 interfaces, the actual operative Ch286/287 labels and statements, relevant Ch285 rate-family contract, and, **after independently reading the body**, prior B04 review history to preserve already repaired findings. V21 convention evidence remains parent-read and transmitted, not independently reread upstream by this reviewer. Runtime model/High setting is not independently exposed and remains UNVERIFIED.

## Only requested functional fixes

The proved recovery formulas, quantifiers, constants, error models and solved examples pass this independent read. Two local definition/type defects remain in Chapter290. Neither requires changing a model, proof conclusion, source authority, or other chapter.

### B05-R290-1 — remove an unexplained pseudoinverse symbol before it is needed

- Location: ch290.tex lines42–43, under `ch290:case-contract`.
- Current: “For example, if an algorithm is given a matrix $A$ and $y$, it may compute $A^\dagger y$.”
- Impact: no definition, recall, or usable upstream reference for the dagger occurs here; the symbol is unnecessary for the point being made. The first concrete least-squares construction is proved later, so the opener need not silently require a pseudoinverse convention or a uniqueness policy in a rank-deficient model.
- Exact replacement for these two lines:

```tex
For example, an algorithm given a matrix $A$ and a data vector $y$ may
choose a least-squares coefficient vector from those supplied data.
```

Keep the following simulation-truth sentences. This preserves the information-contract point and introduces no new theorem.

### B05-R290-2 — correct the types in the spike solution and define evaluation

- Location: ch290.tex lines1009–1011, solution of `ch290:problem-spike`.
- Current: “In $y=Ap+Eq_h+e$, the finite-solve estimate needs a bound on $\|Eq_h\|_2$, not just $\|q_h\|_{L^2}$.”
- Impact: $A$ was defined as a matrix on coefficient vectors in $\mathbb R^3$, whereas $p$ denotes a function. The new evaluation map $E$ is not defined. The preceding spike construction is correct; only its final typed observation equation needs repair.
- Replace that sentence and its following finite-frequency sentence by:

```tex
Let $\theta\in\mathbb R^3$ be the model coefficient vector and define
$Eq=(q(0),q(1/4),q(1/2),q(3/4))^{\mathsf T}$ for continuous periodic $q$.
In $y=A\theta+Eq_h+e$, the finite-solve estimate needs a bound on
$\|Eq_h\|_2$, not just $\|q_h\|_{L^2}$. A finite-frequency defect space
has a bounded evaluation map, or one can supply a direct sample-defect budget.
```

Keep the last two sentences calculating the known Fourier-defect observations. The corrected equation makes the distinction between the function defect and its data vector actually usable.

**Disposition:** Chapters288–289 require no functional correction from this read. Chapter290 is ready after the two bounded edits above and a reviewer delta check. Do not revisit the correct computations merely to shorten prose; repeated explicit model checks and complete solutions carry distinct information.

## Interface checks against the actual preceding body

| Interface | Actual check / consequence |
|---|---|
| Fourier model | Ch288 line19 and Ch290 line385 restrict the ordinary transform integral to L1∩L2 and invoke its unitary extension; canonical PW_B point values are used. B is one-sided cycles frequency and r=2BT throughout. P10's angular edge σ converts by B=σ/(2π), so its r=σT/π matches exactly. |
| Label types | `ch286:pw` is a section and is called Section. `ch286:representative` is a theorem; `ch286:evaluation` is a proposition. `ch287:sample-energy`, `band-projection`, `sequence-projection` are actual operative theorems and are called Theorem. Ch288's strict-gap, inverse, row and finite-erasure claims use their actual distinct labels. No stale source result number replaces a local result. |
| Scaled versus raw samples | Ch287's U_Tf=√T(f(kT)) is unitary; raw R_T has norm√T. Ch288 correctly uses **raw** s_k=f(kT), TΣ|s_k|²=||f||², Q_jk=r sinc(r(j−k)) without an extra T, and projected function gain√(T/γ). Its uniform gain√(r/γ) uses the actual output band. The T2,B1/8 exercise gives D,√2D,2D,D in the right order. |
| Raw Fourier coefficients / DTFT | No consumer treats a raw sample sequence as normalized Fourier coefficients. The r-normalized kernel is inherited from the raw-sampling conjugation in287. Ch290's finite complex DFT uses F*=conjugate transpose, Gram mI and F*y/m; this is finite periodic data with its own declared Euclidean norm, not an infinite real-line DTFT or a second normalization of U_T. |
| Q and convergence | Ch288 uses the bounded orthogonal projection, finite blocks R_UQE_U/R_UQE_C, and ℓ2 row norms. It proves scalar RHS sums absolutely convergent before using them. The block identity K_UK_U*=S_U−S_U² is a legitimate compression of Q²=Q, not an unproved formal infinite product. |
| Band projection | In both Ch288 and Ch290, arbitrary perturbed assembled sequences are projected before claiming narrow-band function error. The equality separating window noise and omitted tail is in sequence space; projection is used as a contraction, not as an assertion that projected error contributions remain orthogonal. |
| Critical versus strict regime | Exact full-lattice critical sampling remains valid, while a missing cardinal coefficient at r1 is nonidentifiable. Ch290 explicitly changes to T1,B1/2 for that example and separately identifies sinc(t) outside the narrow PW1/4 model. No counterexample is silently moved between bands. |
| Finite versus infinite data | Ch288's ideal complement is all C; the finite W model pads only as an approximation and carries a tail. Its finite-window prescribed-value construction uses positive finite Gram S_V, not an unsupported infinite inverse. Ch290 neither uses simulation truth in the algorithm nor subtracts an unobserved value to compute b: it cites the independent odd-square identity first. |
| Ch285 approximation-space bridge | Fixed resolution/dimension and best-term coefficient selection remain different models. Ch289 uses a union of coordinate subspaces and a magnitude-selected best-term tail, and Ch290 specifies the synthesis norm. Neither chapter incorrectly imports a fixed-grid smoothness converse, endpoint identification, or a coefficient-to-function isometry without a basis. |

The Ch286 folding addition and Ch287 transition-window addition do not alter these exports; Ch288–290 do not use their additional theorems. This review makes no independent acceptance claim for those additions beyond the operative interfaces checked here.

## Existence, error conditions, and every solved problem

| Body checked | Evidence and result |
|---|---|
| Ch288 finite inverse | Both 0<S_U and I−S_U>0 are independently proved by a nonzero finite trigonometric polynomial on passband/complement intervals. The inverse gap, condition number, residual and iteration bounds follow in the stated finite Euclidean space. No positivity-only shortcut or infinite-erasure extrapolation remains. |
| Ch288 arbitrary erasure gain | LL*=M_U^−1 S_U gives exact gain sqrt((1−γ)/γ); the attaining input L* v/||L* v|| is valid because λmax>0. Orthogonal coordinate supports give exact assembled gain1/√γ. The independent scalar RHS gain remains1/γ. |
| Ch288 regularization | (M+λI)^−1 is justified by positive spectrum for λ≥0. Bias/noise eigenwise factors, separate exact norms, and known-data gain maxθ θ(1−θ)/(1−θ+λ)² are correct. The norm-only optimum distinguishes increasing/decreasing/constant budget correctly; no data-based choice is inferred from truth. |
| Ch288 all10 solutions | Three scalar problems check translated index invariance, exact finite odd-sum tail and r3/4 gains/critical failure. Seven general problems check two eigendirections, n15 versus14 iteration guarantee, positivity countermodel, four error spaces at T2, finite-acquisition nullspace, sharp norm-ball regularization and orthogonal spectral bias/noise. Decimal roundings and budgets agree with exact formulas. |
| Ch289 definitions and existence | Support/tie rule/Σ_s/best tails are typed; nonlinearity example works even when2s>N; sparse injectivity equivalence covers s0 and saturated dimension. BP existence uses a nonempty compact sublevel. NSP equivalence treats every sparse input and all other feasible competitors. |
| Ch289 quantitative proofs | RNSP uses the top-s truth support for the cone and a separately defined top-s **error** support for final ℓ2 control. The stated constants9 and7√5 for the small matrix follow. RIP squared norms, k>N saturation, small Gram spectrum0,1,3 and δ3=δ4=2 are correct. P12 exact/near proofs use their own coherent constants and last-block conventions; every-minimizer quantification follows from feasibility/minimality alone. |
| Ch289 all8 solutions | Ties, explicit sparse alias, equality/noisy BP including separate saturation uniqueness, short final block, actual scaled-identity RIP countermodel, RNSP scaling, coefficient-tail versus data radius, and identity-matrix feasibility were each checked. No noise guarantee is applied with excluded truth. |
| Ch290 periodic case | Gram diag4,2,2; QR; coefficient gain1/√2; function gain1/2; residual direction; enlarged defect-data vector and exact squared error179/20000; poor-grid eigenvalues2±2|cosα|; invisible periodic function and spike obstruction all check. Ordinary and averaged data norms have distinct correct adjoints. |
| Ch290 erasure/window case | Actual T1,r1/2, odd data and complement gain1; M2 missing error1−8/π², function error²2−28/π²+96/π⁴; two-erasure finite RHS, outputs3809/(450π²),203/(150π²), tail and exact Gram polynomial check. Band mismatch adds explicit −2ρ0, not hidden tail/noise. |
| Ch290 sparse case | Equality BP breakpoint proof; dense least-norm error1/√3; chosen noisy minimizer; diagonal sparse/dense constrained uniqueness; δ1/100 dense squared error417/1250; median near-sparse error√3κ; bad-matrix NSP failure all check. The noisy-disk minimum exists by continuity on its nonempty compact disk; strict convexity then supplies uniqueness (the body's compactness inference is routine, not a new missing hypothesis). |
| Ch290 all8 solutions | Averaged adjoint, finite DFT residues, spike, window/noise allocation, sharp complement gain, constrained sparse/dense errors, near-sparse/matrix failures and final hypothesis diagnosis all have complete reasoning, with only the typed equation fix requested in the spike solution. |

Numerical/algebraic evidence: reran the existing exact `checks/check_cases_b02.py` after reading the actual formulas; PASS for periodic, erasure/window and sparse/dense cases, projected two-erasure L2 error0.361680499997. Independently recalculated n1375 for r0.99's1e−6 reduction; regularization errors0.5503876788 and0.3713264038; safe upward P12 constants10.48 and16.25 from exact values10.4721359550 and16.2472393434. These calculations supplement the actual proofs, not replace them.

## Source responsibility to actual body

B01 source windows were checked against actual body claims, not only “covered” flags. In this review I reread the locally fixed P10 introduction/equations(1)–(2) and their stated r/unit convention; P12 Theorem1 statement and Theorem2/tail discussion; the rest of source provenance below rests on the actually read B01 window record, while this B05 independently checked the full textbook derivations. No fresh full-source-PDF reread is claimed. Source extractor status and final whole-volume completeness remain separate.

| Fixed B01 responsibilities | Actual locations read / scope result |
|---|---|
|288-D01–D04|`ch288:data-contract`, `finite-erasure-data`, `window-perturbation`, `noise-tail-energy`: object/grid/complement/window/noise defined separately.|
|288-T01/P01|`ch288:erasure-equation`, `q-entries`, `blocks`: full known RHS and absolute convergence, all r/T factors consistent with287.|
|288-T02/P02/T03|`ch288:strict-gap`, `passband-form`, `complement-form`, `inverse-norm`: full strictness proof, uniqueness and exact spectral consequences.|
|288-T04/T05|`ch288:residual-certificate`, `iteration`, `iteration-error`, `neumann-error`: explicit residual/input/iteration distinctions.|
|288-T06/T07|`ch288:finite-acquisition-obstruction`, `finite-window-value`, `window-errors`, `general-data-gain`, function/error bounds: finite acquisition remains nonunique; window/noise tail separately controlled.|
|288-E01–E04|`one-erasure`, `two-erasures`, `diagonal-geometry`, critical examples/problems: scalar/two-index/rational-grid/endpoint cases fully computed.|
|288-E05|Scalar analytic benchmark in288; complete independent finite-window/noise arithmetic in `ch290:erasure-window`. Original source plots not treated as textbook numerical proof.|
|289-D01–D03/E01/T01/P01|`ch289:sparsity`, `threshold-optimality`, `order-example`, `identifiability`, `sparse-injectivity`: actual finite-vector proof and support/model distinctions.|
|289-D04–D06/T02–T03/E02|`bp-definition`, `bp-existence`, `nsp-definition`, `nsp-equivalence`, `bad-matrix`, `rnsp-definition`, its immediate NSP consequence: no survey statement substituted for proof.|
|289-D07/T04/P02–P04|`rip-definition`, `gram-rip`, `cone-tube-lemma`, `block-lemma`, `p12-sparse-theorem`: complete adopted P12 condition δ3s+3δ4s<2, gap and final bound; no P11 sharper condition mixed in.|
|289-T05/P05/E03–E05|`p12-near-theorem`, `near-constants`, `decay-tail`, `small-rnsp`, `radius-failure` plus solved tests: actual defect2σ/√s, separate proof-derived constants, genuine small RNSP example independent of failed RIP.|
|290-D01/T01–T02/P01/D02/E01|`case-contract`, `qr-formula`, `function-gain`, periodic examples and problems: actual observation/model, finite Fourier/QR derivation, norm scaling and controlled failures.|
|290-E02–E03|`erasure-window`, `window-M2`, `window-actual-function`, `two-erasure-output`, `two-erasure-actual`: primary one-erasure and distinctly labeled two-erasure variation, exact values/bounds versus actual errors.|
|290-E04–E05|`sparse-case`, `diagonal-minimizers`, near-sparse variation and `bad-matrix`: fixed real model, BP/RNSP certificate, hand-computed minimizers, failed assumptions.|
|290-T03/E07|`synthesis-norm`, `function-gain`, `error-budget`, final problems: norm domains, synthesis conversion, certificate selection. Optional290-E06 larger RIP matrix explicitly omitted by B02; no body claim that it was checked.|

No unsupported blanket regularization theory, random RIP guarantee, infinite-erasure result, arbitrary-distribution multiplication, or full Besov identification is introduced. No Q1/Q2 or unread R1–R4 is used as proof evidence. English expansions were retained where they establish a distinct observation contract, quantify an error space, or solve a different problem; no broad shortening pass is warranted.

## Handoff and remaining scope

HandoffID V22-B05-RECOVERY-REFINE-v1, B single Work / B05 (original A integration/refinement mapping), sender independent sampling author reading other authors'288–290 → parent. Authorization: parent's explicit B05 assignment; only this report written. KEEP all body files, frozen prior volumes, source tables, extractor, R1 baseline. All9 chapter numbers remain fixed282–290 following V21 end281 at the received published commit. Source/PDF visual pairing, integrated compilation and B06/B07 remain separate; this read is source-text refinement and does not claim all-page PDF inspection.

OPEN B05-R290-1/2: parent applies two local replacements above, then send changed hash/diff for bounded reviewer verification. The report is concrete and complete before that handoff; no user decision required. No functional defect remains open in288/289 from this reviewer. Known historical mapping/global-gate UNKNOWNs and model-setting uncertainty are unchanged, not resolved by this report. Report is available locally and will be sent to parent via collaboration; parent actual read-in and durable package save are not presumed. B07 remains the unique final whole-volume mathematical acceptance.
