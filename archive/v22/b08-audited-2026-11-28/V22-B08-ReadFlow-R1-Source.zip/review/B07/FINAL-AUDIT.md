# V22 打厚整卷終審

**PASS．** Volume 22《Approximation, Sampling, and Reconstruction》第 282–290 章通過 B-07 數學終審。判定適用於修後固定來源和 SHA-256 `5b1073ce6a90116bcd6a4ae10aab05a37bbd7ab96293e48cb38fc1707eba4159` 的 201 頁 ReadFlow R1 PDF。原候選 `bbed01fa6df5562a3f9e2bd3fe9d252547b104677fc580ca813628233e3677b3` 的退回記錄保存在 `INITIAL-AUDIT-REPAIR.md`。本次所列數學、涵蓋、來源歸因與局部排版修正均已核閉。

## 固定配對與實讀回執

| 用途 | 檔案／版本 | 大小、SHA-256 與核驗 |
|---|---|---|
| 最終配對 PDF | `candidate/V22-B07-Repair-ReadFlow-R1.pdf`，B-07 修後固定版 | 892718 bytes，201 頁，`5b1073ce6a90116bcd6a4ae10aab05a37bbd7ab96293e48cb38fc1707eba4159`。與 `b07-repair-current/build/entry.pdf` 及終審實際閱讀副本逐位元相符。 |
| 逐檔正文、依賴及模板清單 | `qa/b07/repair-source-manifest.json`、`qa/b07/repair-source.sha256` | 9130／5939 bytes，分別為 `5be41212d1dc1cfbe6265d97436235e69c0de6648c34604a7c09fcbcc6e6954a`、`fccd7cd04a42016f5d7a82600e3d56a975e19a1e7e27cff3a2eb7e277ef6e049`。40 個檔案逐項核對 JSON 大小及指紋，與 SHA 清單均吻合。 |
| 最新編譯清單 | `qa/b07/repair-build-report.json`，run `b07-repair-current` | 5824 bytes，`3d4979a517e7459d54530838d709cfcd38dfd85e4157009a46ae526fca7d5f45`。14 個實際建置快照逐一與正文、前後材料、adapter 和圖檔原件核對。無 hard、overfull 或 header 診斷。 |
| ReadFlow R1 | `layout-prep/recovery/V0-ReadFlow-R1-Source.zip`，正式 artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3` | 7007679 bytes，`5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。實際裝入的 core 三檔和恢復基線逐檔指紋相同。 |
| 分卷、文獻責任與定界 | B-01 `b01/HANDOFF.md`、`b01/approx.md`、`b01/sampling.md`、`b01/recovery.md`，B-02 `b02/design.md` 與 supplement v1 | 實讀各章責任表和指定範圍映射。B-02 SHA-256 `661a4e8d6ab0454120f54e98df0b96c7e3beb5255a34f38af63e4202dc46fb14`，B-01 回執 `975e80f218273c5bc3f50fc33bfa9f50d26f2a38434a07addd92597b2401bad6`。各來源版本與原文定位見責任表。 |
| 前卷章號基線 | V21 固定發布 commit `880969bd1ca5e64e3f0d34fb01d25c54562b94e6`，`archive/v21/b08-audited-2026-11-28/` | 前卷終章 281 由主控核實。本卷前言、目錄、正文與書籤採連續的 282–290。終審依前卷回執核傅立葉慣例，未重新核前卷 PDF。 |

先實讀固定 B-06 九章、前言 1–67 行、書目 1–93 行，逐一檢查定義、陳述、證明、案例及全部 **87 題解答**。先留下 `BLIND-READ.md`，再比對 B-04 審稿、B-05 閱讀路徑及 B-06 回修紀錄。對新稿讀完所有差異及直接與傳遞影響，逐檔確認第 284、285、288、289 章的來源與首次全讀位元一致，第 287 章只有一項分頁移動。第 282、283、286、290 章的文字差異均可追溯到缺陷表。前言、書目、R1 核心、卷專用 adapter 與圖表無新改動。依 v4 附錄四實查型別、量詞、代表與相等、先備次序、正反例、練習選用與責任落點。

## 逐章終審及覆蓋證據

| 章／初版全讀及解答數 | 實核內容與主要責任落點 | 最新結果 |
|---|---|---|
| 282／1–1044 行，9 題 | P1、P1c、P2、P3、P13。`models`、`lagrange`、`remainder`、`lebesgue-gain`、`monic-chebyshev`、`barycentric-formula`、`bernstein-moments`、`weierstrass`、`rational-type`、`defect`、`rational-difference`。節點餘項、等距擾動、配權分母、Bernstein 收斂及有理表示均實核。 | PASS，新版 1049 行。 |
| 283／1–1267 行，10 題 | P4、P5。`dimension`、`hat-stability`、`linear-error-theorem`、`natural-existence`、`bending-energy`、`bspline-support`、`marsden`、`bspline-derivative`、`bspline-smoothness`、`bspline-basis-theorem`、`partition-greville`、`greville-error`。自然三次方程、能量、反例、基底、重數、局部性、仿射再現等證明均實核。 | PASS，新版 1304 行。 |
| 284／1–1100 行，10 題 | P1b、P1c、P2、P3。`finite-existence`、`polynomial-alternation`、`remez-system`、`projection-theorem`、`removable-ratio`、`rational-existence-theorem`、`rational-directions`、`weak-sign`、`rational-alternation-theorem`。核多項式中點唯一、有理相消與極點、方向秩、弱交替、非零與零缺陷例。 | PASS，282 的約分顯式假設與本章兩處交叉分子使用相符。 |
| 285／1–850 行，9 題 | P6 選定案例。`best-error`、`approximation-class`、`k-functional`、`k-dyadic`、`jackson`、`bernstein`、`main-theorem`、`detail-rate`、`endpoint-failure`、`step-rate`。核全 H¹ 範數、上下界、逐級和、正交尾項、尖鋒與跳躍。 | PASS。 |
| 286／1–857 行，11 題 | P7–P9。`representative`、`evaluation`、`poisson`、`periodization`、`fold-theorem`、`fold-minimum`、`alias-packet`、`nyquist-theorem`。核等價類、分布配對、折疊最優範數和零空間、逐纖維最小能量、真 L² 混疊與臨界界限。 | PASS，P9 歸因已校正。 |
| 287／1–982 行，12 題 | P7–P9。`onb`、`sample-energy`、`kernel`、`band-projection`、`frame`、`sequence-projection`、`window-identity`、`offgrid`、`transition-kernel`、`transition-synthesis`、`transition-tail`、`model-budget`。核 T/r 比例、三類收斂、有限窗、位移誤差、過渡帶、局部截尾。 | PASS，分頁移動後首定理可順讀。 |
| 288／1–1108 行，10 題 | P10。`erasure-equation`、`strict-gap`、`inverse-norm`、`one-erasure-gains`、`geometry-iteration`、`general-data-gain`、`window-perturbation`、`finite-window-value`、`regularization-bias`。核兩段譜積分、間隙、尖銳增益、補集與有限窗、對角加載。 | PASS。 |
| 289／1–940 行，8 題 | P6、P11、P12。`threshold-optimality`、`sparse-injectivity`、`bp-existence`、`nsp-equivalence`、`rnsp-bound`、`gram-rip`、`p12-sparse-theorem`、`p12-near-theorem`。核 2s 界、錐管、末塊、全部極小解、RNSP 與 RIP 的獨立條件。 | PASS。 |
| 290／1–1148 行，8 題 | P4、P7、P10、P11 與 287–289。`qr-formula`、`function-gain`、`periodic-budget-bound`、`window-M2`、`two-erasure-actual`、`small-rnsp`、`diagonal-minimizers`、`error-budget`。核週期擬合、混疊、單雙缺樣、稀疏與稠密最佳解和三類假設失敗。 | PASS，新版 1153 行。 |

初讀逐章證據和全部原文缺陷見 `INITIAL-AUDIT-REPAIR.md`。P1c (24.1) 確認約分及缺陷公式，P3 A2428 第二個上界確實誤植為 $m$。重讀 P5 局部導數、光滑度和多項式表示，及 P12 v2 錐管塊證明的關鍵頁。教材保留 B-02 選定的實數有理逼近、$q=\infty$ 的具體 $L^2/H^1$ 空間主定理、$L^2$ 頻限模型及有限實係數稀疏恢復。未選取的廣義定理不計入正文覆蓋，完整原典核讀依 B-01 的分組實讀記錄。

## 回修閉合

| ID／原文缺口 | 最新改文與重核證據 |
|---|---|
| M01／282.6「let $p$ interpolate」，未指定次數和 $x$ | 最新定理明列唯一 $p\in\mathcal P_n$ 與非節點 $x\in[a,b]$。Rolle 迭代中的 $p^{(n+1)}=0$、根點階數界與四次解答均有效。物理 p.11。CLOSED。 |
| M02／282.10「For $k\geq0$」 | 定義明列非負整數，遞迴明列正整數。零次、一階與極值／根計數及 Lobatto 對照成立。物理 p.12–13。CLOSED。 |
| M03／282.29「Let $r=p/q$ have defect $d$」 | 首個 $r$ 明列約分後表示、允許次數、全區間非零分母及 $r=0$ 的選定表示。競爭者允許合規但未約分的表示，該式次數仍可由第一個約分候選控制。284 的必要性、充分性、唯一性使用同前提。物理 p.24。CLOSED。 |
| M04／283.13、283.19「Fix $p\geq0$」與局部重數歸納隱含範圍 | 明列 $p,N$ 的整數域。低次重數逐一按其局部向量判定，含局部重數零的多項式情況，並先證半開指示函數及遞迴右連續。回核端點匹配、基底和 285 的連續仿射空間。物理 p.40、44–45。CLOSED。 |
| E01／283.22 重複結點例只給維數、光滑度 | 新增五個 Greville 點和三列確切活躍值。終審以分數算術獨立執行半開 Cox–de Boor 遞迴，核三列值、總和 1 及加權再現 $x$。交界敘述明列 $B_{2,2}$ 兩側皆趨近 1，其餘皆趨近 0。物理 p.47。CLOSED。 |
| S01／286.10 稱 P9 (A.8) 的位移相位是正號誤植 | P9 原 PDF 物理 p.15／印刷 p.583 清楚顯示求和項 $e^{-j\omega k}$。正號出現在 DTFT 的單位圓引數 $F(e^{j\omega})$。新版依此修正文中歸因，保留 $t=u+kT$ 推得的負相位與第 287 章取樣規一化。物理 p.102。P9 SHA-256 `35128ed1f614d994cbf1825b8f94041b941c411a4918422516693d5b9345ff72`，見 `render/P9-A8-crop.png`。B-01、B-02、B-05 的舊說法為已更正歷史。CLOSED。 |
| M05／290.4 未選底域即寫 $\ell^2\to\mathbb R$ | 缺樣案例明定 $U=\{0\}$、$C=\mathbb Z\setminus U$，觀測與擾動均實數。確認正確增益的定義域 $\ell^2(C;\mathbb R)$，有限窗同底域、對稱噪音的平方合法，單雙缺樣輸出及 288 複數一般結果均相容。物理 p.184–185、196–197。CLOSED。 |
| N01／290.9 負號資料殘差未指方向 | 明列 $y-Az^{(1)}=(-\delta,-\delta)^\mathsf T$。逐項代入兩個最佳解仍有半徑 $\sqrt2\delta$。物理 p.192。CLOSED。 |
| L01／L02，282.3、287.2 單獨頁尾節標題 | 將兩個局部 Needspace 移至節標前，物理 p.12、115 已同頁放入首定義或定理的條件和首式。後頁清楚續接。實看 p.12–13、115–116。CLOSED。 |

## 配對、工程與視檢範圍

數學核驗與工程佐證分列。兩個獨立腳本 `checks/check_examples.py` 與 `checks/check_cases_b02.py` 在回修後重跑均通過。逐式複核含精確週期 Gram 與平方誤差、單／雙缺樣投影與實際 $L^2$ 誤差 `0.361680499997` 的雙缺樣案例、小矩陣 RNSP、兩類稀疏誤差界與向上／向外取整。`repaired-structure.json` 無缺漏或重複標籤、缺失書目鍵或未配對題解。

首次實看物理頁 2、11、12、24、42、44、70、88、103、115、126、148、168–169、184、192、200–201。最新修後配對實看物理頁 11–13、24、40、44–45、47、102、115–116、184–185、192、196–197，對照公式、節標轉接及受改讀法。原配對 201 頁的一般版面由排版官逐頁看；新配對中 173 頁完整像素與原版相同，另外 28 頁由排版官獨立複核。`current-reflow-comparison.json` 記錄差異和頁號，終審抽核範圍如上。乾淨重編在這個環境得到 201 頁，提取文字、渲染像素、書籤及頁標與固定 PDF 相同，兩份 PDF 的檔案位元指紋不同。此重建證據見 `rebuild-comparison-final.json`。

保留六個經排版視檢接受的 underfull 提示及粗體數學用常規字形回退。沒有待修數學項。不可取得的 R1–R4 原教材全文和原證明、舊有 16 主題／22 章映射與六全局門檻原名仍 UNKNOWN。Q1/Q2 保持範圍以外。模型與 High 設定未核實，實體印刷、手機、讀屏、實際學習成效及跨機器重建均維持原來的驗證限制。

## 可貼交接

- `V22-B07-PASS-v1`，2026-11-28 UTC，獨立打厚終審 → 主控。V22 B 單一 Work，B-07 對應 A10–12，正式整卷數學 PASS。下一唯一階段為主控依本次授權完成 B-08 固定交付／封存。接收者先以 PDF 及來源清單核對實讀的新版，並讀入各責任落點及缺陷紀錄。
- 交付材料見本報第一表、B-01／B-02 責任表、`BLIND-READ.md`、`INITIAL-AUDIT-REPAIR.md`、`repair-refinement.md`、`repair-layout-moves.json`、`repair-build-report.json`、`rebuild-comparison-final.json` 與 `current-reflow-comparison.json`。唯一正文為九章、前言、書目及陪同模板與依賴。卷界和 R1 版本固定。無獨立記號檔。
- 編譯入口 `layout-prep/tools/runs/b07-repair-current/layout/study/entry.tex`。可恢復通用命令見 `handoff/BUILD-INSTRUCTIONS.md`，建置使用 Linux、XeLaTeX、LaTeX 套件、fontconfig 及固定字型。保留 B-05 整卷整合輸入、B-06 舊候選、首次缺陷及所有修後核驗證據。
- 前卷和凍結範圍不重做，不自動調整卷號章號、全書課綱或文獻表，不公開受限教材。主控封存以此配對及排版官獨立視檢紀錄為準。沒有待使用者決策。終審結果已在同一 Work 送達主控，B-08 保存、回取與交付由主控另記。
