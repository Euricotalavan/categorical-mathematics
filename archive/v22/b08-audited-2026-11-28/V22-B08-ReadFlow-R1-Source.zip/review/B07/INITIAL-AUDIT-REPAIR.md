# V22 打厚整卷終審

**首次判定 REPAIR。** 固定配對的全卷實讀已完成。第 282 章有兩條定理陳述缺少證明實際使用的假設。第 283 章須補明局部結點歸納和一項承諾的例題落點。第 290 章須明確指定缺樣實驗的資料底域。修後須由本終審角色核對新配對、改文及受影響後文，再決定是否進入 B-08。

## 固定配對與實讀回執

| 證據 | 實核結果 |
|---|---|
| B-06 候選 PDF | `candidate/V22-B06-ReadFlow-R1.pdf`，201 頁，888392 bytes，SHA-256 `bbed01fa6df5562a3f9e2bd3fe9d252547b104677fc580ca813628233e3677b3`。與 `qa/b06/build-report.json` 指定的建置 PDF 位元一致。 |
| 固定來源 | `qa/b06/final-source.sha256` SHA-256 `50f753dcd11993b54e42f47a96936d8c21f484658c30492b04c833e137abf10a`，40 項全部相符。`qa/b06/source-manifest.json` SHA-256 `186ede734004377a6d9e9624e14622360f03cd32296f3a96beff2c7d2da113dd`，逐項核實檔案長度與 SHA-256。九章、前言及書目與 `layout-prep/tools/runs/b06-freeze/inputs` 位元一致，建置清單內的 snapshot 和圖檔也分別實算核對。 |
| 正式模板與章號 | ReadFlow R1 artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，可恢復 ZIP 實算 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`，三個核心樣式與 B-06 基線指紋一致。V21 固定發布 commit `880969bd1ca5e64e3f0d34fb01d25c54562b94e6`，路徑 `archive/v21/b08-audited-2026-11-28/`，主控核實前卷止於 281，本卷 282–290。未重新核讀 V21 PDF。 |
| 規範與邊界 | 核讀導覽 v2.1、A/B v4 附錄三、四、B-07 與排版交接欄位，另讀 B 單一 Work v1。實讀 `b02/design.md`、`b02/design-supplement-v1.md`、B-01 回執及分組責任表。設計 SHA-256 `661a4e8d6ab0454120f54e98df0b96c7e3beb5255a34f38af63e4202dc46fb14`。最終書目各 P 碼可解析。原始 R1–R4 全文和原證明仍 UNKNOWN，Q1/Q2 不進教材。 |
| 內容實讀 | `frontmatter.tex` 1–67、`bibliography.tex` 1–93、九章完整來源及全部 87 題解答。先記錄 `BLIND-READ.md`，之後再核 B-04、B-05、B-06 的修正。 |
| PDF 實看 | 實看候選 PDF 物理頁 2、11、12、24、42、44、70、88、103、115、126、148、168、169、184、192、200、201，對照定義、公式、證明、參考定位及兩項已報版面缺陷。全 201 頁的排版視檢由 B-06 負責，相關紀錄見 `qa/b06/all-page-coverage.json`。 |
| 數值與靜態檢查 | `python checks/check_examples.py`、`python checks/check_cases_b02.py` 皆通過。另按正文公式交叉核算單／雙缺樣重建、Gram 能量、稀疏證書及各章邊界反例。`qa/b07/initial-structure.json` 無重複或缺漏標籤、書目碼或成對解答。數學判定以正文條件、推導和案例為準。 |

## 各章實際落點和處置

| 章與完整實讀 | 主要來源責任與證明落點 | 首次判定 |
|---|---|---|
| 282，1–1044，9 題 | P1、P2、P3、P1c、P13。`models`、`lagrange`、`remainder`、`lebesgue-gain`、`monic-chebyshev`、`barycentric-formula`、`bernstein-moments`、`weierstrass`、`rational-type`、`defect`、`rational-difference`。核節點餘項、擾動增益、等距成長、配權分母、連續逼近、約分與缺陷。 | REPAIR M01–M03。 |
| 283，1–1267，10 題 | P4、P5。`dimension`、`hat-stability`、`linear-error-theorem`、`natural-existence`、`bending-energy`、`bspline-support`、`marsden`、`bspline-derivative`、`bspline-smoothness`、`bspline-basis-theorem`、`partition-greville`、`greville-error`。核自然三次連接方程、唯一性與反例，以及一般局部恆等式、支撐、重數、仿射再現。 | REPAIR M04、E01。 |
| 284，1–1100，10 題 | P1b、P1c、P2、P3。`finite-existence`、`polynomial-alternation`、`remez-system`、`projection-theorem`、`removable-ratio`、`rational-existence-theorem`、`rational-directions`、`weak-sign`、`rational-alternation-theorem`。分別核多項式中點唯一、有理正分母與限值相消、方向秩與弱交替，核正缺陷與零函數例題。 | 本章證明成立。複核 M03 的上游引用。 |
| 285，1–850，9 題 | P6 選定案例，`best-error`、`approximation-class`、`k-functional`、`k-dyadic`、`jackson`、`bernstein`、`main-theorem`、`detail-rate`、`endpoint-failure`、`step-rate`。核全 H¹ 範數、上下界、逐級和、正交尾項、尖鋒與跳躍。 | PASS。 |
| 286，1–857，11 題 | P7、P8、P9。`representative`、`evaluation`、`poisson`、`periodization`、`fold-theorem`、`fold-minimum`、`alias-packet`、`nyquist-theorem`。核等價類、分布配對和規一化，折疊的最優範數、零空間及逐纖維最小能量，真 L² 混疊與臨界界限。 | PASS。 |
| 287，1–982，12 題 | P7–P9。`onb`、`sample-energy`、`kernel`、`band-projection`、`frame`、`sequence-projection`、`window-identity`、`offgrid`、`transition-kernel`、`transition-synthesis`、`transition-tail`、`model-budget`。核 T/r 比例、L²／全域一致／單點絕對收斂、有限窗和位移誤差、過渡帶乘子與局部截尾。 | 數學 PASS。另有版面 L02。 |
| 288，1–1108，10 題 | P10。`erasure-equation`、`strict-gap`、`inverse-norm`、`one-erasure-gains`、`geometry-iteration`、`general-data-gain`、`window-perturbation`、`finite-window-value`、`regularization-bias`。核兩段譜積分、正譜隙、三類擾動增益、全補集與有限窗、對角加載的偏差和噪音。 | PASS。 |
| 289，1–940，8 題 | P6、P11、P12。`threshold-optimality`、`sparse-injectivity`、`bp-existence`、`nsp-equivalence`、`rnsp-bound`、`gram-rip`、`p12-sparse-theorem`、`p12-near-theorem`。核 2s 界、錐與管、最後不滿塊、正交組合及全部極小解的量詞。小矩陣的 RNSP 獨立於主 RIP 條件。 | PASS。 |
| 290，1–1148，8 題 | P4、P7、P10、P11 及 287–289。`qr-formula`、`function-gain`、`periodic-budget-bound`、`window-M2`、`two-erasure-actual`、`small-rnsp`、`diagonal-minimizers`、`error-budget`。核週期加權內積、擬合與混疊、單／雙缺樣、稀疏／稠密最小解、三類假設失敗。 | REPAIR M05，N01 標明殘差方向。 |

## 缺陷與回修單

| ID／範圍 | 原文與位置 | 影響和證據 | 最小修補／責任 | 重新核驗 |
|---|---|---|---|---|
| B07-M01／282，物理 p.11 | `ch282:remainder` 159–162「let $p$ interpolate $f$ … For each $x$ that is not a node」。 | 定理用的是 $p\in\mathcal P_n$，卻漏列次數與 $x$ 定義域。取 $f=0,p=\omega=\prod_j(x-x_j)$，原文資料條件成立，右側為零，節點外餘項非零。B-04 的域修補也尚未反映在原固定候選。 | 精修明列 $p\in\mathcal P_n$、$x\in[a,b]\setminus\{x_j\}$。 | 核 Rolle 證明、根節點界、282.8 餘項算例及相應 PDF。OPEN。 |
| B07-M02／282，物理 p.13 | `ch282:chebyshev` 247「For $k\geq0$」。 | 非整數 $k$ 例如 $1/2$ 得 $\sqrt{(1+x)/2}$，一般沒有多項式性。B-04 282-M3 已提到同一整數條件，仍需落入固定正文。 | 精修明列 nonnegative integer $k$。 | 核遞迴、零點、極值、輸出頁。OPEN。 |
| B07-M03／282→284，物理 p.24 | `ch282:rational-difference` 782–794「Let $r=p/q$ have defect $d$ …」。 | 缺陷以約分後次數決定，展示的分子分母未要求約分。取 $m=n=2$、$p=q=1+x^2$、$A=x^2,B=1$。有 $r=1,d=2$，書面交叉分子 $1-x^4$ 次數 4，高於聲稱上限 2。 | 精修規定 $r=p/q$ 為 reduced pair，競爭者 $A/B$ 仍在容許的次數與無極點條件內。 | 核第 284 章所用 $r=p/q$ 確實是約分後表示，含零的表示和弱交替唯一性。OPEN。 |
| B07-M04／283，物理 p.42–44 | `ch283:bspline-recursion` 469「Fix $p\geq0$」；`ch283:bspline-smoothness` 685–713 延用較低次數的歸納。 | 用原全局結點向量產生較低次數時，可出現超過該次數的全局重數。歸納必須以每個函數實際用的局部向量為條件。右連續是遞迴的直接性質，後續再現與基底落點使用它。 | 打厚明列 $p,N$ 的整數範圍、局部歸納不變量和右連續性。 | 重查低次支撐端、內部重數 $p$、閉區間端點、Greville 全重數交界。OPEN。 |
| B07-E01／283.6 | B-01 283-E03 和 B-02 §283.6 承諾 active-basis table 及 exact Greville nodes。`A repeated interior knot` 791–809 只展示維數和光滑度。 | 正文證明及單格二次例子成立。重複結點例缺少指定點的實算活躍值和對照。 | 打厚在同一例加入 $g=(0,1/4,1/2,3/4,1)$。例如 $x=1/4$ 的五個值為 $(1/4,1/2,1/4,0,0)$，用遞迴或半格重標的 Bernstein 三項證實。 | 核所有表格列、再現與近鄰支持，防止另造同例。OPEN。 |
| B07-M05／290.4，物理 p.184 | `ch290:sharp-one-gain` 435 把補集擾動算子記成 $\ell^2\to\mathbb R$。 | 上游缺樣結果是複數。若沒有另列實擾動，取 $d_C=iQ_{0C}$ 即得非實補值。章末對稱噪音解答使用 $\nu^2$，也需要實變量。 | 精修在此案例起首聲明實數觀測及擾動，明列補集並以 $\ell^2(C;\mathbb R)$ 作定義域。 | 核單／雙缺樣、模型殘差、窗長選擇與對稱噪音解答。OPEN。 |
| B07-N01／290.5，物理 p.192 | `ch290:diagonal-minimizers` 803「Forward substitution gives residual $(-\delta,-\delta)$」。 | 前面週期例採 $y-Az$，此處約束寫 $Az-y$。殘差範數無歧義，帶號向量需註明按哪個方向計算。 | 精修寫明 $y-Az^{(1)}=(-\delta,-\delta)$。 | 核兩個解的殘差仍為同一半徑。OPEN。 |
| B07-L01/L02／282.3、287.2，物理 p.12、115 | 頁尾只有節標題，第一個定義／定理在下頁。 | 已實看，閱讀銜接割裂。 | 排版在本次重排中盡量將標題與首單元同頁，保留原紀錄。 | 視檢新頁並列處置。OPEN，版面欄獨立。 |

## 歷史修正重核與限制

- B-04 所見的若干數學缺陷已核實修正。例包括 282 的擾動型別、代入文字，283 實際結點網格和全重數 Greville 指標，284 有條件的畢氏式與 $n=0$ 有理家族，285 閉區間 AC 代表與實際頭尾界，286–287 的相位、L² 取樣及窗級數，288 的空限制圖和雙重正性，289 的 $s+1$ 非線性例、實際 RIP 反例及噪音解唯一性，290 的傅立葉適用域、臨界帶切換與獨立奇數平方和。仍缺少的 282-M3 兩處明列為本回修項。
- B-05 的三項閱讀路徑修正已在現稿確認。前言區分基函數支撐與資料局部性，準確預告三個案例，286 在用 comb 前給 Schwartz／temperate 定義。287 的截尾整數窗與兩題帶寬已列。290 移除前言突現的 dagger，尖峰題改用係數向量及有明確索引的樣本差。B-06 保留數學正文，只加入必要分頁標記及經授權的尖峰脈絡措辭。
- 前卷與歷史凍結限制維持。歷史 16 主題／22 章映射、六全局門檻原名、原始 R 教材不可取得處及實際模型／High 設定均為 UNKNOWN 或未核實。實體印刷、手機、讀屏、學習成效與跨機器重建維持原先限制。B-06 六個經視檢接受的 underfull 和粗體數學常規字形回退，依工程紀錄原樣列示。

## 可貼交接

- 交接 `V22-B07-REPAIR-v1`，2026-11-28 UTC。獨立打厚終審 → 主控 → 精修／打厚補明／排版 → 同一獨立終審。工作內訊息可追溯，獨立對話連結不另造。
- V22《Approximation, Sampling, and Reconstruction》，B 單一 Work 已授權 B-01–B-08。B-07 對應 A10–12，狀態集中退回。續作只處理上表與直接及傳遞影響，維持已固定際界與唯一正文，保留正式 R1、V21 末章 281、本卷 282–290、已核文獻責任和前卷。實際執行模型及推理設定未核實。
- 固定採用 B-05 整卷整合正文經 B-06 產生的配對，逐檔版號、大小、hash 和可驗入口如「固定配對與實讀回執」及 `qa/b06/DELIVERY-MANIFEST.json`。配對來源含九章、前言、書目及模板、依賴與圖檔。編譯方式見 `handoff/BUILD-INSTRUCTIONS.md`，實際入口見 `layout-prep/tools/runs/b06-freeze/layout/study/entry.tex`，建置參數及指令見 `qa/b06/build-report.json` 和 B-06 乾淨重編紀錄。無另一本正文或獨立記號檔。
- 本次只新增終審報告、實讀與核對證據，未編輯章稿。承接者先核實讀到的原固定來源，再傳回最小補丁、改文、重編 PDF、逐檔 manifest 及改頁視檢。終審驗收要求以新版固定配對驗證全部回修，確認 284 引用、283→285 與 287/288→290 接續及未變文件。通過後主控依授權進 B-08。
- 無待使用者決策。已用同一 Work 的工作訊息傳遞回修定位，待主控回執和新版。保存及後續 B-08 交付由主控負責。凍結原候選的結論保留，重排不用重做文獻、整卷草稿或其他卷。

## 來源核對補記 B07-S01

首次回修單交出後重讀固定 P9 原始 PDF 的 (A.7)–(A.8)。原始檔 `sources/P9.pdf` 實算 SHA-256 `35128ed1f614d994cbf1825b8f94041b941c411a4918422516693d5b9345ff72`，與 B-01 同一檔。物理頁 15／印刷頁 583 的 (A.8) 第一行，在求和內明示 $e^{-j\omega k}$。第二行的 $F(e^{j\omega})$ 是 (A.7) 已定義的 DTFT 表示，求和內仍用負相位。放大渲染證據 `qa/b07/render/P9-A8-crop.png`，SHA-256 `f984c39b43036a1f98fba8dc872f541f81e8e46fc046db4d1a79e41153c92228`。

`ch286.tex` 303–306 說來源有正相位誤植，這個歸因不成立。本文自身的 $e^{-2\pi ikT\xi}$ 與後續推導正確。由精修將這幾句改為同一負相位，補明角頻率換成每時間單位週期後的一致性。B-01／B-02／B-05 舊閱讀說明保留作歷史，最終紀錄須標示本次重核已修正該解讀。OPEN，待新版 PDF 與來源回核。
