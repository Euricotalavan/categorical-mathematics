# B07 return — independent refinement repairs

2026-11-28 UTC · repair-refinement-v1 · recovery refinement → controller and final_audit.

Scope explicitly released by controller: edit only Chapters282,283,290 and this ledger. Frozen originals were preserved in `layout-prep/tools/runs/b06-freeze/inputs/`; independently checked that their signatures exactly match the pre-edit current files. No styles, other chapters, template parameters, chapter boundaries, sources or source tables were edited. Mathematical constants and existing proof cases remain unchanged.

## Exact input/output identities

| File | Before bytes / SHA-256 | After bytes / SHA-256 |
|---|---|---|
| `chapters/ch282.tex` | 45,297 / `b917349f5aa8e8b1fc6ec8291bb7d4921b5beb5a42221f9851043fe136c41a85` | 45,648 / `42d18a442a9ccee5f4174db68be5ca7343da8dab04cd94b698cad4179baf6cef` |
| `chapters/ch283.tex` | 53,249 / `bb85058be631dbbf2a87076f9872cbe8c32282ff6a1b5276991e4253ef96d5eb` | 55,101 / `4a5d726aa273a397bdcddc7abaf04104e88355a127869d81e40e9b9466ad8952` |
| `chapters/ch290.tex` | 55,737 / `0f0ee32f52f87493d3eb62be06b485c6d3b6b7083bb85e1f3e196ba00d976447` | 56,034 / `91a044d81143eb605d8d17986ec28f31e5a576457a962f907596e466914de99b` |

Corresponding preserved inputs: `00-ch282.tex`, `01-ch283.tex`, `08-ch290.tex` under the frozen directory above. Full textual deltas were checked against those copies, not inferred from an earlier author log.

## Concrete change ledger

| ID / actual body target | Exact repair / reason / preserved evidence |
|---|---|
| RF-01 `ch282:remainder` | The statement now says `p∈\mathcal P_n` is the unique polynomial interpolant, and quantifies every nonnode `x∈[a,b]`. This supplies exactly the degree and interval assumptions used by the unchanged Rolle proof and derivative `p^(n+1)=0`. |
| RF-02 Chebyshev definition and `ch282:chebyshev-properties` | The defining index is explicitly a nonnegative integer; recurrence explicitly applies to every integer k≥1. This fixes the polynomial-degree domain without altering any recurrence, root or extrema calculation. |
| RF-03 `ch282:rational-difference` | First displayed r=p/q is explicitly reduced, with degp≤m,degq≤n and q nowhere zero; r=0 uses p=0,q=1. Competitor A/B is any admissible allowed-type quotient with bounded numerator/denominator degrees and B nowhere zero, explicitly not required to be reduced. Thus the first function's actual degrees give m−d,n−d bounds in the existing proof; no unjustified degree statement is made about an arbitrary unreduced first display. |
| RF-04 open-knot definition in `ch283:bspline-recursion` | Explicit integers p≥0 and N≥p+1 added to the existing vector length and open-endpoint setup. No new endpoint or multiplicity convention introduced. |
| RF-05 `ch283:bspline-smoothness` proof | Strengthened the induction hypothesis to degree k and c's multiplicity in each individual local knot vector, including lower-degree vectors whose global source multiplicity would exceed their degree condition. Local multiplicity zero is explicitly polynomial on a neighborhood, including zero outside support. Degree-zero half-open indicators are right-continuous at interior knots, and recurrence with continuous coefficients/zero collapsed terms preserves right-continuity. Thus matching two-sided limits yields the actual value. Existing local-multiplicity-p interior/support-endpoint cases and derivative cases remain. The μ≤p−1 step now explicitly applies the local hypothesis separately to each lower-degree vector. |
| RF-06 repeated-interior-knot example, after `ch283:partition-greville` | Added exact Greville tuple(0,1/4,1/2,3/4,1) and the three promised active-basis rows at x=1/4,1/2,3/4 for knots(0,0,0,1/2,1/2,1,1,1). One display contains the tuple and rows. The active triples are identified and derived as rescaled quadratic Bernstein triples from the existing recurrence. This closes the concrete 283-E03 example coverage. Both half limits give the stated middle-knot row. |
| RF-07 `ch290:erasure-window` / `ch290:sharp-one-gain` | Defines U={0},C=Z\U and explicitly restricts this erasure/window example's known data and noise to real sequences. Known-complement domain is `ℓ²(C;ℝ)`; the displayed operator norm has exactly that domain and targetℝ. Finite-window noise is explicitly e∈ℓ²(W_M;ℝ). Existing real sample calculations and norm constants remain unchanged. |
| RF-08 proof of `ch290:diagonal-minimizers` | Residual now explicitly uses the existing data-residual convention `y−Az^(1)=(−δ,−δ)^T`, whose norm isη. No sign or solution was changed; the formerly unstated residual direction is now explicit. |

## Recheck performed

- Read complete changed neighborhoods and checked full diffs against the preserved frozen sources; every changed hunk is listed above.
- Recomputed RF-06 directly by the half-open degree-zero definition and exact rational Cox–de Boor recursion, including zero-denominator terms: rows are `(1/4,1/2,1/4,0,0)`, `(0,0,1,0,0)`, and `(0,0,1/4,1/2,1/4)`. Recomputed Greville averages directly from the eight knots. These checks do not rely solely on the supplied row values.
- Checked the local degree-induction domains and right-continuity argument against the actual recurrence; no lower-degree global-space condition is used in the repaired induction.
- Recomputed the residual from y=(-(1−δ),-(1−δ)) and z^(1)=(0,0,1−2δ): Az^(1)=(-(1−2δ),-(1−2δ)), giving y−Az^(1)=(-δ,-δ).
- The repaired sources have no duplicate labels and matched definition/proposition/theorem/proof/example/display environment pairs in a source check. No compile, page count or page-visual pass is claimed by this repair role.

## Handoff and remaining gate

Controller and final_audit receive these exact repaired sources for B07 recheck and layout reflow. Earlier frozen source/PDF remains preserved; these new hashes require a newly paired PDF and the layout checks for affected pages before the final auditor decides. This repair ledger is not itself B07 acceptance, and no prior verdict is silently transferred to the new source/PDF pair. Model/mode configuration remains independently unverified. No further user decision is required within the released repair scope. Parent owns durable checkpoint and combined delivery.
