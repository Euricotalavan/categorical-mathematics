# B-02 checks for Chapters 282 and 284

V22-B02-APPROX-20261128 v1. This is a design/proof-check note, not chapter drafting or B-04 acceptance. Actual model/mode unverified. Read-in: B-01 `approx.md` SHA-256 `a897854db5848fec8110e3d56b98098e5b8ccc77ebf1ba4b6d0451fc3515312b`; B-01 `interfaces.md`; B-02 `proof-dependencies.md`. The whole-volume `design.md` had not landed when this initial note was written; exact label review is pending.

## Closed-form rational certificates selected for design

Put `s=√2−1`, `c=s/2`, `d=2s`, and `r(t)=c/(1−dt)` for `0≤t≤1`. These are proposed self-contained solved examples, not numerical Remez outputs.

- The denominator is at least `1−d=3−2√2=s²>0`, so this is an admissible reduced type `(0,1)` function with defect zero.
- For target `f(t)=t`, residual `e(t)=t−r(t)` has derivative `1−cd/(1−dt)²`. Its denominator decreases from1 to s², and `sqrt(cd)=s`, so the only stationary point is `t*=(1−s)/d=1/√2`.
- The derivative is positive before `t*` and negative after. Direct substitution gives `e(0)=e(1)=−c`, `e(t*)=c`. Thus the **whole interval** error is c; this follows from monotonicity, not a plotting grid.
- The three extremal points `0,t*,1` are an alternant of length `0+1+2=3`, proving rational minimax optimality once the Chapter284 theorem is established. SymPy simplification independently verified all three residual equalities and `(1−d t*)²=cd`.
- The same target has exact degree-one polynomial representation, so this example also prevents an overbroad assertion that rational approximation always improves polynomial approximation. Compare only families of specified allowed type and cost.

Substitute `t=x²` on `−1≤x≤1`. Then `R(x)=c/(1−d x²)` approximates `x²` with residual alternating `−c,+c,−c,+c,−c` at

`−1, −2^(−1/4), 0, 2^(−1/4), 1`.

Its exact type is `(0,2)`, and the five points prove the same function is best in all four listed families:

| Allowed type | Defect of this reduced function | Required alternant length | Available |
|---|---:|---:|---:|
| (0,2) | 0 | 4 | 5 |
| (1,2) | 0 | 5 | 5 |
| (0,3) | 0 | 5 | 5 |
| (1,3) | 1 | 5 | 5 |

The `(1,3)` entry is the worked positive-defect example. Required alternant length is a minimum, not an assertion of exactly that many extremal points. The polynomial degree-one best approximation to x² on [−1,1] is constant1/2 with error1/2; its L² best affine approximation is constant1/3 with residual squared norm `8/45`. Those are separate norm choices, not conflicting answers.

## Proof obligations that must be explicit in Chapter284

1. For reduced `r=p/q` of allowed type `(m,n)`, normalize `q>0` on the interval. Set `N=m+n−d`, `d=min(m−deg p,n−deg q)`; the zero function convention is `p=0,q=1,d=n`, hence N=m. Source: official P1-ch24.m (24.1), not P3's printed typo.
2. The map `(u,v)↦q u−p v` from `P_m×P_n` to `P_N` is onto. For nonzero p, coprimality gives kernel `(p h,q h)` with `deg h≤d`, dimension d+1; rank is `m+n+1−d=N+1`. For p=0,q=1 the map is u and its kernel consists of `(0,v)` with v∈P_n, giving the same result. State both cases.
3. Necessity of alternation can use the exact identity `r_t−r=t w/[q(q+t v)]`, where `w=q u−p v`. Choose a sign-matching w whose roots lie strictly between compact extremal sign blocks. A small t preserves positive denominator. On a neighborhood of the extremal set, residual and w have the same sign and w is bounded away from zero; outside that neighborhood residual magnitude is below E by a fixed margin. This produces uniform strict improvement. Merely saying “for small perturbations” omits the essential two-region argument.
4. Uniqueness has an elementary divided-difference certificate. Suppose another admissible `a/b` is equally good, with b>0. Then `h=a q−p b∈P_N` has weak alternating signs at N+2 alternant nodes. Since

   `Σ_i h(x_i)/∏_{j≠i}(x_i−x_j)=0`,

   the denominator signs alternate, making all summands have the same weak sign. Each summand is therefore zero, so h has N+2 distinct roots and vanishes identically. Derive the identity by Lagrange leading-coefficient comparison, instead of requiring an unread divided-differences chapter. This avoids counting adjacent closed intervals as distinct roots and avoids averaging rational functions outside their type.
5. In existence, normalized positive denominators can converge to a polynomial with zeros. On the complement of those zeros the limit ratio is bounded by the uniform candidate bound. A zero of q of multiplicity k must be a zero of p of multiplicity at least k; otherwise the one-sided ratio diverges, including at interval endpoints. Cancel and continuously extend. Equality of just the *sets* of roots is insufficient.
6. Separate exact error E=0 before the extremal-sign block proof. Uniqueness is immediate there. If using the formula with E=0, explain that “alternation” has no nonzero sign content.

## Additional exact examples for Chapter282

- Nodes `−1,1` and data `0,1` have correct barycentric weights proportional to `−1,1`, giving polynomial `(x+1)/2`. Choosing both weights1 instead gives `(x+1)/(2x)` off the nodes, with a genuine pole at0. Its removable node limits still interpolate the data. Thus arbitrary nonzero weights do not preserve polynomiality or pole freedom.
- On [0,1], Bernstein approximation of x² is `x²+x(1−x)/n`, so the exact error norm is `1/(4n)`. Derive first and second binomial moments in the proof before using this example.
- For `f(x)=|x−1/2|`, B1 f=1/2 and B2 f=`x²−x+1/2`. Both reproduce endpoint data but need not reproduce the midpoint. This is an elementary contrast between Bernstein approximation and interpolation.

## Cross-section interface proposals sent to expansion

- Chapter282 owns the polynomial/rational families, interpolation, construction, exact type and defect. Chapter284 owns all best-existence and alternation claims/proofs. A rational expression can appear in282 as an admissible construction; its minimax certificate is proved once in284.
- Chapter284's L² projection is the reusable existence/orthogonality result for Chapter285's dyadic continuous-affine `V_j`. It does not prescribe endpoint values or boundary derivative conditions. Chapter283's natural-cubic endpoint choices must not contaminate these V_j.
- Mean-square results are explicitly real in282–285, with integral definitions on continuous functions or L² classes as appropriate. Fourier chapters may use the volume's linear-first complex convention; no unannounced transpose/adjoint changes.
- The basic least-square projection proof should precede any Ch285 use; the polynomial/rational uniform statements require their own zero-count and extremal-set geometry. No normal-equation explanation is offered for the sup-norm minimax problem.

Pending: read the fixed whole-volume design, map these duties to its exact labels, report conflicts/duplicates, and receive the B-03 pass/B-04 assignment before drafting. No chapter source, matched PDF, layout patch or final audit is produced by this note. Frozen upstream work and all B-01 source copies remain unchanged.
