# V22 B02 contract: Chapters 285–287

Version sampling-contract-v1 · 2026-11-28 · authored by `/root/sampling` for coordinator/expansion. This is a proof/interface memo, not chapter text. Input receipt: B01 `sampling.md` SHA256 `083fc10e778a2f653d4fe4cf143bcef614071128e5e6bbebea32276bf1579e49`; parent fixed the main Ch285 model to L2/H1, q=∞, 0<α<1, and the labels below. `b02/design.md` was not present at the initial and second checks; reconcile the memo against it when created. No manuscript drafting begun.

## Fixed conventions and exported claims

Fourier: `fhat(ξ)=∫f(t)exp(-2πitξ)dt`; inverse positive sign; inner product linear first. `sinc(u)=sin(πu)/(πu)`, sinc0=1. `PW_B` means L2 spectral support in[-B,B] **a.e.**, with B>0 the one-sided bandwidth, and its canonical continuous representative for all point data. Fix T>0, `C=1/(2T)`, `r=2BT`; the no-aliasing/projection interface assumes `0<r≤1`. Strict oversampling is r<1. Do not call angular frequency ξ or use Adams's unnormalized sinc without conversion.

| Required label | Actual claim to appear in chapter | Inputs / downstream use |
|---|---|---|
| `ch286:pw` | Definition of PW_B as closed L2 subspace with a.e. support restriction. | V21 unitary Fourier map; used throughout Ch287/288. |
| `ch286:representative` | Every PW_B class has the unique continuous function `f(t)=∫[-B,B] fhat(ξ)e^{2πitξ}dξ` as its representative. | Compact-support L2⊂L1, inverse transform a.e., continuity, continuous functions equal a.e. agree everywhere. |
| `ch286:evaluation` | `|f(t)|≤sqrt(2B)||f||2`; also applies to PW_B differences, giving uniform control. | Cauchy–Schwarz; used to justify pointwise/uniform passage to limits. |
| `ch286:nyquist` | If `B≤C`, all lattice samples f(nT) uniquely determine f∈PW_B. Critical equality included for L2. | Pad fhat by zero on[-C,C], identify samples as Fourier coefficients, invoke completeness. No reconstruction topology assumed here. |
| `ch287:sample-energy` | For f∈PW_B⊂PW_C, `TΣ|f(nT)|²=||f||2²`; critical map `U_T:PW_C→ℓ2`, `(U_Tf)_n=sqrt(T)f(nT)`, is onto unitary. | Scaled sinc ONB; downstream Ch288 normalizes data/stability with exact T factor. |
| `ch287:band-projection` | On L2, `P_B=F^{-1}1[-B,B]F` is orthogonal norm1 projection onto PW_B. Kernel `K_B(t)=2B sinc(2Bt)`. For g∈PW_C, project its critical sinc expansion; for arbitrary L2 interpret projection by multiplier/inner product, not an unjustified L1 convolution. | V21 projection framework plus original proof; supplies projected sinc atoms to sequence projection. |
| `ch287:sequence-projection` | `Q=U_T P_B U_T*` on ℓ2 is orthogonal projection with range `U_T(PW_B)`. Its matrix is `Q_jk=r sinc(r(j-k))`; the row sum `(Qa)_j=Σ_kQ_jk a_k` converges absolutely for a∈ℓ2 by Cauchy–Schwarz. Prove `Q²=Q=Q*` at operator level first. | Critical U_T and band projection; downstream Ch288 exact missing-data kernel. |

## Ch285 order and complete proof route

1. X=L2(0,1), H1(0,1) with the **full norm**, uniform dyadic mesh h_j=2^-j, V_j continuous piecewise affine, j≥0. Give the H1 absolutely continuous representative before nodal interpolation. Define orthogonal L2 projection P_j onto finite-dimensional V_j; distinguish P_j (best approximation) from nodal interpolant I_j. Prove nesting, density, existence/uniqueness, `E_j(f)=||f-P_jf||2`, and monotonicity.
2. Define `||f||A^α_∞=||f||2+sup_j 2^{jα}E_j(f)`. j counts mesh levels; dim V_j=2^j+1. Derive rate/work relation and make no claim that any arbitrary error sequence is realized by a function.
3. Define `K(f,t;L2,H1)=inf_g(||f-g||2+t||g||H1)` and interpolation norm `sup_{t>0}t^-α K(f,t)`. State equivalence of this to `||f||2+sup_j 2^{jα}K(f,2^-j)`; prove large-t and dyadic bounds. The lower ambient-norm bound follows from continuous embedding and e.g. K(f,1)≥c||f||2. No attained K minimizer assumed.
4. Direct estimate for H1: one-dimensional nodal interpolation yields `E_j(g)≤||g-I_jg||2≤2h_j||g'||2` (a better constant optional). It follows for every g∈H1 that `E_j(f)≤||f-g||2+2h_j||g||H1`; take the infimum to obtain `E_j(f)≤2K(f,h_j)`.
5. Inverse estimate on V_j: on an interval of length h, affine v with endpoint difference b satisfies `||v'||²=|b|²/h` and `||v||²≥h|b|²/12`, including complex coefficients. Sum: `||v'||2≤sqrt(12)h_j^-1||v||2`; hence `||v||H1≤C h_j^-1||v||2`. A broken, discontinuous affine space cannot be substituted here.
6. Converse using actual approximants: let `M=sup_j2^{jα}E_j(f)`, `d_k=P_{k+1}f-P_kf`, so `||d_k||2≤2E_k(f)`, `P_jf=P_0f+Σ_{k<j}d_k`, and inverse bounds give `||P_jf||H1≤C||f||2+C MΣ_{k<j}2^{(1-α)k}≤Cα(||f||2+M2^{(1-α)j})`. Thus `K(f,h_j)≤E_j(f)+h_j||P_jf||H1≤Cα(||f||2+M)h_j^α`. Combine with step3. This supplies the full theorem `A^α_∞=(L2,H1)_{α,∞}`, **0<α<1**, with equivalent norms, without citing unread R2's inverse proof.
7. Useful endpoint counterexample, with a complete short proof: for m≥1, on disjoint interval `I_m=[2^-m,2^{1-m}]` of length ℓ_m=2^-m, put a triangular tent v_m of peak height `sqrt(ℓ_m)` at its midpoint, zero at endpoints/outside; set f=Σv_m. Then `||v_m||2²=ℓ_m²/3`, `||v_m'||2²=4`. Each v_m lies in V_{m+1}, truncated sum m≤J-1 lies in V_J, and disjoint supports give `E_J(f)≤(Σ_{m≥J}ℓ_m²/3)^{1/2}≤C2^-J`. Yet f∉H1 since any weak derivative restricts to the tent derivatives and its squared L2 norm would be Σ4=∞. Therefore `A^1_∞` does not equal H1. Do not claim a θ=1 real-interpolation theorem from the open-interval result. The tent construction also converges continuously at0 because peak heights→0.
8. Include a worked x² nodal error computation, but label its error as the interpolant error unless the L2-best projection is computed. Explain the aligned-jump counterexample for **broken** spaces separately. Omit optional finite q here unless it adds a distinct learning objective; the accepted required theorem is q∞.

## Ch286 proof order

- Define PW_B and canonical representative; then evaluation. Sampling arbitrary a.e. L2 representatives before this point is prohibited. A countable-point modification example explains the need.
- Establish units T,1/T,B and angular conversions. The cosine alias illustration is explicitly periodic/tempered, outside nonzero L2(R).
- Give an actual L2 aliasing example when B>C: choose `0<δ<B-C`, nonzero g∈PW_δ (e.g. inverse transform of an interval indicator), and `f(t)=sin(πt/T)g(t)`. Its spectrum consists of two shifted packets around±C, so it lies PW_B and is nonzero while f(nT)=0. State packet selection so the two packets do not cancel (δ<C, achievable by reducing δ).
- Prove Nyquist uniqueness by completeness of Fourier exponentials on[-C,C]; the endpoint sine `sin(πt/T)` only defeats a larger distributional signal class. No arbitrary-distribution products are needed for this proof.
- Any comb/Poisson explanation starts with Schwartz inputs and distinguishes distributions from ordinary functions. Ideal prefilter definition may be previewed after Nyquist, but its operational projection theorem is exported from Ch287.

## Ch287 proof order and infinite-matrix contract

1. Define `φ_k^T(t)=T^-1/2 sinc(t/T-k)`. Under F they are the normalized exponentials on[-C,C]. Prove ONB directly, then `<f,φ_k^T>=sqrt(T)f(kT)`; no circular completeness argument using a presumed sampling expansion.
2. Prove cardinal formula in L2; apply `ch286:evaluation` to residuals in PW_C for uniform convergence on all R. Derive `ch287:sample-energy`, onto critical U_T, and its inverse `U_T*a=Σa_k φ_k^T` as L2 convergent series.
3. Prove `ch287:band-projection`; `P_B φ_k^T(t)=sqrt(T)2B sinc(2B(t-kT))`. Extend termwise projection from finite sums by boundedness in L2, then evaluate using the PW_B bound. Do not interchange arbitrary infinite sums/integrals without this limit argument.
4. Define Q by operator composition; immediately obtain Q*=Q and Q²=Q, since U_T is unitary and P_B orthogonal. Its range is exactly `U_T(PW_B)` (closed). Evaluate Qe_k at j to get `r sinc(r(j-k))`.
5. For fixed j, the jth row belongs ℓ2; a direct check gives `Σ_k|Q_jk|²=Q_jj=r` via projection norm/Parseval. Hence `Σ_k|Q_jk a_k|≤sqrt(r)||a||2`. This proves **absolute scalar row convergence**, though the vector series/finite-matrix approximants converge in ℓ2 by the bounded-operator construction. Do not claim entrywise convergence alone proves operator boundedness.
6. If displaying `Σ_lQ_jlQ_lk=Q_jk`, justify absolute convergence with two ℓ2 rows/columns and identify it from Q². This is a consequence of projection, not an assumed matrix multiplication rule. For r=1, Q=I by sinc at integer differences. For r<1, its range is proper; choose a nonzero critical spectrum supported in the outer frequency strips to exhibit a nonzero vector in kerQ.
7. Distinguish scaled a=U_Tf and raw samples c_n=f(nT). The range is the same linear subspace and Q also projects raw ℓ2 sample sequences, since multiplying every entry by sqrt(T) preserves that range. For valid samples Qc=c. This is the exact Ch288 interface.
8. Raw reconstruction `R_Tc=Σc_k sinc(t/T-k)` satisfies `||R_Te||2=sqrt(T)||e||ℓ2`. Band-projected reconstruction has norm≤that and maps to PW_B, but generally no longer interpolates arbitrary noisy sample sequences. Fixed-j projected error bound is `|(Qe)_j|≤sqrt(r)||e||2`; continuous error bound is `||P_BR_Te||∞≤sqrt(2BT)||e||2=sqrt(r)||e||2`.
9. Separate spectral guard `r<1` (needed for useful missing-data arguments), point displacement/jitter (not established), deletion (Ch288), global ℓ2 noise, finite-vector bounded-amplitude noise, and sup error. No general jitter stability or deletion theorem is exported here.
10. Truncation: for f∈PW_C and finite I, exact `||f-R_I f||2²=TΣ_{k∉I}|f(kT)|²`; uniform error≤square root of unscaled sample-tail sum. No universal truncation rate without extra decay. For general L2 input filter first. If residual/model orthogonality is unavailable, use triangle bounds; do not invent an exact squared error split.
11. Finite periodic bridge is at most a short finite-DFT comparison: M≥2N+1 and all samples on one period can determine a degreeN trigonometric polynomial. Full computation, case assembly, conditioning and comparison belong Ch290. No regrouping conditionally convergent periodic sinc series; no nonzero periodic L2(R) identification.

## Integration and acceptance

Ch288 may rely on `Q` with `r=2BT`, its projection/range/row-sum properties and exact scaled energy. Ch287 does not prove finite-erasure invertibility, jitter stability, or a global uniform-amplitude noise bound. Ch285 uses Ch283 spline terminology but independently proves its concrete estimates; it must not reopen Ch283 boundary or require a new general quasi-interpolant theorem. B03 one-erasure calibration remains assigned elsewhere; this memo supplies its input contract only.

All chapter proofs above are author obligations for B04, not completed manuscript coverage or independent mathematical approval. Keep B01 source hazards H01–H11, especially P9 A.8 sign issue, in the evolving defect/source history. Parent must reconcile eventual `design.md`, confirm literal labels once incorporated, and keep one official manuscript. No user clarification needed for this interface.


### Read-in alignment supplement

After writing this memo, actually read `work-v22/b02/proof-dependencies.md` (thickening design check); `design.md` was still absent. Adopt its notation **V_j**, its sharper direct bound `E_j(g)≤h_j||g′||2/sqrt(2)≤h_j||g||H1`, and thus `E_j(f)≤K(f,h_j)`; the looser constant2 route above is valid but the final chapter will use the sharper common version. Adopt the inverse constant sqrt13 for the full H1 norm and exact `K(f,1)=||f||2`. For x², prefer the independently checked best-projection formula `p_j` with residual `h_j²(z²-z+1/6)` on every cell, matching endpoint residuals so projections patch continuously; prove moment orthogonality and integrate to obtain `E_j(x²)=h_j²/sqrt(180)`. This fills a distinct best-versus-interpolation example and does not require numerical fitting. No conflict with the proof dependencies or B03 one-erasure interface was found.
