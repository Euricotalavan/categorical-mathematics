# V22 B-02 — Chapter 290 case decisions and exact checks

Version `cases-b02-v1`, 2026-11-28 UTC. Design evidence only; **no textbook manuscript is written here**. Receipt: `b01/recovery.md`, `b01/math-risks.md`, `handoff/authoring.md`, and `b02/proof-dependencies.md` actually read. `b02/design.md` was not yet present at preparation. Scope: Chapter 290 only, B single Work, retaining Chapters 282–290 and R1 v3. Actual inherited model/mode is not independently observable. B-03 adoption and a parent B-04 assignment remain necessary before chapter drafting.

## Selected cases and dependency contract

Use three complete cases below. Each keeps the reconstruction inputs separate from simulation ground truth, identifies its norm and data contract, and supplies both a certificate and an actual error. Sources are the already fixed B-01 windows: P7 §5.8 for the finite periodic model; P4 §3.3 for real QR; P10 §§I–IV for finite erasures; P11 §5.1 for the RNSP model. The computations below are original specializations, not source numerical examples. Do not apply real-line sampling to periodic functions. Do not claim that the small sparse matrix passes P12's RIP hypothesis.

The eventual chapter may prove the elementary finite geometric-sum/QR identities locally. Other required results must already be proved in Chapters 287–289: normalized lattice projection, erasure gap and complement gain, NSP/BP, and the explicit RNSP estimate. Exact cross-reference labels remain OPEN until those chapters exist. The optional seven-column simplex RIP example is **omitted**: the small RNSP case already supplies a complete certified comparison. It can be added only if the parent adopts it without displacing required cases.

## Case 1: four periodic observations, known subspace and an alias audit

Work in real `L²(0,1)` with Lebesgue measure. Put `V_1=span{1,cos(2πt),sin(2πt)}` and use the **orthonormal** ordered basis `φ=(1,√2 cos(2πt),√2 sin(2πt))`. Acquire the four values at `t_j=j/4`, `j=0,1,2,3`, with ordinary Euclidean data norm. The evaluation matrix is

```
A = [[1, √2,  0],
     [1,  0, √2],
     [1,−√2,  0],
     [1,  0,−√2]].
```

The adjoint is `A*=Aᵀ` (real Euclidean coefficient and data spaces), `AᵀA=4I`, rank is 3, all singular values are 2, thin QR is `Q=A/2,R=2I`, and reconstruction is `ĉ=Aᵀy/4`. Thus `‖ĉ−c‖₂≤‖e‖₂/2` under the exact finite model, and `‖Σ(ĉ−c)_jφ_j‖L²=‖ĉ−c‖₂`. Prove the adjoint identity with the declared inner products; no unannounced sample weight `1/4` is used.

For the controlled simulation choose

`f=1+2cos(2πt)−sin(2πt)+(1/10)cos(4πt)+(1/20)cos(8πt)`.

Let `V_2` contain frequencies `|k|≤2`. The declared spectral prior `f∈V_2` is deliberately violated by the final summand; the reconstruction is supplied only `V_1`, grid and noisy observations. Set `e=(1,0,−1,0)/50`. With `v=(1,−1,1,−1)ᵀ` and `1⃗=(1,1,1,1)ᵀ`,

`c=(1,√2,−1/√2)ᵀ`, `y=Ac+(1/10)v+(1/20)1⃗+e=(317,−5,−87,195)ᵀ/100`.

Exact output and checks:

- `ĉ=(21/20,101√2/100,−1/√2)ᵀ`; `ĝ(t)=21/20+(101/50)cos(2πt)−sin(2πt)`.
- `y−Aĉ=v/10`, residual norm `1/5`, and `Aᵀ(y−Aĉ)=0`.
- `‖ĝ−P_1f‖L²=3√3/100`; total actual error `‖ĝ−f‖L²=√358/200`.

Keep the error ledger explicit; the rows use different declared spaces.

| Contribution | Function-space budget | Data budget / finite solve effect |
|---|---:|---|
| Spectral defect `f−P_2f` | `1/(20√2)` in `L²(0,1)` | samples `(1/20)1⃗`, norm `1/10`; reconstructed bias `(1/20)·1`, norm `1/20` |
| Model defect `P_2f−P_1f` | `1/(10√2)` | samples `v/10`, norm `1/5`; `Aᵀv=0`, so fitted bias is zero |
| Finite-data exact-model bias | **0** on `V_1`, since `(AᵀA)⁻¹AᵀA=I` | no infinite series or truncation is used; finite acquisition alone supplies no bound outside the model |
| Measurement noise | no function prior | `‖e‖₂=√2/50`; reconstructed function norm `√2/100` |
| Algebra / solver error | **0**, exact symbolic solve | normal-equation residual is exactly zero |

One certified total bound is `1/(20√2)+1/(10√2)+1/20+√2/100`. A sharper certificate uses orthogonality of Fourier components and the two fitted perturbations: squared error is exactly `1/800+1/200+1/400+1/5000=179/20000`. The spectral and model budgets are external prior/simulation information; the four data do not certify them. Do not count aliasing as a second independent spectral defect: it is the effect of that same defect on the finite solve.

Controlled failures: `q(t)=cos(8πt)−1` is nonzero and vanishes at every acquired node; adding any multiple leaves `y` unchanged while allowing unbounded `L²` error. Removing the finite-subspace/tail hypothesis therefore destroys a data-only error certificate, even with residual zero. Alternatively, sampling `V_1` only at `0,1/2` makes the sine column zero and loses rank. These are separate failed hypotheses.

## Case 2: full lattice with two erasures versus a finite window

Use the fixed real-line convention, `T=1,B=1/4,r=1/2`, `f(t)=sinc(t/2)`. Its transform is `2·1_[−1/4,1/4]`, `‖f‖L²²=2`, samples `s_k=sinc(k/2)`, and erasures `U={0,2}` have true values `u=(1,0)ᵀ`. The reconstruction is given the band and all complement samples, **not** the formula for the truth. For the infinite complement `C=Z\U`,

`S_U=(1/2)I`, `γ=1/2`, `b=(1/2,0)ᵀ`, `(I−S_U)u=b`.

The entries of `b` follow either from the band projection identity or from absolutely convergent sample products; the analytical truth evaluates/checks these supplied data. Right-hand-side gain is 2. Because `Q_UC Q_CU=S_U−S_U²=I/4`, the gain from complement `ℓ²` errors to recovered erasures is exactly **1**, not 2. At the same erase count, adjacent `U={0,1}` gives gap `1/2−1/π`, exposing dependence on geometry.

Now change the contract: acquire only `W={−1,1,3}⊂C`, insert noise `e_1=1/(100π)` and `e_{−1}=e_3=0`, pad all other known-complement coordinates with zero, and solve the same two equations. The inputs are `(2/π,2/π+1/(100π),−2/(3π))`. Exact arithmetic gives

`b_W=(19/(9π²),1/(3π²))ᵀ·2=(38/(9π²),2/(3π²))ᵀ`,

`ũ_W=(76/(9π²),4/(3π²))ᵀ`,

`ũ=(3809/(450π²),203/(150π²))ᵀ` after noise.

Here `b_W` is the noiseless truncated right-hand side; the displayed two equal forms are retained only for checking the factor 2 and should be reduced to one form in the chapter. Noise adds `(1/(100π²),1/(100π²))` to `b_W`. The finite-window equation residual is zero, but the true equation residual is `(1/2,0)ᵀ−ũ/2`, and the actual erased-value error is `‖ũ−(1,0)ᵀ‖₂` (approximately `0.197667`). A zero finite-equation residual does not certify correct missing values.

Budget: exact spectral defect is **0**, exact model defect is **0**, algebra error is **0**; omitted-complement energy is `τ²=1−76/(9π²)`, acquired noise energy is `ε²=1/(10000π²)`. Padding produces `‖d_C‖₂²=τ²+ε²`. Thus `‖ũ−u‖₂≤√(τ²+ε²)` by the sharp complement gain. Keep the independent contributions `τ` and `ε` visible before combining them.

For a signal output, assemble the five coefficients at indices `J=(−1,0,1,2,3)` as

`a=(2/π,ũ_0,2/π+1/(100π),ũ_2,−2/(3π))ᵀ`,

and define `f̃(t)=Σ_(j∈J) a_j (1/2)sinc((t−j)/2)`, i.e. grid-cardinal synthesis projected to the true band. It satisfies

`‖f̃−f‖L²≤√(2(τ²+ε²)) ≈0.537418`.

For a separately reproducible actual-error check, put `G_jk=(1/2)sinc((j−k)/2)`, `s_J=(s_j)_(j∈J)`. Since `Qs=s` and `‖s‖ℓ²²=2`, the exact squared signal error is

`2−2 s_Jᵀa+aᵀGa = (1080000π⁴−15992373π²+59517448)/(540000π⁴)`;

the actual norm is approximately `0.361680500`. The source of this formula must be explained; decimal agreement alone is not its proof. The bound remains an upper bound because projected synthesis contracts; projected error summands are not assumed orthogonal.

Failures: at critical `r=1`, the missing cardinal sinc is invisible on the complement and `I−S_U=0`. With only finite acquired values, bandlimited uniqueness also fails even at `r=1/2`; the finite window output is a specified approximation, not exact recovery of every member of `PW_B`. A tail norm is needed to make its error numerical.

## Case 3: sparse and dense choices for the same measured data

Use real coefficient space `R³`, data space `R²`, Euclidean errors, and

`A=[[1,0,−1],[0,1,−1]]`, ground truth `x=(0,0,1)ᵀ`.

Every pair of columns is independent, `ker A=span{(1,1,1)}`, and strict NSP of order 1 follows because any one kernel coordinate has less absolute mass than the other two together. The already audited identities give RNSP with `ρ=1/2,τ_R=√5/2`. Distinguish these constants from the erasure-tail symbol. Its full Gram eigenvalues are `0,1,3`, so `δ_3=δ_4=2` under the prescribed squared-norm convention; **P12's hypothesis fails**.

Noiseless `y=(-1,-1)ᵀ`: equality BP has unique solution `x`; the dense minimum Euclidean-norm exact fit is `(-1/3,−1/3,2/3)ᵀ`, residual zero and actual coefficient error `1/√3`. Both fit exactly; their prior criteria differ.

Noisy same-data comparison: `y=(-99/100,−99/100)ᵀ`, actual noise `(1/100,1/100)ᵀ`, radius `ε=√2/100`. Over the **same closed feasible set** `‖Az−y‖₂≤ε`:

| Criterion | Unique output | Residual norm | Actual coefficient error |
|---|---|---:|---:|
| minimum `‖z‖₁` | `(0,0,49/50)ᵀ` | `√2/100` | `1/50` |
| minimum `‖z‖₂` | `(-49/150,−49/150,49/75)ᵀ` | `√2/100` | `√417/(25√2)` |

The last expression equals `√(417/1250)` (approximately `0.57758`). These are coefficient errors relative to the declared coordinate truth; there is no undeclared signal-basis norm conversion.

For the sparse minimizer, the dual vector `p=(-1/2,−1/2)` has `‖Aᵀp‖∞=1`; every feasible point has `‖z‖₁≥pᵀy−‖p‖₂ ε=49/50`. The displayed output attains equality. Equality in both inequalities forces the unique measurement `(-49/50,-49/50)` and only the third coordinate, proving uniqueness. For the dense criterion remove the nullspace component, diagonalize `AAᵀ=[[2,1],[1,2]]`, and use symmetry/strict convexity: the optimum data lie at the point of the disk closest to zero on its diagonal, followed by `A†`.

The explicit RNSP estimate recorded in `math-risks.md` yields `‖x̂−x‖₂≤7√5 ε=7√10/100`, with best-one-term tail **0**. Actual `1/50` meets it. Measurement noise, tail/model error (**0**), and algebra error (**0**) are distinct. If that RNSP inequality is not adopted/proved in Chapter 289, prove this specialization locally or use the directly established exact solution as the certificate; never cite P12 for it.

Failures: using radius zero on these noisy data excludes the truth, even if its equality-BP residual is zero. For `A_bad=[[1,0,3],[0,1,1]]`, truth `e_1` is the unique 1-sparse fit, yet `(0,−1/3,1/3)` has the same data and smaller `ℓ¹` norm. Pairwise rank alone does not justify BP.

## Substantial exercise decisions (full solutions required in B-04)

1. For the four-point design derive the adjoint from its two inner products, QR, residual projection, coefficient bound and signal norm conversion. Change data norm to the averaged norm and recompute the adjoint and singular-value statement; the reconstruction must agree.
2. Find all frequencies indistinguishable from a constant on the four nodes. Construct an arbitrarily large invisible perturbation, then state exactly which external spectral/model bound would restore a finite error certificate. Explain why the residual misses the spectral alias.
3. Recompute the erasure case with no noise and with adjacent erasures. Derive the two eigenvalue gaps and the sharp complement-data gain from `S_U−S_U²`. Separate omitted-tail, noise, equation residual and signal error, and explain why the finite window cannot be promoted to a uniqueness theorem.
4. Solve both sparse/dense constrained problems for a general parameter `0<δ<1/2`, data `(-(1−δ),-(1−δ))`, radius `√2δ`. Prove sparse output `(0,0,1−2δ)` and dense output `(-(1−2δ)/3,−(1−2δ)/3,2(1−2δ)/3)`. Derive actual errors and the RNSP bound; diagnose an underestimated radius and the rank-without-NSP counterexample.

## Verification and handoff

`checks/check_cases_b02.py` independently checks the exact matrices, coefficients, residuals, Fourier error sums, projected-sinc Gram error and sparse/dense algebra with SymPy; it is a reversible local exact-arithmetic check, not a full textbook audit. Every assertion above remains a B-02 design calculation pending B-04 prose, independent thickening/refinement and B-07 sole final audit. No PDF, source coverage completion, stage acceptance or final archive is claimed.

OPEN: parent design reconciliation once `b02/design.md` exists; actual prior-chapter labels; B-03 style decision; and adoption/proof placement of the RNSP bound. Next: parent accepts or edits these design choices, then assigns Chapter 290 after B-03. Do not restart B-01, frozen volumes, extractor or template work. Files: this memo and the companion exact-check script. Delivery is shared-workspace save plus parent notification; it is not an external transmission.
