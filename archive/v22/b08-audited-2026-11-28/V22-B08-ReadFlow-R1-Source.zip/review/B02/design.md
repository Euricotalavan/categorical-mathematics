# V22 B-02 fixed narrative and dependency design

Version 1 · 2026-11-28 UTC · Expansion lead · B single Work · Chapters 282–290

## Receipt, authority, and status

Parent handed off B-01 as fixed and explicitly authorized B-02. I read `b01/approx.md`, `sampling.md`, `recovery.md`, `interfaces.md`, `math-risks.md`, and `handoff/authoring.md`. This design supersedes their *proposed* section numbers and resolves their alternative model choices; it preserves actual-read evidence, source fingerprints, and unresolved proof obligations. It is a design, not drafted or audited textbook coverage. A source's verified status does not transfer to unwritten proofs. Actual requested model/High setting remains independently UNVERIFIED.

| Read-in file, relative to `work-v22/` | Bytes | SHA-256 |
| --- | ---: | --- |
| `b01/approx.md` | 38579 | `a897854db5848fec8110e3d56b98098e5b8ccc77ebf1ba4b6d0451fc3515312b` |
| `b01/sampling.md` | 34333 | `083fc10e778a2f653d4fe4cf143bcef614071128e5e6bbebea32276bf1579e49` |
| `b01/recovery.md` | 29181 | `16e55a22f36a0ef281fc1d6fb5d1eded525bfcf72656f040ce4a392fb2781dd7` |
| `b01/interfaces.md` | 14759 | `25977d958a981ccba8f0d45a5cdb1cc774d110a368858577b27c4feb93f6a699` |
| `b01/math-risks.md` | 20976 | `b87106663a4cb85ea6674ef5babe32ce6d1b07b79ad9afca9a311b92714de5bd` |
| `handoff/authoring.md` | 1977 | `67dabc3fe7b56f641482622a8460283db7cfef8e227372017bb1869f1f8f7598` |

The fixed upstream is V21, commit `880969bd1ca5e64e3f0d34fb01d25c54562b94e6`, `archive/v21/b08-audited-2026-11-28/`, ending at Chapter 281. Its actual convention read was performed by the parent, not independently by this role. V22 begins 282 and ends 290. The global curriculum and references tables, extractor ZIP, earlier volumes, and adopted ReadFlow R1 template are KEEP. R1 artifact commit is `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`; no template change is authorized here.

## Narrative and mathematical choices

The volume asks: what information makes reconstruction possible, and how does an error change the answer? Chapters 282–283 build concrete finite approximation families; 284 distinguishes the geometry of choosing a best answer; 285 turns the sequence of best errors into a function space. Chapters 286–287 establish an infinite-dimensional sampling model and its stable inverse. Chapter 288 removes finitely many data from that model. Chapter 289 changes the model to finitely many sparse coordinates and proves which measurement conditions permit stable recovery. Chapter 290 performs complete calculations that make those distinctions operational.

Main choices are fixed:

* Real approximation on `[a,b]`, `a<b`, and on `[0,1]` for the dyadic specialization. Rational minimax existence and defect-correct alternation **are included with full proofs**, using the author ATAP chapter 24 route and an explicit weak-sign lemma for uniqueness.
* Chapter 283 proves the natural cubic system, and selected B-spline structure and local approximation. It does not import not-a-knot order-four error as a natural-spline estimate. General B-spline proof dependencies must be actually read or independently supplied before claims are accepted.
* Chapter 285 uses `X=L2(0,1)`, `H1(0,1)`, continuous dyadic affine spaces `S_j`, and **q=∞ as the required theorem**. Define other q only as orientation if useful; no q<1 proof burden is adopted. The Hölder/sup-norm alternative in the risk memo is excluded as an alternative main model. No identification with a named Besov space is claimed.
* Chapters 286–288 use the cycles-per-time Fourier convention and the canonical continuous representative of `PW_B`. All-lattice data, all-lattice data with finitely many erasures, and a finite observation window are different contracts.
* Chapter 289 is over real finite vectors. Include sparse identifiability, NSP equivalence, and the **complete P12 cone/tube/block proof** under `δ_{3s}+3δ_{4s}<2`. A separately proved RNSP bound is included to support a small, checkable Chapter 290 example; it is not substituted for the main P12 theorem.
* Chapter 290 uses three fixed complete cases: finite periodic least squares, finite-erasure/window reconstruction, and a small certified-RNSP sparse model. No random matrix or large numerical experiment is needed to discharge these responsibilities.

A sensible total scale is roughly 220–300 native ReadFlow pages, with variation by proof length. This is a planning expectation, not a quota or completion criterion. A chapter is complete only when definitions work, proofs are present, examples check assumptions, and the responsibility table has actual body locations. No repeated prose, forced breaks, large blank areas, enlarged type, or duplicate examples may be added to meet a count. At this stage there is no measured page total.

## Ordered section responsibilities

Each chapter source begins `\chapter{...}`, is stored once as `chapters/chNNN.tex`, and prefixes every label `chNNN:`. Section labels below are fixed contracts; additional internal labels may be added without changing them. The “responsibilities” column maps the B-01 definition/statement/proof/example IDs into their final *planned* location. Every chapter opens with its concrete question and ends with assumption-selecting problems and complete solutions. Solutions develop the choice of theorem and its conditions, not only final answers.

### 282 — Polynomial and Rational Approximation

Question: what changes when one approximates on a whole interval rather than matches finitely many values?

| § / label | Mathematical development and proof duty | Examples and B-01 responsibilities |
| --- | --- | --- |
| 282.1 `ch282:models` | Define real `C[a,b]`, sup norm, degree-at-most `P_n`, interpolation/approximation, and feasible error. Explain max existence and interval scaling. | Distinguish data residual and between-node error. 282-D01–D02. |
| 282.2 `ch282:interpolation` | Prove Lagrange interpolation existence/uniqueness, cardinal polynomials, and linearity. Derive the `C^{n+1}` interpolation remainder through the actual Rolle argument. Do not turn it into a convergence theorem without a bound. | Interpolate `x^3` at `−1,0,1`, obtaining `x`; show exact residual and midpoint behavior. 282-T01/P01/E01. |
| 282.3 `ch282:chebyshev` | Define `T_n`, prove recurrence, degree/leading coefficient, roots and alternating extrema. Distinguish root nodes from Lobatto nodes and derive the extremal monic-node-polynomial lower bound by strict sign/root counting. | Compute T2,T3,T4; compare the two grids for n=3. 282-D03–D04/T02/P02/E02. |
| 282.4 `ch282:barycentric` | Derive barycentric evaluation from Lagrange and partition of unity; separately define node values. Prove common scaling of weights is harmless; arbitrary weights need not interpolate by a polynomial globally. | Nodes `−1,0,1`: exact weights `(1/2,−1,1/2)` and a rational bad-weight example with an actual denominator zero. 282-D05/T03/P03/E03. |
| 282.5 `ch282:bernstein` | Construct Bernstein polynomials, compute mass/first/second moments by binomial identities, and prove Weierstrass by weighted near/far splitting. Affinely transfer to any compact interval. | Exact Bernstein operator on `x²` and on `|x−1/2|`; explain why existence differs from interpolation convergence. 282-D06/T04/P04/E04. |
| 282.6 `ch282:rational-type` | Define reduced real rational functions, admissibility after cancellation, positive denominator normalization, exact/allowed type, and correct defect. Prove equality by cross multiplication and zero special case. | `1/(1+x²)`, `(x²−1)/(x−1)`, genuine pole `1/x`; defect at zero and asymmetric allowed degrees. 282-D07–D08/P05/E05. |
| 282.7 `ch282:choice` | Compare global polynomial, rational and forthcoming local families using explicit admissibility/error bounds; I13 bridge on model bias and perturbation sensitivity, with no full regularization theory. | Exact rational target versus polynomial approximation; an error bound must cover the interval. No general claim of rational superiority. |
| 282.8 `ch282:problems` | 6–9 substantive problems with full solutions: distinct-node test, norm choice, weights, proof moment calculation, rational cancellation/pole diagnosis, degree/defect. | Do not duplicate worked examples verbatim. 282-OPT01 Chebyshev-series theorem is omitted as an asserted core theorem. |

Sources: P1a Chs2–6, P2 §6.2, P3 §1 with correction, P1c opening. No unread later ATAP chapter is silently used.

### 283 — Splines and Local Approximation

Question: can one change a small part of an approximation without changing its whole interval?

| § / label | Mathematical development and proof duty | Examples and B-01 responsibilities |
| --- | --- | --- |
| 283.1 `ch283:spaces` | Distinguish strict breakpoints, nondecreasing knots, degree/order, C^r matching, mesh width, and one-sided endpoint conventions. State local coefficients versus input-local operator. | An explicit piecewise quadratic meeting C0 but failing C1. 283-D01. |
| 283.2 `ch283:hats` | Define endpoint/interior hats and derive the unique continuous affine interpolant. Prove positivity, partition of unity, convex-hull bound, and exact data-to-sup-norm gain 1. | Perturb one nodal value; identify precisely the changed support. 283-D02/T01/P01. Exports continuous affine space convention to 285. |
| 283.3 `ch283:linear-error` | Prove local remainder by Rolle and `h_i²||f''||∞/8`; global nonuniform bound; combine with data perturbation by a justified triangle inequality. | `x²` exact residual and sharp maximum; compare coarse and nonuniform grids and noisy samples. 283-T02/P02/E01. |
| 283.4 `ch283:natural-cubic` | Derive cubic piece from endpoint values and second derivatives, derive tridiagonal system with h_i>0 and M0=Mn=0; prove nonsingularity by diagonal dominance (including its elementary proof) or energy. Reconstruct and check interpolation/C2/natural conditions. Explain clamped and not-a-knot as distinct choices. | Three nodes `(0,0),(1/2,1/4),(1,1)` yield middle second derivative 3; derive pieces and compare x². Four-node perturbation illustrates global data dependence. 283-D03/P03–P04/T03/E02. |
| 283.5 `ch283:bspline-recursion` | Define open/basic finite knot conventions, zero denominator terms, right endpoint left-limit, and recurrence. Prove nonnegative/local support/piecewise polynomial behavior by induction; give derivative identity and prove the matching guaranteed by multiplicity. | Fully display p=1 and one p=2 example; repeated interior knot identifies permitted smoothness. 283-D04–D05/T04–T05/P05–P06/E03. |
| 283.6 `ch283:bspline-basis` | Prove dimension through truncated powers; prove local independence and basis for specified regular knots using the exact P5 dual/Marsden prerequisites or a complete independent proof. Prove partition and Greville affine reproduction; handle p=0 separately and the closed endpoint explicitly. | Active-basis table and exact Greville nodes; endpoint failure if all intervals are left half-open. 283-T06–T07/P07–P08. |
| 283.7 `ch283:local-operator` | Define local coefficient functionals, reproduction, and boundedness separately. Prove sup-norm local error from a reproduced Taylor polynomial, positivity/finite active overlap and functional bound. Construct Greville/Schoenberg operator for C inputs, affine reproduction, norm≤1 and C² order-two bound on controlled neighborhoods. | Compute a quadratic's error and show p≥2 alone does not imply reproduction of degree p. Contrast coupled cubic interpolant. 283-D06/T08/P09/E04. |
| 283.8 `ch283:problems` | 7–10 full-solution problems: continuity check, sharp hat error, cubic endpoints, support versus locality, endpoint values, reproduction test, bounded functional versus raw L2 point evaluation. | 283-CTX01 unproved not-a-knot fourth-order theorem excluded from the theorem inventory. |

Sources: P4 §§5.2–5.3, P5 §§1–2.2. Author must consume and record P5 Theorem5/8 proof dependencies before general basis/smoothness is accepted (A-U01/A-U02 remain OPEN until then). The simple affine development is self-contained and may be written before those dependencies are closed. B04 ownership assigned by parent: expansion role owns this chapter only when explicitly released.

### 284 — Best Approximation and Error Characterization

Question: how can one certify that no feasible approximant has smaller error?

| § / label | Mathematical development and proof duty | Examples and B-01 responsibilities |
| --- | --- | --- |
| 284.1 `ch284:best-existence` | Define infimum and minimizer; prove finite-dimensional-subspace existence by bounded minimizing sequences, compactness and continuity. Separate uniqueness. | Sup-norm nonuniqueness in a different finite-dimensional subspace if included must have exact verification. 284-D01/T01/P01. |
| 284.2 `ch284:alternation` | State/prove real polynomial minimax: existence already available; sufficiency by strict root count; necessity by extremal sign blocks, compact neighborhoods and a uniform perturbation margin; uniqueness through midpoint and alternation. Zero error separately. | For x² in P1 on [−1,1], certify 1/2 and global error1/2. 284-D02/T02/P02–P04/E01. |
| 284.3 `ch284:certificates` | Prove de la Vallée Poussin lower certificate. Define one Remez step and prove its fixed-node linear system nonsingular. Distinguish exact continuous upper bound from grid lower tests. | Hand-computable constant approximation to x² and exact extrema, then a deliberately insufficient node-grid “certificate.” 284-T03/D03/P05/E02. |
| 284.4 `ch284:projection` | Define genuine inner product, orthogonality, Gram matrix, positive definiteness on the approximant space; prove normal equations, projection equivalence, uniqueness, Pythagoras, norm≤1 and best-error identity. Use linear-first convention; real chapter examples avoid complex matrix ambiguity. | Project x² onto P1 in L2[−1,1]: 1/3, error²8/45. Show a sampled form can be degenerate. 284-D04–D05/T04/P06/E03–E04. |
| 284.5 `ch284:rational-existence` | Prove real fixed-type rational existence by normalized positive denominators and compact numerator bounds. Prove limiting denominator nonzero; use order-of-vanishing to cancel interior and endpoint zeros; preserve uniform bound after extension. | Bounded quotients with vanishing limit denominators show why coefficient compactness alone does not finish the proof. 284-T05/P07. |
| 284.6 `ch284:rational-alternation` | With candidate defect d, prove difference degree≤m+n−d; prove surjectivity `(u,v)→qu−pv` via coprimality/kernel dimensions; perturb denominators safely for necessity. Sufficiency by strict sign/root count. Prove uniqueness with signed divided-difference lemma, not a type-doubling arithmetic midpoint. Treat zero numerator and zero error. | Correct d=min(m−μ,n−ν), zero d=n; exact-type(2,2) in allowed(2,3),(3,3), plus a direct best-zero odd-target test. 284-T06/P08–P10/E05. |
| 284.7 `ch284:problems` | 7–10 full solutions: choose norm, compute projection, check Gram/rank, exact alternation certificate, defect and weak-sign distinction. | No generic convergence theorem for rational Remez. |

The weak-sign lemma in 284.6 is explicit: at ordered N+1 points, a polynomial of degree≤N−1 whose values have alternating weak signs is zero, provided the signs alternate with all divided-difference denominators. The Nth divided difference is zero; each summand has the same weak sign, so every value is zero; degree then gives identity. Applying this at `m+n+2−d` alternant points proves uniqueness against any other minimizer. State the lemma with exact sign indexing rather than handwaving a root in every adjacent closed interval.

Sources: P1b/chap10.m, P1c/chap24.m, P2 §§6.3–6.4 and P3 for classical statement with correction. P13 only corroborates the defect, not a new theory chapter.

### 285 — Approximation Spaces

Question: what does a fast sequence of best errors tell us about the function itself?

| § / label | Mathematical development and proof duty | Examples and B-01 responsibilities |
| --- | --- | --- |
| 285.1 `ch285:dyadic-spaces` | Define S_j continuous affine on nodes k2^-j, no boundary condition; dim2^j+1, nested, dense in L2 via continuous density and uniform interpolation. Define orthogonal P_j and E_j, prove monotonicity, attainment, Lipschitz distance and L2 expansion in increments. | A dyadic hat eventually has zero error, without being C1. 285-D01–D02/P06. |
| 285.2 `ch285:approximation-class` | Define `A^α_∞` with norm `||f||2+sup 2^{jα}E_j`; verify vector space/norm, and distinguish level j from degrees of freedom. Optional finite-q definition is labeled an orientation, not a promised proof classification. | Abstract decay versus finite-q summability explicitly labeled sequence-level if not realized; fixed-order versus best-term preview. 285-D03/P01–P02/E01. |
| 285.3 `ch285:k-functional` | Define usable 1D H1 via absolutely continuous representative and full norm. Define K(f,t) as an infimum, not a selected minimizer; prove elementary inequalities and interpolation norm `sup_{t>0} t^-α K(f,t)`. Prove low-scale dyadic equivalence retaining ||f||2. | Compute K bounds for constant and affine functions; explain penalized smoothing I13 connection without a regularization theorem. 285-D04–D05/P03–P05. |
| 285.4 `ch285:direct-inverse` | Prove H1 interpolation direct estimate using absolutely continuous representative, interval integrals and derivative control. Derive E_j(f)≤C K(f,2^-j) by arbitrary g and infimum. Prove affine-element inverse `||v'||2≤sqrt12 h^-1||v||2`, and full H1 bound≤sqrt13 h^-1||v||2. | Compute interpolated x² L2 error h²/sqrt30 and best continuous-affine L2 error h²/sqrt180, carefully distinguished. 285-D06/T01–T02/D07; 285-T04 generalized Lq theorem excluded, its local mechanism already in 283.7. |
| 285.5 `ch285:interpolation-equivalence` | Prove `A^α_∞=(L2,H1)_{α,∞}` with equivalent full norms for 0<α<1. Direct direction from K estimate; reverse from P0 plus increments P_j−P_{j−1}, inverse inequality and geometric sum. Use j chosen at t scale, include t≥1. No hidden smoothness converse. | Trace both constants' dependence on α near0/1; no claim at endpoints. 285-T03 with adopted q∞ specialization; P06 used here. |
| 285.6 `ch285:limits` | Distinguish fixed continuous and broken spaces; show dyadic step lies in broken spaces but not H1. Explain why eventually zero error does not justify unrestricted differentiability. No claimed Besov identity. | Contrast direct bound versus exact quadratic rate, and error decay versus a chosen complexity budget. 285-E02–E03. |
| 285.7 `ch285:problems` | 6–9 full solutions: norm/control at low scale, affine inverse calculation, epsilon/infimum correction, false converse, practical level selection with an error tolerance. | Finite-q extension allowed only by explicit later proof assignment; not needed for completeness. |

Sources: P6 §§4.1–4.3 with actual elementary specialized proof; P5 local-reproduction mechanism only. The main proof does not cite unread DeVore–Lorentz to replace an argument.

### 286 — Band Limitation and Sampling

Question: when do point samples identify an entire continuous signal?

| § / label | Mathematical development and proof duty | Examples and B-01 responsibilities |
| --- | --- | --- |
| 286.1 `ch286:pw` | Define PW_B as closed L2 spectral subspace; V21 Plancherel normalization restated. Prove inverse-integral canonical representative `ch286:representative`, continuity, uniqueness and `ch286:evaluation`: `||f||∞≤sqrt(2B)||f||2`. | Change countably many raw representative values while keeping its L2 class; show why raw sampling is undefined. 286-D01/P01/E01. |
| 286.2 `ch286:units` | Define B,T,r=2BT, normalized sinc incl zero. Give cycles/angular conversion and distinguish total bandwidth from band edge and rate. | Explicit numerical conversion; critical endpoint pure tones are outside L2(R). 286-D02–D03. |
| 286.3 `ch286:comb` | Define comb as tempered distribution, Schwartz-first Poisson/periodization proof through Fourier coefficients. For compact L2 spectra use the direct interval/Fourier-basis route instead of multiplying arbitrary distributions. | Test-function action of weighted comb; phase and 1/T factor check. 286-D04/T01. |
| 286.4 `ch286:aliasing` | Show modulation aliases on kT. Construct nonzero compact-spectrum L2 alias packet when B>1/(2T), with actual two spectral supports inside the band. | Classical cosine pair clearly labeled periodic/generalized, then true L2 counterexample. 286-E02–E03. |
| 286.5 `ch286:nyquist` | Prove injectivity for B≤1/(2T) by zero-extension to the Nyquist interval and complete exponential basis. Equality allowed in L2 because endpoints null; state converse noninjectivity from286.4. | Select a permissible rate and diagnose an impermissible one. 286-T02. |
| 286.6 `ch286:model-selection` | Ideal band projection as prefilter, model residual versus samples of filtered function; finite-periodic model preview. | No pointwise raw L2 data for an unfiltered residual; distinguish finite-dimensional bandwidth from real-line spectrum. 286-P02 and model bridge. |
| 286.7 `ch286:problems` | 6–9 full solutions: representative, units, alias packet, Nyquist hypothesis, distribution interpretation. | No irregular sampling or entire-function theory. |

Sources: P7 §§5.5–5.9, P8 §6.20, P9 AppendixA, with independently proved conventions and indicated typo corrections. Plancherel and interval exponential completeness are inherited precisely from Fourier core; restate the exact usable facts before proof.

### 287 — Reconstruction Formulas and Stability

Question: how large is reconstruction error when samples are noisy or truncated?

| § / label | Mathematical development and proof duty | Examples and B-01 responsibilities |
| --- | --- | --- |
| 287.1 `ch287:sinc-onb` | Define `φ_k=T^-1/2 sinc(t/T−k)`; compute Fourier transforms and norms. Prove ONB of PW_{1/(2T)} via interval exponentials; compute linear-first coefficients `sqrt(T)f(kT)` without circularly assuming reconstruction. | Scale/unit check at T=2. 287-D01/T01/P01. |
| 287.2 `ch287:cardinal` | Prove cardinal expansion first in L2, then global uniform convergence using common-band evaluation. Prove `ch287:sample-energy`: `||f||2²=T∑|s_k|²`. Derive reproducing kernel and its norm. | Exact sinc translation and sample sequence. 287-T02–T03/P02. |
| 287.3 `ch287:band-projection` | Define unitary synthesis R_T from raw ℓ2 samples with norm sqrtT, projection P_B and projected synthesis. Derive `P_B sinc(t/T−k)=r sinc(2B(t−kT))`, frame expansion, proper sequence range when r<1. | An arbitrary noisy sequence may be inconsistent with PW_B; projection sacrifices raw interpolation. 287-D02. |
| 287.4 `ch287:sequence-projection` | Prove `Q=T_B R_T` (T_B denotes sampling after band projection; specify composition precisely as sampling∘P_B∘R_T), Q*=Q²=Q, `Q_jk=r sinc(r(j−k))`, and range equals samples of PW_B. Prove each coordinate row ℓ2 and absolute convergence against any ℓ2 sequence. | Sum-of-squares row identity `∑|Q_jk|²=Q_jj=r`, used in288.4. This is an explicit added interface responsibility derived from preceding ONB, not a new unreferenced external theorem. |
| 287.5 `ch287:noise-truncation` | Prove exact unprojected finite-window identity `||R_T(s_W+e_W)−f||2²=T(||s_Wc||2²+||e_W||2²)` under f in Nyquist space. Prove projected upper bounds/contraction; evaluation uses true output band. Distinguish ℓ2 from bounded infinite noise. | A finite tail bound with a declared tail assumption; no universal truncation rate. 287-T04–T06. |
| 287.6 `ch287:model-error` | If target is general L2, filter first and describe observations of P_Bf; then model residual plus projected data error is orthogonal. Otherwise use triangle inequality and actual observation model; no invented residual samples. Brief finite-periodic bridge points to290.2. | Three sources of error in one explicit formula; a projection need not interpolate noisy data. 287-T07/P03 and finite-periodic items according to sampling B01. |
| 287.7 `ch287:problems` | 7–10 full solutions: coefficient scaling, uniform convergence, row identity, projected versus raw output, exact noise/window calculation. | Every convergence assertion states its space. |

Sources: P7 §5.7, P8 §6.20.2–3, P9 projection discussion, direct proofs. P9 typographic DTFT sign is corrected explicitly. Do not place finite-periodic full calculation here and then repeat in290.

### 288 — Incomplete Data

Question: what can redundancy recover after samples are lost?

| § / label | Mathematical development and proof duty | Examples and B-01 responsibilities |
| --- | --- | --- |
| 288.1 `ch288:data-contract` | f∈PW_B canonical, T>0,0<r<1, finite distinct U⊂Z, all C=Z\U known; define s,u and coordinate maps. State finite acquisition and finite window separately. | Diagram/table of exactly known/unknown data; do not imply finite display is all known data. 288-D01–D04. |
| 288.2 `ch288:erasure-system` | Derive `(I−S_U)u=b`, `S_U=Q_UU`, `b=Q_UC s_C`; coordinate sums absolute from287.4. Prove finite arbitrary acquisition nonuniqueness using m+1 independent sinc translates and rank-nullity. | Finite deletion contrasted with finite acquisition. 288-T01/P01/T06. |
| 288.3 `ch288:spectral-gap` | Prove `0<S_U<I` by finite trig polynomial integrals on passband and complement. Deduce gap γ, inverse norm and condition number. Explicit finite-dimensional eigen/spectral facts restated. | Positive S alone insufficient; all strictness hypotheses used. 288-T02–T03/P02. |
| 288.4 `ch288:one-erasure` | **B03 calibration.** U={0}; derive `u=b/(1−r)`. Prove sharp RHS sensitivity `(1−r)^−1` and known-data gain `sqrt(r/(1−r))` via row identity. Explain the perturbation domains. | r1/2,T1,B1/4, f=sinc(t/2): full-complement b1/2,u1, RHS gain2, known-data gain1. Include shifted erasure and critical failure checks. 288-E01 and T04 specialization. |
| 288.5 `ch288:geometry-iteration` | Two erasures at separation d: eigenvalues `r±|r sinc(rd)|`. Rational r=p/q,U⊂qZ gives diagonal S_U=rI. Derive fixed-point iteration and residual certificate with λmax and γ. | At r1/2 compare U={0,1} and {0,2}; compute distinct exact gaps. 288-T04–T05/E02–E03. |
| 288.6 `ch288:window-errors` | Define finite W⊂C, padded y, d_C=e_W−s_C\W. Prove separate noise/tail norm and amplification; assembled synthesis followed by projection. State generic bound in γ and no unassumed decay. At r1, S_U=I; give hidden critical sinc. | Window estimate is approximate and needs tail information; full numerical sinc certificate deferred290. 288-T07/E04–E05. |
| 288.7 `ch288:problems` | 6–9 complete solutions: erasure geometry, residual certificate, missing model conditions, window/noise distinction, critical failure. | B03 sample may include three; final chapter adds genuinely new exercises. |

Source: P10 §§I–IV with strengthened proof, not its loose introductory “positive definite implies solvable” shortcut.

### 289 — A Selected Entrance to Sparse Reconstruction

Question: when does few nonzero coefficients compensate for fewer measurements?

| § / label | Mathematical development and proof duty | Examples and B-01 responsibilities |
| --- | --- | --- |
| 289.1 `ch289:sparsity` | Real R^N, fixed basis, support, Σ_s, ℓ0 count, best-s-term tails for p1/2; prove top-magnitude optimality by exchange. | Large coefficient at high index distinguishes best-term from fixed-order approximation. 289-D01–D02/E01. |
| 289.2 `ch289:identifiability` | Define A:R^N→R^m and data. Prove injectivity on Σ_s iff no nonzero ≤2s-sparse null vector, including smaller N conventions and support splitting. | Known support versus unknown support; exact two-column tests. 289-D03/T01/P01. |
| 289.3 `ch289:nsp` | Define equality BP and noisy BP; prove feasible-minimizer existence by compact sublevel. Define strict NSP and prove equivalence to uniform unique sparse BP recovery both directions. | Fix A_bad=[[1,0,3],[0,1,1]], x=e1, competitor (0,−1/3,1/3), lower ℓ1 despite all column pairs independent. 289-D04–D05/T02/E02. |
| 289.4 `ch289:rnsp` | Define ℓ2 RNSP(ρ,τ), imply NSP, derive cone/tube estimates and a full tail+noise bound using top-s *error* support for final ℓ2 step. Prove constants rather than quote an unproved survey theorem. | Fix A_small=[[1,0,−1],[0,1,−1]], s1, ρ1/2,τsqrt5/2 via three coordinate identities. Do not assert P12 RIP. 289-D06/T03/E04. |
| 289.5 `ch289:rip` | Define δ_k with squared inequalities and δ_k=δ_N for k>N; prove monotonicity and Gram spectral formula. State d>0 equivalence to P12 condition. | Underdetermined 2×3 A_small has δ_3≥1; show main sufficient condition fails while RNSP can hold. 289-D07. |
| 289.6 `ch289:tube-cone` | Prove exact-sparse P12 theorem with every minimizer: tube, cone, sorted complement blocks size3s, decreasing-tail lemma, head lower RIP and tail upper RIP, positive d and full-vector bound. No skipped last-block case. | For δ3s≤δ4s≤1/4 compute a numerical upper constant and show dependence on gap. 289-T04/P02–P04. |
| 289.7 `ch289:near-sparse` | Prove cone defect 2σ_s(x)_1 and repeat complete argument to produce explicit `Cη η+Cσ σ/√s`; distinguish true feasibility, tail model mismatch and noise. | Four-case diagnostic table with exactly which terms vanish; incorrect η can exclude truth. 289-T05/P05/E03–E05. |
| 289.8 `ch289:problems` | 7–10 full solutions: thresholding ties, rank versus NSP, feasible minimizer, tail-block estimate, constants/hypothesis check, RNSP coordinate certificate. | No probability, dictionary-learning or algorithm zoo. |

Main explicit valid constants may be the following elementary (not optimized) package. Put `a=sqrt(1−δ4s)`, `b=sqrt(1+δ3s)`, `d=a−b/√3>0`. With top-s truth support T0, largest3s error indices T1 outside it and H=T0∪T1, the block argument gives

`d||h_H||2≤2η+(2b/√3)σ_s(x)_1/√s`.

Then `||h||2≤(1+1/√3)||h_H||2+(2/√3)σ_s(x)_1/√s`, hence `Cη=2(1+1/√3)/d`, `Cσ=(2/√3)[1+(1+1/√3)b/d]`. These come from the specified proof and are not called the sharp constants printed in P12. Exact-sparse may use the sharper P12 combination if independently checked; the displayed package suffices and is uniform for every minimizer.

For the small RNSP route, a completely elementary bound from cone/tube and top-error support is `||h||2≤[2(1+ρ)^2/(1−ρ)] σ/√s + [2τ(3+ρ)/(1−ρ)]η`. If authors improve it, record and recheck the changed proof and downstream Chapter290 constants.

### 290 — Complete Reconstruction Cases

Question: can one explain each reconstruction decision, compute the answer, and certify its error?

| § / label | Fixed case and full calculation | Responsibility / boundaries |
| --- | --- | --- |
| 290.1 `ch290:case-contract` | State model, known data, uncertainty, criterion, algorithm, computed coefficients, residual, certified error, actual error when simulation truth is known, and one failure. | 290-D01; truth unavailable to reconstruction must not enter its formula. |
| 290.2 `ch290:periodic-fit` | `f(t)=a+b cos(2πt)+c sin(2πt)` on period1. Use four samples t=0,1/4,1/2,3/4. Design rows `[1,cos,sin]`; Gram diag(4,2,2); thin Q has normalized columns, R diag(2,sqrt2,sqrt2). Derive coefficients and σmin=sqrt2. | 290-T01–T02/P01/D02; finite-dimensional geometric-sum/QR proofs, not L2(R) sinc theorem. |
| 290.3 `ch290:periodic-errors` | Truth (a,b,c)=(1,2,−1), samples (3,0,−1,2). Noise e=(η,0,−η,0) gives coefficient error (0,η,0), data norm sqrt2|η|, signal L2[0,1] error |η|/sqrt2; compute residual. Uniform frequency3 cosine aliases to frequency1 on this grid, showing failure if model is changed. | 290-E01, T03; finite model is required. Use parameter η as an explicit deterministic perturbation, not a random assertion. |
| 290.4 `ch290:erasure-window` | T1,B1/4,r1/2,f=sinc(t/2),U={0}, W={k:0<|k|≤M}. Reconstruct u_M from known samples, isolate e_W and omitted tail; prove tail sum≤8/(π²M), M≥1. Use sharp one-erasure known-data gain1, assembled sample error≤sqrt2||d_C||2, projected function error≤sqrt2||d_C||2 and uniform≤||d_C||2. | 290-E02–E03, P10/model of288. Compute e.g. M2 exact u_M=8/π² from ±1 data; u2 error1−8/π². Compare two-erasure gaps only by reference to288.5, not repeated full proof. |
| 290.5 `ch290:sparse-case` | A_small as289.4,x=e1, y=(1,0). Parametrize equality-BP feasible vectors `(1+t,t,t)`; prove minimum at t0 by absolute-value breakpoints. Noisy data y=(1+ε,0), feasibility radius η=|ε| with ε>0 has e1 as a feasible minimizer: show all feasible z have z1−z3≥1, hence ||z||1≥1. Report one chosen minimizer, residual ε, actual error0 and certified RNSP bound; do not falsely claim noisy minimizer uniqueness. | 290-E04–E05; RNSP supplies guarantee even though the P12 sufficient RIP condition fails. Also compute bad-matrix failure from289.3 in compact form. |
| 290.6 `ch290:error-budget` | Translate coefficient error through the declared signal synthesis norm. Compare approximation residual, finite-data tail, and measurement error across the cases with exact hypothesis table. Explain why no single residual certifies missing hypotheses. | 290-T03/E07. Optional larger RIP matrix290-E06 is omitted; principal P12 theorem already fully proved in289. |
| 290.7 `ch290:problems` | 6–9 full solutions requiring selection among finite periodic, finite erasure and sparse models, and a controlled failure for a changed assumption. | No new unproved recovery principle. |

For290.5 the noise case deliberately emphasizes that a valid certified bound can exceed observed error. A second near-sparse vector may be added only with an explicit chosen minimizer computation, not a solver screenshot. Finite model least squares and sparse inequality BP are not interchanged.

## Cross-chapter interface contracts

Author must create these exact labels and consumers must reference the exact result, not rely only on prose proximity. If its mathematical statement changes, downstream checks listed here lose their prior pass and must be repeated. The implementation may split a section/result into multiple environments; keep the export label on the actual operative theorem/definition when possible and avoid duplicate labels.

| Export label | Contract | Consumers |
| --- | --- | --- |
| `ch282:models`, `ch282:rational-type` | Degree-at-most convention, real interval and sup norm; reduced admissible rational function; defect including zero | 284 all minimax statements |
| `ch283:spaces`, `ch283:hats` | Continuous affine interpolant, no boundary constraint, locality, exact sup stability and interval convention | 285 S_j and H1 direct proof |
| `ch283:local-operator` | Boundedness+reproduction+locality are separately stated; point evaluations act on C inputs, not arbitrary L2 classes | 285 local-to-global bridge only |
| `ch284:best-existence`, `ch284:projection` | Finite-dimensional attainment; genuine Hilbert inner product, P_j, orthogonality, norm1 projection | 285 errors/decomposition; 290 QR derivation |
| `ch285:approximation-class`, `ch285:interpolation-equivalence` | q∞ dyadic rate space and exact range0<α<1; level j≈log2 dimension | 289 fixed-order/best-term bridge and 290 budget |
| `ch286:pw`, `ch286:representative`, `ch286:evaluation` | PW_B, canonical f(t), norm bound sqrt2B | 287–288 and290 real-line case |
| `ch286:nyquist` | Sampling injective for2BT≤1 in L2 model, fails for>1; no finite-observation uniqueness implied | 287 and288 critical failure |
| `ch287:sample-energy` | T||s||ℓ2²=||f||2² for f∈PW_B⊂PW_Nyquist | 288 absolute convergence;290 sinc known sum |
| `ch287:band-projection` | P_B contraction, projected R_T output, norm≤sqrtT, projected kernel r sinc(2B(t−kT)) | 288 synthesis and290 error bound |
| `ch287:sequence-projection` | Q selfadjoint orthogonal projection on ℓ2; Q_jk=r sinc(r(j−k)); row squared norm r; range exact; s=Qs iff s samples PW_B | 288 erasure system, gap, row-gain, iteration;290 window |
| `ch288:erasure-system`, `ch288:spectral-gap` | All C known, finite U,0<r<1; (I−S_U)u=b; γ>0 exact norm inverse | 288.4–6 and290.4 |
| `ch288:one-erasure`, `ch288:window-errors` | u=b/(1−r); RHS gain and known-data gain are different; noise/tail d_C explicitly defined | 290.4; B03 calibration |
| `ch289:nsp`, `ch289:rnsp` | Uniform equality-BP uniqueness vs quantitative RNSP; full norms/ρ/τ/hypotheses | 290 sparse case, never P12 hypothesis transfer |
| `ch289:rip`, `ch289:tube-cone`, `ch289:near-sparse` | Squared RIP convention, d positivity, every minimizer, explicit separate η and tail constants | 290 comparison table and final exercises |

Common notation: `B` one-sided cycles bandwidth, `T` spacing, `r=2BT`, `PW_B`, `s_k` sample values, `S_j` spline *space*, `S_U` finite erasure *matrix*, `Q` sequence projection, `U` erased indices, `C` complement, `W` finite window. In sparse sections `s` is integer sparsity and `A` measurement matrix; use `H,T0,T1,...` for support blocks and explain local reuse of T as a set is avoided (write `J` for a general sparse support if necessary). `α` is approximation smoothness. `η` is measurement-noise radius; `ε` is a particular perturbation scalar when distinct. `q` is never simultaneously knot count and interpolation exponent in the same section. Complex signal formulas use conjugate transpose and linear-first inner products. Sparse model remains real.

## B-03 representative and acceptance rubric

Selected section is **288.4 `ch288:one-erasure`**. It is a substantive reusable manuscript section, not a separate competing text. Parent was notified of exact contracts before completion of this design; recovery and thickening roles acknowledged them. B03 is authorized by the user's reported autonomous sequence and parent release; the expansion role does not itself claim B03 performed here.

The representative must include the known-data model in ordinary English, the finite unknown, derivation from Qs=s, absolute convergence, solution and conditioning, a complete r1/2 worked check distinguishing ground truth from observed data, an error/critical-rate diagnostic, and 2–4 problems with full solutions. Keep domain/quantifier/hypothesis details in the necessary reading path. A smooth page or a correct formula alone fails calibration if a reader cannot distinguish missing one sample from observing finitely many samples. A detailed proof can cross pages; layout must not box it into a large indivisible object. Deletion scale: remove redundant restatements only; preserve first explanation of a factor r, the data contract, margin, and perturbation domain. Independent thickening and refinement read the same section; all patches remain traceable in one body. B03 acceptance does not approve the whole volume or eliminate B04 review of this reused section.

## Explicit source corrections, exclusions, and remaining obligations

| Item | B02 decision and effect | Next proof/evidence owner |
| --- | --- | --- |
| P3 printed defect has second m instead of n | Correct to min(m−μ,n−ν); cite P1c and P13 corroboration. Preserve source PDF untouched and record error. | 282/284 author, independent refinement |
| Polynomial/rational uniqueness weak-sign trap | Use polynomial midpoint in284.2 and proved divided-difference lemma in284.6. Do not count closed adjacent intervals as distinct roots. | 284 author/thickening |
| Rational denominator compactness gap | Must show nonzero limiting denominator and removable zeros including endpoints. No coefficient-limit shortcut. | 284 author/thickening |
| P2 terse Bernstein algebra | Independently derive weighted binomial moments and near/far estimates. | 282 author |
| P4 natural vs not-a-knot rates | Fully prove natural cubic existence; omit blanket natural O(h4). No unproved not-a-knot convergence theorem. | 283 author |
| P5 dual/derivative prerequisite not read by B01 indexer | Actual read/proof required for general B-spline claims in283.5–6; affine part unaffected. | 283 author then refinement |
| P6 K-minimizer epsilon suppression and reverse proof not provided | Full-norm q∞ specialized proof with infimum/telescoping, no imported unread proof. | 285 author then independent thickening |
| P6 fixed discontinuous meshes | Main model continuous S_j⊂H1. Fixed discontinuous counterexample remains explanatory. | 285 author |
| P7 noncompact-support informal argument | Simultaneous compact-support theorem omitted; no need for full analytic continuation. | 286 author |
| P8 generalized signal endpoint condition / sinc | Critical equality proved only for L2 spectra; angular and unnormalized-sinc arguments converted. Comb is a distribution. | 286/287 author |
| P9 A.8 apparent positive DTFT phase | Direct substitution gives negative phase under declared convention. Derive result independently and note source discrepancy. | 286/287 author |
| P10 intro positivity shortcut | Use actual passband and complement strict forms, not S_U>0 alone. | 288 author |
| P11 unproved robust theorem / P12 constant mixing | Main P12 proof fully supplied; RNSP bound independently proved with its own constants and small example. | 289 author/thickening |
| Source access/redistribution | R1–R4 bibliography only; Q1/Q2 excluded. Public source PDFs are research inputs, not default public package contents. | Parent packaging |

Excluded theories: Padé/AAA algorithm convergence, Newman/Stahl rates, general potential theory; arbitrary-mesh optimal-order cubic theorem; full Besov/Lorentz or free-knot characterization; interpolation endpoints and q<1 generalization; irregular/Kadec/Landau sampling; entire-function Paley–Wiener theory; infinite erasures, stochastic missingness, full inverse-problem/statistical-risk theory; random RIP sample complexity, low-rank/TV/Bayesian/dictionary-learning recovery. I13 remains an explicit conceptual bridge in282–283. No exclusion erases the mandatory chosen best-approximation/approximation-space/sampling/sparse-recovery duties.

## Handoff, OPEN status, and next action

Handoff `V22-B02-DESIGN-v1`, expansion → parent, independent thickening/refinement and assigned chapter authors. B02 fixed narrative/design complete subject to their dependency review; it maps to original A scope/expansion design, not a textbook acceptance. Internal contracts sent by direct collaboration messages to parent, recovery and thickening; their messages acknowledge receipt. This document is the formal comprehensive record; its durable save is parent packaging responsibility. No remote upload or user file-delivery claim is made by this role.

OPEN B02-1: general B-spline proof prerequisites A-U01/A-U02 require actual reading/proof before Chapter283 acceptance. OPEN B02-2: all proposed theorem/proof/example body locations remain unwritten until B04; source index is not body coverage. OPEN B02-3: final source/PDF pairing, R1 local patches, dependencies, full-page visual inspection and B07 independent sole final audit remain future work. OPEN B02-4: precise V21 conventions are parent-read evidence; do not claim every agent independently opened upstream PDF. OPEN B02-5: small numerical/algebraic computations above are fixed design candidates; authors must actually compute/recheck and independent reviewers verify them. Old EXP-O1, O3–O6 are resolved at design-choice level only; their mathematical proof obligations remain in this table. Historic 16-topic/22-chapter mapping and six global gates remain UNKNOWN with no V22 authority to resolve them.

No user decision is needed for these within-scope choices. Next unique stage is B03 calibration of288.4 using the fixed contracts. B04 authors then work in dependency order on one source per chapter; expansion owns283 only when released. Ordinary drafting choices and safe corrections do not require a new user approval. Substantive interface changes return to the owning role with a patch and downstream impact record. Preserve upstream volumes, numbering, tables, extractor and R1 baseline. No competing full-volume manuscript, prior-volume redo, title-only source coverage, or page-count acceptance is permitted. B05 must later check each chapter and then the entire reading path; B06 accepts only the integrated fixed body; B07 remains the sole strict whole-volume audit and all changes return there for recheck; B08 follows actual pass and existing authorization.

At present: unique body/PDF none produced by this role; compilation/full-page checks not applicable to this planning artifact; mathematical acceptance pending. Layout information is retained in authoring.md and the adopted R1 baseline, with no local style patch created here.
