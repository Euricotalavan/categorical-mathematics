# V22 B02 design supplement v1

2026-11-28 UTC · Expansion lead · nonblocking refinements to `design.md` v1.

The whole-volume fixed design is `b02/design.md`, SHA-256 `661a4e8d6ab0454120f54e98df0b96c7e3beb5255a34f38af63e4202dc46fb14`. After it was saved, I read independent `b02/proof-dependencies.md` and `b02/approx-checks.md`. Their choices align with the fixed main models and section contracts. This supplement adds an exact worked certificate and clarifies proof options; it does not move sections, change labels, or declare any textbook proof complete.

1. **282.4 exact bad barycentric weights.** Nodes `−1,1` and data `0,1` have correct weights proportional to `−1,1` and polynomial `(x+1)/2`. Weights both 1 instead yield `(x+1)/(2x)` away from the nodes, with a genuine pole at0. Its node limits still fit the data. This is the selected explicit bad-weight example promised in the design.

2. **284.6 exact rational certificate.** Select the example from `approx-checks.md`: write `s=√2−1`, `c=s/2`, `d=2s`, and `r(t)=c/(1−dt)` on `[0,1]`. Denominator is positive, residual for target t has only stationary point `t=1/√2`, with values `−c,+c,−c` at0,1/√2,1. Prove these by algebra and derivative sign. It is minimax in type(0,1) by the established theorem. Under `t=x²`, five extrema certify positive-defect type(1,3) as well as types(0,2),(1,2),(0,3). This adds a concrete nonzero-defect certificate to the design's placeholder. Chapter282 may show admissibility, but does not claim its minimax property in advance.

3. **284.6 exact perturbation and uniqueness.** Use the identity `r_t−r=t(qu−pv)/[q(q+tv)]`, not an unexplained asymptotic term. The source-check note supplies the two-region uniform-margin proof. Derive the weak-sign divided-difference identity by comparing the leading coefficient in Lagrange interpolation; no unintroduced divided-difference prerequisite is needed. The zero numerator case has map `(u,v)→u`, kernel `(0,v)`, and must be written separately.

4. **285.4 concrete constants.** `proof-dependencies.md` independently gives direct `E_j(g)≤h_j||g′||2/√2`, inverse full-norm `||v||H1≤√13 h_j^-1||v||2`, and exact best quadratic error `h_j²/√180`; these agree with the design. For full-norm K, `K(1,f)=||f||2` by triangle inequality and g0, making the low-frequency control transparent. Author must still write and reviewer check the actual proof.

5. **289.6 constants are proof-dependent.** The design's conservative full-vector factor `1+1/√3` is valid. Thickening's stronger two-component Euclidean argument gives `√(4/3)` in its place, and hence noise constant `2√(4/3)/d` and tail constant `2√((1+δ3s)/3)√(4/3)/d+2/√3`. Either complete package may be used, with an explicit derived inequality and coherent downstream references. No mixing of constants is allowed. A numerical passing RIP example is optional; it does not replace the proof.

6. **B03 is already underway externally.** Parent reports its independent mathematical/layout review. This supplement does not claim a pass or start another calibration. The single source is the parent's selected288.4 body. The full Chapter290 window arithmetic remains distinct from the calibration's infinite-complement example.

No blocker or user decision arose from the independent design checks. Parent may launch B04 once B03 passes. Expansion role remains assigned Chapter283 for that release. This note changes no body, source PDF, frozen volume, chapter range or template, and carries no final-audit claim. Parent owns durable stage packaging and delivery.
