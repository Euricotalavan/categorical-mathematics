# B03 layout review · revised calibration

The working PDF is `work-v22/b03/V22-B03-ReadFlow-R1.pdf`: six physical pages, Chapter 288, Section 288.4. Source hash is b0961b9c27f793cb29e0eda67c6cbabf20e0178867920b6f6e9b66af3cea415d; PDF SHA256 is 09e81a626ca1bb7634dd66f6938832dcbcd360ba01d059eaecf482de0ddd5956. Every revised sample page was rendered at 120 dpi and viewed individually in sequence. Engineering passes; the two concrete reading issues below remain open. This is B03 calibration, not B06 or whole-volume mathematical acceptance.

## Fixed source and deltas

The earlier source 135a3d31c0a9f18cfb6bfa34feab6f0d03b20124ed8293239aff6efcdb4412d5 remains in `layout-prep/tools/runs/b03-calibration/inputs/01-ch288-calibration.tex`. Its six-page PDF was also fully viewed. The parent-supplied revision changes four textual locations: explicitly places the full sample sequence in the projection range; says finite acquired set; makes M a nonnegative integer; and uses outward-rounded error interval [0.08105,0.13510]. I made no source-body edits. Small text changes cause page reflow, so revised pages were checked again rather than inheriting the first review.

## Page observations

| Physical pages | Observation | Status |
| --- | --- | --- |
| 1–2 | The paragraph ending “isolated the erased sample as” breaks after “erased”; p2 starts with the short fragment “sample as” and then equation (288.1). The formula and its following explanation are present, but the lead-in is awkwardly split. | L-B03-01 OPEN |
| 2–3 | Proposition 288.2 starts at p2 bottom and crosses after the first line of its quantified setup. A continued heading correctly identifies it on p3, but this short proposition could be kept together in the final chapter layout. | L-B03-02 OPEN |
| 3–4 | Long Example 288.3 splits at a complete paragraph boundary and carries a correct continued title. The initial version instead split the word coefficients across the continued heading. Revised break is better. | KEEP revised |
| 4–5 | Exercise 288.1 is complete at p4 bottom; its solution begins p5. The task and full solution are identifiable. Revisit adjacency during chapter reflow rather than making the long solution unbreakable. | Observe at B06 |
| 5–6 | Exercise 288.3 is complete at p5 bottom; its full solution and source note appear p6. Unlike the first version, p6 is a coherent half-page unit rather than a two-line solution tail. | KEEP revised |
| 1–6 | Text, equations, theorem/lemma/example/exercise identifiers, source notes and page furniture are visible; no observed clipping, footer collisions, missing glyphs or wide equations. Formula spacing remains the adopted R1 settings. | Engineering/visual scope checked |

Suggested handling of L-B03-01/02: preserve all mathematical text and protect the short lead-in/formula and short proposition as reading units when the complete Chapter 288 is laid out. The isolated sample starts with a full chapter title; final pagination will differ. No automatic page quotas, global line-spacing changes or forced full-proof boxes were added. These OPEN items are not concealed by the clean build log.

## Adapter repairs and verification

Only `layout-prep/layout/v22-adapter.tex` changed. The core adopted R1 three files remain byte-identical. A bounded patch reserves 3em for the three-digit chapter number in chapter TOC entries; it fails loudly if book.cls cannot be patched. Front and back matter headers now display Volume 22, and main matter displays Volume 22 / Chapter n.

The seven-page `frontmatter-gap-fixed` fixture was rebuilt with no hard, overfull or header warnings. Its sequential contact sheets were viewed, and the TOC was enlarged: “282” and “Fixture” have a clear visible gap. Text extraction confirms front/TOC/bibliography headers show Volume 22; main matter retains Chapter 282. This fixture is separate from the B03 mathematics sample.

## Evidence and handoff

交接ID／版本／時間：V22-B03-LAYOUT-v2，2026-11-28 UTC。發出排版工程/root/layout；接收統籌/root。方案B單一Work，僅B03代表節工程校準。B06須待B05整卷整合，不得提前。

授權與凍結：只包裝Chapter 288/Section 288.4、編譯、視檢、報缺陷及修V22 adapter；正文hash保持父任務指定修訂版，未改其他卷或核心模板、未作公開Git寫入。模型與High設定未另核實，不冒稱切換。

基線：正式R1 ZIP 5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732，artifact commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3。前卷末章281、本卷282–290，由統籌維持固定章界。manifest每檔用途／絕對路徑／bytes／SHA256見layout-manifest.json；各次輸入快照與配對PDF見build-report.json。

重建指令：`python3 work-v22/layout-prep/tools/build.py --sample /workspace/scratch/29eb1e74068b/work-v22/b03/calibration-wrapper.tex --sample /workspace/scratch/29eb1e74068b/work-v22/b03/ch288-calibration.tex --name b03-calibration-v2`。依賴與宏契約沿AUTHOR-CONTRACT.md。建置2 pass收斂，hard/overfull/header/underfull全空；預期§288.4及內部引用均可解析。render-v2/render-report.json記六頁圖像hash；無白字或頁界超出警示。

三層分列：內容保留是來源hash與完整工程標識核對，不裁決數學；工程通過；閱讀視檢6/6頁完成但L-B03-01/02仍OPEN。數學終審及使用者理解／偏好UNKNOWN，不以本報代替打厚。章級先備與完整卷順讀尚未發生。

下一唯一動作：統籌將此B03候選與OPEN併入代表節校準及後續B04/B05，完整章布局時保護已指出的短閱讀單元；B05後再交B06正式全頁與章縫核驗。禁止重做固定模板恢復、重生成已核代表節、移植舊章正文或直接宣告B07/B08通過。待使用者決策：無。交接已由工具訊息送統籌；接收讀入回執待統籌。
