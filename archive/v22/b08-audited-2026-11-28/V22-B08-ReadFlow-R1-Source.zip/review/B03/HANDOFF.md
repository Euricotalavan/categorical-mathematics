# V22 B-02 design and B-03 calibration handoff

V22-B03-20261128 v1 · B single Work · Chapters 282–290. The design and representative section have passed the controller's internal review. The role-specific proof, source, and build evidence is included.

- Fixed B-01 source responsibility checkpoint, version 0, libfile_fde3_f-eda16542acb48191b18e350e24d32475_383d682b1c388191a1961becbec9fb77. Exact checkpoint was recovered and SHA-256 verified.
- B-02 design.md fixes ordered chapter responsibilities and cross-chapter contracts. Supporting audits verify the chosen proof routes and computed cases.
- B-03 section file ch288-calibration.tex has SHA-256 b0961b9c27f793cb29e0eda67c6cbabf20e0178867920b6f6e9b66af3cea415d. Math review read the initial source completely, requested three precise edits, and rechecked the fixed revision. Derived formulas and three solutions were independently checked.
- Corresponding six-page V22-B03-ReadFlow-R1.pdf has SHA-256 09e81a626ca1bb7634dd66f6938832dcbcd360ba01d059eaecf482de0ddd5956. The layout role rendered and examined all six pages and identified two page-boundary issues for normal B-06 reflow. No layout sign-off for the whole volume is claimed.
- ReadFlow R1 core is from the adopted V0 package v3 and fixed commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3. The V22 adapter widens three-digit TOC markers and sets volume-only front/back running heads. To rebuild the representative from this package, invoke layout-prep/tools/build.py with --sample b03/calibration-wrapper.tex --sample b03/ch288-calibration.tex --name calibration and use the reported entry.pdf path.

The source rights and unresolved original-book items carry forward unchanged from the B-01 handoff, with the public source corrections enumerated in B-02. V21 numbering baseline is the published commit 880969bd1ca5e64e3f0d34fb01d25c54562b94e6. All chapter tasks are disjoint. Model settings were requested by role through the agent interface. Runtime-effective model identity and reasoning mode were not independently attested.

The next work is B-04 drafting, thickening and independent refinement of one corpus, with substantive examples and solved exercises comparable to calibration. Author read-in receipts were received for the roles controlling Chapters 282–290. Preserve title numbering and the validated B-03 math. When integrating 288.4, connect its actual sequence-projection reference from 287 and keep the chosen one-erasure model. There is no new user approval required by this handoff.
