# B-03 independent mathematical review

**Verdict** §288.4 passes the calibration mathematics. One dependency sentence and two small precision edits should be folded into the B-04 manuscript. Independently read all 261 lines of the 10,723-byte `ch288-calibration.tex` v1, SHA-256 `135a3d31c0a9f18cfb6bfa34feab6f0d03b20124ed8293239aff6efcdb4412d5`. Scope is this representative section only, V22 B single Work, Chapters 282–290. Reviewer role is independent thickening. Model and reasoning setting unverified. The fixed calibration source was evaluated as supplied.

| Verified area | Evidence from the fixed draft and independent check |
| --- | --- |
| Model and normalization, lines 10–47 | Positive `B,T`, continuous representative of `PW_B`, normalized sinc, `r=2BT∈(0,1)`, known full complement and `ℓ²` ensure the row sum is absolutely convergent. In the declared sampling space it gives `(1−r)u=b`. |
| Sharp gains, lines 49–119 | With `b` perturbed by `ξ`, error is exactly `ξ/(1−r)`. Parseval on a unit frequency interval gives row mass `r`; removing the diagonal leaves `r−r²`. For raw known samples the exact norm is `√(r/(1−r))`; the real row attains equality in the complex data space too. Summation error combines with sample error by the triangle inequality for the stated perturbed-right-side model. |
| Benchmark reconstruction, lines 121–162 | Cycles transform of `sinc(t/2)` has multiplier 2 and band edge 1/4. The parity and signs of retained samples are correct. Parseval for the independently integrated indicator coefficient `q₀=1/2` gives the odd-square sum `π²/8`. The reconstruction computes `b=1/2` solely from retained data before comparing `u=1` with truth. |
| Finite observation and solutions, lines 164–253 | Omitted tail survives even with exact finite-sum arithmetic. Translating a sole erasure preserves the full-complement norm. For `M=1`, independently recalculated `u₁=0.900632743…`, error `0.099367257…`, exact interval endpoints `0.081056947…` and `0.135094912…`. At `r=3/4`, the two gains are 4 and `√3`, with off-diagonal row norm `√3/4`. A multiple of the cardinal sinc certifies nonuniqueness at `r=1`. |

### Precision edits for the next integrated copy

- **B03-M1, lines 24–32.** Identify `Q` as the orthogonal **sequence** projection on `ℓ²(ℤ)` and expressly apply Chapter 287's range result to the current complete sample sequence. Suggested wording is “The full sample sequence lies in the range of the orthogonal sequence projection (Q) from [cross-reference], so (Qs=s).” This replaces the current conditional “For a sample sequence in its range.” Verify the actual source label `ch287:sequence-projection` at integration. The formula already rests on that established interface.
- **B03-M2, lines 164–166 and 200–202.** State that the observed index set `K⊂C` is finite and the exercise parameter `M` is a nonnegative integer. The discrete sum otherwise leaves the index convention implicit.
- **B03-M3, line 224.** The exact analytic interval is correct. To present its decimal version as a certified enclosure, round outward to `[0.08105, 0.13510]`. The current wording says “approximately,” which avoids an exact numerical claim.

### Calibration decisions and handoff

Keep the current progression from data contract to equation, then two gains, then a fully calculated example and solved boundary checks. Preserve the independent evaluation of the known-data sum and the attaining vector in any later compression. Retain the compact finite-window exercise and use a later case for a genuinely different data contract or analysis. The final sentence of the source note can be removed as editorial process language. P10 (1)–(2) and its spectral discussion, plus the P7 §5.7 Parseval interface, support the section's chosen dependencies. The exact gain and computations are independently derived in the manuscript.

**Transmission and next stage** Findings sent to the controller. Proposed edits await B-04 integration with the single manuscript. Review concerns only the supplied TeX; matching PDF, R1 build and visual QA remain separate. No conflict with frozen material, source responsibilities or chapter numbering. No user decision requested.

**Recheck of corrected copy.** Verified the replacement `ch288-calibration.tex` (10,775 bytes, SHA-256 `b0961b9c27f793cb29e0eda67c6cbabf20e0178867920b6f6e9b66af3cea415d`). B03-M1 is closed for the stand-alone calibration at lines 24–32, with the explicit Chapter 287 sequence-projection reference pending insertion into the full manuscript. B03-M2 is closed at lines 165–167 and 201–203. B03-M3 is closed at lines 222–225. The proof, gains, example, and solutions all pass for the corrected scope. The pending linked label and optional editorial sentence removal do not block B-04.
