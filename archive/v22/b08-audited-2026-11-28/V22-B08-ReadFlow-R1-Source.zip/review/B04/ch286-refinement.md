# Independent B04 refinement — Chapter 286

2026-11-28 UTC · case_study role reviewing sampling author's file · B single Work. Read all 25,795 bytes of `chapters/ch286.tex`, SHA-256 `4b945a84a1cb5cc89ad939271b8b7e1ebaff6277dba995abb7c1f1bd46975f1b`, relevant `b01/sampling.md` source locators, fixed B02 §286/contracts, and authoring conventions. This review changes no author file. Actual requested runtime model/High mode remains unverified. V21 dependency locations are parent-received evidence, not independently opened upstream PDF evidence.

## Verdict

No blocking mathematical or ordinary-language defect found in the reviewed file. Reader-side definitions, hypotheses, constants, and proofs work within the stated scope. KEEP the following, rather than replacing precise distinctions by engineering shorthand.

| Actual body | Independent check / KEEP reason |
|---|---|
| `ch286:pw-definition`, `representative`, `evaluation` | PW defined by a.e. compact spectral support, B>0; L2→L1 on finite band; inverse integral continuous, same class a.e., uniqueness everywhere. Evaluation bound √(2B) has correct units and supplies global uniform convergence only under a common band |
| `derivative-bound` | Polynomial weighted spectrum integrable; repeated dominated differentiation justified; ∫|ξ|^(2m)=2B^(2m+1)/(2m+1) yields exact displayed constant. Displacement corollary and warning against summing a constant over an infinite lattice both correct |
| `units` | Cycles, angular rates and two-sided width kept separate; r=2BT; normalized sinc and Adams conversion correct. T1/50,B20 numerical r4/5 correct |
| `poisson` | Schwartz periodization and derivative sums converge uniformly on a period; coefficient 1/T and phase sign correct; completeness plus continuity gives pointwise identity |
| `periodization` | Bilinear distribution pairing explicitly distinct from linear-first Hilbert inner product. Dual Fourier convention <F u,ψ>=<u,Fψ> gives comb factor1/T; Schwartz-product convolution substitution and reindexing give ξ−k/T. No undefined product of arbitrary distributions used |
| `alias-packet` | δ<min(C,B−C) places two disjoint intervals inside band. Modulated sinc is L2, spectrum coefficients ±1/(2i), squared norm δ, and canonical samples vanish. Periodic cosine illustration explicitly outside real-line L2 |
| `nyquist-theorem` | Interval length1/T and ONB √T exp(−2πinTξ) normalized correctly. Linear-first coefficient √T f(nT), all-lattice completeness, critical endpoint measure-zero and endpoint-tone exclusion all correct |
| `model-selection` | Ideal filtering creates canonical samples of P_Bu; removed spectral norm and orthogonal energy decomposition correct. Finite-window nonuniqueness proof uses N+1 disjoint spectral supports, then handles real example by real/imaginary parts. Finite periodic preview is separately modeled |
| Eight exercises/solutions | Countable-representative, units/comb, packet norm1/8, Fourier completeness, off-grid finite/infinite distinction, filtered energy5²−3²=4², and five-point periodic model answers verified. No solver result substitutes for a proof |

## Optional clarity edits, not acceptance blockers

1. At the opening of §286.1 say explicitly that `L²(R)` is complex-valued. The Hermitian product already makes this the standard interpretation, and the finite-window proof eventually states the complex model; moving that declaration earlier reduces reader inference.
2. “The Fourier transform on integrable functions” is valid as written. For the next sentence's *unitary extension*, “on L1∩L2, followed by the unitary L2 extension” would pinpoint the common domain. The canonical representative proof already uses the correct L1∩L2 inversion, so there is no failed formula here.
3. The existing Schwartz spectrum formula and qualitative aliasing theorem do not yet calculate the exact folded L2 data operator above critical rate. This is an opportunity for the separately assigned folding extension; it does not invalidate any current theorem.

## Scope and next action

Mathematical KEEP is for the exact hash above, not an acceptance of future additions. Source responsibility is tracked against the fixed P7 §§5.5–5.9.1, P8 §§6.20.1–3 and P9 Appendix A windows from B01. This role directly rederived the chapter formulas; it does not claim newly rereading every source PDF or V21. Build/PDF/full-page QA and sole B07 final audit are separate. Parent will merge/review any optional changes and the assigned isolated `contributions/ch286-folding.tex`; that addition needs its own independent mathematical review. Do not silently carry this verdict across a changed hash.
