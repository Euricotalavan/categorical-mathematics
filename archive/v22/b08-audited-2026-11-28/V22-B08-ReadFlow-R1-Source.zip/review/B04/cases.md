# Chapter 290 B04 author contribution and coverage locations

2026-11-28 UTC · B single Work · author case_study · English · unique body `chapters/ch290.tex`. Actual requested model/mode remains unverified. Read fixed B02 design, cases memo, design supplement, authoring contract, and relevant actual Ch288 labels. No earlier/frozen volume, source table, extractor, or adopted template was edited.

Final chapter SHA-256: `ed94c800940f063b62af095b9550bf9344034f72279f1e2ab033c900e18f907c`. The chapter has about 7,000 whitespace-delimited words, 60 unique labels, seven fixed sections, and eight fully solved exercises. These counts are descriptive, not mathematical acceptance tests.

## Source responsibilities → actual body

| B01 responsibility | Source method/location | Actual labels and evidence |
|---|---|---|
| 290-D01 | Independent case contract | `ch290:case-contract`, `contract-definition`, `budget-language`: reconstruction inputs separated from simulation truth; forward/backward residuals and five error categories declared |
| 290-T01/P01 | P7 §5.8, printed231–236, finite periodic discussion; original finite geometric-sum proof | `geometric-sum`, `periodic-gram`, `periodic-matrix`, `problem-dft`: orthogonality modulo sample count, real grid, complex adjoint and failed residue test |
| 290-D02/T02 | P4 §3.3.2–3, thin QR and least squares; original four-point specialization | `qr-formula`, `periodic-coefficients`, `periodic-residual`, `coefficient-bound`, `function-gain`: full rank, adjoint, QR, minimization, sharp function gain; `problem-weighted` changes the data metric |
| 290-E01 | Original calculations using preceding methods | `periodic-exact`, `periodic-noise`, `periodic-defect-truth`, `periodic-defect-data`, `periodic-defect-output`, `periodic-budget-bound`, `periodic-actual-error`: all data, coefficients, residuals, orthogonal errors and alias budgets explicit. Additional poor-grid variation proves uniqueness can coexist with arbitrarily poor conditioning. `invisible-periodic` restores the quarter-period grid explicitly before the alias counterexample |
| 290-E02/E03 | P10 §§I–IV and Ch287–288 projection/erasure results | `one-erasure-equation`, `sharp-one-gain`, `window-algorithm`, `window-defect`, `window-coordinate-bound`, `window-tail`, `window-M2`, `window-synthesis`, `window-function-bound`, `window-uniform-bound`, `window-actual-function`: full complement vs finite window, exact scalar and function errors, sharp complement gain, tail and noise separate |
| 290-E02/E03 variation | Original two-erasure arithmetic, methods as above | `two-erasure-output`, `two-erasure-actual`: separated two erasures, three acquired values, exact noisy answer, two distinct residuals, exact Gram error. Geometry now cites actual `ch288:geometry-iteration`/`two-erasures`. `lattice-model-residual` separates failed band from a finite tail with an explicit sinc counterexample |
| 290-E04/E05 | P11 §5.1 RNSP framework; independently proved constants in Ch289 | `sparse-matrix`, `small-rnsp`, `bpdn`, `sparse-noise-certificate`, `diagonal-data`, `diagonal-minimizers`, `dense-actual`, `bad-matrix`: hand-certified property, equality BP and dense fit, feasible noisy primary, same constrained set comparison, near-sparse median solution, underestimated radius, and rank-without-NSP failure |
| 290-T03/E07 | Original synthesis/norm accounting | `synthesis-norm`, `function-gain`, `error-budget`, `problem-diagnosis`: coefficient-space/function-space conversion; norms and applicable conditions retained separately |
| 290-E06 | Optional larger RIP example | OMITTED as fixed B02; small RNSP matrix has δ3=δ4=2 and is explicitly not a P12 example |

## Checks and review response

`checks/check_cases_b02.py` passes exact periodic, two-erasure window, projected-sinc actual-error and sparse/dense arithmetic. Direct additional checks in the body derive the primary M2 error, the poor-grid Gram eigenvalues, and the lattice model residual. All internal labels are unique, all fixed §290 labels exist, and internal references resolve. Cross-chapter references use the fixed design exports and actual Ch288 result labels; the integrated build must resolve exports in the chapters still arriving.

Native build: `layout-prep/tools/runs/ch290-b04-handoff2/build-report.json`, paired PDF `build/entry.pdf`: 25 pages including bibliography (chapter body23), no overfull/header diagnostics, one minor underfull prose paragraph, and expected external-reference warnings in the chapter-only build. Table alignment warnings were repaired with ragged-right fixed-width cells. Full-volume integration and B06 all-page visual QA remain pending; no full-page visual-inspection claim is made.

Independent thickening read the first full chapter, then checked the poor-grid and lattice-mismatch additions. Requested mathematical clarifications were implemented: (1) critical example fixes T1 and changes B1/2; (2) forward integral specified on L1∩L2 before unitary extension; (3) full known RHS evaluated with the independent Ch288 odd-square identity, before comparison to truth; (4) geometry references made precise; (5) quarter-period grid explicitly restored after the poor-grid variation; (6) nonzero perturbation specified before dividing by its norm. These edits do not imply whole-volume final approval.

## Handoff

Author → parent, B04 case draft ready for integration/refinement. Unique source hash above; source and PDF snapshot are recoverable through the named build record, which hashes its exact input. OPEN: final integrated cross-reference resolution, reader-side B05 review, source/PDF acceptance, B06 full-page QA, and sole B07 strict whole-volume audit. Parent assigns those roles. No B08 archive/release is claimed. Preserve already verified calculations and fixed cases; do not restart B01, upstream frozen volumes, or template work. Delivery is local shared-workspace save plus parent notification, not external user delivery.
