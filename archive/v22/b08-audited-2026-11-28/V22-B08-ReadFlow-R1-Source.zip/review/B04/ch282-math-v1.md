# Chapter 282 · B-04 independent mathematical review

Actual read covered all 923 lines of the 40,338-byte `chapters/ch282.tex`, SHA-256 `af49a376c081ac266d6d96ea418183d979e85dc57e8878a6eb93fabffe0d202e`. Compared fixed B02 scope and B01 P1/P2/P3 windows and defect evidence. Independent thickening role, model and reasoning setting unverified.

| Body location | Independent result |
| --- | --- |
| 282.1–2, lines 18–237 | Norm and affine transport, polynomial degree and dimension, Lagrange existence/uniqueness, Rolle remainder, vector maximum-norm stability, and the attained three-node gain 5/4 check. Between-node cubic residual −3/8 and global magnitude 2/(3√3) check. |
| 282.3, lines 239–352 | Chebyshev recurrence, leading coefficient, roots and extrema follow from the trigonometric definition for integer index. Monic extremality uses k disjoint gaps and degree k−1 after subtraction. Root nodes minimize the node polynomial factor, with correct scaling h^(n+1). |
| 282.4, lines 354–437 | Barycentric weights, nonnode denominator identity, scaling, removable nodal values and both worked examples check. The erroneous weights genuinely give a pole at zero. One proof-wording issue below. |
| 282.5, lines 438–577 | Mass, first and second moments, weighted near/far split and affine transport establish Weierstrass. Exact x² error and Lipschitz cusp bound verified. No interpolation convergence is inferred from existence. |
| 282.6–7, lines 578–760 | Rational equality, reduction, positive denominator normalization, corrected defect and zero convention, cross-polynomial degree, exact geometric residual and two deterministic error budgets check. The perturbation-family claim needs the types below. |
| 282.8, lines 762–923 | All nine solutions checked. Includes remainder 8/(3√3) versus exact 1/4, monic cubic norm 2, bad-weight poles, third moment for n≥1, endpoint-cancellation defects, and minimal n within the stated geometric sequence. |

| Finding | Source / effect | Repair |
| --- | --- | --- |
| **282-M1** | Lines 730–739 leave u,v untyped, then claim the new quotient is admissible. The bound holds for continuous perturbations but those may take the expression outside the rational family. | Specify p,u∈P_m and q,v∈P_n, with q≥η>0 and a bound on v, before the estimate. The nonvanishing perturbed denominator and the degree bounds then make it admissible in the same family. |
| 282-M2 | Lines 390–392 say to multiply the Lagrange sum by the representation of ℓ_j, although the displayed identity follows by substitution. | Substitute ℓ_j=ωλ_j/(x−x_j) into the sum and replace ω by the reciprocal of the sum of λ_j/(x−x_j). |
| 282-M3 | At lines 243, 447 and 587 degree indices are described only by inequalities; at line 447 the Bernstein operator input is implicit. | State nonnegative integer k, positive integer n, nonnegative integers m,n, and input f∈C[0,1] where appropriate. In the remainder theorem, make x∈[a,b] explicit. |

**Disposition.** Mathematical results, calculations and exercises pass. Definition types and proof wording flagged for the next fixed copy. The 282→284 degree/count and type interfaces are present. Pending full manuscript checks include consumer labels and compilation. No chapter edits or terminal mathematical sign-off asserted.

**Integrated recheck.** Examined the diff from the matching initial build to SHA-256 `a97ead2e82f6ad4d90bd3f6ef9619e9bc2e49da342b6ee784d2ec5f00cd72d3c`. The rational perturbations now have the correct polynomial types, the barycentric derivation explicitly substitutes its factor, and the Bernstein/rational family degree domains are explicit. The added equally spaced conditioning result uses the exact cardinal value at a half-cell, a telescoping product lower bound and an attaining signed perturbation. Exact lower error values are 0.0000594430839002 and 0.061624301194, safely exceeding the displayed comparisons. Direction of the bounds is correct. Mathematical pass for the recorded version.
