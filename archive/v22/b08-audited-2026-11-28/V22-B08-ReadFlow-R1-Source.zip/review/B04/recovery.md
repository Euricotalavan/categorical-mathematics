# V22 recovery author contribution — B04

Version recovery-b04-v2 · 2026-11-28 UTC · Chapters 288–289 only.

Receipt: B02 design v1 and authoring contract read; parent explicitly released B04. The B03 corrected calibration source read was 10,775 bytes, SHA-256 `b0961b9c27f793cb29e0eda67c6cbabf20e0178867920b6f6e9b66af3cea415d`. Its verified mathematics is preserved in §288.4. The sequence-projection dependency is now the exact label `ch287:sequence-projection`; procedural source notes were replaced with P7/P10 citations. No upstream source, frozen volume, template, extractor, chapter boundary or common notation was changed. Actual requested model/High configuration remains independently unverified.

## Chapter 288 ready for independent B04 review

`chapters/ch288.tex`: final identity is in the handoff manifest below. Its initial independent principal-proof review was on 41,060-byte SHA-256 `697ae53a0b0dd2701c8ba1f065e8a7e546476ffbb922539d6f3da1b219c17bb8`; subsequent precision edits and the authorized regularization addition are separately described below.

| Fixed design section | Actual body labels / fulfilled development |
|---|---|
| `ch288:data-contract` | `finite-erasure-data`, `sample-energy-recall`: canonical PW_B model, cycles B/T/r, finite U, entire known complement C, restriction/extension maps, and explicit three-contract table. |
| `ch288:erasure-system` | `q-entries`, `blocks`, `erasure-equation`, `linear-system`: projection block derivation, bounded maps and absolute coordinate convergence. `finite-acquisition-obstruction`: m+1 independent sinc functions and full rank-nullity proof. |
| `ch288:spectral-gap` | `strict-gap`, `passband-form`, `fullband-form`, `complement-form`, `inverse-norm`, `inverse-condition`, `gamma`, `residual-certificate`: both strict quadratic forms; polynomial strictness; finite-dimensional eigen argument; exact inverse norm versus condition number; residual certificate. |
| `ch288:one-erasure` | Corrected B03 inserted, all internal labels retained. `one-erasure-row-norm`, `one-erasure-gains`, `one-erasure-sinc-example`, `one-erasure-odd-sum`, three solved calibration problems. `gain-figure` consumes existing `one-erasure-gains.pdf` with separate input-norm caption. |
| `ch288:geometry-iteration` | `two-erasures`, `two-eigenvalues`: exact signed matrix/eigenpairs, inverse and gaps for adjacent/separated erasures. `diagonal-geometry`: rational arithmetic-spacing proof. `iteration`, `iteration-rule`, `iteration-error`, `neumann-error`: full convergence, Neumann tail, computable stopping rule and noise floor. |
| `ch288:window-errors` | `general-data-gain`, `lift-square`, `general-gain`, `assembled-gain`: independent general exact known-data lift norm via QQ=Q, with attainment. `window-perturbation`, `noise-tail-energy`, `window-missing-bound`, `window-sequence-bound`: finite W, padded data and separate noise/tail energy. `finite-window-value`: positive Gram construction proves a specified erased value undetermined by any finite window. `function-reconstruction`, `function-error`, `uniform-error`: synthesis/projection and explicit norm factors. `error-budget-example`: complete parameter and geometry calculation. Critical endpoint failure explained. |
| `ch288:problems` | Five additional fully solved problems `problem-two-direction`, `problem-iteration`, `problem-positivity`, `problem-window-bound`, `problem-finite-nullspace`. Together with calibration's three and the two later regularization questions this gives ten assumption-selecting solved exercises. |

All names in the table are prefixed `ch288:` in the body. B01 obligations 288-D01–04, T01–07, P01–02, E01–05 have actual mathematical locations in these sections. The large noisy numerical P10 illustration is not duplicated; its role is supplied by the explicit error-budget example and the full numerical case remains Chapter 290's responsibility.

Sources: approved P10 author PDF §§I–IV and integral (3), plus P7 §5.7 and the proved Chapter287 interface. Stronger known-data norms and finite-window-value construction are independently derived, not attributed to an unread source. Q1/Q2 and unread R1–R4 are absent as evidence.

The initial complete Chapter288 principal proofs and exercises passed independent thickening. Requested precision repairs were applied: Fourier integral is initially on L1∩L2 then Plancherel; coordinate norms ≤1, with nonempty equality; finite-acquisition comparison f∈PW_B; projection-interpolation exercise states safe sufficiency; representative reference type corrected to Theorem. The authorized regularization addition still requires its separate independent mathematical review. No chapter PDF or engineering pass is claimed by the author. Parent/layout will compile the fixed chapter with dependencies and existing figure. Source and final PDF hashes must be paired by that stage. No B05/B07 whole-volume pass is implied.

## Chapter 289 ready for independent B04 review

`chapters/ch289.tex`: final identity is in the handoff manifest below. The complete principal proof/exercise body received independent thickening review. Three requested precision repairs were then applied: explicit s-support plus singleton proof of nonlinearity for every 0<s<N; actual scaled-identity weak-RIP counterexample; retitled exact/noisy BP exercise and a full saturation proof of its particular noisy minimizer's uniqueness. The current hash remains subject to repair closure verification.

| Fixed design section | Actual body labels / fulfilled development |
|---|---|
| `ch289:sparsity` | `sparse-definition`, `best-term`, `threshold-optimality`, `tail-formula`, `order-example`: fixed real coefficient model, tie rule, exchange proof, p=1/2 tails, order-versus-magnitude example. |
| `ch289:identifiability` | `sparse-injectivity`, `identifiability-example`: full null-vector/column equivalence, both support-splitting directions, min(2s,N), known versus unknown support and rank/count counterexample. |
| `ch289:nsp` | `bp-definition`, `bp-equality`, `bp-noisy`, `bp-existence`, `nsp-definition`, `nsp-equivalence`, `bad-matrix`: compact-sublevel existence; both NSP equivalence directions; full-rank sparse identification but failed BP example. |
| `ch289:rnsp` | `rnsp-definition`, `rnsp-inequality`, `cone-tube-lemma`, `tube`, `cone-defect`, `top-error-tail`, `rnsp-bound`, `rnsp-error-bound`, `small-rnsp`, `small-matrix`, `small-rnsp-bound`, `scaling-example`: full independent quantitative proof, top-s error support, explicit coordinate identities, constants9 and7√5, scaling diagnostic. |
| `ch289:rip` | `rip-definition`, `rip-inequality`, `gram-rip`, `gram-formula`, `small-rip-failure`, `p12-condition`, `rip-gap`: squared-norm convention; finite Gram proof, monotonicity, k>N saturation; small matrix δ3=δ4=2 fails main sufficient criterion; d>0 equivalence. |
| `ch289:tube-cone` | `block-lemma`, `block-sum`, `block-tail`, `p12-sparse-theorem`, `exact-block-sum`, `p12-sparse-bound`, `constant-example`: complete sorted3s-block proof with short/empty last block, positive gap, Pythagorean exact-sparse constant4/(√3d), upward-rounded10.48η example. |
| `ch289:near-sparse` | `p12-near-theorem`, `p12-near-bound`, `near-constants`, `near-cone`, `near-blocks`, `near-head`, `decay-tail`, `radius-failure`: full cone-defect and block proof, explicit separate B02 noise/tail constants, four-case table, power-decay model and wrong-radius example. |
| `ch289:problems` | Eight full solutions: `problem-ties`, `problem-null-vector`, `problem-bp-unique`, `problem-blocks`, `problem-rip-check`, `problem-rnsp-certificate`, `problem-tail-noise`, `problem-radius`. Includes actual noisy uniqueness proof, RIP numeric constant check, actual scaled identity countermodel, and scaling of robust constants. |

All abbreviated names are prefixed `ch289:` in the body. B01 obligations289-D01–07,T01–05,P01–05,E01–05 are discharged in the mapped body. Sources: P6 §2 for best-term orientation, P11 §§5–5.1 for NSP/RNSP statements and context, P12 fixed arXiv v2 §§1–2 for the separately and completely proved cone/tube/block route. No survey theorem with an unprinted proof is used as a substitute for a proof. No random/RIP sample-complexity, dictionary, TV, or low-rank theory was added.

## Authorized original finite-erasure diagnostic

Parent requested a short regularization comparison inside existing §288.6 after the principal Chapter289 review. Added `ch288:regularization-diagnostic`, `regularized-answer`, `regularization-bias`, `eigenwise-regularization`, `regularized-bound`, `regularized-data-gain`, and `regularization-example`: M+λI damped inverse, complete eigenwise bias/noise proof and exact operator gains, plus explicit r=3/4 hand calculation. This is original finite-dimensional analysis derived from the already proved spectral facts, not a claim imported from unread inverse-problem literature.

Two solved questions (`problem-regularization-budget`, `problem-spectral-filter`) prove the sharp norm-ball worst case G(λ), its monotonicity/no-universal-interior-optimum, and a two-erasure spectral-prior example where damping improves the actual error. This preserves the fixed chapter/section boundary and does not claim that an arbitrary penalized answer identifies the true signal. Initial combined norm-only bound is sharp when truth and noise occupy the adverse minimum-eigenvalue direction. Separate supplied spectral information excludes that worst case in the second question.

## Handoff status

| Final author file | Bytes | SHA-256 | State |
|---|---:|---|---|
| `chapters/ch288.tex` | 49,069 | `0a3a03108aa372b978f9d50905d56bffcefee3f743f989211753a1443472a799` | Principal review passed; precision edits and original regularization addition require closure |
| `chapters/ch289.tex` | 41,094 | `2f24044ac84ce75f93561ece82611539fe040c18afb9e75f4231c81a7b18717d` | Principal proof/exercise review passed; three requested precision repairs applied, closure pending |

Validation by author: all own references resolve to actual labels; no duplicate own labels; theorem/proof/definition/example/problem/solution and display environments have matching begin/end pairs; arithmetic for both RIP constants, the small RNSP constant and regularization examples independently recalculated. This is limited source validation, not compilation or page acceptance. Parent/layout has the existing gain-figure asset. Actual paired PDF hashes and build/visual evidence are owned by integration/layout and are not invented here.

OPEN: exact upstream reference environment types and frozen crosschapter body checks belong to B05; current numerical/operator proof closure belongs to independent reviewer. Preserve these stages and the sole B07 audit. No external transmission, publishing, or remote durability is claimed by this author subtask; the controller handles its authorized checkpoint and combined handoff.

Handoff ID `V22-B04-RECOVERY-CH288-v1` · recovery author → parent and independent thickening. B single Work, B04, corresponding to staged expansion/thickening/refinement rather than sole final audit. Only own chapter/contribution files changed. No user decision required. Parent is notified of the fixed source/hash and owns durable checkpoint. Receipt and subsequent mathematical/engineering acceptance remain separate from this author-ready report. Next unique action: independent closure review of the Chapter289 precision changes and Chapter288 regularization addition, then fixed chapter engineering/integration. All authoring is saved; no whole-volume pass is claimed.
