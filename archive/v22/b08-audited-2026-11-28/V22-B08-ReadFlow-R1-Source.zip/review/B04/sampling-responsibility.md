# V22 B04 author responsibility and actual-body record: Chapters 285–287

Version sampling-body-v1 · 2026-11-28 UTC · `/root/sampling` → coordinator and independent thickening/refinement.

## Receipt, fixed inputs, and status

Actually read B01 `sampling.md` (SHA256 `083fc10e778a2f653d4fe4cf143bcef614071128e5e6bbebea32276bf1579e49`), B02 `design.md`, `proof-dependencies.md`, `design-supplement-v1.md`, `sampling-contract.md`, and `handoff/authoring.md`. Adopted the final design's **S_j** notation, q∞, 0<α<1; the earlier contract's V_j was only a proposal. B03 one-erasure style was parent-approved before this assignment; this author does not claim to have conducted that calibration. English source is now written, with real theorems, proofs, worked examples, problems and complete solutions. This is author delivery, **not sole B07 approval**.

| File snapshot | Bytes | SHA256 | Ownership/status |
|---|---:|---|---|
| chapters/ch285.tex | 35373 | `19328f50a42fe9c2df5f56bf9c08bd79d003681887dbd56d7b64cc5fb5c9163d` | Author completed initial body, independent small corrections, and parent-requested detail/step extension. Initial body independently reviewed; extension needs its own same-body independent check. |
| chapters/ch286.tex | current shared source | `9fff7caf2f2464c7479022ab656c2fd3adc561db37132c77473991fd1c10d275` at this check | Initial author snapshot was 25795 bytes / `4b945a84a1cb5cc89ad939271b8b7e1ebaff6277dba995abb7c1f1bd46975f1b`; parent has merged separately reviewed folding extension and owns subsequent changes. This author respected the parent's lock and did not edit that merged file. |
| chapters/ch287.tex | 32067 | `bf244d09862681177ae8c017dbeafb03338c72159b32e52966a3208118883a65` | Author completed; one math-preserving problem-display polish after first build. Independent mathematical review pending at preparation of record. |
| contributions/ch286-folding.tex | separate contribution | `b5726b7c42d027e81cbbc2169aa1d7ab8dc2775c7c1df5b92c632f717ee23bdf` | case_study contribution, parent-reviewed/merged. Read by this author for interface awareness, not independently signed by this author. |

All source PDFs and original page locators remain exactly as recorded in B01; P5–P9 were actual public reads, R1–R4 were unread bibliography only, Q1/Q2 excluded. Mathematical developments below are independently written derivations, not reproductions of source pages or source diagrams. In particular P6's omitted inverse proof, P7's informal compact-support argument and P9 A.8 sign are not silently inherited.

## Source responsibility → actual location

Status **BODY** means the author supplied the stated definition/argument/example at the cited label or named environment. It does not mean an independent reviewer or B07 has passed it. **ALLOCATED/EXCLUDED** reflects the fixed B02 boundary, with reason. Source VERIFIED status remains the B01 actual-read status, not a blanket claim of future textbook coverage.

### Chapter 285

| B01 item | Actual body anchor / contribution | Author disposition |
|---|---|---|
| 285-D01 | `ch285:dyadic-spaces`, definition Continuous dyadic affine spaces | BODY: j≥0, no endpoint constraint, dim2^j+1, nested; concrete adopted linear scheme. General nonlinear scheme is orientation only, not a new general theorem. |
| 285-D02 | `ch285:best-error` and its proof | BODY: infimum, orthogonal minimizer, uniqueness/Pythagoras, monotonicity, density and 1-Lipschitz distance. |
| 285-D03 | `ch285:approximation-class`, definition and following proposition | BODY: ambient norm + dyadic supremum; vector space, norm, completeness. |
| 285-P01 | `ch285:approximation-class`, dimension/work calculation | BODY selected scale/complexity relation; nondyadic 1/n-sum equivalence excluded as optional not needed by final q∞ design. No claim its full proof appears. |
| 285-P02 | `ch285:approximation-class`, proposition; sequence example | BODY smoothness-exponent inclusion and supremum interpretation. Finite-q embeddings not adopted as a theorem. |
| 285-D04 | `ch285:k-functional`, H1 and K definitions | BODY full H1 norm, AC representative explicitly on closed [0,1], arbitrary competitor/infimum. Unused weak-derivative equivalence removed after review. |
| 285-P03 | `ch285:k-facts` | BODY bounds, exact K(f,1)=||f||2, nondecreasing/concave K, nonincreasing K/t, subadditivity/homogeneity. |
| 285-D05 | `ch285:k-functional` | BODY exact adopted real interpolation definition 0<α<1,q∞. |
| 285-P04 | `ch285:k-functional`, paragraph after `ch285:k-dyadic` | BODY unequal endpoint operator bounds M0,M1 and M0^(1−α)M1^α via rescaled t. Positive constants explicitly assumed. |
| 285-P05 | `ch285:k-dyadic` | BODY full low-scale dyadic comparison, including ambient norm and t≥1. |
| 285-D06 | `ch285:direct-inverse`, opening and two named theorems | BODY separates direct from inverse, adopted X/Y/S_j only. |
| 285-T01 | `ch285:jackson` | BODY AC interval integral, derivative mean removal, h/√2 constant, then E_j(f)≤K(f,h_j) by infimum. |
| 285-T02 | `ch285:bernstein` | BODY exact affine mass completion, sqrt12 derivative, sqrt13 full norm; AC joining, no broken-space inverse. |
| 285-T03 | `ch285:main-theorem` under `ch285:interpolation-equivalence` | BODY complete two directions q∞ 0<α<1, P0 + increments, geometric sum and dyadic K. No unread R2 proof citation. |
| 285-P06 | `ch285:best-error`, proposition An expansion by successive resolutions; `ch285:detail-rate` | BODY density, telescoping L2 limit, orthogonal details, exact tail identities and two-sided detail-rate norm equivalence for every α>0. |
| 285-E01 | `ch285:approximation-class` sequence example; problems An actual family with a prescribed rate, Sharp constants in the detail comparison | BODY sequence-level caveat followed by real L2 construction using S_k∩S_(k−1)^perp, exact geometric tail. |
| 285-E02 | `ch285:quadratic` | BODY both nodal h²/√30 and best continuous-affine h²/√180, moment orthogonality, explicit continuous correction; resolution problem checks actual tolerance. |
| 285-E03 | `ch285:limits`, broken jump example; `ch285:step-rate` | BODY broken-space exactness versus continuity; continuous-space jump has sqrt(h/8)≤E≤sqrt(h/6), exact exponent α≤1/2. |
| 285-D07 | Cross-reference `ch283:hats`; adopted H1 nodal input in `ch285:jackson` | ALLOCATED general functional locality/reproduction/boundedness to `ch283:local-operator` per fixed design. Ch285 does not claim general P5 local-functional theorem coverage. |
| 285-T04 | Fixed design transfers P5 general local-to-global result to Ch283 | EXCLUDED from adopted Ch285 theorem inventory; concrete direct proof complete above. No unproved Lq/degree-general theorem imported. |

Additional author result `ch285:endpoint-failure`: disjoint dyadic tents prove A^1∞ need not lie in H1, with exact mass/derivative integrals. New detail theorem's constants are tested by isolated and geometric-detail extremizers. There are nine fully solved problems; dimension budget is qualified for M/ε≥1 with fixed base level otherwise.

### Chapter 286

The following items locate the initial author body, retained by the parent through merging. Later parent changes require the new source/PDF to be checked separately.

| B01 item | Actual anchor / evidence | Author disposition |
|---|---|---|
| 286-D01 | `ch286:pw`, `ch286:pw-definition` | BODY complex Hilbert spectral subspace, a.e. support, closedness. Parent may clarify complex-valued at opening. |
| 286-P01 | `ch286:representative`, `ch286:evaluation` | BODY compact L2 spectrum⊂L1, continuous inverse representative, uniqueness, sharp-scale bound sqrt2B (no claim of point values for arbitrary L2). |
| 286-E01 | first example after evaluation | BODY zero-a.e. function with changed countable values; canonical sampling resolves ambiguity. |
| 286-D02 | `ch286:units`, conversion table and numerical example | BODY B/T/C/r; angular conversion direction corrected by parent after independent review. |
| 286-D03 | `ch286:units`, sinc definition/inverse box calculation | BODY normalized sinc incl0, P8 argument conversion and P7 p=2B. |
| 286-D04 | `ch286:comb` | BODY bilinear tempered-distribution pairing, Schwartz weighting, sequence vs comb distinction. |
| 286-T01 | `ch286:poisson`, `ch286:periodization` | BODY full Schwartz Fourier-coefficient proof, both comb factor1/T and sampled spectral shifts with correct sign. No arbitrary-distribution multiplication. |
| 286-E02 | `ch286:aliasing`, periodic cosine example | BODY cos9πt/2 vs cosπt/2 at integers explicitly outside nonzero L2(R). |
| 286-E03 | `ch286:alias-packet` and packet example | BODY actual nonzero L2 null signal sin(πt/T)2δsinc2δt with disjoint supported packets, norm²δ. |
| 286-T02 | `ch286:nyquist-theorem` under `ch286:nyquist` | BODY injectivity iff2BT≤1, complete frequency exponential proof, all samples, endpoint null-set condition; converse actual packet. |
| 286-E04 | endpoint-tone example after Nyquist proof | BODY sine endpoint deltas outside L2 distinguished. |
| 286-D05 | `ch286:model-selection`, ideal prefilter paragraph | BODY parent-inherited spectral projection definition and exact removed energy; operative synthesis theorem `ch287:band-projection`. |
| 286-E05 | unit numerical example and Rate and units problem | BODY explicit cycles/radians/r calculations, no copied source diagram. |
| 286-P02 | `ch286:model-selection`, finite-window proposition and periodic preview | BODY finite arbitrary-time nonuniqueness via N+1 disjoint spectral supports, real case handled, separate periodic finite-dimensional model. |

Added author theorem `ch286:derivative-bound` proves all finite derivative uniform bounds by dominated differentiation and supplies controlled point displacement. Its warning must say **the pointwise bound alone** does not establish ℓ2 error; actual bounded jitter plus derivative L2 can do so, as Ch287 proves. Parent was sent this independent review correction and owns merged Ch286.

Separate parent-reviewed contribution: `ch286:fold-definition`, `ch286:fold-theorem`, `ch286:fold-coefficients`, `ch286:fold-energy`, `ch286:fold-nullspace`, `ch286:fold-series`, `ch286:fold-minimum`, `ch286:fold-minimum-formula`, `ch286:fold-minimum-energy`, the overlap/minimum examples and three problems. It develops exact folded L2 observation operator, sharp multiplicity norm, nullspace and minimum-energy fiber inverse above critical rate. The contribution belongs to case_study plus parent's independent review; this report does not recast it as this author's proof or independent signoff. Original body has eight complete solutions; contribution adds its own distinct examples/solutions.

### Chapter 287

| B01 item | Actual anchor / evidence | Author disposition |
|---|---|---|
| 287-D01 | `ch287:sinc-onb`, definition Critical sinc functions | BODY phi_k^T=T^-1/2 sinc(t/T−k), transform factor sqrtT. |
| 287-T01 | `ch287:onb` | BODY orthogonality/completeness transferred from frequency exponential basis, not circular sampling assumption. |
| 287-P01 | `ch287:onb` proof | BODY coefficient sqrtT f(kT), explicitly linear-first inner product. |
| 287-T02 | `ch287:sample-energy` under `ch287:cardinal` | BODY L2 cardinal expansion then global uniform convergence by common band, finite exhausting index sets; scalar absolute convergence proved after kernel. |
| 287-T03 | `ch287:sample-energy` | BODY ||f||²=TΣ|samples|², onto unitary U_T, raw R_T norm sqrtT. |
| 287-P02 | `ch287:kernel` | BODY reproducing kernel K_B,x, norm²2B, sinc-square identity1. |
| 287-D02 | `ch287:band-projection`, `ch287:frame`, `ch287:sequence-projection` | BODY projected atom r sinc2B(t−kT), Parseval frame, smaller-band consistency range, raw vs projected outputs. |
| 287-T04 | `ch287:noise` | BODY exact raw noise L2 norm, raw uniform bound, projected contraction and sqrt(r) uniform bound; ℓ2 declared. |
| 287-T05 | `ch287:window-identity` | BODY exact finite-window raw squared error T(tail²+noise²), projected upper bounds, no global universal truncation rate. |
| 287-T06 | `ch287:model-budget` under `ch287:model-error` | BODY filtered observation contract, exact orthogonal model+projected-data split, triangle bound for raw wider-band output, cancellation counterexample. |
| 287-E01 | finite three-sample example after kernel | BODY T2 data (1,2,−1), norm²12, off-grid value20/(3π). |
| 287-E02 | missing-coefficient/perturbation example; Window noise and tail problem | BODY exact disjoint-coefficient energy, not residual-only certificate. |
| 287-E03 | bounded-amplitude paragraph; corresponding solved problem | BODY sqrt(TM)η for M entries, attained; infinite constant vector outsideℓ2. |
| 287-E04 | end of `ch287:model-error` | ALLOCATED full periodic calculation to `ch290:periodic-fit`; brief distinct-model bridge only, no periodic L2(R) identification. |
| 287-E05 | `ch287:noise-truncation`, omitted-cardinal counterexample; Interior versus global truncation problem | BODY finite-window retained zeros versus nonzero global signal; Ch286 also proves any finite observation set nonunique. |
| 287-D03 | `ch287:model-budget` | BODY data samples of P_Bu, no invented point-values of u or model residual. |

Additional required interface: `ch287:sequence-projection` proves Q=U_T P_B U_T*, Q²=Q=Q*, exact range, Q_jk=r sinc(r(j−k)), row ℓ2 norm sqrt(r), absolute scalar row convergence and justified matrix-square identity. Sharp half-band complement-row gain is proved and solved. This discharges the dependency used by Ch288's one-erasure calibration.

Additional author result `ch287:offgrid`: local interior truncation bound with explicit sinc tail factor sqrt(2/[π²(N−A)]); global counterexample kept distinct. Derivative-based finite and all-grid displacement error bounds are proved under explicitly specified interval disjointness; common shift sharper bound proved by spectral multiplier, with no irregular-grid invertibility claim. Nine fully solved problems check scaling, projected impulse, row convergence, energy/noise, local/global distinction, sharp row gain, amplitude versus energy, common shift and model-error orthogonality.

## Checks, limitations, and next stage

Author mechanical check: balanced begin/end for theorem/proposition/lemma/example/proof/problem/psolution; no duplicate labels in any authored file at the checked snapshots; no ESC bytes. Chapter285 has18 labels, Ch286 initial body15 labels (parent fold adds more), Ch28715 labels. This mechanical check is not a proof audit.

| Build | Fixed input | Observed engineering result |
|---|---|---|
| `layout-prep/tools/runs/author-ch285-expanded/build-report.json` | 3ee6e1c… | 20-page chapter build including bibliography; no overfull/header/underfull; only ch283:hats and ch284:projection undefined because omitted from this isolated build. Source/PDF hash pairing in report. |
| `layout-prep/tools/runs/author-ch286/build-report.json` | original4b945a… | ENGINEERING_PASS,15 pages including bibliography; no hard/overfull/header/underfull. Parent merged folding afterward, so this PDF does not pair with the new merged hash. |
| `layout-prep/tools/runs/author-ch287/build-report.json` | original9edc8f… |18 pages including bibliography; only omitted external ch286 references and one underfull problem paragraph. Math-preserving display polish saved as ba5564… and rebuild launched at `author-ch287-polished`; use that later build report for the current pair. |

No full-page visual inspection is claimed by this author; B06 owns integrated R1 typography and whole-book visual QA. No attempt to manufacture a page quota; actual depth and missing hypotheses remain subject to independent review. Standalone undefined references are known already existing export labels and must resolve in the integrated book, rather than being suppressed there.

Review read-in: parent and thickening accepted initial285 proofs and all seven initial solutions, requested AC endpoint/weak-language/monotonicity/budget changes, all incorporated before extension. Independent original286 core/eight problems accepted by thickening and case_study; parent owns two clarity corrections and separately merged folding review. Current285 extension and current287 still require same-fixed-body independent check. A changed hash never automatically inherits an old pass.

OPEN-B04-S1: independent actual-body review of new285 detail/step theorem and two added problems, and the bounded287 repair receipt. Owner independent thickening/refinement; blocks chapter final acceptance, not author handoff.
OPEN-B04-S2: parent merged286 source/PDF new pairing and final correction check; original author build cannot certify it. Owner parent/layout.
OPEN-B04-S3: integrated references, proof/source coverage recheck, chapter seams and all error-model assumptions at B05, then B06/B07. Owner designated roles.
UNKNOWN: actual requested model/High runtime setting not independently exposed; V21 exact PDF content remains parent-read evidence; historic topic/chapter mapping and six global gates unchanged UNKNOWN. R1–R4 unread/Q1Q2 excluded. No user decision is needed to continue the assigned workflow.

## Formal internal handoff

Handoff V22-B04-SAMPLING-v1 / sampling-body-v1 /2026-11-28 UTC. Sender `/root/sampling` chapter author → parent coordinator and independent B04 review. B single Work, fixed global285–287 in V22 282–290 following V21 281, original A mapping: expansion/thickening/refinement body phase. Authorization is parent's explicit B04 start after fixed design/calibration. KEEP earlier volumes, numbering, curriculum/reference tables, extractor ZIP, source PDFs and adopted R1 artifact baseline; no publication or frozen-file edit performed. This task only authored assigned chapter paths plus responsibility memo and nonpublic engineering runs.

Manifest: three chapter source snapshots above; B01 sources/versions/pages/bytes/hashes remain in fixed sampling index; template and dependency hashes in each build report. Source/PDF pairing is exact at each report's snapshot and not generalized to subsequent changes. Parent owns durable artifact packaging and remote verification. Compilation command: `python3 layout-prep/tools/build.py --chapter NNN --name author-chNNN --back /absolute/path/bibliography.tex --allow-diagnostics`; isolated missing external references explicitly listed, not an integrated pass.

Completion means author bodies and this evidence map are available. Next unique action is independent fixed-body B04 read and bounded corrections, followed by parent integration; no duplicate author manuscript or restarting passed upstream work. B07 sole mathematical final audit remains pending. Transmission: chapter-ready milestones sent by collaboration messages, complete responsibility memo local and sent next; receiver must actually read/verify exact hashes before passing onward. No claim of user delivery, public release, Library upload, whole-volume acceptance or already-completed visual QA is made by this internal task.


Final bounded review patch receipt: parent requested `ch285:chapter` immediately after the chapter command; inserted, producing19328f50…. Ch287 independent thickening passed ba556416… with one necessary strict B<C assumption and two clarity changes; all three were applied, producingbf244d09…. Original author286 remains locked; parent reports merging/reviewing folding and correcting jitter/units prose. Smooth-window extension for287 is assigned separately and is not part of the authorbf244d09… snapshot; parent owns its merge and separate review. No label was moved from an operative theorem to a different reference type.
