# Chapter 284 · B-04 independent mathematical review

Actual read covered all 1,094 lines of `chapters/ch284.tex`, 46,223 bytes, SHA-256 `2ca1247e82dc10265f0758bf84503bbee6820c89e88158017eb9c78bc5aa6a74`. Compared P1b, P1c, P2 §§6.3–6.4 and P3 §1 and the earlier independent B02 premises. Independent thickening; reasoning setting unverified.

| Body location | Independent result |
| --- | --- |
| 284.1 compactness and existence | Norm-equivalent coefficients through positive minimum on the sphere, closedness, bounded minimizing sequence and distinction from uniqueness all check. Example gives the full coefficient interval [−1,1]. |
| 284.2 uniform polynomial alternation | Extremal sign compact sets have positive separation, so the sweep terminates and cuts can be placed strictly in the gaps. The two uniform margins are explicitly proved near and away from extrema. Necessity, sufficiency by distinct roots, midpoint uniqueness and exact-zero separation all check. |
| 284.3 Remez fixed node system | Nonsingularity and lower certificate hold for each declared candidate. Examples compute both incomplete and complete certificates with independently valid whole-interval bounds. |
| 284.4 projection | Positive Gram, normal equations, orthogonality and minimality both directions, contraction and x² computations all check. Type/conditional wording in theorem below. Weighted continuous and sampled positive-definiteness are distinguished properly. |
| 284.5 real rational existence | Denominator normalization controls numerator and prevents zero denominator polynomial in the limit. Multiplicity argument works one-sided at endpoints. Fixed allowed type survives cancellation and pointwise inequalities extend by continuity. |
| 284.6 defect and rational uniqueness | Dimension calculation for onto direction map and separate zero kernel case check. Rational variation retains allowed degree and positive denominators, with uniform t-independent denominator bounds. Weak-sign lemma uses leading Lagrange coefficient with denominator sign (−1)^(k−i), so it forbids duplicate-root counting. Worked rational candidate and lifted positive-defect five-node certificate check exactly. |
| 284.7 exercises | All ten solutions checked. Includes sampled coefficients (−1/8,1), squared error 1/16, cubic projection 3/5 and squared error 8/175, pole-order and shared-root boundaries, and projection perturbation. |

| Finding | Source / impact | Repair |
| --- | --- | --- |
| **284-M1** | Lines 388–397 state equivalences for q but state the following Pythagorean identity without reattaching the minimizing/orthogonality condition. | Introduce an arbitrary candidate q for the equivalences, then condition the identity explicitly: “For q satisfying these conditions and every v∈V, …”. |
| **284-M2** | Line 529 unconditionally calls R_m,n nonlinear, although n=0 makes it exactly P_m. | State that for positive denominator degree the family need not be linear, and n=0 is the polynomial family. |
| 284-M3 | Lines 507–511 show the sampled Gram at one node without declaring its weight. | Set its weight to one so the displayed matrix matches the prescribed sampled pairing. |
| 284-M4 | Line 116 references `ch285:chapter`, which was absent from the reviewed Ch285 source. | Add the chapter label in assembly or target its appropriate named section. |

**Disposition.** The key polynomial and rational proofs and worked certificates pass. Required statement conditions and the zero-denominator-degree example scope are routed for correction. No chapter source edits by reviewer. Cross-reference and PDF verification belong to assembly and later stages.

**Patch recheck.** Compared the complete diff against the matching initial author build. SHA-256 `9ad7973dfbb4ca2b84cc4160d187246553c6d70521625f05a1f303672cb4ca82` closes M1–M3. Ch285's chapter label was independently confirmed present in its current source, closing M4. Mathematical pass for this fixed Chapter 284 version.
