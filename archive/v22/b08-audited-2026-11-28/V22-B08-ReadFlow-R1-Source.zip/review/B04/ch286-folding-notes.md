# Isolated B04 folding extension — merge and verification notes

2026-11-28 UTC · case_study author · explicitly parent-assigned extension. Unique patch is `contributions/ch286-folding.tex`, 12,718 bytes, SHA-256 `b5726b7c42d027e81cbbc2169aa1d7ab8dc2775c7c1df5b92c632f717ee23bdf`. It does not edit `chapters/ch286.tex`; the independent refinement verdict on old Ch286 hash remains separately scoped. Actual requested model/High mode unverified.

## Placement and dependencies

Insert after the `ch286:periodization` proposition/proof, before the qualitative spectrum-copy paragraph or before `ch286:aliasing`. It is a subsection-level continuation of the Schwartz comb section, not a competing chapter or a change of the fixed section-label contracts. Existing text may still retain its qualitative picture and the P9 phase remark. The extension uses the existing definitions of PW_B and canonical representative, cycles convention, normalized sinc, the inherited Plancherel theorem, finite-interval Fourier completeness and Parseval. It extends the exact L2 calculation beyond the Schwartz product domain without using products of arbitrary distributions.

All fourteen labels begin `ch286:fold-` and are unique internally. Theorems are original elementary derivations from those prerequisites, not claims copied from source numerics. Source-method context remains P7 §§5.5–5.7/P8 §6.20/P9 Appendix A in the fixed B01 ledger; this extension makes no new source-reading or external-source claim.

## Mathematical checkpoints for independent review

- Fundamental interval is half-open, fixed length1/T. Compact support leaves only finitely many relevant k even for nonsmooth L2 spectra. Translated exceptional sets remain null.
- With linear-first inner product, coefficient against √T exp(−2πinTξ) is √T f(nT), hence exact Parseval identity T||s||²=||G||². The Fourier series for G has factor T and is asserted in L2 only.
- Multiplicity bound is essential: M=ceil(2BT). Integer endpoint coincidences can increase a pointwise count on a null set and must not increase the operator norm. Average multiplicity r proves positive measure of the M-sheet region, establishing sharpness by equal sheet values.
- Same-data equivalence is exact folded-spectrum equality. The kernel is fiber sums zero; no scalar positivity shortcut replaces this characterization.
- A prescribed G is admissible iff it vanishes where m0. Equal values G/m minimize fiber energy; cross terms vanish against zero-sum fibers. This proves existence, uniqueness, norm formula and orthogonal decomposition, with no division on forbidden fibers.
- Worked T1,B3/4 example: m1 on center length1/2, m2 on outer total length1/2. Band indicator has spectral energy3/2 and folded energy5/2. An overlap-only spectrum has energy1 and folded energy2, attaining M2.
- Second worked example prescribes unit sample sequence: G1, minimum spectrum 1/2·1[-3/4,3/4]+1/2·1[-1/4,1/4], signal (3/4)sinc(3t/2)+(1/4)sinc(t/2), energy3/4, distance1/2 to sinc t. Both fit identical samples.
- Three fully solved problems check a forbidden-support inconsistent input, integer-overlap endpoint handling, and admissible perturbation norm conversion. Arbitrary ℓ2 noise need not be admissible in an oversampled band.

## Verification / limits / next

Exact rational energy arithmetic and all fourteen internal labels/refs checked. Native six-page sample build `layout-prep/tools/runs/ch286-folding-b04/build-report.json` is ENGINEERING_PASS: no hard, overfull/header or underfull diagnostics; two passes. PDF `build/entry.pdf` SHA-256 `a28198be99d0735f5bda63d587d873dd4bdc097b0ac9d44a27a2e9330d8c63af`. This standalone sample has no chapter wrapper, so numbers are engineering-only; parent must rebuild in its actual Chapter286 location. No full-page visual review or final mathematical acceptance is claimed.

Parent merges only after independent mathematical review, then rechecks the integrated reader path and references. The old Ch286 KEEP report does not automatically approve this changed body. B05/B06 and sole B07 whole-volume strict audit remain pending. Keep original source/PDFs, fixed template, extractor and frozen volumes. Shared-workspace save and parent notification constitute delivery here; no external transmission or B08 archive claim.
