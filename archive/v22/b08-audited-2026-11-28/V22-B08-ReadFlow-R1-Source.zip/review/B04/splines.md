# V22 Chapter 283 B04 author handoff

Version 2 · 2026-11-28 UTC · Expansion/Chapter283 author → parent, independent thickening/refinement and B05 reading-path review.

Status: **single chapter body passed parent-reported full independent B04 review and patch-only mathematical recheck** at source SHA-256 `a8b7c82b248c9ee5c6272a58dd27f240c6ffe424e15da953c09c756dd67302e6`. Author engineering precheck and exact arithmetic checks passed. This is not B05 completion, B06 full-volume layout QA, or B07 final audit. Actual requested GPT-6.1 Sol/High settings remain independently UNVERIFIED.

## v2 review patches and exact pair

Parent and `/root/thickening` independently read the full initial chapter (SHA `cebfda29…`) and all ten solutions. Parent routed six scope refinements, all applied to the same source:

| Issue | Original gap | Applied fix / downstream effect |
| --- | --- | --- |
| SPL-P1 knot mesh | h originally introduced for a separate Δ | §§283.5–7 explicitly define h as maximal consecutive t-knot difference; repeated knots add zero spans. Greville rate now uses its own actual mesh. |
| SPL-P2 discontinuous sup | General spline can jump, so maximum may not be attained | Define its pointwise infinity norm as supremum. Continuous special cases still attain maxima. |
| SPL-P3 local interval | Taylor interval needed input domain bound | Require J⊂[a,b] in local theorem. |
| SPL-P4 full multiplicity | Greville continuity proof summarized endpoint matching | Explicit indices t_j…t_{j+p}=c, B_{j−1,p} left limit1 and B_{j,p} right value1; all other limits0; both Greville points c. |
| SPL-P5 p0 coefficient | y^(p−1) comparison required p≥1 | State that hypothesis before comparison. |
| SPL-P6 rate preview | Endpoint0 used after a general [a,b] setup | State uniform mesh of[0,1] in the natural-rate preview. |

Thickening explicitly rechecked all six at `a8b7c82b…` and reported mathematical pass by direct message; parent has the receipt. These were scope/clarity fixes, not replacement proofs or changed rates. Independent semantic review of the rest is inherited from that full initial read plus this patch recheck. B07 remains independent whole-volume final review.

Current body: `chapters/ch283.tex`, **53168 bytes**, SHA-256 `a8b7c82b248c9ee5c6272a58dd27f240c6ffe424e15da953c09c756dd67302e6`. Current author sample: `layout-prep/tools/runs/ch283-author-v2/build/entry.pdf`, **154861 bytes**, SHA-256 `093ddd2b293240214cef6c89191b88dd4a0d08f2352b0c4d96a30c295b816ffd`. Its build-report input hash matches the current source exactly. It compiled in two passes with no hard/overfull/header diagnostic; the same one underfull paragraph remains. It still has25 chapter pages plus one temporary bibliography page.

After the patch I rendered every current page; sequential contact-sheet view checked physical pages7–26, including all revised text and the downstream page chain. Initial pages1–6 are unmodified and had already been viewed; v1 formula enlargements remain historical evidence, not a claim of v2 full-page independent QA. No clipping/invisible content observed in the revised overview. Both build runs and reports are retained. The next action is B05 integrated reading-path review, then B06/B07 as authorized; no further local mathematical patch is OPEN here.

## Receipt and fixed scope

Read `b02/design.md` v1 and supplement v1, own `b01/interfaces.md`, the fixed `b01/approx.md` Chapter283 responsibilities, authoring/build contracts, and relevant B rules. Parent explicitly released B04 and assigned only `chapters/ch283.tex` and this contribution record to this role. No other author's body was modified.

Fixed whole-volume boundary: V22 Chapters282–290; this chapter is283, *Splines and Local Approximation*. V21 ending281 remains frozen at parent-verified commit `880969bd1ca5e64e3f0d34fb01d25c54562b94e6`. The present chapter needs no unverified upstream theorem-number claim: elementary finite-dimensional rank, polynomial root identity, Rolle, integration by parts, uniform continuity and Taylor remainder are restated or used explicitly. The continuous affine interface to285 has **no endpoint boundary condition**; natural cubic conditions belong only to the separately defined cubic problem.

The unique body has eight sections with all fixed exports:
`ch283:spaces`, `ch283:hats`, `ch283:linear-error`, `ch283:natural-cubic`, `ch283:bspline-recursion`, `ch283:bspline-basis`, `ch283:local-operator`, `ch283:problems`.

## New actual source reading and proof-gap closure

P5 fixed PDF: `sources/P5.pdf`, 304521 bytes, SHA-256 `2e5345b72a6dfccdfa2adc9917d18f7d8066e52d66b20b6fff8d30c42dcc9095`.

In addition to the B01 windows, this author actually read the original PDF's printed/physical pp5–9 and13–14. Pages were rendered with pdftoppm and visually examined, not only text-extracted. Page5 supplies Theorem5 dual recurrence/difference;6–7 Theorem7 local Marsden and local polynomial independence;7–8 Theorem8 derivative proof;9 Theorem11 multiplicity proof;13–14 truncated-power dimension and Curry–Schoenberg basis proof. Text-extracted context also included pp10–17 and27–29, for open endpoints, global partition/Greville identities and local approximation Definitions28–30/Theorem32/Example33. Rendered evidence is under `tmp-splines/p5-05.png` through09,13,14. These are private working references, not redistribution outputs.

Thus A-U01/A-U02 are **closed as source-access/prerequisite-read gaps** for this chapter. They are not claimed closed as independent validation of its new written proofs. The manuscript supplies the whole local dual/Marsden argument and derivative proof before using smoothness and basis. This places derivative/smoothness in283.6 after the recurrence in283.5, rather than referring backward to an unproved basis claim. Main section labels and downstream contracts are unchanged.

P4 source windows remain the fixed B01 online5.2–5.3 snapshots. The manuscript derives its sharper local error and natural cubic results independently. It does not copy a not-a-knot order-four theorem into the natural endpoint setting. No R1–R4 unread book or Q1/Q2 link supports a claim. Citations are P4/P5, with exact subsection pointers in body and this record.

## Actual body coverage map

The entries below identify written material, not a reviewer pass. All the associated definitions, statements, proofs and necessary examples must still be independently read.

| B01 responsibilities | Written location / label | Actual content and limits |
| --- | --- | --- |
| 283-D01 | `ch283:spaces`, `ch283:dimension` | Strict breakpoints/cell width, degree/order, matching vector and right/left values; truncated-power span/independence/dimension proof. Includes no-matching r=-1 and redundant r=p cases. |
| 283-D02,T01,P01 | `ch283:hats`, `ch283:hat-stability` | Endpoint/interior hats; unique affine interpolation, nonnegative partition, convex bound and exact data sup gain1 proved. A nonuniform nodal perturbation example and modulus-of-continuity convergence follow. |
| 283-T02,P02,E01 | `ch283:linear-error-theorem`, `ch283:noisy-linear` | Full Rolle remainder and sharp1/8 bound on each nonuniform cell; x² signed residual and explicit mesh comparison; noise/error separation. |
| 283-D03,P03,T03,P04,E02 | `ch283:natural-cubic`, `ch283:cubic-piece`, `ch283:cubic-system`, `ch283:natural-existence` | Cubic formula derived via second derivatives, slopes/system, direct nonsingularity and reconstruction checks. n1 handled separately. Natural/clamped/not-a-knot distinguished; dimension explanation. Three-node exact cubic and four-node global data-dependence calculation. |
| additional cubic proof | `ch283:bending-energy`, `ch283:problem-natural-rate` | Full integration-by-parts variational property; explicit lower bound2h²/81 for natural interpolation of x² on uniform grids rules out false blanket O(h4). |
| 283-D04,D05,T04,P05,E03 | `ch283:bspline-recursion`, `ch283:bspline-support` | Finite open knot vector, multiplicities≤p+1, half-open degree0, zero-denominator term convention, left endpoint value at b; induction for support/nonnegativity/pieces. Explicit degree1 and uniform local quadratic. |
| 283-P06,T05,A-U01 | `ch283:marsden`, `ch283:bspline-derivative`, `ch283:bspline-smoothness` | Dual identity and full local Marsden proof; dual independence via rank of coefficient matrix; derivative comparison; multiplicity p central/support-boundary cases and lower multiplicity induction. Guarantee is “at least,” not exact smoothness. |
| 283-T06,P07,A-U02 | `ch283:bspline-basis-theorem`, `ch283:dimension` | Dimension/basis with interior full multiplicities allowed; local polynomial independence and every basis support contains a positive span. Truncated powers prove independent constraint count. |
| 283-T07,P08 | `ch283:partition-greville` | Partition and affine reproduction by coefficient comparison; p0 separately; open endpoint values and explicit failure of unchanged half-open rule at b. |
| 283-E03 | `ch283:bspline-recursion` examples and repeated-knot example in283.6 | Degree1 hats, p2 three-piece formula with matching checks, p2 repeated-knot space with dimension/truncated powers and C0-not-C1 member. Active-index calculation in solved exercise8. |
| 283-D06,T08,P09 | `ch283:local-operator`, `ch283:local-error` | Supported functional/input domain C[a,b], reproduction and independent uniform coefficient bound; local best-polynomial error and Taylor bound, global bound under explicit neighborhood diameter condition. Sup-norm selected theorem only; no unproved general Lq theorem. |
| 283-E04 | `ch283:greville-error`, `ch283:bernstein-spline` | Explicit Greville operator; affine reproduction, contraction/norm1, continuity even across full interior knots, C2 second-order error proof. Quadratic example gives exact nonreproduction1/8. |
| 283-CTX01 | natural rate paragraph and solved problem5 | Unproved not-a-knot order4 omitted. Natural rate obstruction is proved instead; no endpoint-condition transfer. |
| definition-use exercises | `ch283:problems` | Ten problems, each followed by a complete solution: space selection; unequal mesh/noise; mesh budget; clamped/natural comparison; rate obstruction; global dependence; explicit basis; supported coefficients/data; L2 evaluation failure; reproduction/boundedness hypotheses. |

The chapter uses 41 distinct labels. Author scan found no duplicate labels or undefined internal ref/eqref targets. All ten problem environments have a corresponding psolution. No unknown external chapter label is embedded; prose references to284–285 preserve the chronological reading path.

## Author checks and native R1 sample

Exact symbolic checks (SymPy) independently of the written algebra confirmed:

* Three-node natural spline values0,1/4,1 and C0/C1/C2 agreement at1/2; signed error `x(2x−1)^2/4` on the first half, maximum1/54 at1/6.
* Four-node perturbation second derivatives `(-2/5,8/5)ε`; first-cell change `ε(x−x³)/15` and valueε/40 at1/2.
* Cubic second-derivative finite-difference identity used in the natural-rate lower-bound proof.
* Structural scan: all declared theorem/proof/example/exercise environments balanced, references/labels internally resolvable, chapter source only (no preamble or counter resets).

Author sample build command:

`python work-v22/layout-prep/tools/build.py --chapter 283 --name ch283-author --back /workspace/scratch/29eb1e74068b/work-v22/tmp-splines/bibliography.tex`

This compiled the exact source snapshot twice to convergence under the pinned R1 template and current V22 adapter. The temporary back matter supplies P4/P5 bibliography entries only for the isolated chapter sample; it is not the eventual whole-volume bibliography. Sample is26 physical pages, of which1–25 contain Chapter283 and26 is the temporary bibliography. This measured size was not used to decide mathematical completion.

Engineering result: `ENGINEERING_PASS`; no hard, overfull, or header diagnostics; one underfull paragraph (source lines158–162). No missing labels/citations in the completed isolated sample. The underfull is a spacing diagnostic, not a semantic gap; no text was removed to silence it.

Visual author precheck: sequential contact sheets for every physical page1–26 were actually viewed; formula-heavy pages7,12,13,14,17,19 were additionally viewed as individual full-size renders. No visible clipped/invisible formula or page overflow was found. The local sample has appropriate theorem continuation on15 and19. This is author overview/selected enlargement evidence, **not B06 all-page independent visual acceptance**, and does not eliminate whole-volume page/reading checks after integration.

## Manifest and preservation

| Output | Role / identity |
| --- | --- |
| `chapters/ch283.tex` | Unique Chapter283 source, v1, author-created. Final bytes/hash are reported to parent after this handoff is saved. |
| `contributions/splines.md` | This versioned author handoff/coverage/source-read evidence. Parent records final fingerprint. |
| `layout-prep/tools/runs/ch283-author/inputs/00-ch283.tex` | Exact sample input snapshot, source SHA-256 `cebfda299813922b619bcd671fa7fbed619d740bccf5e0842845605141f37d76`. |
| `layout-prep/tools/runs/ch283-author/build/entry.pdf` | Paired author sample,154264 bytes, SHA-256 `183c67d3928f55eb9e2ebd805844a0cc514baed976f527a51b4e2c1f00fcf5ac`. |
| `layout-prep/tools/runs/ch283-author/build-report.json` | Snapshot/template/adapter hashes, build passes, diagnostics and pending semantic/visual status. |
| `tmp-splines/render/render-report.json` and page/contact renders | Author raster precheck evidence only. |

No shared template/preamble, source PDF, source table, tool ZIP, upstream manuscript, other chapter, or frozen artifact was edited. Sample runs snapshot the fixed template and adapter without changing them. The persistent stage package and remote receipt are parent responsibilities; this local note does not claim a Library upload or public release.

## OPEN, next action, and acceptance conditions

CLOSED SPL-1 for B04: full independent read and six-patch recheck reported by parent/thickening as recorded in v2 above. OPEN SPL-2: B05 must read the entire integrated path and confirm283→285 no-boundary affine interface. OPEN SPL-3: whole-volume source/PDF pairing, compilation, B06 all-page view and sole B07 strict final audit pending. Historic project UNKNOWNs remain unchanged. No hidden claim is made that source read, hash, build or25 pages proves mathematical completeness.

Next unique action: parent assigns B05 integrated reading-path review, retaining this source/hash and independent B04 receipts. Expansion participates when assigned. Any later fixes return as traceable patches to this same source. Preserve corrected calculations and proofs; do not re-download already fixed sources without a material need, restart frozen volumes, or use the isolated sample as the full-volume final PDF. All changed assumptions/definitions invalidate dependent earlier checks and require downstream recheck. No user decision currently required within this authorized scope.

Transmission state: shared files produced and direct collaboration readiness message will be sent with fingerprints. Actual parent read-in, independent review receipt and mathematical approval are separate and not fabricated here.
