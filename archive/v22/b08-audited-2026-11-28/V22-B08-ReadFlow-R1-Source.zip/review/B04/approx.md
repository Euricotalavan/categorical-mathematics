# V22 Chapters 282 and 284: authoring contribution and responsibility

## Receipt and authority

B04-APPROX-20261128 v1. Controller explicitly released B-04 after fixed B-02 and passed revised B-03. Read `b02/design.md`, `handoff/authoring.md`, `handoff/BUILD-INSTRUCTIONS.md`, the author's fixed B-01 `approx.md` and B-02 `approx-checks.md`. This task owns only `chapters/ch282.tex`, `chapters/ch284.tex`, and this contribution record. No claim is made that the author is the independent thickener, independent refiner or B-07 final auditor. Actual requested model/High settings remain independently UNVERIFIED.

Scheme B single Work; global range282–290 inherited, local ownership282 and284. Prior frozen volumes, tables, tools, sources and adopted R1 template remain KEEP. The controller's fixed B-03 calibration controls exposition depth; no forced page breaks, enlarged typography or duplicated prose are added to satisfy a page target.

## Chapter 282: submitted for independent B-04 reading

Unique source `chapters/ch282.tex`. Source SHA-256 at first chapter-ready submission: `af49a376c081ac266d6d96ea418183d979e85dc57e8878a6eb93fabffe0d202e`; 40338 bytes, rechecked after the Chapter→Section wording correction. 5237 whitespace-delimited words including math tokens at initial static check; this is descriptive, not an adequacy test.

| Body location / exact label | Source responsibilities and actual implementation | Source locator / change of scope |
|---|---|---|
| `ch282:models` | 282-D01–02: real C[a,b], whole-interval sup norm, degree≤n, zero-degree convention, data constraints vs function error, finite residual counterexample, affine scaling. | P1 Ch2 (2.3); P2 §6.1.0.1. Added fully calculated x³−x residual and spike norm distinction. |
| `ch282:interpolation`, `ch282:lagrange` | 282-T01/P01/E01: cardinal products, existence/uniqueness root proof, linearity, partition of unity, x³ at−1,0,1. | P1 pp8–9 and33–35. |
| `ch282:remainder` | Fixed B02 added duty: full Rolle iteration for C^(n+1) remainder including nonnode/node split and exact derivative order; e^x example. | P2 §6.2.2 is supporting context; proof supplied self-contained here rather than claimed copied/read in B01. |
| `ch282:lebesgue-gain` | Exact fixed-node data gain, proof of sharpness, any-polynomial comparison inequality; exact Λ₂=5/4 example. | Derived directly from Lagrange cardinality, no unread ATAP Ch15 theorem imported. This is not a minimax-existence claim. |
| `ch282:chebyshev`, `ch282:chebyshev-properties` | 282-D03–04/T02/P02/E02: recurrence, degree, roots, global alternating extrema, grids and exact T₂,T₃,T₄. | P1 pp14–15; P2 Def6.2.3.3. Root vs Lobatto conventions separated explicitly. |
| `ch282:monic-chebyshev` | Fixed B02 duty: sharp monic norm lower bound by strict root/sign count, root-node remainder factor, affine scaling. | P2 §6.2.3 motivation; complete elementary proof supplied. No best-target interpolation claim. |
| `ch282:barycentric`, `ch282:barycentric-formula` | 282-D05/T03/P03/E03: product derivation, denominator identity, ratio formula, separate node values, common weight scaling; exact3-node arithmetic; actual bad-weight pole. | P1 Ch5 (5.1)–(5.12), pp33–36. |
| `ch282:bernstein`, `ch282:bernstein-moments` | 282-D06: positivity, mass, first/second moments with every binomial shift and n1 edge case. | P2 §6.2.1 (6.2.1.3)–(6.2.1.6); independent expansion repairs terse algebra. |
| `ch282:weierstrass` | 282-T04/P04: weighted near/far proof, epsilon/delta order, uniformity and affine transfer. | P1 Thm6.1 statement, P2 Thm6.2.1.2 first part. Does not use the incomplete Gaussian outline as a complete proof. |
| `ch282:bernstein` examples | 282-E04: x² exact error1/(4n), nonsmooth abs example, Lipschitz weighted Cauchy–Schwarz bound. | Derived moments; B1/B2 abs values checked. |
| `ch282:rational-type`, `ch282:rational-equality`, `ch282:defect` | 282-D07–08/P05/E05: allowed/reduced exact type, coprimality and scalar ambiguity, cross equality, positive normalized denominator, zero convention, cancellation/poles, defect examples. | P1c opening and(24.1); P3§1 corrected; P13§1 corroboration. P3 printed typo is acknowledged in body. |
| `ch282:rational-difference` | Difference cross-numerator degree≤m+n−d, with p0 case separate; exported to284. | P1c opening zero-count paragraph. Does not claim minimax before284. |
| `ch282:choice` | Explicit rational-target polynomial geometric construction with exact interval error; data/model error split; denominator-margin perturbation inequality; bounded quotient sensitivity counterexample; I13 conceptual bridge. | Self-contained finite geometric sum and algebra; no external regularization/statistical-risk theorem claimed. |
| `ch282:problems` | Nine complete solutions: repeated nodes vs derivative constraints, quartic error/remainder, spike norms, scaled monic choice, bad weights, third Bernstein moment, cancellation/defect, tolerance design, noisy-data budget. | Calculations are new elementary examples. No numerical solver/plot supplies a proof. |

### Author checks and limitations at first submission

All eight mandatory section labels occur exactly once. All labels have `ch282:` prefix; no control characters; theorem/proof/problem/solution/example begin/end counts balance. Nine problems each have a full solution. Exact example identities were checked by algebra; the B02 rational minimax example is reserved for284.6. Cross-chapter targets `ch283:chapter`, `ch284:chapter`, `ch284:projection`, and `ch284:rational-alternation` are prospective interface labels whose resolution requires the integrated body. A single-chapter build has been requested with diagnostics allowed; its result is recorded below when available. No full-volume compilation, all-page visual QA or independent mathematics pass is claimed here.

Author engineering build: `python work-v22/layout-prep/tools/build.py --chapter 282 --name b04-ch282-author --back /workspace/scratch/29eb1e74068b/work-v22/bibliography.tex --allow-diagnostics` completed two passes. PDF `layout-prep/tools/runs/b04-ch282-author/build/entry.pdf` SHA-256 `f7c48d306124dd604fc4898b5283c19e69ff6dbcb8918e08616ead4669da6d0f`. No overfull/header diagnostics. Four external chapter/section references remain undefined because their chapters are absent from this isolated build; two underfull lines reported. No visual inspection or mathematics pass is claimed by this build. The exact source snapshot in its manifest matches the submitted hash.

OPEN author-282-1: independent thickening/refinement must actually read this fixed source, including every proof/example and downstream interfaces. OPEN author-282-2: integrated reference/citation resolution and formal layout inspection belong to the controller and later B stages. Neither blocks the next authorized authoring of284.

## Chapter 284: submitted for independent B-04 reading

Unique source `chapters/ch284.tex`, first author-checked version 46223 bytes, SHA-256 `2ca1247e82dc10265f0758bf84503bbee6820c89e88158017eb9c78bc5aa6a74`. Seven fixed section labels each occur once. Static checks: 14 proof environments, ten problems with ten full solutions, nine worked examples, balanced begin/end environments, no control characters. The author corrected an imprecise infimum sentence before fixing this version: individual candidate error bounds the infimum, not the entire set of possible errors. No independent review is claimed by these checks.

| Body location / exact label | Source responsibilities and actual implementation | Exact supporting locator / independent expansion |
|---|---|---|
| `ch284:best-existence`, `ch284:finite-compactness`, `ch284:finite-existence` | 284-D01/T01/P01: infimum vs minimizer, finite-dimensional compactness via Euclidean coordinate bounds, minimizing sequence and attainment; exact nonuniqueness counterexample; distance Lipschitz. | P1b chap10.m existence paragraph. General finite-subspace lemma supplied self-contained, no assertion of arbitrary closed-set attainment. |
| `ch284:sign-blocks` | 284-P03: compact disjoint positive/negative extrema, positive separation, finite greedy sign blocks, gap roots, polynomial sign direction. | P1b necessity paragraph, fully expanded. |
| `ch284:uniform-improvement` | Full two-region uniform improvement with denominator bounds independent of t. Used once for polynomials and reused for rational exact difference. | Elementary compactness expansion of P1b/P1c terse perturbation passages. Every neighborhood/margin and zero crossing restriction is stated. |
| `ch284:alternation`, `ch284:polynomial-alternation` | 284-D02/T02/P02–04: real polynomial alternation, strict root sufficiency, sign-block necessity, midpoint uniqueness, zero error separately, n0, x² uniform optimum1/2. | P1b Thm10.1 full proof, P2 Thm6.4.0.2 statement. Does not extend to an arbitrary finite subspace. |
| `ch284:certificates`, `ch284:lower-certificate` | 284-T03: de la Vallée Poussin-style alternating lower certificate, feasible whole-interval upper bound. | Strict difference-root argument; complete proof supplied rather than relying on a named theorem. |
| `ch284:remez-system` | 284-D03/P05/E02: fixed-node Remez nonsingularity proof, distinction between grid evidence and global bound; x³ exact affine certificate3x/4 with T3/4 error; initial grid exact fit is insufficient; constant x² certificate; missed-grid polynomial. | P2 §6.4.0.3 (6.4.0.4)–(6.4.0.6). No implementation-convergence claim. |
| `ch284:projection`, `ch284:projection-theorem` | 284-D04/T04/P06: genuine real inner product, orthogonality, Gram positivity, normal equations iff orthogonal residual iff unique minimizer, Pythagorean identity, linearity, projection contraction and perturbation contraction. | P2 Defs6.3.1.1–2, Ass6.3.1.6, Thm6.3.1.7, Cor6.3.1.12, pp513–516. Includes explicit V0 case. Export for285/290. |
| `ch284:orthonormal-projection` | 284-D05: orthonormal coordinate formula and squared best error. | P2 Def6.3.1.14 and(6.3.1.16); proof from Gram identity. |
| `ch284:projection` examples | 284-E03–04: exact L² projection x²→1/3, error²8/45, comparison uniform1/2 and7/30, sampled rank/positive weights, degenerate single sample. | Hand calculations; SymPy independently rechecked7/30 and sampled Gram coefficients. Does not evaluate general L² classes at points. |
| `ch284:removable-ratio` | 284-P07: bounded ratio implies full numerator root multiplicity at all interval denominator zeros, including one-sided endpoints; cancellation/continuous bound. | P1c chap24.m existence proof, necessary full multiplicity expansion. |
| `ch284:rational-existence`, `ch284:rational-existence-theorem` | 284-T05/P07: positive normalized q, bounded p, pair subsequence, nonzero q limit, inequality off zeros, removal and extension. Example x/(x+1/k) distinguishes coefficient limits from pointwise value at limit zero. | P1c existence lines270–290, P3 intro existence assertion. No compactness shortcut for nonlinear quotient family. |
| `ch284:rational-directions` | 284-P09 prerequisite: qu−pv onto P_(m+n−d), exact kernel(ph,qh), dimension proof, p0 case separately. | P1c lines306–352. No untyped perturbations, denominator positivity preserved. |
| `ch284:weak-sign` | 284-P10: Lagrange leading-coefficient/divided-difference identity, exact denominator signs and nonnegative summands. | Self-contained alternative to P1b multiplicity proof, authorized/fixed B02. Avoids shared endpoint root double counting. |
| `ch284:rational-alternation`, `ch284:rational-alternation-theorem` | 284-T06/P08–10: strict sufficiency, sign direction and exact t w/[q(q+t v)] necessity, positive uniform denominator bounds, weak-sign uniqueness, zero numerator/error, defect-correct count. | P1c Thm24.1 and four proof parts. P3(1.3) with corrected defect; P13 corroboration used in282. |
| `ch284:rational-alternation` examples | 284-E05: fully computed best type(0,1) quotient c/(1−d0t) for t with c=(√2−1)/2, derivative/global error/three extrema; substitute t=x² for five extrema and allowed-type defect table; bestzero for odd x inR_(0,n). | B02 exact new certificates; algebra and stationary identity checked in B02. Denominator coefficient deliberately named d0, distinct from defectd. |
| `ch284:problems` | Ten full solutions: subspace uniqueness counterexample, x4 polynomial certificate, cubic L² comparison, sampled Gram, incomplete Remez certificate, rational tangent, bestzero changed family, weak signs vs shared roots, cancellation order, noisy projection. | New exact examples; no unsupported solver result. SymPy rechecked cubic8/175 and sampled Gram(-1/8,1). |

An isolated R1 build was requested for284 with bibliography and diagnostics allowed, name `b04-ch284-author`. Result to be appended once complete. Formal all-volume reference resolution, all-page visual inspection, B05 integration and B07 final audit remain later duties. Source evidence supplied here is author evidence, not independent acceptance.

OPEN author-284-1: independent full fixed-version thickening/refinement, particularly finite extremal sign-block construction, uniform margin, root multiplicities, zero tangent map case, weak-sign identity and exact rational examples. OPEN author-284-2: integrated chapter/section reference resolution and formal layout inspection. No unresolved mathematical shortcut is knowingly left in the author manuscript; this is not a guarantee that review will find none.

## Controller-directed review patches and current source versions

The independent thickening task messaged that its full source reads of282 and284 passed the primary constructions/proofs and all exercises, then routed bounded scope/typing clarifications to the controller. Controller requested the following repairs and an additional substantive equally-spaced-grid result. This author applies the requested repairs; the resulting versions still require the reviewers' actual patch read-in. No earlier review is silently promoted to the new text.

| Issue / location | Earlier state | Applied text / direct and downstream effect |
|---|---|---|
| 282 barycentric proof `ch282:barycentric-formula` | Vague wording “multiply the Lagrange sum” | Explicitly substitute each cardinal representation, then replace omega by reciprocal denominator sum. Formula unchanged. |
| 282 Bernstein definition `ch282:bernstein` | n/j integer convention and function domain implicit | Explicit n≥1 integer, j integer, f∈C[0,1]. No formula/hypothesis weakened. |
| 282 rational definition `ch282:rational-type` | m,n integer implicit | State integers explicitly. |
| 282 quotient perturbation `ch282:choice` | Perturbation functions not typed although admissible quotient asserted | Initial p∈P_m,q∈P_n and u∈P_m,v∈P_n now explicit. Bound proves perturbation stays in the same allowed rational family. |
| 282 extension `ch282:equispaced-amplification` | Only exact n2 gain example | Added elementary exponential lower bound Λ_n≥2^n/[2n(n+1)^2], proof at t1/2 on nodes0…n, product bound, binomial maximum bound, affine-invariant scaling, and explicit data signs attaining that row sum. Added solved n20/n32 comparison at sample error10^-6, carefully separating upper/lower and worst-case/all-data statements. Self-contained new derivation, not a falsely attributed theorem from an unread source. Parent supplied proof strategy; author checked each inequality and exact fractions. No downstream theorem contract changes. |
| 284 rational linearity opening `ch284:rational-existence` | Overbroad “not a linear subspace” could include n0 | State R_(m,0)=P_m; for n≥1 generally nonlinear because denominators can grow under addition. Rational existence proof still includes n0. |
| 284 projection theorem `ch284:projection-theorem` | q's arbitrary/solved role could be read ambiguously | q explicitly arbitrary for equivalent conditions; Pythagorean identity explicitly conditional on those conditions. Projection export to285/290 mathematically unchanged. |
| 284 degenerate Gram example `ch284:projection` | Single sample weight implicit | State weight one, matching displayed matrix. |
| External ch285:chapter reference | Target label missing in another author source at review time | Controller assigned its creation to the Chapter285 owner. No cross-owner file edited here. |

Current unique source versions after these patches:

| Source | Bytes | SHA-256 |
|---|---:|---|
| `chapters/ch282.tex` | 44705 | `d9b0ec8b2464caf454983ec9afd0431730919fd45cfb2a6df1878c1d40221bf3` |
| `chapters/ch284.tex` | 46449 | `9ad7973dfbb4ca2b84cc4160d187246553c6d70521625f05a1f303672cb4ca82` |

Final author static check: zero duplicate labels in each file, all mandatory section labels retained, no control characters, balanced proof environments (282:11,284:14), no external source or template modifications. Exact check of the extension's arithmetic gives n20 bound131072/2205≈59.4430839 and n32 bound67108864/1089≈61624.3011938; the printed decimal lower comparisons are rounded down. Complete solutions remain nine in282 and ten in284; the new solved comparison is a worked example and does not duplicate those problems.

Final isolated engineering rebuilds requested under names `b04-ch282-author-v2` and `b04-ch284-author-v2`, with the full bibliography; results appended when available. The earlier284 author build completed two passes, no overfull/header/underfull diagnostics, expected external-label warnings only; its PDF SHA-256 was `d5cd6b42c10238fb07085f54b070790252495d8c1a88a2e171e5a6378fc4908c`. That earlier PDF matches the earlier2ca1247e source, not the current source. Do not pair it with current9ad7973d source for final audit.

### Final author engineering receipt

Both v2 isolated builds completed two passes. Neither has overfull or header diagnostics;284 also has no underfull diagnostics. Chapter282 has the same two underfull paragraph lines as its initial build. Undefined references are exclusively to the other chapters excluded from the isolated builds, so integrated resolution still must be checked rather than marked passed. Neither build performed visual QA or mathematics review.

| Paired source snapshot | Paired PDF under `layout-prep/tools/runs/` | PDF SHA-256 |
|---|---|---|
| 282 SHA-256 `a97ead2e82f6ad4d90bd3f6ef9619e9bc2e49da342b6ee784d2ec5f00cd72d3c`,44705bytes | `b04-ch282-author-v2/build/entry.pdf` | `d72178b391a1e37a8245f53d933092595d95e5f5b9c3a4c4e8f8db9f9efb4c72` |
| 284 SHA-256 `9ad7973dfbb4ca2b84cc4160d187246553c6d70521625f05a1f303672cb4ca82`,46449bytes | `b04-ch284-author-v2/build/entry.pdf` | `ba83788a3181a8ea01183d80363d4792b93c70e1c4750bd0107c47106d86ea66` |

The282 hash changed between the author notification of d9b0ec8b and the build's source snapshot, without an additional edit by this role. Current source and the a97ead2e build snapshot were byte-compared and are identical. Controller was notified immediately to retain central-change provenance and route the actual fixed version for patch recheck. The current hash supersedes d9b0ec8b for pairing; the earlier value is retained above as the actual author submission history. This record does not silently claim who made a concurrent same-size change.

Final local handoff: both assigned chapters are proof-complete author submissions with source responsibilities mapped, requested review scope repairs applied, and the additional282 theorem submitted for independent recheck. Next unique action is controller-directed independent patch read/review and B05 integration, not further unscheduled author expansion. Existing independent full reviews of earlier hashes remain evidence only for unchanged content. B06 visual layout, B07 whole-volume sole final audit, and B08 archive authorization/pass are not replaced by this contribution or its build logs. No user decision pending; original chapter numbering, upstream frozen work, official tables, source copies and R1 baseline remain KEEP.

## Handoff fields

Sender author→controller→independent B04 thickening/refinement. Local stage:282 author manuscript submitted;284 authoring next. Model/mode unverified. Source/PDF pairing is pending the author build result; formal R1 layout pass not yet performed. No local template patch. Approval for ordinary drafting and safe fixes is already supplied; no new user decision is requested. Frozen upstream work, already fixed source evidence and chapter numbering must not be restarted. Production of this record is not independent review, delivery of a remote archive, B05 integration, or B07 final sign-off. Controller receives the local file through the shared workspace and must acknowledge actual fixed-version read-in before marking any gate passed.
