# Chapter 287 · B-04 independent mathematical review

Actual read covered all 751 lines of `chapters/ch287.tex` (31,913 bytes, SHA-256 `ba556416824b3da0bf3178e152f217c5244ffdba9356f4dedd4f3fde12f89bed`). Compared B02 sampling/proof contracts and P7 §5.7, P8 §6.20 and P9 projection discussion. Independent thickening; actual reasoning setting unverified.

| Body location | Independent result |
| --- | --- |
| Critical sinc basis and cardinal reconstruction | Transform factor √T, coefficient √T f(kT), norm-one ONB, completeness, raw sample energy T, global uniform convergence on common band, and the scalar absolute convergence via the evaluation kernel all check. Off-grid value 20/(3π) checks. |
| Projection and full/small bands | Orthogonal multiplier, L² kernel pairing rather than assumed integrable sinc, projected coefficient factor r and frame normalization are correct. Q is built via unitary operator composition before infinite-matrix operations. Row norm, absolute convergence, range and r=1 identity all verified. |
| Window, noise, displacement | Exact unprojected squared decomposition, projected bounds, declared sample-tail certificate and local truncation factor check. Bounded displacement segments have disjoint interiors under the stated uniform bound δ<T/2, so the integrated derivative estimate really gives square-summability. Common-shift multiplier and topology are valid. |
| Model error | Orthogonal splitting holds when the data-error output stays in the band, and the chapter correctly uses a triangle bound for the alternative. Distinguishes arbitrary L² model error from raw point values. One edge assumption needed for its counterexample. |
| Nine solved problems | Scaling, projected impulse, rigorous row, finite-window exact error √(401/50), interior estimate, half-band gain, bounded amplitude vs energy, common shift, and orthogonal budget √41/2 all check. |

| Finding | Scope and impact | Repair |
| --- | --- | --- |
| **287-M1** | Lines 584–586 choose a nonzero Nyquist-band function supported outside the declared band, while the chapter allows B=C. | Explicitly assume B<C for this counterexample. At B=C there is no such nonzero spectrum. |
| 287-M2 | Lines 175–177 can be read as saying feeding √T c into raw R_T makes it a unitary operator. | State that using normalized coefficients a=√T c gives R_Tc=U_T* a, where U_T* is unitary. |
| 287-M3 | Lines 545–566 use a hat for reconstructed u_W while hats denote Fourier transforms nearby. | Use a visually distinct reconstruction symbol, such as ũ_W, consistently if prose is revised. |

**Disposition.** Mathematical core and all worked calculations pass, with the missing strict band comparison routed for local correction. The operative `ch287:sample-energy`, `ch287:band-projection`, and `ch287:sequence-projection` labels carry the expected formulas for Ch288 and Ch290. No chapter was edited by this reviewer. Assembly and B07 remain separate.

**Patch recheck.** Compared the complete diff to the matching polished author snapshot. SHA-256 `bf244d09862681177ae8c017dbeafb03338c72159b32e52966a3208118883a65` explicitly requires B<C in the counterexample, states R_Tc=U_T* a for a=√T c, and consistently uses a tilde for reconstruction. M1–M3 closed. Mathematical pass for the fixed chapter.

**Expansion recheck.** Read the complete transition-window contribution and compared the merged section in SHA-256 `a1c5be1a9d7bba8deb7848bc283cb12680c326dbfe62c228233df40d0c237bc8` to it. Only math-formatting in the heading differs. The plateau and shoulders follow from interval convolution; Fubini gives the product inverse with correct width factors. The synthesis gain √T is exact on any nonzero target-band signal. Cauchy–Schwarz and the fourth-power integral give tail factor √(2/3)/(π²dT(N−a)^(3/2)); its comparison to raw synthesis uses the same data/region. Numerical coefficients 0.012256059 and 0.150052719 verified. All three added solutions check, including the limiting kernel and the strict-band requirement. Mathematical pass for the expanded version.
