# Chapter 286 · B-04 independent mathematical review

Actual read all 587 lines of `chapters/ch286.tex`, 25,795 bytes, SHA-256 `4b945a84a1cb5cc89ad939271b8b7e1ebaff6277dba995abb7c1f1bd46975f1b`. Compared B-02 sampling and fixed source contracts. Related actual-read windows are P7 §§5.5–5.9, P8 §6.20 and P9 Appendix A. Independent thickening with reasoning setting unverified.

| Body responsibility | Independent result |
| --- | --- |
| 286.1 canonical PW_B | Closed spectral subspace, L²-to-L¹ on compact support, inversion and uniqueness of continuous representatives check. Evaluation factor √(2B) and derivative factor from the 2m-power frequency integral are exact stated bounds. |
| 286.2 units and sinc | Proper B,T,r and Nyquist edge, normalized inverse indicator, P8 engineering scaling, and numerical conversions check. |
| 286.3 comb | Schwartz distribution is well-defined, and periodization coefficients retain 1/T and exact sign. Tested distributional transform by the composition rule double-transform ψ(−x) and by the convolution change of variables for the weighted comb. Only Schwartz inputs are asserted here. |
| 286.4–5 alias and Nyquist | Periodic example kept outside real-line L². Two disjoint spectral packets produce nonzero real null signal of squared norm δ. Complete normalized exponentials give coefficients √T f(nT). The equality case depends on the a.e. spectrum and full lattice, and the endpoint tone does not refute it. |
| 286.6–7 model and practice | Filtering before evaluating, projection energy, distinction from finite-dimensional periodic model, finite evaluation null vector, and all eight number/model solutions check. |

**286-M1.** At lines 129–132, “an infinite sequence of individually small displacement errors need not have finite ℓ² energy” is best restricted to what that estimate alone proves. If read as the actual value differences induced by uniformly bounded jitter on one common PW_B function, the wording is misleading: f'∈L² and the bounded-length local integration intervals have uniformly bounded overlap, so those differences are square summable. Use the precise formulation already given in the exercise at lines 549–553. At line 159, say multiplying cycles-per-time by 2π gives radians-per-time. In assembly, Ch288 should refer to `ch286:representative` as a theorem rather than a proposition.

**Disposition.** Mathematical core and examples pass. The jitter wording and units clarifications have been routed. No manuscript edits by reviewer; verification of exact downstream labels and final typesetting occurs separately.

**Expansion recheck.** Compared the complete source diff against the initial audited author snapshot. Fixed SHA-256 `60ada66f62fff1de28614001d4565f966f1d7da653dd17003d2a8dde010cd299` closes the jitter and conversion cautions. The exact compact-spectrum folding uses finite active sheets, sharp essential multiplying count ceil(2BT), and the correct √T coefficients and T factor in Fourier resynthesis. The support-range characterization and minimum-energy construction are fiberwise orthogonal. Both numerical signals and all three added exercises check, including the integer overlap and forbidden-fiber distinction. Minor clarity only: the vanishing cross term is twice the real part, and the support exercise should name the rest of the whole fundamental interval. Mathematical core passes for the expanded source.

**Integrated recheck.** SHA-256 `08fbe90754eb0c9d8dc4e337ff2f95cd9e7c80b5968980c96ea069fe378bfcd8` makes the exact cross-term factor and the forbidden region within J_T explicit. No change to mathematical conclusions. Pass.
