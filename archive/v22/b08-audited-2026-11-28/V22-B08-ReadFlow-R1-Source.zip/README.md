# Categorical Mathematics · Volume 22

**Approximation, Sampling, and Reconstruction**  
ReadFlow R1 · Chapters 282–290 · 2026-11-28

The volume starts with polynomial, rational, and spline approximation.
It develops best-error spaces and then studies the relation between
bandwidth, measurements, reconstruction, and numerical stability.
The final three cases compare periodic fitting, incomplete sampling,
and sparse recovery under explicit data and error models.

## Files

- `V22-B08-ReadFlow-R1.pdf` is the paired reading edition.
- `chapters/`, `frontmatter.tex`, and `bibliography.tex` are the editable body.
- `layout-prep/` contains the fixed ReadFlow R1 files, licensed fonts,
  V22 adapter, figure source and build script.
- `review/` contains the source responsibility, audit, and repair records.
- `SHA256SUMS` records the contents of this source package.

## Verify and rebuild

Use Python 3.10 or newer and XeLaTeX with fontconfig. From this extracted
directory, run:

```sh
python3 verify.py
python3 layout-prep/tools/build.py --full \
  --front "$(pwd)/frontmatter.tex" \
  --back "$(pwd)/bibliography.tex" \
  --name rebuild
```

The rebuild is reported under `layout-prep/tools/runs/rebuild/`.
Reference locations and source versions live in `review/B01/`.
Author-hosted texts and articles are linked from the bibliography.
