import Ch158

namespace V12.Project

-- Literal tests inspect the ORIGINAL children, before recursion.
def fold {t : Ty} (e : Expr t) : Expr t :=
  match e with
  | .nat n => .nat n
  | .bool b => .bool b
  | .add a b =>
    match a, b with
    | .nat n, .nat m => .nat (n + m)
    | _, _ => .add (fold a) (fold b)
  | .lt a b =>
    match a, b with
    | .nat n, .nat m => .bool (decide (n < m))
    | _, _ => .lt (fold a) (fold b)
  | .ite c a b =>
    match c with
    | .bool true => fold a
    | .bool false => fold b
    | _ => .ite (fold c) (fold a) (fold b)
termination_by structural e

theorem fold_preserves {t : Ty} (e : Expr t) :
    eval (fold e) = eval e := by
  induction e with
  | nat n => rfl
  | bool b => rfl
  | add a b iha ihb =>
    cases a <;> cases b <;> simp_all only [fold, eval] <;> rfl
  | lt a b iha ihb =>
    cases a <;> cases b <;> simp_all only [fold, eval] <;> rfl
  | ite c a b ihc iha ihb =>
    cases c with
    | bool v => cases v <;> simp_all only [fold, eval, Bool.false_eq_true, ↓reduceIte]
    | lt x y =>
      change (if eval (fold (.lt x y)) then eval (fold a) else eval (fold b)) =
        (if eval (.lt x y) then eval a else eval b)
      rw [ihc, iha, ihb]
    | ite d x y =>
      change (if eval (fold (.ite d x y)) then eval (fold a) else eval (fold b)) =
        (if eval (.ite d x y) then eval a else eval b)
      rw [ihc, iha, ihb]

def nested : Expr .nat := .add (.add (.nat 1) (.nat 2)) (.nat 3)

theorem one_pass_shape :
    fold nested = Expr.add (.nat 3) (.nat 3) := rfl

theorem second_pass_shape : fold (fold nested) = Expr.nat 6 := rfl

theorem not_idempotent : fold (fold nested) ≠ fold nested := by
  intro h
  cases h

theorem literal_guard_shape :
    fold (.ite (.bool true) (.add (.nat 1) (.nat 2)) (.nat 8)) =
      Expr.nat 3 := rfl

theorem computed_guard_shape :
    fold (.ite (.lt (.nat 1) (.nat 2)) (.nat 7) (.nat 9)) =
      Expr.ite (.bool true) (.nat 7) (.nat 9) := rfl

theorem nested_value : eval (fold nested) = 6 := rfl

#print axioms fold
#print axioms fold_preserves
#print axioms one_pass_shape
#print axioms second_pass_shape
#print axioms not_idempotent
#print axioms literal_guard_shape
#print axioms computed_guard_shape
#print axioms nested_value

end V12.Project
