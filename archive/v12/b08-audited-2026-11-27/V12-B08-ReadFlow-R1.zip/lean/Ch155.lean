namespace V12.Ch155

-- 155.1a-b: propositions, proofs, and implication rules.
theorem keepProof (p : Prop) (hp : p) : p := hp

theorem implicationIntro (p q : Prop) (body : p -> q) : p -> q :=
  fun hp : p => body hp

theorem implicationElim (p q : Prop) (hpq : p -> q) (hp : p) : q :=
  hpq hp

-- 155.2a: each binder has its own scope.
theorem keepFirst (p q : Prop) : p -> q -> p :=
  fun hp : p => fun _hq : q => hp

-- 155.2b: composition, in the order in which evidence is available.
theorem compose (p q r : Prop) (hpq : p -> q) (hqr : q -> r) :
    p -> r :=
  fun hp : p => hqr (hpq hp)

example (p q : Prop) (hp : p) (hpq : p -> q) : q := by
  fail_if_success exact hp hpq
  exact hpq hp

-- 155.3a: introduction and elimination of the connectives.
theorem makeAnd (p q : Prop) (hp : p) (hq : q) : And p q :=
  And.intro hp hq

theorem useOr (p q r : Prop) (h : Or p q)
    (left : p -> r) (right : q -> r) : r :=
  Or.elim h left right

theorem absurd (p : Prop) (h : False) : p := False.elim h

theorem contradiction (p : Prop) (hnp : Not p) (hp : p) : False :=
  hnp hp

-- 155.3b: projection followed by introduction.
theorem swapAnd (p q : Prop) (h : And p q) : And q p :=
  And.intro h.right h.left

example (p q : Prop) (h : And p q) : And q p := by
  fail_if_success exact h
  exact And.intro h.right h.left

-- 155.3c: this uses Lean's definitional proof irrelevance.
example (p : Prop) (h k : p) : h = k := rfl

-- Exercises, with complete solutions.
theorem swapOr (p q : Prop) (h : Or p q) : Or q p :=
  Or.elim h (fun hp => Or.inr hp) (fun hq => Or.inl hq)

theorem notSelf (p : Prop) : Not (And p (Not p)) :=
  fun h => h.right h.left

end V12.Ch155
