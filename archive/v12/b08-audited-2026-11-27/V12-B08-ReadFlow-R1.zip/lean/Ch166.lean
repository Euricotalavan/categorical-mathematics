import Ch165

namespace V12.Project

-- The integration theorem uses the universal theorem, not evaluation tests.
theorem project_correct {t : Ty} (e : Expr t) :
    eval (fold e) = eval e := fold_preserves e

theorem project_sample : eval (fold sample) = 7 :=
  (project_correct sample).trans sample_value

#check @project_correct
#check @project_sample
#print axioms project_correct
#print axioms project_sample

end V12.Project
