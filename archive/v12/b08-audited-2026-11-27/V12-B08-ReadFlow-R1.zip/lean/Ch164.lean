import Ch163

namespace V12.Ch164
universe u

theorem twice_reused {α : Sort u} (f : α → α) (x : α) (h : f x = x) :
    f (f x) = x :=
  V12.Ch163.twice_fixed f x h

theorem twice_term {α : Sort u} (f : α → α) (x : α) (h : f x = x) :
    f (f x) = x :=
  Eq.trans (congrArg f h) h

theorem twice_rw {α : Sort u} (f : α → α) (x : α) (h : f x = x) :
    f (f x) = x := by
  rw [h, h]

theorem twice_simp {α : Sort u} (f : α → α) (x : α) (h : f x = x) :
    f (f x) = x := by
  simp only [h]

theorem rewrite_back {α : Sort u} (f : α → α) (x : α) (h : f x = x) :
    x = f x := by
  rw [h]

theorem five : 2 + 3 = (5 : Nat) := by decide
example : Decidable (2 + 3 = (5 : Nat)) := inferInstance
theorem five_reduced : 2 + 3 = (5 : Nat) := rfl

theorem constructor_with_input (p : Prop) (hp : p) : p ∧ True := by
  constructor
  · exact hp
  · exact True.intro

theorem no_universal_input : ¬ (∀ p : Prop, p ∧ True) := by
  intro h
  exact (h False).left

theorem reverse_rw {α : Sort u} (f : α → α) (x : α) (h : f x = x) :
    x = f x := by
  exact Eq.symm h

#print axioms twice_term
#print axioms twice_reused
#print axioms twice_rw
#print axioms twice_simp
#print axioms five
#print axioms no_universal_input
end V12.Ch164
