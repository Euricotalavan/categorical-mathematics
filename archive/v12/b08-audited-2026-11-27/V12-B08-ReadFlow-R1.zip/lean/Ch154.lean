namespace V12.Ch154

set_option autoImplicit false

abbrev Counter := Nat

section
  variable (n : Nat)

  #check n
  #check (n : Counter)
end

/-- error: Unknown identifier `n` -/
#guard_msgs in
#check n

example (n : Nat) : (n : Counter) = n := rfl

universe u

#check Prop
#check Type
#check Type u

def keepInType1 (A : Type 1) : Type 1 := A

def liftedNat : Type 1 := ULift.{1, 0} Nat

#check keepInType1 liftedNat

example : Type 1 := by
  fail_if_success exact keepInType1 Nat
  exact keepInType1 liftedNat

#check (2 + 3 : Nat)
#eval (2 + 3 : Nat)

end V12.Ch154
