namespace V12.Ch156
universe u v w

-- 156.1a-b: ordinary functions and conversion.
def identity (A : Type u) : A -> A := fun x => x

def compose {A : Type u} {B : Type v} {C : Type w}
    (g : B -> C) (f : A -> B) : A -> C :=
  fun x => g (f x)

example {A : Type u} (a : A) : identity A a = a := rfl

example {A : Type u} (y : A) :
    (fun x : A => fun _y : A => x) y = (fun _z : A => y) := rfl

example {A : Type u} {B : Type v} (f : A -> B) :
    (fun x => f x) = f := rfl

-- 156.2a-b: pairs, their projections, and swap.
def swap {A : Type u} {B : Type v} (z : Prod A B) : Prod B A :=
  (z.2, z.1)

example {A : Type u} {B : Type v} (a : A) (b : B) :
    (Prod.mk a b).1 = a := rfl

example {A : Type u} {B : Type v} (a : A) (b : B) :
    (Prod.mk a b).2 = b := rfl

example {A : Type u} {B : Type v} (z : Prod A B) :
    swap (swap z) = z := rfl

example (z : Prod Nat Bool) : Prod Bool Nat := by
  fail_if_success exact z
  exact swap z

-- 156.3a-b: elimination of a tagged sum into a fixed data type.
def foldSum {A : Type u} {B : Type v} {C : Type w}
    (left : A -> C) (right : B -> C) (z : Sum A B) : C :=
  match z with
  | Sum.inl a => left a
  | Sum.inr b => right b

def inspect (z : Sum Nat Bool) : Nat :=
  foldSum (fun n => n + 1) (fun b => if b then 1 else 0) z

example : inspect (Sum.inl 4) = 5 := rfl
example : inspect (Sum.inr true) = 1 := rfl
example : inspect (Sum.inr false) = 0 := rfl

example {C : Type u} (e : Empty) : C := Empty.elim e

example (z : Sum Nat Bool) : Nat := by
  fail_if_success exact z
  exact inspect z

-- Exercise: swap tags, retaining the payload.
def swapSum {A : Type u} {B : Type v} (z : Sum A B) : Sum B A :=
  match z with
  | Sum.inl a => Sum.inr a
  | Sum.inr b => Sum.inl b

example {A : Type u} {B : Type v} (z : Sum A B) :
    swapSum (swapSum z) = z := by
  cases z with
  | inl a => rfl
  | inr b => rfl

end V12.Ch156
