namespace V12.Ch159

universe u v

-- coverage: 159.1a, 159.1b
#check @Eq
#check @Eq.refl
#check @Eq.rec

def equalityElim {A : Sort u} {x : A}
    (M : (y : A) -> x = y -> Sort v)
    (c : M x rfl) {y : A} (h : x = y) : M y h :=
  Eq.rec (motive := M) c h

-- coverage: 159.2a
theorem symmByRec {A : Sort u} {x y : A} (h : x = y) : y = x :=
  Eq.rec (motive := fun y _ => y = x) (Eq.refl x) h

theorem transByRec {A : Sort u} {x y z : A}
    (h : x = y) (k : y = z) : x = z :=
  Eq.rec (motive := fun z _ => x = z) h k

theorem congrByRec {A : Sort u} {C : Sort v} (f : A -> C)
    {x y : A} (h : x = y) : f x = f y :=
  Eq.rec (motive := fun y _ => f x = f y) (Eq.refl (f x)) h

-- coverage: 159.2b
example (n : Nat) : (fun k : Nat => k) n = n := rfl

example {A : Sort u} {x y : A} (h : x = y) : y = x := by
  fail_if_success rfl
  exact symmByRec h

example {A : Sort u} {C : Sort v} (f : A -> C)
    {x y : A} (h : x = y) : f x = f y := by
  fail_if_success rfl
  rw [h]

example {A : Sort u} (P : A -> Prop) {x y : A}
    (h : x = y) (hx : P x) : P y :=
  Eq.rec (motive := fun y _ => P y) hx h

-- coverage: 159.2c. Proof irrelevance is built into Lean conversion.
example {p : Prop} (h k : p) : h = k := rfl

-- coverage: 159.2d. A deliberately separate addition, recursive on the right.
def add : Nat -> Nat -> Nat
  | a, 0 => a
  | a, Nat.succ b => Nat.succ (add a b)

theorem add_zero (n : Nat) : add n 0 = n := rfl

theorem zero_add (n : Nat) : add 0 n = n := by
  induction n with
  | zero => rfl
  | succ n ih => exact congrByRec Nat.succ ih

theorem add_right_congr (a : Nat) {b c : Nat} (h : b = c) :
    add a b = add a c := congrByRec (add a) h

#print axioms equalityElim
#print axioms symmByRec
#print axioms transByRec
#print axioms congrByRec
#print axioms add_zero
#print axioms zero_add
#print axioms add_right_congr

end V12.Ch159
