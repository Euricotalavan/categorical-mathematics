namespace V12.Ch160

universe u

-- coverage: 160.1b. The missing type argument is inferred from x.
def inferredId {A : Sort u} (x : A) : A := x
example : inferredId 7 = @inferredId Nat 7 := rfl

-- coverage: 160.2a
theorem andCommTerm (p q : Prop) (h : p /\ q) : q /\ p :=
  And.intro h.right h.left

theorem andCommTactic (p q : Prop) (h : p /\ q) : q /\ p := by
  exact And.intro h.right h.left

set_option pp.explicit true in
#check @andCommTerm
set_option pp.explicit true in
#check @andCommTactic
#print andCommTerm
#print andCommTactic

-- The axiom report follows the proof's transitive dependencies.
#print axioms andCommTerm
#print axioms andCommTactic

-- Accepted repair of the incomplete proof shown in experiments/Incomplete.lean.
theorem repaired (p : Prop) (h : p) : p := h
#print axioms repaired

end V12.Ch160
