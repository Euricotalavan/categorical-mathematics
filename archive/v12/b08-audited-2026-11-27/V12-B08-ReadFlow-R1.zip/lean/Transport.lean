namespace V12.Calibration1593

universe u v

inductive Vect (α : Type u) : Nat → Type u where
  | nil : Vect α 0
  | cons {n : Nat} : α → Vect α n → Vect α (Nat.succ n)

def transport {A : Sort u} (B : A → Sort v)
    {x y : A} (h : x = y) (b : B x) : B y :=
  Eq.rec (motive := fun y _ => B y) b h

theorem transport_rfl {A : Sort u} (B : A → Sort v)
    {x : A} (b : B x) : transport B (rfl : x = x) b = b :=
  rfl

def transportVect {α : Type u} {n m : Nat}
    (h : n = m) (xs : Vect α n) : Vect α m :=
  transport (fun i => Vect α i) h xs

theorem singleton_rfl {α : Type u} (a : α) :
    transportVect (rfl : 1 = 1) (Vect.cons a Vect.nil) =
      Vect.cons a Vect.nil :=
  rfl

theorem transport_trans {A : Sort u} (B : A → Sort v)
    {x y z : A} (h : x = y) (k : y = z) (b : B x) :
    transport B k (transport B h b) = transport B (h.trans k) b := by
  cases h
  cases k
  rfl

theorem transport_roundTrip {A : Sort u} (B : A → Sort v)
    {x y : A} (h : x = y) (b : B x) :
    transport B h.symm (transport B h b) = b := by
  cases h
  rfl

-- With independent indices, the local equality does not by itself change the type of xs.
example {α : Type u} {n m : Nat} (h : n = m) (xs : Vect α n) :
    Vect α m := by
  fail_if_success exact xs
  exact transportVect h xs

#print axioms transport
#print axioms transport_rfl
#print axioms transportVect
#print axioms singleton_rfl
#print axioms transport_trans
#print axioms transport_roundTrip

end V12.Calibration1593
