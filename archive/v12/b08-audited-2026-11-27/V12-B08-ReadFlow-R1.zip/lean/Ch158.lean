namespace V12

universe u

-- The parameter is fixed; the length is an index.
inductive Vect (α : Type u) : Nat → Type u where
  | nil : Vect α 0
  | cons {n : Nat} : α → Vect α n → Vect α (Nat.succ n)

def double : Nat → Nat
  | 0 => 0
  | Nat.succ n => Nat.succ (Nat.succ (double n))

inductive Even : Nat → Prop where
  | zero : Even 0
  | step {n : Nat} : Even n → Even (Nat.succ (Nat.succ n))

theorem even_double (n : Nat) : Even (double n) := by
  induction n with
  | zero => exact Even.zero
  | succ n ih => exact Even.step ih

namespace Project

inductive Ty where
  | nat
  | bool

abbrev Denote : Ty → Type
  | .nat => Nat
  | .bool => Bool

inductive Expr : Ty → Type where
  | nat (n : Nat) : Expr .nat
  | bool (b : Bool) : Expr .bool
  | add : Expr .nat → Expr .nat → Expr .nat
  | lt : Expr .nat → Expr .nat → Expr .bool
  | ite {t : Ty} : Expr .bool → Expr t → Expr t → Expr t

def eval : {t : Ty} → Expr t → Denote t
  | _, .nat n => n
  | _, .bool b => b
  | _, .add a b => eval a + eval b
  | _, .lt a b => decide (eval a < eval b)
  | _, .ite c a b => if eval c then eval a else eval b

def sample : Expr .nat :=
  .ite (.lt (.nat 1) (.nat 2)) (.add (.nat 3) (.nat 4)) (.nat 9)

theorem sample_value : eval sample = 7 := rfl

-- An invalid cross-sort addition is rejected by the elaborator.
example : True := by
  fail_if_success have : Expr .nat := Expr.add (Expr.bool true) (Expr.nat 1)
  exact True.intro

#check @Expr.rec
#print axioms V12.even_double
#print axioms sample_value

end Project
end V12
