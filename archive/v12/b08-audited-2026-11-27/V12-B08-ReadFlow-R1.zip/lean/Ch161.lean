namespace V12.Ch161

universe u v

-- coverage: 161.1a. h is a local hypothesis, not a new global axiom.
theorem conditional (p q : Prop) (h : p) : q -> p := fun _ => h

-- coverage: 161.1b. Record types and actual dependencies separately.
#check @propext
#check @Quot.sound
#check @Classical.choice
#check @funext
#print axioms propext
#print axioms Quot.sound
#print axioms Classical.choice
#print axioms funext

-- coverage: 161.2a. Same conclusion, two explicitly different proof methods.
theorem notNotIntroConstructive (p : Prop) (h : p) : Not (Not p) :=
  fun hn => hn h

theorem notNotIntroClassical (p : Prop) (h : p) : Not (Not p) := by
  cases Classical.em p with
  | inl hp => exact fun hn => hn hp
  | inr hnp => exact False.elim (hnp h)

theorem emExplicit (p : Prop) : p \/ Not p := Classical.em p

-- A named wrapper displays a transitive dependency on Classical.choice.
theorem emWrapper (p : Prop) : p \/ Not p := emExplicit p

-- An equivalence of propositions is different from their equality.
theorem propositionEquality {p q : Prop} (h : p <-> q) : p = q :=
  propext h

theorem pointwiseToEquality {A : Sort u} {B : A -> Sort v}
    {f g : (a : A) -> B a} (h : (a : A) -> f a = g a) : f = g :=
  funext h

#print conditional
#print axioms conditional
#print axioms notNotIntroConstructive
#print axioms notNotIntroClassical
#print axioms emExplicit
#print axioms emWrapper
#print axioms propositionEquality
#print axioms pointwiseToEquality

end V12.Ch161
