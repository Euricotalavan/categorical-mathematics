import Lean

namespace V12.Ch163
universe u

theorem twice_fixed {α : Sort u} (f : α → α) (x : α) (h : f x = x) :
    f (f x) = x :=
  Eq.trans (congrArg f h) h

class Step (α : Type u) where
  step : α → α

instance natStep : Step Nat where
  step n := n + 0

def advance {α : Type u} [Step α] (x : α) : α := Step.step x

theorem nat_advance (n : Nat) : advance n = n := rfl
theorem nat_advance_twice (n : Nat) : advance (advance n) = n :=
  V12.Ch163.twice_fixed (fun k : Nat => advance k) n (nat_advance n)

namespace Nearby
def advance (n : Nat) := n + 1
theorem qualified (n : Nat) : V12.Ch163.advance n = n :=
  V12.Ch163.nat_advance n
end Nearby

theorem successor_not_fixed : ¬ ((fun n : Nat => n + 1) 0 = 0) := by
  intro h
  exact Nat.noConfusion h

#check @V12.Ch163.twice_fixed
#check @V12.Ch163.advance
#synth Step Nat
#print axioms V12.Ch163.nat_advance_twice
end V12.Ch163
