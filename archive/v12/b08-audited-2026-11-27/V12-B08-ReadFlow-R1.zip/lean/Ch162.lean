import Ch158

namespace V12.Ch162
universe u

def Sized (α : Type u) (n : Nat) := {xs : List α // xs.length = n}

structure SizedRecord (α : Type u) (n : Nat) where
  entries : List α
  length_eq : entries.length = n

def SizedRecord.toSized {α : Type u} {n : Nat} (r : SizedRecord α n) : Sized α n :=
  ⟨r.entries, r.length_eq⟩

def recordPair : SizedRecord Nat 2 := ⟨[4, 7], rfl⟩
theorem record_entries : recordPair.entries = [4, 7] := rfl

def vectorToList {α : Type u} {n : Nat} : V12.Vect α n → List α
  | .nil => []
  | .cons a xs => a :: vectorToList xs

theorem vectorLength {α : Type u} {n : Nat} (v : V12.Vect α n) :
    (vectorToList v).length = n := by
  induction v with
  | nil => rfl
  | cons a xs ih => exact congrArg Nat.succ ih

def vectorToSized {α : Type u} {n : Nat} (v : V12.Vect α n) : Sized α n :=
  ⟨vectorToList v, vectorLength v⟩

def checkedPair : Sized Nat 2 := ⟨[4, 7], rfl⟩
def indexedPair : V12.Vect Nat 2 := .cons 4 (.cons 7 .nil)
theorem pair_agreement : (vectorToSized indexedPair).val = checkedPair.val := rfl
theorem empty_not_one : ¬ (([] : List Nat).length = 1) := by
  intro h
  exact Nat.noConfusion h

open V12.Project

inductive Raw where
  | nat : Nat → Raw
  | bool : Bool → Raw
  | add : Raw → Raw → Raw
  | lt : Raw → Raw → Raw
  | ite : Raw → Raw → Raw → Raw

abbrev Value := Sum Nat Bool

def rawEval : Raw → Option Value
  | .nat n => some (.inl n)
  | .bool b => some (.inr b)
  | .add x y =>
    match rawEval x, rawEval y with
    | some (.inl m), some (.inl n) => some (.inl (m + n))
    | _, _ => none
  | .lt x y =>
    match rawEval x, rawEval y with
    | some (.inl m), some (.inl n) => some (.inr (decide (m < n)))
    | _, _ => none
  | .ite c x y =>
    match rawEval c with
    | some (.inr true) => rawEval x
    | some (.inr false) => rawEval y
    | _ => none

def typedSum : Expr .nat := .add (.nat 2) (.nat 3)
def rawSum : Raw := .add (.nat 2) (.nat 3)
theorem sum_correspondence : rawEval rawSum = some (.inl (eval typedSum)) := rfl

def typedTest : Expr .bool := .lt (.nat 2) (.nat 3)
def rawTest : Raw := .lt (.nat 2) (.nat 3)
theorem test_correspondence : rawEval rawTest = some (.inr (eval typedTest)) := rfl

theorem bad_add : rawEval (.add (.bool true) (.nat 3)) = none := rfl
-- rawEval checks the selected branch dynamically. It is not a static checker.
theorem unselected_bad_branch :
    rawEval (.ite (.bool true) (.nat 2) (.bool false)) = some (.inl 2) := rfl

#print axioms vectorLength
#print axioms sum_correspondence
#print axioms test_correspondence
end V12.Ch162
