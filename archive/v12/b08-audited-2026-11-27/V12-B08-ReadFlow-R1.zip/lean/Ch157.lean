namespace V12.Ch157
universe u v

-- 157.1a: a dependent result type.
def applyDependent {A : Type u} {B : A -> Type v}
    (f : (a : A) -> B a) (a : A) : B a := f a

def familyIdentity (A : Type u) : (x : A) -> A := fun x => x

-- 157.1b: implicit type arguments can be exposed with @.
def consExplicit : (A : Type u) -> A -> List A -> List A :=
  @List.cons

example : consExplicit Nat 3 [] = [3] := rfl
example : List.cons 3 ([] : List Nat) = [3] := rfl

set_option autoImplicit false in
/--
error: Unknown identifier `A`

Note: It is not possible to treat `A` as an implicitly bound variable here because the `autoImplicit` option is set to `false`.
-/
#guard_msgs in
def unboundHead (a : A) := a

-- 157.2a-b: the second projection is in the first projection's fiber.
def first {A : Type u} {B : A -> Type v} (s : Sigma B) : A := s.1

def second {A : Type u} {B : A -> Type v} (s : Sigma B) : B s.1 :=
  s.2

example {A : Type u} {C : Type v} (s : Sigma (fun _ : A => C)) : A × C := by
  fail_if_success exact s
  exact (s.1, s.2)

def Payload : Bool -> Type
  | true => Nat
  | false => Bool

def packet : Sigma Payload := Sigma.mk true (7 : Nat)

example : packet.1 = true := rfl
example : packet.2 = (7 : Nat) := rfl

example : Payload true := by
  fail_if_success exact (true : Bool)
  exact (7 : Nat)

-- 157.3a-b: specialize at x, then project.
theorem projectForall (A : Type u) (P Q : A -> Prop)
    (h : forall x : A, And (P x) (Q x)) : forall x : A, P x :=
  fun x => (h x).left

-- 157.3c: existential elimination into a proposition.
theorem mapExists (A : Type u) (P Q : A -> Prop)
    (step : forall x : A, P x -> Q x) (h : Exists P) : Exists Q :=
  Exists.elim h (fun x hx => Exists.intro x (step x hx))

-- The failed extraction is checked inside a successful declaration.
example (_h : Exists (fun _n : Nat => True)) : Nat := by
  fail_if_success exact Exists.elim _h (fun n _hn => n)
  exact 0

def dataWitness {A : Type u} {B : A -> Type v} (s : Sigma B) : A :=
  s.1

-- Exercises: construct an existential and specialize a dependent function.
theorem witnessFromPoint (A : Type u) (P : A -> Prop)
    (a : A) (ha : P a) : Exists P := Exists.intro a ha

example (A : Type u) (P : A -> Prop) (h : forall x, P x) (a : A) :
    P a := h a

end V12.Ch157
