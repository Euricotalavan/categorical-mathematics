import Ch154
import Ch155
import Ch156
import Ch157
import Ch159
import Transport
import Ch162
import Ch164
import Ch166

namespace V12.B07Audit
open V12.Project
open V12.Ch162 (Raw rawEval)

-- Distinguish a natural number from a type in a higher universe.
def expectLarge (a : Type 1) : Type 1 := a
example : Type 1 := by
  fail_if_success exact expectLarge Nat
  exact expectLarge (ULift.{1, 0} Nat)

-- Proof irrelevance concerns terms of one proposition, not its neighbors.
example (p : Prop) (h k : p) : h = k := rfl
example (p q : Prop) (h : p ∧ q) : q ∧ p := by
  fail_if_success exact h
  exact ⟨h.right, h.left⟩

def fiber : Bool → Type
  | true => Nat
  | false => Bool

example : Sigma fiber := by
  fail_if_success exact ⟨true, true⟩
  exact ⟨true, (7 : Nat)⟩

example (_h : ∃ n : Nat, n = 7) : Nat := by
  fail_if_success exact Exists.elim _h (fun n _ => n)
  exact 7

-- Both Vect types exist, and the generic operation works with either.
universe u v
example {α : Type u} {n m : Nat} (h : n = m)
    (w : V12.Vect α n) : V12.Vect α m := by
  fail_if_success exact w
  fail_if_success exact V12.Calibration1593.transportVect h w
  exact V12.Calibration1593.transport (V12.Vect α) h w

example {A : Sort u} (B : A → Sort v) {x : A} (h : x = x) (a : B x) :
    V12.Calibration1593.transport B h a = a := rfl

def zeroFiber : Nat → Prop
  | 0 => True
  | Nat.succ _ => False

example : (0 : Nat) ≠ 1 :=
  fun h => V12.Calibration1593.transport zeroFiber h True.intro

-- First rewrite exactly at the inner occurrence; the second goal still needs h.
example (f : Nat → Nat) (x : Nat) (h : f x = x) : f (f x) = x := by
  rw [h]
  show f x = x
  exact h

-- Check all cases by inspection of the source for the universal claim.
-- These fresh tests exercise the boundary between shape and value.
example : fold (.lt (.nat 3) (.nat 3)) = .bool false := rfl
example : fold (.lt (.add (.nat 1) (.nat 2)) (.nat 4)) =
    .lt (.nat 3) (.nat 4) := rfl
example : fold (.ite (.bool false) (.bool false) (.lt (.nat 0) (.nat 1))) =
    .bool true := rfl
example : fold (.ite (.ite (.bool true) (.bool false) (.bool true))
    (.nat 2) (.nat 8)) = .ite (.bool false) (.nat 2) (.nat 8) := rfl
example : eval (fold (.ite (.ite (.bool true) (.bool false) (.bool true))
    (.nat 2) (.nat 8))) = 8 := rfl

example : rawEval (.ite (.bool false) (.add (.bool true) (.nat 1)) (.nat 7)) =
    some (.inl 7) := rfl
example : rawEval (.ite (.nat 1) (.nat 3) (.nat 7)) = none := rfl

-- Explicitly ascribe the required interface types independently of #check.
theorem checkedInterface : ∀ {t : Ty} (e : Expr t), eval (fold e) = eval e :=
  project_correct
theorem checkedSample : eval (fold sample) = 7 := project_sample

#print axioms checkedInterface
#print axioms checkedSample

end V12.B07Audit
