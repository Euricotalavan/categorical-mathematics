# V12 B-07 responsibility locations

Locations identify the manuscript passage. Review verdicts are in the handoff.

| ID | Kind | Manuscript line | Fixed source mapping |
|---|---|---|---|
| 154.1a | 定義 | `ch154.tex:9` | H §1.1，pp.18–19；L §2.1 |
| 154.1b | 定義 | `ch154.tex:39` | H §1.1，pp.18–19 |
| 154.2a | 定義 | `ch154.tex:76` | L §2.2、§3.1 |
| 154.2b | 比較 | `ch154.tex:85` | H §1.3，p.24；L Ch.2 開首及 §2.2 |
| 154.3a | 例題 | `ch154.tex:110` | L §2.1 |
| 155.1a | 定義 | `ch155.tex:10` | L §3.1；M §2.1 |
| 155.1b | 規則 | `ch155.tex:27` | L §§3.1、3.3 |
| 155.2a | 證明 | `ch155.tex:68` | L §3.2 |
| 155.2b | 證明 | `ch155.tex:88` | L §3.2 |
| 155.3a | 定義 | `ch155.tex:136` | L §3.3 |
| 155.3b | 例題 | `ch155.tex:166` | L §3.3.1 |
| 155.3c | 比較 | `ch155.tex:181` | L §§3.1、3.3.1 |
| 156.1a | 定義 | `ch156.tex:11` | H §1.2，p.21；L §2.1 |
| 156.1b | 命題 | `ch156.tex:43` | H §§1.2、1.4，pp.22–23、25–26 |
| 156.2a | 定義 | `ch156.tex:89` | H §1.5，pp.26–29；L Ch.9 開首 |
| 156.2b | 例題 | `ch156.tex:122` | H §1.5；L §3.3.1 |
| 156.3a | 定義 | `ch156.tex:156` | H §1.7，pp.33–34 |
| 156.3b | 例題 | `ch156.tex:196` | H §1.7 |
| 157.1a | 定義 | `ch157.tex:11` | H §1.4；L §2.8 |
| 157.1b | 例題 | `ch157.tex:46` | L §2.8 |
| 157.2a | 定義 | `ch157.tex:91` | H §1.6，pp.30–31；L §2.8 |
| 157.2b | 例題 | `ch157.tex:120` | L §2.8 |
| 157.3a | 定義 | `ch157.tex:171` | L §4.1 |
| 157.3b | 證明 | `ch157.tex:189` | L §4.1 |
| 157.3c | 規則 | `ch157.tex:213` | L §§4.4、7.8 |
| 158.1a | 定義 | `ch158.tex:12` | L Ch.7 開首；H §1.9 |
| 158.1b | 定義 | `ch158.tex:36` | L §7.8 |
| 158.2a | 例題 | `ch158.tex:61` | L §7.7 |
| 158.2b | 規則 | `ch158.tex:96` | L §8.3 |
| 158.2c | 證明 | `ch158.tex:122` | 本卷自立，歸納方法參 L §8.3；H §1.9 |
| 158.3a | 比較 | `ch158.tex:186` | L Ch.8 開首、§8.5 |
| 158.3b | 定義 | `ch158.tex:196` | 本卷自立；索引及遞迴方法以 L §§7.8、8.3 為準 |
| 159.1a | 定義 | `ch159.tex:11` | H §1.12；L §§4.2、7.7 |
| 159.1b | 規則 | `ch159.tex:36` | L §§7.7–7.8；H §1.12.1 |
| 159.2a | 證明 | `ch159.tex:89` | L §7.7 的練習與公式；H §2.2 |
| 159.2b | 例題 | `ch159.tex:125` | L §4.2 |
| 159.2c | 比較 | `ch159.tex:160` | H Remark 1.12.1，p.51；L §3.1 |
| 159.2d | 證明 | `ch159.tex:176` | L §8.3；H §1.9 |
| 159.3a | 命題 | `transport.tex:43` | H Lemma 2.3.1，p.72；L §7.7 |
| 159.3b | 證明 | `transport.tex:49` | H §2.3；L §7.7 |
| 159.3c | 例題 | `transport.tex:68` | 本卷自立；L §7.7；H §2.3 |
| 160.1a | 定義 | `ch160.tex:11` | R Elaboration §§2.2–2.3 |
| 160.1b | 規則 | `ch160.tex:36` | R Elaboration §2.2；L §§6.12–6.13 |
| 160.2a | 例題 | `ch160.tex:74` | L §5.1；R Validating §The Blue Double Check Marks |
| 160.2b | 例題 | `ch160.tex:111` | R Validating §§The Blue Double Check Marks、Printing Axioms |
| 161.1a | 定義 | `ch161.tex:10` | L §§3.1–3.2、Ch.12；R Printing Axioms |
| 161.1b | 比較 | `ch161.tex:33` | L Ch.12；R Printing Axioms |
| 161.2a | 證明 | `ch161.tex:106` | L §3.5、Ch.12；R Printing Axioms |
| 161.2b | 例題 | `ch161.tex:148` | R Validating §§Printing Axioms、Comments |
| 162.1a | 定義 | `ch162.tex:9` | R Subtypes §21.20；L Ch.9 |
| 162.1b | 例題 | `ch162.tex:46` | R Subtypes；L §§7.7–7.8、Ch.9 |
| 162.2a | 命題與證明 | `ch162.tex:122` | 本卷自立。規格形式參 M §1.1 |
| 163.1a | 規則 | `ch163.tex:9` | L §§6.2、6.4 |
| 163.1b | 定義 | `ch163.tex:38` | L Ch.10 開首、§10.1 |
| 163.2a | 例題 | `ch163.tex:58` | L §6.11；R Printing Axioms |
| 163.2b | 例題 | `ch163.tex:78` | L §§6.4、6.9、10.1；本卷例題自寫 |
| 164.1a | 規則 | `ch164.tex:14` | L §§5.6–5.7；R Simp sets |
| 164.1b | 例題 | `ch164.tex:25` | L §§5.6–5.7；R Simp sets |
| 164.2a | 定義 | `ch164.tex:61` | L Ch.10 的判定性段落；R Validating 的 `decide` 說明 |
| 164.2b | 例題 | `ch164.tex:86` | L §§5.1–5.2；本卷例題自寫 |
| 165.1a | 定義 | `ch165.tex:13` | 自立專題；M §1.1、Ch.2；F §8.2 |
| 165.1b | 定義 | `ch165.tex:41` | 本卷自立；L §8.3 |
| 165.2a | 命題 | `ch165.tex:113` | 本卷自立；F §8.2 的逐輸入證法作方法參考 |
| 165.2b | 證明 | `ch165.tex:122` | 本卷自立 |
| 165.3a | 例題 | `ch165.tex:307` | 本卷自立；M §1.1；F §8.2 |
| 166.1a | 專題 | `ch166.tex:12` | 對應 158.3b、161.2b、165.1–165.3 |
| 166.2a | 核驗 | `ch166.tex:99` | R Validating；本卷重建步驟 |
