import Ch158
import Transport

namespace V12.B05Audit
universe u

def calibrationVectorTransport {α : Type u} {n m : Nat}
    (h : n = m) (xs : V12.Calibration1593.Vect α n) :
    V12.Calibration1593.Vect α m :=
  V12.Calibration1593.transportVect h xs

def chapterVectorTransport {α : Type u} {n m : Nat}
    (h : n = m) (xs : V12.Vect α n) : V12.Vect α m :=
  V12.Calibration1593.transport (fun i => V12.Vect α i) h xs

example {α : Type u} {n m : Nat} (h : n = m) (xs : V12.Vect α n) :
    V12.Vect α m := by
  fail_if_success exact V12.Calibration1593.transportVect h xs
  exact chapterVectorTransport h xs

theorem empty_length {α : Type u} : ([] : List α).length = 0 := rfl

theorem cons_length {α : Type u} (a : α) (xs : List α) :
    (a :: xs).length = Nat.succ xs.length := rfl

#check @calibrationVectorTransport
#check @chapterVectorTransport
#print axioms chapterVectorTransport
#print axioms empty_length
#print axioms cons_length
end V12.B05Audit
