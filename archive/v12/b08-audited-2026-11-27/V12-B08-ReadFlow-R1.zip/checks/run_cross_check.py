"""Compile the fixed V12 source closure and independently checked boundary examples."""

import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory


root = Path(__file__).resolve().parent
intake = Path(sys.argv[1]).resolve()
lean = sys.argv[2]

version = subprocess.check_output([lean, "--version"], encoding="utf-8")
if "version 4.33.0," not in version or "d8b18978322de05a8f3dba51ef03cf5461676c17" not in version:
    raise SystemExit("Use the pinned Lean 4.33.0 toolchain.")
print(version.strip())

with TemporaryDirectory(prefix="v12-b07-cross-check-") as tmp:
    build = Path(tmp)
    env = os.environ | {"LEAN_PATH": str(build)}
    modules = [*sorted((intake / "lean").glob("Ch*.lean")), intake / "lean/Transport.lean"]
    for path in modules:
        shutil.copyfile(path, build / path.name)
        subprocess.run(
            [lean, "-DwarningAsError=true", "-o", path.with_suffix(".olean").name, path.name],
            cwd=build, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            check=True, encoding="utf-8",
        )
    for path in (intake / "checks/BRIDGE-CHECK.lean", root / "CROSS-CHECK.lean"):
        shutil.copyfile(path, build / path.name)
        run = subprocess.run(
            [lean, "-DwarningAsError=true", path.name], cwd=build, env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding="utf-8",
        )
        print(f"[{path.name}]\n{run.stdout}", end="")
        if run.returncode or "sorryAx" in run.stdout:
            raise SystemExit(f"Diagnostic failure: {path.name}")
        if path.name == "CROSS-CHECK.lean":
            for name in ("checkedInterface", "checkedSample"):
                if f"'V12.B07Audit.{name}' depends on axioms: [propext]" not in run.stdout:
                    raise SystemExit(f"Unexpected axiom report for {name}")
    chapter = (intake / "source/content/ch166.tex").read_text(encoding="utf-8")
    example = re.search(r"\\begin\{verbatim\}\n(import Ch166\nopen V12\.Project\n.*?)(?=\\end\{verbatim\})", chapter, re.S)
    if example:
        (build / "Audit166.lean").write_text(example[1], encoding="utf-8")
        output = subprocess.check_output(
            [lean, "-DwarningAsError=true", "Audit166.lean"], cwd=build, env=env, encoding="utf-8"
        )
        print("[Audit166.lean as printed in Chapter 166]\n" + output, end="")
        if "∀ {t : Ty} (e : Expr t), eval (fold e) = eval e" not in output or output.count("[propext]") != 2:
            raise SystemExit("Printed project audit does not give the stated results.")
print("PASS: clean dependency closure, transport bridge, review examples, exact project signatures.")
