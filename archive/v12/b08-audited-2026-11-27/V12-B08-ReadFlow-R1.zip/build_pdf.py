"""Build the Volume 12 reading PDF using the adopted ReadFlow R1 layout."""

from hashlib import sha256
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
STUDY = ROOT / "source/layout/study"
XELATEX = sys.argv[1] if len(sys.argv) > 1 else "xelatex"


def main():
    for record in (ROOT / "FONTS.sha256").read_text(encoding="utf-8").splitlines():
        expected, name = record.split("  ", 1)
        font = ROOT / "source/fonts" / name
        if not font.is_file() or sha256(font.read_bytes()).hexdigest() != expected:
            raise SystemExit(f"Missing or different ReadFlow R1 font: {name}")

    captures = ROOT / "scratch"
    captures.mkdir(exist_ok=True)
    command = [XELATEX, "--disable-installer", "-no-shell-escape", "-halt-on-error",
               "-interaction=nonstopmode", "-file-line-error", "V12-B07.tex"]
    for run_number in (1, 2):
        capture = captures / f"xelatex-pass{run_number}.log"
        with capture.open("wb") as output:
            result = subprocess.run(command, cwd=STUDY, stdout=output,
                                    stderr=subprocess.STDOUT, check=False)
        output = capture.read_text(encoding="utf-8", errors="replace")
        if "Output written on V12-B07.pdf" not in output or result.returncode:
            print(output[-4000:])
            raise SystemExit(f"XeLaTeX pass {run_number} failed")

    log = (STUDY / "V12-B07.log").read_text(encoding="utf-8", errors="replace")
    if re.search(r"undefined references|multiply[ -]defined|Missing character:|Label\(s\) may have changed", log):
        raise SystemExit("Undefined references, duplicate labels, or missing glyphs in final log")
    target = ROOT / "V12-B07.pdf"
    shutil.copyfile(STUDY / "V12-B07.pdf", target)
    print(f"PDF SHA-256 {sha256(target.read_bytes()).hexdigest()}")
    for line in log.splitlines():
        if re.search(r"Warning:|Overfull|Underfull|^Output written", line):
            print(line)


if __name__ == "__main__":
    main()
