-- Intentionally admitted demonstration: NOT part of the accepted source set.
namespace V12.Experiment

-- coverage: 160.2b, 161.2b
theorem admitted (p : Prop) (h : p) : p := by
  sorry

theorem downstream (p : Prop) (h : p) : p := admitted p h

#print axioms admitted
#print axioms downstream

end V12.Experiment
