"""Check the fixed inputs and locate each responsibility in the single manuscript."""

from collections import Counter
from hashlib import sha256
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source/content"
INPUT = ROOT / "baselines/B01-B02-INTAKE.md"
DRIVER = ROOT / "source/layout/study/V12-B07.tex"
PINNED = {
    INPUT: "a642e876ef572aee6ba053b8c61944f38594fd10680f8b461bc6c76df802b2aa",
    SOURCE / "transport.tex": "86760bf12b57aee7dc28352849caf3adae650f6d6d41727c3efa2ea8134df6ac",
    ROOT / "lean/Transport.lean": "8d79e9a9fa2bd088f43a9c19e615864ebe0a6d72b42836a719f6df4f638106d6",
}
RESPONSIBILITY = re.compile(r"^\| ((?:15[4-9]|16[0-6])\.\d+[a-z]) \| (.*?) \| (.*?) \| (.*?) \|$", re.MULTILINE)
MARKER = re.compile(r"^% coverage: (\d+\.\d+[a-z])\s*$")
FROZEN = {
    "159.3a": "\\begin{proposition}[Transport]",
    "159.3b": "Choose the motive",
    "159.3c": "\\begin{example}[Changing the vector index]",
}


def read(path):
    return path.read_text(encoding="utf-8")


def main():
    for path, expected in PINNED.items():
        if sha256(path.read_bytes()).hexdigest() != expected:
            raise SystemExit(f"Fixed input changed: {path.name}")

    chapters = list(range(154, 167))
    driver = read(DRIVER)
    if "\\setcounter{chapter}{153}" not in driver:
        raise SystemExit("Expected the V11 chapter 153 baseline")
    if [int(n) for n in re.findall(r"\\input\{../../content/ch(\d+)\.tex\}", driver)] != chapters:
        raise SystemExit("Chapter order or coverage changed")

    planned = RESPONSIBILITY.findall(read(INPUT))
    if len(planned) != 67 or len({r[0] for r in planned}) != 67:
        raise SystemExit("Fixed responsibility count changed")

    found = {}
    labels = []
    references = []
    for number in chapters:
        path = SOURCE / f"ch{number}.tex"
        body = read(path)
        section = 0
        if len(re.findall(r"^\\chapter\{", body, re.MULTILINE)) != 1:
            raise SystemExit(f"Expected exactly one chapter command in {path.name}")
        labels.extend(re.findall(r"\\label\{([^}]+)\}", body))
        references.extend(re.findall(r"\\(?:ref|autoref|eqref|pageref)\{([^}]+)\}", body))
        for line_number, line in enumerate(body.splitlines(), 1):
            section += line.startswith("\\section{")
            match = MARKER.fullmatch(line)
            if match:
                key = match[1]
                if not key.startswith(f"{number}.{section}") or key in found:
                    raise SystemExit(f"Duplicate or misplaced responsibility {key}")
                found[key] = path.name, line_number
        expected_sections = {re.match(r"\d+\.(\d+)", row[0])[1] for row in planned if row[0].startswith(f"{number}.")}
        inherited = number == 159 and body.count("\\input{../../content/transport.tex}") == 1
        if (number == 159 and not inherited) or section + inherited != len(expected_sections):
            raise SystemExit(f"Unexpected section count in Chapter {number}")

    frozen = read(SOURCE / "transport.tex")
    labels.extend(re.findall(r"\\label\{([^}]+)\}", frozen))
    if any(count > 1 for count in Counter(labels).values()) or set(references) - set(labels):
        raise SystemExit(f"Duplicate labels or unresolved references: {sorted(set(references) - set(labels))}")
    for key, anchor in FROZEN.items():
        if frozen.count(anchor) != 1:
            raise SystemExit(f"Frozen anchor changed: {key}")
        found[key] = "transport.tex", frozen[:frozen.index(anchor)].count("\n") + 1

    want = {key for key, *_ in planned}
    if want != set(found):
        raise SystemExit(f"Missing {sorted(want - set(found))}; extra {sorted(set(found) - want)}")

    print("# V12 B-07 responsibility locations\n")
    print("Locations identify the manuscript passage. Review verdicts are in the handoff.\n")
    print("| ID | Kind | Manuscript line | Fixed source mapping |")
    print("|---|---|---|---|")
    for key, kind, _, reference in planned:
        path, line = found[key]
        print(f"| {key} | {kind} | `{path}:{line}` | {reference} |")


if __name__ == "__main__":
    main()
