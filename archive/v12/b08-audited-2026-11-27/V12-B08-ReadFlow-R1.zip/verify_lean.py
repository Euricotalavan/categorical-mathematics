"""Rebuild the B-04 Lean code from source with the pinned toolchain."""

from pathlib import Path
import os
import re
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory


ROOT = Path(__file__).resolve().parent
LEAN = sys.argv[1] if len(sys.argv) > 1 else "lean"
VERSION = (ROOT / "lean-toolchain").read_text(encoding="utf-8").strip().split(":v", 1)[1]
PINNED_COMMIT = "d8b18978322de05a8f3dba51ef03cf5461676c17"
MODULES = [f"Ch{n}" for n in range(154, 167)] + ["Transport"]


def run(*args, cwd=ROOT, env=None):
    return subprocess.run(
        [LEAN, *args], cwd=cwd, env=env, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, encoding="utf-8", errors="strict", check=False,
    )


def main():
    version = run("--version")
    print(version.stdout, end="")
    if version.returncode or f"version {VERSION}," not in version.stdout or PINNED_COMMIT not in version.stdout:
        raise SystemExit(f"Expected the official Lean {VERSION} build at {PINNED_COMMIT}")

    with TemporaryDirectory(prefix="v12-lean-") as temporary:
        build = Path(temporary)
        env = os.environ | {"LEAN_PATH": str(build)}
        sources = ROOT / "lean"
        if {p.stem for p in sources.glob("*.lean")} != set(MODULES):
            raise SystemExit("Unexpected existing or missing Lean module")
        log = []
        for module in MODULES:
            name = module + ".lean"
            text = (sources / name).read_text(encoding="utf-8")
            code = re.sub(r"/-(?:.|\n)*?-/|--[^\n]*", "", text)
            if re.search(r"\b(?:sorry|admit|axiom|unsafe)\b", code):
                raise SystemExit(f"Unfinished or unchecked declaration in {name}")
            shutil.copyfile(sources / name, build / name)
            result = run("-DwarningAsError=true", "-o", module + ".olean", name, cwd=build, env=env)
            print(f"\n[{name}]\n{result.stdout}", end="")
            if result.returncode:
                raise SystemExit(f"Module failed: {name}")
            log.append(result.stdout)

        output = "\n".join(log)
        if "sorryAx" in output:
            raise SystemExit("An accepted module reported sorryAx")
        if "'V12.Calibration1593.transport_trans' does not depend on any axioms" not in output:
            raise SystemExit("Missing frozen calibration axiom report")
        if "'V12.Project.project_correct' depends on axioms: [propext]" not in output:
            raise SystemExit("The project's recorded axiom inventory changed")

        experiment = ROOT / "experiments" / "Incomplete.lean"
        shutil.copyfile(experiment, build / experiment.name)
        result = run(experiment.name, cwd=build, env=env)
        print(f"\n[Isolated experiment: {experiment.name}]\n{result.stdout}", end="")
        if result.returncode or "depends on axioms: [sorryAx]" not in result.stdout or "uses `sorry`" not in result.stdout:
            raise SystemExit("The isolated admission demonstration returned unexpected diagnostics")

    print(f"\nPASS: {len(MODULES)} clean source builds plus isolated diagnostic experiment.")


if __name__ == "__main__":
    main()
