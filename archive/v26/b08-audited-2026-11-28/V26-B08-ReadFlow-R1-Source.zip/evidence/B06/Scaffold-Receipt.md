# V26 scaffold receipt

2026-11-28. Technical staging only; no chapter manuscript copied or authored.

The three official ReadFlow R1 style files were copied directly from the
fixed V0 ZIP. Each is byte-identical to both that official file and the
published V25 counterpart. Exact hashes are in `../ReadFlow-baseline.json`.
Fonts and accompanying licenses were copied from the fixed published V25
source; `dependency-hashes.json` records their identities. No V25
manuscript, assessment or prior acceptance status is inherited.

The local volume adaptation is confined to `v26-setup.tex`,
`volume-26.tex`, `frontmatter.tex`, `references.tex`, and two adapted tools.
The official three style files are unmodified. The setup supplies volume
metadata, author commands and the established width correction for
three-digit contents numbers. The entry continues at Chapter 325 after
the published V25 Chapter 324. The five bibliography keys are `Axler`,
`Papadimitrakis`, `Ivrii`, `ArmitageGardiner`, and `Ransford`.

`tools/build.py` retains the proven V25 XeLaTeX environment, bundled-font
resolution, no-shell-escape, repeat-until-stable references, and source
hash checks. It adapts the selection to Chapters 325--332. Absolute sample
paths are supported. A sample counter must be supplied with
`--chapter-number N` or is inferred from its `ch:N` label; an existing
sample chapter heading is retained, and a heading is inserted only for
a sample without one. No unrelated chapter is silently chosen.

Validation command:

```
python v26-book/tools/build.py --sample /workspace/scratch/4cc490e05d4f/v26-stage/B06-scaffold-smoke.tex --chapter-number 331 --name scaffold-smoke
```

Result: 2 converged XeLaTeX passes, 0 monitored diagnostics, 3 pages,
42,864 bytes; SHA256
`90026b422151e89a4701f65fd1deae8d3c66287c86ca4549a58216fd6778654c`.
PDF metadata has Volume 26 title, author and Chapters 325--332. Extracted
and rendered sample chapter is Chapter 331, confirming the supplied
counter. All seven command names and all standard V0 theorem/proof/
exercise/solution environments compiled. All 3 synthetic sample pages
were rendered and visually inspected; this is not any V26 textbook
page's B-06 acceptance. The intentional one-line smoke exercise lies at
the end of page 1 and its sample solution on page 2; it is not a retained
textbook layout decision.

Pending: B-05 fixed chapter integration, full contents and metadata
inspection, full source audit, clean whole-volume build, actual all-page
visual reading and B-07. The structural audit will report missing chapter
files until the content roles supply the eight final manuscript files.
