# V26 B-06 行文排版接收與檢核計畫 v1

日期：2026-11-28。角色：行文排版官。方案：本次已授權 B 單一 Work，B-06；未開始其他卷或改動凍結稿。本階段不改章正文，不代替 B-07 數學終審。

## 實際讀入與固定方法

- 已讀 `project_sources/20-Git-QA-v3.txt`、`21-v2.1.txt`、`13-A-B-v4.txt` 第三篇、`05-ReadFlow_Editor_Operating_Draft_v1.md`。
- Git connector 已取回且全文讀入：`SUCCESS-ANALYSIS.md`、`REUSE-GUIDE.md`，固定 commit `dde82ab6b14859774b7f26283bf15b6f2000847e`；`METHODOLOGY-v1.md`、`EDITOR-QA-v1.md`，固定 commit `f4969cc5336bf761d5f80ff616531f85b357a475`。保存於 `project_sources/layout-methodology/`。
- 權威：正式 V0 ReadFlow R1，artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`；ZIP 預期 7007679 bytes / SHA256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。須連同必要字型、build.py、verify.py、MANIFEST.json核驗使用；不得由研究版另造模板。
- 模型實際 High 設定：本工具沒有可獨立查證的模型設定讀取，故記「未核實」，不宣稱切換。

## 接收門檻與保護範圍

只接 B-05 整卷整合版及其固定來源、覆蓋/缺陷表、記號與 OPEN。核 V25 實際末章與 V26 接續章號；核目錄、正文、定理例題、引用與書籤。正文保留單一版本。官方模板已取回解壓；三樣式與官方及V25逐位元一致。現階段尚未收到整合正文與其PDF，相關結果均 PENDING。

KEEP：既有已核內容與正式模板。版面 L 可修局部環境；非語義 E 必須留原文/改文/理由；N/M 轉內容角色。不得藉排版刪假設、改量詞、數學表示、證明或必要例題。

## 工程路徑

已實測命令可用：`pdflatex`、`lualatex`、`latexmk`、`pdftoppm`、`pdftotext`、`pdfinfo`；Python `fitz`、`PIL`、`pypdf`、`lxml` 可匯入。實際模板可能指定 XeLaTeX，須待 build.py確定，不預設更換引擎。

1. 比對官方三份 layout/config 與字型、build.py/verify.py/manifest；任何本卷必要 adaptation列明路徑、原hash、改hash、原因，無未列模板改動。
2. 乾淨編譯；核 log 缺字、overfull/underfull、未定義引用、重複 destination；記引擎、字型實際解析、PDF頁數、metadata、bytes/SHA256。
3. 用 PyMuPDF / pypdf 查頁界之外可疑文字、正文與頁腳相交、異常淺色文字、空白頁、內外連結、書籤目的頁。這些只定位，不能替代目視。
4. 來源→PDF的章、標籤、定義/命題/證明/例題標識與必要末尾內容核對；PDF抽取成功不代表畫面可見。

## 全頁閱讀路徑

初審所有頁面依物理頁1到末頁逐序渲染，按可讀尺寸分批呈現；密集公式/異常頁另用高解析完整頁與必要局部放大。每批記頁範圍與觀察，不能把縮圖或抽樣當全頁視檢。

沿章順讀：條件/公式/理由就近、短定義與短題資料完整、長證明續接可辨、短Remark/Why相鄰、圖表與文字近接；檢頁尾與頁碼碰撞、裁切、溢出、孤立標題和跨章重流。自然章末短頁或高密頁不自動判缺陷。不以拉大行距、硬字元上限、批量強制斷頁或整體縮字湊頁數。

每次局部修補後重檢直接單元、前後頁及全部連鎖重流範圍；全域patch須全卷重編視檢。章正文若由內容角色更新，舊PDF與視檢不冒稱仍有效。

## 輸出與下一步

後續輸出 `B06-Layout-QA.md`、同一缺陷表（ID/原文位置/影響/分類/責任/原文→patch/重核證據/狀態）、PDF與來源hash及實際視檢頁域。內容保留、工程、閱讀三項分列。完成只交打厚 B-07，修正仍回打厚複核。

OPEN：B-05正文/來源/PDF尚待接收；正式書稿全頁視檢尚未開始；讀者裝置/理解測試與跨平台效果UNKNOWN。官方ZIP與三樣式已核；V25實際entry與正文ch324已確認，V26 entry從325接續。三頁技術smoke已編譯及視檢，證據見 `v26-book/evidence/B06/Scaffold-Receipt.md`，不冒稱正式書稿視檢。既有V0/V2頁尾重疊是歷史警示，非本卷已發生缺陷，也不授權修舊稿。

送達狀態：已透過協作訊息送出接收摘要；本檔寫入共享工作目錄可供統籌讀取，非宣稱對使用者外部交付或封存。
