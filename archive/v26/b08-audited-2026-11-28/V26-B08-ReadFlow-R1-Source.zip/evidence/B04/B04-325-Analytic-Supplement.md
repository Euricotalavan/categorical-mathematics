# V26 第325章解析性補充交接 v1

V26-B04-325-ANALYTIC-v1 · 2026-11-28 UTC · 擴充 → 主控／獨立複核。
依主控本次明確追加：只在嚴格且有教學用途時補2–4頁解析性／齊次展開或顯式核導數估計。未為湊頁調字型、重複例題或重排模板。

## 固定來源變動

| 來源 | bytes | SHA256 |
| --- | --- | --- |
| 本章前一B04作者固定稿 | 51,635 | `1b61d16c79390169eaa0f85b9022bcbad5d981c6647d110c8115daefe0a6f612` |
| 新增解析性初稿（獨立reviewer完整讀入） | 60,959 | `1ccc08349046d3e794135748c9d14066170480ea58199a60d9e7a7d9b7f853ab` |
| 目前最終作者副本 `v26-drafts/ch325.tex` | 61,392 | `c1ac9b4b1bcb50adf9a95759df756c03268bd7a0f5e9b357c79d64642f5256b7` |

第一個固定稿的所有定理label及證明原樣保留；在可去奇點節後、完整解題節前新增 `sec:325-analytic`（實際第325.8節），原完整解題移為第325.9節，仍16題。新稿共9主節、59個不重複label，所有本章ref/eqref可解。原B04 handoff的數學落點仍有效，只有解題節號8→9；本補充追加B01 325-08的新解析性責任。

## 新增推導與實際落點

| label | 實際內容與必要條件 |
| --- | --- |
| `thm:325-analytic`／`eq:325-homogeneous-expansion` | 固定閉球B(a,R)緊含harmonicity域，q=|z|/R≤1/4。Poisson kernel binomial展開以2q+q²≤9/16控制；absolute homogeneous／coordinate-monomial sums皆有共同majorant，可積分及按degree重組。每H_m只有有限k來源。沿ray使用一維power-series微分識別Taylor係數，避免把單純uniform convergence當成可座標微分。 |
| `eq:325-series-majorant`／`eq:325-homogeneous-bound` | C_n=(17/16)(16/7)^(n/2)與M=maxsphere|u|給Σ|H_m((R/4)e)|≤C_n M。另明列Σ_i|z_iθ_i|≤|z|，保完整multivariable monomial絕對收斂。 |
| `cor:325-analytic-estimates` | 任意unit e的m階方向導數≤m! C_n M(4/R)^m；r<R/4上的Taylor尾≤C_nM(4r/R)^(N+1)。uniform radius與quantitative remainder明列。 |
| `cor:325-unique-continuation` | 全部multi-derivatives為0的集合closed，由local expansion使其open，connected domain給zero-jet／open-set唯一延拓。 |
| 兩個完整例 | Re(z^m)顯示任意finite jet不足；Re[1/(1−z)]幾何級數顯示實際radius可大於保守R/4，同時鄰近singularity阻止任意擴張。n>2例只用與額外座標無關的同一polynomial。 |

每個H_m harmonic以有限Taylor polynomial直接計算ΔH_m=Σ D^β(Δu)(a)z^β/β!；使用本章已證C∞，沒有靠未證級數二階微分。零polynomial允許作任意degree的齊次term，避免恆常函數的高degree零項型別不清。

## 獨立重核與工程狀態

主控派另一獨立作者middle完整讀入1ccc0834稿，已回訊主定理證明核過，並提出兩項細化：(1) coordinate-monomial absolute majorant明列Cauchy–Schwarz；(2) Poisson公式boundary y與Green interior-pole y的角色分開，observer x固定。兩項均採入最終c1ac9b4b稿。完整讀稿後另有三個僅文字delta：零polynomial定義、上述majorant細化、上述角色澄清；已把exact change及finalhash發reviewer待其最終接收紀錄。主控可據其獨立回執判定B04追加範圍，不把作者自核代簽。

最終c1ac9b4b hash工程編譯完成：`v26-book/.build/draft325-analytic-expand/volume26.pdf`，168,362 bytes，SHA256 `1e2faa9bd9d142c2ab116bf7796e8801be91188b7ee14168323cd935bd4207c8`；28頁（含書目），2 passes，diagnostics=[]，build-report來源hash與作者副本一致。較先前23頁增加5頁，包含4個理論結果與2個完整例；未改字型／leading湊量。此前1ccc/0983ca版編譯不充當本版配對證據。未做正式B06逐頁視檢、不代B05/B07整卷通過。

來源：推導完全基於本章已證球Poisson核及標準binomial power series（本節亦給係數、ratio-test與scalar ODE辨識），原創呈現。R1 Ch1 real-analyticity／homogeneous expansion和S1 §1.10供定位，未抽取copy-disabled R1文本。R2/R3原書UNKNOWN不變。

下一唯一動作：主控收獨立reviewer的最終delta回執與c1ac9b4b配對PDF工程證據，再按原B04合稿流程接受本新增責任；只在發現問題時有界回修。禁止改動已審326/327、其他作者文件、工具／總表、凍結卷或正式模板。無新增使用者決策需要；模型及High實際設定未核實。資料由主控收入授權快照，發送不等於讀入。
