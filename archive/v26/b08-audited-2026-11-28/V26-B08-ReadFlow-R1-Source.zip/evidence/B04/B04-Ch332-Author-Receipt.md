# V26 Ch332 author handoff

B04 · controller's chapter task · Chapters 325–332 remain fixed. The unique released draft for this chapter is `v26-drafts/ch332.tex`, 63,919 bytes, SHA-256 `a4882905a821d856115c0b31ba363c701cef9d45956893e86070c6df62abec75`. All mathematical statements and examples are original expositions of established methods. The fixed written interfaces were B01 source coverage, the B02 variational interface, the authoring conventions and the B03 proof-depth receipt. Recheck if a dependency changes.

| B01 item | Worked location and concrete evidence |
|---|---|
| 332-01 | Sections 332.1–3, weak identity and exact a.e. type, Proposition `thm:332-weyl`, smooth forcing corollary. |
| 332-02 | `def:332-h1`, `prop:332-h1-complete`, `def:332-h10`, `lem:332-zero-boundary-ball`, `prop:332-poincare`, and the corner/jump notes. |
| 332-03 | `prop:332-disk-energy`, `thm:332-disk-trace`, collar inequality, density via inward dilation, Fourier range and zero trace kernel on the disk. General trace theory remains outside the proof. |
| 332-04/05/06 | `def:332-weak-problem`, `thm:332-minimum`, trial and stability proofs, and the H⁻¹ extension. Hilbert representation and completion of the square prove existence, uniqueness and the converse. |
| 332-07 | `thm:332-weyl` uses the independently supplied proof at `lem:329-weyl`; `cor:332-smooth-forcing` proves the reduction by a localized fundamental solution. |
| 332-08 | `thm:332-green-agreement` proves smooth compact forcing on balls gives the variational solution and absolute double integral. `prop:332-green-l2` and `ex:332-l2-threshold` determine the dimension threshold for pointwise L² kernel pairing. |
| 332-09 | `prop:332-classical-agreement` and `ex:332-poly-extension` prove the ball overlap. `thm:332-disk-trace` extends it to finite-energy continuous disk data. |
| 332-10 | `eq:332-green-energy`, direct link to the free-space calculation `prop:329-smooth-energy`, shell energy linked to relative Green-capacity `thm:329-green-capacity`. The functional's factor one-half differs from both conventions. |
| 332-11 | Constant versus zero boundary class (332.1), `ex:332-lacunary`, `prop:332-puncture`, point mass test and `ex:332-point-data`. Worked problems differentiate scaling, traces, source types and normalization. |
| 332-12 | The chapter source guide points to the exact Ivrii pages after using independent proofs. No reliance on the questionable source formulas. |

Symbolic checks verified radial power and logarithmic Poisson expressions, exact flux for the (nge3) shell and constant-forcing energy arithmetic. The integration reviewer checked first and second draft hashes, including the disk trace correction, the dual and the dimension-four threshold. Editor fixes after (d3970725) link a previously proved Green boundary corollary, localize (L), and clarify two examples without changing their calculations. No full book acceptance is represented by this handoff.
