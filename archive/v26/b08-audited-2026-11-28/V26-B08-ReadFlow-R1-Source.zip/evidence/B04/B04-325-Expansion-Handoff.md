# V26 第325章 B04 擴充交接 v1

交接ID V26-B04-325-EXPAND-v1 · 2026-11-28 UTC · B單一Work
發送：擴充獨立任務 → 主控 → 打厚／精修獨立核查。

已收主控 B04 release，實讀 `B01-Source-Coverage.md` 最終37,707 bytes、SHA256 `77c5f345ab3d250b405d6057bdee542ccbb0414200ff672d355e51140a8aac6d`；`B02-Controller-Release.md`、`B03-Calibration-Receipt.md`、`Authoring-Contract.md`，接受本章325及其共同符號、唯一主稿和不越權限制。模型及High實際設定未獨立核實。

## 可取來源與工程證據

| 用途 | 實際路徑／版本 | bytes／SHA256 |
| --- | --- | --- |
| 章作者副本（待獨立審核） | `v26-drafts/ch325.tex` v1 | 51,635；`1b61d16c79390169eaa0f85b9022bcbad5d981c6647d110c8115daefe0a6f612` |
| 固定整卷設計 | `v26-stage/B02-Design.md` v1 | 36,044；`9c54c48a6866c88c42dacc8c45f14d7ea6dc396dee7e228de3d13b0b74c11783` |
| 作者契約 | `v26-stage/Authoring-Contract.md` | 3,632；`a225e902f228e64af1d9e289c449775dae4738797dad458ac1d825a2dac271e6` |
| B03接收紀錄 | `v26-stage/B03-Calibration-Receipt.md` | 2,400；`9c07b588909b32975413616ebd0c260748724f885a51f9148c7c0221e159bade` |
| 本章工程PDF（非正式B06） | `v26-book/.build/draft325-expand/volume26.pdf` | 147,738；`9f8eba52b56d7fcec141e6c3ff9876d66414b28ceecf95ce61eaa1cc655ef2fb` |
| 同版建置紀錄 | `v26-book/.build/draft325-expand/build-report.json` | 來源hash相符；2 passes；diagnostics=[] |

建置：`python v26-book/tools/build.py --sample "$PWD/v26-drafts/ch325.tex" --chapter-number 325 --name draft325-expand`。使用主控已固定的ReadFlow R1架構／字型依賴，來源未在編譯中變動。此獨立章工程輸出23頁（含書目），零選定阻塞診斷。未做全章逐頁B06視檢；不冒稱正式排版或打厚終審。

本章含8主節、16個不同完整解題、52個不重複label。靜態核本章ref/eqref全部可在本章解出。唯一正文尚待主控接收hash與獨立打厚／精修，作者副本不直接改canonical。

## 原書責任 → 實際正文落點

| B01 ID | 實際節／label與證據 |
| --- | --- |
| 325-01 | 325.1 `sec:325-equation`、`def:325-harmonic`；實值/複值型別、域、C²、Laplacian，常數／線性／跡零二次與非例 |
| 325-02、325-04 | 325.2 `sec:325-means`、`thm:325-mean`；球面半徑微分→通量→0，極座標→體均值；未正規化s_(n−1)與球體積明列 |
| 325-03 | 325.2 `eq:325-green-first`、`eq:325-green-second`；由散度定理推兩恆等式，C¹域／C²鄰域及外法向明列 |
| 325-05 | 325.2 `thm:325-mean-converse`徑向mollifier與Taylor；`prop:325-integrable-means`點態全體積球版本先證連續；325.4 `thm:325-weak-means`連續+每點半徑列，二次擾動比較；325.8 `prob:325-discontinuous-means`完整不連續反例 |
| 325-06 | 325.1相似變換與定義域；325.8 `prob:325-linear-change`證所有harmonic-preserving可逆線性變換恰為相似，單方向拉伸反例 |
| 325-07 | 325.3 `thm:325-maximum`、`cor:325-comparison`；強最大開閉集與弱最大緊level-set；半空間xn；325.8 `prob:325-infinity`補無窮遠假設的證明 |
| 325-08 | 325.2均值逆向證C∞；325.5 `prop:325-gradient`、`eq:325-derivative-estimate`、`thm:325-normal`；實解析性未作主線且無後文偷用 |
| 325-09 | 325.6 `thm:325-harnack`、`thm:325-monotone`；核上下界與有限球鏈，單調差的正性及有限一點/全∞二分；325.5正常族 |
| 325-10 | 325.4 `thm:325-poisson`、`eq:325-poisson-kernel`、`cor:325-poisson-representation`；直接Δ驗算、質量徑向ODE、近遠分割、唯一性，無327/328循環 |

本章額外自含、供下游引用：325.7 `thm:325-removable`及穿孔域失敗例；325.8小o奇點完整證。主線未用分佈／弱導數／一般Green存在；下一章正式次調和代表元與球lift責任仍歸326。

## 來源實讀與自核

Papadimitrakis作者2004公開PDF（hash見B01），實際讀§§1.1–1.3印67–71、§1.9印82–85、§§1.10–1.12印85–92，均值、Poisson、Harnack、梯度／正常族與可去奇點依本章順序自足重證。球Poisson質量採直接徑向調和積分而非先假定表示公式；一列半徑版本用二次擾動比較，不誤用共同卷積半徑。

R1對照定位承B01 Ch1/Ch3；本角色未對copy-disabled Axler PDF執行文字抽取。R2/R3原書未讀狀態原樣保留，不能稱原三書全章已核。

來源差異修正：S1 §1.2 Thm1.1(ii)/Cor1.1字面未充分標bounded，但證明用closure compact；本章明列bounded，無界域需另加infinity。此差異已通知精修。兩個真正次調和代表a.e.等同即逐點等同的議題屬326，本章不寫錯誤反例。

## 下一步與禁止重做

下一唯一階段：主控按本hash送打厚／精修獨立固定稿核查，再合入唯一來源。驗收須核每個責任的條件、量詞、正規化、均值逆向、球核質量及邊界極限、Harnack鏈與單調差證明；所有必要例題有完整解，不以編譯或字數代替語義核查。

OPEN：本章B04獨立打厚／精修尚未完成；配對PDF只有工程檢查、無正式逐頁QA；與326–332章縫、全卷實際來源落點及B05覆蓋尚待主控整合。R2/R3全文UNKNOWN原樣保留。無新使用者決策需要。

相對設計的有界變動：325.5集中估計／正常族，325.6集中Harnack／單調；故實際節ID較設計第5節拆分為兩節，章號與數學範圍不改。所有下游穩定label已傳327–328作者。禁止重做已核preflight／B03，不改工具、總表、凍結稿、模板或其他作者文件；不得將本次作者自核當B05/B07通過。

傳遞：此文案與source已放同Work共享目錄並發主控hash，不等於接收方已讀。由主控合入授權快照保存並重取核驗；本角色不直接發布或封存。B02已固定不等於B07整卷終審。
