# V26 B-04 第 326、330 章打厚交接 v1

交接 V26-B04-THICKEN-326-330-v1 · 2026-11-28 UTC  
打厚 → 精修／主控。V26《Harmonic Functions and Classical Potential Theory》，B 單一 Work。依使用者本卷 B-01–08 授權及主控 B-04 release，完成第 326、330 章的可審查來源副本和工程試編。B-04 對應原 A 04–07 的設計起稿、證明展開與精修銜接。本角色的實際模型與推理模式未獨立核實。

## 基線與實讀回執

前卷末章 324，V25 已發布適用 Git commit `0fb04b259609ceb1554d7b714249e792b6f90ff6`，路徑 `README.md` 與 `archive/v25/b08-audited-2026-11-28/README.md`。本卷依 B-02 固定 325–332。分卷／文獻表 revision `v4.1-interface-and-open-coverage-review`，兩表指紋由 `V26-References-Preflight-v1.md` 記錄。實際讀入設計的第 326／330 章、共同介面、B-01 的相應責任和限制。採用下列可讀固定工作區檔案。

| 用途 | 檔案及版本 | bytes | SHA-256 |
| --- | --- | ---: | --- |
| 文獻責任 | `v26-stage/B01-Source-Coverage.md` v1 | 37,707 | `77c5f345ab3d250b405d6057bdee542ccbb0414200ff672d355e51140a8aac6d` |
| 原書版本與取用 | `v26-stage/B01-Source-Fixation.md` v1 | 3,776 | `4175b6322039c69c769563db75df5819ccdde4f3fcd6eebd3dfc0ff9017b2e34` |
| 敘事與依賴 | `v26-stage/B02-Design.md` v1 | 36,044 | `9c54c48a6866c88c42dacc8c45f14d7ea6dc396dee7e228de3d13b0b74c11783` |
| Green／Perron 介面 | `v26-stage/B02-Green-Perron-Interface.md` | 3,373 | `8dc4d035c5f36172ae5c32d35e5fcbf5cc4352911048165127a0ff8af81ea5b2` |
| 定界／開工 | `v26-stage/B02-Controller-Release.md` | 2,870 | `e4e3982791fd0293dd9cc9c92cbc265157592defad9cac0e7aa0c63389a577ca` |
| 校準固定 | `v26-stage/B03-Calibration-Receipt.md` | 2,400 | `9c07b588909b32975413616ebd0c260748724f885a51f9148c7c0221e159bade` |

R1 採 Axler、Bourdon、Ramey 第 2 版作者電子版（2020-07-17）。作者正文查讀第 11 章次調和／Perron 的選用段落，以及 6.39、6.42、6.44、7.28–7.30 的各條件。S1 採 Papadimitrakis 2004 作者公開筆記，配合檢核第 2 章半連續、比較、平均、Poisson modification、分布與 Riesz，以及第 8–9 章容量、極集和 Wiener 的已定位內容。工作引用範圍詳 B-01。R2／R3 正文可讀性仍列 UNKNOWN。

## 可取產出及核驗

| 用途 | 檔案 | bytes | SHA-256／實核 |
| --- | --- | ---: | --- |
| 第 326 章 B-04 版 | `v26-drafts/ch326.tex` | 55,478 | `2d1f67329ff519a34023e01b272baa458e01cd764c6fed6368f81d6e53984be6`。已確認 12 組完整題解和關鍵介面標籤；章級獨立複核回報無數學必修。 |
| 第 326 章配對試編 | `v26-book/.build/b04-326/volume26.pdf` | 151,781 | `4c118563edcb02a1cacc902c36483d2d6e1a5956ed64a011c902a96e047f0829`。23 物理頁，含書目；報告同目錄 `build-report.json`。 |
| 第 330 章 B-04 版 | `v26-drafts/ch330.tex` | 49,459 | `996dbb3beac273581fe31b6a9f16199c212aa60a86bf8b676f43821e58534036`。已確認 12 組完整題解；該章源碼跨章標籤已在八章檔案中核到。 |
| 第 330 章配對試編 | `v26-book/.build/b04-330-fixed/volume26.pdf` | 145,846 | `2268d6bdd4a5cf67ed8566b6bd6c7f1e6597eec425726971c69e9e5335855984`。21 物理頁，含書目；報告同目錄 `build-report.json`。 |

兩次樣本 XeLaTeX 編譯各兩輪。指令分別為 `python v26-book/tools/build.py --sample v26-drafts/ch326.tex --chapter-number 326 --name b04-326 --allow-diagnostics` 與 `python v26-book/tools/build.py --sample v26-drafts/ch330.tex --chapter-number 330 --name b04-330-fixed --allow-diagnostics`。正式模板基線為 ReadFlow R1，Library v3，artifact Git `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，ZIP SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。本階段使用主控 scaffold 的模板、字型、XeLaTeX harness、136mm 行寬和英文章節，不由本角色修改樣式。精修歸併後由主控重新配對唯一正式全文。

| 第三篇核驗層 | 本次結果 |
| --- | --- |
| 內容保留 | 配對報告記入各固定來源 SHA-256，已核章號、引用標籤和題解數。逐節責任的正文落點見下表。 |
| 工程 | 選定診斷只有單章試編未載入其他章造成的交叉引用警示。整卷編譯需實際驗證交叉引用、字型和內容未裁切。 |
| 連續閱讀 | 本角色已重讀兩章 TeX，獨立複核狀態見下。整卷頁面視檢屬 B-06，樣本頁數不是語意或版面驗收。 |

## 覆蓋落點與後續依賴

| B-01 責任 | 正文落點 |
| --- | --- |
| 326-01／02 | `def:326-subharmonic`、`ex:326-quadratic`、`ex:326-point-change`。 |
| 326-03／04 | `lem:326-local-comparison`、`thm:326-comparison`、`cor:326-strong`、`cor:326-smooth`。 |
| 326-05／06 | `thm:326-integrability`、`prop:326-recovery`、`prop:326-max`、`thm:326-envelope`、`ex:326-envelope`。縮小球平均恢復全部點值，給 a.e. 同類唯一性。 |
| 326-07／08 | `lem:326-gluing`、`thm:326-lift`、`ex:326-lift-quadratic`、`prop:326-smooth-approximation`。Perron 接口採有限連續子類；提升定理亦證擴充實數類。 |
| 326-09／10 | `def:326-distribution`、`thm:326-distribution`、`thm:326-positive-functional`、`thm:326-positive-distribution`、`cor:326-riesz-measure`、`ex:326-log`、`ex:326-powers`。正泛函表示供 328 調和測度，分布符號與正測度則供 327／329／332。 |
| 328-08、330-01／02 | `sec:330-which-limit`、`sec:330-local`、`thm:330-exterior`、`cor:330-lipschitz-convex`、`cor:330-cone-rate`。Lipschitz／C²、凸域、外球外錐皆明證，並給控制 Green 函數零邊界極限的估計。 |
| 330-03／04／06 | `sec:330-differentiation`、`def:330-lebesgue-point`、`lem:330-differentiation`、`lem:330-half-kernel`、`thm:330-half-fatou`、`thm:330-ball-fatou`、`thm:330-ball-representation`、`thm:330-bounded-fatou`。半空間全局有界古典唯一性由 331 接續。 |
| 330-07／09／10 | `thm:330-polar-potential` 回用 329 的已證構造，`cor:330-polar-comparison` 證緊集移除及外容量零的 Borel 調和測度結論。例題 `ex:328-puncture`、`ex:330-segment`、`ex:330-atom`、`ex:330-tangential`，另有圓周 Cantor 弧容量、資料代表與半空間 \(u=t\) 的討論。 |
| 330-05／08／11 | Local Fatou (R1 7.30)、Wiener (S1 §9.8) 及完整 Kellogg 結果依 B-02 列可追查的進階閱讀。R2／R3 的正文項目保留 UNKNOWN。 |

本次更動由代表節的暫用符號轉入正式章號、固定共同介面和完整章節。第 328 章已有局部障礙與穿孔球，第 329 章已有極集位勢構造，第 330 章對相關結果引用並建立新的幾何估計和邊界比較。兩件樣本 PDF 分別配對上述兩份作者章稿，均非正式合稿。上游正式正文、分卷／文獻表、工具、共用模板、凍結卷範圍均由原責任角色管理。

**OPEN／UNKNOWN**　B04-OPEN-326-330-01，330 獨立複核已送精修，交接書寫時待正式回執，影響該章的合稿簽核。B04-OPEN-326-330-02，兩章試編的跨章警示由主控整卷編譯時測試，B-06 接實際整卷視檢。B01-UNKNOWN-R2/R3，合法可讀全文仍待來源階段；保留本次實讀範圍與引用身份。待使用者決策無新增。

**唯一下一步**　精修對第 330 章固定 hash 獨立回執，主控依第 326、330 章各自的回執核入唯一主稿。之後交 B-05 以整卷順讀核責任和章縫，不重做已核的章級證明與來源定位。內容變動才核受影響依賴，排版後仍交獨立打厚 B-07 對固定整卷及配對 PDF 終審。

**傳遞狀態**　兩份 TeX 路徑、hash、覆蓋落點與工程結果已經 Work 角色訊息送主控。第 326 章獨立數學複核已回報。第 330 章精修已回執首版並確認收件，最終 hash 的複核回執另記。正式持久化與後續跨階段入口由主控整合。
