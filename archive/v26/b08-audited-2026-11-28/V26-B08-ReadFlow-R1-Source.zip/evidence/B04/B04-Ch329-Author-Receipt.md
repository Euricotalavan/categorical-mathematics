# V26 B-04 chapter 329 author handoff

**Handoff V26-B04-329-v1 · 2026-11-28 Asia/Taipei**  
Chapter author (擴充) → controller and independent B-04 proof/precision reviewers. V26 *Harmonic Functions and Classical Potential Theory*, Chapter 329 *Energy and Capacity*. B single Work authorized across B-01–08. B-04 corresponds to the original A draft, proof expansion, and refinement phases. This handoff supplies the single chapter draft at the controller-assigned path. Integration, refinement and final release are downstream. The actual model configuration and reasoning mode were not independently verified.

**Read and fixed.** Applicable curriculum/reference revisions are `v4.1-interface-and-open-coverage-review`. Published V25 ends at Chapter 324 on Git commit `0fb04b259609ceb1554d7b714249e792b6f90ff6`, `archive/v25/b08-audited-2026-11-28/README.md`; V26 is Chapters 325–332. The author read `V26-References-Preflight-v1.md`, `v26-stage/Authoring-Contract.md` (SHA-256 `a225e902f228e64af1d9e289c449775dae4738797dad458ac1d825a2dac271e6`), `B01-Source-Fixation.md` (`4175b6322039c69c769563db75df5819ccdde4f3fcd6eebd3dfc0ff9017b2e34`), `B01-Source-Coverage.md` (`77c5f345ab3d250b405d6057bdee542ccbb0414200ff672d355e51140a8aac6d`), `B02-Controller-Release.md` (`e4e3982791fd0293dd9cc9c92cbc265157592defad9cac0e7aa0c63389a577ca`), the Green/Perron and variational design interfaces, and `B03-Calibration-Receipt.md` (`9c07b588909b32975413616ebd0c260748724f885a51f9148c7c0221e159bade`). Chapter 329 imports the positive-functional representation and superharmonic theory from Chapter 326 and the fundamental solution and symmetric ball Green kernel from Chapter 327. The Weyl lemma, local Riesz decomposition, and normalized capacities are available to later chapters by stable labels.

## Manifest and coverage

| Item | Version, access and verification |
|---|---|
| Chapter 329 TeX | `v26-drafts/ch329.tex`, controller/author shared Work path. 61,006 bytes, SHA-256 `fe7d10fbdeab4a4b8865935bd3d9a0d250a6daba5e12b681527a2d3960a8e69f`. Independently derived proofs and 13 original solved exercises. |
| Main author source S1 | Mihalis Papadimitrakis, January 2004 notes, 917,506 bytes, SHA-256 `c7263d587ed6ad1880e6978a88a43af6b6452a3f2351ac4ebc587edd73788d51`. Author read the relevant sections from the fixed source. [Author PDF](https://fourier.math.uoc.gr/~papadim/potential_theory.pdf) |
| Main author source S2a | Oleg Ivrii, *Potentials and Energy*, 11/09/2020, 332,383 bytes, SHA-256 `bb0356f5d6b727ed96a5a25aba667fe1b45aa143b4a98a557d3ac4611ed1352b`. Relevant slides 11–14 and 61–64. [Author PDF](https://www.math.tau.ac.il/~ivrii/potential_theory/week4a.pdf) |
| Index / coverage | B-01 source table above. Ch329 mapping below. No copied reference text is part of the draft. |
| Layout baseline | Official V0 ReadFlow R1 Library v3, artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, ZIP SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`. Chapter uses the existing V26 portable XeLaTeX scaffold and no chapter-local formatting definitions. [Fixed asset commit](https://github.com/Euricotalavan/categorical-mathematics/commit/8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3) |
| Isolated PDF and compile | See verification addendum below. The authoritative paired full-volume PDF is still to be generated in B-06. |

| B-01 responsibility | Chapter 329 location and evidence |
|---|---|
| 329-01 kernel and energy | `def:329-potential`, `def:329-energy`: point and product bounded-below shifts, local integrability, atom diagonal mass, Tonelli. |
| 329-02 concrete kernel scope | `sec:329-potentials` and `def:329-green-capacity`: normalized free-space versus ball Green. A general classification was not used. |
| 329-03 lower semicontinuity | `lem:329-weak`: weak compactness, product tests, continuous truncated kernels, monotone convergence. |
| 329-04 minimum and existence | `def:329-compact-capacity` and `thm:329-equilibrium`: positive capacity equivalent to some finite-energy probability, minimizing subsequence, infinite case separately stated. |
| 329-05 finite mutual and strict uniqueness | `lem:329-gaussian`, `thm:329-energy`, `thm:329-equilibrium`: absolute variation domination, Gaussian representation, signed zero-mass condition for log, strictness by approximate identity, midpoint uniqueness. |
| 329-06 Newtonian capacity | `def:329-compact-capacity`, `sec:329-examples`, `thm:329-ball-capacity`: reciprocal convention, normalization and scaling. The general bounded-potential supremum equivalence remains outside this proof scope. |
| 329-07 logarithmic capacity | Same definition and examples section: conversion to PDE energy, dilation, unit-circle integral and exact planar segment formula. |
| 329-08 relative Green capacity | `def:329-green-capacity`, `prop:329-green-positive`, `thm:329-green-capacity`: compact subset of ball, signed positivity, existence, shell formula and outer-radius checks. |
| 329-09 inner/outer capacity and q.e. | `def:329-outer`, `prop:329-outer`: positive proxy for planar logarithm, compact consistency, countable subadditivity and null-mass consequence. General Borel capacitability is outside the proof scope. |
| 329-10 equilibrium potential inequality | `prop:329-variation`, `thm:329-equilibrium-level`: q.e. lower inequality, measure-a.e. equality, upper level on support, boundary concentration. The global upper domination theorem is outside the proof scope. Exercise 329.7 is an exact q.e. exception. |
| 329-11 polar compacts | `def:329-polar`, `thm:329-polar`: both directions, using truncations and local Riesz decomposition. Exercises give an uncountable Newtonian null segment and a countable null set. |
| 329-12 calculations | `prop:329-shell`, `thm:329-ball-capacity`, `ex:329-segment`; singletons at Section 329 Sizes of conductors; concentric Green shell under `thm:329-green-capacity`. |
| 329-13 smooth energy link | `prop:329-smooth-energy`, `prop:329-green-positive`: normalized whole-space smooth identity and ball Green identity, with planar zero-charge hypothesis for the former. Exercise on nonzero charge gives a divergent-gradient counterexample. The Sobolev variational comparison proceeds in Chapter 332. |
| 329-14 original sources | R2 and R3 remain UNKNOWN for the body pages and their individual proof and exercise coverage. |
| Local Riesz prerequisite | `lem:329-weyl`, `thm:329-riesz`: local integral smoothing, recovery of pointwise representative, restricted finite measures reaching the ball boundary, greatest harmonic minorant from vanishing spherical means. S1 pp. 122 and 169–172. |

**Open.** `OPEN-329-REVIEW` Independent B-04 reading of this fixed source and integration into the one canonical manuscript are pending, owned by controller and the separate reviewers. Recheck hypotheses, proof chains, source locators and downstream dependencies before B-05. `OPEN-329-PDF` Full-volume source/PDF pairing, ReadFlow reading and final review stay at B-06 and B-07. `UNKNOWN-329-ORIGINALS` R2/R3 unread proof and exercise coverage as in B-01. No additional user decision is required for the fixed execution scope.

**Next intake.** Controller and separate mathematical reviewers verify the identical source hash, author scope, and actual read receipt. Review first variation, polar proof and normalization, check both Green steps against Chapter 327, and preserve the necessary proof steps in any precision edit. Record fixes as a patch on the single chapter file and retest only affected proof and layout. No action on frozen volumes, reference originals, curriculum or template, and no external publication. Author sends the path and hash within this Work. Controller intake and patch decisions have their own evidence.

## Verification addendum

Command: `python v26-book/tools/build.py --sample "$PWD/v26-drafts/ch329.tex" --chapter-number 329 --name ch329-initial`, run from the Work root. The ReadFlow R1 scaffold paired the source hash above with `v26-book/.build/ch329-initial/volume26.pdf`, 165,833 bytes, SHA-256 `fe4f559eb3a314332410eb9934849905233e4dacac7b774bd1acaefdb47be596`. Two XeLaTeX passes. The build report lists zero selected diagnostics. The PDF has 25 chapter pages and one bibliography page. The author checked all page-level thumbnails for dense or broken blocks, visible carryover, and the exercise section, and confirmed the rendered numbering ends at Exercise 329.13. B-06 still owns detailed page legibility and final paired-volume checks. No final mathematical disposition is asserted here.
