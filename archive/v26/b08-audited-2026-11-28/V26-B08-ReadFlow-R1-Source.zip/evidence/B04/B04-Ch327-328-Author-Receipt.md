# V26 B-04 · 第 327–328 章作者交接

V26-B04-327-328-AUTHOR-v1 · 2026-11-28 UTC · 章級正文子任務 → 主控和精修。卷名 Harmonic Functions and Classical Potential Theory，B 單一 Work，第 325–332 章，本文工作限第 327–328 章。模型與推理模式未獨立核實。

## 固定版本

| 用途 | 可取檔案、Bytes 與 SHA-256 |
| --- | --- |
| 第 327 章 Green Functions | v26-drafts/ch327.tex · 49,674 · 6119c40755089810bd88bdc1e45c051b54b8eda767a7964238f229e23914e681 |
| 第 328 章 The Dirichlet Problem | v26-drafts/ch328.tex · 46,928 · c584efaa9bade2e11bc699321ceea0f72404f5387c5fe5b8c5438a165158274d |
| 第 327 章工程樣本，20 頁 | v26-book/.build/middle-327/volume26.pdf · 145,122 · 8657b91c3a943f14d0431ea3201805eef68bb2d98398a3733daec8f40630c195 |
| 第 328 章工程樣本，20 頁 | v26-book/.build/middle-328-fixed/volume26.pdf · 136,656 · da799bb6e10629619579c1b467f5d737e35ec0b0764c0e313c614626c982be6d |
| B-01 公開來源責任表 | v26-stage/B01-Source-Coverage.md · 37,707 · 77c5f345ab3d250b405d6057bdee542ccbb0414200ff672d355e51140a8aac6d |
| B-02 主控放行與章間介面 | v26-stage/B02-Controller-Release.md · 2,870 · e4e3982791fd0293dd9cc9c92cbc265157592defad9cac0e7aa0c63389a577ca。v26-stage/B02-Green-Perron-Interface.md · 3,373 · 8dc4d035c5f36172ae5c32d35e5fcbf5cc4352911048165127a0ff8af81ea5b2 |
| B-03 代表 Perron 小節校準 | v26-stage/B03-Calibration-Receipt.md · 2,400 · 9c07b588909b32975413616ebd0c260748724f885a51f9148c7c0221e159bade |
| 固定 R1 模板 | v26-inputs/V0-ReadFlow-R1-Source.zip · 7,007,679 · 5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732。Library v3，Git artifact commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3 |

前卷末章 324，依該卷 Git commit 0fb04b259609ceb1554d7b714249e792b6f90ff6 的 V25 封存入口。本卷分卷表以 B-01 紀錄的 v4.1-interface-and-open-coverage-review 為準。章級工程樣本使用 v26-book/tools/build.py 的 --sample 參數與 ReadFlow R1 原樣版式，XeLaTeX 兩輪。單章只有跨章引用尚未定義的預期警示，無溢出版面及缺字診斷。樣本各自對應上表正文 SHA-256，整卷配對、三層排版檢查及顯示審核待 B-06。

## 內容及變動

- 327-01、02 的單位源與自由空間光滑密度落 sec:327-fundamental，緊支撐一般正測度的兩個自由空間核及能量落 Ch329。327-03、04、07 落 sec:327-correction、sec:327-ball 及 sec:328-general-green。327-05、06 落 sec:327-exhaustion。327-08 落 sec:327-potentials。327-09 的球上 Green 平均界落 lem:327-ball-green-mean，分解落 Ch329。327-10 落 sec:327-boundary。章末 14 題完整解答。Axler 第 2 版 9.1–9.2，Papadimitrakis §§5.1–5.6、5.8–5.10 可核。
- 328-01、02 落 sec:328-families，03 落 sec:328-harmonic-envelope，04 落 sec:328-resolutivity 並核連續族與擴充族同值。05 落 sec:328-families、sec:328-harmonic-measure。06、07、09 落 sec:328-regularity，08 的一般外球、外錐與圖形／凸域推論落 Ch330，10 落 sec:328-harmonic-measure。章末 15 題與一般有界域 Green 補節完成。Axler 第 2 版 Ch11，Papadimitrakis §§3.1–3.4、3.6–3.7、5.2、5.5–5.6 可核。
- 第 327 章獨立審查 v26-stage/B04-326-327-Review.md 已實讀，核同一固定稿無必修項。第 328 章依 v26-stage/B04-Ch328-Independent-Review.md 修訂。R01 將錯列為次調和的負 Laplacian 範例改為單一邊界點的對數函數，核 Δ=(n−2)/|x−ξ|²≥0 且 v≤min f。R03 明定 C_b 值域，R04 以正 Radon 測度唯一性證比較，R05 明列對角線的擴充值與分布代表，R06 補例題的邊界點型別。R02 的兩個幾何推論可在 Ch330 cor:330-lipschitz-convex 核。

## 未決與唯一下一步

B04-327328-O1 為第 328 章最後小修的獨立重核回執，影響其合稿指紋，由原審查人／主控對照修文及目前檔案。B04-327328-O2 為 Armitage–Gardiner、Ransford 原書內容、版本與完整覆蓋 UNKNOWN，由精修在 B-05 保留。公開來源可證主線已寫成，原書責任維持。B04-327328-O3 為整卷 PDF 跨章引用、版面、配對與實頁視檢，待 B-05／06。

唯一續接為主控收兩份 SHA-256 固定正文與各獨立回執，核受改動的位置後合入唯一稿，精修核 326→328、327→329、328→330／332 的引用、記號與實際覆蓋。不可重做已核文獻預檢、章號、工具或凍結舊卷。無待使用者決策。正文、雜湊及回修內容已送主控，收件及可恢復合稿關聯由主控回執。
