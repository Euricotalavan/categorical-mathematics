# Clean recovery check

XeLaTeX recompiled the final source, layout, tools and fonts from a fresh directory, without prior build caches. The two build reports have the same eight source digests and no selected diagnostics. The final reading edition and the fresh rebuild both have 196 pages and 903486 bytes. They match for every 144-ppi page raster, text and link, page label, and bookmark. Replacing only the PDF trailer document IDs makes the two byte strings equal. The delivered source package preserves the original accepted PDF and its raw file hash.

Build: `python3 tools/build.py --full --name b08-clean-recovery`.

Compare: `python3 tools/compare_pdf_pair.py accepted.pdf rebuilt.pdf report.json` (PyMuPDF dependency).
