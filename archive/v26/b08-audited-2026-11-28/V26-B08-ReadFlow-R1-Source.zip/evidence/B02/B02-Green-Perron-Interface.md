# B-02 · V26 Green 核、Perron 解與容量記號

適用第 327–332 章。第 325–326 章提供球上 Poisson 公式、最大原理、Harnack 收斂、次調和提升與超調和超平均工具。以下為 B-02 範圍與介面，供各章作者與精修共同查核。

| 對象 | 固定約定 |
| --- | --- |
| 基本解 | \(n\ge 2\)，\(s_{n-1}=|S^{n-1}|\) 為單位球面的面積。\(\Phi(z)=|z|^{2-n}/[(n-2)s_{n-1}]\)（\(n\ge3\)），\(\Phi(z)=(2\pi)^{-1}\log(1/|z|)\)（\(n=2\)）。分布等式為 \(-\Delta\Phi=\delta_0\)。 |
| Green 核 | \(G_\Omega(x,y)\) 的 \(x\) 是觀察點，\(y\) 是極點。\(-\Delta_xG_\Omega(\cdot,y)=\delta_y\)。在有連續邊界值解的有界域，\(G_\Omega(x,y)=\Phi(x-y)-h_y(x)\)，其中 \(h_y\in C(\overline\Omega)\) 為調和函數，邊界值等於 \(\Phi(\cdot-y)\)。第 327 章以球的 Poisson 解和影像公式給出早期實例，並證正性、單調性及對稱性。對稱性用凸截斷與局部積分，無須將區域邊界假設為光滑。 |
| Perron 解 | 有界域 \(\Omega\subset\mathbb R^n\)，\(f\in C(\partial\Omega;\mathbb R)\)。下類由 \(\Omega\) 上有限連續次調和函數 \(v\) 組成，且每個 \(\xi\in\partial\Omega\) 都滿足 \(\limsup_{x\to\xi,\,x\in\Omega}v(x)\le f(\xi)\)。上類為負號下類，對應資料 \(-f\)。第 328 章證共同包絡 \(H_\Omega[f]\) 調和，為正線性收縮且保常數，並由 Radon–Riesz 表示在 \(C(\partial\Omega)\) 上定義機率測度 \(\omega^x_\Omega\)。 |
| 邊界正則點 | \(\xi\) 正則意指每個 \(f\in C(\partial\Omega)\) 的 \(H_\Omega[f](x)\) 在 \(x\to\xi\) 時收斂至 \(f(\xi)\)。全域障礙 \(b_\xi\in C(\Omega)\) 有限非負、超調和、在 \(\xi\) 趨向零，並在 \(\Omega\setminus B(\xi,r)\) 上（若非空）有正下界。第 328 章證全域障礙與正則性等價，亦證局部有限連續正超調和障礙足夠。第 330 章使用幾何條件與定量估計。 |
| 正常導數 | \(\nu_\xi\) 為 \(\Omega\) 的外單位法向量，\(\partial_{\nu_\xi}G_\Omega(\xi,y)\) 作用於第一變數，於平滑且足以使正常導數公式成立的假設下，\(-\partial_{\nu_\xi}G_\Omega(\xi,y)\) 為 \(\mathrm d\omega^y_\Omega/\mathrm dS(\xi)\)。每處公式明列域與函數的正則性。 |
| 不正則域上的 Green 核 | 第 328 章先建立 Perron 解後定義 \(G_\Omega(x,y)=\Phi(x-y)-H_\Omega[\Phi(\cdot-y)|_{\partial\Omega}](x)\)。單點消失由障礙判定，不能對任意邊界點預設。利用 Perron 解是 \(\Phi(\cdot-y)\) 的最大調和下界證正性、對稱性及域單調性。 |
| 能量及容量 | 第 329 章 Newtonian 核取 \(\Phi\)（\(n\ge3\)），容量為機率測度最小能量的倒數，半徑 \(R\) 閉球容量為 \((n-2)s_{n-1}R^{n-2}\)。平面對數核取 \(\log(1/r)\)，容量為最小能量的負指數，半徑 \(R\) 閉圓盤容量為 \(R\)。平面 PDE 勢依基本解多一個 \(1/(2\pi)\)。以局部 Riesz 分解、有限能量平衡測度與一階變分為主。Wiener 容量判準、Kellogg 定理及一般 Frostman 支配原理沒有列入證明範圍。 |

參看 Axler–Bourdon–Ramey，第 2 版，第 191–193、226–233 頁；Papadimitrakis，§§2.11、3.1–3.4、3.6–3.7、5.1–5.10、7.2–7.3、8.1–8.2、8.5；Ivrii，*Potentials and Energy* 講次。R2、R3 指定原書的逐項覆蓋狀態沿用 B-01 紀錄。
