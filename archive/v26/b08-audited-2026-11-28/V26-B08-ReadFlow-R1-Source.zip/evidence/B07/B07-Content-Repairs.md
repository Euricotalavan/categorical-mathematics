# V26 · B07 returned content repairs

V26-B07-CONTENT-REPAIR-v1 · 2026-11-28 UTC · responsible content editor → controller / independent B07 reviewer.

The controller transmitted four localized prose defects from the independent B07 review. This record implements only those four repairs in the three authorized canonical chapter files. It does not grant B07 approval. No canonical build was run; the controller will generate the new fixed source/PDF pair and return it for independent recheck.

## Exact before snapshots and repaired identities

Each exact before file was saved and byte-compared before editing, in separate scratch history under `b07-history/`. The snapshots were not overwritten by the repair.

| Canonical file | Before bytes / SHA256 | After bytes / SHA256 | Exact before snapshot |
| --- | --- | --- | --- |
| `v26-book/manuscript/ch325.tex` | 61,792 · `0a29abc0849826ef857dd626c25dbb3b57c5bbd76e86ba87a84d795da1f835b2` | 61,802 · `a32369e9afa489554139c43c7dba153e5772e5ea2f20c3950eb21fba6f961bbf` | `b07-history/ch325-before-0a29abc0.tex` |
| `v26-book/manuscript/ch331.tex` | 62,757 · `d49a2c4f088cb3e2c01fe19626a0a2875847a8e436920d6351a6eea5bc509832` | 62,755 · `4f735c3a6d80b775d7e3b0f4cfc43b3e92ade049094153adc3746fb640442cc1` | `b07-history/ch331-before-d49a2c4f.tex` |
| `v26-book/manuscript/ch332.tex` | 63,924 · `d3c9f86939862f38fde1d23ff9e8c97289efeaf7dfd539f66336f6cc22e99c23` | 63,986 · `e1abcca8901d55117197daee54fd117a0c5f25d81931f30b44eddc811624adb7` | `b07-history/ch332-before-d3c9f869.tex` |

## Four returned defects, changes and bounded dependency checks

| ID / landing | Original defect | Repaired prose / direct and propagated check |
| --- | --- | --- |
| B07-C01 · `prop:331-disk-green`, proof | The negative logarithmic modulus was called a unit source without stating its factor 1/(2π). | “The singular term \(-(2\pi)^{-1}\log\lvert z-w\rvert\) has unit distributional source under \(-\Delta\).” The actual TeX uses the unchanged modulus notation `|z-w|`. This now matches the displayed Green expression and normalized planar Φ. The Cayley transport, centered special case, image formulas and source coefficient remain unchanged. |
| B07-C02 · `prob:331-cubic`, solution | “The correction vanishes exactly where |x|=R” incorrectly excludes its additional zeros on x₁=0. | “The correction vanishes on \(|x|=R\). Thus \(u(z)=z_1^3\) on the sphere.” The boundary-value assertion needs only sphere vanishing. The cubic coefficient, Laplacian cancellation and disk Fourier cross-check are unchanged; the claim no longer characterizes the full zero set. |
| B07-C03 · `ex:332-poly-extension` | The sphere boundary identity was attributed to the Laplacian identities instead of to the vanishing correction. | “The correction vanishes on the sphere, so the boundary values equal those of \(g\). The identities \(\Delta x_1^2=2\) and \(\Delta |x|^2=2n\) give \(\Delta U=0\).” The introduction is “Take g(x)=x₁² and set”, with a terminal period after the displayed polynomial, so it is a complete definition and harmonicity is established by the later Laplacian calculation. The displayed U, collar-class argument, variational/Poisson/Perron identification, center value and Green reference are unchanged. |
| B07-C04 · `prob:325-constant-source`, solution | “subtracting …, which is harmonic” could assign harmonicity to the subtracted quadratic instead of the resulting difference. | “This calculation is also obtained by setting v(x)=u(x)−c|x−a|²/(2n). The difference v is harmonic because Δv=c−c=0.” The actual TeX retains the original mathematical notation. The center a and source Δu=c are in the same problem. The sphere/volume average increments and their different constants are unchanged. |

The repair changes prose and clarifying inline expressions only. The mathematical contents of the display formula blocks, all labels and `ref`/`eqref` lists remain identical; the definition display in B07-C03 adds only its requested terminal punctuation. Direct replacement reversal reproduces each before text; the introduction adjustment and display punctuation are the ones explained in B07-C03. No changes to Chapters 326–330, reference inputs, tools, template or frozen prior volumes were made.

The initial B07 return described the two Chapter 331 defects as substantive prose errors. This record preserves them as repaired defects and does not recast the earlier B04 coverage as having detected them. The independent B07 role must recheck these actual changes and any reflowed pages.

## Handoff

The unified diff is `v26-stage/B07-Content-Repairs.diff`, with literal before/after source names and actual newlines. The earlier single-file `B07-Ch331-Repair.diff` is a retained intermediate diff for the first two repairs; the combined content diff is authoritative for this four-row batch. No canonical PDF was built or declared paired with the repaired sources. The controller receives the final hashes, builds the repair pair, records reflow/visual effects and returns that pair to independent B07. Existing B05 labels remain destinations, but their old source hashes and the old B06 PDF are not identities of this repaired batch. Model/reasoning setting remains unverified. Delivery is same-Work; actual review/approval is not implied by sending the report.

Combined diff: 3,673 bytes; SHA256 `fee838a8ec540e5dbba32522d166227df463dc7728fc8f94ea4b37862f77ec07`.

**Released for controller repair build.** All four requested repairs and the two final grammatical precision edits are fixed at the after hashes above. No further author edit is pending in this batch. Independent B07 recheck and controller build remain separate.
