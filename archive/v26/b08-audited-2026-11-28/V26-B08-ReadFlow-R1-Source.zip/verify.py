#!/usr/bin/env python3
"""Verify the sealed V26 package with the Python standard library."""
import hashlib
import json
from pathlib import Path
import sys


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFEST.json").read_text())
    failed = []
    for relative, expected in manifest["files"].items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            failed.append(f"{relative}: missing or outside package")
            continue
        data = path.read_bytes()
        if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
            failed.append(f"{relative}: size or SHA-256 mismatch")
    if failed:
        sys.exit("\n".join(failed))
    print(f"Verified {len(manifest['files'])} files for {manifest['edition']}.")


if __name__ == "__main__":
    main()
