"""Render the fixed PDF and report its geometry and document navigation."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import re

import fitz
from PIL import Image, ImageDraw


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("pdf", type=Path)
parser.add_argument("out", type=Path)
parser.add_argument("--zoom", type=float, default=0.74)
parser.add_argument("--full-zoom", type=float, default=1.4,
                    help="Render every individual whole page at this scale; zero disables.")
args = parser.parse_args()

data = args.pdf.read_bytes()
args.out.mkdir(parents=True, exist_ok=True)
doc = fitz.open(stream=data, filetype="pdf")
matrix = fitz.Matrix(args.zoom, args.zoom)
if args.full_zoom > 0:
    (args.out / "whole-pages").mkdir(exist_ok=True)
bookmarks = doc.get_toc()
dimensions = [round(doc[0].rect.width * args.zoom) + 3,
              round(doc[0].rect.height * args.zoom) + 3]
columns, rows = 3, 3
chunk = columns * rows
padding, caption = 15, 24
width, height = dimensions
cell_w, cell_h = width + padding, height + padding + caption
sheets, scan = [], []
for page in doc:
    pix = page.get_pixmap(matrix=matrix, alpha=False)
    if args.full_zoom > 0:
        page.get_pixmap(matrix=fitz.Matrix(args.full_zoom, args.full_zoom), alpha=False).save(
            args.out / "whole-pages" / f"page-{page.number + 1:03d}.png")
    if page.number % chunk == 0:
        sheet = Image.new("RGB", (columns * cell_w + padding, rows * cell_h + padding), "#dce0e0")
        draw = ImageDraw.Draw(sheet)
    col, row = page.number % columns, (page.number % chunk) // columns
    x, y = padding + col * cell_w, padding + row * cell_h
    sheet.paste(Image.frombytes("RGB", (pix.width, pix.height), pix.samples), (x, y))
    draw.text((x + 2, y + height + 4), f"Physical page {page.number + 1}", fill="#10181a")
    if page.number % chunk == chunk - 1 or page.number + 1 == len(doc):
        a = page.number // chunk * chunk + 1
        b = page.number + 1
        path = args.out / f"pages-{a:03d}-{b:03d}.png"
        sheet.save(path)
        sheets.append({"first": a, "last": b, "path": path.name})

    flags = []
    spans = [
        span
        for block in page.get_text("dict")["blocks"]
        for line in block.get("lines", [])
        for span in line.get("spans", [])
        if span["text"].strip()
    ]
    page_rect = page.rect
    # A geometry flag is a candidate for visual inspection, never an acceptance result.
    footers = [sp for sp in spans if sp["bbox"][1] > page_rect.height - 55 and
               ("ReadFlow R1" in sp["text"] or re.fullmatch(r"[0-9ivxlcdm]+", sp["text"].strip()))]
    for span in spans:
        if not page_rect.contains(fitz.Rect(span["bbox"])):
            flags.append({"type": "out-of-page text", "text": span["text"][:70], "bbox": span["bbox"]})
        color = span.get("color")
        if color is not None and min(color >> 16, (color >> 8) & 255, color & 255) > 235:
            flags.append({"type": "near-white text", "text": span["text"][:70], "bbox": span["bbox"]})
        if "\ufffd" in span["text"]:
            flags.append({"type": "replacement character", "text": span["text"][:70], "bbox": span["bbox"]})
        if span not in footers:
            for footer in footers:
                if fitz.Rect(span["bbox"]).intersects(fitz.Rect(footer["bbox"])):
                    flags.append({"type": "possible footer overlap", "text": span["text"][:70],
                                  "bbox": span["bbox"], "footer": footer["text"]})
    for link in page.get_links():
        if link["kind"] == fitz.LINK_GOTO and not 0 <= link.get("page", -1) < len(doc):
            flags.append({"type": "invalid internal link", "page": link.get("page")})
    scan.append({
        "page": page.number + 1,
        "size": [page_rect.width, page_rect.height],
        "text_spans": len(spans),
        "text_characters": sum(len(sp["text"]) for sp in spans),
        "links": len(page.get_links()),
        "flags": flags,
    })

log = {
    "source": args.pdf.name,
    "sha256": sha256(data).hexdigest(),
    "size": len(data),
    "pages": len(doc),
    "bookmarks": bookmarks,
    "metadata": doc.metadata,
    "page_labels": doc.get_page_labels(),
    "bookmark_flags": [item for item in bookmarks if not 1 <= item[2] <= len(doc)],
    "fonts": sorted({tuple(font[:6]) for page in doc for font in page.get_fonts()}),
    "full_page_renders": "whole-pages/page-NNN.png" if args.full_zoom > 0 else None,
    "human_review_status": "PENDING: rendering and geometry checks do not mean pages were viewed",
    "renders": sheets,
    "flags": [p for p in scan if p["flags"]],
    "engineering": scan,
}
(args.out / "review-map.json").write_text(json.dumps(log, indent=2) + "\n")
print(json.dumps({k: log[k] for k in ("sha256", "pages", "flags")}))
