"""Compare two editions for exact page replay and document navigation."""
import argparse
import hashlib
import json
from pathlib import Path

import fitz

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("reference", type=Path)
parser.add_argument("other", type=Path)
parser.add_argument("report", type=Path)
args = parser.parse_args()


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def link_targets(page):
    return [{
        field: tuple(link[field]) if isinstance(link[field], (fitz.Point, fitz.Rect)) else link[field]
        for field in ("kind", "page", "to", "uri", "zoom", "from", "name")
        if field in link
    } for link in page.get_links()]


original = args.reference.read_bytes()
candidate = args.other.read_bytes()
ref = fitz.open(stream=original, filetype="pdf")
out = fitz.open(stream=candidate, filetype="pdf")
mismatches = []
for i in range(min(len(ref), len(out))):
    page = ref[i]
    other_page = out[i]
    if page.rect != other_page.rect or page.rotation != other_page.rotation:
        mismatches.append([i + 1, "geometry"])
    if page.get_text() != other_page.get_text():
        mismatches.append([i + 1, "text"])
    if link_targets(page) != link_targets(other_page):
        mismatches.append([i + 1, "links"])
    matrix = fitz.Matrix(2, 2)
    if hash_bytes(page.get_pixmap(matrix=matrix, alpha=False).samples) != hash_bytes(
        other_page.get_pixmap(matrix=matrix, alpha=False).samples
    ):
        mismatches.append([i + 1, "render"])
result = {
    "reference": args.reference.name,
    "reference_sha256": hash_bytes(original),
    "reference_bytes": len(original),
    "compared": args.other.name,
    "compared_sha256": hash_bytes(candidate),
    "compared_bytes": len(candidate),
    "byte_identical": original == candidate,
    "reference_pages": len(ref),
    "compared_pages": len(out),
    "matching_bookmarks": ref.get_toc(simple=False) == out.get_toc(simple=False),
    "matching_page_labels": ref.get_page_labels() == out.get_page_labels(),
    "render_dpi": 144,
    "page_mismatches": mismatches,
}
args.report.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
if (mismatches or len(ref) != len(out) or not result["matching_bookmarks"]
        or not result["matching_page_labels"]):
    raise SystemExit(1)
