"""Map repeated page body images across a pagination-only revision."""
import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path

import fitz

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("before", type=Path)
parser.add_argument("after", type=Path)
parser.add_argument("report", type=Path)
args = parser.parse_args()


def body(page):
    bounds = page.rect
    clip = fitz.Rect(bounds.x0, 47, bounds.x1, bounds.y1 - 49)
    return sha256(page.get_pixmap(matrix=fitz.Matrix(1.4, 1.4), clip=clip,
                                  alpha=False).samples).hexdigest()


with fitz.open(args.before) as before, fitz.open(args.after) as after:
    previous = defaultdict(list)
    for page in before:
        previous[body(page)].append(page.number + 1)
    matching = {}
    changed = []
    for page in after:
        matches = previous.get(body(page))
        if matches:
            matching[page.number + 1] = matches
        else:
            changed.append(page.number + 1)
    result = {
        "before_sha256": sha256(args.before.read_bytes()).hexdigest(),
        "after_sha256": sha256(args.after.read_bytes()).hexdigest(),
        "before_pages": len(before),
        "after_pages": len(after),
        "matching_physical_body_pages": matching,
        "changed_physical_body_pages": changed,
        "point_crop": "47 points at top, 49 points at bottom. Includes the entire body.",
        "dpi": 100.8,
    }
    args.report.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"before": len(before), "after": len(after),
                      "equal_body_count": len(matching), "changed": changed}))
