# V26 font dependency notice

These font files and their accompanying license notices are copied unmodified
from the published V25 source archive, fixed at commit
`0fb04b259609ceb1554d7b714249e792b6f90ff6`. The adopted V0 ReadFlow R1
source archive does not bundle these fonts. Exact dependency file hashes
are recorded in the delivery manifest.

PagellaX uses the included newpx/LPPL notices; Asana and STIX use their included
OFL notices; Noto uses its included copyright/OFL notice; DejaVu uses its
included copyright/license. See `licenses/` for the notices. Historical
template notices in `../licenses/` document separate Study dependencies.
