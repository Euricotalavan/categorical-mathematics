# V26 · Harmonic Functions and Classical Potential Theory

Categorical Mathematics · Chapters 325–332 · ReadFlow R1.

The English manuscript covers the mean-value characterization, subharmonic comparison, Green functions, continuous-data Perron resolutivity, equilibrium measures and capacities, regular points and Fatou limits, explicit model domains, and an energy formulation of the Dirichlet problem. The worked problems include solutions in the reading edition and in the editable source.

The reading edition is 196 pages with 60 sections, 55 worked examples and 104 exercises with complete solutions. Its fixed PDF SHA-256 is `1dbd599c96eb870bee99955529a344f8b8aae40c461c5a530b3d6381e5010268`. The independent final mathematical review of this exact pair is recorded in `evidence/B07/B07-Final-Audit.md`.

## Files and verification

- `manuscript/ch325.tex` through `manuscript/ch332.tex` are the single editable manuscript.
- `layout/study/volume-26.tex` is the volume entry. The adopted ReadFlow R1 style hashes and font dependencies are documented in `evidence/ReadFlow-baseline.json` and `dependencies`.
- `paired/V26-B08-ReadFlow-R1.pdf` is the exact reviewed reading edition.
- `MANIFEST.json` identifies the files and their SHA-256 digests.
- `evidence/B01` through `evidence/B08` record the source coverage, roles, chapter reviews, integration, typesetting, final mathematical decision and reproducibility checks.

From the extracted source directory run:

```sh
python3 verify.py
python3 tools/build.py --full --name rebuild
```

Rebuilding requires Python 3.10 or later, XeLaTeX, the TeX Live packages used by the template and fontconfig. Bundled fonts carry their licenses. The rebuilt file is `.build/rebuild/volume26.pdf`. The shipped PDF has its own exact digest. Rebuild verification records which rendered and logical properties reproduce.

The source-coverage review used the author versions of Axler–Bourdon–Ramey and Papadimitrakis and the course materials of Ivrii. The two catalogue/preview-only books and the deferred advanced proofs are identified precisely in the source map. See the author and publisher links to access the references.
