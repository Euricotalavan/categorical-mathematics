# V9 — Computability and Reverse Mathematics

課量先鎖；來源未簽核，不寫稿。id="V9"> V9 可計算性與逆向數學 2 學期預估 · 12 章 逐卷正式定界待核 先備 一階邏輯；基礎分析相關例子 教完落點 從計算不可解性走到公理強度比較。 預估 2 學期，96 接觸小時；其中新內容 72、例題 12、專題 6、評量 6 小時。課量為規劃估算。 章號 章名 印頁／預估課時 1 計算模型與可計算函數 6.0 小時 2 可枚舉集合 6.0 小時 3 不可判定性的基本證明 6.0 小時 4 歸約與完全性 6.0 小時 5 計算程度 6.0 小時 6 相對可計算性 6.0 小時 7 弱二階算術 6.0 小時 8 編碼與分析語句 6.0 小時 9 基本公理系統 6.0 小時 10 典型定理的反轉 6.0 小時 11 緊緻性與覆蓋原理 6.0 小時 12 分析命題的公理強度比較 6.0 小時

| 章 | 正文（每格 90 分） | 例題課 |
|---|---|---|
| 126 計算模型與可計算函數 | one explicit computation model ／ coding inputs and finite computations ／ partial and total functions with simulations ／ admissible Church–Turing interpretation and a worked program | 60 分 |
| 127 可枚舉集合 | enumerators and partial semidecision ／ two-direction equivalence via dovetailing ／ decidability iff set and complement are c.e. ／ enumerate a nontrivial relation | 60 分 |
| 128 不可判定性的基本證明 | effective numbering and universal computation ／ diagonal halting argument ／ self-input and pairing variants ／ analyze what the proof does not imply | 60 分 |
| 129 歸約與完全性 | define many-one reductions ／ explicit map to the halting set ／ demonstrate a completeness proof ／ distinguish undecidability transfer directions | 60 分 |
| 130 計算程度 | mutual Turing reducibility ／ equivalence classes and partial order ／ join construction using tagged sets ／ give examples at the computable degree and strictly above it, and prove that no degree lies below it | 60 分 |
| 131 相對可計算性 | oracle programs and queries ／ relativized enumeration ／ diagonal jump theorem ／ examples separating reductions from complexity | 60 分 |
| 132 弱二階算術 | two sorts and set parameters ／ number and set quantifiers with complexity classes ／ comprehension and induction schemas ／ model/omega-model distinctions | 60 分 |
| 133 編碼與分析語句 | code rationals and fast Cauchy names ／ handle comparisons and equality with error bounds ／ code open data or trees ／ prove a representation lemma over the stated base | 60 分 |
| 134 基本公理系統 | spell out RCA0, WKL0 and ACA0 principles ／ separate syntactic extensions from theorem comparisons ／ one elementary implication with proof ／ explain role and boundary of stronger systems | 60 分 |
| 135 典型定理的反轉 | set a fixed base and specify a theorem ／ forward proof ／ reverse construction recovering the principle ／ check coding and hidden comprehension | 60 分 |
| 136 緊緻性與覆蓋原理 | state WKL in a coded tree setting ／ forward compactness proof ／ reverse cover-to-tree or exact alternate WKL equivalence ／ distinguish finite subcover assertions from other versions | 60 分 |
| 137 分析命題的公理強度比較 | pick two explicitly coded analysis statements ／ show one equivalence with required hypotheses ／ compare implications with countermodel or scoped nonimplication ／ compile an assumption and proof map | 60 分 |

合計 96 小時：正文 72、例題 12、整合專題 6、評量 6。先校準第 135 章。

- Every session maps to actual manuscript anchors with definitions and hypotheses, a teachable proof or construction with steps, worked reasoning, in-class check and answer. Proof and hour gates independent of PDF page count.
- One new step-by-step example and three graded practice exercises with full solutions per chapter.
- 4 sessions of 90 minutes; authentic problem, checkpoints, instructor solution and 100-point rubric.
- Question sheets and worked answer keys on separate pages; total 6 hours means two 120-minute sittings plus two 60-minute debriefs; total 3 hours means one 90-minute sitting and 90-minute debrief.
- B-01 primary-source decision before calibration. Calibrate one complete chapter, including teaching materials, before any full production.
- Pass exact scope, assigned chapter, mathematical source evidence, verified dependencies and approved notation to every job. Attach actual text, hash it, and stop if a required document is missing. Independent anchored math and depth audit sees full draft.
- Build and rasterize XeLaTeX PDF, verify manuscript counts and all hour plans, package exact source hashes, publish only when explicitly requested. Teaching hours remain planning estimates, not classroom measurements.

原參考卡書目候選（非原文證據）：
- Recursively Enumerable Sets and Degrees
- Subsystems of Second Order Arithmetic
- Computability: An Introduction to Recursive Function Theory
