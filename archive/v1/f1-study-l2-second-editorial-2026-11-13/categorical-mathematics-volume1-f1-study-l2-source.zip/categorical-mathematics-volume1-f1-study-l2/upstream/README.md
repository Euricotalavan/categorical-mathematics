# Volume 1 content F1

Start with VOLUME1-CONTENT-F1-REPORT.md and VOLUME1-EDITOR-HANDOFF-F1.md.

The agreed Chapter 10–28 English content is ready for editorial Step8. GAP-V1-01/02 are completed; optional GAP-V1-03 was not selected. Source, exact patch/before-after hashes, complete reading/proof/answer windows, issue dispositions and accepted boundary are included.

Run `python3 tools/verify_source.py` after extraction to verify the package and source bytes. This is not machine certification of mathematics. The optional `tools/apply_to_rough.py` is guarded for the exact rough-source ancestor; it applies only the twelve listed paths and supports exact rollback. It does not merge unrelated or conflicting source trees.

Other volumes in source/ are historical recovery context, not authority to replace the current V0 editorial edition or any active later-volume tree. Shared styles and generators were not changed. No current F1 V1 PDF was built. Formal framework gates and LR uncertainty remain as stated in the report.

