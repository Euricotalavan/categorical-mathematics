# Volume 1 boundary r1 — Step 2 expansion consensus

Date: 2026-11-13. Receiver: Content Expansion Agent. Decision: **AGREED WITHOUT RETURN**.

## Exact received inputs

- Fixed boundary file: `categorical-mathematics-v1-boundary-r1.zip`, Library `libfile_fde3_f-6a0a7154c480819181a4c78fec1f4ce8_383d682b1c388191a1961becbec9fb77`, version `1`, SHA256 `7b15d97c5ce1bf5f14c3b9c909e727ba70a03d6e19cb7ac59ca2f3c1f4320781`.
- Reused author source: `categorical-mathematics-author-v0-r2-cp58-policy-A-scope-controlled-source.zip`, Library `libfile_fde3_f-1bf7d9ff724881918702165715c5b3bb_383d682b1c388191a1961becbec9fb77`, version `0`, SHA256 `a8e309e118a37a80cc285dc5dd71f1f95f17e9d71708684c4f75da03b45da510`.
- Thirty-five selected Volume 1 canonical paths and their SHA256s agree with the boundary's frozen-source index. Existing Chapter 10–28 and 283 historical V1 rows remain the only content baseline; do not create a competing master.

## Agreed bounded seven strands

1. Ch10–11: Given constructions, quantifier order, T/P/E/B and finite-diagram synthesis.
2. Ch12–14,20: Given exponentials, evaluation, beta/eta and exponential calculations.
3. Ch15–19,21: Classifiers and represented predicates, conjunction, implication and families.
4. Ch22–24: Coequalizers, regular images, existential predicates and relation composition with explicit R hypotheses.
5. Ch25: Effective quotient and descent, no global representative choice.
6. Ch26–27: Coproducts, C/D and strictness, finite queries and gluing, not general colimits/sheaf theory.
7. Ch28: Given NNO and represented recursion only; further arithmetic in V2.

## Supplement decision

- **GAP-V1-01 adopted as a small core bridge:** finite, externally supplied diagram and cone; one equalizer of two finite-product arrows; full factorization/uniqueness proof including empty diagram; derive finite-limit existence conditionally from T+B; include compatible and failed-equation tests. No general small-limit framework, no arbitrary family formation, no global selections.
- **GAP-V1-02 adopted as a small core synthesis:** existing categorical packages and dependency/status map; distinguish the existence of particular supplied data from requirements for every input and from a chosen coherent foundational framework. Do not infer regularity, effectiveness, C, D, NNO or classical negation from bare category axioms.
- **GAP-V1-03 remains optional P3 and is not selected for this expansion draft.** A nonselected optional law is not a completeness defect.

## Contract and safeguards

The present Step 2 agreement uses no boundary return. In Step 3–4, expand the existing V1 draft in approximately four connected narrative batches; checkpoints are safety saves, not formal iterations and do not require fresh dot approval. Preserve canonical IDs, selected-source lineage, proof claims and all prior volumes; additions may get new unique IDs. The F1 Volume 0 editorial work is not reopened. No new global policy, choice, size convention, sheaf theory, general presheaf completion, general limits or topos inference. LR body, its correspondence and exhaustive no-omission claims remain UNKNOWN. The six inherited framework gates remain OPEN. V1 remains an English working DRAFT, not a completed or EN-STABLE volume. No unverified GitHub submission, file cleanup or Study overwrite.

External-literature anchors are the inherited finite Riehl comparisons and the verified boundary package; they are not claims to have read every external proof or the inaccessible Lawvere–Rosebrugh body.
