# Volume 1 r1: bounded expansion rough-draft handoff (Steps 3–4)

Status: **English DRAFT — four narrative work batches completed; not a final or independently verified volume**.

## Signed-off boundary

- Input: `categorical-mathematics-v1-boundary-r1.zip`, Library v1, SHA256 `7b15d97c5ce1bf5f14c3b9c909e727ba70a03d6e19cb7ac59ca2f3c1f4320781`.
- Consensus: **agreed without return**, recorded in separately saved `v1-boundary-consensus-r1.md`, Library `libfile_fde3_f-bb2322491bd08191965b2ed886e727eb_383d682b1c388191a1961becbec9fb77` v0.
- Existing source baseline: CP58 author archive, SHA256 `a8e309e118a37a80cc285dc5dd71f1f95f17e9d71708684c4f75da03b45da510`.
- All 35 existing V1 selected canonical files and hashes have been retained unchanged. The seven agreed strands remain Chapter 10–28; original 283 historical V1 matrix rows and stable IDs are preserved, not forked.

## Four connected rough-draft batches (work batches, not formal iterations)

1. **Reading route / Chapter 10.** `v1-d01-existence-route.tex` distinguishes a supplied construction, an individual witness and a universal existence requirement. It adds forward reading orientation without declaring any new construction automatically existent.
2. **Finite-limit synthesis / Chapter 11 (GAP-V1-01).** `v1-d02-finite-cones.tex` defines externally supplied finite diagram and cone, constructs the finite limit using products over object and arrow lists plus their equalizer, proves existence and uniqueness for arbitrary cone sources, handles the empty diagram, and derives the pointwise existence implication from `(T)+(B)`. Contains a one-arrow example, a parallel-pair omitted-equation countertest, four exercises and full solutions. This does not supply arbitrary small limits, uniform choices, or all-object family formation.
3. **Two narrative interfaces / Chapters 21 and 27.** `v1-d03-predicate-to-images.tex` explains the transition from represented conditions to quotient/existential image calculations and keeps (R) explicit. `v1-d03-gluing-to-recursion.tex` explains why finite gluing does not supply an NNO; full arithmetic remains with V2. These are reader bridges, not independent new existence assertions.
4. **Package map / Chapter 28 (GAP-V1-02).** `v1-d04-assumption-map.tex` locates T/P/E/B, finite limits, locally supplied exponentials versus cartesian closure, classifier, R, effectiveness, C/D/strict initial and NNO, separating definitions, local witnesses, external working packages and derived implications. It explicitly leaves the eventual shared foundation, family/size/choice choices, the LR body and the historical gates unresolved.

## Explicit nonselection

`GAP-V1-03` (coproduct-input exponential law) remains optional P3 and was not added; no new general sheaf, LCCC, presheaf, general (co)limits, monadicity, Kan extension, full arithmetic or topos claims were made.

## Compatibility and review boundary

The original selected V1 canonical sources are *byte-identical* to CP58; no existing canonical theorem, exercise, answer or label was altered. Only five new canonical files, their V1 generated views and the necessary V1 selection/entry maps were added, plus this audit record. All other volumes' canonical sources remain unchanged. The 35 existing source hashes, all source/view hashes, the global uniqueness of selected `\\label`s and all explicit `\\ref`/`\\eqref` targets in the five new units were checked. This is limited author-side consistency and targeted mathematics drafting, not independent proof review, whole-volume completion, external proof comparison or formalization.

The independently checked accessible Riehl bounded statement locators in `V1-BOUNDARY-HANDOFF-r1.md` are the literature reference for this addition. Hammack/May remain prerequisites only; the unreadable body of Lawvere–Rosebrugh remains UNKNOWN, and source-wide no-omission coverage is not claimed.

## Recovery and next workflow stage

Recover from this self-contained ZIP (`source/` and `SOURCE-SHA256.json`); the CP58 source and r1 boundary proposal are separate recoverable ancestors, never nested in this checkpoint. The next handoff is to Content Refinement for the contract's **bounded completeness decision**: if enough content exists, refine and correct in roughly three internal batches (not a strict cap); if a named major deficiency remains, return once to expansion, without restarting all seven strands. The editorial/style agent comes only after content readiness. Neither this rough draft nor its unbuilt V1 PDF is an EN-STABLE or complete volume.

Do not overwrite Volume 0 F1/Study, any refined matrix, or any V2/V4 source. No GitHub submission, deletion, move, blanket dependency scan, new framework adoption, PL09/LR gate closure, or full-volume rebuild is authorized by this draft.
