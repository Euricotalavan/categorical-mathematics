#!/usr/bin/env python3
"""Guarded sparse source merge from the exact expansion rough source; optional exact rollback.
Usage: python3 tools/apply_to_rough.py /absolute/target/source [--rollback]
Do not use this to replace a V0/Study workspace. Every affected path is hash-guarded.
"""
from pathlib import Path
import json,hashlib,sys,os
R=Path(__file__).resolve().parents[1]
if len(sys.argv) not in (2,3) or (len(sys.argv)==3 and sys.argv[2]!='--rollback'):
 raise SystemExit(__doc__)
T=Path(sys.argv[1]).resolve();rollback=len(sys.argv)==3
changes=json.loads((R/'CHANGES.json').read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
pending=[]
for c in changes:
 rel=Path(c['path'])
 if rel.is_absolute()or '..'in rel.parts:raise SystemExit('Unsafe source path')
 p=T/rel;before=c['before_sha256'];after=c['after_sha256']
 old=after if rollback else before;new=before if rollback else after;actual=h(p)
 if actual==new:continue
 if actual!=old:raise SystemExit('Before-hash conflict; no writes made: '+str(rel))
 src=R/('before' if rollback else 'source')/rel
 if new is not None and h(src)!=new:raise SystemExit('Payload-hash conflict; no writes made: '+str(rel))
 pending.append((p,src,new))
for p,src,digest in pending:
 if digest is None:p.unlink()
 else:
  p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.v1-f1-tmp');tmp.write_bytes(src.read_bytes());os.replace(tmp,p)
for c in changes:
 expected=c['before_sha256']if rollback else c['after_sha256'];assert h(T/c['path'])==expected
print(json.dumps({'operation':'rollback'if rollback else'apply','changed_paths':len(pending),'all_guards_passed':True}))

