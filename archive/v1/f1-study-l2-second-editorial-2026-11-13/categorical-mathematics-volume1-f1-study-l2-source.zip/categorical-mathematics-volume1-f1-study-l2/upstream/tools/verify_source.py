#!/usr/bin/env python3
"""Verify the restored F1 package. This is source validation, not a proof or PDF checker."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((R/'MANIFEST.json').read_text())
for x in manifest:
 p=R/x['path']
 assert p.is_file(),x['path']
 assert p.stat().st_size==x['bytes'] and h(p)==x['sha256'],x['path']
source=json.loads((R/'SOURCE-SHA256.json').read_text())
for path,digest in source.items():assert h(R/'source'/path)==digest,path
print(json.dumps({'package_items':len(manifest),'source_files':len(source),'source_checks':'PASS','proof_machine_certification':False,'matching_PDF':False}))

