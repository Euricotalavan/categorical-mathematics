# Volume 1 boundary proposal r1 — handoff for Step 2

13 November 2026. Content refinement → content expansion. **Proposed; consensus not yet received.**

## Decision requested

Confirm the finite boundary below, or return one consolidated list of specific objections and requested changes. The contract permits at most one return to Step 1; unresolved disagreement then goes through dot to the user. This document is the first V1 boundary submission, not an authorization to start new manuscript text before agreement.

Retain the existing Chapter 10–28 manuscript and its seven connected strands. The manuscript supplies a substantial starting draft; no basis was found for discarding it or commissioning a replacement. Existing names, proofs, examples and exercises are the starting boundary, not a claim that all their proofs have now been independently checked or that all reference literature is covered.

Add two small proposed synthesis objectives to the boundary: **GAP-V1-01**, a typed finite-limit construction summary, and **GAP-V1-02**, a concise package/terminology and assumption map. Keep **GAP-V1-03**, the coproduct-input exponential law, optional P3. These are concrete proposals for consensus, not adopted scope or newly written mathematics.

The series' original requirement for a coherent acknowledged foundational framework is retained. Keeping the existing conditional theorems does not remove that requirement or turn assumption disclosure into an adequate replacement for derivations. This handoff does not decide the framework or revive six separate gate-research tasks.

## Exact recovered baseline and reuse

The complete F1 source/evidence archive v0 was downloaded: Library `libfile_fde3_f-c2cce40dcf388191aa41658498fa5b93_383d682b1c388191a1961becbec9fb77`, 14,660,129 bytes, SHA256 `78da56fbcd73593d342e5c854ad0ad993aeb264b3c422291c39029c9643c97d2`. Actual ZIP CRC passed. It preserves the CP58 V1 source unchanged. CP58 author source identity is `libfile_fde3_f-1bf7d9ff724881918702165715c5b3bb_383d682b1c388191a1961becbec9fb77` v0, archive SHA256 `a8e309e118a37a80cc285dc5dd71f1f95f17e9d71708684c4f75da03b45da510`; that historical ZIP was not needlessly downloaded again.

All **35 V1 selected canonical file hashes** were actually checked against the recovered map. They contain 6,356 source lines. The archive includes these exact files and the few actual prerequisite anchors used here, with maps and hashes. Generated views were not promoted to canonical.

The accepted r71/v77 evidence was recovered flat from F1. Its master has 1,882 IDs; **283 existing V1 rows** are reused: 257 manuscript items, 19 chapter allocations, five reference-only rows and two prose containers. The 257 include 13 definitions, 87 named theorems, their 87 proof rows, 67 exercises and three environment-marked examples. Those counts are inventories, not completion rates. Sixteen existing prose definitions/interfaces/models are additionally named because environment-only indexing misses them. Their new boundary IDs do not change the global registry.

The original master, registry, gate register and source were not edited. Historical V0-relative “later-volume” statuses remain in their original columns; the new V1 projection explains that Chapter 10–28 material is now in the volume under consideration. A V0-relative status is not evidence that V1 content is absent.

The earlier broad project scope `categorical-mathematics-scope-v1.html`, Library `libfile_fde3_f-93da495964108191929f0f81b1e86742_383d682b1c388191a1961becbec9fb77` v0, and book-workflow-v1 v0 were actually read. The broad series goals are allocation context, not permission to put the entire future category/topos/logic curriculum in V1. Bounded searches and the recovered matrices did not yield an equivalent agreed V1 boundary; this is not a claim to have searched every possible historical artifact.

The user reports V0 second editorial source v5 / PDF v1. This work does not download, edit, rebuild or recertify that edition. Its accepted role as the prerequisite volume is retained.

## Proposed finite content boundary

| Strand | Existing chapters | Required named content and learning outcome | Hypotheses and exit limit |
| --- | --- | --- | --- |
| 1. From given tests to existence assertions | 10–11 | T/P/E/B; local witnesses versus uniform assignments; product+equalizer pullback; terminal pullback product; diagonal equalizer; equivalence of packages; order models; wrong-arrow and missing-bound tests. Proposed finite-cone synthesis consolidates these. | Supplied finite data and explicit existence assumptions; no all-object choice or all-small limits. |
| 2. Representing maps | 12–14, 20 | Exponential, evaluation, beta/eta, compatible uniqueness; parameter/input/output substitution and represented composition; unit/output-product/iterated laws; exponentiation of given equalizers and pullbacks. | Given products and exponentials at the used instances. V0 naturality/adjunction/representability supplies the language. No arbitrary functor category or dependent-product construction. |
| 3. Classifying predicates and families | 15–19, 21 | Truth classifier, factor test and compatible representatives; pullback of characteristic arrows; conjunction and implication; power membership/family names; graph and singleton tests; pointwise operations and universal condition along projections. | Explicit classifier, products, truth pullbacks, equalizers and used exponentials. Internal implication is not automatically Boolean; generalized tests do not reduce to global points. |
| 4. Quotients, regular images and existential conditions | 22–24 | Epi, balancedness warning, coequalizer, corrected target transport, kernel pair, regular epi/lifting, least regular image; R, stable images, direct/inverse-image comparison, composition, base change, Frobenius; existential order/local-witness test and relation composition. | Keep the exact R hypotheses; do not infer regular factorization or stability from category laws or all finite limits. |
| 5. Effective relations and descent | 25 | Internal equivalence relation, effective quotient, noneffective countermodel; total/single-valued graph criterion; unique output versus arbitrary choice; invariant arrows, saturated representatives and descended equations. | Effectiveness and kernel-pair data are genuine extra information. No global representative selection. |
| 6. Alternative sources and finite gluing | 26–27 | Initial and strict initial objects, tagged coproducts, copairing, distributivity; unions, C stability, D disjointness, negation versus complement; finite query calculations, safe/unsafe quotient compression; sums of quotients; two-/three-piece gluing with overlap agreement. | C/D/strictness retained exactly where used. Finite gluing does not entail general sheaf theory, Giraud's theorem or all colimits. |
| 7. The recursive interface handed to V2 | 28 | Given NNO, unique recursion, compatible uniqueness, represented-subobject induction, zero–successor decomposition, parameter recursion through an exponential; parity and degenerate-model tests; retain the existing first addition illustration. | NNO is supplied, not an existence theorem from category laws. Internal induction is distinct from external finite-syntax induction. Full arithmetic remains in V2. |

`NAMED-ITEMS.md` and `v1-live-boundary-view.json` name every inherited manuscript definition/theorem/proof/exercise row with exact canonical path, hash and line window. `chapter-boundary.json` supplies the nineteen chapter dependencies and historical review states. Existing explicit cross-chapter references are retained in `existing-dependency-edges.json`; this is a location inventory, not a fresh dependency-completeness certificate.

## Literature boundary and actual access

| Designated source | Actual access / use | Boundary consequence |
| --- | --- | --- |
| Emily Riehl, *Category Theory in Context*, author-hosted revised PDF, derived from Dover 2016 | Actual recovered PDF: 299 physical pages, SHA256 `e4779f34ff0432508f1105912f39a84af3c64799b969507325c80e27c2d994dd`. [Author PDF](https://emilyriehl.github.io/files/context.pdf). 44 bounded named fragments now have statement/assumption locators and manuscript anchors; existing precise readings are reused. | These are applicable fragments, including V0 prerequisites, not an obligation to reproduce the entire book. Named external statements are read; full proofs/solutions are not blanket-certified. |
| Richard Hammack, *Book of Proof*, third edition, file edition 3.4 (2018) | Actual recovered PDF: 380 physical pages, SHA256 `e0e471ca794ddda7bc46704b22885e1582350b7fc5881f8ba9a61b3747ec79fd`. [Author PDF](https://richardhammack.github.io/BookOfProof/Main.pdf). Inherited actual scope: §§2.6–2.7, 2.10, 7.3, with named rows and exact pages in the inherited records. | Proof-language prerequisites in V0; no new Hammack curriculum or proof re-reading imposed on V1. |
| J. P. May, *Finite spaces and larger contexts*, existing fixed collated draft | Retained original SHA256 `0bbd76036251235c8d47113c499433161b0f4965b79cd809a47503b244478867`, 802,924 bytes / 124 pages. [Author draft](https://math.uchicago.edu/~may/FINITE/FINITEBOOK/FINITEBOOKCollatedDraft.pdf). Preserve the r69 ten-item fixed-original statement alignment and earlier exact proof windows, not a new May reading. | V0 finite-topology example/prerequisite only. Preserve the opposite-order convention warning. No V1 topology expansion. |
| F. W. Lawvere and R. Rosebrugh, *Sets for Mathematics*, Cambridge UP (2003), DOI 10.1017/CBO9780511755460 | [Publisher DOI](https://doi.org/10.1017/CBO9780511755460). Readable body not obtained; hash, body pages, theorem names and proof correspondence **UNKNOWN**. Existing failed-access evidence is retained; no new retries. | Nineteen chapter-correspondence records explicitly remain UNKNOWN. They identify our manuscript requirements, not invented LR chapter contents. Exhaustive LR coverage and no-omission certification remain unavailable. |

`REFERENCE-BOUNDARY.md` and `reference-to-manuscript.json` give each selected Riehl fragment's precise printed/PDF locator, paraphrased statement, applicable assumptions, actual manuscript label/path/hash/window, and covered/partial/missing classification. A whole source theorem is never labelled covered when only its named finite or supplied-data fragment is intended.

In particular:
- Riehl Lemmas 3.5.15–16 match the existing Chapter 11 product/diagonal constructions.
- Theorem 3.5.17 is **partial**, because the manuscript proves the T+P+E ↔ T+B special-construction equivalence without a general finite-diagram definition/construction. This is one synthesis objective, not three duplicate gaps for three related references.
- Definition 4.4.10 is **partial** at the named-package level: local exponentials exist in the text, but the explicit cartesian-closed package vocabulary is not present.
- Corollary 4.5.5 has two existing laws and one **missing explicit optional** coproduct-input exponential law. The missing law is not misreported as an error in the adjacent iterated-exponent theorem.
- The existing universal condition is along projections. General locally cartesian closed slices and the full adjoint triple of Proposition 4.6.6 are stronger; V0 B47 already gives postcomposition ⊣ base change. They are **partial/outside the proposed V1 core**, not falsely assigned to a written later volume.
- LR uncertainty is distinct from absence in the manuscript. Unassigned exact external answers remain UNKNOWN.

## Concentrated supplement / exclusion decisions

1. **GAP-V1-01 — proposed small core bridge.** Give a finite typed cone test and the finite-product/equalizer construction, including its full factor proof and empty-diagram case. Conclude finite completeness from T+B. Existing exact anchor: `prop:existence-packages`; current source/hash/window and acceptance specification are in `concentrated-gaps.json`. No arbitrary family formation or new choice principle is needed for the proposed bounded claim. The current special-shape theorem itself is not defective.
2. **GAP-V1-02 — proposed small core synthesis.** Consolidate existing T/P/E/B, local exponentials versus cartesian closure, classifier, R, effectiveness, C/D/strictness and NNO into one terminology/assumption map. Explain which propositions supply each implication and which hypotheses are still independent. Do not assume all structure families or adopt ETCS/a new foundation by naming a package.
3. **GAP-V1-03 — optional P3.** The law for a coproduct in the exponent may be added as a compact application if selected. It is not a blocker or a reason to return the whole draft.
4. **Actual later-volume allocation.** V2 Chapters 29–51 already hold parameter induction/addition, multiplication, recursion/order/bounded search, Euclidean arithmetic, integers, fractions and completion. Exact map evidence is in `verified-later-volume-allocation.json`. V3 is reserved, not written. No complete complex-number construction is inferred.
5. **Not this volume's obligation.** General small limits/colimits, general LCCC/dependent products, arbitrary presheaf exponentials, monadicity, Kan extensions, Grothendieck topoi and a complete formal internal-language course belong to the broader series agenda, but no specific written later location is claimed here. This is a scope proposal for agreement, not evidence of their completion elsewhere.

No named contradiction or erroneous theorem was established by this statement-level boundary pass. This does not certify all V1 proofs: the purpose is to agree what must be present and what exact assumptions it must use. No new prose, canonical patch or mathematical policy was applied.

## Expansion handoff checklist

- [ ] Acknowledge the exact CP58/F1 V1 source and this boundary r1; preserve all existing stable IDs.
- [ ] Confirm the seven strands plus the attached item/prose inventory, or give one consolidated concrete return.
- [ ] Decide whether the two proposed small synthesis objectives are included; explicitly keep or decline optional GAP-V1-03.
- [ ] Preserve the V0 prerequisite / V2 arithmetic boundary; do not rewrite previously accepted V0 content.
- [ ] Keep the distinction between current conditional theorem contracts and final common-framework obligations; do not silently lower the latter or adopt a policy.
- [ ] Retain LR UNKNOWN and separate “text present”, “proof read”, “reference compared” fields.
- [ ] After consensus, proceed to Step 3 narrative ordering and an integrated rough-draft plan. This Step 1 handoff does not request serial small-task approvals.

Six inherited gates remain open in their precise current states; the working empty-category admission is already adopted and is not again offered as an undecided policy. SM-ZF/HFSet remains comparison evidence. The later EC realization is not moved into V1. No unconditional full-volume, common-foundation or exhaustive-literature certificate is issued.

## Recovery and non-actions

`lineage.json`, `v1-source-index.json`, `reference-statement-scope.json`, exact frozen source files, editable tables, the preserved historical V1 projection and the unchanged inherited registers provide recovery. The entire prior archive and PDFs remain available from the pinned parent; they are not nested in this package.

The 1,882-ID master and registry remain unchanged. No V0, CP58/F1 canonical, Study, PDF, GitHub, cloud cleanup, permission or repository action was performed. The checkpoint is recovery history, not another formal boundary round.

