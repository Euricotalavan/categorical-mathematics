# V1 F1 Study L2 — second editorial edition QA

## Fixed input and decision

The fixed assessed source version2 has SHA256 af88d2fecaa25d90335a0cd3343c9a65e66364b2507ddcb7786862d2fb3db8bc,4,105,439 bytes,800 manifest items. Its saved PDF version0 has SHA256 2d68ae972b2e74b33c4a0af1ce9e868c01c7a2ab21d0d82123ace8c938ea2e6b; the corresponding raw PDF inside the ZIP is b339b0342c3400ed0da1175ea0b11c1b4d468cf0e9e938f5b0bbe557bd96b57a. Exact fixed versions were freshly downloaded and verified. Both full Step11 originals are retained with IDs/hashes in editorial/step12-13/receipt-and-decision.json. Refinement: NO OBJECTIONS, no repair request. Expansion: NO OBJECTIONS to proceeding, sole optional nonblocking P2.

Step12 adopts P2 through three bold paragraph lead-ins on physical2. Removing exactly these three tokens restores the original five-paragraph guide byte-for-byte; no assumptions, status caveats or order were removed. The heading labels distinguish the student route, working assumptions and editorial limits. Cover/footer/metadata identify the second edition. No other guide rewrite or new content review was undertaken.

## Source and navigation preservation

The complete upstream and all40 V1 derived body views are byte-identical to the assessed first edition. Accepted style/config/fonts,external V0 AUX,notes/print/notebook/template entries are unchanged. The prior finite16 English/6 presentation edits remain exactly reversible to author views. All90 proof bodies,71 full answer sources/content,269 protected formal regions and ordered mathematical tokens preserve the first-edition verifier results; this is a source guard, not a repeated proof review. All322 current AUX values,folios and destination IDs equal the first edition; all122 page labels,109 bookmarks and189 internal/6 remote link semantics are equal. No page-number shift or new citation target occurred. V0 was not rebuilt or changed.

## Actual build and local visual scope

The incremental warm build converged in2 passes; white printing converged in3. The actual current PDF has122 pages, raw SHA256 e8f9115d990ea6b5486586d060fa3c748dd8ffd87a6ff2b7caa65ac4bd4f6b9c. Zero hard,missing-glyph,unresolved-reference,overfull or header diagnostics. One inherited underfull1082 paragraph remains at section58 lines31–36, already actually accepted at physical55 in the first edition and now retained on an unchanged page; it is not concealed or called a fresh visual review.

Actual full-page Poppler renders of current physical1,2,3 were viewed: edition cover, changed guide and neighboring contents. Guide stays on one page, with readable lead-ins and no clipping, overlap, missing glyph or new severe gap. Exactly120 pages match the accepted first edition above the bottom6%, both in72DPI pixels and text geometry. Physical3 overlaps actual review and unchanged-page comparison. The footer edition string and unchanged folio were separately checked on every noncover page. The first edition's actual122-page visual record remains under provenance/first-edition/qa; no claim of fresh all122-page visual inspection is made this round. Current coverage and render hashes are in qa/render-manifest.json.

The white print entry was really rebuilt. All122 warm/white pages have identical nonspace glyphs/origins/bounds/fonts/sizes,folios,bookmarks and link semantics. White physical2 was actually viewed and passed. Blank entries are exact accepted first-edition sources; their prior build/review is reused. No redundant white/blank output is delivered.

## Fresh measurements and delivery

Current prose samples3029,character median75,p90=81,max88 under the verifier's documented selection rule; these were recalculated, not copied as assumptions. Fresh body/secondary contrast12.9579660104/7.7229610724 on F5F1E7,with242A28/454D49. Current glyph/baseline sample method/counts are in reading-measurements.json. English Babel left/right minima2/3 unchanged; the fresh normalized adjacent-body-line diagnostic has zero short-fragment hits and does not replace actual visual review. Color/contrast are readability checks, not medical effects or universal comfort claims.

The complete editable package includes current raw PDF,exact source maps,frozen input/rollback,fonts/licenses,design/English rules,workflow contract,first-edition historical evidence,original responses,decision and current QA. MANIFEST.json includes every packaged file except itself. Source bytes/manifest/recovery and persistent-PDF page/render equivalence are verified in the separate saved-output report after upload/download. Any PDF C2PA/container byte difference is recorded separately from page equivalence, without claiming byte identity or signature trust.

## Remaining limits and next step

Only the single existing feedback round was handled. Six inherited global gates remain OPEN and Lawvere–Rosebrugh body/exact external correspondence UNKNOWN, with the exact register under upstream/REMAINING-GATES.json. No new mathematics defect was established or sent to refiner. Step14 belongs to dot's closing explanation, not another mathematical/editorial approval round. This is not EN-STABLE, exhaustive literature verification or formal complete-volume acceptance. Original first edition remains available; no cloud deletion, GitHub operation or other-volume modification occurred.
