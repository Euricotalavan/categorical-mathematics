# Volume 1 — F1 / Study L2 second editorial edition

A bounded successor to the fixed first editorial source version2 (SHA256 af88d2fecaa25d90335a0cd3343c9a65e66364b2507ddcb7786862d2fb3db8bc) and PDF version0,122 pages. Both Step11 original replies were read in full; neither raised an objection. At Step12 the editor adopted the sole optional P2. Step13 adds only three bold guide lead-ins: Reading route, Working assumptions, Editorial status and limits. Removing them restores every original guide byte and paragraph order. Cover/footer/PDF edition identification changes accordingly. The mathematical body,40 derived views, frozen upstream and other volumes are unchanged. The current real PDF remains122 pages.

## Contents and recovery

- Current warm PDF and complete editable XeLaTeX entries are at the package root/layout/study. Study settings, seven licensed fonts, pf/problem/psolution and English hyphen minima2/3 remain unchanged.
- `upstream/` preserves the complete691-manifest F1 input and rollback; `provenance/source-map.json` preserves canonical/view/derived relations. No generated view is promoted to canonical.
- `editorial/step12-13/` contains both actual original responses, exact overlay guards, receipt and Step12–13 decision. The original four batches and finite16 English/6 layout ledgers are historical first-edition work, not repeated here.
- `provenance/first-edition/` preserves original manifest/docs/QA. The first source version2 and PDF version0 remain the rollback identities. No historical ZIP or PDF is nested here.
- Current `QA.md`/`qa/` distinguish three actual current visual reviews from120 unchanged above-footer pages whose accepted first-edition coverage is carried. Edition footer/folios are checked separately on every page. `MANIFEST.json` hashes the current package except itself.
- The paired saved-output verification and Step14 handoff outside this ZIP record actual saved IDs/versions/hashes and redownload checks, avoiding circular self-hashes.

## Build

Use Python3.10+, full XeLaTeX/TeXLive (or equivalent), Babel English patterns, `fontspec`, `unicode-math`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `geometry`, TikZ/`tikz-cd`, `fancyhdr`, `titlesec`, `needspace`, `enumitem`, `caption`, `booktabs`, `array`, `etoolbox`, `xcolor`, `placeins`, `xr-hyper` and `hyperref`. Seven OTF fonts and licenses are included; Latin Modern Mono is supplied by TeX. PDF verification uses PyMuPDF; optional rendering uses Poppler/Pillow.

From this package root:

```sh
python3 verify.py --pdf
python3 build.py
python3 build.py --entry print
python3 build.py --entry notebook
python3 build.py --entry template
python3 package.py
```

`verify.py --pdf` validates the included actual PDF and recorded AUX without rebuilding. `build.py` uses incremental XeLaTeX, shell escape disabled, and rejects hard/overfull/header diagnostics; it preserves `.build/` intermediates. The warm output is refreshed only on success. One underfull1082 diagnostic was actually inspected and accepted; it is retained in QA rather than hidden. Font/toolchain/time changes can change build bytes; validate actual output and references as well as source hashes.

## Correct current V0 link dependency

`layout/external/volume-0.aux` is copied from the actual accepted V0 second-edition source v5, not historical CP58. The exact V0 source/PDF identities and hashes are in `provenance/inputs.json`. Four target labels were independently resolved against the actual accepted V0 PDF v1; all six V1 external PDF annotation actions are `/GoToR` to `volume-0.pdf` with current named targets. `provenance/v0-remote-targets.json` records display values/folios and physical target pages.

For distribution, save that accepted V0 second-edition PDF alongside this V1 PDF as **volume-0.pdf**. Its native Library ID is `libfile_fde3_f-a3482ecc25d08191b87c8271fb6ea8d0_383d682b1c388191a1961becbec9fb77`, fixed PDF version1/file `file_000000006c7481fb87a235ee5fc186e6`, SHA256 `d4d7996be987225b6d90266a905a60e910d747254f729d97df8f3f4019b6f459`. No duplicate V0 PDF is packed here. Local PDF viewers may support sibling-file actions; browser previews may not. Actual link dictionaries and target destinations were verified, not a claim that every viewer opens them.

## Workflow and limits

Steps12–13 are complete. Dot receives the paired edition, decision and saved-output audit for Step14 explanation; no new Step11 review round or mathematical task is requested. Six global gates remain OPEN and LR body/exact external correspondence UNKNOWN. Working empty-category admission remains the accepted convention with local witnesses. This is not EN-STABLE, exhaustive-reference certification or formal complete-volume acceptance. No V0 rewrite, cloud deletion or GitHub operation occurred.
