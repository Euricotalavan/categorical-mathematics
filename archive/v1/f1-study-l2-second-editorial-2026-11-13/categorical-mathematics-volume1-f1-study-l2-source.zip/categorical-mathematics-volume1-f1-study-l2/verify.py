#!/usr/bin/env python3
"""Verify exact V1 F1 intake, finite editorial overlays and actual current PDF; not mathematics certification."""
from pathlib import Path
import json,hashlib,re,argparse,unicodedata,subprocess,sys
from editorial_tools import protected_regions,math_regions
from aux_labels import labels as aux_labels
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def j(n):return json.loads((R/n).read_text())
def math_normal(s):
 s=re.sub(r'^\\\[|\\\]$|^\\\(|\\\)$|^\$|\$$','',s.strip())
 s=re.sub(r'\\(?:allowbreak|quad|qquad|enspace)\b|\\[,;!]','',s)
 return re.sub(r'\s+','',s).rstrip('.,;:')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pdf',action='store_true');a=ap.parse_args()
 upstream=j('upstream/MANIFEST.json');assert len(upstream)==691
 for x in upstream:
  p=R/'upstream'/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],x['path']
 source=j('upstream/SOURCE-SHA256.json');assert len(source)==623
 for n,h in source.items():assert sha(R/'upstream/source'/n)==h,n
 pairs=j('upstream/source/author-volumes/source-view-manifest.json');assert len(pairs)==254
 all_labels=[]
 for x in pairs:
  c=R/'upstream/source'/x['canonical'];v=R/'upstream/source'/x['view'];assert sha(c)==x['canonical_SHA256'] and sha(v)==x['view_SHA256']
  cl=re.findall(r'\\label\{([^}]+)\}',c.read_text());vl=re.findall(r'\\label\{([^}]+)\}',v.read_text());assert cl==vl;all_labels+=cl
 assert len(all_labels)==len(set(all_labels))==2155
 mapping=j('provenance/source-map.json');assert len(mapping)==40;ledger=j('editorial/edits.json')+j('editorial/layout-edits.json');local=[];refs=[];proofs=0;formal_bytes_equal=0;formal_total=0
 for x in mapping:
  c=R/'upstream/source'/x['canonical'];assert sha(c)==x['canonical_SHA256']
  v=(R/x['view']).read_text();s=(R/x['layout_view']).read_text();assert hashlib.sha256(v.encode()).hexdigest()==x['base_view_SHA256']
  reverse=s
  for e in reversed([e for e in ledger if e['logical']==x['logical']]):
   assert reverse.count(e['after'])==1,e;reverse=reverse.replace(e['after'],e['before'],1)
  assert reverse==v,('Unknown source mutation',x['logical'])
  assert [math_normal(z) for z in math_regions(v)]==[math_normal(z) for z in math_regions(s)],('Math changed',x['logical'])
  pv=re.findall(r'\\begin\{proof\}.*?\\end\{proof\}',v,flags=re.S);ps=re.findall(r'\\begin\{proof\}.*?\\end\{proof\}',s,flags=re.S);assert pv==ps,('Proof changed',x['logical']);proofs+=len(ps)
  old=protected_regions(v);new=protected_regions(s);assert len(old)==len(new)
  for (_,_,aa),(_,_,bb) in zip(old,new):
   formal_total+=1;formal_bytes_equal+=aa==bb
   assert re.sub(r'\\(?:leavevmode|par)\b|\s+','',aa)==re.sub(r'\\(?:leavevmode|par)\b|\s+','',bb),'Formal content change'
  ls=re.findall(r'\\label\{([^}]+)\}',s);assert ls==x['labels'];local+=ls
  assert re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',v)==re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',s)
  refs+=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',s)
 assert len(local)==len(set(local))==322 and proofs==90 and formal_total==269
 actual_order=[x+'.tex' for x in re.findall(r'\\input\{\.\./views/v1/([^}]+)\}',(R/'layout/study/volume-1-study.tex').read_text())];assert actual_order==[x['logical'] for x in mapping]
 for x in j('provenance/template-map.json'):assert sha(R/x['path'])==x['SHA256']
 guide=(R/'layout/study/reading-guide.tex').read_text()
 overlay=j('editorial/step12-13/reading-guide-overlay.json')
 assert hashlib.sha256(overlay['before'].encode()).hexdigest()==overlay['before_SHA256']
 assert hashlib.sha256(overlay['after'].encode()).hexdigest()==overlay['after_SHA256'] and guide==overlay['after']
 for heading in overlay['headings']:
  token=r'\textbf{'+heading+'} ';assert guide.count(token)==1;guide=guide.replace(token,'',1)
 assert guide==overlay['before']==(R/'upstream/source/content-refinement/v1/scope-and-reading-order.tex').read_text(), 'Unexpected guide content mutation'
 issues=j('upstream/ISSUES.json');assert len(issues)==5 and all(not x['unresolved'] for x in issues)
 for x in issues:
  if 'canonical' in x:assert sha(R/'upstream/source'/x['canonical'])==x['after_sha256']
 answers=j('upstream/review/ANSWER-WINDOWS.json');assert len(answers)==71
 for x in answers:assert sha(R/'upstream/source'/x['answer_canonical'])==x['answer_sha256']
 external=aux_labels(R/'layout/external/volume-0.aux');assert set(refs)<=set(local)|set(external)
 inputdata=j('provenance/inputs.json');assert sha(R/'layout/external/volume-0.aux')==inputdata['accepted_V0_second_edition']['imported_aux_SHA256']
 report={'frozen_package_manifest_items':691,'frozen_source_files':623,'canonical_view_pairs':254,'all_context_unique_labels':2155,'V1_sources_in_author_entry_order':40,'V1_unique_labels':322,'all_90_explicit_proofs_byte_unchanged':True,'protected_formal_regions':formal_total,'formal_regions_byte_unchanged':formal_bytes_equal,'formal_region_layout_only_changes':formal_total-formal_bytes_equal,'all_71_complete_answer_sources_and_contents_retained':True,'all_ordered_delimited_math_tokens_unchanged_except_layout_and_sentence_punctuation':True,'English_edits':len(j('editorial/edits.json')),'presentation_edits':len(j('editorial/layout-edits.json')),'all_edits_exactly_reversible_to_author_view':True,'all_five_F1_repairs_retained':True,'V1_scope_words_and_order_exact_F1_with_three_declared_leadins':True,'Study_config_style_fonts_exact_accepted':True,'external_V0_labels_used':sorted(set(refs)-set(local)),'medical_or_mathematics_completeness_claim':False}
 if a.pdf:
  import fitz
  p=R/'categorical-mathematics-volume-1-f1-study-l2-editorial-candidate.pdf';d=fitz.open(p);fonts=set();links={'internal':0,'remote_V0':0,'URI':0};names=d.resolve_names();lines=[];bboxes=[]
  auxpath=R/'.build/volume/volume-1-study.aux'
  if not auxpath.exists():auxpath=R/'qa/build-evidence/volume-1-study.aux'
  aux=aux_labels(auxpath);assert set(local)<=set(aux)
  for k in local:assert aux[k]['destination'] in names,k
  for i,pg in enumerate(d):
   text=pg.get_text();assert '??' not in text and '\ufffd' not in text
   for block in pg.get_text('dict')['blocks']:
    for line in block.get('lines',[]):
     bb=line['bbox'];assert bb[0]>=-1 and bb[1]>=-1 and bb[2]<=pg.rect.width+1 and bb[3]<=pg.rect.height+1,(i+1,bb)
     spans=line['spans'];t=unicodedata.normalize('NFKC',''.join(s['text'] for s in spans));body=[s for s in spans if 'Schola' in s['font'] and 'Math' not in s['font'] and abs(s['size']-11.5*72/72.27)<.2]
     if len(t)>=30 and sum(len(s['text']) for s in body)>=.55*len(t):lines.append(len(t))
   for lk in pg.get_links():
    if lk['kind'] in [fitz.LINK_GOTO,fitz.LINK_NAMED]:assert 0<=lk['page']<len(d);links['internal']+=1
    elif lk['kind']==fitz.LINK_GOTOR:
     assert lk['file']=='volume-0.pdf',lk
     if lk.get('page',-1)>=0:assert lk['page']<367
     else:assert lk.get('to') in {x['destination'] for x in external.values()},lk
     links['remote_V0']+=1
    elif lk['kind']==fitz.LINK_LAUNCH and lk.get('file','').startswith('volume-0.pdf#nameddest='):
     # PyMuPDF exposes a named GoToR as kind3; inspect the actual PDF action.
     target=lk['file'].split('#nameddest=',1)[1];obj=d.xref_object(lk['xref'])
     assert '/S /GoToR' in obj and '/F (volume-0.pdf)' in obj and '/D ('+target+')' in obj
     assert target in {x['destination'] for x in external.values()}
     links['remote_V0']+=1
    elif lk['kind']==fitz.LINK_URI:links['URI']+=1
    else:raise AssertionError(lk)
   fonts.update((f[0],f[3]) for f in pg.get_fonts(full=True))
  for x,n in fonts:assert d.extract_font(x)[3],n
  assert any('ScholaMath' in n for _,n in fonts)
  expected=j('qa/label-semantics.json') if (R/'qa/label-semantics.json').exists() else None
  if expected is not None:assert all(aux[x['label']]==x['AUX'] for x in expected['entries'])
  pct=lambda q:sorted(lines)[min(len(lines)-1,round((len(lines)-1)*q))]
  report['PDF']={'file':p.name,'bytes':p.stat().st_size,'SHA256':sha(p),'physical_pages':len(d),'bookmarks':len(d.get_toc()),'links':links,'embedded_fonts':sorted(n for _,n in fonts),'prose_line_sample_count':len(lines),'prose_characters_p50':pct(.5),'prose_characters_p90':pct(.9),'prose_characters_max':max(lines),'all_322_labels_resolve_in_actual_current_PDF':True}
 (R/'qa/source-and-pdf.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
