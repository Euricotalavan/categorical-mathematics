# Volume 1: accepted Study direction retained

The user accepted Study L2. This is its V1 adaptation, not a redesign or a website UI transfer. Exact style, configuration and font hashes are recorded in `provenance/template-map.json` and verified. The local adapter supplies V1 metadata and preserves the author entry's counter semantics, including global equation numbering and Chapters10–28.

| Parameter | Actual retained value |
| --- | --- |
| Page / text width | A4 /147mm |
| Margins L/R/T/B |27/36/23/23mm |
| Body / baseline |11.5/15.8 TeX points |
| Text / math / structural font |TeX Gyre Schola /Schola Math /Heros |
| Paragraph indent / gap |0 /4pt with accepted glue |
| Display skip |7pt plus2pt minus2pt |
| Paper / body / secondary / accent |F5F1E7 /242A28 /454D49 /2D5660 |
| Recomputed body / secondary contrast |12.957966 /7.722961 |
| English patterns and minima |Babel English, left2/right3 |
| Proof / exercise conventions |pf /problem /psolution |

All90 explicit proof bodies are exact input bytes. Existing paragraph strategy and the disclosed finite-list/existence tests remain visible. Short pairs may stay inline with a permitted break between complete pairs; long full-answer equalities and relation sets were displayed without shrinking. One long exercise heading receives a local statement break. Two bounded `Needspace` guards keep short final question/answer blocks together; long proofs remain breakable. No global letter spacing, padding to add pages, font reduction or ornament was introduced.

Two near-empty chapter-end pages were removed by concise narrative retaining the same chapter route and qualifications. Some shorter chapter endings remain intentionally because chapters begin on new pages and complete question/answer units are kept coherent. The final122 physical pages are layout, not an amount of new mathematics or a content-completion certificate.

Actual current line measurements and glyph-size/baseline samples are in `qa/reading-measurements.json`. Contrast is only one readability check; warm color does not imply medical eye protection or comfort for every person/screen. White printing has identical text geometry, folios and link targets across all122 pages. Prior third-party design-method attribution/font licenses remain under design/ and licenses/; those website analyses are not official brand standards, and no hero/card/CTA is transplanted.

## Bounded second-edition change

Only three bold lead-ins separate the existing guide paragraphs; original words/order are preserved byte-for-byte under exact overlay guards. Edition identification changes on cover/footer/metadata. No body, font, color, geometry or spacing redesign. The current actual guide and neighboring cover/contents were visually checked; unchanged pages carry first-edition coverage with explicit above-footer matching and separate footer/folio checks. Current warm/white measurements and actual review are in qa/.
