# V1 Step12 decision and Step13 disposition

Both formal original replies were actually received and read in full, against the fixed first-edition source v2/PDF v0,122 pages. Their exact IDs,versions and SHA256 are recorded in receipt-and-decision.json; originals are included here.

| Original role | Reply | Editor decision |
| --- | --- | --- |
| Content refinement | NO OBJECTIONS; no repair requirement | Accept the reply; no math/editorial repair opened. |
| Content expansion | NO OBJECTIONS to proceeding; optional P2 guide separation | Adopt P2 now, with exactly three bold lead-ins. |

The optional suggestion improves scanning between student route, working assumptions and editorial limits. Removing the three added lead-in tokens recovers the exact original guide bytes, including every foundation/choice/size/empty-category/PL09/LR qualification. Cover/footer/metadata identify the second edition. No other content or layout redesign occurred.

Step13 completed: real122-page incremental warm/white builds; actual current full-page reviews1–3 and white2 pass;120 remaining above-footer pages equal the already visually accepted first edition. All source/body/navigation/folio guards pass, with no new hard/overfull diagnostic. One previously accepted underfull remains disclosed. Measurements were refreshed. Saved pair and redownload/recovery evidence are in the companion delivery-verification report, not an invented pre-upload identity.

First source v2 and PDF v0 remain rollback versions. The next workflow step is dot14 explanation, with no new Step11 round, approval stop, reproof or new boundary. Six inherited global gates OPEN and LR UNKNOWN remain; no EN-STABLE, exhaustive-reference or formal complete-volume claim. No cloud deletion, V0 rewrite or GitHub operation.
