# Volume 1 — F1 / Study L2 first editorial edition

This is a real 122-page current V1 PDF and editable independent successor of the fixed content-refinement F1 source v2, not an old V1 PDF relabelled. Chapters 10–28 and all 40 selected inputs are present in the author's order. Four consolidated editorial batches complete workflow steps8–10. The refiner judged the agreed content sufficient; the editor did not repeat the mathematics review.

This is a first editorial candidate for the two independent Step11 responses, not EN-STABLE or complete-volume acceptance. Six global gates remain OPEN and Lawvere–Rosebrugh body/exact external correspondence UNKNOWN.

## Structure and recovery

- `categorical-mathematics-volume-1-f1-study-l2-editorial-candidate.pdf`: current warm Study PDF.
- `layout/study/volume-1-study.tex`: current V1 entry; `config.tex` and `layout/shared/style.tex` are exact accepted Study v0.2-r1 bytes. `print.tex` preserves white printing. `notebook.tex`, `template.tex` and `notes.tex` provide editable authoring/worksheet entries; the final volume includes the notes page.
- `upstream/`: exact 691-manifest input package, including its complete623-file source, four selected-canonical repairs, current V1 scope, exact patch/rollback and content-refiner reading/proof/answer evidence. It is immutable input evidence, not the editor's modified canonical tree. Historical other-volume files in it are recovery context only.
- `layout/views/v1/`: editable derived V1 presentation; never treat these generated views as new canonical sources. `provenance/source-map.json` records all40 canonical/view/derived relationships and author order.
- `editorial/edits.json` and `layout-edits.json`: exact reversible16 English and6 presentation edits. All90 explicit proofs are byte-identical;268 of269 protected formal regions are byte-identical and the remaining exercise has only an inserted paragraph break after its long title. All71 full answers and ordered mathematical tokens are retained.
- `qa/`, `QA.md`, `DESIGN.md` and `editorial/REVIEW-SUMMARY.md`: actual build, all-page visual record, navigation and measurements. `provenance/workflow/book-workflow-v1.md` retains the received contract.
- `MANIFEST.json`: all current packaged files except itself. There is one current raw PDF, no historical PDF or nested ZIP. Source checkpoint versions are recovery saves, not extra formal editorial iterations. The author/refiner originals and accepted V0 remain separate.

## Build

Use Python3.10+, full XeLaTeX/TeXLive (or equivalent), Babel English patterns, `fontspec`, `unicode-math`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `geometry`, TikZ/`tikz-cd`, `fancyhdr`, `titlesec`, `needspace`, `enumitem`, `caption`, `booktabs`, `array`, `etoolbox`, `xcolor`, `placeins`, `xr-hyper` and `hyperref`. Seven OTF fonts and licenses are included; Latin Modern Mono is supplied by TeX. PDF verification uses PyMuPDF; optional rendering uses Poppler/Pillow.

From this package root:

```sh
python3 verify.py --pdf
python3 build.py
python3 build.py --entry print
python3 build.py --entry notebook
python3 build.py --entry template
python3 package.py
```

`verify.py --pdf` validates the included actual PDF and recorded AUX without rebuilding. `build.py` uses incremental XeLaTeX, shell escape disabled, and rejects hard/overfull/header diagnostics; it preserves `.build/` intermediates. The warm output is refreshed only on success. One underfull1082 diagnostic was actually inspected and accepted; it is retained in QA rather than hidden. Font/toolchain/time changes can change build bytes; validate actual output and references as well as source hashes.

## Correct current V0 link dependency

`layout/external/volume-0.aux` is copied from the actual accepted V0 second-edition source v5, not historical CP58. The exact V0 source/PDF identities and hashes are in `provenance/inputs.json`. Four target labels were independently resolved against the actual accepted V0 PDF v1; all six V1 external PDF annotation actions are `/GoToR` to `volume-0.pdf` with current named targets. `provenance/v0-remote-targets.json` records display values/folios and physical target pages.

For distribution, save that accepted V0 second-edition PDF alongside this V1 PDF as **volume-0.pdf**. Its native Library ID is `libfile_fde3_f-a3482ecc25d08191b87c8271fb6ea8d0_383d682b1c388191a1961becbec9fb77`, fixed PDF version1/file `file_000000006c7481fb87a235ee5fc186e6`, SHA256 `d4d7996be987225b6d90266a905a60e910d747254f729d97df8f3f4019b6f459`. No duplicate V0 PDF is packed here. Local PDF viewers may support sibling-file actions; browser previews may not. Actual link dictionaries and target destinations were verified, not a claim that every viewer opens them.

## Next stage

Dot should deliver this fixed first edition separately to expansion and refinement for one explicit Step11 response each. Missing responses are not no-objection replies. The editor then makes the Step12 decision. Do not re-expand optional GAP-V1-03, reprove the volume, reopen working empty-category admission, merge historical context over active volumes, or submit GitHub as part of this handoff. The companion saved-output verification and YAML handoff record actual final IDs, versions, hashes and recovery results after upload/download.
