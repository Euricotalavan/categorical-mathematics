# V1 F1 Study L2 — first editorial edition QA

## Exact intake and role boundary

Fixed content source Library version2/file `file_0000000066b882069d4a87076dffa38d`:2,307,983 bytes, SHA256 `925a60f1b853ed9d67806dbca7e6253a34e268106145bebe703912015cb59e13`. ZIP integrity, safe paths, all691 manifest entries and all623 source files passed. The full editor handoff, repair conclusions, five resolved issue records and current V1 scope were actually read. The refiner's sufficient-content decision is accepted; no new proof review, boundary return, GAP-V1-03 expansion or mathematical task was opened.

The complete source/rollback evidence remains unchanged under upstream/. All254 context canonical/view pairs and2,155 unique context labels pass their hashes. All40 selected V1 views are loaded in the author's actual19-chapter entry order. Other-volume historical context is not merged over any active source; V0 was neither rebuilt nor changed.

## Four consolidated batches and preservation

1. Exact intake, five-issue retention, accepted Study entry and actual V0 second-edition label mapping.
2. First-half English narrative review in entry order, retaining supplied assumptions and tests.
3. Remaining narrative review, local equation/answer placement and status consistency. All8 bounded narrative excerpts were actually read;13 initial/follow-up edits plus3 chapter-end refinements produce16 exact English edits in the finite ledger. Six presentation edits are separate. This is not another mathematical review of the refiner's90 proofs.
4. Actual current PDF convergence, all-page visual QA, external navigation, white entry, recoverable source and persistent-output verification.

The verifier reverses every exact edit to its original author view byte hash. All90 explicit proofs remain byte-identical. Of269 protected formal regions,268 are byte-identical; one exercise only has a paragraph break separating its long heading. All71 complete-answer sources/content are retained; two answers receive display/sentence punctuation changes, not content removal. Ordered delimited mathematical tokens are identical after declared layout/sentence punctuation normalization. Labels and ref order are retained. The five F1 repairs, external finite-list rule, both finite-cone comparison inverse equations, four full finite-diagram answers and post-NNO assumption map survive.

No new mathematical concern was established in the editorial scope. A derived initial-object narrative sentence was synchronized to the already adopted working empty-category admission, while local witnesses and formal-framework questions remain. Canonical source was untouched. Exact issue dispositions are in qa/editorial-issue-list.json.

## Actual build and navigation

The actual current PDF has122 physical pages: cover, exact F1 reading guide, contents, Chapters10–28 and optional working notes. Raw bundled PDF SHA256 is `b339b0342c3400ed0da1175ea0b11c1b4d468cf0e9e938f5b0bbe557bd96b57a`. It is a new matching F1 build, not an old V1 PDF. The final volume build converged in2 incremental passes with zero hard errors, missing glyphs, unresolved references, overfull or header diagnostics. One underfull1082 message remains at section58 lines31–36; actual physical55/printed50 was inspected at full-page scale and accepted without severe visible gaps. No diagnostic was hidden or claimed zero.

All322 V1 labels resolve in the actual PDF;109 bookmarks and189 internal link actions are valid. All6 external named GoToR actions target the accepted V0 second-edition PDF v1 via its source-v5 AUX. Four unique referenced labels were checked against that actual V0 PDF, including physical24/printed14 for the external finite-syntax rule. This avoids using historical CP58 folios. PyMuPDF exposes named remote actions through a kind3 convenience representation; the actual PDF dictionaries have `/S /GoToR`, the correct sibling filename and named destination. No unnecessary PDF action rewrite occurred. Distribution/viewer limits are explained in README.md.

## Actual visual coverage

Every one of the final122 pages was actually inspected from current Poppler full-page renders, organized in31 sequential2x2 review sheets. Each final PNG hash and actual review timestamp is recorded in qa/render-manifest.json. This is full current visual coverage, not inherited old-V1 QA or tool statistics. Full-page details additionally viewed physical14,15,55,84,118 and120: finite products and external rule, finite-cone construction, diagnostic paragraph, long relation-associativity proof, parameter recursion and closing package map. The closing notes/UNKNOWN page was included in actual coverage.

The initial five overfull lines were repaired by a concise reason, inline pair-break opportunities, complete displayed equality/relation sets and an exercise-title break. Two near-empty chapter-end pages were corrected by preserving the same narrative route more concisely, giving124→122 pages. Two bounded short exercise/answer guards keep their blocks together. Final page review found no clipping, glyph loss, overlap or diagram-label collision. Some short complete chapter-ending exercise blocks and narrative bridges retain whitespace intentionally; proofs and answers were not cut to fit.

## Fresh readability measurements and alternate entries

Fresh current prose-line samples:3029; character median75,90th percentile81, maximum88 under the documented exact sample rule. Body/secondary contrast:12.957966/7.722961, paper F5F1E7, body242A28, secondary454D49. Actual glyph/baseline values and full design parameters are recorded separately. These diagnose readability, not medical effects, quantified aesthetic superiority or universal comfort.

English Babel left/right minima remain2/3. The supplementary normalized body-line scan has no short-fragment hits; all actual pages were also inspected. The white print entry was built and all122 pages match warm output in nonspace text/glyph positions, fonts/sizes, folios, bookmarks and link semantics. Its finite-product physical14 was actually viewed. Accepted blank entry/style/font evidence is reused; the reusable template only adapts CurrentVolume to1. No redundant white/blank PDF is delivered.

## Recovery, publication limits and Step11

The source package contains current editable XeLaTeX, fonts/licenses, English/design rules, exact frozen input/patch/rollback, current V0 cross-reference AUX, source maps, finite editorial ledgers, all-page QA and current raw PDF. No historical ZIP/PDF is nested. The companion delivery-verification JSON and formal handoff YAML record actual saved IDs/versions/hashes and fresh download/recovery results. Source checkpoint versions are recoverability saves, not formal iterations or approval stops.

This is the first editorial candidate for two explicit independent Step11 responses. Dot should send it separately to expansion and refinement; the editor's Step12 decision follows both. Six inherited global gates remain OPEN and LR body/exact external correspondence UNKNOWN as in upstream/REMAINING-GATES.json. Working empty-category admission is not reopened; model comparisons do not adopt a common foundation. No EN-STABLE, exhaustive-reference or complete-volume acceptance claim is made. No cloud deletion or GitHub operation occurred.
