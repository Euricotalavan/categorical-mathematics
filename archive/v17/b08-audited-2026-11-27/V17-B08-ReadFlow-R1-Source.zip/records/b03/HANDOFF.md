# V17-B02-B03-20261127-v1

**B single Work. V17, Chapters 224–231. Design and representative calibration are complete.**

The fixed B-01 source and coverage checkpoint is `V17-B01-Checkpoint-v1.zip`, version 0, 94,252 bytes, SHA-256 `d8c2950045e67bfe44b6df9f02648d124cbe8e645f2794f0551b057e7f1ab4b5`. It was recovered and matched bit for bit. B-01 checkpoint

Senders are expansion, thickening, refinement and main controller. Receivers are the assigned B-04 expansion lines, followed by independent thickness and precision. Receipts in this package distinguish actual reads and permissions. The user authorized the full sequence, independent roles and principal review of the otherwise manual gates. Roles used the settings recorded with the B-01 authorization and individual receipts. The applicable Git chapter basis and predecessor inputs remain those recorded in B-01. B-02 integrates design and prerequisites. B-03 calibrates two actual sections with supported claims, examples and proofs.

B-02 fixed 37 numbered sections and one prerequisite prelude. Independent refinement verified exact coverage of 177 adopted obligations and separation of 65 deferred items. Exact book design SHA-256 is `01a3766e1172c226bec2e4188412e440cea173eacaa96ee539596b38c32010ec`. Fixed section mapping and precision reports ship with this package. The scope of each earlier source is preserved. Myers retains the source-error record and no dependency in the accepted HK comparison. Bartle and the 1990 Dover working text remain UNKNOWN. The Blackie missing p. 104 falls outside the selected central source passages.

B-03 authorship, thickening and independent precision were completed separately for §227.3 and §229.3. The accepted source pair and conditions are in `CONTENT-GATE.md`. The integrated engineering sample uses the three fixed ReadFlow R1 files and adopted fonts. Two initial running headers in the wrapper were corrected by clearing the preceding page before changing a counter and using an empty page style for the context page. Neither accepted body file changed. The 15 physical pages were visually checked, with the two corrected pages viewed again. The short ending on sample page 7 is caused by the excerpt boundary. It is retained as a calibration layout observation and does not prescribe a break in the complete Chapter 227.

The fixed calibration PDF is 102,757 bytes, SHA-256 `8de6ca076814354775a68d12766c38d9cf8f87d559225125349838945d2f4609`. Exact source/PDF build report is included. For a local rebuild after extraction, run the following from the bundle root:

```sh
python editor/build-v17.py --book-root editor/calibration-preflight --entry layout/study/calibration.tex --output-dir rebuilt-calibration --dependencies-dir editor/dependencies --source-date-epoch 1795737600
```

V0 template archive version 3 and its exact hash remain in the B-01 record. The three core template files are byte-identical extractions. Neither B-03 nor the sample is a final B-06 layout or a B-07 whole-volume verdict.

Next authorized action is B-04. Reuse the exact calibrated sections once, complete the eight chapters through independent thickness and refinement, and verify every body location and proof before integration. The sample approvals do not stand in for adjacent chapter proofs. Keep the current chapter range, approved source scope, upstream volumes, fixed external bibliography tables and ReadFlow template. No user decision remains for this transition. Recipients have read the exact accepted samples and design. No outside publication forms part of this checkpoint.
