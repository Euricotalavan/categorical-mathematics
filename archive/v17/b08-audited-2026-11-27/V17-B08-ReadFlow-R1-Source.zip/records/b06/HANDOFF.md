# V17-B06-20261127-v1 — fixed ReadFlow R1 candidate

**Decision: B-06 complete; deliver this fixed candidate to the separate B-07 thickening auditor.** Content-preservation, engineering and reading-layout results are stated separately below. This is not terminal mathematical acceptance. One principal-approved protected continuation limitation is retained explicitly.

Date: 2026-11-27 UTC. Scheme: V17 B single Work. Sender: layout engineering/editor `/root/layout`; receiver: principal, then clean B-07 thickening auditor. B-06 corresponds to A08–09; B-07 remains the only terminal whole-volume mathematics audit. Actual runtime model version and reasoning intensity were not independently verified; no claim of a mode switch. Conversation URL: UNKNOWN.

## Exact input receipt

Read B-05 HANDOFF.md in full; SHA-256 `ab480de71a319085862c528fb48cd81c1c38055755bae07c49fdaf64f0e5ed36`. Fixed ten-file input manifest: `bc76fc6201db7b368389ace62d31dd812ba7162fadadd2c1008467f9e03063ab`; every input byte count/hash was recomputed before copying. Fixed body map: `ec089a08b06533302fa027ad405e4cb210a987684b5f487c4b2c5a4f051e0442`; OPEN register: `74e576995de7d3dcdc89b1b67e54804dcfe870f2b657f01b17d322bc17a5ef60`.

The independent precision and expansion B-05 gates and the B-02 common notation/design were read. B-05 already applied its bounded bibliography-range and complex-coefficient OPEN corrections. No B-05 file was written. The only B-06 body is the independent regular-file copy in `book/manuscript/`; no link points to a mutable canonical/B-05 tree.

Title: *Series, Improper Integrals, and Topics in Real Analysis*. Project: *Categorical Mathematics*. Chapters224–231 are continuous after the user-fixed V16 endpoint223. The applicable published numbering baseline remains V14 Git `bd68f94015bb93ec48fb0edcf9d794f632cba57c`, `archive/v14/b08-audited-2026-11-27/README.md`, through194; user-fixed V15 through207 and V16 through223 remain as received. Their own audit/freeze limitations are not cleared by B-06.

## The one fixed source/PDF pair

| Object | Relative path | Bytes | SHA-256 |
|---|---|---:|---|
| Portable regular-file source ZIP | V17-B06-Source-v1.zip | 9767157 | cfb0db20347014301031959de73c5d0ab465ea68cbdc6e6031dedce7443d36d4 |
| Source member manifest | book/SOURCE-MANIFEST.json | 6560 | 013ce346a1d5bff897ded691089dc955b98d9d46e241867e7ea0cb82d185fb63 |
| Matching reading PDF,92 physical pages | output/v17.pdf | 414209 | f0b436eedf4f6423936913dc6711c2621e9a4b395cf92851be779e12dbf3ce25 |
| B-06 body locations,177 rows | body-locations.tsv | 5477 | eaef47d4726682a15a5d3abf4be8fb6b120ea5ea50d0ed255d965428cd6f1871 |
| Content-preservation comparison | content-preservation.json | 5209 | 0ea84e1dfd8a0864e441f58c47b99cc3118d3598a5a38cd4abead99687349797 |
| Actual13-input FLS proof | actual-input-proof.json | 2956 | 4fd0835177b364e01b39ef967103a30f6af07a179ab416f26afb296b39ee4dbd |
| Moved/extracted clean rebuild comparison | restore-verification.json | 11331 | 799040222debb06ab6d3d9ad0e1e0ee2a71eaa541110a376a1453dc04ecc629c |

All other delivery evidence and per-file hashes are in `B06-MANIFEST.json`; that manifest does not self-hash. The source ZIP contains the39 declared source/dependency files plus SOURCE-MANIFEST.json. It contains no chapter duplicates, prior PDFs, historical V0 body, mutable links or private runtime caches. Sources are recoverable independently of this scratch path. Persistent saving is coordinated by the principal; this role does not claim a Git archive or B-08 acceptance.

## Fixed template, local adapter and build

Formal template: ReadFlow R1 Library version3; artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, adoption commit `c749e4867538888d3069346fa055ac2ca834c9e1`; original ZIP SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`. Core `readflow-base.tex`, `config.tex`, `readflow-layout.tex` remain exact. No body font size, leading, page dimensions, margins, palette or core environment was changed.

Local V17 adapter holds metadata, mainmatter-aware running context and the principal-authorised TOC number-box widths for three-digit labels. Cover/TOC/preface headers show Volume17 without Chapter0. `mainmatter` clears the prior page before chapter is set223; each chapter supplies its original chapter command. Backmatter clears chapter231 before the bibliography context.

Portable command from the source ZIP extraction directory:

```sh
python book/build-v17.py --book-root book --output-dir output --source-date-epoch 1795737600
```

Installed XeLaTeX/xetex, fontconfig, Poppler pdffonts and the R1 TeX packages are required; private indexes/format/font caches are generated in output/.runtime. The original nine font faces and licences are in book/dependencies; every face is hash-checked and private fontconfig excludes system substitutions. Engine auxiliaries go under output/engine. The B-06 harness copy rejects project TeX outside its fixed root; actual-input-proof.json identifies the ten manuscript files and three core files actually read. No shell escape or source mutation occurs. Exact machine paths, compiler version, fonts, warnings and command are in output/recipe.json; BUILD-RECOVERY.md explains relocation.

The initial output-directory relative-path mistake was caught as a failed diagnostic, never accepted. `first-path-diagnostic.json` records the observed excerpt and retention limit; the superseded original binary/log are not claimed retained. The synthetic shadow-file negative control was rejected, and the relocated clean build read its own book. No semantic issue was routed because the accepted edits were purely L or the one explicitly authorised equivalent E sentence.

## Results, separated

**Content preservation:** ten-file B-05 comparison; all non-layout source tokens retained after one explicit equivalent Cauchy introductory sentence. Every original condition, formula term/order, proof, example and solution remains. The199 labels and77 local references are identical and resolve;177 duties remain in their same planned sections;37 numbered sections and24 worked exercises/solutions are retained. §227.3 and §229.3 retain their accepted exact hashes and each occurs once. The whole ch227, ch226, ch230 and preface are byte-identical to B-05. This is independent preservation/diff checking, not a new proof-by-proof mathematical acceptance.

**Engineering:** final stable build PASS with exactly the two known full unicode-math/mathtools notifications, no additional warning allowlist, no overfull/underfull boxes, missing characters, unresolved references, unexpected/unembedded fonts, out-of-page spans, invalid internal links or footer collisions. Eight chapter bookmarks and37 section bookmarks retain correct destinations; all92 physical pages are present. Fonts and widths were checked by actual logs, embedding records, geometry scan and visible equations.

**Reading/layout:** all physical pages1–92 were rendered and inspected in order, with high-resolution checks at the named anomalies, tables/formulas, all chapter/front/back seams, QED/footer areas and reflowed units. `visual-review.tsv` gives every physical/printed page, sheet and outcome; `visual-review.json` gives resolution, exact coverage and limits. No page is marked uninspected. Exact change/old-new page/recheck records are in CHANGES.md and editorial.patch. No human comprehension, preference, print or accessibility test is claimed.

**Recovery:** clean ZIP extraction into a separate moved book with a separate format/font cache converged to92 pages. All pages have matching extracted text, links, bookmarks and108dpi pixels. The rebuilt PDF SHA-256 is `077f84bd5db96ce4fa3074c84bfb1750c4916fe37caa325cebc79566e78946ec`; it is not the delivered binary. The principal independently checked the difference as trailer ID only; the comparison evidence is separately retained. Hash equality was not substituted for visual or mathematical checking.

## Changes, OPEN and next stage

CHANGES.md lists14 local L/E repairs: two overflowing displays, local paragraph/formula formatting, short definition/question/example protection, the full endpoint-value sentence, TOC label spacing, and the final Aitken exercise+solution on existing p91. The unsuccessful preceding-example shortening was reverted; no protected byte was touched.

**B06-L15 KEEP:** protected Example227.11 ends on physical p34 and continues with the single word “unavailable.” on p35. The principal explicitly instructed preservation if the nonprotected short trial did not help. This is a retained minor editorial limitation, not an ideal break or hidden clearance. The complete condition/negation and continued label remain; B-07 receives the exact source/PDF.

Inherited Bartle/Dover/Blackie/source-error/upstream/scope OPENs are retained verbatim in B05-OPEN.md and carried in OPEN.md. Model/mode verification remains UNKNOWN. B-07 mathematical audit is pending and is the sole terminal decision. No known content blocker was found within layout scope, and no original source/scope unknown was cleared.

**Only next role: clean B-07 thickening audit on this fixed pair.** Pass criteria remain whole-volume actual mathematics/dependency/source responsibility and all reported defects, independently checked against the same fixed body/PDF. If not passed, return the located affected issue to its responsible role; every repair returns to B-07. Do not overwrite this candidate, reopen frozen volumes, reacquire already settled sources, alter the template or revive NO OBJECTIONS closure. No user decision is pending.

Delivery state: the principal received the formal decision and final hashes in a shared-workspace message, and independently read the fixed source/PDF and selected pages. Detailed evidence is now on disk. Actual B-07 receipt and terminal result belong to that role; this handoff does not invent its acknowledgement or acceptance. No Git upload or external message was sent by this task.
