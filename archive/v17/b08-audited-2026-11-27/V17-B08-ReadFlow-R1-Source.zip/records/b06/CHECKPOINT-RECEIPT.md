# V17 B-06 fixed checkpoint receipt

`V17-B06-Checkpoint-v1.zip`, version 0, 10,219,358 bytes. SHA-256 `dc70a3b9a030d076ac9e24cd68613f0d63a6ce123b276d95e1a1d42f78fc6f53`.

All 61 listed member sizes and hashes match and ZIP CRC passed. The version-pinned retrieval matched the local ZIP byte for byte. This recovery point contains the B-06 92-page pair, source, portable dependencies, exact compiled-file trace, page review, and ReadFlow R1 change record. Its separate B-07 revision supersedes it for final release acceptance. V17-B06-Checkpoint-v1.zip
