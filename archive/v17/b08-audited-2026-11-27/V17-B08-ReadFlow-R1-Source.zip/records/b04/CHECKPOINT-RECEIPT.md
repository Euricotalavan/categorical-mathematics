# V17 B-04 fixed checkpoint receipt

`V17-B04-Integrated-Checkpoint-v1.zip`, version 0, 406,571 bytes. SHA-256 `049cc49584a2f6c1c4b42f834fe857b7232ea7a6e382c4cad431d07845aae4a4`.

ZIP CRC passed and all 74 listed file hashes matched. The exact version was retrieved afterward. The retrieved ZIP compares byte for byte with the checked local ZIP. The file includes the fixed manuscript, the source map, the two protected samples and the separate author, thickness and precision receipts. V17-B04-Integrated-Checkpoint-v1.zip
