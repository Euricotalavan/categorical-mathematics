# V17 B05 bounded documentary corrections

Role: independent precision `/root/refine`. Date: 2026-11-27 UTC. These are proposed exact replacements, not mutations of canonical text. No proof, definition, chapter/section, marker, exercise, source PDF or protected sample changes.

## B05-D01 — selected source ranges omit material actually used

Input `v17-work/manuscript/bibliography.tex`, SHA-256 `1fae588d8b19f8a6eb9c0e6516dc7023b443d3c6531380a39c2b6aa9d0a6ba99`.

1. Lebl entry, current:

`Volume I Sections 3.2, 5.2 and 5.5, and Volume II Sections 10.3--10.4.`

Replace with:

`Volume I Sections 3.2, 5.2, 5.5 and 6.2, and Volume II Sections 10.3--10.4.`

Affected responsibility: 230-16–19, canonical ch230.tex §230.5. Fixed B01 integrals.tsv explicitly locates Ex.6.2.3, Thm.6.2.4, Ex.6.2.6 and Ex.6.2.22. All four actual body statements/proofs are present. This fixes the bibliography's selected-range description, not their mathematics.

2. Fonda entry, current:

`Sections 1.2--1.3, 1.8--1.12 and 1.15--1.16.`

Replace with:

`Sections 1.1--1.4, 1.6, 1.8--1.12 and 1.15--1.16.`

Affected responsibility: 229-02 (tagged partitions §1.1), 229-08/09 (elementary properties §1.4), 229-12 (countable support at end of §1.6). Verified against fixed B01 table/notes and local Fonda text headings and propositions. Existing selected ranges for Cauchy/Saks/comparison/Hake remain. Does not import all of §1.6 into textbook scope.

Recheck after application: exact replacement only in bibliography, all eight chapter SHAs unchanged, 177 body-map entries unchanged, both sample byte spans unchanged; update the manuscript manifest and receipt for the new bibliography SHA. No mathematical downstream repair is required.

## B05-D02 — historical OPEN boundary understates the current scalar field

Input `v17-work/b01/OPEN.md`, row `V17-ADV`, current phrase:

`Core 227 proves the two Tauber criteria in ordinary real series.`

For a current B05 addendum (preferred, retaining frozen B01 bytes), use:

`Core Chapter 227 proves the two Tauber criteria for real or complex coefficient series, with an Abel limit along real radii. Littlewood's stronger statement is recorded as a boundary result and is not used in the proofs.`

Evidence: canonical ch227.tex first problem, first criterion, protected second criterion; fixed B02 common field/real radial conventions and fixed tauber.tsv 227-01/05/10. The chapter is already correct. Keep the original B01 record recoverable, record correction in B05 OPEN/addendum rather than silently rewriting the fixed ledger or its hashes.

## Disposition

Neither finding blocks the mathematical reading path. D01 should be applied before freezing B05 front/back matter for B06. D02 should be acknowledged in the current handoff. Independent precision has not edited any input file.
