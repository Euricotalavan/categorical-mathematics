# V17 B-05 fixed checkpoint receipt

`V17-B05-Integrated-Checkpoint-v1.zip`, version 0, 186,898 bytes. SHA-256 `b1a59c3317bbceab552d7d9d445a5196ca2f520c7cc9ded3c5c1d667fdaa9690`.

ZIP CRC and all 33 listed member hashes passed. A version-pinned retrieval matched the original archive byte for byte. The archive holds the integrated body, its exact source-location map, both whole-volume content-role receipts and the documentary corrections. V17-B05-Integrated-Checkpoint-v1.zip
