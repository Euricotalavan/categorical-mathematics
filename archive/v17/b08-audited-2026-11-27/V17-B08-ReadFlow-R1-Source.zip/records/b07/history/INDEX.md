# V17 earlier defect records for B-07 reconciliation

Use this index after the independent first read has been recorded. Paths below are relative to the V17 work root. Current source boundaries and OPEN/UNKNOWN are conveyed separately in the audit intake.

|Phase|Exact change evidence|Verification and source|
|---|---|---|
|B-01|Source exceptions and source-dependent condition repairs in `b01/refinement-gate.md`, plus the three subject notes|The fixed source ledgers and their independent verification identify adopted, deferred and barred proof chains.|
|B-02|Design and revision history in `b02/design.md` and `b02/refinement-gate.md`|Stable section plan in `b02/target-locations.tsv`.|
|B-03|Representative section receipts and protected accepted bytes in the B-03 checkpoint|Calibration gate in `b03/CONTENT-GATE.md`. The body carries both accepted samples once.|
|B-04|Exact author→thickening→precision changes in `b07/history/b04-manuscript-changes.patch`|Separate `b04/thicken/ch*-review.md` and `b04/refined/ch*-review.md` contain each issue's location, impact and review. The paired versions can be recovered from the checkpoint recorded in `b04/CHECKPOINT-RECEIPT.md`.|
|B-05|Bibliography selection and Tauber scalar-field record in `b05/bounded-corrections.md`|Candidate closure and exact comparison at the end of `b05/refinement-gate.md`. The eight chapters and preface are unchanged.|
|B-06|Exact editorial changes and their rendered locations in the B-06 handoff and layout change record|Use the fixed candidate-specific source hashes, compiled-file trace, page coverage and visual review.|

Retain distinct dispositions for repaired defects, standing source limits and deliberate deferred scope. The auditor compares the current exact PDF and body to the applicable closure evidence and records any issue that still needs repair, with its actual current location.
