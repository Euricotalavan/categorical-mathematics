# V17 B07 revision change and reflow record

The three precision repairs are fixed inputs. The six presentation overlays are the entire further source difference. The source/PDF pair is fixed in `FIXED-PAIR.json`; the original B06 remains unchanged.

|Defect|File|Old physical pages|Final physical pages|Purpose|
|---|---|---|---|---|
|D01|ch226.tex|22–23|22–23|Complex inner-disk absolute convergence and generating identity; radial specialization explicit.|
|D02|ch225.tex|18|18|Complex inner-disk absolute convergence before the unchanged real radial Abel conclusion.|
|D03|ch228.tex|39–48|39–48|Finite-singularity improper value explicitly sums all components, with independent endpoints.|
|D04|ch227.tex|34–35|34–35|Replace unavailable hypothesis sentence with equivalent shorter condition-fails sentence.|
|D05|ch229.tex|62–63|62–63|Move entire inclusion-conclusion sentence to continued example with local Needspace.|
|D06|ch231.tex|82–83|82–83|Keep entire short induction paragraph and its resulting display together using samepage.|
|D07|ch229.tex|57–58|57–58|Complete measurable-bin partition assertion before its unchanged display.|
|D01-L|ch226.tex|precision trial 22–23|22–23|Keep exact zero-case sentence and QED together with removable samepage directives.|
|D04-L|ch227.tex|post-D04 trial 35–36|35–36|Keep section heading and whole short Littlewood boundary remark on p36.|

## Exact presentation differences

Each old/new block below occurs once. Reverse only these blocks to recover the precision/base files exactly. Full patch is `presentation.patch`; full B06 comparison is `revision.patch`.

### D04 — ch227.tex

Old:

```tex
The first criterion's $o(1/n)$ hypothesis is unavailable.
```

New:

```tex
The first criterion's $o(1/n)$ condition fails.
```

Principal/auditor-authorised equivalent short sentence; removes one-word continuation without changing the coefficient comparison.

### D05 — ch229.tex

Old:

```tex
points, the total contribution of rational tags can be made small.
This example proves that the Riemann integrable functions form a
```

New:

```tex
points, the total contribution of rational tags can be made small.

\Needspace{4\baselineskip}
This example proves that the Riemann integrable functions form a
```

Keep the complete short inclusion conclusion as one reading unit; no words or mathematical content changed.

### D06 — ch231.tex

Old:

```tex
For $k=0$ this is $a_n$.  Subtracting the formula at $n+1$ from the
formula at $n$ multiplies the numerator by $k+1$ and adds the factor
$n+k+2$ in the denominator. This proves the next order by induction.
All these differences are positive and decrease to zero with $n$.
Thus the sequence is completely monotone and
$D^ka_0=1/(k+1)$.  Euler's formula becomes
\[
 \log2=\sum_{j=1}^{\infty}\frac1{j2^j},\qquad
 E_m=\sum_{j=1}^m\frac1{j2^j}.
\]
```

New:

```tex
\begin{samepage}
For $k=0$ this is $a_n$.  Subtracting the formula at $n+1$ from the
formula at $n$ multiplies the numerator by $k+1$ and adds the factor
$n+k+2$ in the denominator. This proves the next order by induction.
All these differences are positive and decrease to zero with $n$.
Thus the sequence is completely monotone and
$D^ka_0=1/(k+1)$.  Euler's formula becomes
\[
 \log2=\sum_{j=1}^{\infty}\frac1{j2^j},\qquad
 E_m=\sum_{j=1}^m\frac1{j2^j}.
\]
\par
\end{samepage}
```

Short samepage induction explanation and its resulting log2 display; physical Needspace inside a breakable box was ineffective. No word, term, index or formula changed.

### D07 — ch229.tex

Old:

```tex
$\tau(b-a)<\varepsilon/4$. The measurable sets
\[
 E_j=\{x\in I:j\tau\leq g(x)<(j+1)\tau\},\qquad j=0,1,2,\ldots,
\]
are disjoint and cover $I$, because $g$ is finite everywhere. Their
lower staircase is
```

New:

```tex
$\tau(b-a)<\varepsilon/4$. The following measurable sets are disjoint
and cover $I$, because $g$ is finite everywhere:
\[
 E_j=\{x\in I:j\tau\leq g(x)<(j+1)\tau\},\qquad j=0,1,2,\ldots,
\]
Their lower staircase is
```

Complete the bin-partition assertion before its display. All bins, finiteness premise, following staircase, estimates and labels unchanged.

### D01-L — ch226.tex

Old:

```tex
At $z=0$, only the constant terms can
contribute, and $S_Nz^N=0$ for $N\geq1$.
```

New:

```tex
\par\begin{samepage}
At $z=0$, only the constant terms can
contribute, and $S_Nz^N=0$ for $N\geq1$.\qedhere
\par\end{samepage}
```

Keep the fixed precision zero-case statement complete across the page boundary; removable layout directives only.

### D04-L — ch227.tex

Old:

```tex
\section{The boundary of the elementary criterion}

```

New:

```tex
\Needspace{14\baselineskip}
\section{The boundary of the elementary criterion}

```

Keep the section heading and short Littlewood boundary remark together after D04 reflow; outside the protected sample.

## Reflow and preservation

Total pages remain 92; chapter starts remain physical 5, 14, 22, 28, 38, 49, 67, 78. Changed physical pages versus B06: 3, 18, 22, 23, 34, 35, 39–48, 57–58, 62–63, 82–83. Page 3 updates the §228.2 TOC page. All other 70 pages are pixel-identical at 108 dpi. A further 56 current physical pages were directly viewed in affected-unit/context sequence, and the reported/new breaks were viewed individually at higher resolution. Exact coverage and images are in `visual-review.tsv`, `visual-review.json`, `render/` and `review-sheets/`.

The two historically accepted samples now have the explicitly authorised presentation differences D04 and D05/D07. Reversing only those differences restores original sample bytes/hashes; tagged mathematics is unchanged. `revised-samples/` contains the exact new rendered-source spans for the independent auditor.

Engineering: exact adopted cores, fonts and other dependency/source files outside manuscript are byte-identical to B06. The FLS records all ten actual manuscripts plus all three actual core files under this fixed book. Both local and extracted-path builds converge with only the two known package notifications; all 92 moved-build pages match in pixels, text, links and bookmarks. The PDF bytes differ only in trailer ID. No font substitution, missing character, bad box, unresolved reference, geometric clipping or footer collision was detected.

Content/status: 177 KEEP duties, 37 sections, 24 worked exercises/solutions, 199 labels, 76 references. One redundant eqref was intentionally removed by D01. Reading and engineering pass; independent B07 terminal mathematics and revised-pair acceptance remain the auditor’s gate.
