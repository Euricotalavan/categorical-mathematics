# V17 B07 revision — signed layout handoff

Role: layout; stage: bounded B07 revision after B06; scheme: B single Work.

The source and PDF below are fixed together. No further source edits are planned. The original B06 pair remains unchanged. This is layout delivery for the independent B07 auditor, not terminal mathematical acceptance.

- Source manifest: `book/SOURCE-MANIFEST.json`, SHA-256 `e8ea5c29da9e0861409b652e6ed74b72749da26c5da4ef9a27d665c6be569531`; 39 regular source/dependency files plus the manifest.
- PDF: `output/v17.pdf`, 92 physical pages, 415651 bytes, SHA-256 `5552934c35163b91c0895c5fb9a1340cc3f31de672ec13e63d1d9f698bf55b05`.
- Recoverable source ZIP: `V17-B07-Revision-Source-v1.zip`, SHA-256 `e1dc813935a30cf6a6816596e723d4be099544a20293a48ec0aa4155a7a4207d`.
- Fixed epoch: `1795737600`.

Reading status: PASS for all changed pages and their affected reading units; the other 70 physical pages are pixel-identical at 108 dpi to the original B06 pair whose entire 92 pages were reviewed. Current unit and seam reinspection found no new comparable split, clipping, footer or equation-width defect. D04, D05, D06, D07 and the zero-case/Littlewood follow-up defects have been resolved.

Engineering status: PASS. Two passes stable; no unexpected warning, bad box, missing character, unresolved reference or font substitution. The exact three adopted R1 core files and all dependencies remain unchanged. Build recipe and actual-file input records are in `output/`. A fresh extracted-path rebuild is complete: all 92 pages match in pixels, text, links and bookmarks, and PDF bytes differ only in trailer ID. See `restore-verification.json`.

Content preservation: three precision replacement SHA-256 values were checked at intake. Reversing exactly the six declared presentation overlays restores every one of the ten manuscript files to its precision replacement or unchanged B06 base. Counts: 177 KEEP duties, 37 numbered sections, 24 worked solutions, 199 labels, 76 references; D01 intentionally removed one redundant reference. Exact micro-patches in §§227.3 and 229.3 are separately reversible to the historical accepted sample bytes. See `content-preservation.json`, `layout-patches.json`, `presentation.patch`, `revision.patch`, and `revised-samples/`.

OPEN: independent B07 mathematical and final revision acceptance. No unresolved layout/content blocker identified by this role. The auditor must review this exact source/PDF pair and the changed samples. Do not overwrite B05, B06, upstream templates or Git. Do not start another volume or archive without the principal's authorized gate.

Next: B07 independent recheck of the declared repairs and exact fixed pair; reject to the responsible role if a substantive issue remains. Layout acceptance does not replace that gate.

Signed by the V17 layout role, 2026-11-27 UTC. Actual model/intensity settings were not independently verified.

Evidence addendum: `actual-input-proof.json`, `pdf-engineering.json`, `changes.tsv`, `CHANGES.md`, `visual-review.tsv`, `visual-review.json`, `restore-verification.json`, `output/recipe.json`, `restore-check/output/recipe.json`. Direct current visual coverage is 56 pages; every changed page is included. All remaining coverage inherits B06’s full physical-page review via exact raster equality.
