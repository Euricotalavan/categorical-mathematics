# V17 B07 RETURN D02 — precision repair candidate

Role: independent precision `/root/refine`; date 2026-11-27 UTC. Stage: bounded repair after B07 RETURN, separate from D01 and not final audit. Dispatched GPT-6.1 Sol / high; underlying setting not independently introspected.

## Cause, input identity and scope

Ledger 225-18 requires interior absolute convergence throughout |z|<1. The fixed §225.4 proof showed only 0≤r<1. This is the same distinction between complex coefficients and complex arguments missed by the earlier precision gate. Restore the retained scope by local proof repair; the real radial definition of Abel summability stays unchanged.

Actual immutable input `v17-work/b06/book/manuscript/ch225.tex`: 14554 bytes, SHA-256 `9d6706accdb24bbe48876c8473d71c554ac12b1d3a95cb07206059c613ba49d1`. Parent corrected the initial assignment's older pre-layout SHA `c8687a03f0ba9518d8a904fc40bf9efa25029143e06a81375b6cd64be3dc0143`; the actual B06 file includes Needspace directives, all preserved here. B06 source manifest independently recomputed: `013ce346a1d5bff897ded691089dc955b98d9d46e241867e7ea0cb82d185fb63`. Fixed ledger 225-18 and actual finite Abel lemma were re-read. No ledger/design/source/PDF is edited.

## Exact candidate and changed span

Output `v17-work/b07/repairs/D02/ch225.tex`: 14841 bytes, SHA-256 `baf1598e8fc1dab871fdd9a7a43011b67f749ecfa2c2909de513bdfcfce90b46`.

Change is confined to §225.4 theorem proof: old lines188–208 become new lines188–217, with unchanged surrounding lines retained in the exact `ch225.patch`. Detailed line-span operations are in `span-check.json`. The finite lemma and its any-scalar statement are unchanged. The definition of Abel summability in §225.3 is byte-identical. All text from marker225-14 to the chapter end, all 20 obligation markers, all labels, all Needspace directives and all three solved exercises are unchanged. No other chapter file is written by D02.

## Before / after / affected use

|Responsibility|Before|Candidate|
|---|---|---|
|225-18 inner existence|Geometric comparison at real r≥0 only|Fix complex z, |z|<1. The ratio of (n+1)|z|^n tends to |z|<1, giving convergence by an eventual geometric majorant and (n+1)|z|^n→0; handle z=0 separately. The existing coefficient bounds control all three power series absolutely on the disk.|
|First finite identity passage|f(r)=(1−r)ΣS_nr^n with implicit endpoint estimate|Apply the unchanged finite scalar identity with z; explicit |S_Nz^N|≤(2N+1)M|z|^N→0 gives f(z)=(1−z)ΣS_nz^n.|
|Second finite identity passage|Real r, implicit second endpoint estimate|Apply with coefficients S_n and partial sums (n+1)C_n; explicit |(N+1)C_Nz^N|≤(N+1)M|z|^N→0 gives f(z)=(1−z)²Σ(n+1)C_nz^n for every |z|<1.|
|Nonnegative weights and Abel limit|Real r already in force|Explicitly set z=r with real 0≤r<1 as required by the original method before defining weights. The original weight normalization/head-tail proof then follows unchanged.|

## Proof and downstream verification

- C_n bounded implies |S_n|≤(2n+1)M and |a_n|≤4(n+1)M, including n=0; |(n+1)C_n|≤(n+1)M. These are O(n) majorants for every complex z after replacing its powers by |z|^n.
- Absolute convergence is proved before writing f(z) and before both limiting finite identities. This uses no C⇒A conclusion, no endpoint theorem from 226, and no infinite double-series exchange. Polynomial prefactors times |z|^N vanish for fixed |z|<1; at z=0 they are zero for N≥1.
- With coefficients S_n, their partial sum at N is exactly (N+1)C_N under the chapter's n+1 convention; thus the second endpoint bound and every index are correct. The unchanged finite lemma permits every scalar; writing z does not constrain or alter it.
- Weight positivity and sum1 are used only after real specialization. Their head/tail bound still yields a finite real radial Abel limit, as required by §225.3, without claiming arbitrary-complex-path convergence. The displayed double-generating identity is now stronger internally, while the summability definition/theorem's endpoint conclusion is unchanged.
- Directly rechecked all actual references to the finite lemma and double-generating identity. Ch226 §226.1 can use the same arbitrary-scalar finite lemma (both before and after D01); Ch226 §226.2 still specializes to real radii. D01 and D02 modify separate chapter files and can be integrated together without overlapping spans.
- Ch227 independently establishes its generating identity from Abel-domain convergence, because ordinary convergence is not its premise. Its first/second Tauber proofs remain real radial and retain their own convergence checks. No new reliance on C⇒A or a complex boundary limit is introduced.
- The remainder of Ch225 theorem, counterexamples, linearity/shift proof and all three practice solutions stay unchanged. Their r convention remains the real Abel definition. Ch226 examples/exercises and Ch231 log2/π4 uses need no change; D01 receipt records their direct content recheck.
- Machine comparison confirms exact labels, marker lines as text, all Needspace directives, and suffix beginning225-14 are identical. Exact line positions after the repair must be regenerated by integration. Neither protected sample is in this file and none is edited.

## Transfer and remaining checks

This precision candidate addresses D02 only; fresh B07 acceptance is pending. Parent should integrate D01/D02 through layout, rebuild and fix a new exact source/PDF/manifest/map pair, then return it to the fresh B07 auditor for independent mathematical and rendered recheck. Old B06 is immutable. Pagination, reference rendering and final engineering checks remain OPEN until that rebuild; no B07 PASS, archive or publication is claimed here. Earlier B05 PASS cannot override this RETURN or the required independent recheck.
