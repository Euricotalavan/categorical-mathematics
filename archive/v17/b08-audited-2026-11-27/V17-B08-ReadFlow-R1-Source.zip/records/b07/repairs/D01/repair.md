# V17 B07 RETURN D01 — precision repair candidate

Role: independent precision `/root/refine`; date 2026-11-27 UTC. Stage: bounded repair after the fresh B07 auditor's RETURN, not B07 clearance. Dispatched GPT-6.1 Sol / high; runtime setting not independently introspected.

## Cause and fixed inputs

The fresh auditor correctly found that retained obligations 226-03 and 226-04 cover all scalar arguments of modulus less than one, while the body only proved existence and the generating identity at real 0≤r<1. Complex coefficients alone did not cover complex arguments. The earlier B04/B05 precision PASS missed this range restriction; it does not dispose of the B07 defect.

Read actual immutable `v17-work/b06/book/manuscript/ch226.tex` in full, 11228 bytes, SHA-256 `c46391957e63a68d67e3d15a4f501a32dfeab78555555a31dae4b5c98635bfd1`. Independently recomputed B06 `book/SOURCE-MANIFEST.json` SHA-256 `013ce346a1d5bff897ded691089dc955b98d9d46e241867e7ea0cb82d185fb63`. Re-read actual fixed source ledger rows 226-03/04 and upstream local lemma at B06 ch225.tex §225.4. Source/ledger/design/PDF are not edited.

## Exact output and replacement extent

Candidate: `v17-work/b07/repairs/D01/ch226.tex`, 11591 bytes, SHA-256 `0dae4546e3b88be85368b39ebdc67f51f3b405ccf9be3161bece6afee075c5d2`.

The local replacement begins at `% V17: 226-01`, covering §226.1's notation, finite identity, proposition and corollary; it adds an explicit three-line specialization immediately after the §226.2 heading. Detailed exact diff is `ch226.patch`; `span-check.json` records each old/new changed line span. Old lines 12–61 are the substantive changed region, plus the insertion after old §226.2 heading at line64. Everything from `% V17: 226-05` through the end is byte-identical to input. Chapter introduction and all four section headings/labels, all 14 responsibility marker lines and all result/equation/problem labels are preserved. No other chapter file was written by this repair.

## Before / after / impact

|Location|Before|Candidate and reason|
|---|---|---|
|§226.1 notation|f(r), real endpoint parameter imposed before the inner result|f(z), complex z; endpoint theorem is previewed as real radial. This separates the two domains.|
|226-02 finite identity|Formula written with r only|Written with z and explicitly every complex scalar, without imposing |z|<1 on this finite algebra. The existing §225.4 lemma already permits any scalar, including N=0 with empty sum.|
|226-03|Absolute series and endpoint term at 0≤r<1|For each fixed complex |z|<1, bounded partial sums yield Σ|S_n z^n|≤M/(1−|z|), Σ|a_n z^n|≤2M/(1−|z|), and |S_N z^N|≤M|z|^N→0. z=0 is addressed separately for N≥1.|
|226-04|Generating identity on the real interval|f(z)=(1−z)ΣS_nz^n on the whole complex open unit disk, obtained from the same finite identity using both absolute convergences and vanishing endpoint. No boundary or arbitrary-complex-path limit is claimed.|
|§226.2 introduction|Radial condition appears inside the proof|Explicitly set z=r with real 0≤r<1 before the theorem, so the later f(r) is the real restriction and all positivity arguments keep their original domain.|

## Mathematical and downstream recheck

- For any complex |z|<1, |z| is a nonnegative real ratio below one, making both geometric majorants valid. No ordering of complex z is used, no division by z occurs, and zero partial-sum bound M=0 is harmless. a0=S0 is bounded by M, hence also 2M.
- The finite identity is polynomial algebra, valid for every complex z including zero and values outside the disk; only passage to infinite sums assumes |z|<1. N=0 and the empty sum are inherited unchanged from §225.4.
- §226.2 still takes r↑1 along real radii. Its unchanged nonnegative weights (1−r)r^n sum to one; the estimates depend on real r, not arbitrary complex z. Interior disk existence specializes to the needed real interval. The direction-of-approach remark remains correct.
- §226.3: fixed boundary w applies the unchanged radial Abel theorem to b_n=c_nw^n, and f(rw) uses real r. The local function with radius R is separately defined there. Leibniz xG(x²) and harmonic xA(x) remain real-inner calculations followed by radial limits; their ordinary convergence premises are unchanged.
- §227: directly read the definition and first proof chain, protected second-criterion interface and all references to Chapter226. Abel summability still means every real 0≤r<1 plus a finite radial limit. Its separate generating proposition under the weaker Abel-domain premise is still required and is not replaced by the ordinary-convergence corollary. Neither criterion acquires a complex-path premise or conclusion.
- §231: re-read harmonic and Leibniz Euler examples and their actual Chapter226 references. They use the same previously identified ordinary values log2 and π/4, not an enlarged endpoint theorem. Their bounds/indices/formulas are unaffected.
- All three Ch226 exercises and full solutions were read: first retains the expressly real estimate |f(r)|≤M from nonnegative weights, which the complex identity permits by specialization; no |f(z)|≤M is asserted for arbitrary disk z. Second retains t=x² real. Third still distinguishes finite real Abel values from ordinary convergence. No exercise text changed.
- Exact structural comparison confirms the label sequence and marker sequence are unchanged; from 226-05 onward the bytes are identical, so downstream proofs/exercises were preserved. All reference uses of the changed proposition/equation were inspected in actual B06 source. Both protected samples lie in other immutable chapters and were not touched.

## Transfer, OPEN and next gate

Delivered only this candidate plus exact diff and span record in D01. This repairs the specific proof-coverage defect; it does not claim the fresh auditor has accepted it. Parent routes the candidate to the responsible layout rebuild, updates source/PDF pair and body-locations/manifest for changed line positions, then sends the rebuilt exact pair to the independent B07 auditor. PDF wrapping, pagination, live links and final source/PDF hash correspondence remain OPEN until rebuild/recheck. Do not edit original B01/B02, immutable B06 source/PDF, any other chapter or protected samples. No publication or archive was performed.
