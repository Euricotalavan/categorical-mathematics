#!/usr/bin/env python3
"""Strict, isolated XeLaTeX harness. Writes only to --output-dir; no manuscript edits.

Example: python build-v17.py --book-root sandbox --entry layout/study/sandbox.tex
         --output-dir sandbox/harness-output --dependencies-dir dependencies
"""
from pathlib import Path
from xml.sax.saxutils import escape
import argparse, hashlib, json, os, re, shlex, shutil, subprocess, sys, zipfile

CORE = {
    'layout/shared/readflow-base.tex': 'cc9cc678504651f8f1baa196a714a70de1331684589d71b14353c77ec6f6f63b',
    'layout/study/config.tex': 'fdccf765bbb70ff9f8b178a81af841d721cb4f962c9d90ddb476d5728e1c0424',
    'layout/study/readflow-layout.tex': 'b04bf2f5bb7611b8a4899c9a582050681d36d71fba8b0c44a31f8d87d2924f69',
}
FACES = {'TeXGyrePagellaX-Regular.otf','TeXGyrePagellaX-Italic.otf',
         'TeXGyrePagellaX-Bold.otf','TeXGyrePagellaX-BoldItalic.otf',
         'Asana-Math.otf','STIXTwoMath-Regular.otf','NotoSans-Regular.ttf',
         'NotoSans-Bold.ttf','DejaVuSansMono.ttf'}
# Exact known compatibility notices; no wildcard package-warning acceptance.
BUILTIN_ALLOW = [
    {'id':'unicode-math-mathtools-bracket',
     'message':r"Package unicode-math Warning: Using \overbracket and \underbracket from `mathtools' package. Use \Uoverbracket and \Uunderbracket for original `unicode-math' definition.",
     'reason':'Original R1 loads mathtools before unicode-math; use of either bracket command still needs content review.'},
    {'id':'unicode-math-mathtools-colon',
     'message':r"Package unicode-math Warning: I'm going to overwrite the following commands from the `mathtools' package: \dblcolon, \coloneqq, \Coloneqq, \eqqcolon. Note that since I won't overwrite the other colon-like commands, using them will lead to inconsistencies.",
     'reason':'Known package interaction, retained explicitly. This does not approve any new colon notation or semantic substitution.'},
]

def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def dump(path, value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def normal(text): return re.sub(r'\s+',' ',text).strip()
def fail(message): raise RuntimeError(message)

def run(cmd, cwd, env, log):
    p=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True)
    log.write_text(p.stdout+p.stderr)
    if p.returncode: fail(f'Command failed ({p.returncode}); see {log}\n'+(p.stdout+p.stderr)[-2500:])
    return p.stdout

def warnings(log):
    result=[];lines=log.splitlines();i=0
    while i<len(lines):
        if lines[i].startswith('Underfull \\'):
            result.append(normal(lines[i]));i+=1;continue
        if re.match(r'^(?:LaTeX(?: Font)?|Package \S+|Class \S+) Warning:',lines[i]):
            chunk=[lines[i]];i+=1
            while i<len(lines):
                line=lines[i]
                if line.startswith('(') and re.match(r'^\([^ )]+\)\s',line):
                    chunk.append(re.sub(r'^\([^ )]+\)\s*','',line));i+=1
                elif not line.strip(): i+=1;break
                elif re.match(r'^\s+',line): chunk.append(line);i+=1
                else: break
            result.append(normal(' '.join(chunk)))
        else:i+=1
    return result

def hard_diagnostics(log):
    return re.findall(r'Missing character:.*|Overfull \\[hv]box[^\n]*|Undefined control sequence.*|.*(?:undefined references|multiply-defined|destination with the same identifier).*',log)

def font_cache(dep, runtime):
    manifest=json.loads((dep/'FONTS.json').read_text());faces=manifest['faces']
    byname={f['filename']:f for f in faces}
    if not FACES.issubset(byname):fail('Required nine-face manifest incomplete')
    target=runtime/'fonts';target.mkdir(exist_ok=True)
    archive=dep/'upstream/newpx.zip';records=[]
    for name in sorted(FACES):
        item=byname[name];src=dep/'fonts'/name
        if src.exists(): b=src.read_bytes();origin=str(src)
        elif name.startswith('TeXGyrePagellaX-'):
            if not archive.is_file() or sha(archive)!=item['archive_sha256']:fail('newpx archive missing or hash mismatch')
            with zipfile.ZipFile(archive) as z:
                if z.testzip():fail('newpx archive CRC failure')
                b=z.read(item['archive_entry']);origin=str(archive)+'::'+item['archive_entry']
        else:fail('Missing exact font face: '+name)
        if len(b)!=item['bytes'] or digest(b)!=item['sha256']:fail('Font hash mismatch: '+name)
        (target/name).write_bytes(b)
        records.append({'name':name,'source':origin,'sha256':digest(b),'bytes':len(b),'license':item['license']})
    return target,records

def tex_index(source, root):
    root.mkdir(exist_ok=True)
    for child in source.iterdir():
        if child.name=='ls-R':continue
        p=root/child.name
        if p.is_symlink() and p.resolve()!=child.resolve():fail('TeX cache links to a different installation; use a new output directory')
        if not p.exists():p.symlink_to(child,target_is_directory=child.is_dir())
    lines=['% ls-R -- filename database for kpathsea; do not change this line.','']
    for folder,dirs,files in os.walk(source):
        rel=Path(folder).relative_to(source)
        lines += [('./' if str(rel)=='.' else './'+str(rel))+':']+sorted(dirs)+sorted(files)+['']
    (root/'ls-R').write_text('\n'.join(lines))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--book-root',required=True,type=Path)
    p.add_argument('--output-dir',required=True,type=Path)
    p.add_argument('--entry',default='layout/study/v17.tex')
    p.add_argument('--dependencies-dir',type=Path)
    p.add_argument('--tex-tree',action='append',type=Path,help='TeX installation tree; repeat for separate font tree')
    p.add_argument('--warning-allowlist',type=Path,help='JSON list of exact message/id/reason; hard errors cannot be allowed')
    p.add_argument('--source-date-epoch',type=int,default=int(os.environ.get('SOURCE_DATE_EPOCH','0')))
    p.add_argument('--max-passes',type=int,default=6)
    a=p.parse_args();book=a.book_root.resolve();out=a.output_dir.resolve();entry=(book/a.entry).resolve()
    if not entry.is_relative_to(book) or not entry.is_file():fail('Entry must be an existing file inside book root')
    if out==book or entry.is_relative_to(out):fail('Output must not contain or replace entry source')
    if a.max_passes<2 or a.source_date_epoch<0:fail('At least two passes and a nonnegative epoch are required')
    out.mkdir(parents=True,exist_ok=True);runtime=out/'.runtime';runtime.mkdir(exist_ok=True)
    # XeTeX searches output-dir before cwd for relative input names. A nested
    # engine directory prevents ../../manuscript resolving to mutable siblings.
    engine=out/'engine';engine.mkdir(exist_ok=True)
    dep=(a.dependencies_dir or (book/'dependencies' if (book/'dependencies').is_dir() else Path(__file__).resolve().parent/'dependencies')).resolve()
    template=[]
    for rel,expected in CORE.items():
        src=book/rel
        if not src.is_file() or sha(src)!=expected:fail('Fixed R1 core mismatch: '+rel+'; declare and review any template revision before using this strict baseline harness')
        template.append({'path':str(src),'sha256':expected})
    fonts,font_records=font_cache(dep,runtime)
    trees=[x.resolve() for x in (a.tex_tree or [Path('/usr/share/texlive/texmf-dist'),Path('/usr/share/texmf')]) if x.is_dir()]
    if not trees:fail('No TeX trees found; pass --tex-tree for this machine')
    indexed=[]
    for i,tree in enumerate(trees):
        target=runtime/f'tex-search-{i}';tex_index(tree,target);indexed.append('!!'+str(target))
    cache=runtime/'font-cache';cache.mkdir(exist_ok=True)
    conf=runtime/'fontconfig.xml'
    conf.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd"><fontconfig><dir>'+escape(str(fonts))+'</dir><cachedir>'+escape(str(cache))+'</cachedir></fontconfig>')
    var=runtime/'texmf-var';fmt=var/'web2c';fmt.mkdir(parents=True,exist_ok=True)
    overrides={'TEXMF':'{'+','.join(indexed+[str(var)])+'}',
        'TEXMFDBS':'{'+','.join(indexed)+'}', 'TEXMFVAR':str(var),'TEXMFCONFIG':str(runtime/'texmf-config'),
        'TEXFORMATS':str(fmt)+'//:', 'TEXINPUTS':'.:',
        'OPENTYPEFONTS':os.pathsep.join([str(fonts)+'//']+[str(t/'fonts/opentype')+'//' for t in trees])+':',
        'TTFONTS':str(fonts)+'//:', 'FONTCONFIG_FILE':str(conf),'FONTCONFIG_PATH':str(runtime),
        'SOURCE_DATE_EPOCH':str(a.source_date_epoch),'FORCE_SOURCE_DATE':'1', 'TZ':'UTC',
        'openin_any':'a','openout_any':'p'}
    env=os.environ.copy();env.update(overrides)
    for query,name in [('Noto Sans','NotoSans-Regular.ttf'),('Noto Sans:style=Bold','NotoSans-Bold.ttf'),('Asana Math','Asana-Math.otf'),('DejaVu Sans Mono','DejaVuSansMono.ttf')]:
        selected=run(['fc-match','-f','%{file}',query],out,env,out/('font-match-'+name+'.txt')).strip()
        if not Path(selected).is_file() or sha(Path(selected))!=sha(fonts/name):fail('Font substitution detected for '+query+': '+selected)
    version=run(['xelatex','--version'],out,env,out/'xelatex-version.txt')
    signature=digest((version+'\n'+'\n'.join(str(t) for t in trees)).encode())
    sigfile=runtime/'format-signature.txt'
    if not (fmt/'xelatex.fmt').is_file() or not sigfile.exists() or sigfile.read_text()!=signature:
        run(['xetex','-ini','-etex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-jobname=xelatex','xelatex.ini'],fmt,env,out/'format-build.txt')
        sigfile.write_text(signature)
    stem=entry.stem;cmd=['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder','-output-directory='+str(engine),entry.name]
    recipe={'schema':'V17-XELATEX-RECIPE-v1','book_root':str(book),'cwd':str(entry.parent),'command':cmd,'environment_overrides':overrides,'compiler_version':version,'template':template,'font_manifest':font_records,'warning_policy':{'builtin':BUILTIN_ALLOW,'external':{'path':str(a.warning_allowlist.resolve()),'sha256':sha(a.warning_allowlist),'entries':json.loads(a.warning_allowlist.read_text())} if a.warning_allowlist else None},'content_edit':False,'scope':'compilation only; not B06 acceptance or mathematical review'}
    dump(out/'recipe.json',recipe)
    (out/'recipe.sh').write_text('#!/bin/sh\nset -eu\ncd '+shlex.quote(str(entry.parent))+'\n'+'\n'.join('export '+k+'='+shlex.quote(v) for k,v in sorted(overrides.items()))+'\n'+shlex.join(cmd)+'\n')
    previous=None;passes=[]
    # .aux includes nested include auxiliaries; toc/out/lof/lot cover navigation.
    for n in range(1,a.max_passes+1):
        run(cmd,entry.parent,env,out/f'pass-{n}.txt')
        state={str(f.relative_to(engine)):sha(f) for f in sorted(engine.rglob('*')) if f.is_file() and f.suffix in {'.aux','.toc','.out','.lof','.lot'}}
        passes.append({'pass':n,'auxiliary_state':state})
        if n>=2 and state==previous:break
        previous=state
    else:fail('Auxiliary state did not converge; report is not a passing build')
    log=(engine/(stem+'.log')).read_text(errors='replace');found=warnings(log)
    hard=hard_diagnostics(log)
    hard += [message for message in found if message.startswith('LaTeX Font Warning:') or re.search(r'substitut',message,re.I)]
    allow=BUILTIN_ALLOW.copy()
    if a.warning_allowlist:
        for item in json.loads(a.warning_allowlist.read_text()):
            if set(item)!={'id','message','reason'} or not all(isinstance(v,str) and v.strip() for v in item.values()):fail('Allowlist entries require nonempty id/message/reason only')
            allow.append(item)
    accepted=[];unexpected=[]
    for message in found:
        match=next((x for x in allow if normal(x['message'])==message),None)
        (accepted if match else unexpected).append({'message':message,**({'id':match['id'],'reason':match['reason']} if match else {})})
    inputs=[]
    for line in (engine/(stem+'.fls')).read_text(errors='replace').splitlines():
        if not line.startswith('INPUT '):continue
        f=Path(line[6:]);f=(entry.parent/f).resolve() if not f.is_absolute() else f.resolve()
        if not f.is_file() or f.is_relative_to(out):continue
        inputs.append(f)
    for f in set(inputs):
        if f.suffix in {'.tex','.tikz','.bib','.sty'} and not f.is_relative_to(book) and not any(f.is_relative_to(t) for t in trees):
            fail('Project source escaped fixed book root: '+str(f))
    source_manifest=[{'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(set(inputs))]
    for ext in ['pdf','log','fls','aux','toc','out']:
        src=engine/(stem+'.'+ext)
        if src.is_file():shutil.copyfile(src,out/src.name)
    pdf=out/(stem+'.pdf')
    font_output=run(['pdffonts',str(pdf)],out,env,out/'pdffonts.txt')
    permitted={name.removesuffix('.otf').removesuffix('.ttf') for name in FACES}
    pdf_fonts=[]
    for line in font_output.splitlines()[2:]:
        parts=line.split()
        if len(parts)<7:continue
        name=re.sub(r'^[A-Z]{6}\+','',parts[0]).removesuffix('-Identity-H')
        pdf_fonts.append({'name':name,'embedded':parts[-5]=='yes'})
        if name not in permitted or parts[-5]!='yes':hard.append('Unexpected or unembedded PDF font: '+line)
    if not pdf_fonts:hard.append('PDF contains no inspectable font records')
    report={'schema':'V17-XELATEX-BUILD-v1','entry':str(entry),'passes':passes,'converged':True,'accepted_warnings':accepted,'unexpected_warnings':unexpected,'hard_diagnostics':hard,'pdf_fonts':pdf_fonts,'pdf':{'path':str(pdf),'bytes':pdf.stat().st_size,'sha256':sha(pdf)},'recorded_inputs':source_manifest,'verdict':'PASS' if not hard and not unexpected else 'FAIL','limits':['No mathematical acceptance','No full-page visual or continuous-reading acceptance','No cross-machine binary identity promise','Original R1 runtime font binary versions unavailable; this build fixes the supplied nine hashes']}
    dump(out/'build-report.json',report)
    print(json.dumps({k:report[k] for k in ['converged','accepted_warnings','unexpected_warnings','hard_diagnostics','pdf','verdict']},ensure_ascii=False,indent=2))
    return 0 if report['verdict']=='PASS' else 2

if __name__=='__main__':
    try:sys.exit(main())
    except (RuntimeError,FileNotFoundError,ValueError,KeyError) as exc:
        print('BUILD FAILED: '+str(exc),file=sys.stderr);sys.exit(1)
