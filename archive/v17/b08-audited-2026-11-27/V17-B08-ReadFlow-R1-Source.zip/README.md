# Categorical Mathematics, Volume 17

*Series, Improper Integrals, and Topics in Real Analysis*

This fixed B-08 edition covers Chapters 224–231 in English. The ReadFlow R1 reading PDF has 92 physical pages, 37 numbered sections and 24 exercises with solutions. The independent final thickening audit approved the exact reader-facing source and this PDF after rechecking the localized repairs.

| File | Contents |
|---|---|
| `V17-B08-ReadFlow-R1.pdf` | Exact approved reading copy |
| `book/` | One LaTeX manuscript, the adopted R1 core, the V17 adapter, fonts and build harness |
| `COVERAGE.tsv` | 177 adopted obligations with current source lines and 65 deferred obligations |
| `OPEN.md` | Standing source, scope and prerequisite limitations |
| `records/b07/AUDIT.md` | Signed independent whole-volume verdict |
| `records/b07/revision/` | Actual compile inputs, page review, patch and rebuild evidence |
| `records/` | Handoffs, coverage decisions and earlier revision evidence |
| `MANIFEST.json` | Exact byte lengths and hashes for the archive |

## Verify and rebuild

Run from the extracted archive root. The isolated build uses XeLaTeX, fontconfig and Poppler. The archive supplies the nine fixed font files and their license records. For nondefault TeX Live installations, use `--tex-tree` to identify the installed trees.

```sh
python verify.py
python book/build-v17.py --book-root book --output-dir rebuilt --source-date-epoch 1795737600
```

The reference PDF is the signed release copy. A same-environment rebuild reproduces the pages, text, bookmarks and links. XeLaTeX may write a different PDF trailer identifier at another output path.

## Scope

Hardy uses the authorized Oxford 1949 copy. Knopp uses the Blackie 1954 reprint of the 1951 English second edition listed by the National Library of Finland. The missing printed page 104 is outside the cited sections. Bartle was waived. Fonda supplies gauge-integration background and the book independently proves the finite-interval HK and Lebesgue comparison. The stronger Littlewood theorem is stated at the chapter boundary. The exact limitations and older source errors appear in the accompanying register and audit.

The adopted R1 template is the V0 artifact at `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`. The project scope continues the assigned V14, V15 and V16 chapter intervals through Chapter 223.
