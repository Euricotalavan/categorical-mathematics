#!/usr/bin/env python3
"""Verify the archived V17 source, evidence and accepted reading PDF."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", default="MANIFEST.json")
    args = parser.parse_args()
    manifest_path = Path(args.manifest).resolve()
    root = manifest_path.parent
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest["volume"] != 17 or manifest["chapters"] != list(range(224, 232)):
        raise SystemExit("Unexpected volume or chapter range")
    files = manifest["files"]
    if not files:
        raise SystemExit("No files were listed")
    for name, expected in files.items():
        path = root / name
        if path.resolve().is_relative_to(root) and path.is_file():
            if path.stat().st_size == expected["bytes"] and file_sha256(path) == expected["sha256"]:
                continue
        raise SystemExit(f"Missing or changed archive input: {name}")

    pdf = manifest["pdf"]
    if pdf["file"] not in files:
        raise SystemExit("The accepted PDF is missing from the file manifest")
    pages = pdf["pages"]
    if shutil.which("pdfinfo"):
        info = subprocess.run(["pdfinfo", str(root / pdf["file"])],
                              check=True, text=True, capture_output=True).stdout
        match = re.search(r"^Pages:\s+(\d+)\s*$", info, re.MULTILINE)
        if not match or int(match[1]) != pages:
            raise SystemExit("The accepted PDF page count disagrees with the archive")
        print(f"Verified {pages} PDF pages")
    print(f"Verified {len(files)} file identities for V17, Chapters 224–231")
    print("The independent mathematical and page reviews are in the archived evidence.")


if __name__ == "__main__":
    main()
