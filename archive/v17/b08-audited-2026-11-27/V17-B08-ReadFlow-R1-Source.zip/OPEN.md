# Remaining source and scope items

| ID | Status | Record and consequence |
|---|---|---|
| V17-BA | UNKNOWN, waived as a primary source | The 2001 Bartle monograph remains unread. The user declined this source and scanning. Fonda supplies gauge definitions and proofs on the selected real interval. The comparison with Lebesgue integration has an independent complete proof. |
| V17-KN | UNKNOWN for Dover 1990 | The Blackie 1954 reprint of the 1951 English edition is the fixed working copy. The earlier questionable scan remains outside the production input. |
| V17-KN-104 | OPEN, outside selected working pages | The Blackie scan jumps from printed 103 to 105. The missing leaf is in Chapter II §11. Sections 28–30 and 33–35, used here, have complete selected pages. |
| V17-TM-624 | Source error, barred proof chain | Myers Proposition 2.7 fails because convergence to an HK-integrable function does not imply eventual integrability. Statements depending on it require a separate proof. |
| V17-TM-632 | Source error, stronger wording rejected | Myers Theorem 3.8 drops measurability or integrability of the sign-bearing function. A nonmeasurable sign function can have integrable absolute value. The retained comparison has explicit hypotheses. |
| V17-VI | Source corrections | Villarino's difference identity requires the factor (1/2) at the first averaging step. Use non-strict remainder inequalities at boundary cases. The whole Euler derivation is independently checked. |
| V17-ADV | Deferred boundary | Core 227 proves the two Tauber criteria for ordinary convergence of real or complex series. Littlewood's stronger statement is a boundary result. Wiener, Laplace–Stieltjes, and higher-order methods belong to later study. |
| V17-UPSTREAM | Read against stated builds | Chapters 179–194 are aligned to V14's public fixed index and predecessor manuscript. V16 Chapters 208–223 use the recovered B04 integrated snapshot for interface checks. Other freezes and OPEN/UNKNOWN records live with those volumes. |
