# V17-B08-20261127-v1

B single Work. *Series, Improper Integrals, and Topics in Real Analysis*. Chapters 224–231. ReadFlow R1.

The independent final auditor signed `records/b07/AUDIT.md`, SHA-256 `15da92f93ffbb654b43b07c702d8c2b7bcd22cb7271f72cafc207656bd0428b4`. This B-08 package uses the exact approved `book/SOURCE-MANIFEST.json` SHA-256 `e8ea5c29da9e0861409b652e6ed74b72749da26c5da4ef9a27d665c6be569531` and the 92-page PDF SHA-256 `5552934c35163b91c0895c5fb9a1340cc3f31de672ec13e63d1d9f698bf55b05`. The manifest records 39 source and dependency files. The build trace records the actual TeX inputs. The integrated source map and all historical defect dispositions are included.

Chapter continuity follows V14 through Chapter 194 at `bd68f94015bb93ec48fb0edcf9d794f632cba57c`, the user's V15 through 207 and V16 through 223. Contact with those volumes was for their fixed prerequisite interfaces. Original ReadFlow R1 source ZIP SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`. V17 compile command and ancillary requirements appear in `README.md`.

This archive is the exact passed B-07 source plus matching reader PDF, project records and verification program. Authorization was given for B-01 through B-08 within this Work. Standing source and scope items appear in `OPEN.md`. Earlier checkpoints remain recoverable by their versioned handoffs in `records/`. The source and PDF identities, B-07 sign-off, compiled-file trace, readings, defects and cover map are the baseline for any future task. New substantive changes reopen affected checks with the original roles.
