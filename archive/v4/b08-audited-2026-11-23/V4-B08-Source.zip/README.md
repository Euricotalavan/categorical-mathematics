# Categorical Mathematics, Volume 4

B-08 public source and reading PDF, 2026-11-23. The mathematics passed the B-07 whole-volume review. This edition has 106 sections and 539 pages. Chapters 71–84 are provisional pending the final numbering of Volume 3. The PDF and manuscript match the reviewed version and retain the B-07 footer.

## Contents

- `content/inputs.tex` and the 106 section files are the reviewed manuscript.
- `layout/` contains the adopted ReadFlow R1 implementation for this volume.
- `reference/current.pdf` is the paired reading PDF.
- `qa/runtime.json` lists the tested XeLaTeX version and external font files, with their checksums.

## Rebuild

Extract the ZIP. Install Python 3, XeLaTeX, and the TeX packages used by the source. A full TeX Live installation includes the required packages. Make the following fonts available through Fontconfig and the TeX font search path.

- TeX Gyre PagellaX Regular, Italic, Bold, and Bold Italic from TeX Live's `newpx` package
- Noto Sans
- DejaVu Sans Mono
- Asana Math
- STIX Two Math for the two-symbol fallback

From the extracted directory, run:

```sh
sha256sum -c SHA256SUMS
python3 build.py --entry template
```

The rebuilt PDF is `.build/template/template.pdf`. If the system XeLaTeX format is missing, use the distribution's format generation command. The paired PDF has SHA-256 `266a5acd2ddb594b1d196f5392f14412fd848f8d8f6256fe1d7d868cace70601`.

This distribution uses externally installed fonts. Template adoption and attribution are documented in the [ReadFlow R1 archive](https://github.com/Euricotalavan/categorical-mathematics/tree/8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3/archive/v0/readflow-r1-editorial-2026-11-17).
