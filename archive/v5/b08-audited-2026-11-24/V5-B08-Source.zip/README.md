# Build Volume 5

This release preserves the audited TeX and ReadFlow R1 layout without changes.
Install Python 3 and TeX Live with XeLaTeX, fontspec, unicode-math, mathtools,
and the packages declared by the layout. Install Asana Math, STIX Two Math,
TeX Gyre Pagella X (regular, italic, bold and bold italic), Noto Sans (regular
and bold), and DejaVu Sans Mono. The baseline font fingerprints are in
qa/runtime-baseline.json; fonts are not bundled. Make the named OTF files
visible to TeX (e.g. via OPENTYPEFONTS) and register the named system fonts.

From this directory run `python3 build.py --entry template`. The output is
`.build/template/template.pdf`; the builder runs until references converge.
Reproducibility of the page result is distinct from binary identity of fresh
PDFs, which can include timestamps and other environment metadata.
