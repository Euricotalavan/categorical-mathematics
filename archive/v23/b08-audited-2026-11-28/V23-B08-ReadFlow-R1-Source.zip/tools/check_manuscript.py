"""Check the fixed V23 source map and report book metrics without grading mathematics."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from hashlib import sha256
from pathlib import Path


CHAPTERS = range(291, 305)
LABEL = re.compile(r"\\label\s*\{([^}]+)\}")
REFERENCE = re.compile(r"\\(?:ref|eqref|autoref|pageref)\s*\{([^}]+)\}")
BEGIN = re.compile(r"\\begin\s*\{([^}]+)\}")
ENV = re.compile(r"\\(begin|end)\s*\{([^}]+)\}")
CHAPTER_TITLE = re.compile(r"\\chapter\s*\{")
SECTION_TITLE = re.compile(r"\\section\s*\{")
WORK_MARKER = re.compile(r"\b(?:TODO|TBD|FIXME)\b")
DOC_CONTROL = re.compile(r"\\(?:documentclass|usepackage|setcounter)\b")
SEMANTIC_ENVS = (
    "definition", "theorem", "lemma", "proposition", "corollary",
    "example", "problem", "psolution", "proof",
)


def location(text: str, match: re.Match[str]) -> int:
    return text.count("\n", 0, match.start()) + 1


def check_source(source: Path, calibration: Path | None) -> dict:
    errors = []
    labels = {}
    references = []
    stats = {}
    expected = {f"ch{number}.tex" for number in CHAPTERS}
    actual = {path.name for path in source.glob("ch*.tex")}
    if actual != expected:
        errors.append({"missing_chapters": sorted(expected - actual),
                       "unexpected_chapters": sorted(actual - expected)})

    for number in CHAPTERS:
        path = source / f"ch{number}.tex"
        if not path.is_file():
            continue
        data = path.read_bytes()
        body = data.decode("utf-8")
        controls = {character for character in data if character < 32 and character not in (9, 10)}
        if controls:
            errors.append(f"{path.name}: unexpected control bytes {sorted(controls)}")
        content = re.sub(r"(?<!\\)%[^\n]*", "", body)
        counts = Counter(BEGIN.findall(content))
        stats[str(number)] = {
            "bytes": len(data),
            "sha256": sha256(data).hexdigest(),
            "tex_words": len(content.split()),
            "sections": len(SECTION_TITLE.findall(content)),
            **{key: counts[key] for key in SEMANTIC_ENVS},
        }
        if len(CHAPTER_TITLE.findall(content)) != 1 or f"ch:{number}" not in LABEL.findall(content):
            errors.append(f"{path.name}: expected one chapter and its fixed chapter label")
        if DOC_CONTROL.search(content):
            errors.append(f"{path.name}: stray document or counter control")
        if re.search(r"\\C(?![A-Za-z])", content):
            errors.append(f"{path.name}: inherited category macro used in analysis manuscript")
        if WORK_MARKER.search(content):
            errors.append(f"{path.name}: working placeholder")
        if counts["problem"] != counts["psolution"]:
            errors.append(f"{path.name}: problem and complete-solutions counts differ")
        stack = []
        for match in ENV.finditer(content):
            operation, environment = match.groups()
            if operation == "begin":
                stack.append(environment)
            elif not stack or stack.pop() != environment:
                errors.append(f"{path.name}:{location(content, match)}: environment closure for {environment}")
        if stack:
            errors.append(f"{path.name}: unclosed environments {stack}")
        for match in LABEL.finditer(content):
            key = match.group(1)
            position = f"{path.name}:{location(content, match)}"
            if key in labels:
                errors.append(f"{position}: duplicate {key} at {labels[key][1]}")
            labels[key] = (number, position)
        references.extend(
            (number, match.group(1), f"{path.name}:{location(content, match)}")
            for match in REFERENCE.finditer(content)
        )
        if number == 291 and calibration and calibration.read_bytes().strip() not in data:
            errors.append("ch291.tex: the accepted B-03 body fragment is missing or changed")

    for _, key, position in references:
        if key not in labels:
            errors.append(f"{position}: unresolved source label {key}")
    return {
        "chapters": stats,
        "totals": {key: sum(row[key] for row in stats.values())
                   for key in ("tex_words", "sections", *SEMANTIC_ENVS)},
        "errors": errors,
        "forward_references_for_reading_review": [
            {"target": key, "source": position}
            for number, key, position in references if key in labels and labels[key][0] > number
        ],
    }


def check_pdf(pdf: Path) -> dict:
    import fitz

    with fitz.open(pdf) as doc:
        number_to_page = {}
        for level, title, page in doc.get_toc():
            match = re.match(r"(29[1-9]|30[0-4])\b", title.strip())
            if level == 1 and match:
                number_to_page[int(match.group(1))] = page
        labels = list(number_to_page.items())
        no_text = [page.number + 1 for page in doc if not page.get_text().strip()]
        return {
            "pdf_pages": len(doc),
            "pdf_sha256": sha256(pdf.read_bytes()).hexdigest(),
            "chapter_start_pages": labels,
            "unlocated_chapters": sorted(set(CHAPTERS) - set(number_to_page)),
            "pages_without_text_to_review": no_text,
            "outlines": len(doc.get_toc()),
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--pdf", type=Path)
    parser.add_argument("--calibration", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = check_source(args.source, args.calibration)
    if args.pdf:
        report["pdf"] = check_pdf(args.pdf)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return int(bool(report["errors"]))


if __name__ == "__main__":
    raise SystemExit(main())
