#!/usr/bin/env python3
"""Check the retained R1 style/tool provenance and licensed font dependency hashes."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
lock=json.loads((root/'provenance/template-lock.json').read_text())
failures=[]
for item in lock['files']:
    p=root/item['path']
    if not p.is_file() or p.stat().st_size!=item['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
        failures.append(item['path'])
print(json.dumps({'files_checked':len(lock['files']),'failures':failures,'status':'PASS' if not failures else 'FAIL'}))
sys.exit(bool(failures))
