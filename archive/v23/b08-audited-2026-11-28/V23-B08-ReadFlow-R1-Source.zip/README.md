# Complex Analysis · Volume 23

Chapters 291–304 · ReadFlow R1 · B08 reviewed edition

The included PDF is paired with these LaTeX chapters, layout inputs, fonts and
figure files. The original reference books are identified in the review notes.

To check the installed bytes and rebuild from this directory:

```sh
python verify_release.py
python verify.py
python tools/build.py --full --preamble layout/v23-breaks.tex --name release-rebuild
```

The build requires Python 3.10 or later, XeLaTeX and fontconfig. It uses the
supplied fonts and the TeX packages loaded by the adopted ReadFlow R1 template.
The new PDF appears at `.build/release-rebuild/build/entry.pdf`.
The supplied paired PDF has SHA-256 `5ab065c2e86241f7063074536efe80b12bb6054ba0f09117ec2e742d93c6ab40`.

Read `review/B08/HANDOFF.md` for the fixed source, review coverage and
handoff details.
