"""Verify the exact files in an extracted V23 delivery."""

from __future__ import annotations

import json
from hashlib import sha256
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> int:
    manifest = json.loads((ROOT / "MANIFEST.json").read_text(encoding="utf-8"))
    issues = []
    for name, expected in manifest["files"].items():
        path = ROOT / name
        if not path.is_file():
            issues.append(f"Missing {name}")
            continue
        data = path.read_bytes()
        if len(data) != expected["bytes"] or sha256(data).hexdigest() != expected["sha256"]:
            issues.append(f"Fingerprint mismatch {name}")
    if issues:
        print("\n".join(issues))
        return 1
    print(f"Verified {len(manifest['files'])} files, including the paired reading PDF.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
