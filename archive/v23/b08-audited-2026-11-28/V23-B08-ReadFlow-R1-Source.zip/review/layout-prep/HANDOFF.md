# V23 排版工程預備交接 v1

交接 ID：V23-LAYOUT-PREP-20261128-v1。發出角色：獨立排版子任務；接收：主控及後續內容作者／B-06 排版角色。日期：2026-11-28 UTC。實際模型及推理強度未獨立核實，均記 UNVERIFIED，不聲稱切換 Sol／High。

方案：使用者明確採用 V23 B 單一 Work。當前主線 B-01；本任務只準備後續工程依賴，不標 B-06 開始或完成，不審數學、不改數學正文。B-06 對應 A08–09，只有 B-05 全卷整合固定正文完成後才能正式接入；B-07 唯一打厚整卷終審及回修複核不變。

## 已實讀／版本核對

已實讀 project_sources/21-v2.1.txt、18-v3.txt、20-Git-QA-v3.txt、04-Math_Readability_System_Study_v1.html、05-ReadFlow_Editor_Operating_Draft_v1.md、06 交接、07 manifest 及 08 evidence；並實讀 v4 第三篇與 B 單一 Work 規則。歷史「未採納」措辭按現行明確採納處理，不引回舊模板。

固定 Git 方法文件已取回，保存於 v23-research/layout-fixed/：

| 檔案 | 固定 commit | SHA256 |
|---|---|---|
| SUCCESS-ANALYSIS.md | dde82ab6b14859774b7f26283bf15b6f2000847e | 6189a16745cd2098ee5ec3fb9237b96c3d42aae1d17f8a373f7431ca3f740fd3 |
| REUSE-GUIDE.md | 同上 | 25c1cda4709e7e7b5b2de48db5243566b148f11e0e883f1459a2f29bc31dd441 |
| HANDOFF-SUCCESS-v1.md | 同上 | 261ca918e5b3e1a2b0f600846e3566e5e55fb89102e1d10b8b74b8c25a523ae5 |
| METHODOLOGY-v1.md | f4969cc5336bf761d5f80ff616531f85b357a475 | a2d89bba12f74b2eac883fd9009a85acec95e2ae9dbf50a3a54b9af9063330df |
| EDITOR-QA-v1.md | 同上 | 152c3b0ea5f3d6b702d31c89a27f8bea61980847493131d5a601f051d9e943c5 |

成功分析、重用指南、方法論及 QA 已全文實讀；交接亦已核其證據、OPEN 與禁止事項。沒有為本預備任務重新跑歷史研究或修理凍結稿。

## 正式模板身份及依賴

直接由 Git 固定 commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3` 取回 `archive/v0/readflow-r1-editorial-2026-11-17/V0-ReadFlow-R1-Source.zip`。

- 實測 7,007,679 bytes；SHA256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`，與 18-v3 完全相符。
- ZIP CRC PASS；全部 913 個 MANIFEST 成員 bytes/hash PASS。這是身份核驗，沒有重編或審核 V0。
- 書架保留四個原樣樣式：layout/shared/readflow-base.tex、layout/shared/style.tex、layout/study/config.tex、layout/study/readflow-layout.tex；原 build.py、verify.py、MANIFEST.json 原樣留 provenance/readflow-r1，僅為來源證據，不執行其 V0 入口。
- R1 ZIP 自身不附字型。只從 V22 來源包 dependencies 子樹復用 11 個字型及其合法通知／授權；沒有移植 V22 正文、章表、圖或補丁。
- 三個主要樣式 hash：base `cc9cc678504651f8f1baa196a714a70de1331684589d71b14353c77ec6f6f63b`；config `fdccf765bbb70ff9f8b178a81af841d721cb4f962c9d90ddb476d5728e1c0424`；layout `b04bf2f5bb7611b8a4899c9a582050681d36d71fba8b0c44a31f8d87d2924f69`。
- provenance/template-lock.json 固定 29 個樣式、上游腳本／manifest、字型及通知檔；根 verify.py 核查 PASS，build 每次先核。

實際 XeLaTeX：XeTeX 0.999996／TeX Live 2025/dev/Debian。字型解析及版本見 environment.json。Noto Sans、Asana Math、DejaVu Sans Mono 都實際解析至本卷 dependencies/fonts，hash 相符；PDF 字型嵌入見 pdf-fonts.txt。PagellaX 及 STIX 用原 R1 檔名設定及 OPENTYPEFONTS 指定目錄，沒有字型替換。

## 檔案及作者接口

唯一新卷正文位置預留 book/chapters/ch291.tex 至 ch304.tex；本任務未建立或改動任何一章。章號 291–304 由主控已核卷界傳入，本任務不重新決定 Git 章界。

作者環境、label、巨集規則已先傳主控，完整列 README.md。特別注意 R1 的 `\C` 是 `\mathcal C`；複數用 `\CC` 或 `\mathbb{C}`。本卷 adapter 增加 `\CC`、`\RR`、`\ZZ`、`\NN`、`\Res`、`\Log`、`\Arg`，不重定義既有 `\Re`／`\Im`。

本卷局部 patch 只有 layout/v23-adapter.tex：三位數章號 TOC 寬度、前後頁 running context、上述記號別名及 square fallback。沒有更改 R1 字級、行距、幾何、色彩或數學環境。最小 frontmatter 主標題為英文 **Complex Analysis**；backmatter 只有註解，待來源責任角色填核訂書目。

建置：`python v23-staging/book/tools/build.py --full --name b06-candidate`；個章／代表節見 README。程式使用 R1 收斂迴圈及 V22 通用工程包裝慣例，先複製輸入並記 hash，每次新 run 不覆寫舊證據。預設輸出 .build/name/build/entry.pdf。保留獨立 format/cache/fontconfig，no-shell-escape。

## 已核證據與限制

1. 在獨立 /tmp 目錄生成可丟棄的十四章假內容，從 291 至 304，測全部標準數學環境、proof／solution／QED、短 Remark/Why、60 行可分頁 align、交叉引用、TOC／書籤及本卷標題。
2. XeLaTeX 三輪收斂，20 頁；hard／overfull／header diagnostics 全零；60/60 預期行標識可見；PDF 主標題 Complex Analysis；末章 304 存在；PDF 使用嵌入字型。
3. 依序查看全部 20 頁合成縮圖，另放大第 5 頁檢短 Remark/Why、proof／QED 及長 align 開始；未見該樣本的碰撞或裁切。這不是正式數學正文全頁視檢，不聲稱 B-06 已通過。
4. 負向控制故意放入壞引用及超寬線：正確退出 1，報 ENGINEERING_DIAGNOSTICS，捕捉 undefined reference 和 overfull hbox。
5. 所有合成章、快照、PDF、渲染、cache／format 及臨時目錄已刪除；沒有假章留在 book/chapters，也未覆寫作者章。保留兩次 build-report、console、正向 log、PDF 檢查及環境等純工程紀錄。報告中的 /tmp 路徑明確已刪除，不能視為可取正式來源／PDF。

內容保留：尚無 B-05 固定正文可比對，NOT APPLICABLE。工程：僅合成樣本 PASS。正式全頁閱讀：NOT STARTED。數學終審：NOT STARTED。真人理解／跨系統／實體印刷／輔助科技：UNKNOWN。

## OPEN、下一步、通過條件及禁止重做

| OPEN | 責任／下一步 |
|---|---|
| 本卷核訂正文及書目尚未接入 | B-01 至 B-05 原責任角色按原序完成；本任務不提前代寫 |
| 模型及推理強度未獨立可核 | 主控保留 UNVERIFIED；不得以角色名推定模型 |
| 300 頁左右只供內容篇幅規劃 | 實際頁數由必要數學決定，不拉行距、不灌空白、不以頁數驗收 |
| 正式全頁視檢與數學整卷終審未做 | B-06 收 B-05 固定稿後重編、逐頁看畫面及順讀；B-07 打厚唯一終審 |
| 歷史六全局門檻、16／22 映射及來源 UNKNOWN | 全部保留，不因模板恢復／工程測試而清零或解凍 |

下一唯一動作：主控接收作者接口與工程 scaffold，繼續當前 B 主線；不用重取已核模板。正式 B-06 接收時必須核 B-05 唯一整合來源／覆蓋／OPEN 版本並回執，才能編正式候選；全部必要內容可見、引用及字型正確、全頁視檢／順讀完成後交打厚 B-07。

禁止：不移植 V0/V22 正文、不解凍、不重排舊卷、不動分卷／文獻表或工具 ZIP、不用合成 PASS 冒充真稿通過、不用工程／hash 代替數學驗收、不新增逐節使用者批准、不推送 Git 或外部保存。

傳遞：早期作者接口已透過內部訊息送主控；本檔及工程檔在共用工作區可取。實際送達不等於主控已讀；尚待主控列實讀版本及缺檔的接收回執。未送外部 Work，未發布或外部保存。
