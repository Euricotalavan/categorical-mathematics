# V23 B-07 交接｜《Complex Analysis》第 291–304 章

【交接】

交接 ID `V23-B07-20261128-v1`。發出角色為未參與本卷起稿、打厚、精修或排版的獨立打厚終審。接收角色為本 Work 主控及 B-08 封存承辦，正式交接在同一 Work 內完成。實際模型及推理強度未獨立核實。

**B-07 正式整卷終審 PASS。** 2026-11-28 UTC。裁決只對本交接指定的章稿鎖定清單與配對 PDF 生效。未見尚未處置的數學阻塞。

依使用者對 V23、B 方案單一 Work、獨立子任務與全 B-01–08 的授權。本次為 B-07，對應原 A 的 10–12 步。分卷表為 `math-curriculum-v4-git-aligned.html` v4，SHA-256 `098aaacab85e330cb0493fc928916361c3fba09c0d36b3964f61c74ad2a2e1df`。前卷章序依固定 V22 已發布 Git `0c1b95031d31162eb4f2026b6e7e0d2aa6839074` 的 `archive/v22/b08-audited-2026-11-28`，前卷末章 290。本卷正式章號 291–304，邊界以 B-02 固定設計為準。主控替代本次授權的人工作業關口，數學裁決始終由獨立打厚作出。

## 檔案清單

下列為本 Work 接收和封裝的實體檔。固定正文逐檔名稱、位元組與 SHA-256 以章稿鎖定清單為準。B-06 閱讀 PDF 與實際編譯輸出逐位元相同，B-08 封裝時須保留相同位元組。

| 用途 | 固定檔或入口 | Bytes | SHA-256 或核驗方式 |
|---|---|---:|---|
| B-02 邊界與證明安排 | `B02/design.md` | 11,496 | `acbc3a9b0d58accf9cb62f2acefc11af66426dd0ed2a701251cfdc655d416f83` |
| B-01 基礎項目索引 | `B01/foundations.md` | 29,542 | `907c9990a904f848c3fb97c426f62d8b08fcd2668e9e9853e0beaddecc9a5ab7` |
| B-01 全域項目索引 | `B01/global.md` | 29,072 | `bd0802aed0ca0b0457486974b71f6d97d0e502d54d24f00aa04d2d7c0c55a7a8` |
| B-01 進階項目索引 | `B01/advanced.md` | 23,932 | `2c8c6bf59fc6d18ce4857008e8cb08972b1621cdbaa6869b98d650d5ea66745a` |
| 出版版核讀範圍 | `B01/published-editions.md` | 14,904 | `07262050d941c729b646dbcf6138a8ce616015438c3cbe45dbcff1095f9e3f10` |
| Conway 補充核讀 | `B01/conway-full-access.md` | 1,995 | `9415b229e8c0a08297f4761d6f617a59fa255c1eaf1adbb3343558a5311ff305` |
| 終審唯一章稿清單 | [final-source-lock.json](sandbox:/workspace/scratch/57dcaeb95aa3/v23-staging/B06/final-source-lock.json) | 4,110 | `e2f6775fa50993d1cb21073e1f23258a745b0c3d52e0cffd2499d88e25abb349`，實算清單與十四檔 |
| 終審唯一配對閱讀 PDF | [V23-B06-ReadFlow-R1.pdf](sandbox:/workspace/scratch/57dcaeb95aa3/v23-staging/B06/V23-B06-ReadFlow-R1.pdf) | 1,161,523 | `5ab065c2e86241f7063074536efe80b12bb6054ba0f09117ec2e742d93c6ab40`，實算 PDF、262 頁及書籤 |
| B-06 完整來源與 PDF 清單 | `B06/SOURCE-PDF-MANIFEST.json` | 9,854 | `d2b31cd24c322009283609903e685cc90b3b013dab390919a4973fdfc7120c78`，重算 54 個來源成員及 PDF |
| B-06 全頁視讀與導覽 | `B06/qa/render-final-reader/mechanical-pdf-checks.json` | 124,685 | `3b877950b911c7f89f72d22d8ab005911459ccd1586745f65d00adcde5a87026`，44 張順讀縮圖涵蓋全部 262 頁 |
| B-06 排版交接 | `B06/HANDOFF.md` | 3,056 | `dad33ba55e5fbcd10b0e35ad7668dcf92b9961df7fccd0cd6c79e7dffbc39f87`，已讀，配對指紋相同 |
| 全卷建置及快照配對 | `book/.build/b06-final-reader/build-report.json` | 8,117 | `f5f9cd55192543dac25f713e7254cf641198838795345c69241932ffd6d05cff`，核心輸入與 PDF 全對 |
| 正式模板恢復基線 | `V0-ReadFlow-R1-Source.zip`，Git `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，Library v3 `libfile_fde3_f-eb9eb2144e748191a467e61bed5290ae_383d682b1c388191a1961becbec9fb77` | 7,007,679 | `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`，取回及 CRC 由排版預備實核 |
| 樣式與字型依賴清單 | `book/provenance/template-lock.json` | 5,407 | `d79c5dea9cd1ab2e28941575e95a418e8158f03e4565944dc663ab687e255888`，正式樣式與內附字型／授權隨本卷來源 |
| 本卷記號與版面適配 | `book/layout/v23-adapter.tex` | 825 | `3634068003d573596920ff0301d17cb866f4be9ce31e0ec392effcfd883f90f6`，原件及建置快照相同 |
| 第 292 章局部分頁處理 | `book/layout/v23-breaks.tex` | 523 | `aa4cedd0e2e651b2ef018bf1ef857e73a3262a4bf0efed6dd05424fbeb4624cf`，原件及建置快照相同 |
| 終審逐章證據與缺陷表 | [audit.md](sandbox:/workspace/scratch/57dcaeb95aa3/v23-staging/B07/audit.md) | 由 B-07 機讀清單登記 | 終審先獨立實讀十四章，再核 B-04／B-05 缺陷史與精確修補 |

## 完成範圍與分層證據

- **數學與閱讀順序。** 逐章查定義與型別、量詞、相等與良定性、相依順序、證明和例題，再對照固定來源責任。實核全域 Cauchy 的對角差商、有限繞數留數、Monodromy 的路徑存在假設、正常族及球面圖卡、Riemann 極值證明、外域面積與增長下界、Hadamard 的好圓、Poisson–Jensen 和原點規範、第一基本定理及兩個 Picard 定理。章內共 136 題與 136 份解答，數量僅為交付盤點。
- **修訂及複核。** B07-01 至 B07-04 均已對原文、讀者影響、改文及實際印頁複核。第 298 章接通兩種單連通表述並明寫反射題的連續延拓條件，第 300 章只聲明已證的徑向最短路徑，第 302 章分別處理常數與正次多項式的階。第 300、302 章末兩題解的精簡保留各個證明條件。自 B-05 唯一稿只有 298、300、302 改變，連帶使用處的證明仍有效。B-03 代表節逐位元保留。
- **配對與工程。** 可恢復建置命令為 `python tools/build.py --full --preamble layout/v23-breaks.tex --name release-rebuild`，在 `book/` 下執行，由 XeLaTeX、fontconfig 與內附字型建置。原輸出三輪收斂，十四章、三幅圖與適配檔的來源及快照均精確相符。引用與書籤可用，零阻斷錯誤、零溢欄或頁眉錯誤。排版的九處非阻斷 Underfull 記於 B-06，字型相容提示與非浮動圖 caption 的 hypcap 提示分列。
- **閱讀及版面。** B-06 使用相同 PDF hash 順序視檢實體頁 1–262，含放大複核。B-07 另讀三幅輪廓圖、各處修訂與關鍵公式，均吻合已核稿。正式 R1 共用樣式維持基線，本卷僅有記號／三位章號適配、單一局部分頁控制及兩份章末題解的等義行文整理。

## OPEN／UNKNOWN、授權與下一步

| ID | 未決範圍與影響 | 責任與下一步 | 阻塞 |
|---|---|---|---|
| OPEN-PUB-01/02 | 三本出版版僅有記錄所列的合法資料與選段核讀。Conway 的後續同版選段補核已列，仍非全書。 | 來源負責角色在未來獲得可讀原書時只補受影響項。 | 不阻本卷封存 |
| HIST-16/22、HIST-SIX | V0／V3 歷史的主題與章號對照，以及六個全局門檻原名仍未知。 | 原規劃角色。有新指示才續查，不據本卷裁決清除。 | 不阻本卷封存 |
| ENV-MODE、READ-USABILITY | 部署端模型與 High 未獨立驗證。跨系統、實體列印、輔助科技與讀者成效未作實驗。 | 主控保留記錄。 | 不阻本卷封存 |
| B08-VERIFY | 恢復包及遠端固定版本、可見性與授權核驗屬封存階段。 | B-08 回下載逐檔驗證及核 PDF 同一性，僅在已有授權與經驗證的可見性內完成封存。 | B-08 完成前必核 |

唯一下一階段為 B-08。接收後請列實際讀入的兩枚配對指紋、審核證據及封存承辦結果。不可覆寫舊卷、重排凍結稿、變更章號、擴展來源範圍、外傳受限教材或重做已核證明。來源或配對 PDF 如再變更，按實際差異回 B-07 重核。待使用者決策無。本交接提交主控於同一 Work，主控及 B-08 接收者的讀入回執另記，這次終審交接本身不作外部發布。

【接收回執】

本獨立 B-07 已讀入 B-02 固定設計、B-05 鎖定稿、B-06 最終章稿清單及十四個正文實體、精確配對 PDF、建置報告與必要快照、B-06 最終配對清單及全頁回執。來源及歷史缺陷記錄於獨立全章讀完後進行對照。每個指定檔案可讀，十四章及配對 PDF 版本無衝突。已完成 V23 第 291–304 章 B-07 數學終審與修後複核，接受上表固定配對供 B-08 續作。
