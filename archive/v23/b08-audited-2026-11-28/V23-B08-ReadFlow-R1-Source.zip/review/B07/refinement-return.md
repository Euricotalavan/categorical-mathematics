# V23 B07 pending｜四項定界精度修正

2026-11-28；接主控指定的獨立B07預備審查修正。只寫本目錄三份完整候選章稿及本回執，未改book、master或既有卷。候選尚待獨立精確delta接收與主控提升，不宣稱B07已通過。

| 章 | 輸入SHA-256（當下book實算） | 候選SHA-256 |
|---|---|---|
| 298 | `ddca3af33f0c40b3fad2404f71f6789d8151434cbb5b8b16bab3e68181421df9` | `61dadf0d66cdd9d3bee6a42aed2ac8787e6ba3218b69feb93a7615ad19360d17` |
| 300 | `b5e6cab9e797f0af3bcb816900fbef9800136650f21e84fcdb2b4bda825eb615` | `8170bff35e8deac9ab8d86a7d9764d2290d20c82ed996a39ff68aa2812f430e0` |
| 302 | `2d84bee94f6b2857504b091f3361cc95c2a275cca36872debf5de227325aacf6` | `171afae87a3b17f2251f9cab5c1bfa58df4369eaac55dc813e5c10e698bfa50b` |

298補自由閉路收縮到固定基點收縮的實際橋接：beta_s(t)=b(st)作移動基點的共軛，固定三段參數保連續；終端retracing以顯式K(t,u)收縮。再以gamma*sigma逆及取消retracing得到固定端點同倫，未增加域的假設。僅兩個反射題的連續性文字補強為半盤與直徑聯集上的連續延伸，主反射定理與證明未改。300僅改徑向線段「實現距離」的已證結論；302分開常數與非恆多項式，避免常數的小模使無正部loglog未定義。

所有差異精確列下；沒有其它正文改動。實際模型／High設定未另核實。後續由獨立角色核同hash/delta，再由主控提升重編PDF與安排必要版面複核。

## 第298章精確diff

```diff
--- book/chapters/ch298.tex
+++ B07/pending/ch298.tex
@@ -264,13 +264,38 @@
 would largely assume the desired conclusion. Nor does it differentiate
 along the homotopy, an operation unavailable for merely continuous data.
 
-A domain is simply connected if it is path connected and every two
-paths with common endpoints are homotopic relative to those endpoints.
-Equivalently every based loop can be contracted with its base point
-fixed: concatenate one path with the reverse of the other, contract
-that loop, and cancel the retraced portions. Retracing is contracted by
-shortening the distance traveled along it continuously; changes of
-parameter do not affect the homotopy class.
+The simple connectivity used in Chapter~\ref{ch:293} means that every
+closed path can be contracted through closed paths; its base point may
+move. This also gives contractions with a fixed base point. Indeed, let
+$H(t,s)$ freely contract a loop $\eta$ based at $a$, so
+$H(t,0)=\eta(t)$, $H(t,1)$ is constant in $t$, and
+$b(s)=H(0,s)=H(1,s)$ satisfies $b(0)=a$. Put
+$\beta_s(t)=b(st)$. The loops
+\[
+ \beta_s*H(\cdot,s)*\beta_s^{-1},\qquad 0\le s\le1,
+\]
+are all based at $a$ and depend continuously on $s$, using three fixed
+parameter subintervals for concatenation. At $s=0$ the loop is $\eta$
+with constant pauses; at $s=1$ it is $b*b^{-1}$ with a constant pause.
+Pauses can be removed by linearly interpolating their nondecreasing
+parameter schedules with the identity schedule, keeping endpoints fixed.
+For any path $b$, the retraced loop $b*b^{-1}$ contracts at its base
+point by traversing $b$ only as far as parameter $1-u$ and returning:
+\[
+ K(t,u)=
+ \begin{cases}
+ b(2(1-u)t),&0\le t\le1/2,\\
+ b(2(1-u)(1-t)),&1/2\le t\le1.
+ \end{cases}
+\]
+This is continuous, starts with the retraced loop, and ends at the
+constant loop. Conversely a fixed-base contraction is a free contraction.
+Finally, for paths $\gamma,\sigma$ from $a$ to the same point, contract
+$\gamma*\sigma^{-1}$ at $a$ and concatenate with $\sigma$.
+Cancelling the retraced portion $\sigma^{-1}*\sigma$ by the same
+construction gives a homotopy from $\gamma$ to $\sigma$ relative to
+both endpoints. Thus the earlier definition supplies exactly the
+endpoint-fixed path property required by the monodromy corollary.
 
 \begin{corollary}[Single-valued continuation]\label{cor:298-single-valued}
 If $U$ is simply connected and a germ at $a$ can be continued along every
@@ -631,8 +656,9 @@
 \end{psolution}
 
 \begin{problem}\label{prob:298-imaginary-reflection}
-Suppose $f$ is holomorphic on an upper half-disk, continuous on its open
-real diameter, and has constant real part $c$ there. Write its reflected
+Suppose $f$ is holomorphic on an upper half-disk and extends continuously
+to the upper half-disk together with its open real diameter. Suppose the
+extension has constant real part $c$ on the diameter. Write its reflected
 extension and prove the matching condition.
 \end{problem}
 \begin{psolution}
@@ -647,9 +673,10 @@
 \end{psolution}
 
 \begin{problem}\label{prob:298-zero-boundary}
-If a holomorphic function on an upper half-disk is continuous on the
-diameter and zero on a nonempty open subinterval of it, prove it is
-identically zero.
+If a holomorphic function on an upper half-disk extends continuously to
+the upper half-disk together with its diameter, and that extension is
+zero on a nonempty open subinterval of the diameter, prove the function
+is identically zero.
 \end{problem}
 \begin{psolution}
 Choose a smaller disk centered at a point of that subinterval whose
```

## 第300章精確diff

```diff
--- book/chapters/ch300.tex
+++ B07/pending/ch300.tex
@@ -686,10 +686,9 @@
 The length formulation also proves the triangle inequality:
 concatenate paths with lengths arbitrarily close to the two
 infima. Reversing paths gives symmetry. Thus this is a genuine
-distance, rather than just a two-point expression. Its
-geodesics from zero are radial segments; applying inverse
-disk automorphisms gives shortest paths between arbitrary
-points. No classification of all such paths is needed for
+distance, rather than just a two-point expression. Radial segments
+from zero realize this distance; applying inverse disk automorphisms
+gives shortest paths between arbitrary points. No classification of all such paths is needed for
 the contraction argument.
 
 For a proper simply connected $U$ with a disk coordinate $f$,
```

## 第302章精確diff

```diff
--- book/chapters/ch302.tex
+++ B07/pending/ch302.tex
@@ -81,7 +81,7 @@
 It does not in general give $\log M(r,f)=O(r^\rho)$. A small increase in the exponent is essential in several proofs below.
 
 \begin{example}[Different kinds of order]\label{ex:302-orders}
-A nonzero polynomial has order zero: its maximum modulus grows at most as a fixed power of $r$, so $\log\log M(r)=O(\log\log r)$. For $b\ne0$ and integer $d\ge1$, $f(z)=e^{bz^d}$ has $\log M(r,f)=|b|r^d$ and order $d$. The maximum is attained by choosing $z$ so that $bz^d$ is positive real. The function $e^{e^z}$ has $M(r)=e^{e^r}$, since $\operatorname{Re}e^z\le e^{\operatorname{Re}z}\le e^r$, with equality at $z=r$. Its order is infinite.
+Nonzero constant polynomials have order zero directly from the positive-part definition. For a polynomial $P$ of degree $k\ge1$, its leading term gives $\log M(r,P)=k\log r+O(1)$ as $r\to\infty$, so $\log\log M(r,P)=\log\log r+O(1)$ and its order is also zero. For $b\ne0$ and integer $d\ge1$, $f(z)=e^{bz^d}$ has $\log M(r,f)=|b|r^d$ and order $d$. The maximum is attained by choosing $z$ so that $bz^d$ is positive real. The function $e^{e^z}$ has $M(r)=e^{e^r}$, since $\operatorname{Re}e^z\le e^{\operatorname{Re}z}\le e^r$, with equality at $z=r$. Its order is infinite.
 
 Noninteger orders occur as well. Define
 \[
```

## 實際合入及記號對齊

終審角色複核三份修補提案與四項變更。主控合入前將第 298 章新段中的五處反向路徑上標對齊第 292 章已定義的上標 `-`。298 實際固定 SHA-256 為 `1cb9a880cce50a5adc6e2554b8f606be8e061c0a26987ac2f6b9389aed5af725`；300、302 均為上述提案精確位元。同一位置、連續性假設與主證明須對 B-06 回編後的實際來源與 PDF 作最終複核。章集鎖定 SHA-256 `bf59c34427a7872da1d6ec7f586bb1642271908583ae08384edfb178c1adfe02`。
