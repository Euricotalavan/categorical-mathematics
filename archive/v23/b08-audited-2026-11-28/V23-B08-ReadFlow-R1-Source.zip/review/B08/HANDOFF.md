# V23 B-08 交接｜Complex Analysis

交接 ID `V23-B08-20261128-v1`。採 B 方案單一 Work，第 291–304 章。使用者於文獻準備後確認來源並授權 B-01 至 B-08，由主控負責原本要人審的節點。擴充、逐節打厚、精修、排版和唯一整卷終審各有獨立任務與實際回執。部署端實際模型與推理級別無另行核實證據。原 A 步號對照見總規範，B-08 對應第 13 步。

## 固定交付與可恢復入口

| 檔案或基線 | 核對資料 |
|---|---|
| 英文讀本 `V23-B08-ReadFlow-R1.pdf` | 262 頁，1,161,523 bytes，SHA-256 `5ab065c2e86241f7063074536efe80b12bb6054ba0f09117ec2e742d93c6ab40` |
| `V23-B08-ReadFlow-R1-Source.zip` | 唯一正文 `chapters/ch291.tex` 至 `chapters/ch304.tex`，含同一份 PDF、原始圖、編譯相依、查核程式與本卷歷程。根目錄 `MANIFEST.json` 列檔名、位元組數及 SHA-256 |
| `review/B06/final-source-lock.json` | 14 章固定清單，排版輸入與 PDF 配對見同目錄 SOURCE-PDF-MANIFEST.json，SHA-256 `e2f6775fa50993d1cb21073e1f23258a745b0c3d52e0cffd2499d88e25abb349` |
| V22 章號基線 | Git commit `0c1b95031d31162eb4f2026b6e7e0d2aa6839074`，V22 實際驗至 290 章 |
| V0 正式 ReadFlow R1 | Git artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，固定來源 ZIP SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。保留的 29 個依賴核驗通過，V23 章首與分頁調整見 `layout/` |

解壓後在根目錄執行 `python verify_release.py`、`python verify.py`。重建命令為 `python tools/build.py --full --preamble layout/v23-breaks.tex --name release-rebuild`。用另一目錄重建驗得 262 頁、書籤逐項相同、262 頁在 72 dpi 的像素逐頁相同。重建 PDF 位元組指紋與固定 PDF 各見 `review/B06/independent-rebuild.json`。恢復時以交付 PDF 的固定指紋核對封存件。

## 已核證據與相依變更

| 階段 | 已核事項與檔案 |
|---|---|
| B-01、B-02 | `review/B01/` 三個責任片共 214 筆，出版版選段及各來源可讀範圍附列。總跨度、先備及各章證明鏈見 `review/B02/design.md` |
| B-03、B-04 | 代表節的審定片段在第 291 章原樣嵌入。14 章均有逐章獨立打厚與精修的回執，見 `review/B04/` |
| B-05 | 四組整合順讀、正文落點及全卷連續依賴紀錄在 `review/B05/`。明列簡單圍道特化的 Jordan 輸入，以及面積定理可選極限詮釋的平面面積連續性 |
| B-06 | 三輪 XeLaTeX 無硬錯誤、未解引用或溢出，14 個章書籤依序正確。全 262 頁實際視檢及完整工程證據見 `review/B06/` |
| B-07 | 由獨立打厚角色先順讀固定稿，再追修訂史。終審找出的四處問題均有原責任角色修訂及獨立再驗。最後數學簽核與覆蓋落點見 `review/B07/HANDOFF.md` 及 `review/B07/audit.md` |

全書 119 個編號小節，110 個例題，136 道習題一一配完整解答。收尾局部分頁後再核第 298、300、302 章受影響的段落和配對 PDF，校準節原樣保留。成書篇幅參照本卷實讀來源，262 頁接近 Langley 的 266 頁講義。第 294 章連通域、第 295 章鏈權重、第 301 章外域反函數辨認實際邊界的路線，及 B-07 四項精度修補，皆可從各階段缺陷表查到改文和重核證據。

## 保留項與接續

- 數學終審無未結的阻塞缺陷。版面編譯的字距和既有套件警示已分類並核看受影響頁。
- Ahlfors、Conway、Stein–Shakarchi 各有未逐頁核讀的出版版段落，保持該欄 UNKNOWN。用到的選段與允用依據見 B-01。第 304 章定界為 Nevanlinna 第一定理與 Picard，第二定理留在卷界之外。
- 本次交付為固定來源和配對 PDF。已查 Git 基礎專案的公開可見性，這次授權涵蓋定稿及封存。第三方教材全文、帳密及金鑰未打包。
- 接收以配對檔及根目錄清單核對。恢復、引用或往後另獲授權發布時沿用這個固定版本。章號與正式模板以列出的基線接續，既有定稿不得重做或覆寫。

## 先前固定配對

B-06 配對檢查點 `V23-B06-Paired-Checkpoint-v1.zip` 已實際取回並核出原指紋。版本 v0，4,445,435 bytes，SHA-256 `55f3aedf5e9ed87eaecfde1c1cf4e8485567270d3e9ececb8b180b8c874e8e1f`，Library ID `libfile_fde3_f-402a41bfaf3c819191f93a6ecf7434b4_383d682b1c388191a1961becbec9fb77`。本次封存沿用其中已核配對 PDF，換成 B-08 的檔名並補入獨立終審證據。
