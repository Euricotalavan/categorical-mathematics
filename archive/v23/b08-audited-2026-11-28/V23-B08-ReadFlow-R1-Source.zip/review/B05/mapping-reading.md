# V23 B-05｜299→300→301整合順讀與接口精度 v1

回執ID：V23-B05-MAPPING-20261128-v1。B方案單一Work；本輪只做整合順讀與有界precision patch，不是B-07正式整卷終審。模型及High設定未另核實。

已先實際讀到`LOCKED`，實算`source-lock.json` SHA256為`863e78cd798397b3b173af076b35845426002d37fedb4c91b65ad5bf6c103611`，與marker一致，再開始正文核查。以下6個實體檔均與該鎖相符，未改book/master。

| 章／book/chapters固定輸入 | SHA-256 |
|---|---|
| 298 | ddca3af33f0c40b3fad2404f71f6789d8151434cbb5b8b16bab3e68181421df9 |
| 299 | 62c0d576f4e4113e3ab63abca39ebc797fb6bd9e46ec671b6dca329bc447c615 |
| 300 | ff6728556b8fb8508f8f5fa29d3c2df6916bb3fa2034d98f4d3c438fd1f73ca7 |
| 301 | f6144681bad3b6b979c9cb944623aef614e55c8c0213e30294fdc7e4c7eb0f5b |
| 302 | 2d84bee94f6b2857504b091f3361cc95c2a275cca36872debf5de227325aacf6 |
| 304 | dcd2f7ebbe9d4efd175d454c6e6a892aef4b23c129413493a9c5309545794912 |

## 實讀與角色揭露

本輪按299（compact convergence至10題解）→300（local/global至10題解）→301實際章首、area/root、distortion/growth/compactness及尾題接口順讀。301的同一hash正文已於前輪精修完整讀入1085行與全部10題解，本輪以鎖定實體再核接縫，沒有把hash本身當語意證據。298讀global log/root正式陳述與證明；302讀Jensen／product中相應log依賴；304讀sphere density、comparison、omitted Montel接口。沒有聲稱本輪獨立終審298／302／304全部內容。

獨立性界限：299主章、300主章、301主章均非我起稿；但299的moving-poles應用補充由我起稿，已在本稿中見到他人精修後版本，其獨立核准仍交主控安排的另一審查者，不以本報告自審背書。301先前精修是我執行，不能把這次B-05順讀說成第二份獨立終審。302／304曾由我起稿，這裡只核接口契約，非另給自己正文獨立通過。

## 已核接口與閱讀次序

| 接口／實際落點 | 已核證據 |
|---|---|
| 298→299／300／301／302 | `thm:298-log-root`先建局部log、finite chain、每路存在、monodromy，再給無零函數在簡連通域的全純log/root。299 binomial用的是已指定近1級數支；300 bounded injection及RMT improvement只對無零函數開方；301 odd-root先消原點零且H(0)=1；302先精確消全部零重數才取整log。無循環借303 Poisson–Jensen或304省略值Montel。 |
| 299有限值／sphere兩種compactness | `thm:299-weierstrass`在Montel前；locally bounded、finite-valued normal與spherical normal分定；常數n容∞但不有限值normal。sphere limit兩charts及holomorphic limit無孤立pole由Hurwitz給，omitted-value只保非恆常limit不取被省略值。Marty以同一sphere derivative與局部charts證雙向。 |
| 299→300 RMT | 300先證真簡連通域有bounded injection，才取正導數sup；299 finite-valued Montel、derivative convergence及univalent-limit定理排所有constant；漏值b≠0的square-root improvement因子(1+s)/(2√s)>1有明確證明，沒有提前用301quarter或distortion。 |
| 300→301 inverse／area／normalization | `prop:300-univalent-inverse`、Joukowski、disk automorphisms均先給。301 Σ明定外域，Koebe裂縫−1/4與外倒數[−4,0]一致。a2以odd root搬至b1，quarter搬至每點。r_U=1/f_normalized′與B_f=(1−|a|²)|f′|一致，δ比較的兩常數及source scaling一致。area所需額外拓樸先備見下表，已另備去除它的patch。 |
| Schwarz／length尺度 | 300盤density是2/(1−|z|²)，half-plane density1/Im z，距離log((1+r)/(1−r))；301 two-point log B界故是2d。299／304 sphere line element均|dw|/(1+|w|²)，χ同式；299用unit-sphere embedding時speed/chord同有factor2，304用radius1/2 embedding時兩者均無factor2，最終χ≤∫f#一致。 |
| 299→304 compactness | 299明示省略值Montel延至304；304先獨立證λ0負曲率比較，再以8/(3cR)的sphere derivative bound及299 chordal-length/Ascoli推出normal。Möbius把第三省略值送∞後，以reciprocal chart說明原pole處composition仍holomorphic，無定義域暗缺。 |
| 題解／source scope | 299、300本輪10題／10題全解讀完；301同hash10題全解前輪完整核，本輪重核其相關尺度、root、inverse與sharp examples。W/L的area／root／quarter錯植沒有搬入。General Carathéodory／SC全域存在、完整曲面覆蓋及second main theorem均未被當必要已證先備。新增sphere／metric／inverse推導由正文證明，不冒稱原書頁標即證明。 |

三主章的所有`ref/eqref`在14章鎖定正文均有實際label（299/300/301各10、9、8個section，均10題）；這只是交叉引用存在檢查，非語意通過替代。

## 缺陷與有界patch

| ID／鎖定位置 | 影響／修正 |
|---|---|
| B05-MAP-01，300 `ex:300-cayley`，原130行 | −i被稱作H的boundary point，實為下半平面的pole。copy改「The pole −i」，原Cayley公式不變。 |
| B05-MAP-02，300 `ex:300-half-disk`，原269–270行 | 誤把「平方在full half-plane單射」說成錯誤，與301正確的右半平面平方單射衝突。copy改為quadrant平方onto H、整個右半平面平方onto slit plane，保留原biholomorphic計算。 |
| B05-MAP-03，301 `thm:301-growth`，原624–637行 | 數學有效，但未明列AC/a.e.鏈律先備；300相應距離證明已用ordinary Riemann/FTC。copy改為inverse lift在s>0不為零、γ(s)/s在0 smooth非零延伸，ρ=s|γ/s|為C¹且ρ′≤|γ′|；普通chain rule／FTC即足。題解的continuous tangent共同方向亦改「throughout」而不用a.e.。 |
| B05-MAP-04，301 `sec:301-area` | 鎖定稿先借一般simple-closed-curve分離以辨外域像、定orientation，不在B02明列先備中。按主控指定另備copy：定Ωr=g(|ζ|>r)；∞chart保大值皆取；bounded preimage序列證finite boundary⊂g(circle)；每圈點local inverse加global injectivity辨內外side，得Kr bounded smooth boundary，conformality給內側在左，直接Green。annulus面積差改用Ωr\ΩR的set identity，不用Jordan分類。 |

| 新的完整copy（只供獨立打厚複核） | Bytes／SHA-256 |
|---|---|
| `ch300-precision.tex` | 46318／b5e6cab9e797f0af3bcb816900fbef9800136650f21e84fcdb2b4bda825eb615 |
| `ch301-precision.tex` | 44982／5728264977dd4d04e769cc45475bc6222f24a039d9ca77893242e4dec8ad2ce5 |

copy labels全保留（300為42、301為46），無重複，環境計數平衡。原book／source-lock未被本角色修改；沒有編譯或PDF／版面通過宣稱。

OPEN-MAP-05：301原有後續段仍把K=∩Kr的面積寫成lim A(r)，並明用decreasing measurable sets的area continuity；它不是主area inequality所需。若B02只採Green／普通Riemann而不帶一般平面measure，建議把此段限為「limiting complementary area lim A(r)=π(1−Σn|bn|²)」，不聲稱已先建任意compact K的measure。已明報主控，copy未擅加新的measure先備。這與主area定理正確性分開。

## 下一步

本順讀沒有發現其餘主線循環、sphere尺度衝突或題解數值錯誤。B05-MAP-01–04的copy尚需另一打厚角色有界複核，OPEN-MAP-05由主控以實際先備範圍處置；在這些處置與重鎖完成前，不把原鎖定稿直接標整合無缺陷。主控採納後須更新source-lock並保留原鎖歷史。所有修正仍留待B-07正式整卷獨立終審；本報告不能代替它。
