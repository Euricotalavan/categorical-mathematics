# V23 B-05｜第 294–295 章章縫修補複核

交接 ID V23-B05-294-295-RECHECK-v1。B 方案單一 Work，數學複核 → 主控合稿。已核兩組完整位元差異，實際模型及 High 設定未另核實。

| 章 | 固定輸入 SHA-256 | B05 修補稿 SHA-256 |
|---|---|---|
| 294 | d2074f00373cfb82ab0ca892d426dfc3a2fc70c77adb130b1dbc95580cf9384b | a8134693080afc9d1da94dbd81d744d00f9bbd46e9a53c1a09b8027e8ab052f8 |
| 295 | eca80119b8b3f2d2629e696c7c49c9f34e6bec0e47812fea372736653f70b5eb | ef1dde1cbf70afdcee96113226bdc166b8407031509b139c152071e66aff6936 |

- ch294-precision.tex 唯一差異是導言加上 on a domain。現與同章局部冪映射定理的連通性要求一致。
- ch295-precision.tex 唯一差異是循環回顧明列只取非零係數的路徑像，並指向第 292 章。新增引用 def:292-chain 已定位到唯一標籤。留數證明此前提下成立。

兩個指定修補均通過，交主控併入後實核新固定稿。這份回執承接 foundations-reading.md 的兩項章縫。正式版面和整卷終審留後續。
