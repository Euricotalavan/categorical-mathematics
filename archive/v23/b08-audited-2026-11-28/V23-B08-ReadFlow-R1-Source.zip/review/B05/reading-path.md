# V23 B-05｜整卷閱讀路徑核查 v1

交接ID：V23-B05-READING-PATH-20261128-v1。角色：擴充／整卷閱讀路徑核查→主控。方案B單一Work，僅B-05；本角色先前起草299–301，這次不代其獨立打厚或B-07終審。模型及High實際設定未另核實。未修改唯一正文、master、圖或組版檔，只產出本報告。

## 固定接收與判定

已讀 `B05/LOCKED` 後實核 `source-lock.json` SHA256 `863e78cd798397b3b173af076b35845426002d37fedb4c91b65ad5bf6c103611`。14個 `book/chapters/ch291.tex`–`ch304.tex` 的bytes及SHA256全對清單；B02設計SHA256 `acbc3a9b0d58accf9cb62f2acefc11af66426dd0ed2a701251cfdc655d416f83`。沒有把live draft／較早工程PDF當鎖定整合稿。

**閱讀主線與B02一致，未發現跨章先借後證循環。** 有一個尚須處理的先備範圍差異：301主面積證明依賴已明說但尚未在本卷證明的簡單曲線分離事實；見RP-01。另有B06裝配待辦，不能以本次路徑核查代排版或數學終審。

實讀各章開頭、進入習題前的正文結束、所有向後章前指的實際上下文，並讀下表所列橋接證明／對比例題及三張圖的實際放置。291–294先前精修已全文核讀；299–301曾起稿，本次再讀固定整合版新增moving-pole／harmonic應用。其餘章本次是針對依賴與敘事的選段核查，不宣稱重新逐式審完14章全部證明與習題。

## 14章實際路徑與篇幅

字數是LaTeX空白分隔詞，含公式代碼，只作相對篇幅證據，不是完整性門檻。

| 章 | 詞數／完整題解數 | 實際橋接與有用辨識例 |
|---|---:|---|
| 291 | 4955／9 | opener明示全純⇒Taylor待293；先獨立證series微分，再在章末以D(1,1)的ell構造local roots，供292 winding及294正常形使用。 |
| 292 | 5136／10 | opener分real integration與holomorphic增強；章末square對1/z與1/(z−5)給不同允許同倫域，local primitive網格定理先證，293再供給其假設。 |
| 293 | 5047／10 | Goursat→star primitive→circle formula→Taylor／Morera／Liouville→global cycle；末例e^z/[z(z−2)]先用Cauchy算，不提前借residue。 |
| 294 | 5024／10 | Taylor首項→identity→收縮local inverse→local root／power normal form→open/max/min；末段boundary data e^-it不能全純填入，區分uniqueness與existence。 |
| 295 | 4549／8 | opener接293 Taylor與294factorization；環域兩個Laurent展開到annular residue圖，章末區分function在∞的類型與differential的∞ residue，供296／297使用。 |
| 296 | 5273／10 | signed order／log derivative→argument principle→Rouché→roots perturbation；根值繞參數互換只指向298作解釋；末段e^h因子不改root moments，預告302–303要量growth。 |
| 297 | 4961／10 | improper/PV、Jordan、實極點、keyhole、cotangent各有獨立限制；L0在slit用CR實證holomorphic，不借298 global log。末段強調各limit先後與量綱檢查，非無條件套式。 |
| 298 | 5347／10 | opener以local germs而非數值定延拓；兩log在disconnected overlap的不同差值是實例；monodromy含all-path存在條件，local/global log後才給300使用；reflection與factorial natural boundary各實證。 |
| 299 | 5364／10 | finite-valued normal與spherical normal分明；sphere兩chart／Hurwitz先證，最後moving 1/(z−a_n)與colliding z/(z−a_n)相反結果及finite net例，把compactness做成可用工具；omitted Montel明示留304。 |
| 300 | 5953／10 | 先局部／global map辨別與exact inverses，再用298 roots＋299 Montel建立非空extremal family及嚴格改善，不借301 quarter。章末harmonic interval／disk arc只用holomorphic log的imaginary part，不借303 Poisson。 |
| 301 | 5402／10 | exterior circle area→odd transform→a2→quarter→distortion→growth→compact S／inverse stability；Koebe slit例辨識sharp常數與boundary collapse。平面Jordan先備缺口另列RP-01。 |
| 302 | 4912／8 | opener將zero divisor、product、growth三任務分開；Jensen→order→log tails→Weierstrass→good circles→Hadamard；sin product不用297 cot展開，末例order0但無窮zeros接303 rational-growth區別。 |
| 303 | 5264／11 | Mittag–Leffler有Taylor corrections，接302 Weierstrass造quotient；Poisson先只為holomorphic logarithm實證，再Poisson–Jensen及origin c,z^d→m/N/T；e^z/z^d例把pole count與proximity變化分開，末段明指FFT待304。 |
| 304 | 5439／10 | target記號／first main theorem先接303 reciprocal identity；另一條density→disk comparison→spherical compactness→Little Picard→log lift／shrinking circles→Big Picard獨立成鏈。e^(1/z)展示真實多次取值，不以FFT推Picard。 |

總72,626詞、136題配完整解答；各章約4549–5953詞。多數為7–8個教學節加習題；299因moving-poles應用有9個教學節，303有11題，均是B02「依數學需要」的可用增加，未發現以空白、重複標語或拆題灌篇幅。

## 先證後用、前指與重複

- 291→293是明示待證的反向analyticity，不在291證明中使用；292→293只預告一般holomorphic積分增強。294 local inverse依293高階光滑及292FTC，自己的收縮證明不借後章Rouché。
- 295→303只預告whole-plane quotient construction；295→304只預告Casorati以外的精確值分布。296→298只解釋root interchange；297→298開頭明說不需要它，branch在當章以實偏導驗證。
- 299→304是省略值Montel尚需新估計的明示提醒；304使用的是299已證sphere compactness與chordal-length，不倒借自己的Picard。302→303只延後boundary Jensen；302現在的Hadamard以good radii／real-part coefficients閉合，沒有偷借303 Poisson–Jensen。
- 291振盪係數例前指本章lacunary習題、304 puncture test前指後面e^(1/z)例，都是比較提示，當前計算無須其結論。機械核654個labels唯一，全部ref/eqref有目標；這是名稱完整性佐證，不當作依賴已證的替代。
- 293與299均完整給Weierstrass／derivative limit，292與297均有指數弧估計，294與300均提univalent inverse。這些回顧分別服務integral tools、normal-family compactness與geometric vocabulary；目前屬局部短重述，沒有造成必須重學另一套假設的障礙。B06若瘦身可把299 Weierstrass標為recall，但不得刪去使用前的明確接口。

## 圖與附錄位置

三個圖均在其相關主證明／例題旁：293 `fig:293-goursat-subdivision`在四分證明後；295 `fig:295-annular-cycle`嵌annular residue例，緊接實際算式；297 `fig:297-keyhole`在L0支定義之後、keyhole運算之前。方向／被排除點／banks由正文說明，讀者不用只靠箭頭猜。既有contact圖曾實看，共邊反向與圈方向可辨。

鎖定14章沒有把必要proof或first-use definition移到appendix；目前book無數學附錄。書目應置正文後而非取代來源責任表；B02 bibliography已有八來源條目。正式floating位置／跨頁圖說與全頁視檢屬B06，這次僅核source placement。

## RP-01｜先備範圍差異，阻「僅靠B02先備完全自足」宣稱

位置：`book/chapters/ch301.tex:133–136`（定位行約數，以字面為準），原文：

> The elementary separation fact for a simple closed plane curve identifies its bounded and unbounded sides

`thm:301-area`證明於約149–162行以這兩個components辨識g(|ζ|>r)為unbounded component。B02契約僅列「planar topology at the level of compactness and connectedness」；B01 F-OPEN-03也要求查更早卷先備或補必要版本，不能猜已先修。Green公式有推導，但simple-curve separation本身在本卷尚未證明，亦沒有已核前卷精確落點。

這不是area計算的符號錯誤，也不是作者未明示它：現稿明確說是額外plane-curve fact。293的Jordan段只用於optional simple-contour specialization，circle/cycle主線可避；301則主area proof確實需要。**窄範圍處置**：補足所用regular analytic circle-image版本的分離／方向引理，或以已核的前卷確切來源正式供給該先備並在本卷first use接引。沒有此證據前，不把「全卷相對B02先備自足」標通過。本報告不自行改既定先備或寫master。

## 裝配及頁數限制

`book/.build/b04-full-volume-probe/build/entry.pdf`經pdfinfo核為257頁，report的PDF SHA256 `94e147eb9d5be602a4704bc16ba2a0d25a46704f89dd77d1c21049681171339b`。其inputs中292／293／294／298／299／300／301／304共8章hash與本次lock不同；所以257頁是較早實際編譯證據，不能寫成本次鎖定稿的最終頁數，也不推算應有幾頁才算完整。

`book/backmatter.tex`目前僅147 bytes scaffold註解；`tools/build.py --full`預設讀它，而正文有beck/howell/langley/honda/weber五種cite keys。完整工程預檢曾明確以 `--back B02/bibliography.tex`補入，故可構建；**B06必須凍結實際使用的非空書目與front/back入口**，否則預設入口的書目引用會未解析。這是可直接處理的裝配事項，不是要求新章內容。frontmatter也仍是title/TOC scaffold；B06需固定正式版，不把工程README用語移進讀者正文。

## 交接

實作改動：無正文變動。已核證據：固定14章hash／實際bridges及代表例／前指用途／654 labels／圖的source位置／較早257頁PDF。OPEN：RP-01先備來源或局部補證；B06 front/back書目綁定、鎖定稿全編及全頁視檢；B07唯一全卷終審未做。本報告不是14章所有proof逐式重審。

下一步：主控實讀RP-01並安排窄範圍處置，更新受影響source lock後重核該接口；完成B05各角色整合才進B06。禁止改凍結卷、重寫已閉合章稿、把字數／頁數／無缺label當完整教材驗收。文件已在共用目錄供接收；產出及回報不等於主控已讀，待回執核版本。
