# V23 B-05｜302→303→304有序整合精度核讀

V23-B05-GROWTH-v1，2026-11-28。獨立精修核讀，未改任何章稿或master。實際模型／High設定未另核實。

**本範圍未發現阻塞缺陷。** 已按302→303→304重核順讀與必要先備；303、304逐證與全部例題／解題的先前精修可重用，因固定book檔與實讀精修檔逐hash相同。302則完整讀本次接受版全部530行及8題解，並重核所有跨章使用位置。此為B05分工閱讀證據，不替代全卷整合或B07唯一嚴格終審。

## 接收與版本

`source-lock.json`實算SHA-256：
`863e78cd798397b3b173af076b35845426002d37fedb4c91b65ad5bf6c103611`，與LOCKED標記一致。所有下列book/chapters檔案逐一實算吻合該清單：

| 章 | SHA-256 |
|---|---|
| 294 | d2074f00373cfb82ab0ca892d426dfc3a2fc70c77adb130b1dbc95580cf9384b |
| 295 | eca80119b8b3f2d2629e696c7c49c9f34e6bec0e47812fea372736653f70b5eb |
| 298 | ddca3af33f0c40b3fad2404f71f6789d8151434cbb5b8b16bab3e68181421df9 |
| 299 | 62c0d576f4e4113e3ab63abca39ebc797fb6bd9e46ec671b6dca329bc447c615 |
| 302 | 2d84bee94f6b2857504b091f3361cc95c2a275cca36872debf5de227325aacf6 |
| 303 | a982f622f79436b4fc704af826bac6d9de100bfc8e18b3b1a50aebba0ca7f306 |
| 304 | dcd2f7ebbe9d4efd175d454c6e6a892aef4b23c129413493a9c5309545794912 |

303完整精修及304完整精修證據分別在 `B04/refined/ch303-review.md`、`ch304-review.md`。本次沒有用舊「通過」標籤跳過橋接檢查：下表以book正式label及其實際假設重新對接。

## 按閱讀順序的實核證據

| 位置／先備邊 | 具體核查與結論 |
|---|---|
| 294→302/303 | `thm:294-factorization`、`thm:294-identity`、`prop:294-finite-zeros`實際供局部unit、有限重數與緊子集有限零點。302開頭排f恆零並把原點m單列；303 divisor非恆零才賦整數階。沒有因重複列零點而當成互異點。 |
| 295→302/303/304 | `thm:295-laurent`提供任意小圈係數與半徑無關；303原點以cz^d（d可負、c≠0）固定；304 Big Picard的a_(−k)積分及r_n^k界採相同Laurent約定。`thm:295-casorati`已證，才可在304本性假設下選有限目標2的逼近序列。 |
| 298→302 Jensen／商、303 Poisson | `thm:298-log-root`的域單連通＋函數處處非零已實讀。302先用精確重數取消f與產品的零，商確為全平面非零整函數後才取global log；Jensen與303 Poisson則在無零、無極的稍大圓盤取log。沒有在穿孔盤不加條件取global log，也沒有偷用任意主值log乘法律。 |
| 302 `lem:302-linear-mean`→`thm:302-jensen` | 平均都是1/(2π)，局部log在1附近取零值；每個零計重數。f(0)≠0的Jensen先成立；原點m的版本完整落在 `prob:302-origin`。302後續n_f(r)界遇外圈根時只取避根R↓2r並用M連續，沒有先用303才證的完整碰界Jensen。 |
| 302 order→zero exponent | `def:302-order`為log正部兩層除logr；`eq:302-order-upper`只對α>ρ給r^α，不錯升為有限型r^ρ。原點先除z^m後套Jensen，dyadic殼計每個重數；s=λ端點不擅判收斂。 |
| 302 product→Weierstrass | `lem:302-log-product`逆向以局部G(P_M)與離散2πi整數差證log尾和收斂，無未定義global log；`lem:302-normal-product`正常收斂給非零尾，有限頭供精確零重數。`thm:302-weierstrass`取p_n=n的2^−n界在每固定盤成立，重複零的商先可去再log。 |
| 302 `lem:302-good-circles`→Hadamard | p<α<β<p+1：排|a_n|的r^(−q)小區間總長O(r^(α−q))，選R∈[r,2r]；頭部線性因子下界−Cr^αlogr，校正多項式項由α>p估Cr^α，尾部由α<p+1估Cr^α。故整圈log模P≥−CR^β。Re g的Fourier係數界消k≥p+1，Q度≤p。這條證路不使用303 Poisson–Jensen，無302↔303循環。 |
| 302 genus／sine／cot→303 | 同一零序列的least index q與p=floorρ分開，從P_p換P_q時Q加正的校正多項式，內和因j≥q+1絕對收斂。sine產品先由Hadamard、奇偶與原點導數定π；cot配對部分分式在 `prob:302-cotangent`才由正常log尾微分，303 `ex:303-cot`單向引用它。沒有拿cot先證sine又反用。 |
| 302→303 quotient／finite divisor | `thm:303-quotient`以302 Weierstrass按極點確切重數造h，hf在h零點非零。`prop:303-finite-divisor`先用303代數與T/M比較證f/R的有限整階，再引302 `cor:302-zero-free`得exp多項式。未把「無零」直接當成多項式指數。e^(e^z)的∞階已在302 `ex:302-orders`實算。 |
| 302→303 normalization | 303 `def:303-order`取log正部T/logr，`prop:303-MT`的T(r,h)≤log正部M(r,h)≤3T(2r,h)證與302整函數階相同。常數階0；所有極點N非負估計用r≥1，無小r origin負項造成的越界。 |
| 303 Poisson–Jensen→reciprocal | B_a=R(z−a)/(R²−共軛a z)，B0=z/R；乘極點因子、除零點因子、乘B0^(−d)取消。還原零正極負、dlog(模z/R)；扣dlog模z才取中心。中心式平均log模f=log模c+N(1/f)−N(f)，故T(f)−T(1/f)=log模c。與302原點Jensen符號一致。 |
| 303 boundary／rational scope→304 | `rem:303-boundary`的角距離恆等式給一致可積，故所有r>0的倒數式可在304逐r使用。平面且∞可亞純延伸才有rational-sphere；T=O(logr)沿一列就有理的證明先清有限極點，再Cauchy消高次，不只憑有限極點斷有理。304說非恆常T→∞有前章確實證據。 |
| 303→304 FMT interop | 304有限a取1/(f−a)，∞取f，N計極點／a點，m是圓上log正部接近量。平移不改極點重數，所以N完全相同；T(1/(f−a))=T(f−a)−log模c_a。與303 `thm:303-reciprocal`逐字同號、同原點c慣例，FMT誤差對固定a而非全a一致。 |
| 303/304 exponential targets | 303 T(e^z)=r/π、T(e^Q)=模b r^d/π+O(r^(d−1)+1)已由cos正部均值證。304非零a的logarithmic lattice只選一個scalar log重新編號；F=e^(2z)−e^z的−1/4目標是雙根，經exp局部導數非零保持重數2。理性target在∞用f(1/w)−a或其倒數的零階，不與303有限原點N混為同一計數。 |
| 299→304 spherical tool | 接受版299（含已核補節）明分finite-valued與spherical normal；`thm:299-spherical-limit`用有限／倒數圖卡及連通性，允許恆∞。`eq:299-chordal-length`為χ≤∫f#模dz，與304半徑1/2立體投影同尺度。AA的compact-target版本已在299證，不預設強省略值Montel。 |
| 304 independent Picard closure | 密度比三端1/49、1/49、8/49、√q_*縮放、∞球面支配、critical點避開log的內最大比較，均已逐證再查。省略三值的Möbius在原極點以1/f圖卡變全純，Little Picard用任意R導數界；Big Picard用log半平面得額外log分母，Casorati給finite base再消負Laurent。沒有以FMT或未證覆蓋替代這些責任。 |

302新增／例題與8份解答亦逐核：n²零列、重數n時index1、order<1無零⇒常數、sinh產品、cot、Basel、Re g係數界、index1端點產品均有效。`prop:302-square-zeros`上界O(√r)及由零收斂指數取下界無循環；`ex:302-zero-order`幾何零列的O((logr)²)上界只用於order0，不誤說T=O(logr)。303實際12例11題11解、304實際10例10題10解；全部題數差異已在單章精修回執說明，不刪解題。

## 結果、限制與交接

阻塞缺陷：**本次指定有序弧與incoming介面未發現。** 無需退回補丁。B01來源責任的細項與候選排除沿303／304精修回執；SMT、Cartan、deficiency與正式曲面覆蓋仍非本卷此弧的證明目標。B02已選Big Picard完整平面證路，與B01早期暫排建議分清。

下一唯一動作：主控把本回執與其他B05閱讀分工合併，處置其餘範圍後固定整卷整合正文。PDF編譯、頁面QA及B07終審不由此回執代替。任何已鎖定章稿更動須依直接／傳遞依賴重核；本檔沒有修改來源、主檔或既有卷。
