# V23 B-05｜第 291–294 章順讀與第 295 章接口

交接 ID V23-B05-FOUNDATIONS-READING-v1。B 方案單一 Work，數學順讀 → 主控整合。讀入 B05/LOCKED 後，實核固定清單 SHA-256 863e78cd798397b3b173af076b35845426002d37fedb4c91b65ad5bf6c103611，與表內五份唯一正文符合。依章順序核正文定義、完整證明、必要算例及引用，並把 B-04 已獨立整讀的內容與固定精修版比較。範圍為 291–294 的整章及第 295 章引入前章工具的接口。模型及 High 設定未另核實。

| 章 | 固定正文 SHA-256 | 本次查讀 |
|---|---|---|
| 291 | cf037090851d5422b53060b27ba7a2611989c92a510885a3aabbf13309db5c5e | 八節，九題題解。代表節逐字核對 B-03 核准 SHA-256 5d309e73c90109e3fe843f2d4af7db7de2cee12748dfbcc29b8696a2b6e73e65。 |
| 292 | aeab998650fac4748ea9ef4c5613dd7c18e46c0466f226da5a0234562d0e562c | 八節，十題題解。精修只在參數積分補無支集的空和情形。 |
| 293 | 33805df68a835a21d1c220354ec5825bdadaf367cc659522a8d46cf1d1bbd02c | 八節，十題題解。精修補局部一致定義，將 Jordan 分離及指數規則明列為額外平面拓撲事實。 |
| 294 | d2074f00373cfb82ab0ca892d426dfc3a2fc70c77adb130b1dbc95580cf9384b | 八節，十題題解。全章順讀，三處精修差異亦已在 B-04 複核。 |
| 295 | eca80119b8b3f2d2629e696c7c49c9f34e6bec0e47812fea372736653f70b5eb | 核 292 至 295 的 Laurent、零點階數與留數接口。 |

## 覆蓋落點及順序

| B-01 責任 | 正文落點與實核 |
|---|---|
| 291-01–05 | def:291-holomorphic、prop:291-rules、ex:291-conjugate、prob:291-conjugate-tests。複差商走全部方向，共軛兩軸差商相反，共軛平方只在原點可微，連續與局部全純的命題各有適用條件。 |
| 291-06–09 | sec:291-real-differential 的原核准樣節及 prob:291-conjugate-tests。實線性、Fréchet 餘項、兩軸偏導及連續偏導在點與開集的不同用法均在先前定義後落地。兩反例的斜率或對角餘項有實算。 |
| 291-10–16 | def:291-analytic、thm:291-radius、prop:291-ratio-radius、lem:291-uniform-tools、thm:291-termwise、ex:291-generating。局部絕對一致收斂控制整個緊盤，逐項微分先證差商尾，再驗導函數半徑。振盪及稀疏例分別辨識根值與比值。291-13 的固定曲線限積落在 prop:292-uniform-integral，291-16 的全純反向落在 thm:293-analytic。 |
| 292-01–07 | def:292-path、def:292-chain、sec:292-integral、prop:292-integral-rules、def:292-length、thm:292-ml。參數區間、端點、速度可為零、反向、整權重及任意分割相容。共軛兩路計算為 1 和 1+i。長度公式直接給上述直段 $\sqrt2$ 與圓周 $2\pi$；後者也實用於 prob:292-chain-bound。 |
| 292-08–12 | def:292-primitive、thm:292-ftc、thm:292-exactness、ex:292-circle-powers、ex:292-no-primitive、def:292-homotopy、thm:292-local-exact-homotopy。原函數以端點值相減，在連通域由零環路積分造原函數。固定端點與閉路同倫側邊分開，細格證明只在端點曲線積分，未要求中間曲線可微。 |
| 293-01–08 | thm:293-goursat、thm:293-star-primitive、cor:293-local-cauchy、def:293-null-homologous、thm:293-global-cauchy、thm:293-circle-cauchy；繞數先在 def:292-index 與 thm:292-index-homotopy。Goursat、星形原函數、移心縮圓依序成立，均在使用 $f'$ 連續前。一般循環的差商先由本章 Taylor 和連續導數跨對角，再以第 292 章參數積分、Fubini 及 Morera 黏合，不借第 295 章可去定理。 |
| 293-09–15 | sec:293-applicability 的正向簡單曲線推論，cor:293-derivatives、thm:293-estimates、thm:293-morera、thm:293-liouville、thm:293-analytic、ex:293-inside-outside、ex:293-two-points。Jordan 分離及正向指數是明列的拓撲輸入；主線圓盤與循環公式已成立。Morera 先造原函數才用 Cauchy 解析性推出導函數全純；固定圓上一致收斂給 Taylor，回應 291 的前引。 |
| 294-01–07 | def:294-order、thm:294-factorization、prop:294-orders、ex:294-sine-order、lem:294-local-root、thm:294-normal-form、thm:294-identity。數學先排除恆零芽或給單點有限階；全域因子只在根點必須無零。正規形平移至根點、固定分支與縮圓，分清非中心值的不同原像數、中心的計重。恆等定理的聚點在連通域內且相等點互異。 |
| 294-08–12 | thm:294-open、thm:294-maximum、cor:294-boundary-maximum、thm:294-minimum、cor:294-boundary-minimum、thm:294-local-inverse。局部逆用第 293 章導數連續、第 292 章線段積分和完備閉盤上的收縮迭代自行建立，沒有實逆定理或開映射的提前依賴。全域或邊界極值精確區分域連通、有界、閉包連續及倒數所需的無零。 |
| 292–294 → 295 | 次方正負環域先取代換、內外圈保有方向、兩個負號在內圈 Laurent 核相消。全純因子與第 294 章零階續成亞純的帶號階。留數小圈沿正向、有限循環由緊繞數集求有限奇點，減適當小正圈後再用第 293 章公式。無窮遠的 $-w^{-2}$ 是座標變換因子。 |

## 需統一的兩處局部文句

| 位置 | 固定稿中的問題 | 可直接核對的文字 |
|---|---|---|
| ch295.tex 499–502，循環留數定理前的定義回顧 | 寫 trace 為所有 constituent traces 的聯集。第 292 章的 def:292-chain 已限定非零係數，並因此確保只在 trace 上定義的積分不必評估零係數路徑。本章略寫使兩處慣例有差。主證明在前章慣例下成立。 | “Its trace $\lvert\Gamma\rvert$ is the union of the traces with nonzero coefficients, as in Chapter~\ref{ch:292}.” |
| ch294.tex 6–7，章導言 | “every nonconstant holomorphic function is locally exactly a power map” 未在導言說明連通域。若在不連通開集的一個分量恆常、另一個分量非恆常，這句過廣。正式定理與後面的分量辨識已正確。 | “After changing to a suitable holomorphic coordinate, every nonconstant holomorphic function on a domain is locally exactly a power map.” |

65 處章內與跨章引用均能在現有唯一正文定位到一個標籤。本輪實查 Goursat 與環域圖為已核 PDF 指紋。F-OPEN-01／02 的本卷證明已找到正文落點；F-OPEN-03 中局部逆已在正文補證，Jordan 的索引事實依定界明列為外部先備。三本商業原書的實讀限制沿 B-01 最終接收紀錄。主控收兩處局部修補並重核新指紋後，可關閉這段的章縫審查。版面、配對 PDF 與整卷 B-07 留待各自的固定版。
