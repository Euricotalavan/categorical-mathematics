# V23 B-05｜295→298 integrated analytic reading

交接 ID：V23-B05-ANALYTIC-20261128-v1。角色：獨立整合精修；未起稿295–298，亦未打厚這四章。等 `B05/LOCKED` 及 `source-lock.json` 出現後才開始本次整合讀入。模型／推理部署未另核實。僅B-05，不是後續強制B-07終審。

固定鎖定清單 `source-lock.json` SHA-256：**`863e78cd798397b3b173af076b35845426002d37fedb4c91b65ad5bf6c103611`**，與LOCKED文字相符。下列book/chapters檔案均實算bytes及hash對上該清單；本角色沒有修改master。

| Chapter | Bytes | Locked SHA-256 |
|---|---:|---|
| 292 | 38871 | `aeab998650fac4748ea9ef4c5613dd7c18e46c0466f226da5a0234562d0e562c` |
| 293 | 38425 | `33805df68a835a21d1c220354ec5825bdadaf367cc659522a8d46cf1d1bbd02c` |
| 295 | 34123 | `eca80119b8b3f2d2629e696c7c49c9f34e6bec0e47812fea372736653f70b5eb` |
| 296 | 37562 | `f597a399ff234d44c678b1c8e1ec3001db1f115ffd13db490635e9b808188f42` |
| 297 | 39212 | `159b45c7c5401b18dea2d9409c5cac21330dc7ef92f64c894fbe9cbe7e7389b8` |
| 298 | 36999 | `ddca3af33f0c40b3fad2404f71f6789d8151434cbb5b8b16bab3e68181421df9` |
| 299 | 40251 | `62c0d576f4e4113e3ab63abca39ebc797fb6bd9e46ec671b6dca329bc447c615` |

實讀方法：295及298完整正文、全部證明例題及8／10題全解；296、297與本角色剛完成全章獨立精修的固定輸入逐位元相同，重新核hash及整合串接、條件、前後引用。其完整逐式核讀證據仍見B04/refined/ch296-review.md、ch297-review.md，未以變動稿冒充已讀。292/293核實際正式稿的差異與積分／同倫／全域Cauchy介面；299核Weierstrass、Hurwitz、單射極限、球面兩圖卡與省略值推論的實際正文。對B01 foundations/global與B02確認範圍；B02明列295 Casorati，因此採B02而非較早來源片段的候選排除。

## 發現與最小候選補丁

**AN-01，295 `sec:295-residue-theorem` 前的trace回顧。** 舊文 “union of their traces” 把係數為零的路徑也含入，與292 `def:292-chain` 明定只取非零係數路徑不一致。主控同時指出此項，本角色回到兩份固定正文實核確認。

已產獨立完整候選 `B05/ch295-precision.tex`：**34196 bytes**，SHA-256 **`ef1dde1cbf70afdcee96113226bdc166b8407031509b139c152071e66aff6936`**。只把該回顧改為：引用 `def:292-chain`，trace是 “the union of the traces of those paths with nonzero coefficients”。不改任何公式、標籤或其他章。舊master hash仍維持上表；本角色不自行升版或改鎖。

直接與下游重核：295的compact winding support K、S∩K有限、帶繞數減小正圓、穿孔域零同調證明皆以292的正確trace運作；空trace時循環積分及貢獻和均空，293已處理零循環。295座標變換只用單一非零圈，無變動；296帶權辯值與297實際輪廓均相容。補丁不變更任何計數、方向或留數。**處置：候選已送主控作有界複核／提升；本報告不把產檔算作已提升。**

## 整卷順讀介面與實證

| 介面／正文位置 | 實際推理核查 |
|---|---|
| 292→293→295 | 292先定分段C1、反向／串接、有限鏈積分／ML、繞數整數與局部常值、連續同倫、compact winding support。293的圓盤Cauchy→Taylor／Morera／Liouville→Dixon全域公式已完成；其對角差商用局部Taylor，沒有倒借295可去定理。295 Laurent以外正圈減內正圈在原環域零同調，內核幾何級數負號與邊界負號相消，係數唯一與緊子環域一致收斂有實證。 |
| 295本章定義鏈 | 去心全純→Laurent分類→bounded removal→有限order reciprocal→Casorati；後兩者未先用304 Picard。亞純先明列相對閉離散極點集與可去補值，帶號order排除局部恆零；局部quotient不冒充303全域整函數商。留數先定c−1，再證各階極點公式與座標微分因子。annular primitive逐項積分排除−1項，正常收斂足夠。 |
| 295循環與無窮遠→296 | 295 residue theorem允許本性孤立奇點，但S相對閉離散，K緊含U令有貢獻項有限；減小圈後在U\S零同調。∞的函數類型用f(1/w)，微分留數用−w⁻²f(1/w)，兩者分清。296 f′/f的局部m/(z−a)+u′/u以已定帶號order取留數m；要求原函數亞純並避零／極點，未把295容許本性的積分定理誤升為無窮零點計數。 |
| 296→297 | 正向簡邊界index1及一般cycle負權不混用。Rouche全閉邊界的嚴格共同gap保整數連續；meromorphic版本只保Z−P。297每個閉輪廓都有全純／亞純鄰域與邊界避極點，新增trig的z=0極點有計入；實極點小上凹口順時針−iπRes，所以PV公式右側+iπ實留數。沒有以境界「一半」代替方向計算。 |
| 297收斂與298前置 | 實積分兩端各收斂、∞對稱PV、各實極點局部對稱刪除分列；Jordan端點界、Fresnel先驗實尾、keyhole先角後半徑、moment共同支配、cot半整數方框與絕對樣本和皆在正文證明。297 Log(z+i)／positive-ray slit power用明確Arg範圍及CR直接造支，未偷用298尚未證的全域對數或monodromy。 |
| 296→298 branch與monodromy | 298先定同底點附近相等的germ、時間局部compatible family，再用identity／連通參數證固定路徑唯一；有限鏈含compact subpaths與接縫小盤。nearby-path lemma有正距離、相同兩端點，才說相同terminal germ；monodromy每個homotopy slice由明列all-path continuation假設供存在。simple connectivity只負責終芽唯一，非供延拓存在。 |
| 298根／反射／natural boundary | 全域log先實造每路局部log鏈，再single-valued gluing；period／nth-root criterion用292 primitive及296 image winding，整數／2πi／n因子相符。Schwarz reflection有開disk、連續實diameter、上下translate有限多邊形後Morera，無未證任意邊界延拓。factorial／dyadic自然邊界由密集roots-of-unity正尾證無任一邊界element；連續邊界版本對導數作同一反證，未引用一般gap theorem。 |
| 295/296/298→299 | 299在固定母域用compact convergence交換三角積分，293 Morera及較大Cauchy圈控較小盤導數；Hurwitz用296嚴格Rouche與294孤立零點，保留恆零例外。單射極限例外為任意常數。sphere至299才作值域約定，倒數在295極點可去／零點有限階的論證支撐圖卡；connectedness排除開∞區混合有限區，holomorphic approximants再用Hurwitz排孤立極點。 |
| 全題及重要forward refs | 295八題、296/297/298各十題，題／解配對且解算結果逐項核讀，無已知缺解。arc內未解引用0，全14章重複標籤0。未來章引用僅295→303全域quotient、→304精確值達；296→298根互換；297→298表示本章不依賴／→303格點principal-parts主題。均為前瞻，不是當前證明必需的未證引理。 |

## 來源責任與限制

既有H/B/W段落的來源假設差異沿B01處理：W全域cycle公式及計數顯示式的漏i／漏2πi不照搬，B同倫版未附一般完整證明的缺口由292局部primitive網格法補；H對稱Rouche的原曲線／像曲線記號混用由296凸homotopy證法避開。298另實讀L §§12.2.2–12.2.4及12.3.1–12.3.3（印pp205–210）：來源偏meromorphic spherical element；本稿明確採有限值平面holomorphic germs並給自足有限鏈／stability證法，沒有把來源較廣結論當同一未證範圍。未宣稱重讀三本原書的完整相關章，也不因本次報告清除V0歷史門檻等既有UNKNOWN。一般曲面／covering formal theory留後卷，未暗作monodromy先備。

**結論：本arc除AN-01外，未發現新的整合語義阻塞；AN-01有上述最小完整候選，需主控核後提升及更新清單。** 本報告是固定來源的B-05精修證據，不是編譯、圖版全頁視檢、來源/PDF配對或B-07通過。無master編輯；不啟動其他卷、不重做既有已核工作。
