# V23 B-04 independent refinement｜Chapter 297

Independent full precision/source reading; this reviewer authored and thickened neither Chapter 297 draft nor thickened input. Read every section, proof, example and all 10 complete problem solutions, not only the earlier thickening report. Read B-02, B-01 297 source responsibilities and risks. Model/mode not independently verified.

Input `thick/ch297.tex`: **39,212 bytes**, SHA-256 **`159b45c7c5401b18dea2d9409c5cac21330dc7ef92f64c894fbe9cbe7e7389b8`**. Output `refined/ch297.tex` is byte-identical with the same hash. No further patch or safe deletion warranted. Detailed limiting arguments serve mathematical conditions and are retained.

## Source reading and independent checks

Actual source reread: W §4.2 printed pp.62–64 (cotangent rectangle proof and example); H §8.3 Thm.8.3/proof pp.257–258; §8.4 Thm.8.4 and Jordan Lem.8.1/proof pp.259–262; §8.5 Thm.8.5–8.6 pp.263–264; §8.6 Thm.8.7/proof pp.268–269 (branch cut phases/endpoint conditions). H's use of P.V. does not supersede the manuscript's separately proved absolute or ordinary conditional convergence. The manuscript's independent Fresnel, Gaussian, logarithm, parameter-moment and exercises are checked as actual derivations, not claimed to be identical textbook proofs.

| Complete unit | Independently checked evidence |
|---|---|
| Rational real integrals | Ordinary two-tail limit distinguished from symmetric PV; degree-gap2 gives absolute convergence and arc O(R⁻¹). Quadratic π/a, quartic π/√2 (positive half π/(2√2)), double-pole residue1/(4ia³) and π/(2a³) recomputed. |
| Trigonometric | Differential dz/(iz) included; a>abs(b), b=0 separate; interior root −b/(a+d) and exterior reciprocal root correct. For cos(2θ)/(5−4cosθ), zero double-pole residue5i/8 and half-point residue−17i/24 sum−i/12 and give π/6. |
| Jordan/Fourier | Bound πMR/t follows from sin endpoint inequality, uniform on both arc ends. Rational degree-gap1 tails converge by parts at each end when t≠0; no false absolute-convergence claim. Upper/lower closure signs and π exp(−a abs(t))/a correct; x sin example conditionally convergent and t=0 exception stated. |
| Fresnel/Gaussian | Real oscillatory tail justified before ray rotation; positive π/4 sector arc boundπ/(4R); returning-ray sign/conjugation yields exp(iπ/4)√π/2. Real Gaussian square trapped between disk integrals; no circular contour evaluation or improper double-integral interchange. |
| Indentation | Counterclockwise half-circle+iπA and actual left-to-right upper indentation−iπA; therefore PV formula has+iπΣreal residues. Thickener's open-neighborhood meromorphic hypothesis and finite simple real pole list verified in every use. Small holes first, large radius after; ordinary tails distinguished from finite-pole PV. |
| Real-pole examples | Dirichlet π/2 and nonabsolute divergence; rational two-pole PV0 and oscillating cosine −πsin1; non-symmetric deletion of1/x gives−log c; PV1/x² diverges. No zero-residue/removability confusion. |
| Keyhole/log branches | Explicit angle0<arg<2π satisfies CR; literal rays at δ and2π−δ approach banks first at fixed radii; bottom bank has exp(2πis) and reversed direction. Residue phase at−1 and small/large bounds give positive π/sinπs precisely for0<s<1. Half-plane log(z+i) has branch point outside region and log(2i)=log2+iπ/2, giving2πlog2 real formula with arcO(logR/R). |
| Moments | u=x^m yields π/m csc(πs/m),0<s<m. Compact parameter interval supplies integrable bounds at both ends including all log powers and difference quotients; second log momentπ³/8 and first0 verified. |
| Lattice | Half-integer vertical sides cot≤1, horizontal bound<2, all boundary points modulus≥A; length8A and qO(A⁻²) give vanishingO(A⁻¹). Noninteger poles finite and samples absolutely convergent. Residues at±ia both negative; coth identity gives Baselπ²/6 without assuming its value. Alternating csc kernel signs correct; double-pole derivative yields π²csc²πw; local uniform4/n² and half-integer pairing yield odd sumπ²/8. |
| All10 solutions | Partial-fractionπ/[ab(a+b)] and dominated double limit; shifted sine and squared cosine denominator; Fourier squaredπ(1+a abs(t))exp(−a abs(t))/(2a³); shifted real-pole PV iπexp(itc); PV failure; Mellin2π/√3 andπ/(3√3); log momentπ³; alternating Baselπ²/12; derivative lattice sum with two positive terms; sinc²π/2 with both by-parts endpoints controlled. |

No unresolved chapter-level mathematical defect found. Environment pairing, 10 problem/10 solution count, unique labels and absence of forbidden control bytes checked. Figure inclusion/branch directions read and agree with the formula; this receipt does not claim compiled-page visual approval. Retained the entire thickener hypothesis patch after independently checking its scope.

Outcome: exact fixed chapter passes B-04 independent precision/refinement. This is not B-05 integration, B-06 layout QA, or B-07 whole-volume final acceptance. Source/PDF pairing, compilation, full-page review, remote recovery and final publication remain later-stage responsibilities. Next action: integrate this exact refined chapter. No master, draft, thickened input or other chapter was modified.
