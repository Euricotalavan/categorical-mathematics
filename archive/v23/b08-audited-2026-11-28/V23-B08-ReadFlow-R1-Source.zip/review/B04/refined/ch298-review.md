# V23 B-04｜第298章獨立精修回執 v1

交接ID V23-B04-REFINE-298-20261128-v1；獨立精修→主控／B05整合。方案B單一Work，本章B-04，未啟動B-06／B-07。模型及推理強度實際部署未核實。本角色未參與298起稿或打厚；本次先完整獨立審讀，後讀打厚回執。

| 身份 | SHA256 |
|---|---|
| 打厚輸入 B04/thick/ch298.tex | ddca3af33f0c40b3fad2404f71f6789d8151434cbb5b8b16bab3e68181421df9 |
| 精修輸出 B04/refined/ch298.tex | ddca3af33f0c40b3fad2404f71f6789d8151434cbb5b8b16bab3e68181421df9 |
| 章級工程PDF | 8ec5d31e3eaaad7780fe53fcb524845b316c0304d8e3d6e716272acddfae2c9e |

**結果：獨立精修通過，無必要修補；輸出是上述最終打厚稿的逐位元複本。** 這是可合入B05的章級精修結果，不是整卷通過或正式排版驗收。沒有為縮字重寫已完整證明，也沒有另增數學證明而留下新的打厚義務。

## 實際讀入與來源

已完整讀入最終740行、B01 global的298-D01–E14、B02本章設計、較早291的微分／級數介面；逐一定義／定理／必要證明例題及10題全解核讀。

本次實讀L `langley-pg1` §§12.2.1–12.2.4、12.3.1完整巢套方形證明及Cor12.3.2；K Honda §31.2的沿路／monodromy／single-valued條目；W Thm5.4.1及其Morera證法。L/K/W固定PDF hash沿本輪已實算，分別032990304286b8d586661721bba6041222d5b3715d4394047890d68b096f7fc0、3eb1f4a0f2a97a9582ed55d3258178634a0c9888e8e36ab8c99585f64b9b75e9、893da9917e484edd37d067f319d9ad930a94ed47e49065373232db7e15415050。未混Langley current版。L原以球面亞純元素為主；本稿明取平面全純芽，沒有把兩種結論混稱。

## 逐項語義／覆蓋核查

| B01責任或實際單元 | 獨立核查證據 |
|---|---|
| 298-D01/T02 | 全文log branch均指定割線開域或近1局部級數；兩種argument區間的交集分量清楚。沒有把全平面指定principal value誤稱全純branch，也沒有無條件log(ab)=log a+log b。局部log導數及exp identity由291工具可得。 |
| 298-E03/E14 | log單位圈初值0終值2πi；n根一圈乘e^(2πi/n)，n圈回原芽；平方根不能越零由零階奇偶排除。sqrt(1−z²)已限定正向簡閉路才給兩根總period4πi，explicit cuts的兩個Log argument皆避負軸。 |
| 298-D04/D05 | 固定端點H在整緊方形連續，兩端邊常定且全像留U；simple connectivity明採同端點路徑同倫。所有連續path與piecewise C1積分path明確分開，不對H求導。 |
| 298-D06/D07 | def:298-germ同底點共同開鄰域相等；transitivity取交，值相等不等於芽相等。along-path definition要求整個時間鄰域由一個代表函數給出，不是逐點任配；不要求斷開的overlap處處相等。Taylor recenter的雙絕對和先有限再交換，係數及半徑下界正確。 |
| 298-T08/P09 | thm:298-path-uniqueness先縮共同disk，若在其中一點同芽，identity使整disk同函數，故相等時間集合及補集都相對開；區間連通給唯一。返回同一底點多次不造成比較錯誤。唯一性一直限於已存在的延拓。 |
| finite-chain realization | compatibility cover經緊性／Lebesgue數選有限閉子區間，每段像緊含代表disk；各seam再有真正相等disk，首尾代表初末芽。反方向在seam由path連續性把鄰近時間送入相等disk，真正恢復定義，沒有只畫鏈而跳過拼接。 |
| nearby-path stability | 每段緊像到disk補集有正距離，有限seam也有同一正下界，取一個δ。σ逐段仍在原disk，seam在相等區；固定初末點保同底點比較，same chain給same terminal germ。沒有預假設整homotopy square有一個branch。 |
| 298-D10/T11/P12 | all-path existence獨立列假設。每homotopy slice已有延拓，緊方形的uniform continuity使相近slice的sup距離<δ；terminal germs對s局部常值，連通區間逼全相同。此完整finite-chain路線是K短證的展開，沒有拿L不同的亞純方形證直接當本稿證據。 |
| 298-T13 | cor:298-single-valued不是只逐點指定F(b)：選末芽代表G，再append短segments證F在小盤等於G，故全純。路徑獨立及identity給唯一。C單連通仍不能穿過1/(1−z)的pole，反例分清存在性。 |
| global log/root及period | 局部log用f(a)非零及series、有限path cover與seam的2πik調整，先構造all-path延拓再用monodromy。全域log／root的非唯一性用連通的離散值差／商。log period iff取f'/f的primitive H後f e^(−H)=c，再加scalar log c，無偷加simple-connectivity必要性。 |
| Morera reflection | 主定理限定實中心disk，保反射後每個diameter點真有開鄰域。lower side共軛Taylor全純，real trace保連續。切三角形得閉半平面polygon，連貼diameter的單側三角形也涵蓋；上／下平移進內部後Cauchy，compact上的uniform continuity傳回邊界積分，內邊cancel後Morera。沒有從「內部全純＋邊界連續」直接未證跳到邊界積分零。 |
| natural boundary | factorial gaps在根unity後尾相位全1，有限prefix有界、positive tail→∞。任意候選extension disk包含一個dense root的compact neighborhood，與radial blowup矛盾，故不只證dense點失敗。首次離開單位盤的path代表與原F在連通overlap由identity相等，才得禁止path continuation。 |

## 全部10題與詳解

逐題驗二中心Taylor（在2值−1）、k圈log與n根乘子、含負m時n整除m、sqrt跨0的零階矛盾、固定Re f=c的2c−conj f反射、零邊interval先reflection再interior identity、dyadic roots dense的自然邊界、weighted factorial closed-disk連續而導數radial blowup、annulus上z²有root而無log、一般n根period criterion。

最後一題的充分方向以c exp((1/n)∫f'/f)構造，兩路差閉積分為2πi乘n的倍數使exp路徑獨立；append小線段給局部全純及g'/g=f'/(nf)，g^n/f零導數加base value1給g^n=f，沒有借未知covering theorem。所有必要假設都可在已讀正文找到。

原打厚兩項修正TH298-01（雙branch point正向簡閉路）及TH298-02（reflection貼邊測試片）已獨立重核，保持原樣。36個labels全相同、無重複，begin/end配對平衡。

## 工程、OPEN與下一步

章級命令：`python v23-staging/book/tools/build.py --chapter 298 --source /workspace/scratch/57dcaeb95aa3/v23-staging/B04/refined --name b04-ch298-refined-smoke --allow-diagnostics`。2輪收斂，完整16頁；overfull、underfull、header診斷均零。單章未接整卷時缺ch293、ch294、ch292三處前引及langley、honda兩個bib key，故ENGINEERING_DIAGNOSTICS；不是本章內部標籤缺失。配對source/PDF hash及樣式hash見book/.build/b04-ch298-refined-smoke/build-report.json。未作正式全頁視檢，不冒稱B06。

B05仍須核292 primitive、293 Taylor/Cauchy/Morera、294 identity/zero order、296 argument principle及本章引用的實際唯一稿與bibliography。一般Riemann surface構造只明列為後卷動機，沒有使用或驗收。歷史來源UNKNOWN、16／22映射及六全局門檻不改。

下一唯一動作：主控實讀本回執並核同一hash，將本章納B05整卷整合；本章無新增數學delta，不需為此再打厚。所有其他章新增delta仍依各自回執複核，不能由本章通過一併清零。完成此298分派後，本子任務等待主控B05接受固定全卷及正式B06指派，現在不改TOC／reading-guide、不做全卷排版或終審、不外部保存／發布。後續B06孤尾contents／guide與caption hypcap提示已收到，只作之後gate的待查項。
