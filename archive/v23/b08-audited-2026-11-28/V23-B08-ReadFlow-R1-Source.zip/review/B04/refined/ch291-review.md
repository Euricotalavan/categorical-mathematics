# V23 B-04｜第291章獨立精修回執 v1

交接 ID：V23-B04-REFINE-291-20261128-v1。角色：獨立精修；發出→接收：精修子任務→主控／打厚複核。方案 B 單一 Work；本章 B-04，不是 B-05、B-06 或 B-07。前次排版工程任務只做模板和合成試片，未參與本章起稿或打厚。模型及推理強度實際設定未獨立核實，記 UNVERIFIED。

## 固定接收及輸出

| 身份 | SHA256 |
|---|---|
| 最終打厚輸入 `B04/thick/ch291.tex` | aee7fcbb4ac872852891e47fa8817ffa7800882dd18cc9534166e36968dab2da |
| 打厚回執 `B04/thick/ch291-review.md` | ea5d6e6c7ff069b07404ea43d1097149fcdcc8f907e1c1cd0461320cbc70e8d1 |
| 本次精修輸出 `B04/refined/ch291.tex` | cf037090851d5422b53060b27ba7a2611989c92a510885a3aabbf13309db5c5e |
| KEEP：B03/real-differential-thick.tex | 5d309e73c90109e3fe843f2d4af7db7de2cee12748dfbcc29b8696a2b6e73e65 |
| 章級工程 PDF | c408ee7936b990a377de12d87d180cc978549f7563063c8fec336b7d5ec8c164 |

先完整讀入 draft 的818行，再核最終打厚全部差異及完成稿的數學單元；未把打厚報告本身當作通過證據。B01 foundations 的291-01–16、B02 design、B03 final v2 精修及正式交接已實讀。輸入 hash 與主控傳入一致。未改 draft、thick 或核准片段。

來源 PDF 本次重新實算 hash 與 B01 一致：H Howell–Mathews `7d494e3ebcecb0654ba4d7d325987aa7292b030dd461796963fc4e1e4a5102ce`；B Beck 等 `941c08dca537ec96c49dbc5351648d53c1804504fc29d777eccaa035c6d4b1cd`；W Weber `893da9917e484edd37d067f319d9ad930a94ed47e49065373232db7e15415050`。實讀局部：W Lem1.6.2；B Thm2.3.1、Ex2.3.3、Thm7.4.3／Prop7.4.5 及其證明、根法推論；H Ex3.6／Thm3.4、Thm4.15–4.17 與相關例題及差商尾項證明。不是三本全文審核。

## 逐項覆蓋與獨立核查

| B01責任 | 實際正文落點／核查結果 |
|---|---|
| 291-01–02 | def:291-holomorphic、eq:291-linear-complex：開集、所有複增量、有限極限、鄰域全純與單點可微分開。餘項與連續性推論正確。 |
| 291-03 | prop:291-rules 及證明：純量型別、積的二階小項、倒數非零鄰域、鏈式內層增量 O(模h)，包括內層增量為零時的餘項均有效。 |
| 291-04–05 | ex:291-conjugate 兩軸商1／−1；KEEP 的 modulus-square 例為另一孤立點可微測試。新增 prob:291-conjugate-tests 顯式覆蓋 B01 指定共軛平方例：0導數0，非零點兩方向商不同，任何0鄰域非全純。 |
| 291-06–08 | thm:291-real-cr、prop:291-continuous-partials、cor:291-cr-neighborhood：兩向 Fréchet 證明、四偏導型別、導數兩公式、中值點距離及2ε模h餘項界逐項驗算。只在目標點連續與全鄰域偏導存在的區別保留。核准片段315行在精修稿內是原樣 substring，未重寫。 |
| 291-09 | KEEP 連續反例兩路商1／1/2完整保留；新增同題中的 h=共軛z平方/z 顯式覆蓋 H Ex3.6：模h(z)=模z，四偏導1,0,0,1；兩軸商1、對角商−1；被迫 L(w)=w 而餘項比2，無實微分。 |
| 291-10–11 | def:291-analytic、thm:291-radius：n=0項、正半徑解析性、0／有限／∞半徑、limsup量詞、較小閉圓盤 M-test、距任意中心a的外部發散、邊界另判均正確。 |
| 291-12 | 新增 prop:291-ratio-radius 完整證明，分別處理0、有限正值、∞的比值極限並要求尾部係數非零；新增 ex:291-oscillating-radius，根值2／3交替、limsup3、半徑1/3，係數比沿子序列0／∞，邊界奇數項模1。補足原稿僅引ratio test及沒有振盪根例的責任缺口。 |
| 291-13 | lem:291-uniform-tools：uniform N不依點、ε/3、完整性與可求和尾項證明成立；幾何例與稀疏級數題有閉盤界。固定路徑下積分交換屬尚未定義的292工具，本章未提前使用，B05須核292相應落點。 |
| 291-14–15 | thm:291-termwise：ρ處係數有界→nr^(n−1)可求和→差商及導數尾項共2倍上界；先N後δ；導數半徑反證選R<t<s<R'並界 Ms(t/s)^n/n 成立。生成函數例已正確用一次微分乘z；在1/2處和為2，未代入邊界。 |
| 291-16 | 局部解析定義、導數係數唯一、改中心、Cauchy乘積、複合／倒數均先有絕對和控制；解析⇒全純已證，全純⇒解析明示待293，不形成循環。 |
| B02新增基礎 | exp加法由絕對Cauchy乘積，非零、實限制及三角公式正確；D(1,1)上的對數導數1/z，e^ell/z零導數在連通盤上為常數；局部m次根的選值、域及構造成立。未借全域log或後章可去定理。 |

七個教學節及習題節依先備相接。現有 lem:291-zero-derivative 用多邊形連通與實分量MVT，不用了不存在的複值MVT。改中心的雙重絕對和、composition 的 A(r)→0、根分支初值選擇均可由已讀正文接續。沒有為字數刪必要條件或首次操作。

九道題及完整解答逐一驗算：線性加共軛線性、立方CR僅兩軸、新增共軛兩例、實值全純／非連通反例、稀疏指數半徑與閉盤收斂、平方Cauchy乘積、奇偶係數、局部log與exp逆、平方根1/2及3/8係數與連通商唯一性。未發現尚存的數學錯誤。

## 最小修改及再核義務

本次只做三處局部增補：把原四行比值引述換成帶端點情形的證明；增加一個振盪根增長算例；增加一題共軛平方與CR不足的對比題／全解。沒有改已核B03片段或其餘打厚修正。新增標籤僅 prop:291-ratio-radius、ex:291-oscillating-radius、prob:291-conjugate-tests；原46標籤全保留，總49，無重複；環境配對核過。

這些是針對 B01 具體責任缺口的數學增補，不為湊頁。因新增證明／例題在先前打厚輸入中不存在，請打厚對這三處新增單元作有界複核再合入；不需重做原已核內容。此精修回執不代簽該複核或B07。

## 工程及限制

根 verify.py 沿固定 ReadFlow R1。章級命令：`python v23-staging/book/tools/build.py --chapter 291 --source /workspace/scratch/57dcaeb95aa3/v23-staging/B04/refined --name b04-ch291-refined-smoke --allow-diagnostics`。兩輪收斂，實際19頁；原draft為17頁。沒有改字級、行距或留白；頁數不是驗收門檻。

PDF位於 `book/.build/b04-ch291-refined-smoke/build/entry.pdf`，build-report.json 固定配對源hash和樣式hash。overfull、underfull、header diagnostics均零。只有被單章隔離的 ch:293 兩處前引未解析，因此工程狀態為 ENGINEERING_DIAGNOSTICS；不能稱全卷引用已通過。未做本章正式全頁畫面檢查，B06尚未開始。語義審讀與工程／視檢分列。

OPEN：新增三單元待打厚有界複核；292的固定路徑積分交換、293反向解析性與跨章引用待B05實際整合核；本章和整卷B07未開始。原歷史UNKNOWN、16／22映射及六全局門檻保留。本章精修無其他已知數學阻塞。

下一動作：主控讀入本回執與三處新增diff，交打厚複核新增部分；通過後合入唯一正文並繼續B04。禁止覆寫draft/thick、改核准片段、提前B06／B07通過、重開凍結卷或外部發布。檔案已在共用區，文案產出不等於主控實讀；待接收回執核hash。未作外部保存或發布。
