# V23 B-04｜第300章獨立精修回執 v1

交接ID V23-B04-REFINE-300-20261128-v1；獨立精修→主控／打厚有界複核。方案B單一Work、本章B-04；未啟動B-06／B-07。模型與推理強度實際部署未核實。主控另明確授權增加區間／圓弧的harmonic boundary-value應用，以有證明內容增加深度。

| 身份 | SHA256 |
|---|---|
| 打厚固定輸入 B04/thick/ch300.tex | 937e12230d411781cf126bad3e61d3746341a4b976741dd5bf076900554bf27e |
| 精修輸出 B04/refined/ch300.tex | ff6728556b8fb8508f8f5fa29d3c2df6916bb3fa2034d98f4d3c438fd1f73ca7 |
| 章級工程PDF | 1ca1658a3e1abf99b74efe32edccda838619ad8b463c851d7689bb58c81d5efe |

逐字diff另存`ch300-delta.patch`，可直接對固定打厚輸入核新增義務及兩處局部修正。未覆寫draft／thick。

## 實讀及精修證據

完整讀入最終打厚949行、B01 global 300-D01–P19、B02本章設計及共用介面，先獨立核證再讀歷史回執。實讀W Lem5.2.5及Thm5.2.6的完整非空族／RMT證明及§5.3邊界定理狀態；來源固定PDF沿本輪已實算W hash893da991…15050。全章既有證明、公式、例題與10題詳解逐一核，沒有把來源RMT的簡寫或未證邊界延拓當作本稿通過。

| 覆蓋 | 獨立核查結果 |
|---|---|
| 300-D01/T02/P03 | 非零切向量下(f∘γ)'=f'γ'；複乘法同旋轉／縮放故保定向角，臨界點局部m次冪分開。指數非單射的必要反例保留。 |
| 300-D04/T05/P06 | Möbius determinant、∞與極點、逆式及係數同乘；平移／乘法／倒數的廣義圓方程，三點正規化及固定0,1,∞的唯一性均正確。 |
| 300-E07/T08 | Cayley雙向不等式與逆域證onto；Schwarz最大模證法、disk automorphism逆式及1−模φ²恆等式、Schwarz–Pick兩式與等號剛性全部核算。 |
| 300-T09–P13 | 只採298的路徑同倫⇒log／root方向，不循環借RMT拓樸等價。非空族的sqrt像與其負集不交，遺漏一個開盤後倒數有界；正規族sup有限且正，Montel／導數及非恆常極限保單射；漏值b的q²=φ_b∘f給改進因子(1+s)/(2√s)>1，s∈(0,1)的理由正確；唯一性另用正導數的旋轉。 |
| 顯式映射 | sectors、strip、slit、half-disk、lens及Joukowski每個中間域／逆branch均查。Lens代入兩圓得Re w<−模Im w，旋轉後平方才是H；Joukowski二根乘積1且避單位圈，恰一外根給onto，平方根branch由已證inverse選，不任套principal root。 |
| conformal radius | disk、H、slit及lens數值核，lens map derivative2i經−i旋轉變2，所以radius1/2；domain inclusion嚴格性、一般映射導數界與等號雙全純正確。 |
| 增域與距離 | Increasing-domain theorem先有限覆蓋每緊集、Montel對角抽列，r_n↑L及Schwarz迫L=r_U，然後整列升級。Disk距離的徑向上界及下界、密度2模f'/(1−模f²)、H密度1/Im z及所有映射收縮的鏈式與路徑積分皆核。 |
| 300-D14/T15/T18/P19範圍 | 本章只在顯式座標討論boundary identification及局部角導數α/π−1，未提出Jordan閉包同胚或完整SC存在／全域單射定理，故不冒稱其來源P UNKNOWN已解。B02未要求在此自證完整一般邊界理論；相關UNKNOWN保留。 |
| 300-T16/P17 | 一般Schwarz reflection在B02明列交298；本章不重證，B05須核298實際落點。 |

十道既有題解核完：2i正規半平面map及逆、三點Möbius保H、中心strip inverse、3π/2 sector branch、Pick rigidity、radius包含等號、全平面／穿孔盤障礙、sqrt改進因子、H中垂直距離模logy、Joukowski ellipse的半軸／方向／外域，均無尚存計算錯誤。

## 局部修正與新增應用的精確義務

1. prop:300-univalent-inverse補U為domain；若U不連通，原「image is a domain」不成立，現假設與使用範圍一致。
2. Disk-distance下界證明不用尚未明列的absolute continuity及a.e.鏈式，而令ρ_ε=√(模γ²+ε²)。它在每個C¹片段可微，模ρ'_ε≤模γ'；對H(s)=log((1+s)/(1−s))作普通實鏈式及有限片段FTC，最後以分母一致正下界令ε↓0。這完全在已採Riemann積分背景內，結論與公式不變。
3. 依主控明確指示新增「A harmonic boundary-value application」：先定義harmonic及以CR／二階混合偏導證holomorphic imaginary part調和，再證prop:300-harmonic-interval。a<b為有限實數；T=(w−b)/(w−a)的Im=(b−a)Im w/模(w−a)²>0，Log branch於H採Arg∈(0,π)，所以u=Arg T/π調和且0<u<1。邊界(a,b)取1、其外實軸取0是任意域內接近的極限；∞極限0。兩endpoint不指定值，沿角θ接近a、b分別得1−θ/π、θ/π，說清為何直上取1/2不足給全極限。
4. Disk pullback用W=C^−1=i(1+z)/(1−z)，v=u∘W仍是holomorphic function的虛部。W(e^{it})=−cot(t/2)嚴格遞增給exact open arc；boundary point1由W→∞給0，只有C(a),C(b)兩跳點例外。沒有引用Poisson公式或假稱boundary uniqueness。
5. 新ex:300-harmonic-arc取a=−1,b=1，boundary data為左半圓1、右半圓0，跳點i,−i；v(0)=1/2，實直徑s∈(−1,1)上v(s)=2 arctan((1−s)/(1+s))/π=1/2−2 arctan s/π，兩端極限分別1／0。branch與inverse-domain逐項核算。

請打厚對上述精確delta作有界複核，尤其新harmonic application與smooth-radius證明替換；不用重做其他已核段落。保留原40標籤，新增prop:300-harmonic-interval及ex:300-harmonic-arc共42，無重複，環境配對通過。沒有改正式R1樣式或spacing。

## 工程與下一步

命令：`python v23-staging/book/tools/build.py --chapter 300 --source /workspace/scratch/57dcaeb95aa3/v23-staging/B04/refined --name b04-ch300-refined-smoke --allow-diagnostics`。2輪、21頁（主控原稿benchmark18頁），零overfull／underfull／header診斷；只缺單章隔離的ch294、ch298、thm299-montel、cor299-univalent-limit、ch293五處跨章引用，因此ENGINEERING_DIAGNOSTICS。內部引用已解。未做正式全頁視檢，不稱B06完成。

OPEN：delta待打厚有界複核；B05核294局部power／inverse、298log／simply-connected／reflection、299Montel／univalent limit的實際唯一稿來源。一般Carathéodory、完整SC證明等未納入內容不可標作covered；原來源UNKNOWN及全局歷史門檻不清零。

下一唯一動作：主控核本精修版、delta與回執，交打厚複核新增／替換證明後合入。文案可取不代表主控已讀；待接收核hash回執。依主控最新追加分派，本精修角色接下來只獨立核298，完成後等B05正式gate，不自行開始B06或其他章。未做外部保存／發布，凍結卷保持只讀。
