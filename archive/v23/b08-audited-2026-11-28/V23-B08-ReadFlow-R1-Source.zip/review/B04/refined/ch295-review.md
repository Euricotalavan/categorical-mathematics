# V23 B-04｜第295章獨立精修回執 v1

交接ID V23-B04-REFINE-295-20261128-v1；獨立精修→主控／打厚有界複核。方案B單一Work，本章B-04；未啟動B-06，不是B-05或B-07。模型與推理強度實際部署均未核實。

| 固定檔 | SHA256 |
|---|---|
| 最終打厚輸入 B04/thick/ch295.tex | 7c5a05d6d211d606499f9afe6c4cab83c04d54011cbcb2adcf95f5bc5ef06a8b |
| 精修輸出 B04/refined/ch295.tex | eca80119b8b3f2d2629e696c7c49c9f34e6bec0e47812fea372736653f70b5eb |
| 主控提供原創向量圖 book/figures/annular-residue-cycle.pdf | ed7d9b64ec2fa7ff152337dab83fbe3442b627e1dbccd7f7ca9996fb832d4710 |
| 章級工程PDF | 656b01f35ac0bfbe14fdc0dbb017c05dc23201be3adb3328b413aecb071041af |

實際完整讀入最終打厚694行，先獨立逐證明／例題／題解核算，再讀打厚回執。已讀B01 foundations 295-01–17、跨來源差異及相關OPEN；B02全卷介面。B/H/W來源PDF的hash沿本任務291時實算一致的固定檔。對照原文實讀 B Thm8.3.5、Cor8.3.7–9、Prop9.1.6及證明、Thm9.2.2、Prop9.2.4／9.2.7及例題；W Cor4.1.9及證明。沒有聲稱三本全文已核。

## 逐項語義及來源責任

| 責任 | 正文落點及獨立重核 |
|---|---|
| 295-01–02 | def:295-laurent 與 annulus 節：正、負兩半各收斂，負半變數1/(z−a)的半徑S轉內半徑1/S；邊界另判。兩半緊子環絕對一致收斂與全純由291冪級數結果取得，不偷用對稱和。 |
| 295-03–04 | thm:295-laurent：外圈核z/w、內圈核w/z的幾何級數；兩個負號相消；中間圓差零同調故係數半徑不變；M外R外^(−n)及M內r內^m給可和界；逐項乘w^(−k−1)積分選出任意整數係數。每一步在正確的固定圓／閉子環一致收斂。 |
| 295-05 | def:295-isolated、thm:295-classification：有限主部非空、m正整數、首係數非零；與可去及無窮主部三分互斥，唯一性來自Laurent係數。 |
| 295-06 | thm:295-removable 的小圓界使每個負係數歸零；新增 cor:295-vanishing-product 顯式補 B Prop9.1.6(a) 的一般判準：(z−a)f→0當且僅當可去。反向先延伸有界乘積g，g(a)=0，Taylor除一因子；不借後章。另明說乘積僅有界仍容許單極點。 |
| 295-07–08 | prop:295-pole-limit 的倒數非零、可去延伸及有限階零點因子完整；(exp z−1)/z、z^(−4)、exp(1/z)、sin z/z³均先給正確Laurent／延伸值再分類，正負實軸反向趨勢反駁把無界誤作極點。 |
| 295-09 | def:295-meromorphic、prop:295-local-quotient：明列U中相對閉離散極點集及可去先填。精修補 f:U\P→C 的型別，排除任意有限值填極點；日後球面版本用∞。局部非恆零及連通分支的限制保留；乘除階數加減、和的消去、零分子、分母非恆零及緊集零點有限均成立。 |
| 295-10–12 | def:295-residue、eq:295-local-residue、prop:295-residue-formulas：正向小圈正號、regular／removable留數0；至多單極點才用極限；高階公式對延伸後g取m−1導數並除(m−1)!，不是對未定義中心原式直接求導。 |
| 295-13–15 | quotient formula p(a)/q'(a)由q=(z−a)v、v(a)非零；分子同時零時可去且公式0。exp z/sin z留數(−1)^k exp(kπ)、exp z/(z−a)³留數exp(a)/2、exp(2/z)本性留數2、sin z/z³二階但留數0均核。補寫exp(2/z)正向單位圓積分4πi，顯式覆蓋295-14計算。 |
| 295-16–17 | thm:295-residue-theorem：先用K=trace∪非零繞數域建立閉、有界、K⊂U；相對閉離散S與緊K交有限。減去各繞數倍的小圈後，在U外及每個S點索引為0，才能對U\S用293全域Cauchy。此為本卷自證較強零同調版，不冒稱W的零同倫陳述就是此版；沒有借296辯值原理。 |

B02要求亦逐項核過：Casorati用省略小圓盤的倒數延伸，非零值／零值兩種都排除本性；序列與無界性選點均在原去心盤。環域原函數 iff c−1=0，以可和Laurent原函數級數證充分性；座標留數保留φ'，以非零線性因子的同倫給像圈索引1，再逐項積分。無窮遠區分f(1/w)的函數類型和−w^(−2)f(1/w)的微分留數，符號及有限奇點總和式正確。

全部8題及詳解已獨立核算：兩種環域係數、次冪增長可去的臨界α=1、三種分類與留數、雙極點抵消、含本性積分2πi、帶負繞數−10πi、亞純導數無簡單極點、球面亞純為有理的有限極點與Cauchy估計證明。未發現其餘數學錯誤。

## 最小補丁及圖

只新增上述一般可去判準及證明、亞純型別／極點值慣例、明寫本性積分，並依主控明確指示把原創圖緊接ex:295-annular-residue置入。圖採`.48\linewidth`，短caption與圖用一個短minipage保持同一閱讀單元，沒有鎖住長證明。新增 cor:295-vanishing-product 與 fig:295-annular-cycle；原42個標籤全部保留，總44，無重複；環境配對通過。

向量圖已獨立渲染查看：外|z|=2逆時針，內|z|=1/2順時針，0及1位置正確。章級PDF實體第13頁再放大查看，例題、圖及caption相鄰，公式與頁尾未見碰撞。未作全章正式全頁視檢，不拿此局部檢查代替B06。

一般可去判準為針對B01已列來源責任的數學增補；請打厚有界複核新corollary及定義澄清再合入，無須重做原已核章。

## 工程、OPEN、下一步

命令：`python v23-staging/book/tools/build.py --chapter 295 --source /workspace/scratch/57dcaeb95aa3/v23-staging/B04/refined --name b04-ch295-refined-smoke --allow-diagnostics`。2輪收斂，實際16頁（打厚原稿15頁），未改R1間距／字級／樣式。overfull、underfull、header diagnostics皆零。工程狀態仍ENGINEERING_DIAGNOSTICS，因單章隔離而缺ch:293／294／303／304八處前後引；沒有缺本章內標籤。配對源hash、PDFhash和圖hash見book/.build/b04-ch295-refined-smoke/build-report.json。

OPEN：新增corollary及定義澄清待打厚有界複核；B05要讀293實際循環Cauchy及294實際因子／逆函數落點，並查299球面值定義一致；全卷引用、B06全頁閱讀與B07唯一嚴格終審未做。歷史UNKNOWN與凍結範圍維持。

下一唯一動作：主控接收上述固定精修版，交打厚複核新增部分後合入唯一正文。不得覆寫draft／thick、不推送或外部保存、不因個章工程或精修稱整卷通過。已以內部訊息報主控；文案可取不等於主控實讀，請回執核檔及hash。
