# V23 B-04｜第292章獨立精修回執 v1

交接ID：V23-B04-REFINE-292-20261128-v1。方案B單一Work；角色：獨立精修，未參與292起稿或打厚。發出→接收：精修→主控／打厚複核。模型及High實際設定未另核實。這是B-04章級精修，不代簽B-05整合、B-06排版或B-07唯一整卷終審。

## 固定版本與實讀

| 身分 | SHA256 |
|---|---|
| 打厚輸入 `B04/thick/ch292.tex` | cfbca4322cf214f20c94952bc8b438ddcdb3a280706e32c9ee6d5b927513e445 |
| 精修輸出 `B04/refined/ch292.tex` | aeab998650fac4748ea9ef4c5613dd7c18e46c0466f226da5a0234562d0e562c |
| 已核上游 `B04/refined/ch291.tex` | cf037090851d5422b53060b27ba7a2611989c92a510885a3aabbf13309db5c5e |

實際讀完292全部839行，含所有10題及完整解答；先讀打厚回執後仍逐正文重算，不將其標籤當數學證據。實讀B02固定設計、B01 foundations之292-01–12及相關跨章風險；實看291的domain／polygonal connectedness、zero derivative lemma與local-log-root。另回查Beck 1.6原文Prop4.1.3、Thm4.2.5、Thm4.2.9所載重參數與原函數條件，與B01固定來源相接；沒有重讀整本或把原文習題當已給證明。

## 覆蓋落點與數學核查

| B01責任 | 本文實際落點及核查 |
|---|---|
| 292-01 | def:292-path、def:292-chain：有限分段C1、容許零速度、路徑與trace不同、反向／串接端點、整係數有限cycle及非零係數trace慣例完整。 |
| 292-02–03 | def:292-integral及前導複Riemann積分：實虛部定義、純量線性、分割無關、只需trace上連續；ex:292-path-dependence兩條積分1／1+i重算一致。 |
| 292-04–05 | prop:292-integral-rules：遞增雙射且端點匹配，分片換元成立；反向負號與串接兩倍速度各自有推導，prob:292-reparam的s^3允許端點速度零。 |
| 292-06–07 | def:292-length、thm:292-ml：長度與鏈長使用絕對權重，先以旋轉取實部證複值積分三角不等式；prob:292-chain-bound的五圈例能辨識幾何union不能代替鏈長。 |
| 292-08–09 | def:292-primitive、thm:292-ftc：F'=f且f連續使沿路實基本定理可用；公式是F(γ(b))−F(γ(a))，不是參數端點代入。 |
| 292-10 | ex:292-no-primitive、ex:292-circle-powers：正圈1/(z−a)積分2πi；k=-1唯一非零，局部primitive的ell明確引用291的D(1,1)版本。 |
| 292-11 | thm:292-exactness：domain polygonal paths、閉路零推出良定積分函數、小線段差商與連續性均實核；restricted polygonal problem不偷用所有piecewise C1閉路假設。 |
| 292-12 | def:292-homotopy、thm:292-index-homotopy與thm:292-local-exact-homotopy：固定端點／閉路自由同倫分開；同倫只需連續，幅角比值與有限網格兩條證法均不微分同倫。 |
| B02補充接口 | argument-lift用291 local logarithm有限拼接，唯一性靠2πZ連續函數；index整數／局部常值／遠處零、winding support compact性完整。parameter-integral及兩固定鏈交換積分給293所需接口，不借後章Cauchy／可去定理。 |

compact winding support是trace與非零index集合的聯集：其補集為off-trace零index開集，且每條有限路徑遠處index為零，故閉有界；null-homology時確實緊含於U。共同避開點的距離d與d/2界給核差常數2，沒有遺失分母因子。

局部原函數同倫證明的格網：每個小矩形影像在一個primitive disk；共享邊兩端同在相鄰兩disk，其直線段同在兩者的凸交；內邊能抵消，原端邊可由相同primitive比較。左右邊在閉路同倫下是同一polygonal replacement逆向，在固定端點下則常段。沒有隱藏光滑同倫要求。

10題逐解核算：共軛圈2πir²；重參數積分i；鏈權重2／3及五圈；兩向半圈±iπ；僅polygonal閉路的primitive；四點index2／1／0／1；近閉路直線同倫；矩形頂邊2Ae^-B/(B²−4)；a>0指數弧O(1/R)與a=0極限iπ；primitive交盤的單常數。未發現尚存數學錯誤。

## 精修差異、依賴及交接

唯一文字修改是在prop:292-parameter-integral證明首句補空trace時A≡0，避免對空compact product直接寫sup造成讀法不清。非空情形與所有已核證明／例題保留原文；無新增定理、來源或章界，不因篇幅而增刪。此改動不改定理範圍，請打厚作有界確認後合入，不需重做已核原證明。

50個標籤保留且唯一；環境配對與本章reference已核。對291的local-log-root、zero-derivative標籤已在上述固定精修版本找到；只有ch:293是明示後章前引。下一章使用本章固定鏈限積交換、參數積分、連續同倫及緊winding support，需B05再以唯一正文實核。

本角色未編譯、未改master／draft／thick、未寫其他路徑，未作PDF全頁視檢；工程／PDF與語義核查分列。OPEN：本次局部clarification待打厚確認，294等待獨立實讀；整卷覆蓋、工程及B07仍未完成。已知來源歷史UNKNOWN照留，不以本章報告解除其他工作凍結。

下一唯一動作：主控接收本章精修檔及hash，交打厚核本處短clarification，之後依B04流程合入。禁止重做：不重寫已核數學單元、不改章號或來源版本、不將本章精修當B07通過。檔案已在共用區；產出與回報不等於主控已實讀，待接收回執。
