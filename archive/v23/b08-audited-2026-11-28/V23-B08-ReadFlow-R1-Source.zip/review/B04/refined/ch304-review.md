# V23 B-04｜304獨立精修回執 v1

2026-11-28；B單一Work，精修。完整讀固定輸出509行、全部證明、10例、10題與10解，另核draft→thick全部delta。實際模型／High設定未另核實。

輸入 `../thick/ch304.tex` 與唯一交整合輸出 `ch304.tex` 的SHA-256相同：
`dcd2f7ebbe9d4efd175d454c6e6a892aef4b23c129413493a9c5309545794912`。

**本章精修通過，無實質補丁，逐位元沿用。** 實際為7個內容section＋1題解section、10個example、10個problem、10個psolution、47個唯一label，環境配對。打厚回執467行指輸入，固定打厚輸出實為509行，均已讀。

## B01逐項來源與正文落點

已回核L §3.3.1 pp32–33、K §32.2 pp72–73，以及W Lem7.2.7 pp96–97、Thm7.3.1 p97。特定λ0及Big Picard長度證法是B02明確採用、自負完整推導責任的路線，不冒稱K或W原文已有此特定公式。

| B01項 | 實際落點與處置 |
|---|---|
| 304-01 D，L(3.17) | `sec:304-targets`：有限a取1/(f−a)的m、N；∞取f的m、N。原f極點轉倒數零，計重數，不混N與m。 |
| 304-02 S，L§3.3.1 | `thm:304-first-main`：固定f,a的誤差；精確中心c_a非零，d_a為整數；∞為定義恆等。 |
| 304-03 P，L(3.14)–(3.16) | `lem:304-translation`雙向log(1+模a)界且N不變；FMT proof套T(1/(f−a))=T(f−a)−log模c_a，符號正確。 |
| 304-04 E，L§3.3.1 | `ex:304-exponential`：省略0由m=r/π承擔；非零晶格N=r/π+O(logr)、m=O(logr)只聲明已證精度。a=−1的兩側界T−2log2與T正確。 |
| 304-05 S/P/E候選已採，L§3.3.2(i) | `cor:304-mobius`有完整倍乘／平移／倒數組合證明；`ex:304-tangent`得2r/π+O(1)，±i省略，不拿原練習當已附證。 |
| 304-06/07 S/P，L§3.2.8 | 已前置303 `thm:303-rational-test`；本章 `rem:304-first-limits`用其推出T→∞，無新循環。 |
| 304-08 S，K Thm32.4 | `thm:304-little-picard`只稱整函數最多省略一有限值；亞純推論為最多兩球面值。 |
| 304-09 P候選未採，K覆蓋證路 | 不依K「不難驗證覆蓋」或未證提升。正式曲面／覆蓋留後卷，以本章density完整證明取代，不留下Picard證明空缺。 |
| 304-10 S候選已完成，K末頁僅敘述 | `thm:304-omitted-montel`在304自證；299只供AA、兩圖卡極限和弦距長度，不拿有限值Montel替代。 |
| 304-11 P候選未採 | 不用先強Montel再f(nz)的候選證路；`thm:304-little-picard`直接以任意R中心導數界令R→∞。 |
| 304-12 E，K/L | Little Picard後e^z最佳與多項式無省略；`ex:304-essential-exp`逐值驗1/(α+2πik)並排可能零分母。 |

## 新增完整證明責任與獨立核對

- `lem:304-density`：距離分數冪是正實數冪，C²域恰去0、1。徑向∆log(1+r^α)=α²r^(α−2)/(1+r^α)²、∆logr=0；α=2/7給4/49。0處λ0²~4r^(−12/7)、∆logλ0~(4/49)r^(−12/7)，比1/49；1對稱同；∞為r^(−16/7)與(8/49)r^(−16/7)，比8/49。三端與餘下緊集才給q_*>0。λ=√q_*λ0的縮放方向正確。λ0(1+模w²)在三端發散，∞階r^(6/7)，所以有另個全域c>0。
- `thm:304-disk-comparison`：Hessian鏈律用CR正交等長梯度消混合項，∆(H∘h)=∆H(h)模h′²。非零h′局部log模調和，故∆logu≥u²；v_s=2s/(s²−t²)滿足∆logv_s=v_s²，中心由連續性。內縮s<R確保u有界、比值邊界延0；正最大>1不在critical點，C²對數可用，Laplacian矛盾正號無誤。最後s↑R，不假設原外邊界正則。
- `rem:304-spherical-geometry`：半徑1/2的S使弦=χ、速度=模dw/(1+模w²)，與299 `eq:299-chordal-length`之unit-sphere除2一致。χ(w,2)≤1/(2√5)推出χ(w,∞)≥1/(2√5)，故模w≤√19；未將小∞球誤作有限值界。
- `thm:304-omitted-montel`：R/2內h#≤8/(3cR)，線段弦距得局部等度；AA／耗盡／299極限定理得亞純或恆∞。固定M逆在compact sphere一致連續，無需等距。原極點用1/f圖卡，因M的∞原像被省略，其分母在該圖卡非零，故composition真全純有限值。
- `thm:304-little-picard`：任意R中心界2/(cR)令h#=0，再以有限h值得h′=0；不由FMT或未證省略值Montel偷推。
- `lem:304-punctured-bound`：H(ζ)=h(e^ζ)在左半平面，到邊界距離log(r0/模z)；先s<距離再取極限，H#=模z·h#。全圈長≤4π/(c log(r0/r))；只選單一log值，未聲稱穿孔盤有global log。
- `thm:304-big-picard`：兩個有限次目標可共同縮盤省略；affine保本性。295 Casorati給h(z_n)→有限2，圓像長→0加χ三角式得整圈在有界圖卡，a_(−k)≤√19r_n^k且半徑無關，負Laurent全消→可去矛盾。小球面長本身容許極點，稿件以finite base排除，未跳步。
- 全10例／10解題已核：有理∞重數的q,s,D各情況、z^d非零目標常數−log模a、雙指數的−1/4雙晶格、平方有理式c_1=−4、兩種puncture map、e^(1/z)導數反例、縮放精確區間、裂平面log後有界指數、selected-circle Laurent界及亞純Big Picard圖卡推論均成立。

## 範圍與下一步

SMT完整敘述／例外集與誤差項、Cartan、對數導數引理、deficiency、一般曲面覆蓋不在本章責任。B01早期X-ADV-03對Big Picard的暫排建議已由正式B02完整平面證路取代，不能回用舊候選界來刪已授權證明。

本章未發現數學阻塞。待主控接同hash加入唯一整合稿，實際PDF／全頁QA／B05有序依賴與B07整卷終審另核；本回執不替代那些階段。若密度尺度、定義或hash變動，相關三端／圖卡／Picard重核。未改master、其他章或凍結卷，待明確B05派令。
