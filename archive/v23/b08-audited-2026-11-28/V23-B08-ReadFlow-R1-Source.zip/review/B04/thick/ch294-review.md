# V23 B-04｜第294章獨立打厚回執

交接 V23-B04-THICK-294-v1，2026-11-28。角色：本章獨立打厚。方案B單一Work；接主控指定的固定草稿，完整讀全部正文、證明、例題及10題解答；對照B02設計、B01 foundations第294章與共同風險。實際模型／High設定未另核實。

| 角色 | 檔案 | SHA-256 |
|---|---|---|
| 已讀固定輸入 | `../drafts/ch294.tex` | `72c10b4cc507c7ff87b844e7295f8933be0dd9ad99c1546f7e4f0f39ed8e42b9` |
| 交精修唯一輸出 | `ch294.tex` | `72c10b4cc507c7ff87b844e7295f8933be0dd9ad99c1546f7e4f0f39ed8e42b9` |

**判定：本章不需額外展開或實質補丁，保留完整原稿逐位元複本。** 相同hash不代表跳過核讀；下表記實際檢查關節。此判定只供後續精修，非B-07全卷終審。

| 固定定位 | 已核證據 |
|---|---|
| `thm:294-factorization`、`prop:294-orders` | Taylor首非零項、非零unit、階數唯一與孤立性成立。乘積／不同階和／同階取消分別處理；商的負階以模發散排除有限延伸。未把局部恆零函數賦有限階。 |
| `prop:294-finite-zeros`、`thm:294-identity` | 先明示有限零點命題的第一部分待隨後恆等定理，沒有提前使用形成循環。恆零鄰域集合開且相對閉：以每階導數連續及Taylor傳遞到極限點；域內聚點、互異點、連通性俱明列。邊界累積與非連通反例成立。 |
| `thm:294-local-inverse` 全證 | 閉圓盤內線段積分給R的1/2-Lipschitz界，反三角給f的下Lipschitz界。T_w在閉完備圓盤自映且收縮；迭代距離幾何可和，固定點存在唯一。參數的嚴格半徑保解在開圓盤。V以開圓盤與f逆像交集定義，無偷用open mapping；g的Lipschitz連續與倒差商給全純性、導數非零。 |
| `lem:294-local-root`、`thm:294-normal-form` | 實核第291章已存在 `prop:291-local-log-root`，在D(1,1)以收斂級數得規範根，故不借298全球log。q(a)≠0→φ′(a)≠0，先用已證local inverse，再限制像為圓盤；每個非中心小值恰m個互異原像、中心一個但重數m，界線清楚。 |
| `cor:294-injective-derivative`、`prop:294-critical-order` | 單射排m≥2，local inverse提供全像開與局部逆的拼合。φ′非零可直接由φ逆的鏈律得到，未循環。f′階m−1與局部非中心fiber的simple性正確；未把critical values誤說全域離散。 |
| `thm:294-open`、`thm:294-maximum` | 在任意開子集內縮正常形鄰域，像為圓盤得open mapping；非恆常與連通性足夠。弱局部最大在f(a)=0和非零兩情形皆被像中更大模點排除。非連通union的非恆常不足，已明說。 |
| `cor:294-boundary-maximum`、`thm:294-minimum`、`cor:294-boundary-minimum` | 有界域＋閉包連續給緊性與boundary maximum；邊界點是域內點極限，故sup等式充分。minimum只在非零點取局部倒數，再用恆等定理傳回整域；全域boundary minimum明列閉包無零。沒有把local minimum theorem擴為允許內部零的boundary assertion。 |
| 全部例題與10題 | 核sin(z²)乘z的階3、sin在kπ簡單零、取消升階、局部二次inverse係數1,−1,2、z³(1+z)根座標、sin在π/2的二次degree。逐題算得−1/3比值、無窮平坦⇒恆零、非連通反例、exp局部log/全球週期、(z−2)e^(z/2)、像在直線／圓⇒常數、e^(−iz)無界半平面反例、閉盤模1需無零假設，以及sin兩類點degree1/2。 |

來源差異：W §2.5 pp22–25先引用逆函數再作根正常形；本稿以完整收縮論證與291局部根重排為可順讀依賴，未借後章Rouché或全球單值化。B §8.2 pp125–128提供零點／恆等／最大最小模責任，內部聚點與域連通之條件已保留。W正常形原文有中心簡寫，本稿始終用z−a，無需修回來源寫法。

靜態核驗：begin/end環境配對、10個problem對10個psolution、所有本章label唯一。專門跨章label `prop:291-local-log-root` 已定位；其餘以章label對接。正文／PDF配對、實際頁面與全卷交叉引用留整合與B-06，尚未驗收。

下一唯一動作：精修接上述固定hash的 `ch294.tex` 核本章來源落點與順讀；無OPEN數學阻塞。若主控或精修改動假設／證明／hash，重核受影響項。禁止改主檔、其他章、凍結卷或用本回執取代唯一嚴格全卷終審。
