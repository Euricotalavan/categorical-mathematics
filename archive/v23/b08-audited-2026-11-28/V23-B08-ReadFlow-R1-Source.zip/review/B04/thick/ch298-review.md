# V23 B-04｜第298章獨立打厚回執 v1

交接ID：V23-B04-THICK-298-20261128-v1。角色：未參與本章起稿的打厚 → 精修／主控；方案B單一Work。已實讀凍結輸入全部739行（正文、每個例題、10題及完整解答），對B-02固定設計、B-01 global索引298-D01至E14，並實讀L §§12.2–12.3及K §31。模型及High實際設定未另核實。本檔是B-04章級打厚，不替代B-05整卷整合或B-07唯一整卷終審。

| 檔案／用途 | SHA-256 |
|---|---|
| `../drafts/ch298.tex` 作者凍結輸入 | `ed4820503b2a02d1cca8ed3663950120232f81be67616fd3984188bf3594cb58` |
| `ch298.tex` 打厚完整輸出，36999 bytes | `ddca3af33f0c40b3fad2404f71f6789d8151434cbb5b8b16bab3e68181421df9` |

## 補丁與重核

| ID／原文定位 | 影響 | 改後及重核 |
|---|---|---|
| TH298-01，`ex:298-two-branch-points`：「A loop enclosing both zeros produces logarithm change 4πi」 | 指定4πi的數值需要正向單圈的繞數；任意重走或反向loop不一定有此數值，雖某些情況仍回到根的原支。 | 補「positively oriented simple closed loop」，沿296 argument principle對兩個簡零各給+1，總週期4πi，平方根乘子e^(2πi)=1。負向／重走不再被原句無差別量化。已修、已核。 |
| TH298-02，`thm:298-reflection`證明中「If it crosses the real axis, cut…」 | 原有上移／下移證法本身有效，但字面可能漏掉三角形完全位於閉半平面且一邊正好在實軸的Morera測試情形。 | 改明「必要時切開；每個非退化片在一個閉半平面；已在一側的三角形作一片，即使一邊落在diameter」。所有片沿原有平移與連續極限證零，內部界互抵。未改反射公式與定理假設。已修、已核。 |

## 各節實讀與證明級核查

| 實際正文落點 | 核查結果／保留理由 |
|---|---|
| `sec:298-germs` | 芽的同基點、共同開鄰域相等定義可用；等價關係transitivity取交集。值相等不同於芽相等，所有Taylor導數決定芽但任意序列不必收斂，辨識例正確。兩log割線交集兩分量，只有上半平面相等而下半平面差2πi，避免跨不連通交集誤套identity。 |
| `sec:298-recentering` | 雙級數交換先給Σ|a_n|(|b−a|+ρ)^n有限，控制閉小盤，係數與Taylor導數一致。1/(1−z)在b=−1/2半徑3/2例正確；避1緊路徑有正距離和有限細分，沒有把半徑1誤作處處不可跨越的壁。 |
| `sec:298-path-continuation` | 定義用時間局部單一代表函數，含端點相對區間；不只逐點任指芽。固定路徑唯一性在共同小盤以identity使相等時間集合及補集皆開，對重返同底點路徑也有效。有限chain用compact interval cover及Lebesgue數取閉子區間；每段像緊含disk、每seam另有相等disk。反方向用連續性把seam附近時間送入其disk，確實滿足原定義，沒有只列disk而未證chain的缺口。 |
| `lem:298-path-stability` | 正距離來自每段緊像與代表disk補集，以及有限seam disk半徑；選同一δ控制全path。σ每段仍落原disk、seam在相等區，故同一chain可沿σ使用。固定初／終端確保同基點芽的比較；沒有暗借整個homotopy已有單一branch。 |
| `sec:298-monodromy` | 每homotopy slice因all-path假設有continuation；uniform continuity給相近slice sup距離<δ，terminal germ沿s局部常值；connected interval推出全相等，不需預建芽空間拓樸。單值全域F不是只逐點指定值：末端代表disk加短segment證F局部等於代表函數，所以真全純。明列簡連通不給存在性，1/(1−z)反例正確。 |
| `sec:298-logarithms` | 局部log用明確series，exp identity由微分與初值；任一路徑以局部log disks的有限cover及seam常數調整建立存在性。這一步只重用finite-cover技術，不循環預設continuation。global log/root由monodromy給，差2πik與根之商均為連通域上的連續離散值函數。period iff由f′/f的primitive證，選scalar log c後補常數；不要求域本身簡連通。 |
| `sec:298-branches` | log單圈加2πi，n次根乘e^(2πi/n)，零階奇偶證平方根不能過0。sqrt(1−z²)的兩個簡零、明確割線branch及乘子正確；TH298-01限制圈向與單圈後數值精確。沿分段C1閉路的log端差由局部導數鏈律與有限段積分得到，不把一般連續路徑直接當可積路徑。Riemann曲面只作後續動機，不偷借V24覆蓋理論。 |
| `sec:298-reflection` | 低半盤用共軛Taylor得全純；實邊值保兩側連續匹配；triangle/polygon平移入內後Cauchy，再在compact closed-half-disk上uniform continuity傳回邊界積分，最後Morera，確實補了邊界Cauchy步驟。TH298-02覆蓋貼邊測試片。純虛邊值公式−conj(f(conj z))及iz例核正，target line不被混淆。 |
| `sec:298-natural-boundary` | Σz^(n!)在r<1由Σr^n正常收斂；|z|>1項不趨0。q階unit root在n≥q之後所有相位1，正tail徑向→∞且finite prefix有界。dense roots使任何假定extension disk包含一個radial-blowup點，contradicts compact bound；未把僅在dense點不延拓直接當全circle結論。路徑首次觸邊時前段fixed-path uniqueness與disk交unit disk的連通交集identity給真正extension，故不能沿路繞過natural boundary。 |
| `sec:298-problems` 1–5 | 二中心Taylor−Σ(−1)^n(z−2)^n、log k圈加2πik與n根乘子；z^m的n根必要充分n整除m（含負整數）；sqrt在0的零階矛盾；固定實部c的反射2c−conj(f(conj z))均有完整理由。 |
| 同節6–10 | 零邊interval先反射再identity，沒有把boundary當interior；dyadic gaps用2^k階unit roots密性與正tail；Σz^(n!)/n² closed-disk continuous但derivative在unit roots正tail發散，證natural boundary有效；annulus上e^z有log及root，z²有root但period4πi拒log；一般n根period criterion以exp((1/n)∫f′/f)明證path independence、局部holomorphic及g^n/f≡1。所有題解實讀，未用未知表面理論。 |

## 依賴、狀態與唯一下一步

章內所有核心證明可由291–296與本章較早結果順讀：Taylor、identity、Cauchy/Morera、primitive criterion、winding/argument principle。所有path只連續；使用積分時另限piecewise C1。先有finite chain，再有path stability、monodromy、global log/root，依賴沒有循環。自然邊界及連續邊值反例各有獨立證明，不拿來源標題當已覆蓋證據。

36個原標籤全部保留，無重複；begin/end環境計數平衡，沒有異常控制字元。數學完整性與hash／編譯／PDF分列：本次沒有編譯或頁面視檢，沒有宣稱排版通過。來源L/K仍為Preflight的固定PDF版本；本次未修改來源PDF、draft、master、模板、分卷／文獻表或其他卷。

本章B-04打厚完成，無未解數學阻塞；兩處局部文字補丁已直接修入同一完整輸出，交精修核來源與安全瘦身。唯一下一動作：精修讀入此hash，核TH298-01/02及跨章引用後納入B-05整合。整卷最終審核仍由B-07打厚處理，不以此章通過代替。共享目錄檔案已產生並回報主控；對方讀入回執另記。保存與後續封存由主控按既有授權處理，沒有另行外部發送。
