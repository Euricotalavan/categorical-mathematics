# V23 複分析｜文獻確認與 B-01 交接

**2026-11-28（臺灣時間）｜B 方案單一 Work｜待使用者確認書目**

分卷表規劃 14 章。本次核對 V22 的 Git 發行包、章源檔與配對 PDF 目錄，確認前卷止於第 290 章。下表把 V23 的規劃章依序對齊第 **291–304 章**。章內納入範圍、原文逐項覆蓋及證明核查待 B-01。

## 可供確認的公開文獻

三本完整教材、兩份作者講義均已從下列入口實際取回 PDF。已核版本、頁數及章節，並在正文定位代表性條目。逐頁數學校對待 B-01。

| ID | 書目與固定版本 | 公開入口與讀取狀況 |
|---|---|---|
| H | Russell W. Howell、John H. Mathews，*Complex Analysis*，作者網站 471 頁 PDF，以 SHA-256 固定本次版本 | CC BY 4.0。已取全文，核 §3.2、§5.2、§8.7 的位置。 [作者網站](https://complexanalysis.org/index.html) · [PDF](https://complexanalysis.org/howell-complex-analysis-web.pdf) |
| B | Matthias Beck、Gerald Marchesi、Dennis Pixton、Lucas Sabalka，*A First Course in Complex Analysis*，1.6（2025-08），173 頁 PDF | CC BY 4.0。已取全文，定位 §2.2–2.3、§8.2、§9.3 與第 10 章。 [作者網站](https://matthbeck.github.io/complex.html) · [PDF](https://matthbeck.github.io/papers/complex.pdf) |
| W | Matthias Weber，*Complex Analysis*，2026-01-06，113 頁 PDF | 印第安納大學典藏，CC BY-NC-SA 4.0。已取全文，核 §3.3 Weierstrass 乘積、§4.3 Rouché 定理、§7.5 Koebe 四分之一定理。 [大學典藏](https://hdl.handle.net/2022/34728) · [PDF](https://scholarworks.iu.edu/dspace/bitstreams/0a384151-7cd5-460f-a06a-b6be76707024/download) |
| L | J. K. Langley，*Postgraduate notes on complex analysis*，前言標示 2014-01-27，266 頁 PDF | 諾丁漢大學學術網域上的作者講義。同系教師的公開頁面也指向這份講義。已取全文，核 §3.3 第一基本定理、§7.1 Koebe、§12.3 單值化定理的實際正文。 [來源佐證](https://www.maths.nottingham.ac.uk/plp/pmzdn/) · [PDF](https://www.maths.nottingham.ac.uk/plp/pmzjkl/pg1.pdf) |
| K | Ko Honda，*Notes for Math 520: Complex Analysis*，UCLA 作者教學 PDF，73 頁，以 SHA-256 固定本次版本 | 已取全文，§28 有 Montel 定理，§31 有單值化定理，§32.2 有 Picard 小定理證明。末頁列 Picard 大定理的敘述。 [作者頁](https://www.math.ucla.edu/~honda/) · [PDF](https://www.math.ucla.edu/~honda/math520/notes.pdf) |

## 14 章的來源位置

頁碼使用原文印頁，PDF 檢視器的頁序可由章節號定位。以下是本次確認的查讀範圍，供 B-01 逐項回到原文。

| V23 章 | 分卷表主題 | 優先查讀位置 |
|---|---|---|
| 291 | 全純、Cauchy–Riemann 與冪級數 | H §3.1–3.2、§4.4，B §2.2–2.3、§7.3–7.4、§8.1，W §1.2、§1.6 |
| 292 | 複積分 | H §6.1–6.2（pp. 163–180），B §4.1–4.2，W §1.7–1.9 |
| 293 | Cauchy 定理與公式 | H §6.3–6.6（pp. 181–209），W §1.10、§2.1–2.2、§4.1，B §4.3–4.4 |
| 294 | 零點與局部結構 | B §8.1–8.2，W §2.5（pp. 22–25），H §7.4 |
| 295 | 留數與亞純函數 | H §7.3–7.4、§8.1，B §8.3、§9.1–9.2，W §2.6、§4.1 |
| 296 | 辯值原理與 Rouché | H §8.7（起 p. 273），B §9.3（起 p. 147），W §4.3（起 p. 64） |
| 297 | 積分計算與應用 | H §8.2–8.6（pp. 252–272），W §4.2。B 第 10 章提供留數的離散應用候選。 |
| 298 | 解析延拓與單值性 | L §§12.1–12.3（pp. 200–212），K §31，H §2.4、§5.2 補分支與複對數。 |
| 299 | 正規族 | W §2.4、§5.1（起 pp. 20、73），K §28。局部有界與省略值兩個 Montel 版本各自記假設。 |
| 300 | 共形映射 | W §1.3、§5.2–5.4（pp. 75–84），H 第 9 章、§10.9。 |
| 301 | 單葉函數入口 | W §7.5（pp. 103–108），L §7.1（pp. 141–144）。定位面積定理、二次係數估計及 Koebe 四分之一定理。 |
| 302 | 整函數與分解 | W §3.2–3.6（pp. 34–47），L §2.1、§2.4。定位無窮乘積、Weierstrass、Jensen、階與 Hadamard。 |
| 303 | 亞純函數與增長 | W §2.6、§3.3–3.5，L §3.2、§3.4、§3.8。定位部分分式、Poisson–Jensen、極點計數與特徵函數。 |
| 304 | 值分布的選定入口 | L §3.2–3.3（pp. 27–33），K §32.2（pp. 72–73）。第一基本定理與 Picard 小定理有正文和證明。L §3.6 提供第二基本定理與 Picard 型推論的候選位置，其深度待正式定界。 |

擬以 H 與 B 並讀基礎例題與不同證明路線，以 W 支撐進階主線，L 補解析延拓、單葉函數及值分布，K 補核正規族與 Picard。公開講義與教材的使用方式為閱讀、定位與交叉核查。V24 曲面、覆蓋理論的正式展開，以及 V23 選題深度，依後續定界確認。

## 原書目三本的正版入口

本次用三本的紙本 ISBN 分別在清大 OneSearch 查得館藏，三筆都標記為實體可借閱。以 Conway 和 Stein–Shakarchi 電子 ISBN 查清大本地館藏，皆未命中。清大提供 SpringerLink 平台，Conway 這一本的機構授權仍待確認。

| 原書目 | 已核的入口與實讀範圍 |
|---|---|
| Lars V. Ahlfors，*Complex Analysis*，McGraw-Hill，第 3 版（1979），9780070006577 | 清大紙本已核。已查書目與章節目錄。出版全文尚未取得。 [清大館藏](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990007630210206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw&search_scope=NTHU_holding&tab=LibraryCatalog) · [第 3 版詳細章目](https://kw.maruzen.co.jp/ims/itemDetail.html?isbn=0070006571) |
| John B. Conway，*Functions of One Complex Variable I*，Springer，第 2 版（1978），紙本 9780387903286，電子版 9781461263135 | 找到清大實體第 2 版。已取 Springer 前置頁 i–xiii，核對細目。章正文呈現訂閱預覽，全文待機構存取或紙本。 [清大館藏](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990007767690206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw&search_scope=NTHU_holding&tab=LibraryCatalog) · [Springer 電子版](https://doi.org/10.1007/978-1-4612-6313-5) · [官方前置頁](https://link.springer.com/content/pdf/bfm:978-1-4612-6313-5/1) · [清大電子書說明](https://www.lib.nthu.edu.tw/research/ebook.html) |
| Elias M. Stein、Rami Shakarchi，*Complex Analysis*，Princeton University Press（2003），紙本 9780691113852，電子版 9781400831159 | 清大紙本已核。已開啟出版社第 2 章節選，從章首到 §5.2 開頭，定位 Goursat、Cauchy 公式、恆等定理及 Morera。完整電子版購買後由出版社 App 閱讀。 [清大館藏](https://nthu.primo.exlibrisgroup.com/discovery/fulldisplay?docid=alma990009258840206774&context=L&vid=886UST_NTHU%3A886UST_NTHU&lang=zh-tw&search_scope=NTHU_holding&tab=LibraryCatalog) · [官方節選](https://assets.press.princeton.edu/chapters/s02_7563.pdf) · [出版社電子版](https://press.princeton.edu/books/ebook/9781400831159/complex-analysis) |

若需以三本原書做逐項對照，紙本可按以下章節先提供需要的內容。

- **Ahlfors 第 3 版**：第 2 章 §1–2、第 3 章 §2–4、第 4 章 §1–5、第 5 章 §1–3 與 §5、第 6 章 §1–2、第 8 章 §1 與 §3。
- **Conway 第 2 版**：第 III–V 章（pp. 30–127）、第 VI 章 §1–3（pp. 128–137）、第 VII 章 §1–6（pp. 142–175）、第 VIII 章 §3（pp. 204–209）、第 IX 章 §1–3（pp. 210–220）、第 XI–XII 章（pp. 279–301）。出版社的章首與印頁為本次定位依據。
- **Stein–Shakarchi 2003**：第 1–3 章、第 5 章、第 8 章，先看版權頁和目錄確定相同版次，再補出版社已公開節選以外的需要段落。

## 交使用者判定的第三方入口

下列頁面指向與出版版同名的第三方副本。未核實權利人給予公開散布許可，僅提供入口供判定。它們未納入 14 章對照的正文證據，也沒有下載或附上這些副本。

| 待判定 ID | 來源與疑點 | 判定入口 |
|---|---|---|
| Q1 | Ahlfors 第 3 版。Georgia Tech 教師課程網站掛有 McGraw-Hill 出版版 PDF，未查得出版社允許公開散布的依據。 | [Georgia Tech 頁面指向的 PDF](https://mccuan.math.gatech.edu/courses/6321/lars-ahlfors-complex-analysis-third-edition-mcgraw-hill-science_engineering_math-1979.pdf) |
| Q2 | Conway 第 2 版。第三方 GitHub 倉庫放有同 ISBN 的 Springer PDF，未查得授權依據。 | [GitHub 檔案頁](https://github.com/AsakawaUniversityofScience/AsakawaLib/blob/main/GTM/GTM%20011%20-%20ISBN978-1-4612-6313-5%20-%20John%20B.%20Conway%20-%20Functions%20of%20One%20Complex%20Variable%20I.pdf) |
| Q3 | Stein–Shakarchi 2003。McGill 課程路徑下有 Princeton 出版版 PDF，未查得出版社允許公開散布的依據。 | [McGill 課程路徑的 PDF](https://www.math.mcgill.ca/darmon/courses/25-26/complex/stein.pdf) |

## 檔案指紋與續接

| 用途 | 固定版本／檔案 | Bytes | SHA-256 |
|---|---|---:|---|
| 分卷基線 | `math-curriculum-v4-git-aligned.html` | 2167706 | `098aaacab85e330cb0493fc928916361c3fba09c0d36b3964f61c74ad2a2e1df` |
| 原書目基線 | `math-references-v4-git-aligned.html` | 3482004 | `4b3e0af09024a799744ee6fbb76ad68b95d82baeb020e5a6b8033cf00361a59d` |
| H | `howell-complex-analysis-web.pdf` | 9226873 | `7d494e3ebcecb0654ba4d7d325987aa7292b030dd461796963fc4e1e4a5102ce` |
| B | `complex.pdf`，Beck 等 1.6 | 1857395 | `941c08dca537ec96c49dbc5351648d53c1804504fc29d777eccaa035c6d4b1cd` |
| W | `complex.pdf`，Weber 2026-01-06 | 6022228 | `893da9917e484edd37d067f319d9ad930a94ed47e49065373232db7e15415050` |
| L | `pg1.pdf` | 1391998 | `032990304286b8d586661721bba6041222d5b3715d4394047890d68b096f7fc0` |
| K | `notes.pdf`，Honda | 440321 | `3eb1f4a0f2a97a9582ed55d3258178634a0c9888e8e36ab8c99585f64b9b75e9` |
| 官方節選 | Conway 前置頁，13 PDF 頁 | 1116975 | `39977896558b0a427fe78ce2fc5a52e0bd72d5bd4f87b17a674d57de1615f332` |
| 官方節選 | Stein–Shakarchi `s02_7563.pdf`，23 PDF 頁 | 2181596 | `f2b4abefa97631084ee40ef77e18523d6599441e3726aa9a94cbf4595596d25b` |
| 前卷 Git 章號證據 | [V22-B08 配對來源包、PDF 與清單](https://github.com/Euricotalavan/categorical-mathematics/tree/0c1b95031d31162eb4f2026b6e7e0d2aa6839074/archive/v22/b08-audited-2026-11-28)，實算來源包與包內 PDF 指紋一致，ZIP CRC 通過 | [Git 固定清單](https://github.com/Euricotalavan/categorical-mathematics/blob/0c1b95031d31162eb4f2026b6e7e0d2aa6839074/archive/v22/b08-audited-2026-11-28/SHA256SUMS) | ZIP `b6cc80eee2a2d57ecdf8f04b263dcaa98f1e43026eec40293e8167a245bf251c` · PDF `5b1073ce6a90116bcd6a4ae10aab05a37bbd7ab96293e48cb38fc1707eba4159` |
| 正式模板識別 | [V0 ReadFlow R1 來源包](https://github.com/Euricotalavan/categorical-mathematics/blob/8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3/archive/v0/readflow-r1-editorial-2026-11-17/V0-ReadFlow-R1-Source.zip)，專案導覽固定值，留待排版接收時實核 | 7007679 | `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732` |

**交接 V23-REF-PREFLIGHT-20261128／v1。** 本 Work 主控發出，後續由 B-01 精修角色接收。依本輪明確指定採 B 方案單一 Work。本次完成來源取得、版本與章位核對，B-01 等待書目確認。模型及推理設定未另行核實。V23 唯一正文、來源/PDF 配對、編譯紀錄、文獻擷取索引、逐項覆蓋表及章依賴尚未產生。ReadFlow R1 的編譯與局部調整留待相關階段。

| 未決項 | 對續作的影響 | 處置 |
|---|---|---|
| OPEN-01 書目使用範圍 | 使用者確認前，B-01 暫停。 | 由使用者確認公開來源組合，或指定須納入的原書。 |
| OPEN-02 Q1–Q3 授權狀態 | 對應第三方副本暫不列入證據。 | 等待使用者判定。若判定不合法，改走正版紙本或由使用者提供相應掃描。 |
| UNKNOWN-03 三本原書完整正文 | 目前無法宣稱逐項對照三本出版版。若以原書為必用來源，對應部分須先取得。 | 保留已核的正版入口、章目和試讀範圍。 |
| OPEN-04 值分布深度與跨卷依賴 | 第 304 章已有可讀來源，納入到哪個定理及證明深度仍待定界。 | B-01 核來源責任與假設，後續依已核範圍設計敘事。 |

**下一步**　取得使用者確認後，B-01 精修以同一版本回執，建立逐定義、命題、證明與必要例題的原文定位和覆蓋責任。沿用本次已核的 ISBN、頁碼與 Git 章號。交接已備，角色接收回執待 B-01 啟動。既有卷及分卷表無修改。
