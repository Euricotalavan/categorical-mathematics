# V23 B06 排版 QA — PASS

交接 ID：V23-B06-20261128-FINAL。方案 B 單一 Work；角色排版官；B06（原 A 行文排版階段）完成，B07 唯一整卷數學終審待主控釋出。本回執不代簽 B07。

## 最終固定輸入與成品

- 正式模板：已採納 V0 ReadFlow R1，artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`。來源 ZIP SHA256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。完整913檔 manifest、ZIP CRC 已在準備期驗證；每次本卷編譯再核29個固定樣式／字體／授權來源檔，全部 PASS。V0／V22 數學正文未帶入。
- B05/PASSED 實際接收後才啟動正式 B06；原 B05 lock `fa885862fc25236cba2aeffeea1266e80f567574c7607671a1e34ffd63f577fd` 留歷史。主控審核298／300／302有界精度修正及兩個末解答等價精簡後，唯一最終正文鎖為 `final-source-lock.json`，SHA256 `e2f6775fa50993d1cb21073e1f23258a745b0c3d52e0cffd2499d88e25abb349`。14章與實際編譯快照逐一一致。
- 成品：`V23-B06-ReadFlow-R1.pdf`，**262實體頁**（7頁卷首、254頁14章正文、1頁完整文獻表），SHA256 `5ab065c2e86241f7063074536efe80b12bb6054ba0f09117ec2e742d93c6ab40`。主標題 Complex Analysis；連續章291–304。
- `SOURCE-PDF-MANIFEST.json` 含54個可編輯來源／樣式／字體／授權／工具檔的路徑、bytes、SHA及配對 PDF，SHA256 `d2b31cd24c322009283609903e685cc90b3b013dab390919a4973fdfc7120c78`。

## 實際修改與讀流

採納 shared/base 與 layout/study 檔完全未改；沒有改字體、字級、行距、頁面尺寸、欄寬或以空白補頁。B02完整閱讀說明接在最後目錄頁，僅把章級無號標題改成節級無號標題，另加 About This Volume 書籤；說明正文逐字保留。B02完整8筆 bibliography 逐字保留，只添獨立書籤。第7頁已不再只有三筆目錄後浪費整頁。

`layout/v23-breaks.tex` 僅對(292.1)之後一個段落設定 widowpenalty=10000，在Definition292.4前還原正式8500；第29頁現在從完整段落開始，沒有單獨`g.`跨頁。此調整未改任何章檔。試作的 page enlargement 與 looseness 已否決，只留 QA 診斷副本，不在採用的排版檔中。

依主控明確指示，300最後 Joukowski 解答刪重複敘述、保留正反包含與極限方向；302最後解答保留可和性、兩個部分乘積、對數準則、每盤零自由指數尾與有限頭零點。精確前後副本和 diff 在 `qa/prose-cleanup/`。除此之外，本排版角色沒有修改章正文。最終300 SHA `77de5a4355357aa99704307e92752695ca7bac5fb9ccb7820864f6496c40daa0`；302 SHA `005bb6b16ff297f18ba30320fc0dfbf50769eb2fe4edc246950b62be7f4ec02e`。核准 B03 片段 SHA `5d309e73c90109e3fe843f2d4af7db7de2cee12748dfbcc29b8696a2b6e73e65` 仍為291原樣子字串。

## 工程與全頁實看證據

最終 run：`book/.build/b06-final-reader`。三輪 XeLaTeX，aux／toc／out 收斂；hard=0、overfull=0、header=0、未解析 reference/citation=0、缺字=0、重複目的地=0。8筆bibcite已解析。沒有以 hfuzz 或濾掉錯誤使檢查通過。

Poppler以90dpi完整渲染最終262頁，`qa/render-final-reader/pages/` 含每頁 PNG；**44張順序contact sheet，從第1張p1–6到第44張p259–262，全部逐張實看**，每一最終頁都在其中。`mechanical-pdf-checks.json` 的每張紀錄均標記 REVIEWED_SEQUENTIALLY_FINAL。最終另外放大 p29、137、184、215、222，確認孤行修正、新增同倫公式、兩個章末解答、曾在縮圖顯示似缺字的302.6標題；實際大圖完整。先前263頁首版也全頁檢查，且放大全部三圖、9個underfull提示附近、dense頁、文獻表與跨頁處；證據在 `qa/visual-review-v1.md`。

最終全頁機械核對：頁外文字=0、正文碰頁尾=0、隱藏白色正文=0、壞內部目的地=0。432個定義／命題等編號單元（含136習題）與TeX開始環境逐一對上，沒有遺失。135書籤包含14章、119節及閱讀說明／文獻表，章節層級和頁面有效；目錄可點。頁碼連續；封面不印頁碼，卷首使用羅馬數，正文使用阿拉伯數，符合採納樣式。

所有字體已嵌入；三張精確向量圖完整，標記／方向／圖說皆可讀，位於相應論證旁。原圖內嵌Type3字體無Unicode映射，但已實看其標記；正文數學與文字字體具映射。最終僅封面屬稀疏提示，兩張原先只有兩行的章末頁已消除。較短自然章尾未補空白。

尚有9個underfull hbox提示：涉及含公式的行間調整及長文獻URL，放大後可讀、無裁切，接受。非浮動Figure295.1的captionof令caption套件明示忽略該caption的hypcap；圖和說明同頁、就在例題內，沒有宣稱不存在的圖頂跳點；普通浮動圖目的地保留。amsmath的atopwithdelims與unicode-math相容提示屬採納套件組合，沒有未定義指令或可見缺字。

## 章長與頁數邊界

| Chapter | Physical start | Pages |
|---|---:|---:|
| 291 | 8 | 19 |
| 292 | 27 | 18 |
| 293 | 45 | 18 |
| 294 | 63 | 16 |
| 295 | 79 | 16 |
| 296 | 95 | 17 |
| 297 | 112 | 19 |
| 298 | 131 | 17 |
| 299 | 148 | 17 |
| 300 | 165 | 20 |
| 301 | 185 | 20 |
| 302 | 205 | 18 |
| 303 | 223 | 20 |
| 304 | 243 | 19 |

頁數由實際數學內容產生，約300頁是規劃參考而非湊頁目標；頁數／環境數／編譯工具完成不代替完整性或數學驗收。

## 可恢復重建與限制

由`book/`目錄執行：

```sh
python tools/build.py --full --preamble layout/v23-breaks.tex --name release-rebuild
```

輸出`.build/release-rebuild/build/entry.pdf`；同名已有run時工具保留舊證據另建新run。需要Python3、XeLaTeX/TeX Live、fontconfig及已附字體／授權。實際環境：Python3.12.14、XeTeX0.999996 (TeX Live2025/dev/Debian)、Poppler26.05.0、fontconfig2.15.0，見`qa/environment.json`。模型及推理強度未能獨立驗證，均 UNVERIFIED。

OPEN：B07尚未由本角色簽署；主控須以這一exact source lock和paired PDF執行唯一整卷數學終審／複核。跨專案16主題／22章映射及六全局門檻歷史UNKNOWN不因B06而解除。沒有外部上傳、發布或封存；本地可取不等於遠端送達。禁止重做已核模板、改B03片段、重啟凍結卷、擅改來源責任表或把本排版PASS當數學終審PASS。
