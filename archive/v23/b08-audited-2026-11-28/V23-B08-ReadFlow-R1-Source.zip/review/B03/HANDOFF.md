# V23 B-03交接｜校準通過與 B-04 放行

V23-B03-CALIBRATION-20261128-v1。B 方案單一 Work，已授權的第 291 章代表節。擴充交打厚，打厚對同節補證，精修獨立核最終差異，主控完成原人審詳略節點及最終 7 頁視檢。接受範圍只涵蓋此代表節。

| 固定檔 | 版本證據 |
|---|---|
| `real-differential.tex` | 擴充原稿，SHA-256 `c285b3680e7fd3efaacaf9418b7261397954947224e512f2e2aa86acb165f092` |
| `real-differential-thick.tex` | 唯一通過片段，SHA-256 `5d309e73c90109e3fe843f2d4af7db7de2cee12748dfbcc29b8696a2b6e73e65` |
| `ch291-calibration-reviewed.tex` | 配對樣節建置源，SHA-256 `689d5371021a9962c82a0c07b633771d80fa37ded09a6c8ee6d836421fa9d017` |
| `V23-B03-Cauchy-Riemann.pdf` | 配對 7 頁，SHA-256 `90e09603ac327f7d25a17e2cc294db89d4ad516822b7f8976481f15590b711b3` |
| `thickening.md` 與 `refinement.md` | 各角色正式回執。精修 v2 已核真正完成後的打厚片段。 |
| `build-report.json` | XeLaTeX 兩遍收斂，未見錯誤、缺引用或溢欄。 |

前卷定本 Git `0c1b95031d31162eb4f2026b6e7e0d2aa6839074` 止於章 290，本卷 291–304。B-02 設計及 B-01 索引為本階段有效基線。套用已核對的正式 V0 ReadFlow R1，Git `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，模板包 SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。採 V23 薄適配檔。編譯方式 `python tools/build.py --sample /absolute/path/B03/ch291-calibration-reviewed.tex --name calibration`，需 XeLaTeX、fontconfig 與內附授權字型。已實讀、實編、逐頁查看此固定版。模型實際模式依各角色回執，主控無部署自證。

樣節保留重點包括從增量控制建立型別，完整證兩向判準，將點值偏導與鄰域條件分開，例題包含可算的正例、只於單點可微的例，以及帶假設失效的近似反例。R1 標題、公式、定理、續頁、例題層級與頁尾俱可讀。樣節最後的較短頁會由同章後續內容自然接續。

下一唯一動作為 B-04 各章起稿，使用共通命名和先備合同。第 291 章的已採片段原樣納入。打厚與精修各自回到固定同章輸入，主控只合有完整回執的正文。現階段未產生其他正式稿章或整卷 PDF。來源未知仍留在原索引，不牽涉任何需使用者再決定的章界。B-04 四作者均收到放行。凍結卷與分卷表不得重做。
