# V23 font dependency notice

These font files are redistributed unmodified with their existing filenames
and internal names. They were recovered only from the licensed dependency
subtree of `v23-research/v22-release-source.zip`; no V22 manuscript was copied.
The adopted R1 source ZIP itself includes no fonts.

PagellaX uses the included newpx/LPPL notices; Asana and STIX use their included
OFL notices; Noto uses its included copyright/OFL notice; DejaVu uses its
included copyright/license. See `licenses/` and the file hashes in
`../provenance/template-lock.json`. No license is asserted over the manuscript.
