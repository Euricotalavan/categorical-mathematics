# Volume 16 · Measure and Real Analysis

ReadFlow R1 revised reading edition, Chapters 208–223. The chapters
keep their established order. Dense proofs have locally numbered
stages and the volume has additional solved exercises.

Open V16-ReadFlow-R1-Rerun.pdf for the reading edition.
The outline includes the new subsection entries. Run
python3 verify_release.py after unpacking to check the fixed bytes.
A clean build starts with

    python3 build.py --jobname V16-ReadFlow-R1-Rerun

It requires Python 3 and XeLaTeX with the packages loaded by
layout/study/volume-16.tex. Use --debian-unindexed on a TeX Live
installation without an indexed XeLaTeX format. The font faces are
verified from dependencies/. The SHA-256 of all 18 manuscript
and six layout inputs, plus the paired PDF, are in qa/build.json.

HANDOFF.md provides the B-01–08 record and current source limits.
The live bibliography index is coverage/body-locations.tsv.
The latest full chapter and section names are in
coverage/edition-outline.tsv. Earlier stage records document
their own frozen input hashes and page references.
