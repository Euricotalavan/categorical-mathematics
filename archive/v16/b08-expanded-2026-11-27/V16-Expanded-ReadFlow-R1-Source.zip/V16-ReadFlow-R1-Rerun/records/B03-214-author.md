# V16 B-03 author calibration, Chapter 214.2

The fixed candidate is draft-b/ch214.tex, SHA-256
caf391bfef7611d7f87d34f452af49da4e48f36cbed270457d4020243b40179e.
The only additions are within the original 214.2 and its existing
Practice section. Existing statements, labels, practice numbers and
source responsibility markers are preserved.

214.2 first gives the full notation, scope and proof of dominated
convergence, followed by the old single-envelope examples. The new
reader move tests difference quotients with a uniform-in-increment
integrable envelope. The sine integral is worked from existence
through the exact derivative and its value at zero. The cosine
example deliberately satisfies individual integrability and
pointwise quotient convergence but fails the common-bound test.
Its two one-sided quotients are computed by a justified scaling
substitution. Practice problem 9 handles a local parameter domain
and the boundary where its initial integral ceases to be finite.

Sources supporting the criterion are Axler 3.31 and Tao 1.4.49.
The constructions and worked solutions are independent teaching
examples. Formal 214.2 calibration requires the same fixed draft
to be read by independent roles. The remainder of the chapter
is held on this hash until those checks are received.
