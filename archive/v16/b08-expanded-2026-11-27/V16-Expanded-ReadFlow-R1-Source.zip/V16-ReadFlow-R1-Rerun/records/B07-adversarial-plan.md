# V16 rerun · independent B-07 reading probes

Preparation on the published 138-page baseline, not a verdict on
the rerun. The selected Git commit is
`aedc9f1322e20414f369747b086e30120f9ad56e`.
The recovered archive SHA-256 is
`9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5`.
Its CRC and all 18 extracted chapter/front/reference hashes were
verified against the archived build record. The PDF SHA-256 is
`26790fe003857f1602a37928cd9cbb59e79d10ecf083acf40414df36a58419d9`.
The curriculum fixes 208–223 and keeps Hausdorff as the geometric
measure interface. The actual final candidate and new B01/B02
responsibility decisions will govern the rerun audit.

## Highest-return overlaps to consider during drafting

| Baseline difference | Direct source landmarks and decision check |
|---|---|
| Ch. 213 proves Riemann-integrable implies measurable and integral equality. The standard oscillation criterion remains only in the source note. | Axler 3.34–3.38 and Lebl II §10.4 develop the iff criterion. If adopted, prove the measurable bad-oscillation levels via neighborhoods or nested finite partitions. Treat the countable partition endpoints and both implications. Test rational indicator, a function with countably many jumps, and Thomae's small heights. |
| Ch. 219 proves limits in measure are unique and yields a good subsequence of an already convergent sequence. It lacks the preceding Cauchy criterion on the same general measure spaces. | Folland 2.30. If adopted, use summable successive errors of a chosen subsequence to obtain a finite measurable pointwise limit. Bound the subsequence errors by (2^{1-j}) when starting at (j), then recover the full sequence with the Cauchy property. Distinguish global testing from local finite windows and say where countable exhaustions are needed. |
| Chs. 212–215 use inverse images, distributions and coordinate pullbacks, but the pushforward measure and transfer identity are not assembled. Ch. 208 scales boxes under translations, signs and uniform dilations. | Tao Exs. 1.4.38–39 and Folland 2.44/2.46. If admitted, the pushforward moves mass by inverse images, where the determinant power is the reciprocal of the image-volume multiplier. For an invertible linear map, use a full generator or elementary factors and distinguish raw Borel equality from completed-set preservation. For a singular linear map all image volume vanishes in the ambient dimension, while its pushforward measure is generally not zero. Preserve the V15 interface if a general nonlinear formula is deferred. |
| Chs. 218–220 contain simple approximation and (C_c) density/(L^1) cutoff examples but do not derive norm continuity of translation. | Tao Prop. 1.6.13, Folland Prop. 8.5. This is an in-volume bridge for finite (p), using translation isometry and compactly supported continuous approximants. State the (p=infty) obstruction and the separate need for hypotheses on the approximating functions. Convolution/Fourier results need scope and proof responsibility of their own. |
| Ch. 221 develops pointwise BV and AC, Ch. 209 Stieltjes, and Ch. 217 Radon–Nikodym, but the normalized right-continuous BV/signed-measure correspondence remains a reference comparison. | Folland 3.29–3.35 and Fremlin 226B–C. If adopted, define normalization, work with finite signed Stieltjes measures via the Jordan functions, and separate interval endpoints, jumps, AC representative and continuous singular part. Pointwise changes at a single point can alter variation. Do not give all pointwise BV functions the measure of their canonical representative silently. |
| Ch. 222 includes the nicely shrinking sets in practice; the upper-density behavior of singular measures is contextual. | Folland 3.20–3.22 and Simon Ch. 1 §§3–4. Main-body nicely-shrinking proof is a compact promotion. A general Radon differentiation theorem is a separate claim with its own regularity and covering hypotheses. If retained, a density limit for an AC part should be separable from the null Lebesgue derivative of the singular part. |
| Ch. 223 proves exact normalization in a whole Euclidean dimension. Useful adjacent distinctions are fixed-scale equality and transport to isometrically embedded flat pieces. | Simon Ch. 1 Thm. 2.6 and Fremlin 264I, 471J. The existing opposite bounds support same-dimensional outer equality at each positive cutoff, with normalization stated explicitly. A lower-dimensional embedded plane needs subspace covers and its own `d`-dimensional scaling. Rectifiability and area/coarea remain later responsibilities unless expressly bounded in. |

These are source-backed audit priorities for the new boundary. They
do not prescribe equal page budgets, a source-by-source union of
unrelated chapters, or imported theorems without their conditions.
The Royden–Fitzpatrick fourth-edition table of contents can identify
a counterpart but does not establish its wording, proof, examples,
or parity. Preserve that source limit unless a legal body is read.

## High-risk tests for the exact candidate

1. Test Carathéodory splitting on arbitrary subsets, finite total
   measure versus arbitrary outer measure, equality of a Borel
   sandwich's masses versus a null difference, and local finiteness
   versus sigma-finiteness. On completion keep a measurable null
   envelope for each necessary modification. An infinite mass cannot
   be removed by subtracting two values of infinity.
2. For extension and product uniqueness, require an actual generating
   algebra and a usable finite cover. For Stieltjes retain the
   endpoint orientation ((a,b]) with right continuity, the
   countable premeasure step, and correct exhaustion of unbounded
   intervals. For products test a null strip, an incomplete factor,
   and different iterates without absolute integrability. A Tonelli
   null-set argument cannot assume integrability beforehand.
3. Check the domain and conventions for nonnegative, signed and
   integrable functions, including (0cdotinfty), measurable
   versions and simultaneous exceptions. In RN preserve the
   distinction between existence of a density and the more general
   measure decomposition. If an (L^p) proof divides by a norm,
   test zero norm and both endpoints. In convergence tests retain
   a sequence that escapes to infinity and a sequence that moves
   through finite cells, and distinguish finite-mass, pointwise,
   almost-uniform and measure hypotheses.
4. For fine covers test noncentered closed witnesses and the
   summable tails, for BV distinguish image span from image set, and
   for AC bound all gaps with one length budget. Rademacher needs
   Tonelli for the fixed-direction bad sets, one countable family
   with the proved common linear map, and finite-net convergence
   for all small increments. A directional derivative at a point
   does not automatically define a linear derivative.
5. In the isodiametric proof, disconnected fibers test the
   inequality between fiber length and endpoint span. Check all
   scales, normalization, infinite outer mass and arbitrary cover
   members. Middle-thirds Cantor gives exact raw cost one by the
   tree count; a weaker positive probability bound suffices only
   for dimension. Any new method must preserve this distinction.

For sign-off, verify actual names, domains and claims behind the
revised responsibility rows, read every chapter sequentially and
the changed and adjacent proofs, preserve required counterexamples,
record exact open limitations, inspect relevant rendered pages,
and bind the result to hashes of the entire frozen source and
its paired PDF. Historical verdicts are comparison evidence after
the independent read, and never carry forward as the new decision.
