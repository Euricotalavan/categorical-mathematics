# V16 rerun · B-04 return for Chapters 208–211

Baseline is the 138-page source at commit aedc9f1322e20414f369747b086e30120f9ad56e with archive SHA-256 9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5. This return contains independently authored changes to those four chapters, in isolated copies.

| File | Baseline SHA-256 | Return SHA-256 | Net TeX words | New solved problems |
|---|---|---|---:|---:|
| ch208.tex | 4f9bbe7113398b269f911aa5ced604c4dc278a0983b43a31524f6ab1796b8a77 | ed60d2ecccf75c1a4f31c1301a54870d5b304c7901c6b5ca4571d7a32eb920ef | +1121 | 3 |
| ch209.tex | 9b04404591379192edb548e530324b9ffc101af2be6bd156cac9471c592d2ca5 | d95f08c0e964ec785c32c92bb64fd8f23e5751110fc6b2420d3889b877b708f2 | +1126 | 4 |
| ch210.tex | 72386156e05030871d1a3ffb46793d5b0c0050ebc06cdd4c7fa9d4f090291328 | 5e307a4b081a455a2543587ef835a71e062b3bf1d352f65b6e981b70a3369ec0 | +1027 | 3 |
| ch211.tex | 968b712d748ded3763d780bff209fbcd7eb9b7149ae885c9a4b13811286a6f53 | 7c9df53d4b7ecd26340478787abe8a998bec7366146fdd2a0b1779c7bdf99c9a | +1287 | 3 |

## Reading-path and source changes

| Chapter | Added proof work in the original order | Checked source locators and new practice |
|---|---|---|
| 208 | Pullback/generated domains, binary observation of singletons and cover subadditivity. Finite-mass splitting tests, null modifications and restriction to a splitting region. Refine finite-total-cost covers to strict small diameter with face accounting, then use separation for outer additivity. | TA §1.4.1 and Lem. 1.2.5, Thm. 1.7.3; AX 2.23–2.33 and §2A; FR 113C. Practice on integer-observation events, reconstructing splitting sets from pieces, and countable pairwise separation without a uniform gap. |
| 209 | Quantitative set limits in finite windows. Algebra of rational half-open rectangles with unbounded tails, using already constructed Lebesgue measure as the verified premeasure witness. Borel/generated envelopes of finite outer mass and localized null errors for splitting sets. Endpoint-jump and CDF recovery formulas. | AX 2.59–2.60; TA §1.7.2, Exs. 1.7.7–1.7.9 and Thm. 1.7.9; FO §§1.4–1.5. Practice on uniform intersection tests, irrational endpoint recovery, envelope uniqueness and jumps at ends of a flat interval. |
| 210 | Distinguish mass equality from null sandwich gap. Direct finite-piece proof that the completion of a sigma-finite measure is its induced Carathéodory domain, then comparison with the previous chapter’s premeasure construction. Dyadic finite unions approximate arbitrary finite-mass sets; extend locally, not globally, to infinite mass. | FR 212C–212E; FO Thm. 1.9 and §1.4 Ex. 22; AX 2.65–2.73. Practice on completion after restriction, eventual membership along fast grid approximations, and simultaneous positivity on both sides of every interval via compact sets. |
| 211 | Borel pushforwards, local-finiteness boundary, and radial versus projection computations. Prove compact-neighborhood shrinking and the second-countable hypothesis from first principles, then directly prove the full regularity comparison for locally compact Hausdorff spaces with sigma-compact open sets. Identify the exact Borel, completed and Simon outer domains in the sigma-finite case. | FR 256B–256D and 411B–411K; FO 7.5–7.8, especially printed page 217; SI 5.6–5.7. Practice on an atomless image losing local finiteness, recovery from regular open/compact data, and an outer measure that agrees on Borel values but lacks Borel envelopes. |

## Subsections and anchors

Chapter headings and all original section titles, labels, coverage comments and existing numbered theorem-type environments were verified unchanged in order. These new subsection headings were inserted into old sections without moving old formal statements:

- 208.2.1 Restricting the splitting test.
- 209.3.1 Measurable envelopes.
- 210.1.1 When the outer construction gives exactly the completion.
- 210.2.1 Approximation by dyadic cells.
- 211.2.1 Regularity when open sets are countable unions of compacts.

## Independent review points

The small-cover argument submits every interior grid face to an enlarged open box and uses a strict diameter below the separation. The envelope argument keeps finite upper masses before taking differences and never claims uniqueness over arbitrary enlarged domains. The open-set regularity generalization uses a compact exhaustion with interiors covering the space, not merely a sequence whose union is the whole space. The pushforward symbol agrees with the following chapter. The Riesz–Markov theorem remains an orientation and is not used by the regularity proof. Royden–Fitzpatrick body remains UNKNOWN in the fixed working source. No source PDFs were copied into this return.
