# V16 Chapters 220–223 design and authored return

Fixed Git aedc9f1322e20414f369747b086e30120f9ad56e and pair ZIP SHA-256
9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5.
Existing numbered statements and 16 chapter boundary retained. Authored
additions are derived independently and anchored to the following
already available source portions.

| Chapter | Source and proof choices | Worked material and practice |
| --- | --- | --- |
| 220 | Tao §§1.6.20–23; Axler 4.2–8; Folland §§3.4, 6.4; Fremlin 261B. Weak-to-strong argument truncates at the test level, then applies Tonelli; uncentered witnesses compared by containment. | Packing at one scale, weak failure at p=1, pointwise radius budget in fine families; threshold location and singularity membership, revised cutoff optimization. |
| 221 | Fremlin 224–226 and Folland §§3.5–3.6. Stieltjes construction of Ch209 and variation of Ch216 applied to right-continuous BV; no full singular/jump decomposition. | Right-continuity of variation via nearly maximizing partitions, finite-union uniqueness, slope/jump, Hölder continuous infinite variation; interval atom and L² length-budget exercises. |
| 222 | Tao §§1.6, 2.2; Axler 4.10 and 4.19–24; Fremlin 222A, 224I, 225D–E; Folland §3.4; Simon Chapter 2. B03 validates the three roles of line proof, testing and finite-net uniformity. | Moving-center averages, absolute continuity and null images, globally Lipschitz homogeneous example with nonlinear directional data, worked weak test and extension, finite maxima and one-sided density exercises. |
| 223 | Fremlin 264H–J and 471A–L, Simon Ch1 §2, Folland §§11.2–11.3. Fixed-scale normalization follows from the existing proof at any upper scale. Dimension countable stability and a product-Cantor example stay at basic interface scope. | Subspace cost equality, graph bounds, planar Cantor product via rectangle masses; exact polygonal graph length and area-versus-length exercise. |

Sections and headings split locally where the reading order needs
it. B03 received and closed by independent refinement after giving
an explicit operator norm, oblique hyperplane Tonelli argument, and
both endpoint pieces of the Lipschitz extension. Follow-up refinement
also requested the finite-union algebra in signed-measure uniqueness,
a local Tonelli layer calculation, and the exact Cantor measure domain.
These are applied in the final files.

## Last authored file hashes
10ed6ec701413a2e755d2388910e92b99dedc28fa88b3f6c13608c0707df6d84  v16-rerun/draft-d/ch220.tex
242675fbf09349fb814702b0bf181a98b6df4eb0e24a9bc93485ad407e2846c8  v16-rerun/draft-d/ch221.tex
8360ce3f807790d88c130f3af91021b2476c3c8996db8d1f99a0b82a39fcb990  v16-rerun/draft-d/ch222.tex
ec3e011b5e1582d9301526d9e7c40a7832ba08d5e7962b94665cf8c79f73bf09  v16-rerun/draft-d/ch223.tex
