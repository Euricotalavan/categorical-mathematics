# V16 rerun B-01/B-02 intake and design, Chapters 212–215

Baseline: fixed 138-page V16 Expanded ReadFlow R1, Git
aedc9f1322e20414f369747b086e30120f9ad56e and source ZIP SHA-256
9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5.
The chapter sources were read from the verified recovered archive.
All four old titles, section order, statement numbering, cross references,
and original practice numbering stay fixed. The new examples are ordinary
prose blocks or solved practice inserted within existing sections.

## B-01 source-to-teaching comparison

Reuse the 34 primary responsibilities of these four chapters from the immutable
208-212.tsv and 213-218.tsv. Existing FO-215-01 through FO-215-03 stay in place.
FO and RF retain their old scope and access constraints. No new claim of whole
book coverage.

| Chapter | Verified source band | What the earlier expansion already does | Need for the new in-place pass |
|---|---|---|---|
| 212 | Axler 2.35–2.53 and 2.88–2.95, Tao Def. 1.4.32, Fremlin 121A–121C | Rational rays, countable limit operations, real-limit locus, dyadic clipping, common completion envelope | Make the choice of a measurability proof explicit by target and by available operations. Use a moving threshold and a first-passage function to force correct ordering of countable operations. Contrast measurable modifications on full and incomplete domains. Explain why the dyadic construction acts on values rather than coordinates and reuse it for finite-valued implementations and null-representative consistency. |
| 213 | Axler 3.1–3.24 and 3.34, print 74–88 and 93–94; Tao 1.4.33–1.4.39; Folland §§2.2–2.3 | Overlapping cells, lower-sum supremum, threshold slack, extended positive and negative parts, a dense rationals comparison | Guide readers through choosing partitions, truncations and positive parts. Extract simple lower and upper estimates and expose when subtraction of even correct nonnegative integrals is invalid. Add an integral computed directly by lower/upper simple functions with quantified error and a signed worked test with honest separate part calculations. Use a Riemann/improper distinction with an integrability check rather than another dense-null modification. |
| 214 | Axler 3.11, 3.26–3.31, print 78 and 89–93; Tao 1.4.40–1.4.49; Folland 2.14, 2.18, 2.24 | Geometric infinite limit, strict Fatou, escape/concentration, binomial common envelope, tail estimates; eight existing solved problems | Organize choices by the conclusion (equality, one-sided bound, or absolute error). Give reverse Fatou with a finite dominating integral; separate a local parameter envelope from integrability of each individual integrand; work a differentiation under the integral pair and match practice. For tails, compare uniform control on a high-mass bounded region with a family whose whole tails fail the required uniformity. |
| 215 | Axler 5.1–5.35, print 117–134; Tao 1.7.11, 1.7.15–1.7.23; Fremlin 251K and 252H; Folland 2.36–2.42 | Diagonal section trap, premeasure grid, raw versus completed products, two corner kernels, separable integrand and distribution formula | Make the chain joint measurability → nonnegative or absolute test → particular section order → joint conclusion explicit. Use two distinct values of a parameter where Tonelli gives finite and infinite outcomes and why pointwise finite sections alone cannot prove absolute integrability. Add a concrete raw-completion representative calculation using equality a.e. on a product. Practice should justify the input domain and use the section estimates, rather than just evaluating another elementary double integral. |

## B-02 authoring and acceptance scale

The calibration begins with the exact final-shaped section 214.2. Establish a
bounded-neighborhood common difference-quotient envelope for a parameter
integral, and follow it with a family where all individual integrals exist
but the derivative interchange would give the wrong result. The matching
new solved exercise must establish its domain and envelope before exchanging
limits. The analytic constructions are original explanations of earlier
responsibilities. Source passages guide the allowable claims, and their
exercise wording is not transferred.

Once accepted, apply the scale to all four chapters. Use each calculation to
teach a different condition or proof move. Subsequent validation checks all
old practice items are preserved by number, new items have full solutions,
old chapter/section headings and statement labels are stable, and no material
requires a theorem before its introduction.
