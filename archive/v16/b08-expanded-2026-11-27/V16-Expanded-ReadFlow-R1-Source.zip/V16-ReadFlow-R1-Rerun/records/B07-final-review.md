# V16 rerun · independent B-07 mathematical review

*Measure and Real Analysis*, Chapters 208–223. User-authorized
B single-Work rerun. Sole independent thickening reviewer.
Audit date 2026-11-27. Exact actual model subversion and reasoning
effort were not independently observable.

## Sole final mathematical decision

**PASS on the exact final source/PDF pair below.** B-07 has no
remaining mathematical or source-placement blocker. B-08 depends
separately on the independent B-06 layout decision.

| Verified final file, relative to this work directory | Bytes | SHA-256 |
|---|---:|---|
| `compiled-navigation/V16-ReadFlow-R1-Rerun.pdf` | 820474 | 15c3c0b2b3b012234309036da5a786dd276224c5fcb53de9f323483dc3527967 |
| `compiled-navigation/V16-ReadFlow-R1-Rerun-build.json` | 3318 | 26164c3d210ce742bc6a592c864b73791c6535b4bec38d9fe168b37219fae067 |
| `final-source/coverage/body-locations.tsv` | 56208 | e62a800731cf2121624147387c3e11416dfe60c8414ef283d869cb09b97ebedd |
| `final-source/coverage/edition-outline.tsv` | 6088 | 22c8fac007bfbe9980e5b0f72be4156b257d0d7409b73cdc93634974c5151a7a |
| `final-source/coverage/FO-addendum.tsv` | 10893 | 014665daa1986367d3e6550c85be4df7eebce5e88706e6b9378ceca046aa3509 |
| `final-source/coverage/OPEN.md` | 1382 | 790d3f111893418bdd51ce1dae84fd890cf57fc0a09f5612984e97a4330523e0 |

`final-source/manuscript/` is the one final text. I verified
its 18 file hashes and all six layout-input hashes against the
build JSON, then compared every manuscript file to its mathematical
read after removing only vertical-space directives. Chs. 208, 211, 215, 218, 220 and
222 differ from the initially compiled mathematical text only by
one local space reservation apiece. The only layout-file
difference from the published baseline is the subsection bookmark
depth in the metadata file. The final PDF has 187 physical pages.
The three-pass XeTeX 0.999996 build had no blocking or overfull
diagnostics. Use the fixed `build.py` at the source root with
the source and output directories specified as in the build record.
The entry is `layout/study/volume-16.tex` and the fixed fonts
come from the adopted baseline.

I verified all 145 actual anchor lines and their current headings
for the 140 inherited responsibilities, retaining 136 core and
four contextual rows. All 117 outline positions resolve, with 16
chapters, 68 retained sections including Practice, and 33 added
subsections. The 57 printed label identities match the published
baseline. All 85 reference uses resolve. The edition has 138
problem/solution pairs, an increase of 49.

I read the relevant post-layout passages in the final PDF and
rechecked the local spacing changes. Physical pp. 23–25 and 32
contain finite envelopes, Stieltjes endpoint cases and the
sigma-finite completion comparison. Pages 67, 76 and 86–87
retain the two-way Riemann test, the quotient estimates and
the relative products/Tonelli passage. Pages 129–130 and 141–143
retain the Cauchy and strong maximal estimates. Pages 150–151,
166–167 and 181–183 retain the signed Stieltjes bridge, the
two Tonelli calls and finite-net rationale, and the exact
fixed-scale volume and separate product Cantor bounds. I visually
checked final reading page 87 and the corresponding full reading
pages 49, 150 and 172 in the first post-layout build, including
the exercises in 211 and 222. On the final build the corrected
heading and statement remain coupled on p. 87, and the examples
in 211 and 222 are still on pp. 49 and 172. Math sign-off is separate
from the full-page layout inspection.

## Independent read and baseline

The published 138-page baseline is Git commit
`aedc9f1322e20414f369747b086e30120f9ad56e`, source ZIP SHA-256
`9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5`
and PDF SHA-256
`26790fe003857f1602a37928cd9cbb59e79d10ecf083acf40414df36a58419d9`.
I matched the Git blobs and verified the archive CRC, baseline
text fingerprints and paired PDF. The frozen baseline remains
recoverable.

I prepared [adversarial source and reading probes](B07-adversarial-plan.md),
then compared all authored chapters directly with that published
baseline. I read every added or changed mathematical passage and
solution and reread the baseline statements and proof dependencies
they use. [Early read 208–211 and 220–223](B07-early-a-d.md) and
[early read 212–219](B07-early-b-c.md) give exact per-chapter hashes
and checks. Those receipts were written before reconciliation with
the joined source and historical review reports. I independently
checked the intervening changes in the integrated source, the front
matter, the substantive placement of examples and the relevant
rendered passages. The archived bibliography remains the source
edition record.

## Reading and proof evidence by chapter

| Chapter | Check on the exact mathematical content |
|---|---|
| 208 | Observation preimages commute with sigma-algebra generation. Binary readings separate the union of finite-stage domains from the countably generated domain. Disjointification proves measure subadditivity and avoids subtraction of infinite values. Null changes preserve the splitting test, and a restriction inherits it from an already splitting region. Fine grid box covers give outer additivity for positively separated pieces. |
| 209 | Finite windows control symmetric-difference errors. A rational endpoint grid gives the actual partition algebra; its measure is a restriction of the previously constructed Borel volume. Premeasure envelopes use intersected countable algebra covers, with a separate finite-mass step before subtracting a splitting-set error. The Stieltjes formulas recover all endpoint conventions and the finite target from its cumulative function. |
| 210 | The sigma-finite Carathéodory/completion identification uses disjoint finite measurable pieces, a measurable envelope and a genuinely null difference. The generated extension induces the same outer measure by comparing countable covers with measurable supersets. The dyadic approximation uses compact-inside-open geometry and a mass budget. The two-sided-positive-mass Borel example has disjoint compact witnesses in every rational window. |
| 211 | The proper map check covers arbitrary compact subsets of its target. The radius example obtains its pushforward by the mass difference of two finite concentric disks. The local compactness argument directly proves the every-open-set sigma-compact comparison, including locally finite tails of compact neighborhoods. Borel envelopes are required to recover the corresponding outer measure, as the Vitali deletion counterexample shows. |
| 212 | Target generators decide the coordinate and inverse-image tests. Countable disjoint preimages give the pushforward and agree with the earlier Borel notation. A rational margin yields the strict limit-superior rule. A measurable first-hit example controls a selected index without an uncountable choice. The grid explanation now distinguishes a strict test from unresolved exact equality; incomplete-domain null modifications have the correct trace condition. |
| 213 | Finite common refinements detect equality for ordered simple profiles. Geometric partitions compute the integral via approximating sums rather than an antiderivative. Pushforward transfer starts with indicator preimages and simple monotone limits, then extends to real integrable (f) using its two parts. The Riemann criterion handles both directions, including mesh subdivision away from a small bad-oscillation set and the countable endpoints in the necessity proof. |
| 214 | Reverse Fatou and downward convergence use one finite dominating integral, with the relevant null exceptions removed. The absolute series bound proves integrability before signed summation. Parameter examples apply domination to the difference quotients and a cusp diagnoses the failure without it. The local-plus-tail example chooses its fixed window before the convergence index. |
| 215 | Joint measurability precedes sectional computation. On each exhausted relative domain the traced generators are exactly the trace rectangles, so finite product uniqueness applies. The power-region counterexample has finite individual sections on both sides even when total area is infinite. The completed diagonal and raw null-set exercise handle measurable versions without an undefined infinity difference. Each signed Fubini example checks absolute integrability before exchanging the integrations. |
| 216 | Signed continuity follows from a real-valued countably additive series and finite subtraction. The signed difference of infinite positive masses is constructed from summable atomic differences where valid. The Hahn proof controls both limits by the deficit without assuming monotonicity of signed masses. Jordan searches and a coarser partition sigma-algebra give valid variation comparisons. |
| 217 | Absolute continuity transfers to variation by testing all measurable null pieces, and the common-base density ratio defines values only where division is legal. Radon–Nikodym construction on disjoint pieces uses finiteness of both measures and proves its integrals by nonnegative summation. Density failure and success on the same non-sigma-finite reference diagnose scope. The signed domination criterion uses only finite test masses. |
| 218 | Truncation is well-defined on measurable real classes and nonexpanding in the finite and infinity norms. Equality cases of Hölder and Minkowski track both normalized magnitude and sign and treat endpoint nonattainment separately. The Cauchy tail budget passes through Fatou or a common conull set. Interpolation and the common simple approximation use the exponents in their stated ranges. |
| 219 | The global Cauchy-in-measure subsequence construction gives a finite pointwise limit off a null set and a uniform bound off each small tail exception. The full sequence follows from the pairwise error bound. The finite-space converse for subsequences has an explicit escaping counterexample. The Fremlin 246A condition is compared with the stated height tests and has its own fixed-region example. Finite-(p) continuous cutoffs and Lusin examples check the two different senses of approximation. |
| 220 | The packing bound uses disjoint open balls and a finite volume budget. The new strong maximal estimate verifies the high-value part is integrable before applying the weak theorem, then uses nonnegative Tonelli and the correct power (p-2). The finite representative is specified before naming the (L^p) class. Off-center balls compare by a (2^d) volume ratio. The separate fine-cover argument keeps its local witness and arbitrary outer-null conclusion. |
| 221 | Moving the initial partition endpoint proves right continuity of variation. The associated finite signed Stieltjes measure is normalized on ((a,b]) and identified by an actual relative generating algebra; variation agrees with the Stieltjes measure of the cumulative variation. The slope/jump example distinguishes supremum from attainment. The Hölder tents reuse the same endpoint value at shared boundaries and have infinite total variation. |
| 222 | Moving centers use one volume factor even when the containing ball radius changes. Absolute continuity maps null sets to outer-null sets by one budget over all covered oscillations. The original monotone slow/fast argument bounds endpoint spans and retains the outer-measure comparison. The Rademacher proof uses two Tonelli applications, countably many directional exceptions, weak testing and a finite net. Its ampliations explain which limits are uniform and test a genuine incompatibility of directional data. |
| 223 | Fixed-scale subspace costs use cover intersections and remain invariant under isometry. The exact Euclidean comparison holds before the small-scale limit, with arbitrary-shape lower comparison and fine-ball plus null-remainder upper comparison. Disconnected fibers are controlled by endpoint spans through the valid inequality. The exact raw middle-third Cantor cost remains one. The product Cantor example proves a separate critical dimension by finite positive bounds, without asserting an exact product cost. |

The overlapping source comparisons are specific. Axler 3.34 and
the earlier Darboux comparison support the two-direction Riemann
criterion. Tao Ex. 1.4.38 supplies the pushforward question,
whose definition and integral transfer are now both present.
Folland 2.30 supplies the Cauchy-in-measure criterion, whose
geometric error bound was checked directly. Folland 3.29–3.35
and Fremlin 226B–C distinguish the normalized right-continuous
BV bridge from the wider pointwise decomposition. Simon Ch. 1
Thm. 2.6 supplies the fixed positive-scale normalization
comparison. The results were checked on their actual V16
conditions. The user's desired comparison is supported by
the scope and worked proof coverage, with no whole-book
equivalence claimed.

## Scope of returns and historical reconciliation

Five local clarity and domain returns were incorporated. The radius
map tests every compact in its target; Chs. 211–213 share pushforward
notation; the dyadic threshold now explicitly allows exact equality
to remain undecided at finite scales; the strong maximal discussion
uses a finite representative; and the consecutive closed tents
specify disjoint interiors. The integrated Ch. 215 trace-product
clarification compares finite relative rectangle measures and is
valid. All amended passages were reread in place.

After the independent read I checked the B-04 and B-05 receipts
and the past defect history. The finite-box Borel product
algebra, both Tonelli null transports, the local integrability
definition, the exact Radon sandwich, and the corrected
isodiametric fiber inequality remain valid. The numbered
statements keep their mathematical conditions. The previous
weak ((1,1)) truncation exercise was strengthened in the same
chapter and its former argument remains in the strong estimate.
The supplementary Folland rows retain their source locators.
The integrated Cauchy-in-measure and (C_c) additions carry the
applicable extra source markers.

At initial B-06 the 187-page, 820,212-byte compiled pair
verified against all 18 text and six layout inputs. Its PDF
SHA-256 was
`ec7427e747609681a873e9673f7e4f3e04da5022b2e5cd01976bc33f625149b1`
and its build-record SHA-256 was
`f681f6aa16dca24599666dea4ef789139d0139734b576ead8decd21e2093a1c3`.
Rendered mathematical checks included physical pp. 23–25
(extension and Stieltjes), 32 and 40 (completion and Radon),
52 and 67 (pushforward and Riemann criterion), 76 (dominated
quotients), 86–87 (product), 108 and 117 (density and norm
equality), 129–130 (Cauchy in measure), 141–143 (maximal
estimates), 150–151 (BV Stieltjes), 166–167 (Rademacher),
and 181–183 (normalization and Cantor comparison).
The separately verified final post-layout pair is identified above.

## Remaining scope and limitations

- Royden–Fitzpatrick is the identified five-page fourth-edition
  cover and contents fragment. Its mathematical body and exact
  printing remain UNKNOWN. Source-comparability judgments are
  restricted accordingly.
- The published predecessor V15 on the selected Git tree
  covers 195–207, and the V17 index begins at 224. Precise
  cross-volume theorem anchors were not added. V16 supplies
  the local basis of every operative mathematical claim.
- Full Riesz–Markov representation, (L^p) duality, advanced
  covering variants, full pointwise BV decomposition, and
  later geometric measure theory retain the authorized scope.
  The four inherited contextual IDs remain contextual.
- The adopted ReadFlow R1 artifact commit is
  `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, adoption commit
  `c749e4867538888d3069346fa055ac2ca834c9e1`, archive 7,007,679
  bytes, Library version 3, SHA-256
  `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`.
  Full layout acceptance, device limits and visible page QA belong
  to the independent B-06 record.

## Handoff

**V16-RERUN-B07-20261127-v1**, 2026-11-27 UTC. Sender is the
sole independent B-07 thickening reviewer. Recipient is the
V16 controller for the already authorized B-08, after B-06
layout acceptance. B-07 maps to original A10–12. The fixed source,
PDF and coverage table are identified by the verified digests
above. This reviewer performed no manuscript edit, archive or
publication. Preserve the 138-page original, the exact accepted
187-page pair, review and source records and the OPEN entries.
Keep existing frozen volumes unchanged. The next stage should
verify recoverability and visibility within authorized scope.
No user decision is pending. This handoff and the sole verdict
are supplied in the shared workspace and delivered to the
controller in the agent message.
