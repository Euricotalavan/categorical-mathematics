# V16 rerun B-04 author handoff for Chapters 212–215

Input: verified 138-page expanded ReadFlow R1, Git
aedc9f1322e20414f369747b086e30120f9ad56e, ZIP SHA-256
9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5.
Workflow: B single Work. The author outputs are the four numbered chapter
files in this directory. ch214-calibration.tex is the exact accepted B-03
snapshot and is not a manuscript input.

## Changes by existing teaching section

| Chapter and section | New material | Practice added |
|---|---|---|
| 212.1 | Choose generators based on target. Prove the coordinate criterion, test a closed ellipse by pullback and generalize the Borel pushforward convention to measurable maps. | 6 uses the coordinate criterion for an inverse image involving a product. |
| 212.2 | A rational strict margin makes the limsup test valid. A first-passage construction proves measurability when selecting a value at a point-dependent finite index. | 7 computes finite and extended convergence loci separately. |
| 212.3 | Common approximant levels handle arithmetic and threshold tests. A trace condition on an exceptional set permits measurable modification on incomplete spaces. | 8 identifies the carry in dyadic addition. 9 combines a sequence of original-domain representatives. |
| 213.1 | A common partition gives the integral gap criterion; a counterexample has equal infinite integrals with a nonzero gap. | 9 revisits simple upper estimates after the nonnegative construction. |
| 213.2 | A geometric partition computes the reciprocal integral and quantifies the lower/upper gap. The nonnegative pushforward formula follows from indicators and the simple-limit lemma. | 9 proves the majorant infimum on a finite-measure space. 10 applies pushforward without a density formula. |
| 213.3 | The signed formula follows from the two positive-part formulas. A pointwise difference can have finite integral even when both original nonnegative integrals are infinite. | Retained the existing signed exercises and supplemented their technique in the body. |
| 213.4 | Full proof of the bounded Riemann integrability criterion, with an explicit compact mesh argument. Domain exhaustion proved directly from simple minorants compares proper, improper and Lebesgue integrals before general MCT. | 11 identifies the exact boundary criterion for an indicator. |
| 214.1 | Choose equality or a one-sided bound. Reverse Fatou under an integrable envelope and the finite starting integral for decreasing convergence. | 10 checks decreasing-limit failure on a finite-measure space. |
| 214.2 | An absolutely summable sequence supplies one shared envelope for signed partial sums. The accepted calibration contrasts valid parameter differentiation with a failed interchange computed from both sides, despite every individual integral being finite. | 9 verifies the local parameter domain. 11 bounds signed partial sums when the sum of absolute term integrals diverges. |
| 214.3 | A quantitative split controls local uniform error and the tail separately. The earlier translating bump identifies the failed uniform bound. | 12 assembles local integral convergence and uniform tails into global convergence. |
| 215.1 | Coordinate pullbacks establish the joint domain first, then a slanted band supplies concrete section lengths. | 8 applies the raw domain criterion when the second factor is counting measure. |
| 215.2 | Counting sections gives a formula beyond finite unions of rectangles. The finite-cell proof later makes the trace domain and rectangle uniqueness explicit. | 8 contrasts geometrically summable and harmonic section masses. |
| 215.3 | Separate nonnegative and signed paths. Choose the easier order for the absolute test. A parameterized example has finite individual sections at every coordinate despite divergent joint mass below its threshold. | 9 verifies joint absolute integrability before a signed infinite-domain exchange. |
| 215.4 | A completed-product function taking infinity on an arbitrary diagonal subset retains the integral of its raw representative. | 10 proves joint and a.e. sectional invariance under modifications inside a raw product-null set. |
| 215.5 | One-variable substitution changes the domain to a triangle before Tonelli changes the order. | 11 derives the sectional weight for a generic \(u(x+y)\) on the square and evaluates a moment. |

## Navigation and evidence

Old section titles and numbers are stable. New subsections are:

- 214.2.1 The theorem and its proof
- 214.2.2 Building and testing a common bound
- 214.2.3 Parameter-dependent integrals
- 215.3.1 From rectangles to nonnegative integrands
- 215.3.2 Absolute integrability and signed functions
- 215.3.3 Choosing which integral to compute first
- 215.4.1 Sections after completion
- 215.4.2 The Euclidean product

Predecessor coverage contains 34 primary rows for 212–215, with
FO-215 supplementary rows retained. Axler 3.34 (print 93–94, physical
108–109) is the full Riemann criterion locator. Tao Ex. 1.4.38
(author PDF physical 119) supports the pushforward and integral formula.
Remaining verified exact bands and edition scope are in B02.md. The
calculations, examples and full solved exercises are independent
expositions of the indexed ideas.

The common-null convention is stated at the first use of conull in
214. The terse trace argument in 215 now explicitly compares measures
on the same domain. Neither repair changes a statement or assumption.
Independent refinement read the four chapter additions and its focused
requests were incorporated. Whole-volume reflow, final source pairing
and independent final mathematical sign-off are distinct downstream
checks.

| File | Input words | Output words | Old to new solved problems | Input SHA-256 | Output SHA-256 |
|---|---:|---:|---:|---|---|
| ch212.tex | 2336 | 3460 | 5 to 9 | 22b399984978f8f4d5dd17e6c3e05b8cb7c5feee27e4ac16a83a73ffea52f473 | 5921e03711cdf99a4569cf1be4b34e8e1aa843a582478718fadcf749851e354b |
| ch213.tex | 2280 | 3389 | 8 to 11 | fa430623bf0307cd82ad7ee6656530c85d47387993dc90b810c2b6f122ac0b0a | 8a54a5d39a3c6bb8be049b078506489504f1c943acbcd2a271d35e0a6805a88a |
| ch214.tex | 1833 | 2957 | 8 to 12 | af8e211dcac96ccc7af4b7474396083de8ee9162465d939c66216018ba3358ed | b381578c2a28516831016ed69cdd62140c5fa97a3dda55981d33ceec6f4d7f52 |
| ch215.tex | 2900 | 4004 | 7 to 11 | 9a605b37e5b35e1a4e5f030a17f6cac6b64050e9e399360e575d7778bc632b32 | c893afb2d07c8f081b24d928f232b19e3cc50a380fbebe622ebbbdd06bb44709 |

The four chapters add 15 new problems with complete solutions and
4,461 whitespace-delimited words before final ReadFlow layout. The
original numbered statement counters, headings, responsibility marker
order and exact earlier problem/solution text are preserved.

An author smoke build used the four output digests above and the
unchanged baseline for the other chapters. The PDF has 152 pages
through three XeTeX passes, with zero blocking diagnostics and zero
overfull boxes. Its SHA-256 is
`a06dd582dd4f1eace27cbcbe20f9f9dfe57323572c5f7dc2628a5925dcc3a74d`.

The coordinating editor subsequently clarified the threshold-grid
example in ch212. Equality at a non-dyadic value can leave the bounds
on opposite sides at every finite level. That superseding draft has
SHA-256 `95249d383dc2f56d6a85106a328e3e713abc7aded7c725dc044b8cc0316b2162`
and will be paired with the integrated build.
