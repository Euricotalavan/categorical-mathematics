# V16 rerun B-01 and B-02 · Chapters 216–219

The audited 138-page input is fixed at Git
aedc9f1322e20414f369747b086e30120f9ad56e and ZIP SHA-256
9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5.
The original chapter and source rows are read from the fixed manuscript
and coverage. Sections below preserve the approved mathematics boundary.
New source-specific responsibilities use narrower evidence than an
entire author chapter.

| Section | Gaps relative to actual baseline and intended work | Responsibility and source |
|---|---|---|
| 216.1 Finite signed measures | Retain conditional-series counterexample and geometric example. Explain why finite truncations of two infinite positive measures do not authorize an extended subtraction. Use concrete singleton data with both a feasible finite cancellation and a genuine obstruction. | 216-01, 216-02, FO-216-01. Axler 9.1–9.7; Folland §3.1 print 85–86. |
| 216.2 Hahn's decomposition | Replace compressed supremum-union argument by quantitative finite-union and tail stages. Explain choice of budget and show why a simple whole-set sign or finite numerical test does not certify every subset. Explain restriction of a Hahn partition as a sign-space inheritance step. | 216-04, 216-05. Axler 9.23–9.24 PDF 282–283; Fremlin 231E, Ch. 23 PDF 2–3. |
| 216.3 Jordan parts and variation | Retain common-addition example. Derive sup/inf formulas on every subset and use finer/coarser measurable information to compute loss of variation. Include triangle estimate and a solved case of disjoint carriers. | 216-03, 216-06–08. Axler 9.8–9.11, 9.28–9.30; Folland 3.3–3.4. |
| 217.1 Absolute continuity | Turn null preservation into a usable proof on variation, and extract a quantitative cutoff from an unbounded, explicitly summable density without duplicating inverse-root example. Add transitivity exercise using both quantitative cutoffs. | 217-01–02. Axler 9.32–9.34; Fremlin 232A–232B. |
| 217.2 Existence and uniqueness | Unpack the finite common pieces and the no-subtraction patch for positive sigma-finite targets. Contrast a representable target for non-sigma-finite counting measure with the existing counterexample, and solve ratios when both totals are infinite. | 217-03–05, 217-07. Fremlin 232E–232H; Axler 9.36 PDF 287–289; FO-217-01. |
| 217.3 Decomposition and integrating a density | Distinguish decomposition and density hypotheses. Compute the ratio between two positive weights with a common base and detect failure on zero-weight regions. Derive an operational test for domination by a constant times the reference. | 217-06, 217-08, FO-217-01. Axler 9.35, Folland §3.2 Prop. 3.9, Cor. 3.10. |
| 218.1 Representatives and classes | Expose representative independence and truncation as a map on classes. Verify contraction and convergence, handling endpoint essential size separately. | 218-01–02, FO-218-01. Axler 7.1–7.4 and 7.15–7.18; Folland §6.1. |
| 218.2 Hölder and Minkowski | Expand normalization bookkeeping and derive the equality criterion. Contrast existing interior attainment with an endpoint supremum approached but unattained. Solve an equality/sign exercise for Minkowski. | 218-03–05. Axler 7.6–7.14 PDF 211–215; Folland 6.2, 6.5–6.6. |
| 218.3 Completeness | Separate pointwise summability, Cauchy property, measurable exceptional set and computable norm error from a known Cauchy cutoff. Add whole-sequence conull behavior at the infinity endpoint and a concrete a.e.-versus-fixed-representative issue. | 218-06. Axler 7.20–7.24, Fremlin 242F, 243E, 244G. |
| 218.4 Approximation and comparisons | Reuse the existing truncation mesh rather than add its clone. Show one sequence of finite-support simple functions works in two finite exponents and derive the intermediate-exponent estimate by Hölder. Include finite versus infinite-space tests. | 218-07–08. Axler 7.10–7.11, Fremlin 244H. |
| 219.1 What happens to the error sets? | Prove the referenced Cauchy-in-measure criterion, with a.e. subsequence using summable jump sets and a global threshold argument. Show a.e. subsequences alone need finite total measure to recover global measure convergence. | FO-219-01. Folland §2.4 Props. 2.29–2.33 print 61–63; TA 1.5.6 and 1.5.9; FR 245A. |
| 219.2 When convergence in measure controls integrals | Derive uniform small-set integrals from high tails, and compare small height control to actual tight mass outside finite-measure regions. Explain why the medium-height example satisfies one criterion and fails the other. | 219-09–10. TA 1.5.11–1.5.13 PDF 142–145; Fremlin 246A PDF 56. |
| 219.3 Approximation by continuous functions | Map budget choices and the exceptional set in Luzin to an explicit jump-ramp calculation. Extend the previously proved cutoff construction to \(L^p\) on \(\mathbb R^d\) for finite \(p\), with an integrable-simple reduction and a bounded test solution. | 219-11, FO-219-02. Axler 2.85, 2.91–2.93 PDF 78, 81–83; Folland §7.2 Props. 7.9–7.10 print 217–218 (Radon terminology checked separately). |

Each original teaching section gets at least one additional solved
practice problem appended after the already-numbered items. Use
unnumbered worked headings to keep theorem counters fixed. Folland's
more general signed convention, complex polar decomposition and
function-space duality stay contextual. Any historical RF file
remains metadata-only. A scoped exercise can reference an earlier
proved chapter result and should not introduce an unplanned analytical
dependency.
