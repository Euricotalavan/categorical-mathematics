# V16 rerun · B-04 draft return · Chapters 216–219

Input is the 138-page audited Expanded ReadFlow R1 release at
Git aedc9f1322e20414f369747b086e30120f9ad56e and source ZIP
SHA-256 9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5.
The fixed book-level design retains Chapters 208–223. This return covers
only Chapters 216–219. Baseline archives, layout and authoritative copies
were read only. Exact model and reasoning strength were not independently
verified. The four drafts are ready for the book's independent role checks
and canonical merge.

## Reader work by original teaching section

| Section | Main addition | New solved problem | Locators |
|---|---|---|---|
| 216.1 Finite signed measures | Expands the disjoint-increment continuity argument and explores differences of two positive measures with infinite totals. Contrasts telescoping singleton differences with harmonic differences to delimit when a finite signed extension exists. | Determine the finite extension of counting measure differences with singleton weights \(n^{-2}\), and give a tail bound. | AX 9.1–9.7, PDF 271–274. FO §3.1, printed pp. 85–88, for the one-infinite-sign comparison. |
| 216.2 Hahn's decomposition of the space | Uses finite union indices, explicit summable deficit estimates, and two oriented continuity limits to obtain a true maximizer. Writes the all-subset sign checks and their transfer to restrictions. | Reject a four-atom partition despite the correct signs on its whole cells. Compute the maximal set and exact deficit. | AX 9.23–9.24, PDF 282–283. FR 231E, Ch. 23 PDF 2–3. |
| 216.3 Jordan parts and variation | Recovers both parts by sup and inf on measurable subsets. Computes how variation drops on a coarser sigma-algebra and shows which restrictions commute with taking Jordan parts. | Derive subadditivity of variation and equality for disjoint signed carriers. | AX 9.8–9.11, 9.28–9.30, PDF 274–278, 283–284. FO §3.1, printed pp. 86–88. |
| 217.1 Absolute continuity | Gives the full variation-null test on every partition. Builds a uniform reference-mass tolerance from a disjoint density with explicit high tails at the levels \(2^n\). | Compose two quantitative absolute-continuity cutoffs in the correct order. | AX 9.32–9.34, PDF 285. FR 232A–232B, Ch. 23 PDF 6–8. |
| 217.2 Existence and uniqueness | Separates finite signed targets and positive sigma-finite targets. Proves common exhaustion, measurable disjoint patching, infinite-safe summation, and piecewise uniqueness. Shows a target that has a density for the same non-sigma-finite reference as the known counterexample. | Compute both derivatives when singleton masses are \(n\) and \(1/n\), and explain why both full integrals are infinite even with finite density values. | FR 232E–232H, Ch. 23 PDF 9–10. AX 9.36, PDF 287–289. FO §3.2, printed pp. 90–91. |
| 217.3 Decomposition and integrating a density | Compares two weights on a shared base by checking the vanishing denominator region. Gives an exact worked positive ratio and a signed-density test for a uniform domination constant. | Determine and attain the least domination constant for a sine density. | FO Prop. 3.9, Cor. 3.10, printed pp. 90–91. AX 9.35–9.36, PDF 286–289. |
| 218.1 Representatives and classes | Proves clipping gives a well-defined contraction on the classes, converges for finite exponent and preserves the class above the essential bound at infinity. | Compute the exact error when capping \(x^{-1/4}\) in \(L^2\) and compare with deleting its high part. | AX 7.1–7.4, 7.15–7.18, PDF 209–210, 217–218, plus the existing truncation construction. FO §6.1, printed pp. 181–184. |
| 218.2 Hölder and Minkowski | Recovers the exact normalized equality condition from zero Young slack. Separates absolute from signed product integrals and works an optimal bound at the endpoint that is approached but never attained. | Derive the real Minkowski equality characterization for two nonzero classes at finite interior exponents. | AX 7.6–7.14, PDF 211–215. FO §6.1, printed pp. 181–184. |
| 218.3 Completeness | Uses Fatou on an a.e. subsequence to read the actual error of any element in a Cauchy tail. Explains a common conull domain for all infinity-norm tail estimates and computes one representative-dependent divergence. | Convert the pairwise bound \(1/n+1/m\) into the limit bound \(1/n\) including at infinity. | AX 7.20–7.24, PDF 219–220; FR 242F, 243E, 244G, Ch. 24 PDF 12, 22, 31–32. |
| 218.4 Approximation and comparisons | Reuses the same finite-support rounding construction in both integral exponents. Derives the intermediate norm estimate by selecting the exact Hölder exponents and gives a quantitative example without a finite-total-mass premise. | Use a bounded infinity norm and an \(L^p\) limit to obtain an intermediate norm limit, and isolate the endpoint failure. | AX 7.10–7.11, PDF 212–213; FR 244H, Ch. 24 PDF 32. Interpolation here is a direct application of the already-proved Hölder inequality. |
| 219.1 What happens to the error sets? | Gives the Cauchy-in-measure criterion in full. Makes its threshold budgets, common subsequence and full-sequence limit explicit. Writes the exact every-subsequence quantifier for the finite total measure comparison. | Test a receding half-line indicator for local convergence and global failure of Cauchy in measure. | FO Thm. 2.30 and Cor. 2.32, printed pp. 61–62, PDF 74–75; TA Ex. 1.5.6 and Egorov 1.5.9. |
| 219.2 When convergence in measure controls integrals | Derives uniform small-set integrals from high tails alone. States the Fremlin condition in its actual capped integrand form, quantitatively derives Tao's three tests, and isolates failure of a common region for moving unit masses. | Derive a common finite-mass region and cap directly from \(L^1\) convergence and finite-support simple approximations. | TA Def. 1.5.11 and Thm. 1.5.13, PDF 142–145. FR 246A, Ch. 24 PDF 56. |
| 219.3 Approximation by continuous functions | Extends Euclidean compactly supported norm approximation to all finite \(p\) and distinguishes exact Lusin agreement from integral control with an explicit one-jump ramp. | Reconstruct a two-jump continuous ramp on the complement of two small gaps and compute its exact integral error. | AX 2.91–2.93, PDF 81–83. FO §7.2 Props. 7.9–7.10, printed pp. 217–218, as general Radon comparison. |

Proofs are in original prose and computations use original data unless
the exercise explicitly reuses an existing example to compare a second
operation. No previous theorem statement was withdrawn. The expanded
source obligation FO-219-01 now has a marked full Cauchy-in-measure
landing. FO-219-02 remains a comparison source. Its Euclidean \(L^p\)
density instance is proved here, and there is no claim of a proof for
arbitrary Radon spaces. No restricted primary RF text was assumed.

## Section structure and checks

- 216 adds “Measuring the deficit” and “Variation under restriction.”
- 217 adds “Finite signed targets,” “Patching positive densities on
  finite pieces,” and “Comparing weights.”
- 218 adds “Reading equality in the estimates,” “Using a bound on the
  Cauchy tail,” and “Approximating in more than one norm.”
- 219 adds “Testing without a proposed limit,” “Small sets and mass
  outside a fixed region,” “Approximation in norm,” and “Exact agreement
  outside a small set.”

All original chapter and section headings, labels, ordering, Needspace
guards, and primary source markers were checked. New numbered subsections
are inside existing sections. There are 13 new problem environments and
13 matching solutions appended in their original Practice sections.
Added proof and worked exposition uses prose or unnumbered paragraphs,
so the old theorem numbers are preserved.

Independent review feedback on common finite representatives before
division, \(n\ge1\) in the singleton ratios, the finite-\(p\) endpoint
conditions, the conull uniform reading, and the finite-total-measure
quantifier are incorporated. For canonical sign-off recheck those scopes
on the fixed files, verify the FO-219-01 location remap and then run
whole-book cross-reference and visual review. The author draft itself
does not record final PDF approval.

An isolated three-pass XeTeX build used these four drafts alongside the
other twelve unchanged baseline chapters. It produced 149 physical pages,
up from the baseline 138, with zero blocking and zero overfull diagnostics.
The temporary proof PDF SHA-256 was
`365f4b07fc305833f360f99da0b2e5fd14345f06084f9cb5acdc722cfd712f23`.

## Fingerprints

| File | Baseline bytes | Baseline SHA-256 | Draft bytes | Draft SHA-256 | Whitespace-word delta |
|---|---:|---|---:|---|---:|
| ch216.tex | 13893 | dd6d04f16acf7c65a2d366dec4af727e18bdc26f605c06426d54a415061c9cc3 | 20728 | 1775f7c41e58b9a331c0eb3036ff5cfbf55969825ac203be5b7f41c5dbe758b1 | 967 |
| ch217.tex | 17116 | d94abca7bd0de296246470b5376b1b81a00a2c3b3f267b16dd08fbde8eaf01a5 | 24174 | d75bcbe16869c770865c4d4e6552cebd5d57b50ea401a588414e001bbf11c56b | 946 |
| ch218.tex | 15730 | a2c170216b05f560c27ede71bee74752a3e2f8bba2a2984a16ea40ef85170e0e | 23856 | a9aa3559eb126d7f96dffd67e0c7d3df3a19e966791f417ca74db372e35efa63 | 1086 |
| ch219.tex | 19292 | 259f68ad406358d25e9d13bd4216e0b5b38aa6f2a50650673f87cd62ee2726c5 | 28141 | fd6090dcf2ba8ca42010500f98c3b700a213459b2b306148341040c4cf3e8382 | 1260 |
