# Chapter continuity

Current published tree d9d72a253a9406a42410fa97ea98b6f64d623001
contains the V15, V16 and V17 editions. Its root index gives
V15 195–207, V16 208–223 and V17 224–231. The stored 138-page
V16 pair remains at aedc9f1322e20414f369747b086e30120f9ad56e.

The published 209-page V15 PDF at that earlier commit was opened.
Its top-level outline ends at 207 Differentiation in Banach Spaces.
Other verified V15 topics used as background are 195 Euclidean
Spaces and Norms, 196 Linear Approximation and Differentiation,
201 Multiple Riemann Integration and 202 Jordan Volume and Null
Sets. V16 constructs its own measures and integrals; no new
cross-volume theorem-number dependency was introduced.
