# V16 layout preparation receipt

**V16-READFLOW-PREFLIGHT-v1 · 2026-11-27, Asia/Taipei · B single-Work variant**

Layout agent → V16 controller. V16 *Measure and Real Analysis* uses Chapters
208–223 from the user’s V15 end chapter 207 and the declared 16-chapter
scope. The controller authorized coordination through B-08. This receipt
covers the reproducible preflight; the formal editorial input is the later
B-05 whole-volume source and coverage/defect records. Model variant and
reasoning setting could not be independently verified in this task.

## Read-in and verification

- Official V0 ReadFlow R1: Git artifact
  `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, adoption
  `c749e4867538888d3069346fa055ac2ca834c9e1`, Library v3, 7,007,679
  bytes, SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`.
  Pinned library bytes were recovered. ZIP CRC and original source verification
  checked 913 release files and 668 frozen mathematical assets without failure.
- Copied `config.tex` and `readflow-layout.tex` without changing their bytes.
  `readflow-fontpaths.patch` records the single local shared-base change,
  which directs the exact font families to the bundled dependencies. The
  four PagellaX faces are generated at build time from the whole pinned
  CTAN newpx archive. The five other files and all license notices accompany
  the source. The dependency set comes from the earlier checked V13 public
  release, whose recovered ZIP has SHA-256
  `289ad78c6acf86aa380ec60b8f7255d4e1c825883c4b8976686ac5044a8d4cbf`.
  Every font SHA-256 and the newpx ZIP CRC are checked before compilation.
- Project layout authority: A–B v4 Part III, B single-Work variant,
  project Git QA v3, and the ReadFlow operating draft and manifest
  as methodology evidence. Fixed research references retrieved from Git:
  SUCCESS-ANALYSIS, REUSE-GUIDE, HANDOFF-SUCCESS at
  `dde82ab6b14859774b7f26283bf15b6f2000847e`; METHODOLOGY-v1 and
  EDITOR-QA-v1 at `f4969cc5336bf761d5f80ff616531f85b357a475`.
- `layout/study/volume-16.tex` is the sole entry. It sets chapter counter
  207 before loading files `ch208.tex` through `ch223.tex`.
  `v16-metadata.tex` supplies title, headers, chapter number width and
  the exercise alias. ReadFlow page geometry and leading remain inherited.
- Preflight is built using isolated technical inputs, not any textbook pages.
  Runtime XeTeX 0.999996 and PyMuPDF 1.26.6, with a local format initialized by
  `--debian-unindexed`. The regular build uses the same entry when the
  installed TeX already has the xelatex format.

## Handoff

Run `python3 build.py --chapter-dir <fixed-manuscript> --outdir <output>`,
adding `--debian-unindexed` in current Work. The build records the fixed
chapter/layout digests and generated PDF digest. Then run `check_pdf.py`,
followed by full-page rendered inspection and full continuous reading that
has to use the actual B-05 content. Defects must be recorded by kind and
affected scope. Whole-volume semantic acceptance is the later B-07 reviewer’s
responsibility. Readability on Windows, paper, and assistive technology remains
unverified. No downstream publication decision follows from this preflight.

The next action is to receive, hash and verify fixed B-05 inputs at the B-06
gate. The original template archive, any reference books and earlier volumes
remain external to the book package.

## Isolated preflight verification

- Clean technical build converged in 3 passes. PDF 93,509 bytes, SHA-256
  `7c819e22031f7c3e0b3482643a68013468cc2671c011932c5f8e86cb43f9e1d3`.
  19 physical pages, 16 chapter bookmark targets, 32 total bookmarks, 48
  internal links, 64 numbered environment hits reconciled with fixture
  source, and eight embedded fonts used by the fixture, including Asana and
  STIX Two Math. Final log has no underfull or blocking diagnostics.
- All 19 fixture pages were rendered and visually checked. Initial ToC
  chapter numbers touched the titles. The local metadata now reserves
  2.25 em for chapter numbers; it and the title page adaptation were
  re-rendered and checked. No adopted layout geometry was changed.
- Deliberate fault fixture: final build check detected undefined reference
  and an overfull box, and PDF check detected white text on physical page 4.
  Its output and the smoke inputs remain outside the volume source.
