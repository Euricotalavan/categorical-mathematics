#!/usr/bin/env python3
"""Compile and verify the fixed 208–223 XeLaTeX entry."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

import prepare_fonts

ROOT = Path(__file__).resolve().parent
STUDY = ROOT / 'layout/study'
CHAPTERS = range(208, 224)
OPTIONAL_INPUTS = ('notation.tex', 'frontmatter.tex', 'bibliography.tex')
BLOCKING_LOG = re.compile(
    r'Missing character:|Undefined control sequence|undefined references|'
    r'Reference .* undefined|Citation .* undefined|multiply-defined|'
    r'destination with the same identifier|Overfull \\[hv]box|'
    r'fancyhdr Warning|Font shape .* undefined|Token not allowed in a PDF string',
    re.IGNORECASE,
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require_chapter_inputs(chapter_dir):
    inputs = [chapter_dir / f'ch{i}.tex' for i in CHAPTERS]
    missing = [p.name for p in inputs if not p.is_file()]
    if missing:
        raise SystemExit('Missing chapter inputs: ' + ', '.join(missing))
    for path in inputs:
        source = path.read_text(encoding='utf-8')
        body = '\n'.join(line.split('%', 1)[0] for line in source.splitlines())
        if len(re.findall(r'\\chapter\s*(?:\[[^\]]*\])?\s*\{', body)) != 1:
            raise SystemExit('Expected one numbered chapter in ' + str(path))
        if re.search(r'\\(?:setcounter|addtocounter)\s*\{chapter\}', body):
            raise SystemExit('Unexpected chapter-counter command in ' + str(path))
    return inputs + [chapter_dir / n for n in OPTIONAL_INPUTS if (chapter_dir / n).is_file()]


def command_output(cmd, cwd, env, path):
    result = subprocess.run(cmd, cwd=cwd, env=env, text=True, capture_output=True)
    path.write_text(result.stdout + result.stderr, encoding='utf-8')
    if result.returncode:
        raise SystemExit((result.stdout + result.stderr)[-5500:])
    return result


def setup_unindexed_format(outdir, env):
    env['TEXMF'] = '{/usr/share/texlive/texmf-dist,/usr/share/texmf}'
    formats = outdir / 'formats'
    formats.mkdir(exist_ok=True)
    env['TEXFORMATS'] = str(formats) + os.pathsep
    env['TEXMFVAR'] = str(outdir / 'texmf-var')
    command_output(
        ['xetex', '-ini', '-etex', '-jobname=xelatex', '-interaction=nonstopmode',
         '-output-directory=' + str(formats), '*xelatex.ini'],
        STUDY, env, outdir / 'format-initialization.txt',
    )


def compile_book(chapter_dir, outdir, stem, unindexed=False, allow_overfull=False):
    inputs = require_chapter_inputs(chapter_dir)
    chapter_hashes = {p.name: sha(p) for p in inputs}
    prepare_fonts.main()
    env = os.environ.copy()
    env['TEXINPUTS'] = str(chapter_dir) + os.pathsep
    env['SOURCE_DATE_EPOCH'] = '1795737600'
    env['FORCE_SOURCE_DATE'] = '1'
    outdir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='fresh-', dir=outdir) as fresh:
        scratch = Path(fresh)
        if unindexed:
            setup_unindexed_format(scratch, env)
        previous = None
        for passes in range(1, 7):
            command_output(
                ['xelatex', '-no-shell-escape', '-interaction=nonstopmode', '-halt-on-error',
                 '-file-line-error', '-recorder', '-output-directory=' + str(scratch),
                 '-jobname=' + stem, 'volume-16.tex'],
                STUDY, env, outdir / f'{stem}-pass-{passes}.txt',
            )
            state = tuple(sha(scratch / f'{stem}.{ext}') for ext in ('aux', 'toc', 'out')
                          if (scratch / f'{stem}.{ext}').is_file())
            if passes >= 2 and state == previous:
                break
            previous = state
        else:
            raise SystemExit('LaTeX auxiliary files did not converge after six passes.')
        if chapter_hashes != {p.name: sha(p) for p in inputs}:
            raise SystemExit('Chapter input bytes changed during compilation.')
        for extension in ('pdf', 'log', 'fls', 'aux', 'toc', 'out'):
            generated = scratch / f'{stem}.{extension}'
            if generated.is_file():
                generated.replace(outdir / f'{stem}.{extension}')
        if not (outdir / f'{stem}.pdf').is_file():
            raise SystemExit('The compiler did not emit a PDF.')
    log = (outdir / f'{stem}.log').read_text(encoding='utf-8', errors='replace')
    diagnostics = [line.strip() for line in log.splitlines() if BLOCKING_LOG.search(line)]
    hard = [d for d in diagnostics if not (allow_overfull and d.startswith('Overfull '))]
    pdf = outdir / f'{stem}.pdf'
    report = {
        'entry': 'layout/study/volume-16.tex',
        'engine': subprocess.check_output(['xelatex', '--version'], text=True).splitlines()[0],
        'passes': passes,
        'environment': {'SOURCE_DATE_EPOCH': env['SOURCE_DATE_EPOCH'], 'FORCE_SOURCE_DATE': '1'},
        'chapter_inputs': chapter_hashes,
        'layout_inputs': {str(p.relative_to(ROOT)): sha(p)
                          for p in sorted((ROOT / 'layout').rglob('*.tex'))},
        'pdf': {'name': pdf.name, 'bytes': pdf.stat().st_size, 'sha256': sha(pdf)},
        'blocking_diagnostics': hard,
        'layout_overfull_diagnostics': [d for d in diagnostics if d.startswith('Overfull ')],
        'underfull_diagnostics': [line.strip() for line in log.splitlines() if 'Underfull ' in line],
    }
    (outdir / f'{stem}-build.json').write_text(json.dumps(report, indent=2) + '\n',
                                              encoding='utf-8')
    print(json.dumps({k: report[k] for k in ('engine', 'passes', 'pdf', 'blocking_diagnostics',
                                             'layout_overfull_diagnostics')}, indent=2))
    return 2 if hard else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--chapter-dir', type=Path, default=ROOT / 'manuscript')
    parser.add_argument('--outdir', type=Path, default=ROOT / 'build')
    parser.add_argument('--jobname', default='V16-ReadFlow-R1')
    parser.add_argument('--debian-unindexed', action='store_true')
    parser.add_argument('--allow-overfull', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]+', args.jobname):
        parser.error('jobname must contain only letters, digits, underscores, and hyphens')
    return compile_book(args.chapter_dir.resolve(), args.outdir.resolve(), args.jobname,
                        args.debian_unindexed, args.allow_overfull)


if __name__ == '__main__':
    raise SystemExit(main())
