# V16《測度與實變分析》逐節打厚版交接

**V16-EXPANDED-R1-20261127 · 2026-11-27（台灣）**

| 欄位 | 紀錄 |
| --- | --- |
| 角色 | V16 主控交付。子代理分章起稿及打厚，精修獨立核讀，排版官逐頁查驗，獨立打厚官負責 B-07 整卷終審。 |
| 本次授權 | 使用者指示「逐小節打厚」，承接本 Work 的 B 方案單一 Work 變體及自主審查。本次限 V16 第 208–223 章。 |
| 階段及舊流程 | 沿用 B-01–03 固定文獻、卷界、校準及先備。B-04 對應原粗稿、打厚及精修，B-05 核整卷先備與實際落點，B-06 對應原行文排版，B-07 對應原 A10–12 獨立終審，B-08 對應原 A13 封存。 |
| 有效卷界 | 前卷末章 207，依使用者指定。本卷採 v4 Git 對齊分卷及書目表，已發布核查快照 ee4d2b7e723a32c2b58961e3903391c535fb8b07。卷界、章號、節序及唯一英文正文均沿用。 |
| 初版固定來源 | V16-B08-ReadFlow-R1-Source.zip，SHA-256 842539760edb798d608cb55ac36539f0c44d58f4db41179a0f2a921fd0a1f7f6。97 頁 PDF，SHA-256 be493de4a53202c5601b6841cf7c5ff306f502cba9219a2d44eb682c906d260a。 |
| 模板 | V0 ReadFlow R1，固定 artifact commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3，採納 commit c749e4867538888d3069346fa055ac2ca834c9e1。模板與本地字型依賴見 layout/、provenance/、dependencies/。 |
| 模型及模式 | 實際有獨立角色任務，精確模型底版及推理量未核實。 |
| 傳遞 | 本 Work 內部以實際讀入固定來源、回執和再核記錄交接。使用者可取成套配對檔。 |

[97 頁初版固定來源](https://chatgpt.com/library?file_id=libfile_fde3_f-13b34a81e2a0819197275e2784ca1d60_383d682b1c388191a1961becbec9fb77&account_id=personal)

## 成果和驗證入口

- 正文在 manuscript/，以 layout/study/volume-16.tex 為入口。用 README.md 的 XeLaTeX 指令重建。qa/build.json 配對正文、模板和正式 PDF。
- coverage/expanded-sections.tsv 逐節列本次新增內容，coverage/expanded-exercises.tsv 列各章原題數及新題數。52 個教學節與 16 個 Practice 節均有實質新增，新增 57 道有完整解答的練習。
- coverage/body-locations.tsv 的 140 筆文獻責任含所有主要及次要落點。coverage/FO-addendum.tsv 原有 23 筆 Folland 補充對照。原 57 個標籤和編號經 TeX 輔助檔直接比對。
- 四份 B-04 逐節回執、整卷精修、終審和缺陷改正紀錄在 review/。獨立排版回執與展開後的編譯、PDF QA 在 qa/。
- RELEASE-MANIFEST.json 列各檔用途可由路徑辨識、完整檔名、bytes 和 SHA-256。解包後執行 python3 verify_release.py。

## 尚未定案與續接

- V16-RF。Royden–Fitzpatrick 使用者已確認可用。本次可讀檔僅含第四版封面與目錄，實際印次及數學正文仍 UNKNOWN。後續需對照時由文獻角色取得可用正文。
- V16-V15。本卷以 207 接續，V15 已定稿的精確交叉引用待其最終固定版對齊。章內已給出適用先備。
- V16-DEPTH。原四項導讀地位沿用。Riesz–Markov、較廣的 Radon 覆蓋、完整 BV 分解與後續幾何測度理論仍屬導讀或後續卷。這次加深既有內容。
- V16-DEVICE。實機列印、手機、Windows、投影及真實自學讀者測試未核實。上述事項不阻本次 PDF 與 LaTeX 私下交付。
- 下一角色若收到續修授權，先核本版 ZIP、PDF 及相同雜湊的來源配對，沿指定變更範圍續作。保留兩版歷史與已核證據。Git 發布或改其他卷依個別授權。無待使用者決策。
