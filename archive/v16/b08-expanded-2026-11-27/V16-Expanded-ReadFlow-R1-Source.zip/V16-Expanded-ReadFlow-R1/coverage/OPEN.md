# Volume 16 source and scope notes

- V16-RF. Royden–Fitzpatrick is a user-cleared source. The identified
  PDF has five scanned pages, comprising the Pearson fourth-edition
  cover and contents v–viii. Exact printing, copyright page and all
  mathematical prose remain unavailable in that copy.
- V16-FO. Folland is a user-cleared reading source. The copy is
  the 1999 Wiley second edition, second printing. Record supplementary
  locators and align any numerical statement with the author's first-five-printing
  errata. Provenance is recorded without including the scanned book.
- V16-V15. Volume 15's B02 plan for Chapters 195–207 is fixed evidence of
  its scope. Its eventual fixed manuscript is needed for precise
  cross-volume references. Core V16 statements provide their local
  mathematical starting points.
- V16-DEPTH. Full locally compact representation, advanced Radon
  covering variants, Riesz duality outside the stated Lp scope and
  higher geometric measure theory are contextual or later reading.
  The specifically planned Hausdorff examples and differentiation
  theorems are traced in the chapter responsibility table.
- V16-MODEL. Role tasks have independent executions. Exact reported model
  and inference-effort settings were not exposed in the inherited runtime.
