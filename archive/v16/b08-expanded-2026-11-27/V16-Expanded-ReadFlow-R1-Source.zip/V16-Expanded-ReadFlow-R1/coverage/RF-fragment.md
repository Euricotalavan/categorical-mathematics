# Royden–Fitzpatrick 第 4 版片段核驗

V16-B04-RF-20261127-v1，精修實讀後交主控。使用者確認此前提供的兩個入口。此處核的是工作區收到的 RF 檔，不延伸到其他來源。

- 實檔 royden-verified.pdf，1,858,801 bytes，SHA-256 d60d16f53dcb484cb343a650d03bb27507cda41e052a7cabe0c9a2cca37bbbbf。PDF 共 5 頁，均為掃描。逐頁渲染目視並以 OCR 輔助查目錄，使用畫面核對 OCR 對頁碼與版次的誤識。
- PDF 1 為 Pearson 的 H. L. Royden 與 P. M. Fitzpatrick《Real Analysis》封面，明載 Fourth Edition，並有印度次大陸流通範圍標記。未見版權或出版資料頁，故出版年、ISBN、印次，以及與 c2010 美國裝幀版是否屬同一印刷，仍無本片段可核。
- PDF 2–5 為印頁 v、vi、vii、viii 的目錄。片段止於目錄結尾，正文頁數為 0。目錄能確認題名與起頁，各定義、定理、證明與例題仍無 RF 原文覆蓋。

| V16 對照主題 | RF 目錄位置及起始印頁 | 實際讀到的頁面 |
|---|---|---|
| Lebesgue 測度、可測函數與積分 | 第 2、3、4 章，印 29、54、68 | PDF 2（v） |
| 收斂、實線微分、BV、AC 與 Lᵖ | 第 5、6、7 章，印 97、107、135 | PDF 3（vi） |
| 一般測度、有號測度、Carathéodory 判準 | 第 17 章及 §§17.2–17.3，印 337、342、346 | PDF 4（vii） |
| 預測度延拓、Radon–Nikodym | §§17.5、18.4，印 352、381 | PDF 5（viii） |
| 乘積測度、度量空間的 Hausdorff 測度 | §§20.1、20.4，印 414、441 | PDF 5（viii） |
| Radon 測度及 Riesz–Markov | §§21.3–21.4，印 454、457 | PDF 5（viii） |

狀態更新為 RF 第 4 版封面與目錄已核；版權頁和數學正文均 UNKNOWN。可供書目定位，尚不足採作一條正式定理或證明的原文證據。
