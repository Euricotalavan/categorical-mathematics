# Folland supplemental source receipt

Verified copy, second edition, second printing per number line on PDF page 3, Wiley, copyright 1999, ISBN 0-471-31716-0, 402 physical pages, 8,330,607 bytes, SHA-256 de07cef31253c1a2e1166ffcb011c203f9ad1641368d3949bc31edb477174341. The user cleared the exact copy for private reading. The printed-to-PDF offset is +13 on the selected main-text pages. Consult the official first-five-printings errata for exact original formulations. The scan and its text layer remain private.

The addendum supplies targeted comparison after the initial public-core coverage. Selected sections were checked for the indexed statements, assumptions, proofs or examples indicated in the rows. Unlisted subsections and exercises are outside this pass. Source proof status is separate from proof status in V16. No wording or figures were copied into the addendum.

FO consequences important for the manuscript are equality for finite-mass sets even without global uniqueness, right-continuity for its one-sided interval convention, Borel versus completed Radon definitions, a.e. fibers in the completed product, the broader signed-measure codomain, and the unnormalized Hausdorff definition. The existing public core suffices for the construction and teaching sequence. FO is a privately accessed supplement and supplies comparison without a scope expansion into all its exercises.
