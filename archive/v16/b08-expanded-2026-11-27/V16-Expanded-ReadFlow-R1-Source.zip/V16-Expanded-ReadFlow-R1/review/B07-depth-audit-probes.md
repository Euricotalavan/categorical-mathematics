# V16 depth revision · B-07 audit probes

Initial audit only. The immutable revised source and its paired PDF
are still to be reviewed. I verified the original source ZIP
SHA-256 `842539760edb798d608cb55ac36539f0c44d58f4db41179a0f2a921fd0a1f7f6`,
all 18 baseline text files against the archive and its build record,
and the 97-page baseline PDF SHA-256
`be493de4a53202c5601b6841cf7c5ff306f502cba9219a2d44eb682c906d260a`.
The read baseline is `baseline/V16-ReadFlow-R1/`. The baseline has 52
teaching sections and 16 Practice sections across Chs. 208–223.

## Decision criteria

- **Sequential use.** For each section, a reader with the declared
  background can identify the objects, domain, quantifiers, prior
  result and advertised goal from the text already available. A new
  term, operation or notation with material consequences needs a
  definition or a nearby earlier anchor. A cross-reference must still
  land on the correct statement and use that statement's actual
  hypotheses.
- **Worked mathematical move.** Look for the exact intermediate idea
  or inference readers were previously being asked to supply. A
  genuine deepening makes the reader able to reproduce that move on
  another input. A motif repeated in prose, a preview followed by
  the same compressed leap, and a computation that skips checking the
  essential hypothesis leave the gap open.
- **Case diagnosis.** Where an important condition divides cases,
  use the proof, a meaningful adjacent example or a solved task to
  show how it changes the result. Use a threshold, exceptional set,
  normalization, ambient domain or denominator explicitly if it makes
  the example work. Retain the earlier necessary counterexamples and
  exercise responsibilities. Section needs govern the amount of
  explanation, with no target page count or uniform quota.
- **Mathematical blockers.** False added claims, missing premises or
  circular proofs, lost conditions or required material, ambiguous
  operations on infinite values, stale substantive locators, and
  incorrect dependence on earlier results block sign-off. Record
  precise location, impact and bounded return scope. An unexplained
  transition that the authorized revision was meant to teach also
  remains open. Stylistic differences that preserve accessible
  mathematical content carry no such consequence.
- **Completion evidence.** Compare candidate and baseline section by
  section, read all new or changed mathematical reasoning and trace
  affected unchanged proofs. Check the 140 core/context rows and the
  separately scoped Folland records against the intended placements,
  preserving the four contextual boundaries and other OPEN entries.
  Verify source/PDF hashes, chapter and reference continuity, and
  inspect the rendered repaired passages. Keep semantic findings
  distinct from layout checks and hash verification.

## Baseline examples of compressed pacing

| Baseline source and physical PDF page | Question the new text should let a learner answer |
|---|---|
| 209.3, Ch. 209 lines 131–151, p. 15 | Why does the covering argument only give one inequality, and how does applying that same inequality to the finite piece's complement reverse it? Why must the common mass be finite? |
| 209.4, Ch. 209 lines 207–226, p. 17 | Why enlarge the cover at the right endpoint, trim the target at the left endpoint, and take a finite subcover in between? Which direction of continuity is used on each side, and where is finite additivity enough? |
| 215.4, Ch. 215 lines 169–199, pp. 46–47 | Which sets are measurable before completion? Why does a single raw measurable null envelope give an exceptional set independent of the Borel level, and where is factor completeness indispensable? |
| 217.2, Ch. 217 lines 87–116, p. 56 | Why must admissibility bound every measurable subset? How does a positive Hahn region convert a nonzero residual into an explicitly admissible better density? |
| 219.2, Ch. 219 lines 154–176, p. 67 | How do large heights, simultaneous low heights and the bounded intermediate region exhaust the space? How does global convergence in measure control the last region when the whole space has infinite measure? |
| 222.2, Ch. 222 lines 135–155, p. 83 | What is measured by interval length and what is measured by image length? Why discard the slow intervals' endpoints before putting fast intervals inside them, and how does the resulting budget force zero outer measure? |
| 222.3, Ch. 222 lines 308–341, pp. 86–87 | Why do the averaging kernels separate locally integrable functions? Which exceptional sets are combined countably, and why does compactness turn convergence in finitely many directions into uniform control of the remainder? |
| 223.4, Ch. 223 lines 313–347, pp. 94–95 | What quantity is bounded at every node of the Cantor tree? What happens when an interval reaches both children, and why can deep construction intervals be assigned to individual members of the finite open subcover? |

## Adversarial checks by chapter

| Ch. | Test the revised text against |
|---|---|
| 208 | Outer-null singletons, arbitrary test sets in the splitting criterion, a zero-volume side, or a box crossing a boundary. Approximation by covers is an inequality before Borel measurability is shown. |
| 209 | Infinite-mass complement trap and differing extensions without sigma-finiteness. Use an atom at either endpoint to test the one-sided Stieltjes convention, and an unbounded interval to test the premeasure. |
| 210 | Compare a subset of a Borel null set with its Borel parent and distinguish the original, completed, and outer domains. On an infinite-mass set the approximation error must be measured directly. |
| 211 | Locally finite counting measure on an uncountable discrete space separates local from sigma-finite. For a Euclidean infinite-mass Borel set, preserve a single finite-error closed/open sandwich and the narrower hypotheses of source comparisons. |
| 212 | Test both extended-real endpoints, a binary grid boundary, a monotone approximation with infinite limit, and an incomplete space with an a.e. modification. Check the `0⋅∞` convention only on its actual domain. |
| 213 | Refine disagreeing indicator presentations that represent the same simple function, including a zero coefficient on infinite mass. A sign-changing example with two infinite part integrals must remain undefined. |
| 214 | Put a positive spike on shrinking support, a translate on escaping support, or a wide low bump on expanding support. Verify the exact failed premise. Check simultaneous null sets and finite subtraction in DCT. |
| 215 | Test a null strip with one nonmeasurable fiber, an integrable function with an exceptional raw fiber, and the counting/Lebesgue diagonal without sigma-finiteness. Retain the generating algebra on finite boxes and apply Tonelli when integral finiteness is yet to be proved. |
| 216 | A signed measure can have zero total on a set with nonzero signed subsets. Check all-subset Hahn signs, Jordan carriers, variation, null parts and the finite signed convention separately. |
| 217 | Test a residue for which naive constant perturbation fails, an absolutely continuous measure without a density for a non-sigma-finite reference, and (0⋅∞) in the signed density formula. Distinguish decomposition from existence of a derivative. |
| 218 | A representative can be changed on a null set without changing the norm. Check the attained essential bound, (p=1,∞), zero norms before Young normalization, and summable increments on a common measurable conull set. |
| 219 | Use escaping translates, the dyadic typewriter, and tall or wide spikes to check implications. Global convergence and all finite-window tests differ on an infinite space. Check both tails and where finite total measure is used. |
| 220 | Distinguish triple-ball finite selection from the fine-cover fivefold tail and the advanced layer count. Witness balls can be noncentered, closed and tangent. The proof needs a finite volume budget on each bounded localization. |
| 221 | A single-point change can alter total variation. A Cantor function has derivative zero a.e. without being AC. Test the finite total-length quantifier and endpoint overlaps before invoking integral recovery. |
| 222 | Test a representative with a special value at one point, nonlinearity of directional derivatives at one point, the rational-increment measurability step, and the scope of exceptional sets. Keep two Tonelli steps, the test-uniqueness lemma and the finite-net reason. |
| 223 | Test fixed scale versus the metric limit, empty and singleton covers, set diameter versus an ambient enclosing-ball diameter, arbitrary nonmeasurable cover members, and raw vs normalized costs. In the Cantor proof count wholly contained leaves and justify the finite-subcover replacement quantitatively. |

The probes guide the independent final read. They name failure modes
and representative inputs rather than prescribing replacement prose.
