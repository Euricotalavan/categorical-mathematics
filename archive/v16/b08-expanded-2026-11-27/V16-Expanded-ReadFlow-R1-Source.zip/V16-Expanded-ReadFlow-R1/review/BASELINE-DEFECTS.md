# V16 proof and editorial issue ledger

This ledger records changes in the integrated manuscript source. Role
receipts retain the reviewed snapshots and proof discussion.

| Issue | Earlier wording or gap and effect | Accepted remedy and check |
|---|---|---|
| D01 | The 209 nonuniqueness example did not specify one orientation for half-open intervals. Mixing orientations could admit singletons. | Uniform left-closed bounded intervals and the two ray forms in the pilot and 209. Generated Borel domain and disagreement on singleton verified. |
| D02 | The differentiation pilot relied on an inline invocation of Markov and did not give the last average inequality. | Include both exceptional sets, the pointwise mass estimate and the triangle bound for the average. Carry exact B03 proof and both earlier anchors into 222. |
| D03 | Early manuscript used Euclidean dilation in covering before it was grounded. | Prove volume and splitting-class preservation under translations, positive dilations and coordinate reflections in 208. Verify later 220 use and 222 integral transport. |
| D04 | The closed/open approximation proposition in 210 put the tolerance after the pair of sets. | Put “for every tolerance” before the pair and check summable approximation. |
| D05 | The Simon citation used 5.15 for Riesz representation. | Replace with 5.12 and 5.14 after original page check. The result remains orientation in 211. |
| D06 | The completed product discussion could sound as though pointwise differences were always defined and did not spell out the rectangle uniqueness step. | Compare inverse images outside null sections. Verify completed rectangle masses by Borel representatives and product uniqueness. Both completions identified. |
| D07 | A signed-difference example and the density theorem used finite-signed and positive conventions without clearly stating both types. | Require a finite positive common addend and define absolute continuity for positive measures as well as finite signed ones. Differentiate density representation from arbitrary reference decomposition. |
| D08 | The uniform integrability responsibility asked for equivalence while the theorem stated one direction. | Supply the converse via the previously proved integral threshold estimate. |
| D09 | The advanced covering comparisons lacked a precise bounded-center family description. | State the one-ball-per-center and fine-centered requirements for the comparison and record the claims as contextual. |
| D10 | The direction-line argument could presume an unintroduced zero-dimensional product or a general rotation rule. | Treat dimension one directly. Parameterize a nonzero coordinate, derive null transport by Fubini and coordinate translation, and display the quotient scaling. |
| D11 | The isodiametric proof could apply a positive-radius ball formula to diameter zero. | Handle the singleton case and omit empty covering members or give zero diameter convention. |
| D12 | Dominated convergence inherited the real-valued type only from the surrounding chapter. | Type the measurable maps into the extended real line explicitly, maintaining the finite-integral hypotheses. |
| D13 | The local-density Radon example is proved after the integral construction. | Record its actual second location in 217 with provenance 211-07 and reference 211 Euclidean regularity. |

## B-07 local repairs

The independent B-07 findings were written on the fixed B-06 source and
PDF before the prior issue ledger was read. The initial pair is preserved
by its checkpoint. Only the following proof and definition repairs change
the canonical text before the final B-07 recheck.

| ID | Correction in the repaired manuscript |
|---|---|
| B07-01 | In 222, the Borel bad-set indicators are nonnegative. Apply Tonelli first in direction-line coordinates, obtain null fixed-parameter sections in the other direction, translate them, and apply Tonelli in the original coordinates. |
| B07-02 | In 215, use the relative algebra of finite unions of half-open subboxes on each finite exhaustion box before applying uniqueness. Pass to the product by continuity from below. Use Borel Lebesgue restriction for the graph calculation. |
| B07-03 | Define sigma-finiteness for measures and premeasures in 209, including the meaning for a measurable restriction. |
| B07-04 | Define local absolute integrability and its a.e. function space in 217 before the Radon density example. Refer to that definition in 222. Explain the signed integration product convention explicitly. |
| B07-05 | Put the general locally finite Euclidean Borel measure's joint closed–open approximation and summable error estimate in 211, and move the corresponding responsibility marker. |
| B07-06 | Use “real-valued” in 219 and 222 where the condition excludes infinite values. Introduce indicator notation in the reader guide and the Banach definition before completeness in 218. |

Final acceptance of the changed statements and the repaired PDF is recorded
separately in the sole B-07 mathematical review.
