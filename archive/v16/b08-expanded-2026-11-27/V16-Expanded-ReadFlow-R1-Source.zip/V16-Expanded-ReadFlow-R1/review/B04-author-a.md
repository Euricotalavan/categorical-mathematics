# V16 depth revision · Expansion return A

Chapters 208–211. The 97-page audited baseline is the unmodified V16-ReadFlow-R1 source archive with SHA-256 842539760edb798d608cb55ac36539f0c44d58f4db41179a0f2a921fd0a1f7f6. The four draft TeX files are independent copies for the commissioned deeper edition.

| File | Baseline SHA-256 | Returned SHA-256 | Added problems with solutions |
|---|---|---|---:|
| ch208.tex | `2cceb4bc7610b42f8bb3170a74d7d4693c90c2345864d41dd29bd29138f62b25` | `4f9bbe7113398b269f911aa5ced604c4dc278a0983b43a31524f6ab1796b8a77` | 3 |
| ch209.tex | `6fc124add9787ed25f108fee7916d917e27a06c36bcbfeec8cd500e77b609091` | `9b04404591379192edb548e530324b9ffc101af2be6bd156cac9471c592d2ca5` | 4 |
| ch210.tex | `b3a974b95555f7c8a7580e258b816cccf6b1c2164da78f12df7a6c9bcb2a2528` | `72386156e05030871d1a3ffb46793d5b0c0050ebc06cdd4c7fa9d4f090291328` | 2 |
| ch211.tex | `65cfa49e2103b77c7a0ab9c2b57dcabcb23293443851805abcc41f4705fc57b5` | `837e340ba2bdbb0edcdc06e5208b40cacb5aed11e1abfea719c51fb504593af3` | 3 |

## What each original section gains

| Original section | New in-section work | New graded practice with full solution |
|---|---|---|
| 208.1 The sets on which a measure is defined | Three-cell report, checking countable additivity and correcting overlapping weights. Finite-cofinite family shows why countable closure matters. | Find the cells of a two-generator sigma-algebra, and reject incompatible mass assignments. |
| 208.2 What it means for a set to split every test set | Tracks the residual term in the proof without continuity of an outer measure. A priced cover gives a set passing the whole-space test and failing a smaller test. | Recover every Carathéodory set for outer counting of projected fibers. |
| 208.3 Length and volume by covers | Covers a Lipschitz graph with closed rectangles, distinguishes null planar mass from a full-length projection, and tracks the splitting face under open box enlargement. | Bound the area of a closed triangular region by counting cells that do or do not meet the diagonal. |
| 208.4 Practice | Three added problems after the existing two, with no changes to the original solutions. | Algebra and mass consistency → proof of a domain → area computation. |
| 209.1 Moving limits of sets | Uses summable tails to obtain a null set of infinitely many visits, and models the failure of this conclusion from individual masses tending to zero. | Uses continuity from above to bound the mass of infinitely many visits from below and tests the finite-mass hypothesis. |
| 209.2 Building an extension from countable covers | Derives continuity at the empty set as an exact premeasure criterion for finite charges, with a finite-cofinite failure. | Characterize extendibility for arbitrary singleton weights plus a prescribed total mass. |
| 209.3 Why finite pieces determine the extension | Gives a globally infinite but sigma-finite unique extension, explains why finite pieces must come from the given algebra, and contrasts local agreement. | Construct two extensions of one measure assignment on a line component plus an isolated point and calculate the two canonical outer masses. |
| 209.4 A measure from a cumulative function | Derives singleton mass by continuity from above and computes a measure from a continuous ramp plus an upward jump, including endpoint inclusion. | Recover a cumulative function up to an additive constant and compute an atom directly. |
| 209.5 Practice | Four added problems and solutions after the existing two. | Monotone set control → extension criterion → local and global distinction → Stieltjes identifiability. |
| 210.1 Adding subsets of null sets | Different weights on the same domain can yield different completions. An infinite-mass two-set domain gives a strictly larger outer splitting domain without adding any null subsets. | Prove that the Carathéodory domain of the induced outer measure equals completion when total mass is finite. |
| 210.2 Open and compact approximation | Constructs a closed approximation of the irrational numbers with small omitted mass, explaining why no compact approximation can have the same error property. | Control the symmetric difference of a finite-mass set and a small translate using compact and open approximants. |
| 210.3 Practice | Two added problems and full solutions. | Finite envelope and split proof → quantitative translation argument. |
| 211.1 The Borel convention | Proves regularity directly for weighted atoms accumulating at zero and contrasts finite compact mass with finite cardinality of support. | Diagnose local finiteness for arbitrary finite weights before and after removing the accumulation point. |
| 211.2 Regularity on Euclidean space | Computes an explicit joint closed–open error for an infinite-mass set under Lebesgue measure plus point masses. Dropping endpoints changes the conclusion. | Build an increasing compact family exhausting a Borel set up to measure zero. |
| 211.3 Comparing source conventions | Constructs the outer formulation from the Borel convention, with proofs of Borel splitting, existence of a Borel envelope and open outer approximation. | Verify the Borel Radon axioms for restriction to an open subspace. |
| 211.4 Practice | Three added problems and full solutions. | Local finiteness under changing domain → compact approximation without a global finite-mass assumption → topological restriction. |

## Sources, dependencies and checks

Source responsibility rows 208-01 through 211-08 and the adopted Folland comparison rows remain in place. The new proofs and examples were written from the existing chapter definitions and author-available sources. The main source families are Axler §§2A–2D, Tao §§1.2, 1.4, 1.7, Fremlin 113C, 212C–212E and 256A–256D, and Simon §5.6–5.7. Folland’s user-cleared §§1.3–1.5 and §§7.1–7.2 continue to support the original coverage notes. New illustrative constructions are original adaptations, not copied passages.

Preservation check passed for exact chapter, section, label and coverage-marker sequences and the shared theorem-type counter sequence. Every original manuscript line remains in order. Numbered examples and established theorem numbers are preserved by using unnumbered paragraphs for the new lessons. Each practice addition has a corresponding solution. No preamble, bibliography, source corpus or original package was changed.

The 210 finite induced-outer-measure exercise uses a finite hull so its subtraction is legitimate; the 210 infinite example exhibits the precise failure. The 211 outer-convention bridge transfers the open-set properties and proves the Borel-envelope requirement; it does not claim a converse for arbitrary spaces or invoke the deferred representation theorem. The 211 weighted shell example deliberately retains atoms on finite endpoints. Independent mathematics and layout review of the full deeper edition remain with their assigned reviewers.

The final four sources also passed an isolated three-pass XeLaTeX build when overlaid on the original 16-chapter source. That mixed engineering preview was 106 pages; it had zero blocking and overfull diagnostics and three underfull warnings in untouched Chapters 221–223. This preview is only a source-build check, not the expanded volume's formal PDF or its final visual pass.
