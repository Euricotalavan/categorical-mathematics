# Volume 16 | Chapter design and dependencies

Status: proposed B-02 design input for reconciliation with the B-01 register.
Numbers 208–223 follow the explicit preceding-volume ending at Chapter 207.
The volume treats ordinary real measure theory in English and gives all
mathematical readers a directly checkable proof path.

## Scope

Begin with abstract outer measure and the real-line model, separate
Carathéodory measurability from extension of a premeasure, then isolate the
measure-space and topological meanings of completion and regularity. Build
integration on simple functions before any limit theorem. Separate product
construction and section measurability from equality of the iterated
integrals. Signed measures and Radon–Nikodym feed Lp, and the final run
connects quantitative covering, differentiation, AC, BV and Hausdorff measure.

Use finite real signed measures as the main form. State the broader
one-sided-infinite convention only with its restrictions and without
identifying it with the main finite form. Use sigma-finite reference measure
and finite signed target for the primary Radon–Nikodym theorem. For the
positive sigma-finite target extension, prove the assembly or mark the
broader theorem as contextual. Keep non-sigma-finite extensions and
localizable spaces outside the core.

Use the Borel Radon convention fixed in 211, specifying local finiteness,
outer regularity and exactly where inner regularity is asserted. If using
locally finite Borel measures on Euclidean space, give the applicable
regularity theorem or a proof by finite exhaustion. Distinguish completed
Radon measures in Fremlin. Reserve the full locally compact Hausdorff
representation theorem for its explicitly stated assumptions and level of
treatment. Explain Borel vs. completed measurability whenever moving to
product or Lebesgue statements.

Keep Hausdorff geometry to outer-measure construction, Borel restriction,
counting, a positive-dimensional interval/Euclidean demonstration, and how
distance scaling and Lipschitz maps change the measure. State the normalization
before using equality with Euclidean volume. Further geometric measure
theory, currents, area/coarea, and geometric BV are outside the volume.

## Chapter sequence

| Chapter | Sections and proof path | First use or later use |
|---:|---|---|
| 208 | Measurable spaces and positive measures. Outer measure and Carathéodory measurable sets. Euclidean outer length and basic examples. | Sigma algebras before measurable sets. Do not cite premeasure extension until 209. |
| 209 | Algebra, premeasure, covering construction, extension, sigma-finite uniqueness. | Reuse abstract Carathéodory theorem. Establish each box/interval premeasure property used to get Lebesgue measure, or explicitly start from real outer length of 208 and verify its interval values. |
| 210 | Null sets and completion. Borel/Lebesgue pairs. Regularity and approximation by open/compact sets. | Supports Lusin and Cc-density. Distinguish measure completion from Cauchy completeness, and finite-measure inner approximation from local finiteness. |
| 211 | Radon definitions, Euclidean regularity, examples, Borel vs completed conventions. | No reference to RN. If showing representation, define Cc and the functional precisely and respect the stated scope. |
| 212 | Measurable functions, range, algebra, countable limits, simple approximants. | Define extended-real measurability and the calculation convention 0 times infinity before integration. |
| 213 | Integrals of simple, nonnegative, signed, and integrable functions. | Check independence of simple partitions, monotonicity, zero a.e. and definition of equalities of extended integrals. |
| 214 | MCT, Fatou, DCT, comparison/liminf examples. | MCT may be used here to prove additivity on nonnegative functions if 213 establishes only monotonicity and scalar multiplication. Avoid using indefinite-integral counts before proving them. |
| 215 | Product sigma algebra, section measurability, Tonelli, Fubini, completions and counterexamples. | For sigma-finite product choose one acknowledged construction and state the sigma-algebra for uniqueness. Explicitly distinguish rectangle factor completion from completion of product. |
| 216 | Finite signed measures, Hahn, Jordan, total variation. | Give Hahn proof or earlier lemmas sufficient to derive it. Distinguish a Hahn decomposition of the space from a Jordan decomposition of a measure. |
| 217 | Absolute continuity of measures, singularity, RN derivative and Lebesgue decomposition. | Keep distinct from absolute continuity of functions in 221. If using a Hilbert proof, isolate Riesz representation and L2 completeness first instead of borrowing 218 forward. A maximal-density supremum proof bypasses both. |
| 218 | Lp classes, Hölder, Minkowski, Banach completeness, L-infinity and density. | Build all statements over the same measure space, with p or sigma-finiteness specified. Explain a.e. equality and limits of finite-support approximants. |
| 219 | a.e., a.u., measure, and Lp convergence. Modes, subsequences, Egorov, Lusin and Cc approximation. | On infinite measure, name the local and global versions separately. Do not require 222 differentiation to prove Cc-density. |
| 220 | Finite ball selection, centered maximal operator, weak (1,1). Vitali fine-cover comparison. | Distinguish factors 3 and 5, centered vs uncentered, and ball cover vs null-remainder selection. Expose measurability of M. |
| 221 | Bounded variation, Jordan functions, absolute continuity and Cantor counterexample. | Define AC and prove its elementary relation to BV here. Establishing the derivative-to-integral characterization can be deferred to 222, with a clear forward signpost and no use in the 221 proofs. |
| 222 | Lebesgue differentiation, density, AC fundamental theorem, Lipschitz differentiation. | Use 219 density plus 220 weak estimate. Prove the AC characterization without circular use of Lipschitz/Rademacher. Rademacher in higher dimensions requires a joint-derivative argument, with a separate author proof from a cited source. |
| 223 | Hausdorff scales, metric outer measures, Borel restriction, counting/interval examples and Lipschitz distortion. | Cite Carathéodory result with correct scope. At exponent 0 count each nonempty covering set, even diameter zero, or present counting in a separate construction. Coordinate Euclidean vs normalized conventions. |

## Chapter and cross-reference interface

The chapter labels are ch:208 through ch:223. Every chapter opens with a
short problem or motivation. Each substantive result should include a condition
check or a counterexample somewhere nearby, with at least one worked example
per chapter and a short practice pair with solutions. No example should rely
on a result in a later chapter except a clearly announced orientation note.
Use the original-source responsibility IDs in semantic TeX comments
(% V16: 208-01 208-02) at their actual landing points. If a row is not included,
record side treatment or exclusion with reason instead of attaching a misleading
marker. Use only canonical file names ch208.tex through ch223.tex.
Use AMS notation. Set labels unique across the volume. Give source locations
in a short chapter note or where a proof route needs attribution. Rewrite in
original prose and retain verified assumptions.

## Pilot reader and proof checks

Calibrate one short section on extension uniqueness and one on Lebesgue
differentiation. State domains, finite subtraction, and the sigma-finite
exhaustion in the former. Show the full estimate, the exceptional-set
mechanism, and localization in the latter. Calibrating those checks is part
of B-03, and the named pilot source can be included in its canonical chapter
during B-04 after approval.

## Locked implementation decisions

The coordinator accepted the B-02 expander receipt and independent
refinement input after checking the 140 B-01 rows. Chapter numbers remain
208–223. MCT appears in 214 with full proof; 213 proves and reuses the
simple increasing-approximation lemma so signed linearity is available
there. Chapter 216 proves finite range before Hahn. Chapter 217 uses the
finite-signed Hahn/density construction and tracks arbitrary-reference
decomposition separately. Chapter 219 establishes continuous compactly
supported approximation before 220/222 use it.

Chapter 211 states the Riesz–Markov correspondence as an optional
orientation item for later study and invokes no unproved representation
theorem. Chapter 220 gives the finite selection and weak maximal estimate
in full and provides the fine Lebesgue covering proof. The Besicovitch
layers and arbitrary Radon fine-cover extension are contextual, precisely
stated and identified with Fremlin as external reading. For 221 we keep
the order of the main construction explicit: any a.e. derivative or
FTC conclusion deferred to 222 must be cited there with a statement of the
prior dependency. The extended BV decomposition can be contextual with
one-sided representative and endpoint qualifications. All optional or
deferred text is tracked by responsibility ID and may not become a
prerequisite for a core proof. Chapter 223 targets a fully proved exact
integer-dimensional Euclidean normalization via isodiametric and fine
covering if the full compact-fiber symmetrization proof fits. The Cantor
dimension follows from exact or two-sided positive finite measure bounds.
If its critical mass value is cited externally, distinguish that value
from the proved dimension.

B01 and current user authorizations allow B03. No human interstitial
approval is pending. Final proof decisions at B07 stay with the independent
thickening auditor.
