# V16 section expansion, Chapters 220–223

B-04 authorship for the expanded edition. The fixed input is the 97-page
B-08 ReadFlow R1 source ZIP, SHA-256
842539760edb798d608cb55ac36539f0c44d58f4db41179a0f2a921fd0a1f7f6.
The input files were extracted into the baseline directory. All original
numbered statements, exercises, source markers and labels are retained.
The additions use the first edition's template and local conventions.

| Section | Added reading material | Added exercise with solution |
| --- | --- | --- |
| 220.1 | Sharpness of three for selecting from two equal intervals, dependence on radius order, and the absence of a maximum in an infinite family | Approximate-largest choices and the factor \(1+2/\alpha\) |
| 220.2 | Compact witness accounting, integrable singularity with infinite maximal value, and a local exceptional-fraction estimate | Weak estimate with the small-value part removed |
| 220.3 | Why every tail covers missed points, the arbitrary-set use of outer measure, and failure for a two-interval coarse cover | Finite disjoint inner approximation of an open set |
| 221.1 | Variation through turning points, minimal increasing parts, and a continuous oscillating function of infinite variation | Exact variation of a multi-jump step function |
| 221.2 | Family-wise quantifiers and the sharp length budget for a logarithmic singularity | Composition with Lipschitz maps and products |
| 222.1 | The two approximation error sets and a thin-spike Lebesgue point where averages over insufficiently thick subsets fail | The rational indicator and dependence on the representative |
| 222.2 | Image-length inequalities for slow and fast families, the role of the gaps, and the jump component in the integral inequality | Integration by parts for absolutely continuous functions |
| 222.3 | Countable exceptional sets and the uniform finite-net estimate, with differentiation of the maximum of two projections | A Lipschitz function with two coordinate derivatives and no total derivative |
| 223.1 | Exact interval costs at and around exponent one, and the parity gap in the metric outer measure proof | Two-point zero-dimensional costs before and after scale refinement |
| 223.2 | Infinite measure at the critical exponent and the dimension of a snowflaked metric | Exact critical cost with \(d^\gamma\) |
| 223.3 | The two inequality directions and exact raw measurements of a square and its boundary | Raw cost of a ball and sphere |
| 223.4 | A direct Cantor lower bound from a Stieltjes measure, with explicit mass control on each covering interval | Dimension for a two-interval construction of ratio \(a\) |

The Practice sections each retain their two baseline problems and have
respectively three, two, three and four added problems with full solutions.
The new examples and explanations derive directly from the stated
results. Historical proof references remain in the source notes.
The probability proof uses the Stieltjes construction in Chapter 209 and
the continuous Cantor function in Chapter 221.
A separate refinement pass checked the drafts. Its corrections clarified
the first use of the interval cost, the product estimate in Practice, the
directional quotient at the diagonal, and the description of zero-cost
null covers. The logarithmic example gives a sharp length budget and complements the power estimate in Chapter 214.

## Source hashes

0f1ef934dbe1b9e3d295671b662aef099f7f844fd03dc0485c63d9a5eb185c17  v16-depth/baseline/V16-ReadFlow-R1/manuscript/ch220.tex
9288d7402111546fcab5b82c0fc48f12e752be83a69e7667c71758d11004bed5  v16-depth/draft-d/ch220.tex
e81a2224f97de1bf0b7e3653fb8c6b74ef86f22c5b3f4696b0037edfd93645ad  v16-depth/baseline/V16-ReadFlow-R1/manuscript/ch221.tex
2fe2a8cc9ef40ee238d63d71420a060cad14876e3a11f535524f9486a6b329df  v16-depth/draft-d/ch221.tex
0f377606db674a05ce0db0b024f83ad9e97f3141b6933b594cf8752f8088c7c6  v16-depth/baseline/V16-ReadFlow-R1/manuscript/ch222.tex
f644671bab35e7c203f572d57c353fb2610fed3622cc36e2a1f7d80b18ebdb6b  v16-depth/draft-d/ch222.tex
891ff90bb6aa64cb2a89aecfd6fb99761b457fcfdf4294db64896d61833f6478  v16-depth/baseline/V16-ReadFlow-R1/manuscript/ch223.tex
3d106a4b8a03ee541c7386cf9a2c30c71c0dc638939367f6c107a06b574c6e06  v16-depth/draft-d/ch223.tex
