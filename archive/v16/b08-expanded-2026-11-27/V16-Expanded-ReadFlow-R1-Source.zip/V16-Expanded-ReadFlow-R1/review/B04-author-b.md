# V16 substantive expansion receipt for Chapters 212–215

Date: 2026-11-27, Taipei. Workflow: B-04 author handoff to independent thickening and
refinement, V16 section-by-section expansion. Scope: English Chapters 212–215 only.
Input: the coordinator's verified immutable B-08 archive
SHA-256 842539760edb798d608cb55ac36539f0c44d58f4db41179a0f2a921fd0a1f7f6.
The archive contents were read under v16-depth/baseline/V16-ReadFlow-R1/manuscript.
Author outputs are the four chapter files alongside this receipt. No authorship
changes were made to the archived originals, shared layout, or preamble.

## Teaching additions and new practice

Each row refers to one original teaching section. Original Practice sections
retain their two existing exercises at the start. All new exercises appear
within those existing Practice sections and have full solutions.

| Chapter and original section | Added teaching | New solved exercises |
|---|---|---|
| 212 · Measurability as an inverse-image condition | Rational tests recover real fibers, weak levels and the infinite endpoint. Finite-space identity example isolates a failed middle sigma-algebra match. | 3 · Trace interval inverse image on a potentially nonmeasurable domain set. |
| 212 · Operations and pointwise limits | Measurable real-limit locus from the Cauchy criterion. Comparison with an everywhere extended-real limit. Alternating events give a worked limsup and liminf. | 4 · Exactly finitely many visits, including zero, and the resulting limit. |
| 212 · Approximating values on a finite grid | Reciprocal example derives grid cells and clipping bounds, and separates uniform accuracy away from zero from unbounded global error. Raw simple-level replacements are reconciled outside one null envelope. | 5 · Signed dyadic approximation of a decreasing-to-target sequence, with exact endpoints. |
| 213 · Finitely many heights | Three-cell computation verifies overlap accounting and why adding any positive height on an infinite-measure tail changes the integral from finite to infinite. | 3 · Many measurable pieces yield only two heights; group before integrating. |
| 213 · Arbitrary nonnegative functions | Threshold-slack example shows why comparison at factor one fails. Dyadic calculation of the linear function's integral uses only the simple supremum. An infinite level on a null set is contrasted with the same level on a positive-mass set. | 4–5 · Construct an increasing minorant including an exceptional value; prove strict integral inequality without a uniform pointwise gap. |
| 213 · Functions that take both signs | Defined one-sided infinite integrals fail finite linearity. The alternating harmonic example separates ordinary ordered sums from the signed counting-measure integral. | 6–7 · Classify opposite one-sided infinite integrals; characterize equality in the integral absolute-value inequality. |
| 213 · A comparison with Riemann integration | Denominator-weight function on the rationals has vanishing Darboux gap despite dense exceptional points. Proof isolates finitely many high values at any fixed cutoff. | 8 · A change of \(x\) on the rationals preserves the Lebesgue integral and destroys Riemann integrability. |
| 214 · Monotone convergence and Fatou's inequality | Geometric partial sums give an infinite limit integral. Alternating indicator heights give strict Fatou and explain how the tail infimum can lose information. | 3–4 · Integrate a nonnegative series with an unbounded sum; derive signed Fatou from an integrable lower bound and exhibit failure without that assumption. |
| 214 · A single integrable bound | Binomial estimate finds a common integrable envelope on an infinite interval after discarding the first term. The concentration example's pointwise envelope proves directly that its uniformly bounded integral values do not suffice. | 5–6 · A signed exponential–sine limit and dominated convergence through an integrable multiplier on an arbitrary measure space. |
| 214 · Two estimates for integrable mass | A single piecewise function exhibits an unbounded core and a distant integrable tail, with a quantitative small-set estimate. A two-region argument chooses the finite-measure set before choosing the local error. | 7–8 · Combine uniform convergence on a finite region with a tail bound; compute the sharp \(x^{-\alpha}\) integral estimate and show the \(\alpha=1\) failure. |
| 215 · Rectangles and sections | Non-Borel selection of diagonal points gives measurable sections in both variables without product measurability. Pulling back along the measurable diagonal detects the hidden obstruction. | 3 · Measurable comparison \(u(x)<v(y)\) constructed from rational rectangle tests, with both section formulas. |
| 215 · Construction and uniqueness | Overlap of two concrete rectangles is split by the first-coordinate membership patterns. Truncation proves the formula when an individual rectangular factor has infinite mass. | 4 · Prove the equality of product restrictions, including the equality of trace sigma-algebras and inherited sigma-finiteness. |
| 215 · Tonelli and Fubini on the product domain | A mildly singular signed kernel uses Tonelli to certify finite absolute mass before Fubini and antisymmetry are used. | 5 · Check absolute integrability by Tonelli for a separable signed kernel, then evaluate by Fubini. |
| 215 · What changes on completion | A raw Borel null strip contains a completed-product set whose every vertical section fails Borel measurability if the factor is kept incomplete. This is compared with the old one-bad-section example for complete factors. | 6 · Prove that every subset of a Borel graph is null and measurable in the completion. |
| 215 · Failures and a useful computation | Strengthen the previous kernel's singularity by one power. Every individual section is integrable and the two repeated values are finite but unequal; wedge bounds prove both signed joint parts are infinite. | 7 · Derive the distribution-of-levels formula by Tonelli, then integrate the logarithm via its superlevel lengths. |

## Source checks and editorial scope

- **212.** Axler 2.35–2.53 and 2.88–2.95, Tao Def. 1.4.32 and
  Ex. 1.4.29, plus Fremlin 121A–121C were retained as the topic
  locators. The Cauchy-set and quantitative clipping extensions
  were worked directly. The Borel sandwich argument was checked
  against 210 and the B08 proof of completion.
- **213.** Axler 3.1–3.24 (physical PDF pp. 89–103), 3.34
  (pp. 108–109), Tao 1.4.33–1.4.39 (pp. 113–120), and
  Folland §§2.2–2.3 (printed pp. 49–54), already part of the
  B-08 evidence. The denominator-weight, sign-order and strict
  inequality examples have their own proofs in the draft.
- **214.** Axler 3.11 (PDF pp. 93–94), 3.26–3.31 (pp. 104–108),
  Tao 1.4.40–1.4.49 (pp. 122–128), and Folland 2.14, 2.18, 2.24
  (printed pp. 50–54). The shifted signed Fatou and explicit
  envelopes were derived from the chapter theorems to expose
  their assumptions, instead of transferring source exercise text.
- **215.** Axler 5.1–5.35 (PDF pp. 132–149), Tao 1.7.11 and
  1.7.15–1.7.23 (pp. 213–221), Fremlin 251K and 252H
  (Ch. 25 PDF pp. 7, 25), and Folland 2.36–2.42
  (printed pp. 66–71). The two-power kernel pair, null strip,
  grid calculation and solved exercises were checked directly.

The one precision correction to inherited wording is in Ch. 212's
Borel-representative proof. The sandwich used there is described as
having a measurable null difference. Equality of the two masses is
insufficient when both are infinite. The cited completion theorem
already provided the required null difference. No theorem statement,
label, section order or shared statement/example counter changed.
All inline teaching additions use unnumbered paragraphs.

## Verification and review flags

All four chapter headings and labels match the archived sequence. All
28 problems have corresponding solution environments. No new numbered
statement or example environment was introduced. The independent refinement
agent has separately read the additions and reported no mathematical blocker,
with localized clarity edits incorporated. The signed Fatou exercise's
finite subtraction, the cutoff parameter in the sharp small-set problem,
the density of the exceptional sets in the Riemann examples, and the raw
versus completed domains in the product examples are the main points for
the subsequent fixed-pair review. Formal ReadFlow rendering and whole-volume
review are later-stage checks.

| Chapter | Original word count | Expanded word count at checkpoint | Original problems | Final problems |
|---:|---:|---:|---:|---:|
| 212 | 1454 | 2334 | 2 | 5 |
| 213 | 1199 | 2279 | 2 | 8 |
| 214 | 718 | 1832 | 2 | 8 |
| 215 | 1907 | 2900 | 2 | 7 |

| File | Input SHA-256 | Output SHA-256 |
|---|---|---|
| ch212.tex | d6e78c1c7e2dee818363643acd1f3bf16cbd9d3e792a32942e0de6cfe92a4a46 | c75b25670f28d1739fed874d985969a79b1bc71de554cf57a35ef8ab389272ed |
| ch213.tex | ec5ac25d1c88144e682201a41d39bdf59524b59fd9b83c508f7666bf39477db7 | 56e6bc61cc54622aac8d79651e3c37f59b7938c080e742e85895de1fd40e2f08 |
| ch214.tex | d4c0b93a0ecb4dd32c2f19f3c136c00b181f837baacb02edf1e4945eabcbd2e3 | 2c5a81d1af7c071b8eabe5bca4160cb2cbdcccc1288d67e1549bfc7b1a03b207 |
| ch215.tex | 371b021f459c747b60d02832c590da91b59de1a99a4c3f4b310e1dbe1e9ec166 | df3c38448f380fe51666872cccaae146fc861ed46c6d4b2c7d5ed3a2ef67f3c5 |
