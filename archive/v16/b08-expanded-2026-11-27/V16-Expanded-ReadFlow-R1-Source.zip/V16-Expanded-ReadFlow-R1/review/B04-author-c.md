# V16 depth revision · Chapters 216–219 · B-04 author return

The input is the audited 97-page B-08 release. Archive SHA-256
842539760edb798d608cb55ac36539f0c44d58f4db41179a0f2a921fd0a1f7f6.
The four baseline sources were read from
v16-depth/baseline/V16-ReadFlow-R1/manuscript. Changes were made to the
four copies in v16-depth/draft-c. This is an author return for independent
thickening and refinement. The agent's exact model and reasoning setting
were not independently verified.

## Additions by existing teaching section

| Chapter and heading | Added reader work | Solved practice added |
|---|---|---|
| 216 · Finite signed measures | Conditional singleton data cannot define a finite signed measure. Absolute summability lets one regroup the disjoint subfamilies, and geometric weights give a uniform truncation estimate. | Evaluate the masses of a decreasing tail family and separate continuity from monotonicity. |
| 216 · Hahn's decomposition of the space | A deficit gives simultaneous inequalities on every measurable subset of the chosen region and of its complement. A near-maximizing set can still contain a negative singleton. | Resolve a Hahn deficit into missed positive mass and retained negative mass, with a bound on both terms. |
| 216 · Jordan parts and variation | All positive representations add one common nonnegative measure to the Jordan pair. A mixed atom/continuous example computes the common addition and variation cost. | Prove the partition variation is the least positive measure dominating every absolute signed value, and diagnose failure of a single total-mass test. |
| 217 · Absolute continuity | An integrable density gives an explicit order of choices for a small reference-mass cutoff. A locally finite, infinite density \(x\,dm_1\) exhibits failure of a universal cutoff. | Find a quantitative cutoff for the unbounded density \(x^{-1/2}\) on \((0,1]\). |
| 217 · Existence and uniqueness | Expanded admissibility for every measurable test and the point at which exhaustion and absolute continuity supply the residual measure ratio. Computed a signed density on a coarse measurable partition. | Obtain the derivative of counting measure relative to strictly positive summable masses, including infinite total integral. |
| 217 · Decomposition and integrating a density | Reversing the density on its positive region is proved by testing on measurable sets, with a worked unbounded reciprocal and a genuine null-support obstruction. | Compute both parts and a test integral when the reference measure charges one atom and misses another. |
| 218 · Representatives and classes | An unbounded representative obtained by changes on dense rationals preserves every finite \(L^p\) norm and essential supremum, which are computed. | Derive the sharp evaluation bound at a measurable singleton of finite positive mass and show evaluation is well-defined on classes there. |
| 218 · Hölder and Minkowski | Construct the norm-one conjugate-power test attaining Hölder. Compare exact \(L^p\) triangle costs for disjoint indicators. | Determine and attain the sharp restricted integral bound on a set of positive finite mass. |
| 218 · Completeness | Generalize the summable-increment calculation to a norm-tail bound for series. An expanding-support positive series is pointwise summable while its \(L^1\) norms diverge. | Quantify the union of future error sets and prove a.e. convergence of the full sequence under a geometric norm bound. |
| 218 · Approximation and comparisons | Choose tail cutoff, support band and rounding width separately, with numerical tolerance for \(x^{-1/4}\) in \(L^2\). Show finite-measure support prevents \(L^\infty\) approximation of the constant function on an infinite space. | Verify sharpness of the finite-measure inclusion by a constant function, including \(q=\infty\). |
| 219 · What happens to the error sets? | Local convergence along a countable finite-mass exhaustion gives one a.e. subsequence and uniqueness. An infinite one-point mass isolates the role of the hypothesis. A separate weighted singleton sequence converges pointwise and globally in measure while its full sequence fails almost uniform convergence. | Characterize global and local convergence in measure on counting measure by uniform and pointwise convergence respectively. |
| 219 · When convergence in measure controls integrals | Check all three cutoffs from an integrable majorant and from a finite-measure power bound, with precise control of small amplitude and high tail. | Obtain \(L^r\) convergence for \(1\le r<p\) from a uniform finite-\(p\) bound and convergence in measure. |
| 219 · Approximation by continuous functions | Compute the exact integral error of four linear distance-cutoff transitions, then relate the mesh scale to the rate of change and error-set measure. | Preserve nonnegativity and unit integral under \(C_c\) approximation, with a factor-two error bound. |

All 13 solved problems were appended within the existing Practice
sections. Added worked passages use unnumbered paragraphs. Existing
chapter/section headings, label declarations, source responsibilities, and
Needspace directives were checked unchanged. The order and numbering of
pre-existing numbered environments stay the same.

## Reference evidence and coordinated dependencies

- 216 uses Axler's author edition §§9A–9B, especially 9.23 and 9.30 (PDF
  282 and 284), for the supremum and Jordan proof patterns. The initial
  divergence obstruction refers back to the thickened Ch. 213
  alternating-harmonic passage, so the long calculation appears once.
  The numerical measures use original data and derive from the definitions.
- 217 uses Axler 9.32–9.36 (RN theorem PDF 287), Fremlin 232E–232H
  (Ch. 23 PDF 9–10), and the authorized Folland §3.2 discussion
  (printed pp. 90–91). The explicit residual test, reciprocity on the
  positive region and mixed-atom exercise follow the established
  hypotheses and formulas.
- 218 uses Axler §§7A–7B, 7.24 (PDF 220), Fremlin 242F,
  243E, 244G–244H, and the authorized Folland §6.1 (printed pp. 181–184).
  The added estimates are derived using the book's existing Hölder,
  Minkowski, MCT and DCT.
- 219 uses Tao's authorized author manuscript §1.5 (PDF 132–145),
  especially the subsequence exercise 1.5.6, finite-measure power
  condition exercise 1.5.12 and theorem 1.5.13. Fremlin 245A
  (Ch. 24 PDF 44) gives the local distinction. The explicit cutoff
  uses the existing Euclidean Lebesgue regularity and distance formula.

No old mathematical error was corrected in the four texts. The new
proofs retain the signed finite convention, the stated reference or
target \(\sigma\)-finiteness, finite exponent hypotheses where powers
are used, and the distinction between local and global convergence
and between small-height and spatial concentration. Independent
review should verify those conditions, the new numerical solutions,
and the Ch. 213 reference before the volume is integrated. The
authorship receipts are separate from the future whole-volume PDF
and engineering checks.

## Fixed input and output fingerprints

| File | Input bytes | Input SHA-256 | Draft bytes | Draft SHA-256 |
|---|---:|---|---:|---|
| ch216.tex | 8291 | 97b2d631ac48a33250e30d5cae2084618a42e45c1a2f74e159d9688b85354a3e | 13893 | dd6d04f16acf7c65a2d366dec4af727e18bdc26f605c06426d54a415061c9cc3 |
| ch217.tex | 10976 | 88a7b8355f4b88fc7c858897d68b729166edc773ef5780baeaffab3bdb8ba0d3 | 17088 | acec0fa91d8fd7ba30540d0853773364fb3aa8ee64cf4b46a106acdae4f32a43 |
| ch218.tex | 9118 | 51ac2b746b33b44da02028ba43d0e13ed4980bfc170a3dd84d35e38b73cb5059 | 15730 | a2c170216b05f560c27ede71bee74752a3e2f8bba2a2984a16ea40ef85170e0e |
| ch219.tex | 12948 | 32ba7ef71e52d67fca84d68968d8ea6f0e6084a37d9e744f216e530a758545d2 | 19265 | 8494009864972762a5eae54ea33f3f8b678022d890689a2591dc4ebc1582c967 |
