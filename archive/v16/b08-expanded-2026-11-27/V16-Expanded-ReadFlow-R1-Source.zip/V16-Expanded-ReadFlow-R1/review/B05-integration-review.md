# V16 Expanded B-05 integration review

V16 *Measure and Real Analysis*, Chapters 208–223, expanded B single Work. The reopening covers section-by-section elaboration, proof explanations, worked examples and practice. Baseline archive SHA-256 842539760edb798d608cb55ac36539f0c44d58f4db41179a0f2a921fd0a1f7f6. Exact role model and reasoning settings remain unverified.

**PASS for B-05 integration on the frozen 18-file manuscript and remapped indices.** All teaching and practice sections have substantive additions. The placement defects identified on the first check are closed. Layout and sole final mathematical review continue as separate stages.

## Evidence

- [Baseline inventory](B05-baseline-inventory.md), [baseline section list](baseline-sections.tsv) and [integrated structural check](B05-structure.txt) record the whole reading order. [Integrated source SHA-256 manifest](B05-input-sha256.txt) identifies the 16 canonical chapter files and unchanged front/reference sources. All 18 hashes also match the [preserved B-05 sources](B05-frozen/manuscript/). The manifest SHA-256 is ef64c823b2b8901fa7ac38271a35b7aa229014f900f90d80487a649420e91957. The draft reads were checked against the integrated chapter bytes. The chapter verdicts below reflect the reviewed corrections.
- The expansion touches all 52 teaching sections and 16 Practice sections. The 68 section headings and order are preserved, and each [expanded section index](B05-frozen/coverage/expanded-sections.tsv) row identifies the correct integrated source line. The 16 Practice sections have 89 problems with 89 solutions, with 57 of those pairs added in this expansion.
- There are 57 distinct labels, all retained. All 65 chapter references resolve. The new 208→209 premeasure preview and 220→222 differentiation preview are navigational. The 223 interval comparison now follows from diameters and partitions already proved earlier in 223. Every later operative premise has an earlier landing.
- All 140 core-index responsibilities retain the baseline claims, source locators and 136 core plus four context split. The [remapped index](B05-frozen/coverage/body-locations.tsv) matches all 145 primary and secondary source anchor positions. Only their body locations moved. All 23 Folland supplement rows remain byte-identical and their B05 reviewed source comparisons remain in place. Royden–Fitzpatrick remains a cover-and-contents locator.
- Read the original B07 repairs at their new positions. Sigma-finiteness is introduced before the 209/211/215/217 uses. The Euclidean completion comparison still uses a generating relative algebra on every finite box. Local integrability precedes the weighted-Radon example and is reused in 222. The directional line-null argument still uses Tonelli twice. The exact Radon closed–open finite-error proof retains the relocated 210-09 responsibility.

## Section-level readings

| Chapters | Independent scrutiny and result |
|---|---|
| 208–209 | [208 receipt](ch208.md) and [209 receipt](ch209.md). Observable event atoms, the cheap cover splitting failure, graph area bounds, direct tail estimates, finite premeasure continuity criterion, exact Stieltjes jump and length, and all new solutions checked. Repairs define algebra before use and specify the disjoint-union exercise's interval convention and isolated point. |
| 210–211 | [Completion and Radon receipt](ch210-211.md). Null-cell completions, finite induced-bound domain equality, dense open/small finite error, translation, weighted atom approximation, local finiteness, and Borel envelope argument checked. Null-difference wording and the roles of \(E\) and \(C\) in the splitting test were corrected. |
| 212–213 | [Measurability and integral receipt](ch212-213.md). Rational level tests, finite-real convergence sets, clipping and raw representative, simple refinement, threshold factor, extended signed integrals and the denominator cutoff for Riemann integrability all checked. The null-union line and sign/indicator wording were corrected. |
| 214–215 | [Limit and product receipt](ch214-215.md). Nonnegative geometric sums, strict Fatou, actual \(L^1\) majorant, exact power-density small-set maximum, raw-domain failure of section converse, repeated- and joint-integral distinctions and completed-factor failure were tested. The weaker corner singularity is absolutely integrable by Tonelli and the stronger one diverges in both signs despite finite repeated integrals. |
| 216–217 | [Signed and density receipt](ch216-217.md). Summable masses, Hahn deficit, minimal Jordan representation, quantitative continuity, maximal-density hypothesis use, reciprocal transfer and singular/AC coordinate computations checked. The short first paragraph of 216 now refers to the ordered-series calculation in 213 and derives a new consequence about countable additivity. |
| 218–219 | [Norm and mode receipt](ch218-219.md). Norm invariance under representative changes, optimal Hölder bound, summable series, finite value-band approximation, countable exhaustion for local convergence, general-space UI, finite-\(p\) criterion, cutoff tradeoff and normalization practice checked. The finite \(p\) and cutoff slope terms are explicit. |
| 220–223 | [Cover, differentiation and geometry receipt](ch220-223.md). Checked the sharp finite covering factor, fine-cover tails and arbitrary null remainders, minimal BV decomposition, uniform total-length control, maximal-error splitting, concentration in shrinking sets, jump loss, finite direction net, critical Euclidean normalizer, probability measure lower estimate and general Cantor gap bound. The final Ch. 221 log-density transfer is a distinct worked application: capping at \(-\log\ell\) yields the sharp length budget \(\ell(1-\log\ell)\), achieved on the initial interval. The integrand in that estimate is explicitly written with a maximum. The 222 AC product estimate is given directly in its practice solution. |

The new worked material teaches how to compute quantities, choose bounds in the correct order and test hypotheses. Common proof mechanisms recur where needed, with conclusions specific to each chapter. The 216/213 and 221/214 repetitions flagged in the earlier drafts were handled by an explicit cross-reference and a new sharp logarithmic example respectively.

## Locator defects

| ID | Earlier map reference | Correct integrated source |
|---|---|---|
| DEPTH-MAP-01, 210-08 | ch212.tex:184 / Approximating values on a finite grid | ch212.tex:244, completion representative comment in that section |
| DEPTH-MAP-02, 215-08 | ch215.tex:264 / Failures and a useful computation | ch215.tex:338, area below a graph anchor in that section |
| DEPTH-MAP-03, 216-03 | ch216.tex:136 / Jordan parts and variation | ch216.tex:188, variation-as-density anchor in that section |

The positional remap corrected all three stale secondary locators without changing claim responsibilities. Independently verified all 145 mapped positions, including heading and marker identity, against the exact source. The final B05 body-locations digest is 55092a04f23178bb9642ab60612df9bf951db57e28b5f9f3939cf61b72d665eb. The expanded section-index digest is 72917cc57ccad5a082e8bdcdaaacf3796310d185f21dfa30a099aa9153496c29.

## Handoff and remaining uncertainties

B06 receives the fixed B05 source, indices and mathematical findings. It controls font and document-build inputs, source/PDF pairing and visual inspection. Remap and verify the live chapter and anchor positions again after any line-changing pagination adjustments. The B05 snapshot preserves the earlier line evidence. The 97-page original remains the reproducible comparison, with the expanded candidate in a separate workspace. The sole strict final mathematical decision belongs to independent B07. Retain the original archive and its previous scope; the new decision is specific to the expanded copy. Exact final V15 labels, unavailable Royden–Fitzpatrick text, and runtime role metadata remain in the open register and create no mathematical premise for V16.
