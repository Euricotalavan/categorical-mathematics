# V16 expanded reading edition · B-07 independent mathematical review

V16 *Measure and Real Analysis*, Chapters 208–223. B single Work.
Sole independent thickening review for the user-authorized section-by-section
depth revision. Review date 2026-11-27. Actual model subversion and
reasoning effort were not directly observable.

## Sole B-07 final decision

**PASS** on the exact expanded source/PDF pair below. The full
section-by-section mathematical and teaching review is complete.
The one blocking added equality, the notation clarification and
source-locator findings were corrected and rechecked. The final
layout sign-off is a separate requirement for B-08.

| Final verified evidence | Bytes | SHA-256 |
|---|---:|---|
| `compiled-final/V16-Expanded-ReadFlow-R1.pdf` | 611325 | 26790fe003857f1602a37928cd9cbb59e79d10ecf083acf40414df36a58419d9 |
| `compiled-final/V16-Expanded-ReadFlow-R1-build.json` | 2973 | 85938038c3d6742251c494c7880c0b3ddec88f2fb142c31970ee88324b463051 |
| `coverage/body-locations.tsv` | 56152 | ddc3125b9c720948b549734420599283a716c911d1ddb72846d09eb786408ceb |
| `coverage/expanded-sections.tsv` | 7889 | 22fb722f2ac9ace7fde8ca8dcad0d7d92c56052c0c9adaf4296c6602081c2069 |
| `coverage/expanded-exercises.tsv` | 185 | bb21ae7cf67cadcb0c774bd87863c4c709c2d0e172f75128d3b620163e553d3e |
| `coverage/FO-addendum.tsv` | 10893 | 014665daa1986367d3e6550c85be4df7eebce5e88706e6b9378ceca046aa3509 |
| `coverage/OPEN.md` | 1300 | af3dc6656e2d129f93d518a1cb6b091cf51728d30e89f5e94fe050cd005a868f |

The canonical source root is `V16-Expanded-ReadFlow-R1/`. The
final build record supplies the per-file SHA-256, which I matched
against all 18 TeX manuscript files and all six layout inputs.
The layout file fingerprints still match the adopted baseline.
Removing only the local vertical-space directives yields the same
18 file-content digests as on the independently rechecked amended
manuscript. Coverage recheck matches all 145 actual source markers
and current section headings for the 140 fixed responsibilities.
All 68 section records resolve. The 57 manuscript labels and 65
chapter references resolve. There are 89 exercises with solutions,
57 new.

The final PDF has **138 physical pages**. I inspected the rendered
reading at physical pp. 20, 64, 66, 80, 96, 105, 112, 117, 121,
123, 132 and 134. Full-size review of the affected pages 112 and
132 confirmed the maximum notation and non-strict fiber bound.
The latter occurs beside the unchanged sharp proof. The final
build used XeTeX 0.999996, TeX Live 2025/dev/Debian, three passes,
entry `layout/study/volume-16.tex` and the recorded deterministic
settings. The build reported no overfull or blocking diagnostics.
These pairing and engineering observations are distinct from the
semantic verdict and the full layout review.

## Baseline and review method

The frozen 97-page B-08 source archive, SHA-256
`842539760edb798d608cb55ac36539f0c44d58f4db41179a0f2a921fd0a1f7f6`,
and PDF, SHA-256
`be493de4a53202c5601b6841cf7c5ff306f502cba9219a2d44eb682c906d260a`,
identify the prior approved pair. All 18 text files were compared
with their ZIP members and original build hashes. The baseline
remains recoverable and unchanged.

I prepared [baseline pacing and mathematical probes](B07-depth-audit-probes.md)
before reading the incoming candidate. I then compared each exact
manuscript file with the baseline, read every added or changed mathematical
passage and solved exercise, and reread the proof chains they use. I
checked substantive teaching evidence within the 52 teaching sections
and all 16 Practice sections. Source locations and build hashes are
verification evidence alongside the mathematical read.

The initial expansion PDF contained 139 pages, 612,426 bytes,
SHA-256 `8884251981509116350bf21a37d27d3640ac1cbd3b2eedf799ee4c2eedc77506`.
Its exact 18 text and six layout inputs were verified against its
build record. One blocking content defect in that version resulted
in a bounded return before sign-off.

## Scope and mathematical review

| Chapter | Added teaching and proof evidence checked |
|---|---|
| 208 | The three-code model computes overlaps without double counting and makes the event domain independent of the weights. The three-point outer measure shows that testing only the whole space can miss a split. Bounding a graph by thin rectangles makes two-dimensional nullity compatible with a full projection. The grid exercise checks the planar area by two squeezing sums. |
| 209 | Summable tails explain the event of infinitely many visits. The finite-cofinite pair distinguishes a merely finitely additive assignment from a sigma-finite premeasure whose extension is unique even at infinite total mass. I kept the finite-complement comparison and the premeasure's one-sided endpoint, trim and compact-subcover steps intact. The worked jump plus ramp and singleton exercise expose the right endpoint convention. |
| 210 | Reweighting the same two observational cells distinguishes domain from null ideal. The infinite trivial measure shows why the full splitting domain can exceed the completion. The finite-measure exercise proves equality of these domains under its own hypotheses. The infinite irrational example and translation exercise turn regularity into controlled symmetric-difference errors without subtracting infinite masses. |
| 211 | Atom weights with an accumulation point test the precise local-finiteness condition. The infinite-mass sandwich keeps all charged integer endpoints while sending the geometric error to zero. The Borel-to-outer construction verifies infimum, splitting, Borel envelopes and open regularity with the matching domains. Compact exhaustion and restriction to an open subspace use their correct finite and relative conditions. |
| 212 | Rational thresholds recover equality and endpoint fibers, with the middle-domain counterexample checking composition. The Cauchy test builds a measurable real convergence set. The unbounded dyadic calculation explains clipping and endpoint orientation. A common measurable null envelope and a genuinely null sandwich difference justify a raw representative even when both bounding masses are infinite. |
| 213 | A disjoint refinement computes a simple integral with (0cdotinfty). An explicit threshold example explains (c<1) in monotone minorant comparison. Uniformly small changes over an infinite-mass cell can produce infinite integral. Signed cancellation examples distinguish defined infinite values, absolute integrability and ordered series. The rational-height examples distinguish Darboux behavior under dense but differently weighted modifications. |
| 214 | Positive geometric sums give an infinite monotone-convergence limit. Alternating indicators make Fatou strict. A binomial estimate produces the integrable common bound on an infinite interval, and the spike envelope proves a bound cannot always exist. The finite-set and small-set estimates act on different parts of the worked example. The signed Fatou and integrable-multiplier exercises give their precise lower bound or dominator before subtraction or passage to the limit. |
| 215 | The diagonal subset has Borel sections and fails product measurability. The overlapping rectangle example computes the premeasure and explains the infinite coefficient. The two corner singularities contrast legitimate Tonelli-to-Fubini reasoning and divergent joint signed integrals with finite differing iterates. The example with an incomplete Borel factor fails at every fiber, while the earlier complete-factor example fails at a single coordinate. The finite-box relative algebra and raw/completed Euclidean identifications remain intact. |
| 216 | The summable signed atoms justify regrouping and exhibit nonmonotone values on nested sets. The approximate Hahn maximizer controls wrong-sign subsets quantitatively before the exact construction. The common additive measure and mixed atomic example explain cancellation and the minimality of Jordan variation. |
| 217 | The density cutoff chooses the high-value tail before the reference-mass tolerance. The infinite target example shows where finiteness enters uniformity. The residual and positive Hahn-set discussion checks every admissibility constraint rather than only total mass. The cell density and reciprocal density computations expose uniqueness off null cells and reversal only on the positive region. Point-mass exercises separately test the reference and singular atoms. |
| 218 | A dense countable change alters boundedness of a representative while preserving every norm. The normalized Hölder extremizer and disjoint-support example separate different equality cases. The summable-norm series computes a tail norm and tests failure at (p=1). Fixed-height-band approximation controls finite support before choosing the mesh. The exercises test sharp constants and measurable atoms. |
| 219 | The countable exhaustion argument converts local convergence in measure into subsequential a.e. convergence and also shows the hypothesis needed for local uniqueness. Harmonic atoms separate global convergence from almost uniformity of the full sequence. A common integrable majorant or a finite-space power bound checks distinct uniform-integrability cutoffs. The concrete (C_c) cutoff gives both error size and transition slope. |
| 220 | The two nearly tangent balls show the factor-three obstruction and why selection order matters. The weak maximal estimate counts mass only after disjoint selection. A narrow integrable singularity has an infinite maximal value at zero. Arbitrary witnesses can be chosen after every finite selection, so the fivefold tail gives outer-nullity. The finite subfamily exercise reuses the exact original-ball coverage. |
| 221 | An inserted turning point changes the absolute partition sum and yields the normalized least monotone pair. The oscillatory example separates continuity from BV. The family-error explanation identifies the single shared length budget, and the logarithmic example computes a sharp modulus with an explicit maximum. Product and Lipschitz composition follow from the interval increment bounds. |
| 222 | The center error and surrounding average use distinct bounds. The sparse intervals show why no statement about arbitrary thinner sampling regions follows. The slow/fast interval count compares endpoint spans and the AC proof uses one budget on the uncovered gaps. The jump example identifies the lost increment. The line-null and test-function arguments retain two Tonelli applications, a countable family of directions and a finite direction net; the expanded threshold argument makes the direction choice uniform. |
| 223 | The fixed-scale interval and parity-strip calculations distinguish diameter restrictions from the limiting measure. The snowflake metric exercise checks the rescaling of both exponent and cutoff. The exact normalization needs an isodiametric estimate for arbitrary cover members and fine balls for the sharp reverse bound. The revised fiber inequality uses the original endpoints, not an assumption that the fibers are intervals. The exact Cantor tree cost remains; the alternate Stieltjes measure method provides an independently valid dimension bound and transfers to other gap ratios. |

## Return, correction and recheck

| ID and initial location | Impact | Corrected source and proof recheck |
|---|---|---|
| DEPTH-B07-01, Ch. 223, physical p. 133 in the first expansion, paragraph “Which covers give each inequality?” | The added equation asserted that the sum of the Lebesgue lengths of two compact fibers equals the sum of their endpoint spans. Two fibers each equal to ({0,1}) have total length zero and sum of spans two. The statement was false and undermined the newly supplied explanation of the isodiametric proof. | The author replaced equality with (le) and identified each endpoint span as an upper bound. Since the crossed endpoint differences sum to the two spans, their maximum is at least half the sum of the fiber lengths. This is the bound already used in the original replacement-fiber proof and leaves the compactness, volume preservation, ball bound and normalization chain valid. |
| DEPTH-B07-02, Ch. 221, logarithmic length-budget display | The local positive-part subscript notation could require the reader to match an implicit convention. | The amended display uses (max{g-M,0}), agreeing with the cap description. For (Mge0) its integral is (e^{-M}). Taking (M=-logell) gives the asserted sharp upper bound, attained on the interval starting at zero. |
| DEPTH-B07-03, coverage metadata | Baseline source lines are incorrect for the expanded manuscript. During reconciliation the baseline map reappeared at the candidate path, with 96 of 145 pointers landing away from their ID. | The regenerated map matches all 145 primary and secondary markers and heading titles on the exact amended files, including after the final spacing changes. |

The local revision leaves the foundational proof hypotheses and their
source scopes stable. After recording the independent mathematical
return, I read the B-04 author returns, B-05 integration report and
preserved baseline defect history. The earlier fixes on algebra
terminology, null differences, finite-(p) scope and removal of
repetitive examples are present. The finite-complement and Stieltjes
proofs in 209, exact closed–open Radon error in 211, relative
generating algebra and Borel graph domain in 215, local integrability
in 217, and both Tonelli transports in 222 retain their previous
accepted mathematical form.

The first corrected recompile was a 139-page, 612,467-byte PDF,
SHA-256 `23e0b884ef3f63bf3facda0c6eddefe00cf08ef556f9411a9fd5f95b35d52374`.
I verified it with all 18 amended source files and all six layout
inputs. Physical p. 113 shows the maximum in the AC estimate, and
p. 133 shows the amended isodiametric inequality and its endpoint
qualification. The section comparison also identified the original
finite-box argument at p. 66, both Tonelli transports at p. 122,
the finite-direction justification at p. 124 and the alternate
Cantor probability bound at p. 135. The map after regeneration had
all 140 unchanged responsibility records and 145 checked pointers,
SHA-256 `55092a04f23178bb9642ab60612df9bf951db57e28b5f9f3939cf61b72d665eb`.
Final exact pair and map are recorded separately below.

## OPEN and authorized scope

- Royden–Fitzpatrick is limited to the identified five-page fourth-edition
  cover and contents. Its mathematical prose and printing are unknown.
- The fixed boundary is V15 ending at 207 and V16 beginning at 208.
  V15 B02 supplies the available precise interface, and published Git
  commit `ee4d2b7e723a32c2b58961e3903391c535fb8b07` is the retained V13
  anchor. Exact published V15 theorem locators are pending. The V16
  proofs give the local starting facts they require.
- The separate Folland supplement retains the 23 fixed second
  edition/second printing rows and established edition comparisons.
  The baseline's four clearly contextual responsibilities and their
  proof boundaries stay in the same scope.
- This work reopens only the user-authorized pedagogical depth of
  V16 Chs. 208–223. Earlier frozen volumes, the original B-08 pair
  and the V0 numbering/diagnostic issues remain in their existing
  status. Exact actual model and inference effort stay unverified.

The adopted ReadFlow R1 template is artifact commit
`8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, adoption commit
`c749e4867538888d3069346fa055ac2ca834c9e1`, fixed archive
SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`,
7,007,679 bytes, Library version 3. The layout decision remains with
the independent layout role. No user decision is pending within
the math review scope. This reviewer did not edit the source,
archive artifacts or publish anything.

## Handoff

**V16-EXPANDED-B07-20261127-v1**, 2026-11-27 UTC. Sole independent
thickening reviewer to the controller for B-08, after the separate
layout decision. B-07 corresponds to original A10–12. The unique
manuscript, the final PDF and engineering pairing are fixed by the
build record above. This audit is specific to the reopened expanded
volume and leaves the earlier B-08 snapshot intact. Preserve the
evidence, the chapter boundary, and the listed limits. B-08 must
archive and verify the exact approved pair within the user's existing
authorization. No user decision is pending. Report and verdict were
delivered through the shared workspace and agent message.
