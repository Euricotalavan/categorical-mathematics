#!/usr/bin/env python3
"""Check every physical page, navigation, and embedded fonts for the V16 book."""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
import re

import fitz

CHAPTERS = list(range(208, 224))
CHECK_ROLE = re.compile(
    r'^(definition|theorem|proposition|lemma|corollary|example|remark|exercise)\s+(\d+)\.(\d+)',
    re.IGNORECASE,
)
SOURCE_ROLE = re.compile(
    r'\\begin\s*\{(definition|theorem|proposition|lemma|corollary|example|remark|exercise|problem)\}',
)


def printable_page_label(page):
    label = page.get_label()
    if re.fullmatch(r'<FEFF(?:[0-9A-F]{4})+>', label, re.IGNORECASE):
        return bytes.fromhex(label[1:-1]).decode('utf-16').lstrip('\ufeff')
    return label


def examine(pdf, manuscript=None):
    book = fitz.open(pdf)
    toc = book.get_toc()
    chapters = []
    for level, title, page_number in toc:
        match = re.match(r'^(20[89]|21[0-9]|22[0-3])\s+(.+)', title)
        if level == 1 and match:
            chapters.append({'chapter': int(match[1]), 'title': match[2], 'physical_page': page_number})
    pages = []
    problems = []
    embedded_fonts = {}
    anchors = Counter()
    # A running prose line can begin with a numbered cross-reference.
    # Count each role/number once so it cannot duplicate its actual heading.
    numbered_identities = set()
    body_chars = 0
    for i, page in enumerate(book, 1):
        texts = []
        near_white = []
        outside = []
        footer_collision = []
        unreadable = []
        bounds = page.rect + (-1.0, -1.0, 1.0, 1.0)
        lines = [line for block in page.get_text('dict')['blocks']
                 for line in block.get('lines', ())]
        footer = []
        body = []
        for line in lines:
            line_text = ''.join(span['text'] for span in line['spans'] if span['text'].strip())
            if not line_text:
                continue
            match = CHECK_ROLE.match(line_text)
            if match and '(continued)' not in line_text.lower():
                identity = (int(match[2]), match[1].lower(), int(match[3]))
                if identity not in numbered_identities:
                    numbered_identities.add(identity)
                    anchors[identity[:2]] += 1
            rect = fitz.Rect(line['bbox'])
            if rect.y0 > page.rect.height - 45:
                if ('ReadFlow R1' in line_text and i != 1) or (
                        line_text.strip() == printable_page_label(page) and rect.x0 > page.rect.width - 114):
                    footer.append(rect)
                else:
                    body.append((line_text, rect))
            if 50 < rect.y0 < page.rect.height - 45:
                texts.append(line_text)
            for span in line['spans']:
                text = span['text'].strip()
                if not text:
                    continue
                span_rect = fitz.Rect(span['bbox'])
                if not bounds.contains(span_rect):
                    outside.append({'text': text[:70], 'rect': tuple(span_rect)})
                color = span['color']
                if min((color >> 16) & 255, (color >> 8) & 255, color & 255) >= 229:
                    near_white.append(text[:70])
                if '\ufffd' in text or any(ord(c) in range(0xFDD0,0xFDF0) for c in text):
                    unreadable.append(text[:70])
        for text, rect in body:
            if any(x.intersects(rect) for x in footer):
                footer_collision.append(text[:70])
        info = {
            'physical_page': i,
            'label': printable_page_label(page),
            'text_chars': sum(len(t) for t in texts),
            'links': len(page.get_links()),
            'layout_flags': {'near_white': near_white, 'outside_page': outside,
                             'footer_collision': footer_collision,
                             'bad_unicode': unreadable},
        }
        if any(info['layout_flags'].values()):
            problems.append({'physical_page': i, 'layout_flags': info['layout_flags']})
        for link in page.get_links():
            if link['kind'] == fitz.LINK_GOTO and not 0 <= link.get('page', -1) < len(book):
                problems.append({'physical_page': i, 'bad_link_page': link.get('page')})
        for xref, _, kind, name, *_ in page.get_fonts():
            if xref not in embedded_fonts:
                embedded_fonts[xref] = {'name': name, 'type': kind,
                                        'embedded_bytes': len(book.extract_font(xref)[3])}
        body_chars += info['text_chars']
        pages.append(info)
    if [item['chapter'] for item in chapters] != CHAPTERS:
        problems.append({'chapter_navigation': 'expected one bookmark for every chapter 208–223',
                         'chapter_bookmarks': chapters})
    for chapter in chapters:
        target = book[chapter['physical_page'] - 1].get_text()
        if not re.search(fr'CHAPTER\s+{chapter["chapter"]}(?!\d)', target, re.I):
            problems.append({'physical_page': chapter['physical_page'],
                             'missing_chapter_heading': chapter['chapter']})
    if not all(font['embedded_bytes'] > 0 for font in embedded_fonts.values()):
        problems.append({'fonts': 'One or more fonts not embedded.'})
    counts = []
    if manuscript is not None:
        for chapter in CHAPTERS:
            path = manuscript / f'ch{chapter}.tex'
            source = path.read_text(encoding='utf-8')
            active = '\n'.join(line.split('%', 1)[0] for line in source.splitlines())
            expected = Counter('exercise' if role == 'problem' else role
                               for role in SOURCE_ROLE.findall(active))
            actual = Counter({role: count for (ch, role), count in anchors.items() if ch == chapter})
            if expected != actual:
                problems.append({'chapter': chapter, 'numbered_environment_count_mismatch':
                                 {'source': dict(expected), 'pdf': dict(actual)}})
            counts.append({'chapter': chapter, 'source': dict(expected), 'pdf': dict(actual)})
    return {'file': pdf.name, 'sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(),
            'physical_pages': len(book), 'chapter_bookmarks': chapters, 'bookmark_count': len(toc),
            'internal_external_links': sum(p['links'] for p in pages),
            'extracted_body_chars': body_chars, 'embedded_fonts': list(embedded_fonts.values()),
            'registered_numbered_environment_hits': sum(anchors.values()),
            'numbered_environment_counts': counts,
            'short_page_review_candidates': [p['physical_page'] for p in pages if p['text_chars'] < 420],
            'problems': problems, 'pages': pages}


def render_sheets(pdf, output):
    from PIL import Image, ImageDraw

    output.mkdir(parents=True, exist_ok=True)
    book = fitz.open(pdf)
    thumb_width, thumb_height = 315, 431
    columns, rows = 3, 2
    for start in range(0, len(book), columns * rows):
        end = min(start + columns * rows, len(book))
        canvas = Image.new('RGB', (columns * (thumb_width + 16),
                                   rows * (thumb_height + 32)), '#e5e7e7')
        draw = ImageDraw.Draw(canvas)
        for index in range(start, end):
            pixmap = book[index].get_pixmap(matrix=fitz.Matrix(.65, .65), alpha=False)
            preview = Image.frombytes('RGB', (pixmap.width, pixmap.height), pixmap.samples)
            preview.thumbnail((thumb_width, thumb_height))
            x = ((index - start) % columns) * (thumb_width + 16) + 8
            y = ((index - start) // columns) * (thumb_height + 32) + 6
            draw.text((x, y), f'Physical page {index + 1}  /  label {printable_page_label(book[index])}',
                      fill='#26393b')
            canvas.paste(preview, (x, y + 18))
        canvas.save(output / f'pages-{start + 1:03d}-{end:03d}.png')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pdf', type=Path)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--contact-sheets', type=Path)
    parser.add_argument('--manuscript', type=Path)
    args = parser.parse_args()
    report = examine(args.pdf, args.manuscript)
    args.report.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    if args.contact_sheets:
        render_sheets(args.pdf, args.contact_sheets)
    printable = ('physical_pages', 'bookmark_count', 'internal_external_links',
                 'short_page_review_candidates', 'problems')
    print(json.dumps({key: report[key] for key in printable}, indent=2))
    return 2 if report['problems'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
