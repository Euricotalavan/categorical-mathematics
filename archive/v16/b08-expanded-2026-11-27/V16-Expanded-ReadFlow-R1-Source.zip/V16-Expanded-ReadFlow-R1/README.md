# Volume 16 · Measure and Real Analysis

Expanded English reading edition, Chapters 208–223. The 52 teaching
sections retain their original order and numbering. Each Practice section
has new exercises with full solutions. A section-by-section record is
in [coverage/expanded-sections.tsv](coverage/expanded-sections.tsv).
The volume uses the adopted ReadFlow R1 layout with its original relative
font paths.

## Read and build

Open V16-Expanded-ReadFlow-R1.pdf. The physical page numbers in the
review records count the cover and front matter.

For a clean build, install Python 3, XeLaTeX and the packages loaded by
layout/study/volume-16.tex, then run from the archive root:

    python3 build.py --jobname V16-Expanded-ReadFlow-R1

On a Debian installation without an indexed system xelatex format, add
--debian-unindexed to initialize it locally. The build verifies the
supplied font files, reads the 16 chapter sources and the front and
reference matter, converges the auxiliaries and records input and PDF
checksums in build/V16-Expanded-ReadFlow-R1-build.json.

## Verify

Run python3 verify_release.py after unpacking. RELEASE-MANIFEST.json
records the exact distributed bytes. The fixed PDF and source digests
are paired in qa/build.json. The independent mathematical and layout
decisions are in review/ and qa/.

Coverage statuses and source scope are in coverage/. The line positions
in body-locations.tsv refer to this edition. The responsibility tables
retain the v1 source locators. The B-04 receipts record the exercised
hypotheses and material added in each chapter. HANDOFF.md gives the
fixed baseline and review records.
