#!/usr/bin/env python3
"""Verify bundled original font bytes and recover four faces from full newpx ZIP."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
DEP=ROOT/'dependencies'
def digest(b):return hashlib.sha256(b).hexdigest()
def main():
 data=json.loads((DEP/'FONTS.json').read_text(encoding='utf-8'))
 zpath=DEP/'upstream/newpx.zip'
 expected={f['archive_sha256'] for f in data['faces'] if f['filename'].startswith('TeXGyre')}
 if len(expected)!=1 or digest(zpath.read_bytes())!=next(iter(expected)):raise SystemExit('newpx.zip fingerprint mismatch')
 with zipfile.ZipFile(zpath) as z:
  if z.testzip() is not None:raise SystemExit('newpx.zip CRC failure')
  for f in data['faces']:
   out=DEP/'fonts'/f['filename']
   if f['filename'].startswith('TeXGyre'):
    b=z.read(f['archive_entry'])
    if digest(b)!=f['sha256']:raise SystemExit('Archive member fingerprint mismatch: '+f['filename'])
    if out.exists() and out.read_bytes()!=b:raise SystemExit('Existing font differs; refusing overwrite: '+str(out))
    if not out.exists():out.write_bytes(b)
   if not out.exists() or digest(out.read_bytes())!=f['sha256']:raise SystemExit('Font fingerprint mismatch: '+f['filename'])
 print('Verified nine original font faces; no download or system-font installation required.')
if __name__=='__main__':main()
