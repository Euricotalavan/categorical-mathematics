"""Verify every file named in the Volume 16 release manifest."""
from hashlib import sha256
from pathlib import Path
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'RELEASE-MANIFEST.json').read_text(encoding='utf-8'))
failures = []
for name, entry in manifest['files'].items():
    path = (root / name).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        failures.append(name + ': missing or outside release directory')
        continue
    data = path.read_bytes()
    if len(data) != entry['bytes'] or sha256(data).hexdigest() != entry['sha256']:
        failures.append(name + ': checksum mismatch')
if failures:
    raise SystemExit('\n'.join(failures))
print(f"PASS: {len(manifest['files'])} files in the V16 release manifest")
