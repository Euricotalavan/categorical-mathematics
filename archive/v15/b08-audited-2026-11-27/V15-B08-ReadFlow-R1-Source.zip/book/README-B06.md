# Volume 15 — Multivariable Analysis

Fixed B06 English source, Chapters195–207, 65 sections. Formal adopted ReadFlow R1. B07 is the separate, unique strict mathematical final review.

## Build

Python3, XeLaTeX/TeX Live with fontspec, unicode-math, amsmath/amsthm, tcolorbox (most), titlesec, fancyhdr, geometry, enumitem, tocloft, etoolbox, hyperref and bookmark must be installed. All11 actual font binaries and their licenses are bundled under dependencies/fonts and licenses; no host font lookup is needed.

```sh
python3 verify.py
python3 build.py --entry volume --clean
```

On this Debian runtime with unindexed TeX trees, use:

```sh
python3 build.py --entry volume --clean --debian-unindexed
```

The Debian switch creates a local XeLaTeX format under .build/format, leaving system files unchanged. The driver pins SOURCE_DATE_EPOCH, compiles until aux/toc/out converge in two to three passes, records actual package/input/font hashes, rejects unresolved references, missing glyphs, font substitution, overfull boxes and header warnings. Underfull notices require the accompanying human disposition. The driver never treats page count as a pass criterion.

Outputs: V15-Multivariable-Analysis.pdf and qa/build-volume.json. Preserve the fixed original MANIFEST.json: it covers immutable source/tool/font/license/baseline inputs. make-manifest.py creates a new snapshot only after an authorized source change. The final outer B06-FIXED.json pairs this source with one actual PDF and QA evidence.

## Protected content and local adaptation

One prose-only shortening in chapter206 removes rhetorical words from the cubical-domain introduction. All math units, labels/references, environment order and macro definitions are preserved against B05. All four accepted precision calibration blocks are byte-identical and bundled in provenance/calibration. Every other page correction is before a complete unit in layout/b06-local.tex; formal R1 layout stays byte-identical, with its original body leading/density. References furniture is changed only after a clearpage. The B05 body baseline and fixed manifest/precision report are recoverable under provenance.

Two one-word continuation tails and some long, clearly marked continuations are retained as nonblocking visual observations, not silently claimed repaired. B05's5 nonblocking SUPPORT OPEN and31 source UNKNOWN remain. The PDF/source pairing proves artifact identity, not final mathematical acceptance. Actual model/high runtime setting is unverified.
