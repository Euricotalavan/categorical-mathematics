#!/usr/bin/env python3
"""Create an explicitly authorized B06 immutable source snapshot; excludes generated QA/PDF."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
items=[]
for p in sorted(R.rglob('*')):
 rel=p.relative_to(R);name=rel.as_posix()
 if not p.is_file() or rel.parts[0] in ['.build','__pycache__'] or p.suffix in ['.pdf','.png','.pyc'] or name=='MANIFEST.json':continue
 if rel.parts[0]=='qa' and name not in ['qa/B05-INPUT-RECEIPT.json','qa/layout-patches.json']:continue
 items.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
m={'id':'V15-B06-SOURCE-R2','stage':'B06 layout source for separate B07 mathematical final review','b05_manifest_sha256':'cd9c5a666b63b352e2b54786f87ebf9cec989714aeadddaf69df2953ef2e7d5c','template_zip_sha256':'5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732','files':items}
(R/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');print('Source manifest written:',len(items),'files')
