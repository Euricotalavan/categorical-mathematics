#!/usr/bin/env python3
"""Verify fixed B06 source, formal R1 layers, B05 receipt and four exact calibration blocks."""
from pathlib import Path
import hashlib,json,sys,re
from build import check_input
R=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'MANIFEST.json').read_text());errors=[]
for x in m['files']:
 p=R/x['path']
 if not p.is_file() or p.stat().st_size!=x['bytes'] or h(p)!=x['sha256']:errors.append(['source-mismatch',x['path']])
for name in ['layout/study/readflow-layout.tex','layout/shared/style.tex']:
 if h(R/name)!=h(R/'provenance/r1-baseline'/name):errors.append(['baseline-drift',name])
for n in range(195,208):
 if f'\\input{{chapters/ch{n}.tex}}' not in (R/'volume-15.tex').read_text():errors.append(['missing-chapter-input',n])
cal=[]
for p in sorted((R/'provenance/calibration').glob('*-draft.tex')):
 ch=p.name.split('-')[0];ok=p.read_bytes() in (R/'chapters'/f'ch{ch}.tex').read_bytes();cal.append({'path':p.name,'sha256':h(p),'verbatim_in_chapter':ok})
 if not ok:errors.append(['calibration-block-drift',p.name])
received=check_input();errors.extend(received['errors'])
print(json.dumps({'files_checked':len(m['files']),'calibration_blocks':cal,'errors':errors,'verdict':'PASS' if not errors else 'FAIL','scope':'source integrity and exact preservation only; B07 mathematical verdict separate'},indent=2));sys.exit(bool(errors))
