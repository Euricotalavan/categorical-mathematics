# V15 B-05 整卷獨立精修正式回執

交接 ID：`V15-B05-PRECISION-20261127-R1`。角色：獨立精修 → 主控。方案：B 單一 Work；階段：B05 章級／全卷整合，對應原 A 擴充、打厚、精修逐節完成後的整卷整合門檻。日期：2026-11-27。

**結論：原固定 v1 有界退回；修正固定 R1 接受，可交 B06 排版。** 此結論限本報告核定的 R1 SHA，不是 PDF／排版驗收，也不是 B07 打厚唯一整卷終審或封存授權。正文、逐節證據、來源責任範圍與整合差分均已實讀；工具定位與雜湊只作附加核驗。

## 一、接收確認與唯一正文

原唯一輸入 `v15-run/b05-fixed/B05-FIXED.json`，SHA-256 `190bc45f68ab745deca9e3e40bc493326c7911bc08938f79375396a24f7be87b`，ID `V15-B05-FIXED-20261127-v1`。已實讀完整 manifest；71 檔的 bytes 與 SHA 全部重算一致。原母表 `V15-reviewed-coverage.tsv` SHA `46f2bc6d9f56a284eee67be19e51c93669eb7830642300c4c8d9bf5c60324673`，結構表 SHA `1e3f6a62f51fdfb2ae9a4afb7d156b7eef2706949355c7e7a9fe72f0e3623ee9`，review-evidence SHA `411ffad074245714e93dfd5be45718200351a9e6018d63350d920d8c56c4bfe8`，199–207 回表 SHA `590afee050434166d6c2081cc1b883be217f77cfd958f41ab5ffb79a654c4728`。

順讀先依 v1 的 195→207 全部正文、65 節，包括每個定義、命題、證明、例題、練習及解答；工具截斷的 196/197 來源清單、198 尾段、199 開頭、203.3 段均另行補讀，沒有以截斷輸出冒充全讀。再依主控授權讀 205 修正隔離候選及 R1 差分。

本次接受的唯一後續正文為 `v15-run/b05-release/book`，由 `v15-run/b05-release/B05-FIXED-R1.json` 固定：

- ID `V15-B05-FIXED-20261127-R1`。
- manifest SHA-256 **`cd9c5a666b63b352e2b54786f87ebf9cec989714aeadddaf69df2953ef2e7d5c`**。
- 71 檔重新實算，bytes／SHA 全數一致；未修改任何 `b05-fixed` 檔。
- R1 對 v1 僅四份檔內容改變：`book/chapters/ch205.tex`、`V15-reviewed-coverage.tsv`、`review-evidence.tsv`、結構索引。原 `book-structure-b04.json` 更名為 `book-structure.json` 並重建；其餘來源 ID、邊界與正文保留。
- R1 母表 SHA `9ba6332e66d9ca0db764b4aabac29a5dd710d07b1aafa9e2b911b52cd6f8e367`；990 ID 集合與 B01 完全相同。

13 章固定 SHA 如下；除 205 插入橋段外，正文與順讀的 v1 完全一致。

| 章 | bytes | R1 SHA-256 |
| --- | ---: | --- |
| 195 | 26865 | db9354e842b593d3ded012aef4916be123fc5ef05499593304db92f84fd99f21 |
| 196 | 33627 | 5a1e38347041b3c8539c136c6b6c54498e96ada94afc176c97848d2800910171 |
| 197 | 24560 | ef1cf3bc42ebce1adf7dc6553817fdd7136265b252598ccef950486338d19f0b |
| 198 | 33619 | ee86202971302f330e6991744a627902f94276544c75ece9df15e9b13cb5ba8c |
| 199 | 27400 | a94c6502b62e15da39404bd85d77eb812af656b69af19849a50ec931a98e3bda |
| 200 | 30548 | be7edd10434aac0add660a20edb01495273f35fd9d14c72d2887701535d56721 |
| 201 | 25148 | 91bd9c304a878de63ff86ca80b8a79a9beee3b10ec6a096e78f5fd3b9a102309 |
| 202 | 35853 | 96db9d7c2480de8bf860c647324ef8bfbbfde6cb09f717b771369ebd5895169c |
| 203 | 35066 | b7f2c98f2df942653b1c20a68b438ecf0b72148a6cb08b8e122928c5e30336e2 |
| 204 | 20243 | c5c6eefab4380ebd0efcbaaee37498635018ac4ad35e1013f2bc1989eb5c7409 |
| 205 | 55762 | 3691722d20327a9f361cf0cda567ade431bd1eceefc5bedd5db5c285f05cf7db |
| 206 | 79448 | a41faa378ce147c70ca0b9c3656b1ba3301824516409c1ba95fdddc89b331b88 |
| 207 | 36223 | f5113e0fd0676aa67ec2df8fd9051c24eebc965fec95e96e6cbfc84c53f3fe41 |

## 二、逐章／逐節與章縫語義證據

`B05-SECTION-READ.tsv` 逐列記 65 節的閱讀結論、錨點與獨立證據，並非只有章名或雜湊。以下是整合風險較高的核點；各章全節均已讀。

| 章 | 主要獨立核證 | CORE 數 |
| --- | --- | ---: |
| 195 | Euclidean compactness 在任意範數等價前自證；basis 上界先給範數連續，再取球面正下界，無循環。算子範數採閉單位球，零空間可用；有限維線性有界只需 domain 有限維。三種 Lipschitz、相等與運算型別分明。 | 52 |
| 196 | 零值小量的合成、bounded bilinear、chain、非交換矩陣 Exp 的 ordered-word 二次餘項；方向／曲線與全微分反例；一般 normed 值域的 scalar-comparison mean inequality 自證，沒有默借 Hahn–Banach 或完備。偏導的輸入、順序、covector 與梯度均核。 | 91 |
| 197 | 迭代 L 空間的 slot 順序；單點二次可微對稱的矩形增量證明；局部 mixed 判準的獨立 h/k；Ck Peano 不借 k+1 階；純量 Rolle 餘項冪與向量無共同 theta；正定／半正定／零維分開。 | 39 |
| 198 | 非空完備 metric contraction、中心保球及 strict-open-ball 縮球；有限維正規化和兩個開逆鄰域；先控制逆增量才除 small-o；signed cofactor／轉置次序；獨立 compact-minimum 證與 global controls 均有效。 | 34 |
| 199 | block 的 B^{-1}A 次序、增廣逆與 fixed A×B graph equivalence；未知 block 在縮域仍可逆；regular level 與 tangent-kernel 兩包含；normal form 中新舊座標平移；constant-rank 只給局部像。存在與已知 branch 的導數分開。 | 28 |
| 200 | 全章只用 196–199：kernel 正交補上的 restriction 同構與 Dh(0)=0；pointwise differentiable f 的乘子；二階鏈式法則消掉 constraint curvature；球面 compact uniform Hessian 下界；零維可行點、邊界／equator、非緊 box 的存在證均核。 | 31 |
| 201 | Darboux 任意共同網格、arbitrary fine tagged sums 的 grid-wall slabs；先 restriction／有限 gluing，再任意 bounded face corrections；Fubini 的 lower/upper sections 與普通全截面版分開；dense exceptional 反例不任意填零。 | 43 |
| 202 | finite content vs countable null 明分；開閉覆蓋的 epsilon 預算、compact reduction、正體積盒非 null；oscillation 必取原函數；Jordan restriction、兩者已可積才可 null correction；equal-dimension null image 與 compact content-zero image 分開。 | 56 |
| 203 | 初等線性變換在各中間 parallelotope 用早先 Fubini 證體積倍率，與 nonlinear substitution 無循環；cube 的 inner inclusion 用完整 contraction，非僅 pointwise error；curved-image oscillation lemma、先證兩個 pullback 可積，再比和；compact support 用 auxiliary Jordan D，不假設支撐自身 Jordan。 | 10 |
| 204 | polar／spherical 開 cut、逆分支與 determinant；full disk/ball 的有限截斷誤差；paraboloid 的 r²≤a、重心正質量與同權重、n-ball recurrence 指數／維數、Gram 退化與 SPD diagonalization 自證。 | 7 |
| 205 | rank 不代 inverse continuity；chart transition 選 minor 再逆，Gram 用 203；intrinsic tangent／map／field transition 有 Jacobian；boundary extension、full tangent vs inward cone、outward-first signs；finite/countable partition、boundary overlap cutoff、共同乘積分割的 unsigned area 良定性。R1 叉積橋另核。 | 43 |
| 206 | Alt／shuffle 正規化與 associativity、increasing-index basis、minors；d² 與 d pullback 的正則性；compact support/chart sign/global partition derivatives；cubical map 與 image、face signs、boundary²=0、chain Stokes；corner cone／face 內在性、換圖 cutoff 與逐面 FTC；flux／classical theorem、有限光滑同倫、radial primitive。 | 68 |
| 207 | arbitrary normed space 的 bounded derivative；complete Y 已足供 L(X,Y)，X 可不完備；Dini 比較；uniform-q contraction、End(X) 的 Neumann 級數、inverse order、Banach product implicit；既知連續 branch 的吸收證；function parameter 與 unknown 同在 X，量化常數／residual／三次餘項。 | 27 |
| 合計 | 每 ID 落點、原條件與本輪章／節證據見獨立機讀表。 | 529 |

### 高風險章縫

1. **196/197→198/199→200**：198 的導數線段估計、Ck 規則、matrix inverse 與 complete finite ball 已先備；199 的產品鄰域、切空間與正則水平集均在 200 前建立。200 的 constrained Hessian 自己寫出二階 chain 計算與局部圖同胚，不依賴 205 的流形定義或 207 Banach 定理。
2. **201→202**：201.4 只先證矩形基底；原 postponed 五 CORE 必須到 202 才閉合。201.5 對未定義 countable-null 小量只作清楚預告，沒有把後章結論當本章證明。現有跨章 ref 只有這兩個明示 postponed 落點。
3. **202→203**：202 給獨立的 null-image／Jordan-image 與普通 Riemann criterion。203 線性 volume 使用這些幾何工具及 201 Fubini；未先用欲證的 nonlinear theorem。203 不借 206 forms 或 V16 Lebesgue theory。等維／緊集／closure⊂U 不被刪除。
4. **203→205/206**：205 Gram area overlap、206 signed coefficient overlap 都把 compact support 放進 auxiliary finite Jordan neighborhood，再用 203；true-boundary cutoffs 的 source 和 target strip 誤差各證趨零，沒有直接假稱 half-space substitution 已證。205 全局 unsigned integral 放在 partition 證明後；206 的 signed integral／Stokes 不循環支援 203。
5. **205→206**：原缺叉積先備由 R1 補；206.5 中 beta_F(v,w)=F·(v×w)、v×w=dA(v,w)N 由 scalar triple identity、正向 orthonormal basis 與雙線性得到。205.4 的 T=N×nu 與 nu×T=N 正確，unsigned ds 與 signed one-form 不混用。Corner regular faces 與 scalar integrals 已另外定義並證換圖，不只刪低維集合。
6. **199→207 回接**：199-022 完整 Banach block implicit 由 `thm:207-implicit`；199-026 uniform contraction continuity／parameter derivative 由 `cor:207-parameter-fixed-point`；199-008 一般 normed space 既知 branch 單點導數由 `prop:207-existing-branch`。前兩個需要的完備條件在 207 明列；第三個完全不需完備。199-025 未採的較弱 existence 不因導數公式而獲存在性。

### 五個 201 跨章 CORE 的逐項替換

| ID | 正式落點 | 本輪實核證據 |
| --- | --- | --- |
| V15-201-030 | prop:202-jordan-graph | compact Jordan base，兩個連續 graph 加 boundary(A)×[a,b] 的 finite content-zero，給 exact region 及 inner/outer integral。 |
| V15-201-031 | 同上及其完整 proof | f 在 compact region continuous，section extension 每點可積，Fubini 可用；inner integral 相對連續的 overlap/endpoints estimate 仍成立。 |
| V15-SP-I-024 | prop:202-region-fubini；ex:202-square-minus-disk | 不是只補一般定理：實例 E 的 vertical slice 寫出兩段 [-1,-sqrt(1-x²)] 與 [sqrt(1-x²),1]，x=±1 端點重合零積分；兩個 inner integrals 正確。 |
| V15-SP-I-063 | lem:202-bad-sections-null | indicator_C 整體 integral 0，上 section-integral u 可積非負且 integral 0；{u>0} 才是 exceptional set，由先前 zero-integral lemma 得 null。 |
| V15-SP-I-064 | 同上反例 | C=union {p/q}×[0,1/q] 用有限低分母 segments＋薄尾 strip 得 content zero；bad outer set 精確為有理數，null 但非 content zero。 |

與各章 `patches/precision/chNNN-coverage.tsv` 對齊：所有 CORE 的 label／verdict 一致，只有這五個在 201 peer 表仍保留 OPEN 的合法後置責任已以上述 202 實稿替換；沒有覆寫歷史 OPEN。SP-I-024 的舊 additivity 位置改為 general-region Fubini，有具體雙區間例支援。母表未重複追加同一來源 ID。

## 三、具體發現與 R1 差分重核

### B05-P01：205 第一次叉積前無明確定義（已解）

- 原文／位置：v1 `ch205.tex` 約396行 `|a×b|²`，其後只說展開三個分量；同章803行用 `nu×(N×nu)=N`。195–204 無座標叉積定義。V3 候選不得當作已核既學；已查候選68/70也沒有可承接的三分量定義。
- 影響：學生不能只靠已讀正文定義叉積並驗 Gram／orientation／flux；因此原 v1 是有界退回，不以「通常會」代先備。
- 改後：擴充依主控授權另寫 `b05-review/ch205-r1.tex`，先加 `def:205-cross-product` 與 `prop:205-cross-identities`。定義三個有次序的分量，證 scalar triple=columns determinant、Gram 平方、perpendicular／independence 與 a×(b×c)=b(a·c)-c(a·b)。
- 重核：全部新增短證逐式正確。first-component 展開兩項的符號與 cyclic permutation 正確；orthogonal unit N/nu 得 nu×(N×nu)=N 及 |N×nu|=1。插入後所有205.2/205.4/206.5下游依賴閉合。
- 檔案核：R1 205 為55762 bytes，SHA `3691722d20327a9f361cf0cda567ade431bd1eceefc5bedd5db5c285f05cf7db`。新增段2153 bytes、56行；刪去這一段後與原53609 bytes的205逐 byte相等。Diff SHA `095c61bb5acd8040baddc2c881c15858e93e7da74f5e77ea74b08e706f5a584a`。故只改先備，不改原命題條件、證路或範圍。

### B05-P02：199-008 覆蓋表遺留 OPEN（已解）

- 原位置：母表仍指 `prop:199-continuous-branch`，該章只證 Euclidean 版本，所以原 OPEN 有其歷史理由。
- 真正落點：207.4 `prop:207-existing-branch`（R1 line576）。P/X/Y merely normed；u 已知在開參數鄰域連續；F 只在圖上基點全微分；unknown block B 與 B^{-1} 有界。
- 證明核：方程給 0=Ah+B eta+r(h,eta)；u 連續使兩增量趨零，先固定 epsilon 使 ||B^{-1}||epsilon≤1/2，再把 eta 項移左，得 eta=O(h)。回原 full small-o 而非固定 epsilon，才得 r(h,eta)=o(h) 並推出 -B^{-1}A。零空間與零算子不產生除零，因安全 epsilon 用1+norm。
- 作用：完整符合 B01 該 SUPPORT 的一般 normed-space 責任，可 transfer COVERED。這只改表與位置；正文未改，不獲得未知 branch 存在定理。
- R1 母表共有35列變動；34列只是205後續新行號，唯一語義變動是本 ID 的 OPEN→COVERED、label/file/evidence轉207。review-evidence 只改本列；原990 ID與分類不變。

## 四、全表範圍、OPEN／UNKNOWN 的正式處置

本輪把 B01 原條件／證明責任、實稿命題與 proof、各章獨立表及母表逐 ID 對齊。`B05-CORE-AUDIT.tsv` 有529列，保留 source conditions/proof responsibility、實際label/file/line、正文SHA與本輪已實讀的section證據。這是 B05 語義與定位對齊表，不是從 label 存在便推論已覆蓋，也不宣稱本輪重新逐頁讀所有來源原書。

R1 全990列正式計數：

| 原B01層級 | R1 verdict | 數 |
| --- | --- | ---: |
| CORE | COVERED | 529 |
| SUPPORT | COVERED | 150 |
| LATER | COVERED | 1 |
| SUPPORT | OPEN | 5 |
| UNKNOWN | UNKNOWN | 31 |
| SUPPORT | DEFERRED | 201 |
| LATER | DEFERRED | 73 |

唯一 LATER COVERED 是 `V15-199-022`，由207 `thm:207-implicit` 的完整 Banach block 證明承接；206 的 radial Poincare 補證不改這個來源計數。下列五項與31來源UNKNOWN **保留原狀態**，另加 NONBLOCKING 類別；沒有將未採內容偷升COVERED，也沒有以本輪接受宣稱全990責任均完成。

| 保留 SUPPORT OPEN | 已有內容／尚缺範圍 | B05 分類理由 |
| --- | --- | --- |
| V15-YU-D060 | 199／205的full-rank level set、space curve／cylinder／sphere、tangent與normal具完整證；未採維1/2/n−1的系統命名目錄。 | 非阻塞的未採支持；已採證明不用該名詞目錄作先備。 |
| V15-YU-D064 | 199有moving-root例；一般simple-root及全異實根順序、simple eigenvalue依參數之完整定理未寫。 | 非阻塞；不把單例當全定理，後文未援引該更廣結論。 |
| V15-YU-D070 | 205 product charts已給部分支持；ambient diffeomorphism、graph、逐式constraint closure整套練習未完整採用。 | 非阻塞；199／205採用的局部判定都有自己完整coordinate proof。 |
| V15-YU-D072 | 205 intrinsic maps/differentials按chart定義並證良定；general submanifold-target local ambient extension equivalence未證。 | 非阻塞；200只處理已給ambient f的限制，不假定更廣extension theorem。 |
| V15-YU-D082 | 200 two-point convex／strict convex、supporting inequality及C² Hessian判準有證；finite Jensen induction和nondifferentiable例目錄未採。 | 非阻塞；box存在與乘子有獨立證，不靠未證finite Jensen。 |

31 UNKNOWN 全列 `B05-RESIDUAL.tsv`，逐 ID 保留原 evidence。其作用分三類：

- 未讀原來源／窗口及歷史索引：各 Shifrin 未讀責任、舊Spivak preview、MIT/OpenStax窗口、SP-G063、Yu-R44缺號、Yu-D092不得由簡短注記代完整Banach proof。採用的其他來源與自給證明不會改寫這些閱讀史。
- 原式／型別／條件問題：LS bounded-below逆的型別、curve偏導基底rank、Taylor餘項冪、Cramer符號、implicit j範圍、critical-branch正則、Jordan inner/outer方向與boundedness、角度／Gaussian係數、MT外積正規化、Freed operator類型。正文採明確安全版本且有獨立證；不冒稱原書原式已正確或原source status已解除。
- 原推論過廣：同影像曲線總體只差一符號、graph作指定coordinate function自動smooth、vector field漏Jacobian、nested boundary integral未加closed、Borel/Lebesgue可測混用。正文用反例／修正版或明示不建構該理論，未把疑義當證明。

這31項目前都沒有造成已採定理的未知必要前提；因此是來源史／未採範圍的非阻塞保留。若後續新增依賴它們的敘述，必須重新核來源和正文，不沿用此分類。

證法替代按終結論與明示範圍核：203線性volume用elementary/Fubini，不聲稱LS原spectral proof重演；206外積結合性用完整shuffle三分組，沒有默用SP-G004的Alt absorption引理，也不宣稱該原proof技術引理已另立。一般非緊絕對可積形式、任意Riemannian metric、usual continuous simple-connectivity正則化等較廣版本未被當成現稿定理；本卷採embedded induced-metric、compact support及明列finite smooth path/homotopy範圍。

## 五、附加機核、檔案清單與交出門檻

語義順讀後另查：R1共有459個不同label，無重複；187個ref/eqref均可解析。唯一跨章前指是201對202兩個明示後置結果，沒有隱藏的200→205、203→206/207前借。529 CORE全有真實落點，原B01 ID集合不變；五201替換沒有抹去peer原OPEN，199008轉移不動正文。

本角色產物均在 `v15-run/b05-review/`：

| 檔案 | bytes | SHA-256 |
| --- | ---: | --- |
| B05-SECTION-READ.tsv | 14041 | a24a1d5aab7022c7a2dbbd622024b6581d7a5c00650dc799aab625a1dcf760f2 |
| B05-CORE-AUDIT.tsv | 335648 | 43b6fd3b13270574b0fc247f4ea5558a1b872d6446e998e67eba368ea3b0a297 |
| B05-RESIDUAL.tsv | 11858 | 270cb8a48e0c41898156c99a0143fe598e918764c709a9b2d71301c281781b39 |
| B05-CHANGES.tsv | 801 | 314db69aedfa6300e9dc9ea31c8a34605dcb1adc4d4b39b0dc24e3c72c442ffa |

本報告自身hash與以上附檔再列 `B05-PRECISION-SHA256SUMS`；不在本報告內製造自我hash循環。205候選與diff由擴充產出，已被R1正式收錄並經本角色獨立核。

**下一步**：主控可固定接受上述R1，再交排版按正式ReadFlow R1處理B06。唯一正文是release/book；review原稿、math/precision章級候選、calibration與V3候選都不替代。排版改動後須出新manifest、source/PDF配對與可恢復證據，交打厚唯一嚴格終審；有任何語義／公式變更按問題回本角色與打厚複核。

**通過條件與禁止重做**：本B05語義門檻已通過於精確R1，不因此重啟B01來源擷取、重排章號、解凍V14或另卷，不修改分卷／工具ZIP或把UNKNOWN抹除。原v1退回史及B03/B04已修項保留。頁數／PDF渲染／全頁排版QA尚非本輪產物，不以459labels／71hash通過代替。

現行B方案依已授權v4與B單一Work；正式模板依已採納ReadFlow R1 artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`。Git公開頭`ee4d2b7e723a32c2b58961e3903391c535fb8b07`只到V13；V14 B08私人核定封存版為179–194既學基線，不能假稱公開Git已發V14。模型／High實際設定本角色未核實，不以文字假稱已切換。歷史16主題／22章映射及六全局門檻UNKNOWN仍保留，與本次V15限界接受分開。

交出狀態：**正式接受R1；無尚待修正的B05阻塞項；5支持OPEN與31來源UNKNOWN按上文保留為非阻塞；B06／B07待各自執行，不代簽。** 本回執檔案已落盤並回送主控；不把產出文案等同外部送達或Library已封存。
