#!/usr/bin/env python3
"""Portable V15 volume driver, gated on an explicitly received B05 fixed source."""
from pathlib import Path
from b07_repairs import validate_b07_repairs
from audit_destinations import write_audit
import argparse,hashlib,json,os,re,shutil,subprocess,sys
R=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check_input():
    receipt=R/'qa/B05-INPUT-RECEIPT.json'
    if not receipt.is_file():return {'status':'AWAITING_EXPLICIT_B05_RECEIPT','errors':['qa/B05-INPUT-RECEIPT.json absent'],'scope':'B06 preparation only; no volume compilation authorized by this driver'}
    d=json.loads(receipt.read_text());errors=[]
    manifest=R/'MANIFEST.json'
    if manifest.exists():
        for item in json.loads(manifest.read_text())['files']:
            z=R/item['path']
            if not z.is_file() or z.stat().st_size!=item['bytes'] or h(z)!=item['sha256']:errors.append('Fixed source manifest mismatch: '+item['path'])
    if d.get('stage') not in ['B05','B-05']:errors.append('Receipt is not B05')
    if not re.fullmatch('[0-9a-f]{64}',d.get('pinned_manifest_sha256','')):errors.append('No pinned B05 manifest SHA256')
    rows={x['path']:x for x in d.get('content_files',[])}
    required=[f'chapters/ch{n}.tex' for n in range(195,208)]+['references.tex']
    for name in required:
        if name not in rows:errors.append('B05 receipt missing '+name)
    b07=validate_b07_repairs(R,rows);errors.extend(b07['errors'])
    ledger=R/'qa/layout-patches.json';patches=json.loads(ledger.read_text()).get('patches',[]) if ledger.exists() else []
    for name,x in rows.items():
        p=R/name
        if Path(name).is_absolute() or '..' in Path(name).parts:errors.append('Unsafe relative path '+name);continue
        if not p.is_file():errors.append('Missing fixed content '+name);continue
        if h(p)!=x['sha256']:
            accepted=[z for z in patches if z.get('path')==name and z.get('b05_sha256')==x['sha256'] and z.get('current_sha256')==h(p) and z.get('category') in ['L','E'] and z.get('review')=='VERIFIED' and z.get('role')=='editor' and z.get('basis')]
            original=R/'provenance/B05-fixed'/name
            if name not in b07['allowed_paths'] and (not accepted or not original.is_file() or h(original)!=x['sha256']):errors.append('Changed B05 content lacks B06 L/E provenance or exact authorized B07 repair chain: '+name)
        if 'V15-TEMPLATE-STUB' in p.read_text():errors.append('Template stub remains: '+name)
    if not (R/'volume-15.tex').is_file():errors.append('volume-15.tex absent')
    return {'status':b07['status'] if not errors else 'B07_INPUT_BLOCKED','errors':errors,'compile_authorized':b07['compile_authorized'] and not errors,'b07_repair_chain':b07,'pinned_b05_manifest_sha256':d.get('pinned_manifest_sha256'),'scope':'Exact B05/B06 provenance and permission for B07 review build only; mathematical acceptance remains pending'}
def main():
    p=argparse.ArgumentParser();p.add_argument('--entry',choices=['volume'],default='volume');p.add_argument('--check-only',action='store_true');p.add_argument('--clean',action='store_true');p.add_argument('--debian-unindexed',action='store_true');p.add_argument('--max-passes',type=int,default=3);a=p.parse_args()
    received=check_input()
    if a.check_only:print(json.dumps(received,indent=2));return
    if received['errors'] or not received.get('compile_authorized',False):print(json.dumps(received,indent=2));sys.exit(2)
    out=R/'.build/volume'
    if a.clean and out.exists():shutil.rmtree(out)
    out.mkdir(parents=True,exist_ok=True);(R/'qa').mkdir(exist_ok=True)
    env=os.environ.copy();env['SOURCE_DATE_EPOCH']='1795737600';env['FORCE_SOURCE_DATE']='1'
    if a.debian_unindexed:
        env['TEXMF']='{/usr/share/texlive/texmf-dist,/usr/share/texmf}'
        fmt=R/'.build/format';fmt.mkdir(parents=True,exist_ok=True);env['TEXFORMATS']=str(fmt)+os.pathsep;env['TEXMFVAR']=str(R/'.build/texmf-var')
        if not (fmt/'xelatex.fmt').exists():
            q=subprocess.run(['xetex','-ini','-etex','-jobname=xelatex','-interaction=nonstopmode','-output-directory='+str(fmt),'*xelatex.ini'],cwd=R,env=env,text=True,capture_output=True)
            (fmt/'initialization.txt').write_text(q.stdout+q.stderr)
            if q.returncode:sys.exit((q.stdout+q.stderr)[-5000:])
    previous=None;converged=False
    for run in range(1,a.max_passes+1):
        cmd=['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder','-output-directory='+str(out),'volume-15.tex']
        q=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);(out/f'pass-{run}.txt').write_text(q.stdout+q.stderr)
        if q.returncode:sys.exit((q.stdout+q.stderr)[-5500:])
        state=[h(out/('volume-15.'+e)) if (out/('volume-15.'+e)).exists() else '' for e in ['aux','toc','out']]
        if run>=2 and state==previous:converged=True;break
        previous=state
    log=(out/'volume-15.log').read_text(errors='replace')
    hard=re.findall(r'Missing character:.*|Undefined control sequence.*|LaTeX Warning: Reference.*|LaTeX Warning: Citation.*|LaTeX Warning: There were undefined.*|.*multiply-defined.*|.*destination with the same identifier.*|LaTeX Font Warning:.*',log)
    over=re.findall(r'Overfull \\[hv]box[^\n]*|Package fancyhdr Warning[^\n]*',log);under=re.findall(r'Underfull \\[hv]box[^\n]*',log)
    loaded=[]
    for line in (out/'volume-15.fls').read_text().splitlines():
        if line.startswith('INPUT '):
            z=Path(line[6:]);z=z if z.is_absolute() else R/z
            if z.is_file():loaded.append(z.resolve())
    loaded=sorted(set(loaded));local=[{'path':str(z.relative_to(R)),'sha256':h(z)} for z in loaded if z.is_relative_to(R) and not z.is_relative_to(R/'.build')]
    external=[{'path':str(z),'sha256':h(z)} for z in loaded if not z.is_relative_to(R) and z.suffix in ['.sty','.cls','.ldf','.def','.fd','.otf','.ttf']]
    fonts=[{'path':str(z.relative_to(R)),'sha256':h(z)} for z in sorted((R/'dependencies/fonts').glob('*')) if z.is_file()]
    pdf=out/'volume-15.pdf';destination_audit=write_audit(pdf,R/'qa/destinations');rec={'entry':'volume','status':'B07 repair candidate submitted for re-review; not B07 pass','input_receipt':received,'converged':converged,'passes':run,'expected_two_to_three_passes':run in [2,3],'xelatex_version':subprocess.check_output(['xelatex','--version'],text=True).splitlines()[0],'destination_alignment_issues':destination_audit['issues'],'chapter_section_toc_destinations_checked':destination_audit['bookmarks_checked'],'hard_diagnostics':hard,'overfull_or_header_diagnostics':over,'underfull_diagnostics':under,'pdf_bytes':pdf.stat().st_size,'pdf_sha256':h(pdf),'local_inputs':local,'configured_font_file_hashes':fonts,'external_package_inputs':external,'source_manifest_sha256':h(R/'MANIFEST.json') if (R/'MANIFEST.json').exists() else None}
    (R/'qa/build-volume.json').write_text(json.dumps(rec,indent=2)+'\n')
    if not converged or hard or over or destination_audit['issues']:print(json.dumps({k:v for k,v in rec.items() if k not in ['local_inputs','configured_font_file_hashes','external_package_inputs']},indent=2));sys.exit(2)
    shutil.copyfile(pdf,R/'V15-Multivariable-Analysis.pdf')
    print(json.dumps({k:v for k,v in rec.items() if k not in ['local_inputs','configured_font_file_hashes','external_package_inputs']},indent=2))
if __name__=='__main__':main()
