# V15 Multivariable Analysis｜B-07 獨立打厚初審

## 固定件與初審判定

- 本卷採 B 單一 Work，Chapters 195–207。角色是本卷唯一的 B-07 數學終審。此件固定對應進入 B-07 的 B-06 R2，第三篇排版採正式 ReadFlow R1。
- **初審判定：FAIL，退修後須由同一 B-07 重核。** 至少一處正式證明對所聲稱的定義域不成立。另有待補的 CORE 構造、型別、用語、先備順序與電子定位。原 R2 不具備 B-08 通過條件。
- `v15-run/b06-candidate/B06-FIXED.json` SHA-256 `04d9499e356621302914a1c61f942019a825dc4136401092f71821ee3a4502c8`。
- `v15-run/b06-candidate/book/MANIFEST.json` SHA-256 `5d224001384c6ae0d05c4f1af28d77cc509f931d9d7a12e02ba7c6808c0f251e`。93 項逐一比對 bytes 與 SHA-256，無差異。
- `v15-run/b06-candidate/book/V15-Multivariable-Analysis.pdf` SHA-256 `67bb40d1e56e539d115c4f42bdc18b4eb9423929a8230bf4124e687c12d82720`，940453 bytes，207 頁。物理頁碼自封面為 1，正文印刷頁碼為物理頁碼減 4。
- 母 `v15-work/b01-package/V15-source-responsibilities.tsv` SHA-256 `93111e5ff978a19eb261802c734b6221254641ab96ae5dea6f8d2e619cc8d05f`。當版 `v15-run/quality/V15-B06-Coverage.tsv` SHA-256 `91db951536816b5c424c9d5cb56351b874eef0afd0b6feff589b7461b0c74289`。兩表 990 ID 一一相同，章責任、類型、主題與上游狀態逐一核對。529 CORE 及 151 其他標作 COVERED 的條目，在指定檔案、行、標籤層面均存在。此計數不代表全部數學責任已完成。

## 缺陷與重核條件

| 編號／程度 | 原文與確切位置 | 影響與波及 | 要求修正與重核 |
|---|---|---|---|
| B07-01／證明缺口，阻塞 | Ch205:1032–1059，`cor:205-abstract-volume-orientation`，PDF p155。「In positive dimension take a cover by positive charts」。適用域明列 possibly with boundary。Ch206:954–959，PDF p175，反倒正確指出右端點半線座標必須為負。 | 取遞增定向的 `[a,b]`。在點 `b`，標準 `H¹=[0,∞)` 圖的正座標速度指向區間內部，其導數為負，因此不存在這種正圖覆蓋。阻塞抽象定向與最高次場等價證明及 V15-205-032。Ch206 的帶符號積分和 Stokes 使用任意正負 chart，證明不依賴此錯誤前提。 | 選局部常號的圖，各圖在座標基底上的係數取圖號 εᵢ。用分割一加總時，所有非零項在同一個正基上取正值。重新走一遍帶右端點區間與一般重疊過渡。V15-205-032 同時要求「同向 iff 正函數倍數」，補最高次一維與座標係數相除，為比例函數給出唯一性及其正則性。 |
| B07-02／可用定義，阻塞 | Ch206:1193–1220，`def:206-corners`，PDF p180。定義由「has coordinate domains relatively open in orthants」開始。其後直接說 regular boundary 「with the outward-first orientation」，也未在 `thm:206-corner-stokes` 之前定義 embedded orthant patch。 | 讀者無法只靠正文判斷底層拓撲／圖冊要求與嵌入的型別，也無法從未定向的 M 得到誘導定向。涉及 V15-206-019/023、`lem:206-corner-integral`、全角 Stokes、經典三式與 mapped-domain corollary。現有 local facet signs、depth 與嚴格支撐的證明可用。 | 接續 205.3–4 的 Hausdorff、second countability 與 atlas 條件。定義嵌入 orthant patch 是映到相對開像的 homeomorphism，局部 C² 擴展滿秩，指明可重用投影導數逆法與稠密內部的論證。對定向的 M 才指定 outward-first；有向圖與面積分彼此比較同一已選定向。重核各深度、局部面的轉換及 206.5 所引用的適用域。 |
| B07-03／逐點等式與積分混淆 | Ch202:387–390，`lem:202-jordan-null-correction`，PDF p102。「the difference is an integrable zero function」。 | 差可能在 content-zero 集非零。例如差取一點的指示函數。直接影響零集變值、Jordan 拼接，後續 Ch203 零延拓、Ch205 接縫和 Ch206 面積分採同一原則。定理的積分相等結論正確。 | 改成「the difference is an integrable function with integral zero」，以一點差值測試，再確認後續只使用積分為零。 |
| B07-04／先定後用 | Ch205:517–528，§205.2 的 Exercise 205.2，PDF p145。「Is its upward normal the outward conormal of its boundary?」 | conormal 所在的空間、外向與邊界需讀 205.4 才有完整定義。該參數例也沒有指定邊界。習題提問在當前順讀位置無法直接判定其型別。 | 這一題先問上向法向量是否在切平面，解答驗垂直。若保留餘法向比較，移到 205.4 正式定義之後再比較。重核 §205.2 正反例以及向 §205.4 的次序。 |
| B07-05／零維型別 | Ch205:692–707，`def:205-orientation`，PDF p148。「a top-degree functional is just a scalar with the specified sign」。 | 零維時方向是 ±，一般最高次泛函是任意實數，只有相應定向的 metric volume functional 固定等於該符號。與 Ch206 的任意 0-forms 及有號點積分需區分。 | 分開寫任意 scalar、orientation sign 和 associated volume functional。重核 Ch206 零次形式、邊界點符號與 flux 的相容性。 |
| B07-06／核心正則性介面 | Ch206:176–192、1050–1091，`def:206-form-pullback`、`cor:206-finite-regularity-stokes`、`rem:206-hypotheses`，PDF p161–162、177–178。正文只有 `C²/C¹` 足夠與 `C¹/C¹` 一般僅連續。 | 母 V15-206-024 明列一般 `C^min(j,ℓ−1)`。少了可用規則，讀者只能比對已證的特例。現有 regular-boundary 和 corners 的特例假設本身充足。 | 用拉回係數是原係數與 `DF` minors 的乘積證正度數的下界；零度是純函數複合，沒有這項一階損失。有限正則時只就圖冊可談的係數階數陳述。重核與已證 `C²/C¹` 及不擴張到裸 `C¹` Stokes 一致。 |
| B07-07／型別與必要算例 | Ch206:1413–1445、1483–1501，`def:206-vector-operators`、`thm:206-classical`，PDF p184–186。前者把 divergence 置在 oriented `ℝ³` 的定義中，後者在任意 `ℝⁿ` 的定理陳述先用 `div F`。當前未指出 wedge 不是微分分母。 | 一般 Gauss 公式的算子在陳述處只對 n=3 已定義。V15-206-027 明列識別與必要操作例。Grading 與 Euclidean flux 本身數學成立。 | 在定義先列對任意正整數 n 的 `div F=Σᵢ∂ᵢFᵢ`，curl 留在有定向的 `ℝ³`。以 `d(a dx∧dy)=da∧dx∧dy` 明示外積不是微分分母。重核 Gauss 與其他識別、`d²` 的型別。 |
| B07-08／來源要求的正反例 | Ch206:1644–1679，`thm:206-global-primitive`，PDF p188–189。證明的定理比一般連續單連通強，已如實限定。書中有角形式在 punctured plane 的例及徑向 Poincaré，但該條沒有直接給 Euclidean loop 的線性同倫或在 `S¹` 的角形式例。 | V15-206-035 的例欄明列兩例。讀者須能分辨定理的 piecewise smooth endpoint-fixed 量詞與另一個徑向命題。 | 對 `ℝⁿ` 寫 `H(s,t)=(1−s)γ(t)+sp` 並核端點固定、分片光滑。將角形式限制到 `S¹` 並回指其 `2π` 積分，說明無整圈原函數，因此所需路徑條件不成立。 |
| B07-09／算子範數型別 | Ch207:203–212，`prop:207-calculus` 後，PDF p195。「whose operator norms are bounded by」下列含 `A,y,x,C` 的數。Ch207:428–431，`prop:207-inversion`，PDF p199，`(R,Q)↦[H↦RHQ]`「has norm bound ‖R‖‖Q‖」。 | 這是每對輸入所得的值之算子範數，不是固定雙線性映射的範數；若任一變數為零，硬按字面就會錯誤推出雙線性映射為零。兩處被高階反演及 IFT 正則性使用，估計本身有正確解讀。 | 明寫「its value at … has operator norm at most …」，再將其視為雙線性有界性估計。確認下一步的 `C^j` 歸納使用的是固定有界雙線性運算。 |
| B07-10／電子 PDF 定位，交排版 | 電子書籤與 p2/p3 的 TOC links 指到 `section.197.4` p38、`section.202.3` p99、`section.204.3` p128；實際標題分別在 p39、p100、p129。來源節錨 `sec:197-4`、`sec:202-3`、`sec:204-3`。 | 紙面頁碼是正確的，電子點擊會先顯示前一節，影響找 scalar remainder、Riemann criterion、spherical chart 和所有連到該節的引用。已以 PDF 內部 named destinations、TOC annotation、實際印出的標題三方重現。 | 在不更改正式模板來源的情況核正這三個電子目的地，或在改版後確認屬原錨點移頁的問題已消失。重跑全 65 節書籤/頁面標題與紙面頁碼對照，並抽核受影響的內文引用。 |

## 已讀證據與保留

- 逐節自 Chapter 195 至 207 讀 13 個現行章檔、共 8772 行及 65 小節，讀正文各局部證明與例題，核跨章依賴。`B07-INDEPENDENT-SECTIONS.tsv` 逐節記原檔行與實際 PDF 首頁，以及本次核算的代表證據和 529 個核心位置的分布。最後頁欄以包含相鄰標題所在頁的保守頁段給出。PDF TOC 65 個標題與真實頁序逐一核對，直接渲染 p7、32、107、112、119、121、148、155、170、173、177、181、183、185、187、195、199、202、203、205；缺陷位置另用固定 PDF 的實際文字逐項回查。
- 緊 Jordan 換元的獨立高風險核對包含 `F(C)` 雙側內含的閉 cube 自映射、曲 Jordan cells 透過固定網格牆估振盪、證可積先於匹配中心 R/T 極限、零延拓完整保留 ∂K，及輔助的逆映像零集與局部 `h⁻¹(V)` 定義域。舊來源兩側估計改用現版直接定量差值，語意仍有雙向控制；這與鑑別另一個局部 proof route 分開。
- Stokes 的高風險核對包含 `(-1)^k·(-1)^{k−1}=-1`、cubical codimension-two face 的 reduced index、正 chart cube 不重複乘 sign、`∑dρᵢ=0`、真正邊界及人工邊界的 extension 區別，以及正交象限深度、face 對應、沿 edge 的 content-zero 估計、兩個 charts 的緊支撐截帶。`C²/C¹` 及 chain support 條件各自核對，問題如上表。
- Banach 高風險核對包含 invertible bounded operators 的雙側逆、Neumann 的值域完備與閉球完備的用途、`B(V₀)` 開性、固定乘積內唯一、已有連續分支先得 O(h) 再回到原始 little-oh，以及 Volterra 例的 `R, ε, q`、殘差、導數及二階近似。這些均與同版 PDF 核對。
- 核心要求按母登記主題與正文結構審閱，特別核查高風險的來源條件和必須給出的證明／例。登記上 201 責任中有 5 個條目實行落到 Ch202，§201.4–5 有銜接，兩個 Jordan Fubini、壞截面與非 content-zero 例的正文落點均讀到。多個來源共同索引一個正文命題時，以實際命題／後續證明核查。全文讀取不構成對私有來源影像逐頁重擷取。
- `OPEN` 保留 5 項 SUPPORT：`V15-YU-D060`, `V15-YU-D064`, `V15-YU-D070`, `V15-YU-D072`, `V15-YU-D082`。`UNKNOWN` 保留 31 行原樣，含未讀全文與歷史範圍，未以文字評估為已核。B01 與當版同有 356 SUPPORT、74 LATER、31 UNKNOWN。私有教材原檔與 OCR 留在來源端。
- 初審只用固定現行章檔及其入口／版面、同一 PDF、B07 scope、B01 register 和當版落點欄位。未打開 B04/B05/B06 的自評、糾錯表、修補理由或歷史證據。沒有對外傳送和封存。未重做上游取件、分卷或任一舊卷。實際執行模型與推理設定無本地可核證據，記為未核實。

## 接續交接

- 本卷 B-07 對原 B-06 R2 初審 FAIL。交還協調端分派精修／打厚（B07-01–09）與排版（B07-10）。本件和 `B07-INDEPENDENT-SECTIONS.tsv` 為可取的初審交接，尚待協調端傳遞上游歷史及修正版固定對；傳遞和接收方讀入需另有回執。
- 修訂須固定新版 source、manifest、PDF SHA-256、bytes 和頁數，附差異及更新後覆蓋位置。本人實讀偏移／改動檔與成品 PDF，對每項同時記原文、改後文字、新頁碼、直接及傳遞依賴。對未變章檔核同內容，對新頁序重核跨章請求、命題式、跳轉與改頁。
- B-08 的通過條件是本人給出針對同一新版原始檔與 PDF 的唯一明確 PASS，且 B07-01–10 的數學與電子定位證據成立。令 SHA-256、PDF 編譯、已讀語意及來源覆蓋分列。故此初審仍有開項。不要改舊件、重開凍結卷、把本件當最終決定或以編譯／已審標記替代複核。
