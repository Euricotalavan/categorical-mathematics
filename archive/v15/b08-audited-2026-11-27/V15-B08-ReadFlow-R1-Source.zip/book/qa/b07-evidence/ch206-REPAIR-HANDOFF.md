# V15 B07 Chapter 206 有界修補回執

交接ID：V15-B07-206-REPAIR-v3，2026-11-27。角色：原獨立精修，依主控指派處理B07盲讀提出的四處有界問題及主控追加的corner型別補充；方案：V15 Chapters195–207 B單一Work。實際模型/High設定未核實。此回不是新的B07通過簽核；乾淨終審由獨立角色另驗。

## 實收、唯一基線與隔離輸出

唯一基線已實際核對 `b06-candidate/book/chapters/ch206.tex`：79426 bytes，SHA-256 `68f21959185660e1ff180cab86ae8c193ea68788d1873863fe31bdb2dec3c65e`。沒有把舊B04或其他片段當唯一來源。主控交接的先前divergence修補片段 SHA `54638fc33764e6335b89e5ec9016f502a40bf38df9fb8b430555452f5c1a7bd8` 已先存為 `b07-repairs/ch206-refinement-fragment.tex`；實讀其對B06差分後保留該正確任意n定義並補齊其餘三項。

| 可取隔離檔案 | bytes | SHA-256 |
|---|---:|---|
| `b07-repairs/ch206.tex` | 83430 | `326c38ade35d041272dbe9420f83be58de0f4dc55ed1a83c67f059b35172b775` |
| `b07-repairs/ch206.diff` | 7684 | `15b8865417a9ff7746cb8730f830d0136c5809aeadf9bacc79b7329c28793509` |
| `b07-repairs/ch206-fifth-repair.diff` | 3519 | `4c6f2b86beefcb958b7680202c1b49fd5274bcd2bb03c4d1b3ca671ab7cdcaf3` |
| `b07-repairs/ch206-coverage-patch.tsv` | 2946 | `456169ffafdd850e351d393b571d2616d7add2027416f9bd3e39432aade35b25` |

本回執自身hash在傳送訊息列出。四修候選已另存 `ch206-four-repairs.tex`，81870 bytes，SHA `65d6f33e8dd6f69fa2451e4d2006088c04c6d53d7db6d8fd40ad34dd01bcf5a3`；fifth-repair.diff只對此四修版記第五修。六行coverage patch保留四修證據並追加019/023。diff以真正B06唯一基線生成，包含先前片段及本次補文的全部改動。未改B06來源/PDF配對、B06主目錄或其他章。

## 原缺口、改文與語義重核

| B01 CORE／落點 | 原缺口與影響 | 新文與實核 |
|---|---|---|
| V15-206-024，`def:206-form-pullback` 後，新稿194起 | 原只明定C1 pullback，後面C2/C1 Stokes說明不足以逐項承接一般階數損失規則。 | 在smooth local charts，ell>=1、j>=0（可∞）下，係數composition為C^min(j,ell)，DF的q×q minors為C^(ell−1)，乘積得正階C^min(j,ell−1)；零階只composition為C^min(j,ell)。已與 `prop:206-pullback-rules` 的minor公式、`prop:206-d-rules` 的C2/C1交換及 `cor:206-finite-regularity-stokes` 對讀，沒有冒推一般C1流形Stokes。 |
| V15-206-027／029，`def:206-vector-operators`，新稿1433起 | 原div只在R3 α/β/curl定義內，任意n Gauss先用而未先定n型別。 | 在R3識別前先定任意n>=1、open Omega⊂Rn、C1 F:Omega→Rn及divF=sum partial_i F_i；R3只是n=3，刪去重複局部定義。`thm:206-classical` 的全部statement與proof逐byte相同：未更動Gauss範圍、幾何、方向或證法。 |
| V15-206-027，`sec:206-5` 向量識別後，新稿1464起 | 必要操作辨識例尚缺明示，可能把形式記號誤作分母消去。 | C1 a於open R3，d(a dx∧dy)=da∧dx∧dy=(partial_z a) dx∧dy∧dz；dx/dy係數因重複wedge為零，dz移過兩項為正號。位置在d與Leibniz已證之後；說明covectors不是可消分母。 |
| V15-206-035，`prop:206-homotopy` 證後／`thm:206-global-primitive` 前，新稿1670起 | 正負必要辨識例缺Rn明示linear nullhomotopy及S1內在非exact核證。 | 基點p的loop gamma滿足gamma(0)=gamma(1)=p；H(s,t)=(1−s)gamma(t)+sp明算四邊。有限C2 pieces與端點延伸給有限C2 rectangles；piecewise smooth時亦保smooth，各共享邊同值。S1以包含iota限制舊angle form，dη=iota*dω=0；c*η=dt環積分2pi。若η=df，global C1 f:S1→R經c合成的一維FTC給0，矛盾。明說S1為manifold，不是open Euclidean domain。未使用任意continuous homotopy的正則化，也未放寬原定理的smooth-path條件。 |

第五修（V15-206-019／023）接續四修版，原B06 `def:206-corners` 沒有把抽象/嵌入流形的完整共同型別及定向前提寫齊。現明定Hausdorff、第二可數topological space、relatively open orthant到M中open U的homeomorphic charts，overlap與inverse各有C² Euclidean diffeomorphism extension。Embedded M明定subspace topology、chart在開座標鄰域的ambient C² extension及rank k。以full-rank投影P使P phi-tilde局部可逆，寫出(P phi-tilde)^−1 P psi-tilde作transition extension；互換patch給反向extension，composition在relative orthant模型上為identity，先於稠密Euclidean model interior微分再連續到faces，得到inverse derivatives，才由Euclidean IFT縮成diffeomorphism extensions。此論證從未假定模型本身無邊界。它延用205 projected-local-inverse方法，只在本定義補必要橋接，不改205。

Depth-one regular boundary先只稱C² hypersurface；只有M已定向才給outward-first。局部face/top signed integral定義前明說fix orientation，`lem:206-corner-integral` 全局兩積分helper亦明說M oriented；unsigned Gram版本仍不要求定向。原 `lem:206-corner-depth` 全塊、corner face-change既有proof、face signs及Stokes既有proof均未重寫；新修只釐清其輸入型別。所有labels、環境及編號順序維持。

六項受影響原B01條件及必要例欄已實際重讀；本TSV是這次六個受影響ID的補充，不代替全94項重新驗收。原UNKNOWN/LATER/DEFERRED及源書閱讀史不因修補清除。

## 先備、校準與支持性檢查

實讀B06 Chapter205 `prop:205-path-ftc` 的逐片chain rule/FTC、`def:205-tangent` 與 `prop:205-intrinsic-differential` 的圖間線性同構/內在映射。S1反例特別以本章pullback df及scalar FTC證，不把205的ambient-open表述直接當作內在f的假設。B06 Chapter203 `thm:203-substitution` 仍是open域C1 diffeomorphism、compact Jordan、bounded Riemann integrand、absolute determinant；本次改文不碰該換元依賴，既有signed pullback也未被替換成absolute determinant。

已對B03四個accepted-precision來源核逐byte子串：203.2 SHA `d7e3b255465de790ce696435d4f9bd7fa0ff582d0580b0a58e8094973d0183ed`、203.4 `1bd53cdb1efa3da6c3f3ccaeb5394b4f7b2646436d1cfe946404358d7752f7b5` 在未改的B06 ch203各一次；206.3 `95598a65562b995139f86c6d2f860b0407475b5e247021f6115b8932540b67b5`、206.4 `9e8c503e85b6495271877a52a3928da869b9d486b426898527e1c5de552efd91` 在本修稿各一次。兩個本章校準塊未改一byte。

ch206全部labels及順序與B06相同，五節不變，begin/end環境配對；沒有新增theorem/remark等編號環境；Gauss/Green/classical theorem與proof整塊逐byte不變。沒有改style、preamble、counter或ReadFlow R1。這些是支持證據，不是PDF視檢或數學終審。

## 後續與OPEN

已核：四個bounded問題及第五個corner型別修補均在隔離稿有實際英語增補、明確量詞/型別/正則性與必要計算。未核：新PDF/source配對、頁面換行、排版QA、乾淨B07複核與整卷通過；舊B06 PDF不可當新修稿PDF。版面採正式ReadFlow R1，artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，未自行改版。實際PDF/hash/font pairing此次未產出。

下一步：主控核新SHA及diff後序列納入新的候選來源，安排重新配對版面及獨立B07複核。接收方應回執實際讀入326c38ad…五修明示版本，特別重核一般階數規則、Rn同倫四邊、S1 intrinsic pullback/FTC、n維div先定後用與corner完整chart/embedded型別及orientation先備；通過權在B07原角色，不由本回冒簽。新增內容只依既有203/205/206工具，沒有更動跨章statement或先備邊；相應覆蓋可更新六行evidence。全局UNKNOWN門檻及凍結舊稿不解凍。

共享路徑及hash已交主控，不推定所有接收者已讀。可恢復保存由主控負責；不自動封存、不更改工具ZIP/分卷表/文獻表/來源PDF/正式模板、不重啟任何其他卷、不自行修改202/205/207或B06來源/PDF配對。

最後明示（以9a927ae0…五修稿為實收基線）：僅補定義原句後的 “Such charts cover $M$.”，並把V15-206-023主anchor還原為 `thm:206-corner-stokes`；證據分別指向定義、depth/face-change引理、FTC/面號及定理全局拼接，019仍以 `def:206-corners` 為主anchor。除此無數學或版式增改。labels與四校準逐byte重核保留。
