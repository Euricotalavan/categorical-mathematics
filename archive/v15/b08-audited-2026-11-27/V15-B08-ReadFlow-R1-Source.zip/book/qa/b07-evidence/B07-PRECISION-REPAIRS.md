# V15 B07 退修：202／205／207 精修回執

交接 ID：`V15-B07-PRECISION-REPAIRS-20261127-v1`。角色：精修 → 主控整合 → 打厚複核。方案 B 單一 Work；階段 B07 初審退修，對應原 A 終審退精修／修後回打厚。**本角色已完成下列隔離修稿，接受其數學修正，交出複核；不代簽整卷終審。** 本次不是重啟B01–B05，沒有修改B06固定source、排版PDF、其他章或來源母表。

## 接收與唯一輸入

逐一實讀 `v15-run/b06-candidate/book/chapters/` 的202、205、207原文及受影響上下文，原hash均實算；所有修稿另存 `v15-run/b07-repairs/`。不從B04／B05舊候選重起，不把之前已接受標籤代替本輪核查。

| 章 | 原bytes | 原SHA-256 | 修後bytes | 修後SHA-256 |
| --- | ---: | --- | ---: | --- |
| 202 | 35853 | 96db9d7c2480de8bf860c647324ef8bfbbfde6cb09f717b771369ebd5895169c | 35867 | 70d987fdd61feec5db5582c6520c3d141b71f2fc3980c101facfb0524c0d221c |
| 205 | 55762 | 3691722d20327a9f361cf0cda567ade431bd1eceefc5bedd5db5c285f05cf7db | 58183 | 7194aa86c34fc80daf960ffe87ab822d3675aa0b92e9d4b47945fcb1c93ccf4d |
| 207 | 36223 | f5113e0fd0676aa67ec2df8fd9051c24eebc965fec95e96e6cbfc84c53f3fe41 | 36339 | 2e1efeae1f703ff3fe1de8141a46735270db56c123e6be9b3ec0a0d0da749aec |

205曾暫出早題版、constant-sign版等中間hash；**本回執只交上表7194aa86…合修版**，包含全部205退修要求及positive-chart等價句的必要範圍澄清。此前暫存hash不是本次正式送複核版本。

## 202：差函數可積且積分為零，不是逐點零函數

位置：原line389，`lem:202-jordan-null-correction` proof。

- 原句：`the difference is an integrable zero function`。
- 改句：`the difference is an integrable function with integral zero`。
- 實核：`lem:202-finite-covers` 只給bounded function supported on content-zero E可積且積分0。差函數可在E上非零，所以退修成立。本角色先前未攔下這個措辭，保留既有退修史。
- 前後試用：在[0,1]取f=0、g為單點{1/2}的indicator，g−f在1/2是1，原說法不成立；薄interval cover使其上下和／積分均趨0，修後正確。一般h=g−f用||h||∞乘meeting-E cells體積，既可得signed Darboux gap→0亦可得int h=0。另一測試0與1_Q只差countable-null，後者不可積；本次沒有放寬lemma後半「兩者先已可積」的條件。
- 下游：201 finite-gluing原已正確寫bounded face-supported difference有integral0；203 Darboux proof的cubical-face correction亦已用同一正確結論；205 torus／rotation seam可非零但積分0，仍合法援引。202 region additivity也只需零積分。所有結論／條件不變。
- 最小差分：一行一短語、+14 bytes、行數不變；逆換後逐byte還原原稿。完整前後試用另見 `CH202-PRECISION-RECEIPT.md`。

## 205：早題改為已定義的切向量辨識

位置：原tex517–529，205.2第二個problem（原Exercise205.2）。

原問題問upward normal是否outward conormal，但conormal到205.4才定義，且題中未給boundary。原解雖指出型別不同，不能替代先定後用。現改：`Is its upward unit normal tangent at that point?`

解保留：

- affine tangent plane `(1,2,2)+span{(1,0,2),(0,1,1)}`；
- Gram weight `sqrt6`；
- upward unit normal `N=(-2,-1,1)/sqrt6`。

並實算兩個點積：`N·(1,0,2)=(-2+2)/sqrt6=0`、`N·(0,1,1)=(-1+1)/sqrt6=0`。因此N垂直於切平面的**方向空間**，而|N|=1使N非零，故不是切向量。沒有把向量誤當作affine tangent plane中的位置點。

未定義conormal問答已刪；完整比較保留於205.4原 `prop:205-boundary-orientation` 後的outward unit conormal構造，及 `ex:205-orientation` 的N／nu／T。這些地方已先有full tangent、boundary tangent、outward transverse與orientation，且有投影／正規化和cross-product實證。未移動練習、未新增problem，所有題號順序不變。早題改段本身行數也不變。

## 205：含邊界的非零top field存在證改用constant-sign charts

位置：原 `cor:205-abstract-volume-orientation` proof（1032–1059附近）。原「take a cover by positive charts」對含邊界的一維情形不成立：遞增方向[a,b]的右端chart t↦b−t相對方向是負的，且half-line內向座標不能藉反向改成正chart。

現證路逐步為：

1. 依orientation的局部條件，取連通、coordinate tangent basis符號固定為epsilon_i∈{1,−1}的charts覆蓋，再用既有countable locally finite partition；同一chart可被多個partition項使用。
2. 在第i張chart的ordered coordinate tangent basis上，定義唯一alternating top-degree functional取值epsilon_i。只用205已定的determinant rule，不用尚未定義的wedge。
3. 對任意positive basis，設其coordinate columns為C，sign det C=epsilon_i，故該functional求值epsilon_i det C>0。正、負chart都可用。
4. 換chart的coeff乘transition determinant；chain rule與det product law保同一intrinsic functional，coeff為C^(r−1)，並按boundary local extension慣例到true boundary仍有該正則性。
5. rho_i omega_i的support含於rho_i在該chart內的compact support；於artificial edge之外零延拓有相同正則性。locally finite sum局部只有有限項；在每點每個非零項對positive basis為正，且至少一rho_i>0，所以sum不消失、誘導給定orientation。若M smooth則所有物件smooth。
6. 兩端試用：左端t↦a+t符號+1；右端t↦b−t符號−1，故右端functional在coordinate vector−e_x取−1，在positive e_x取+1。與全局正向covector一致，不需要不存在的全正boundary chart cover。

同一缺陷的定義範圍也澄清：`def:205-orientation` 的「equivalently covering by positive charts」現在明限 **manifold without boundary of positive dimension**；含邊界沿用locally constant-sign coordinate-basis條件。否則只修cor、仍讓該等價句被解讀成所有boundary charts可正向，會留下同一先備缺口。

此修正是存在與orientation-independentness：不同cover/partition可產生不同positive top fields，並未宣稱所得field本身唯一。其誘導orientation一致，下一段ratio命題精確描述其差異。

### V15-205-032：全局唯一ratio及同向判準補齊

cor statement與proof新增：任意兩個continuous nowhere-zero top-degree fields alpha、beta，存在唯一continuous nowhere-zero scalar function h使beta=h alpha；若二者同為C^s（0≤s≤r−1），h也是C^s；smooth manifold上的smooth fields給smooth h。二者誘導同一orientation當且僅當h在各點皆正。

證明實核：在一chart basis求出非零coeff a、b，設h=b/a；換chart時兩coeff乘同一非零det，故local quotient相同而glue成global h。determinant rule給beta=h alpha於所有tangent tuples，a≠0給唯一；商的continuity／共同regularity及h≠0直接成立。對positive basis求值的符號給h>0等價；zero-dimensional情形就是兩個非零point scalar的商。

前後試用：同向的alpha與2alpha給h=2；反向−2alpha給h=−2；對disconnected M必逐點h>0才能同向。負coordinate chart同時改變a,b的符號，不改h。此段不把pointwise scalar ratio當成global常數，也不要求metric。

### 零維orientation與任意0-form分開

原 `a top-degree functional is just a scalar with the specified sign` 會把所有0-forms限成orientation sign。現明說：zero-dimensional top-degree functional／0-form可有任意real value；**associated metric volume functional**才取chosen orientation sign。

試用一個正向點：f=2、f=0、f=−3都是合法0-forms；metric volume scalar是+1。負向點則metric volume scalar−1，仍不限制任意0-form。這與205已定signed-point integration、206.1 Lambda^0=R、206.3 point evaluation及206.5 metric signed volume完全相容。

### 205／206下游核證

205 `thm:205-area-integral` 是unsigned Gram integral，本來不需orientation；其finite partition與boundary cutoff證未改。205 embedded metric volume orientation construction、outward-first conormal與cross-product identities未改；新增abstract field ratio只補全原核心定向責任。

206已明寫chart sign epsilon_phi及half-space boundary sign epsilon_phi(-1)^k，且明示右端boundary chart可負。本次205改證與該約定一致；206 density／flux中metric volume是由metric和orientation規範化的特殊field，不是任意nowhere-zero top field。206 algebra的任意0-form是scalar function，不被205方向sign限制。沒有讓205依賴206，沒有用wedge補205先備。

## 207：三個依輸入而變的bound屬於所得算子

位置：207.2原203–212附近兩個bounded bilinear maps，以及207.3原428–431的inversion proof。

第一、第二式修後文句明定：map在(A,y)及(x,C)的**values**是linear operators，其operator norms分別≤||B||||A||||y||和||B||||x||||C||。不是聲稱整個bilinear map的norm依自己的輸入變動。

型別與試用：令B:E×F→G bounded bilinear，增量空間Z任意normed；A∈L(Z,E)、C∈L(Z,F)。所得h↦B(Ah,y)、h↦B(x,Ch)均在L(Z,G)。對每個h，逐點估計分別≤||B||||A||||y||||h||、||B||||x||||C||||h||，在closed unit ball取sup即原兩個value bounds；因此作為bilinear maps其全局bilinear norm各≤||B||。輸入A=0會使第一個value為零，並不使整個bilinear map為零，這正是原句需澄清的型別差別。

第三式現在明定：(R,Q)↦[H↦RHQ]為bounded bilinear map，其在(R,Q)的**value**是operator norm≤||R||||Q||的linear operator。對T:X→Y而言，R,Q∈L(Y,X)，H∈L(X,Y)，RHQ∈L(Y,X)，故value在L(L(X,Y),L(Y,X))。由||RHQ||≤||R||||H||||Q||取sup即得value bound；map自身的bilinear norm≤1。

三式數學bounds和乘法順序完全未改。product／composition C^j歸納及smooth inversion由有界bilinear操作閉包仍有效；207 inverse／implicit theorem、199-008/022/026回接及function-space例的regularity不變。

## 206移交狀態

主控後指示206另由幾何精修負責，本角色已停止改該路徑，**206不在本回執的正式三章patch manifest中**。先前生成參考稿已回報主控供該角色接管：

- B06原206：79426 bytes，SHA `68f21959185660e1ff180cab86ae8c193ea68788d1873863fe31bdb2dec3c65e`。相對B05，只將chain引言兩行縮為一句；未拿舊B05版覆蓋B06。
- 移交時 `b07-repairs/ch206.tex`：79614 bytes，SHA `54638fc33764e6335b89e5ec9016f502a40bf38df9fb8b430555452f5c1a7bd8`；diff SHA `c5e764149acf542170247db3bf4cdc97b925423f03cfdedc2fa83777b125ebf8`。
- 參考改動僅206.5先定任意n≥1、C1場於open Ω⊂R^n的div=Σpartial_iF_i，再說R³是特例。最終206候選、hash與接受以幾何角色回執為準，不把這個移交hash冒充最終送審。
- 移交時已實測206.3／206.4 accepted-precision兩樣本仍逐byte包含，SHA分別95598a65562b995139f86c6d2f860b0407475b5e247021f6115b8932540b67b5、9e8c503e85b6495271877a52a3928da869b9d486b426898527e1c5de552efd91。之後本角色未再改206。

## 差分、定位、覆蓋與交接門檻

| 差分 | SHA-256 |
| --- | --- |
| ch202.diff | ab0a47c3b556ff69f17195e4b868c1e86d6b8e512de95f5abc237d1ecb97776c |
| ch205.diff | 170326d321cd3aff769ecf7ee6cb08e897b353d97669ac01f7b179bb01e4e90a |
| ch207.diff | 380457cac2f83876f1be470530076a3a5a71bd25765e0d77c895a9843f57cd2b |

三章現有label／ref／eqref序列、problem數與先後均不變；未刪來源ID、未搬核心到另一題或另一章。205補proof與statement後總行數+42，207+2，202不變；29個既有label行號改動逐列記 `LABEL-LINE-CHANGES.tsv`。可見的pdf換頁／行寬由後續重排決定，不能將「label沒改」當作版面沒變。

覆蓋impact：202原lemma主張不變、proof糾正；205.2題改為已定義方向空間，不替代／移走205.4 conormal責任；V15-205-032在原定向cor補正含boundary證明和ratio；零維functional型別與207 operator-value型別明確化。原529CORE／支持／UNKNOWN分類不自動變動，母表需主控對真稿更新evidence和行號；本角色不改B06母表。原5支持OPEN／31來源UNKNOWN及歷史全局門檻也不因本輪升格。

附加檢核：用三章隔離文本與其餘未改B06章作只讀引用檢查，459 distinct labels、187 refs，無重複／懸空。這是locator輔核，不代替上述逐式試用與證法審核。沒有編譯／重排／視檢PDF，依主控要求等整份初審問題一次合修重編。

可取檔案：本目錄三章 `.tex`、三章 `.diff`、本回執、202專項回執、`PRECISION-PATCHES.json`、`LABEL-LINE-CHANGES.tsv`、`PRECISION-SHA256SUMS`。JSON固定三章原／新hash、diff與line delta。總SHA檔另列本回執hash，不作自我hash循環。

下一步與通過條件：主控合入本三章及幾何角色最終206，重建唯一source／PDF／manifest並回打厚按具體退修點複核；初審其餘問題也須逐條閉合。接受範圍只到本角色隔離修正，**仍待打厚複核，不能直接封存或沿用B05接受當成B07通過**。

禁止重做／限制：不改B06固定包、不移章號／題號、不重開擷取來源或其他卷；B03校準塊與既有已修項保留。沿用已採正式ReadFlow R1，排版／全頁QA與最終保存由主控依原授權處理；本角色未核實模型／High設定、不宣稱切換，未以落檔代外部封存。
