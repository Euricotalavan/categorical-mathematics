#!/usr/bin/env python3
"""Volume PDF signals and ordered render index; every page still needs visual reading."""
from pathlib import Path
import argparse,fitz,hashlib,json,re
p=argparse.ArgumentParser();p.add_argument('pdf',type=Path);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--render',action='store_true');p.add_argument('--scale',type=float,default=1.15);a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
d=fitz.open(a.pdf);toc=d.get_toc();anchors=[];issues=[]
for level,title,page in toc:
    if level!=1:continue
    m=re.match(r'^(19[5-9]|20[0-7])(?:\s|\.)',title)
    if m:anchors.append((page,int(m.group(1))))
    elif title.strip().lower()=='references':anchors.append((page,'References'))
for n in range(195,208):
    if sum(x[1]==n for x in anchors)!=1:issues.append({'kind':'chapter-anchor-count','chapter':n,'count':sum(x[1]==n for x in anchors)})
if not any(x[1]=='References' for x in anchors):issues.append({'kind':'references-anchor-missing'})
index=[];font_records={};active=None
for n,q in enumerate(d):
    for page,context in anchors:
        if page==n+1:active=context
    lines=[];spans=[]
    for b in q.get_text('dict')['blocks']:
        for line in b.get('lines',[]):
            ls=line.get('spans',[]);text=''.join(x['text'] for x in ls);lines.append({'text':text,'bbox':line['bbox']});spans+=ls
    top=' '.join(' '.join(x['text'].split()) for x in lines if x['bbox'][1]<60)
    wanted='Volume 15 / References' if active=='References' else (f'Volume 15 / Chapter {active}' if active else None)
    if wanted and wanted not in top:issues.append({'kind':'running-header-context','physical_page':n+1,'expected':wanted,'actual_top':top})
    for s in spans:
        if not q.rect.contains(fitz.Rect(s['bbox'])):issues.append({'kind':'outside-page-span','physical_page':n+1,'text':s['text'],'bbox':s['bbox']})
        if s['text'].strip() and min([(s['color']>>v)&255 for v in [16,8,0]])>235:issues.append({'kind':'near-white-text','physical_page':n+1,'text':s['text']})
    footer=[s for s in spans if re.fullmatch(r'[0-9ivxlcdm]+',s['text'].strip()) and s['bbox'][1]>q.rect.height-65 and s['bbox'][0]>q.rect.width*.7]
    if footer:
        boundary=min(x['bbox'][1] for x in footer)
        for s in spans:
            if s in footer or s['bbox'][1]<60 or 'ReadFlow' in s['text'] and s['bbox'][1]>q.rect.height-65:continue
            if s['bbox'][3]>=boundary-2:issues.append({'kind':'possible-footer-collision','physical_page':n+1,'text':s['text'],'bbox':s['bbox'],'footer_top':boundary})
    for link in q.get_links():
        if link.get('kind')==fitz.LINK_GOTO and not 0<=link.get('page',-1)<len(d):issues.append({'kind':'broken-local-link','physical_page':n+1,'link':link})
    for font in q.get_fonts(full=True):
        xref=font[0]
        if xref in font_records:continue
        name,ext,kind,data=d.extract_font(xref)
        font_records[xref]={'xref':xref,'name':name,'extension':ext,'kind':kind,'embedded_bytes':len(data),'embedded_sha256':hashlib.sha256(data).hexdigest() if data else None}
        if not data:issues.append({'kind':'font-not-embedded','font':name,'xref':xref})
        if not any(x in name for x in ['PagellaX','NotoSans','DejaVuSansMono','Asana','STIXTwoMath']):issues.append({'kind':'unexpected-font-family','font':name,'xref':xref})
    render=None
    if a.render:
        render=f'page-{n+1:03d}.png';q.get_pixmap(matrix=fitz.Matrix(a.scale,a.scale),alpha=False).save(a.output_dir/render)
    index.append({'physical_page':n+1,'context':active,'top_text':top,'first_body_lines':[x['text'] for x in lines if 60<x['bbox'][1]<q.rect.height-65][:3],'page_label':q.get_label(),'render':render,'status':'AWAITING_VISUAL_REVIEW'})
rec={'scope':'Automated engineering signals only; not all-page visual or semantic acceptance','pdf_sha256':hashlib.sha256(a.pdf.read_bytes()).hexdigest(),'pdf_bytes':a.pdf.stat().st_size,'pages':len(d),'toc':toc,'chapter_and_references_anchors':anchors,'fonts':list(font_records.values()),'issues':issues,'page_index':index}
(a.output_dir/'engineering-scan.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'pdf_sha256':rec['pdf_sha256'],'pages':len(d),'issue_count':len(issues),'issues':issues[:30]},indent=2))
