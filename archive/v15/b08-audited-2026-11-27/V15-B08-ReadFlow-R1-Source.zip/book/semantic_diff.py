#!/usr/bin/env python3
"""Conservative source preservation guard. It cannot certify mathematical equivalence."""
from pathlib import Path
import argparse,hashlib,json,re,difflib
MATH_ENVS={'equation','equation*','align','align*','alignat','alignat*','gather','gather*','multline','multline*','displaymath','math'}
def decomment(s):
    out=[]
    for line in s.splitlines():
        cut=len(line)
        for m in re.finditer('%',line):
            k=m.start()-1;slashes=0
            while k>=0 and line[k]=='\\':slashes+=1;k-=1
            if slashes%2==0:cut=m.start();break
        out.append(line[:cut])
    return '\n'.join(out)
def math_units(s):
    s=decomment(s);units=[];unknown=[];i=0
    while i<len(s):
        if s.startswith('\\[',i) or s.startswith('\\(',i):
            close='\\]' if s.startswith('\\[',i) else '\\)';end=s.find(close,i+2)
            if end<0:unknown.append('unclosed math delimiter at '+str(i));break
            units.append(s[i:end+2]);i=end+2;continue
        if s[i]=='$' and (i==0 or s[i-1]!='\\'):
            delim='$$' if s.startswith('$$',i) else '$';j=i+len(delim)
            while True:
                end=s.find(delim,j)
                if end<0:unknown.append('unclosed dollar at '+str(i));i=len(s);break
                if end==0 or s[end-1]!='\\':units.append(s[i:end+len(delim)]);i=end+len(delim);break
                j=end+len(delim)
            continue
        m=re.match(r'\\begin\{([^}]+)\}',s[i:])
        if m and m.group(1) in MATH_ENVS:
            env=m.group(1);start=i;i+=m.end();depth=1
            token=re.compile(r'\\(begin|end)\{'+re.escape(env)+r'\}')
            while depth:
                t=token.search(s,i)
                if not t:unknown.append('unclosed math environment '+env);i=len(s);break
                depth+=1 if t.group(1)=='begin' else -1;i=t.end()
            units.append(s[start:i]);continue
        i+=1
    return [re.sub(r'\s+','',u) for u in units],unknown
def neutral(s):
    s=decomment(s)
    # Only standalone layout controls are removed. Content is never rewritten here.
    s=re.sub(r'(?m)^\s*\\(?:Needspace|needspace)\{[^{}]*\}\s*$', '',s)
    s=re.sub(r'(?m)^\s*\\(?:clearpage|newpage|nobreak)\s*$', '',s)
    return re.sub(r'\s+',' ',s).strip()
def compare(old,new):
    a=old.read_text();b=new.read_text();ma,ua=math_units(a);mb,ub=math_units(b)
    names=lambda s:re.findall(r'\\(?:label|ref|eqref|chapter|section|subsection|begin|end)\{[^}]*\}',decomment(s))
    defs=lambda s:re.findall(r'(?m)^.*\\(?:newcommand|renewcommand|def|DeclareMathOperator|newenvironment|renewenvironment).*$',decomment(s))
    return {'path':str(new),'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'byte_equal':a==b,'whitespace_or_standalone_layout_only':neutral(a)==neutral(b),'math_units_equal':ma==mb,'math_units_before_after':[len(ma),len(mb)],'math_parser_unknown':ua+ub,'label_reference_environment_structure_equal':names(a)==names(b),'macro_definition_lines_equal':defs(a)==defs(b),'diff':''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(old),tofile=str(new))),'verdict':'UNCHANGED' if a==b else ('LAYOUT_ONLY_CANDIDATE' if neutral(a)==neutral(b) and ma==mb and not ua and not ub and names(a)==names(b) and defs(a)==defs(b) else 'REQUIRES_EXPLICIT_BOUNDED_REVIEW')}
def main():
    p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();rows=[]
    for old in sorted(a.baseline.rglob('*.tex')):
        rel=old.relative_to(a.baseline);new=a.candidate/rel
        rows.append(compare(old,new) if new.is_file() else {'path':str(rel),'verdict':'MISSING_CANDIDATE'})
    extra=[str(q.relative_to(a.candidate)) for q in a.candidate.rglob('*.tex') if not (a.baseline/q.relative_to(a.candidate)).exists()]
    d={'scope':'Source protection signals only, not mathematical equivalence or final review','files':rows,'extra_tex_files':extra,'requires_review':[x['path'] for x in rows if x['verdict'] not in ['UNCHANGED','LAYOUT_ONLY_CANDIDATE']]};a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'files':len(rows),'requires_review':d['requires_review'],'extra_tex_files':extra},indent=2))
if __name__=='__main__':main()
