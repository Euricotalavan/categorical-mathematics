#!/usr/bin/env python3
"""Exact repair chain validation. This authorizes a review build, never B07 acceptance."""
from pathlib import Path
import hashlib,json,re
B05='cd9c5a666b63b352e2b54786f87ebf9cec989714aeadddaf69df2953ef2e7d5c'
B06='5d224001384c6ae0d05c4f1af28d77cc509f931d9d7a12e02ba7c6808c0f251e'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def validate_b07_repairs(root,b05_rows):
    root=Path(root);errors=[];allowed=set();p=root/'qa/b07-repairs.json'
    result={'status':'AWAITING_EXACT_CALLBACK','compile_authorized':False,'allowed_paths':[],'errors':errors}
    if not p.exists():errors.append('B07 repair ledger missing');return result
    d=json.loads(p.read_text());a=d.get('authorization',{})
    if d.get('b05_manifest_sha256')!=B05 or d.get('b06_source_manifest_sha256')!=B06:errors.append('B07 ledger baseline mismatch')
    original=root/'provenance/B06-fixed/MANIFEST.json'
    if not original.is_file()or digest(original)!=B06:errors.append('Exact B06 source manifest absent');return result
    b06={x['path']:x for x in json.loads(original.read_text())['files']}
    def receipt(x,label):
        if not isinstance(x,dict):errors.append(label+': receipt absent');return
        name=x.get('path','');rel=Path(name)
        if not name or rel.is_absolute()or '..'in rel.parts:errors.append(label+': unsafe receipt path');return
        f=root/rel
        if not f.is_file()or f.stat().st_size!=x.get('bytes')or digest(f)!=x.get('sha256'):errors.append(label+': receipt bytes/hash mismatch '+name)
    # Pending preparation is valid source state but cannot launch XeLaTeX.
    if a.get('status')=='AWAITING_EXACT_CALLBACK':
        if d.get('repairs'):errors.append('Pending ledger contains unapproved repair entries')
        return result
    if a.get('status')!='AUTHORIZED_FOR_B07_REVIEW':errors.append('Not authorized for a B07 review build');return result
    receipt(a.get('callback_receipt'),'root exact callback')
    repairs=d.get('repairs',[])
    if not repairs:errors.append('Authorized repair ledger has no exact repair payload')
    seen=set()
    for x in repairs:
        name=x.get('path','');prefix='Repair '+str(x.get('id',name))+': '
        if name in seen:errors.append(prefix+'duplicate path; merge single batch per file');continue
        seen.add(name)
        if name not in b05_rows or name not in b06:errors.append(prefix+'not a fixed production body file');continue
        if x.get('category')not in ['M','N','L','E']:errors.append(prefix+'explicit M/N/L/E category required')
        if not x.get('issue_ids')or x.get('review_status')!='SUBMITTED_FOR_B07_REVIEW':errors.append(prefix+'issue chain or honest pending review status absent')
        before=x.get('before_sha256');after=x.get('after_sha256')
        if x.get('b05_sha256')!=b05_rows[name]['sha256']or x.get('b06_sha256')!=b06[name]['sha256']or before!=b06[name]['sha256']:errors.append(prefix+'B05/B06/before hashes disagree')
        baseline=root/'provenance/B06-fixed'/name
        if not baseline.is_file()or digest(baseline)!=before:errors.append(prefix+'recoverable exact B06 body missing')
        current=root/name
        if not re.fullmatch('[0-9a-f]{64}',after or '')or not current.is_file()or digest(current)!=after:errors.append(prefix+'current body does not match precise after hash')
        payload=x.get('accepted_payload');receipt(payload,prefix+'accepted precision payload')
        if not isinstance(payload,dict)or payload.get('sha256')!=after:errors.append(prefix+'accepted payload hash does not match repaired whole file')
        findings=x.get('independent_findings',[]);precision=x.get('precision_receipts',[])
        if not findings or not precision:errors.append(prefix+'independent finding / precision receipt chain missing')
        for j,z in enumerate(findings):receipt(z,prefix+'independent finding '+str(j))
        for j,z in enumerate(precision):receipt(z,prefix+'precision receipt '+str(j))
        allowed.add(name)
    result['allowed_paths']=sorted(allowed)
    result['compile_authorized']=not errors
    result['status']='AUTHORIZED_B07_REPAIR_REVIEW_BUILD'if not errors else'B07_REPAIR_CHAIN_BLOCKED'
    return result
