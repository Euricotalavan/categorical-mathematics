#!/usr/bin/env python3
"""Compare every chapter/section bookmark and TOC link with its actual large body heading.
Page-in-range alone is insufficient. A PDF text geometry audit is not visual approval.
"""
from pathlib import Path
import argparse,csv,hashlib,json,re,unicodedata
import fitz

def norm(s):
    s=unicodedata.normalize('NFKC',s).casefold()
    return re.sub(r'\s+',' ',s).strip().replace('–','-').replace('—','-')

def audit_pdf(path):
    path=Path(path);doc=fitz.open(path);headings={};issues=[]
    for n,page in enumerate(doc,1):
        lines=[]
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines',[]):
                spans=line.get('spans',[])
                if not spans:continue
                lines.append({'text':''.join(x['text']for x in spans),'bbox':list(line['bbox']),'large':any('NotoSans'in x['font']and x['size']>=12 for x in spans),'chapter_title':any('NotoSans'in x['font']and 20<x['size']<24 for x in spans)})
        for i,line in enumerate(lines):
            if not line['large']:continue
            match=re.match(r'^((?:19[5-9]|20[0-7])\.[1-5])\s+(.*)',line['text'])
            if match:
                key='section.'+match[1];text=line['text'];box=line['bbox'][:];j=i+1
                while j<len(lines)and lines[j]['large']and not re.match(r'^\d',lines[j]['text'])and abs(lines[j]['bbox'][0]-box[0])<70:
                    text+=' '+lines[j]['text'];box[3]=lines[j]['bbox'][3];j+=1
                if key in headings:issues.append({'kind':'duplicate-real-heading','key':key,'pages':[headings[key]['physical_page'],n]})
                headings[key]={'key':key,'physical_page':n,'printed_page':page.get_label(),'text':text,'bbox':box}
        kicker=next((x for x in lines if re.match(r'^CHAPTER\s+(19[5-9]|20[0-7])$',x['text'])),None)
        if kicker:
            num=re.search(r'CHAPTER\s+(\d+)',kicker['text'])[1];titles=[x for x in lines if x['chapter_title']];text=' '.join(x['text']for x in titles)
            key='chapter.'+num;headings[key]={'key':key,'physical_page':n,'printed_page':page.get_label(),'text':num+' '+text,'bbox':[kicker['bbox'][0],kicker['bbox'][1],max(x['bbox'][2]for x in titles),max(x['bbox'][3]for x in titles)]}
        reference=next((x for x in lines if x['chapter_title']and norm(x['text'])=='references'),None)
        if reference:headings['references']={'key':'references','physical_page':n,'printed_page':page.get_label(),'text':'References','bbox':reference['bbox']}
    expected=[f'chapter.{c}'for c in range(195,208)]+[f'section.{c}.{s}'for c in range(195,208)for s in range(1,6)]+['references']
    for key in expected:
        if key not in headings:issues.append({'kind':'real-heading-not-found','key':key})
    bookmarks=[]
    for level,title,page,target in doc.get_toc(False):
        m=re.match(r'^(19[5-9]|20[0-7])(?:\.([1-5]))?\s+',title)
        key=('section.'+m[1]+'.'+m[2]if m[2]else'chapter.'+m[1])if m else('references'if norm(title)=='references'else None)
        if key not in headings:issues.append({'kind':'unexpected-or-unlocated-bookmark','title':title});continue
        actual=headings[key];dest=target.get('nameddest');resolved=doc.resolve_link('#nameddest='+dest)if dest else None
        target_page=resolved[0]+1 if resolved else page;point=[round(resolved[1],3),round(resolved[2],3)]if resolved else None
        row={'key':key,'title':title,'named_destination':dest,'bookmark_target_page':page,'resolved_target_page':target_page,'resolved_point_top_coordinates':point,'actual_heading_page':actual['physical_page'],'actual_printed_page':actual['printed_page'],'actual_heading_text':actual['text'],'actual_heading_bbox':actual['bbox'],'title_matches':norm(title)==norm(actual['text']),'page_matches':page==target_page==actual['physical_page'],'landing_before_heading':bool(point and actual['bbox'][1]-45<=point[1]<=actual['bbox'][1]+5)}
        row['status']='PASS'if row['title_matches']and row['page_matches']and row['landing_before_heading']else'FAIL'
        if row['status']=='FAIL':issues.append({'kind':'bookmark-heading-mismatch','key':key,'bookmark_target_page':page,'resolved_target_page':target_page,'actual_heading_page':actual['physical_page'],'landing_y':point[1]if point else None,'heading_top':actual['bbox'][1]})
        bookmarks.append(row)
    first_body=min(x['physical_page']for k,x in headings.items()if k.startswith('chapter.'));toc_links=[];bookmarks_by_dest={x['named_destination']:x for x in bookmarks}
    for n in range(first_body-1):
        page=doc[n]
        words=page.get_text('words')
        for link in page.get_links():
            dest=link.get('nameddest');bookmark=bookmarks_by_dest.get(dest)
            if not bookmark:issues.append({'kind':'unexpected-toc-link','toc_physical_page':n+1,'destination':dest});continue
            resolved=doc.resolve_link('#nameddest='+dest);target_page=resolved[0]+1;box=list(link['from']);mid=(box[1]+box[3])/2
            printed=[w[4].strip()for w in words if w[0]>430 and abs((w[1]+w[3])/2-mid)<4 and re.fullmatch(r'\d+',w[4].strip())]
            row={'key':bookmark['key'],'toc_physical_page':n+1,'link_text':page.get_textbox(link['from']),'named_destination':dest,'link_target_page':link.get('page',-1)+1,'resolved_target_page':target_page,'actual_heading_page':bookmark['actual_heading_page'],'toc_printed_page_candidates':printed,'actual_printed_page':bookmark['actual_printed_page'],'link_page_matches':link.get('page',-1)+1==target_page==bookmark['actual_heading_page'],'printed_page_matches':printed==[bookmark['actual_printed_page']],'bookmark_and_link_agree':target_page==bookmark['resolved_target_page']}
            row['status']='PASS'if row['link_page_matches']and row['printed_page_matches']and row['bookmark_and_link_agree']else'FAIL'
            if row['status']=='FAIL':issues.append({'kind':'toc-link-heading-mismatch','key':row['key'],'toc_physical_page':n+1,'target_page':target_page,'actual_heading_page':row['actual_heading_page'],'printed_page_candidates':printed})
            toc_links.append(row)
    for key in expected:
        for records,label in [(bookmarks,'bookmark'),(toc_links,'toc-link')]:
            count=sum(x['key']==key for x in records)
            if count!=1:issues.append({'kind':label+'-count','key':key,'count':count})
    return {'scope':'Actual PDF large-title geometry vs every chapter/section bookmark and electronic TOC link, including printed TOC page. Not merely target-in-range, not visual/mathematical acceptance.','pdf_path':str(path),'pdf_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pdf_bytes':path.stat().st_size,'pdf_pages':len(doc),'actual_chapters':sum(k.startswith('chapter.')for k in headings),'actual_sections':sum(k.startswith('section.')for k in headings),'references_checked':'references'in headings,'bookmarks_checked':len(bookmarks),'toc_links_checked':len(toc_links),'bookmarks':bookmarks,'toc_links':toc_links,'issues':issues,'verdict':'PASS'if not issues else'FAIL'}

def write_audit(pdf,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);rec=audit_pdf(pdf)
    (out/'destinations.json').write_text(json.dumps(rec,indent=2)+'\n')
    with(out/'destinations.csv').open('w')as f:
        keys=['key','title','bookmark_target_page','resolved_target_page','actual_heading_page','actual_printed_page','page_matches','landing_before_heading','status'];w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rec['bookmarks'])
    return rec
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('pdf',type=Path);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args();r=write_audit(a.pdf,a.output_dir)
    print(json.dumps({k:r[k]for k in ['pdf_sha256','actual_chapters','actual_sections','bookmarks_checked','toc_links_checked','issues','verdict']},indent=2))
    raise SystemExit(bool(r['issues']))
