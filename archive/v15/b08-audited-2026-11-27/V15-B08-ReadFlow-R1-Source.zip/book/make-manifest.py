#!/usr/bin/env python3
"""Create an isolated B07 repair/preparation source snapshot; excludes generated QA/PDF."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
items=[]
for p in sorted(R.rglob('*')):
 rel=p.relative_to(R);name=rel.as_posix()
 if not p.is_file() or rel.parts[0] in ['.build','__pycache__'] or p.suffix in ['.pdf','.png','.pyc'] or name=='MANIFEST.json':continue
 if rel.parts[0]=='qa' and name not in ['qa/B05-INPUT-RECEIPT.json','qa/layout-patches.json','qa/b07-repairs.json','qa/B07-CALLBACK.json'] and not name.startswith(('qa/b07-evidence/','qa/accepted-repairs/')):continue
 items.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
ledger=json.loads((R/'qa/b07-repairs.json').read_text())
m={'id':'V15-B07-REPAIR-CANDIDATE-R1','stage':'B07 repair preparation; exact callback pending' if ledger['authorization']['status']=='AWAITING_EXACT_CALLBACK' else 'B07 repaired candidate submitted for strict re-review; not passed','b06_source_manifest_sha256':'5d224001384c6ae0d05c4f1af28d77cc509f931d9d7a12e02ba7c6808c0f251e','b05_manifest_sha256':'cd9c5a666b63b352e2b54786f87ebf9cec989714aeadddaf69df2953ef2e7d5c','template_zip_sha256':'5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732','files':items}
(R/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');print('Source manifest written:',len(items),'files')
