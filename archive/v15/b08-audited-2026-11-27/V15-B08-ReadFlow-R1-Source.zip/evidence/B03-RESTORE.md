# V15 B-03 retention receipt

`V15-B03-Checkpoint-v1.zip`, version 0, Library ID the private retention record.

- 3,376,400 bytes. SHA-256 `499b77476109e0449604403a95853403fe948379b12b0bfa3945aa199b65d9ec`. The separately restored copy matched every byte. All 94 manifest members and the archive CRC passed.
- The PDF is the 25-page four-section calibration preview, SHA-256 `c351c30f6f707345f218b476b9b898af6cc8fb4cf9c79ac872d498e530603f04`. Its recovered source, fonts, build and all-page records are embedded as individual files. The matching PDF fingerprint passed after restoration.
- The layout recovery independently rebuilt the 25 pages. Binary PDF bytes differ between isolated builds. Extracted text, bookmarks and every rendered page were identical. The mathematics source fingerprints were identical.
- The revised preview flushes the preceding page before resetting the chapter counter. All corrected running headers were checked. The writer interface's fixed math label names are retained, with forward context relayed to B-04.
