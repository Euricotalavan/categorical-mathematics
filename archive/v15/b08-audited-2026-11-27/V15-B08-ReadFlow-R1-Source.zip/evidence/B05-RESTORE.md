# V15 B-05 retained integration

`V15-B05-Integrated-v1.zip`, version 0, Library ID the private retention record.

The archive contains 110 verified constituent files and has size 3,569,430 bytes and SHA-256 `77dad0835cae4c4ad8b8da5cefe57351bae9339538049ce20921ea9651db8017`. A separate restoration matched all bytes and the internal manifest and CRC. The restored R1 input manifest has SHA-256 `cd9c5a666b63b352e2b54786f87ebf9cec989714aeadddaf69df2953ef2e7d5c`, the exact source dispatched to the layout role.
