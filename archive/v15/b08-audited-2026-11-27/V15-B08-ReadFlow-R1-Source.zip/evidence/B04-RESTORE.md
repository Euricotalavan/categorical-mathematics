# V15 B-04 interval checkpoints

| Checkpoint | Identity | Restore evidence |
|---|---|---|
| `V15-B04-Progress-v1.zip` | Version 0, 2,909,674 bytes, SHA-256 `f317539847cd561e4cc30148deeb823c0fca35a48c1c7e15d97a7ada710d8095`, Library the private retention record | Restored byte for byte, 87 manifest files and CRC passed. Chapter 198 independently accepted in the master. |
| `V15-B04-Progress-v2.zip` | Version 0, 3,828,655 bytes, SHA-256 `310c84f237d79eb48cb53df4247854145894e77344e960433171afeccbace12e`, Library the private retention record | Restored byte for byte, 180 manifest files and CRC passed. Captures all 13 author drafts and four individually accepted chapters. |
| `V15-B04-Complete-v1.zip` | Version 0, 4,497,456 bytes, SHA-256 `0cddb35ed6520c0f383ccffb222a5740b9b2ce81e1f79a50c51b8d4c0c629258`, Library the private retention record | Restored byte for byte. All 222 manifest files and CRC passed. The recovered B-05 input manifest matches the one sent to both reviewers. |

The first two archives are interim recovery checkpoints. The third fixes the manuscript at the end of the chapter stage and supplies the next stage's read-only input.
