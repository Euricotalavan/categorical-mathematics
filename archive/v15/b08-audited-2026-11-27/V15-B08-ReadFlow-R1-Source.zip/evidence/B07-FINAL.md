# V15 Multivariable Analysis｜B-07 獨立打厚終審

**正式判定：PASS。** 此判定只適用下列同一修後原始檔及 PDF 配對。V15 採 B 單一 Work，Chapters 195–207、65 節。原 B-06 R2 的獨立初審 FAIL 及 B07-01–10 原發現保留，這次逐項重核新版後結案。由 B-07 唯一打厚終審交主控進入授權的 B-08 封存工序。

## 版本與回執

| 產物 | 實核值 |
|---|---|
| 修後外層原始檔／PDF 配對 | `v15-run/b07-candidate-r1/B07-REVIEW-PAIR.json`，SHA-256 `071093fe41281d2137879c2dc851982f52158cbc06084827b6afb8eb305633c7` |
| 修後唯一可編排版來源（136 檔） | `v15-run/b07-candidate-r1/book/MANIFEST.json`，SHA-256 `69fc84be8471d2b577776871da9fd25511a789c69f8bbe3496f24a36bdd27090` |
| 修後固定 PDF | `v15-run/b07-candidate-r1/book/V15-Multivariable-Analysis.pdf`，209 頁、951048 bytes，SHA-256 `9a67df626cd281b39ceaad8357a1a5bf3a9d227243bcfe1f5fd2562327b45047` |
| 修後來源覆蓋 | `v15-run/quality/V15-B07-Coverage.tsv`，SHA-256 `edc5fe64826be6e3630336c801c303ed018ff03f82450fdbafa19d846e1ec089` |
| 獨立初審及原 R2 逐節證據 | `B07-INDEPENDENT.md` SHA-256 `2d512d93ccd7e7a63b2791f601824543cec0c9df9061f050500984ff67c3db84`；`B07-INDEPENDENT-SECTIONS.tsv` SHA-256 `82f3c6f0aafb50424515511c7f167758f5e1f94aa28821fbe59707643e7dcb67` |
| 初審後前史實讀回執 | `B07-HISTORY-READ.md` SHA-256 `36d4bcfde227602282e94d350e947cf3c4e31bc95274e575f6436a37302c3460` |

四個修後章檔精確是下列送核版本。其他九個章檔與我在獨立初審依序讀過的固定 R2 原頁正文逐 byte 相同。入口只引入 B07 局部版面目錄定位補丁，正式 ReadFlow R1 基線及四塊校準正文複查無變動。既有 459 標籤保留。189 個引用全解析，新增的兩個是正文對已定義項的定位。

| 章 | bytes | SHA-256 |
|---|---:|---|
| 202 | 35867 | `70d987fdd61feec5db5582c6520c3d141b71f2fc3980c101facfb0524c0d221c` |
| 205 | 58183 | `7194aa86c34fc80daf960ffe87ab822d3675aa0b92e9d4b47945fcb1c93ccf4d` |
| 206 | 83430 | `326c38ade35d041272dbe9420f83be58de0f4dc55ed1a83c67f059b35172b775` |
| 207 | 36339 | `2e1efeae1f703ff3fe1de8141a46735270db56c123e6be9b3ec0a0d0da749aec` |

## 修正後的實讀及重核

以下 p 為由封面起算的物理頁，正文印刷頁碼小 4。原句和原版位置完整留在初審回執。

| 原編號 | 修後原始檔及 PDF | 重核證據 |
|---|---|---|
| 01 定向證明 | Ch205:1035–1102，`cor:205-abstract-volume-orientation`，p155–156 | 已實讀在每張連通且座標基底定號的圖上取係數 εᵢ。以任一正基的座標列 C 驗 εᵢ det C>0，分割一加權項同號且至少一項為正；緊支撐的零延拓和局部有限性供正則性。右端 `[a,b]` 的負 H¹ 圖回算由係數 −1 給正切向量上 +1。比值 h=b/a 在兩係數同乘非零過渡行列式時保值，點態唯一、具所述正則性。同向正好 h>0。前面的正圖覆蓋已限無邊界。 |
| 02 角域可用定義及其證明 | Ch206:1207–1436，`def:206-corners`、`lem:206-corner-depth`、`lem:206-corner-integral`、`thm:206-corner-stokes`，p181–185 | 覆蓋、Hausdorff、可數基、相對開象限、同胚、嵌入局部 C² 與滿秩現在都可判定。實查投影 P 的局部逆產生過渡擴展，正交象限的稠密內部讓兩個複合導數到各臉仍互逆。給全局定向後才給常深一面的 outward-first。運算測試 0/1/2 深度、商錐排列、共同截帶、符號 `(-1)^i(-1)^{i-1}=-1`、W 外局部零及分割一消項均閉合。正方形及 mapped parameter 下游仍照各自面積分／支撐條件。 |
| 03 零集改值 | Ch202:388–389，`lem:202-jordan-null-correction`，p102 | 現寫差函數可積且「with integral zero」。單點指示函數在其點值為 1 而積分為 0，正符合語句。單純 null 的情形維持兩者先可積，後續 Jordan 拼接、換元零延拓及圖面薄層只用積分為零。 |
| 04 習題先備 | Ch205:517–529，Exercise 205.2，p145 | 題問上向 unit normal 會否在切向子空間，已可用此前 切向空間與 Gram 公式。兩點積均為零而 N 非零，保持切向子空間和仿射切平面的型別區分；205.4 正式定義後才計算 conormal。 |
| 05 零維型別 | Ch205:692–697，`def:205-orientation`，p148 | 零維定向選 ±、一般最高次協變泛函是任意實數、誘導 metric volume 取該符號。試負點上的任意值 f，積分為 −f 的既有規則不變，與 Ch206 的代數和 flux 相容。 |
| 06 正則性 | Ch206:176–206，`def:206-form-pullback` 後，p162 | 對正度數，係數為 ω 對 F 的複合乘 DF minors，故 C^min(j,ℓ−1)。零次只有 C^min(j,ℓ) 複合；兩個界線及原 C²/C¹ 的 chart/field 運算核對。沒有導出任意 C¹ 流形 Stokes。 |
| 07 歐氏向量算子 | Ch206:1455–1500、1538–1614，`def:206-vector-operators`、`thm:206-classical`，p186–188 | 先定任意 n≥1 的 div，curl 仍限已定向 ℝ³。微分例的正號是 dz 穿過 dx、dy 兩次，重複 dx 或 dy 的兩項歸零。切平面上的 flux、無向密度分割與 Gauss 各自保持適用域。 |
| 08 同倫與全局 primitive | Ch206:1699–1723，`prop:206-homotopy` 後，p190–191 | 基點 p 的歐氏 loop 用 H(s,t)=(1−s)γ(t)+sp，兩個 t 端始終是 p，每個小矩形由同一公式生成且符合 C²。S¹ 的角形式是 inclusion pullback，d=0，c^*η=dt，整圈 2π 與任何全局 C¹ 原函數的端點差 0 相矛盾。另核定理的有限分片光滑假設及徑向結果保持原邊界。 |
| 09 值範數 | Ch207:203–217 及 429–435，p197/201 | 兩個 lift 的值在 L(Z,G)，以測試 h 的閉單位球推出兩個 operator bounds；取零參數消去該值，不影響固定雙線性運算。反演中的 R,Q∈L(Y,X)、H∈L(X,Y)，得值 H↦RHQ 的 norm≤‖R‖‖Q‖，再應用 C^j 有界雙線性封閉。向 207.4 與 207.5 重走逆／隱函數正則性，原既有連續分支的 normed 推論只憑點展開，仍與 Banach 存在分開。 |
| 10 目錄與書籤 | `layout/b07-local.tex` 與 `volume-15.tex`，p39、100、129 | 全部 65 個 section named destinations、電子 TOC links 和書籤逐一對到現印標題；三原錯節 197.4/202.3/204.3 現精確落 39/100/129。另核全部 324 數學單元和 55 習題的電子目的頁與實際標題同頁。13 章及 References 頁標及跳轉一併核對。 |

## 範圍、工程與出件

- 原 R2 的 195→207 逐節的實讀及 B01 來源條件已記在初審回執和逐節證據。新版逐差分、改稿上下文、跨章依賴、受影響例式及 PDF 定位另核。高風險成鏈重檢包括 Ch203 cubical 內外包含及先可積後配對、Ch205 Gram 和 Ch206 的 signed pullback／若干零維端點、角域／鏈式 Stokes、Ch207 既有連續分支和完整 Banach 存在。四個校準段逐 byte 各出現一次。
- 覆蓋表和母表仍同 990 IDs。529 CORE 有正文落點，本次逐項重核 B07 受影響條件。150 SUPPORT 及 1 LATER 為 COVERED，201 SUPPORT 與 73 LATER 為 DEFERRED。5 SUPPORT OPEN（YU-D060、D064、D070、D072、D082）與 31 來源 UNKNOWN 原分級保留。四個 UNKNOWN 只因改稿移行而更新行號，內容及狀態保持。未讀 Shifrin 等來源、歷史 16／22 對照及六全局門檻保持原限制。實際模型／High 設定未獨立核實。沒有用定理成立倒推源書原證或早期研究版已讀。
- 外層 25685 bytes，逐一重算外層列出的 146 項資料，全部吻合。內外 136 個 source records 相同，另重算 PDF 的頁數、位元組與指紋。重流後實看所有 38 個新畫面頁及多個高風險對照頁，另擷取相關頁的正文與各標題定位。把版面、雜湊與數學判定分列。環節含全頁排版複查及繼承／重看頁證據，見 `v15-run/b07-candidate-r1/book/qa/b07-visual-review.json`；p158 是 Chapter 205 章末完整解答的低密度頁，p184–185 的 Fubini 一字跨頁，p205 保留 207.17 的短續行。這些外觀停頓皆有完整文字與算式。209 頁末頁實見 References 頁眉。
- **交接至 B-08。** 修後原始檔與 PDF 僅按上面固定對交出。B-08 驗收讀入須另簽收、保持可恢復配對及授權範圍。此回執是數學終審決定與檔案送主控，保留舊版 FAIL、修補歷史與 B05／B06 的來源鏈。禁止覆寫凍結稿、重做 B01–B06 已證事務或用持久化成功替代此唯一整卷終審。
