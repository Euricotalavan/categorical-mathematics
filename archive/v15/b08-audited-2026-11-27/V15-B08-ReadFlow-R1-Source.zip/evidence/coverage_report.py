"""Merge V15 source obligations with actual, reviewed manuscript locations."""

import argparse
import csv
import json
import re
from collections import Counter
from pathlib import Path


def load_table(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("responsibilities", type=Path)
    parser.add_argument("design", type=Path)
    parser.add_argument("structure_report", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("reviews", type=Path, nargs="*")
    parser.add_argument("--require-all-core", action="store_true")
    args = parser.parse_intermixed_args()
    responsibilities = load_table(args.responsibilities)
    design = args.design.read_text().split("## CORE responsibility pairing", 1)[1]
    pairing = design.split("\n## ", 1)[0]
    pairs = re.findall(
        r"^\| (V15-[^ |]+) \| ([^|]+?) \|",
        pairing, re.MULTILINE,
    )
    planned = dict(pairs)
    source = {row["id"]: row for row in responsibilities}
    core = {key for key, row in source.items() if row["status"] == "CORE"}
    if set(planned) != core or len(pairs) != len(core) or len(source) != len(responsibilities):
        parser.error("Design and unique CORE responsibility IDs must agree")
    locations = json.loads(args.structure_report.read_text())["labels"]
    reviews = {}
    for path in args.reviews:
        for row in load_table(path):
            key = row["id"]
            if key in reviews or key not in source:
                parser.error(f"Duplicate or foreign responsibility {key} in {path}")
            if row["verdict"] not in {"COVERED", "OPEN", "DEFERRED", "UNKNOWN"}:
                parser.error(f"Unsupported verdict for {key} in {path}")
            if not row["evidence"].strip():
                parser.error(f"Give concrete evidence or a remaining issue for {key} in {path}")
            if row["verdict"] == "COVERED":
                if not row["label"] or row["label"] not in locations:
                    parser.error(f"Actual manuscript label required for {key} in {path}")
                if source[key]["status"] == "UNKNOWN":
                    parser.error(f"Unknown B-01 source cannot be accepted automatically: {key}")
            reviews[key] = row
    fields = ["id", "chapter", "kind", "topic", "b01_status", "planned",
              "verdict", "label", "filename", "line", "evidence"]
    counts = Counter()
    with args.output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for item in responsibilities:
            key = item["id"]
            status = item["status"]
            default = {
                "verdict": "UNKNOWN" if status == "UNKNOWN" else
                           "DEFERRED" if status == "LATER" else "OPEN",
                "evidence": item["landing"],
                "label": "",
            }
            row = reviews.get(key, default)
            point = locations.get(row["label"], {})
            item_output = {name: item[name] for name in ("id", "chapter", "kind", "topic")}
            item_output.update(row)
            item_output.update({
                "b01_status": status,
                "planned": planned.get(key, item["landing"]),
                "filename": point.get("file", ""),
                "line": point.get("line", ""),
            })
            writer.writerow(item_output)
            counts[(status, row["verdict"])] += 1
    print(json.dumps([
        {"status": status, "verdict": verdict, "count": count}
        for (status, verdict), count in sorted(counts.items())
    ], indent=2))
    if args.require_all_core and counts["CORE", "COVERED"] != len(core):
        raise SystemExit("Unresolved CORE source obligations remain")


if __name__ == "__main__":
    main()
