"""Create and verify a portable, deterministic V15 checkpoint."""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath


def digest(contents):
    return hashlib.sha256(contents).hexdigest()


def verify_archive(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or archive.testzip() is not None:
            raise ValueError("Duplicate or corrupt archive member")
        manifest = json.loads(archive.read("CHECKPOINT-MANIFEST.json"))
        expected = {item["path"] for item in manifest["files"]}
        if set(names) != expected | {"CHECKPOINT-MANIFEST.json"}:
            raise ValueError("Archive members differ from the manifest")
        for item in manifest["files"]:
            data = archive.read(item["path"])
            if len(data) != item["bytes"] or digest(data) != item["sha256"]:
                raise ValueError(f"Manifest mismatch: {item['path']}")
    return manifest


def write_archive(root, archive, state, requested):
    files = set()
    for name in requested:
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"Path is outside the checkpoint root: {name}")
        source = root / relative
        if not source.exists():
            raise FileNotFoundError(source)
        if source.is_symlink():
            raise ValueError(f"Symlink is not a checkpoint input: {source}")
        files.update(source.rglob("*") if source.is_dir() else [source])
    contents = {}
    for source in sorted(files):
        if source.is_symlink():
            raise ValueError(f"Symlink is not a checkpoint input: {source}")
        relative = source.relative_to(root)
        if not source.is_file() or any(part.startswith(".") for part in relative.parts):
            continue
        contents[relative.as_posix()] = source.read_bytes()
    if "CHECKPOINT-MANIFEST.json" in contents:
        raise ValueError("Use a new checkpoint root")
    if not contents:
        raise ValueError("No checkpoint files selected")
    manifest = {
        "volume": 15,
        "state": state,
        "files": [
            {"path": name, "bytes": len(data), "sha256": digest(data)}
            for name, data in contents.items()
        ],
    }
    contents["CHECKPOINT-MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    with zipfile.ZipFile(archive, "w") as output:
        for name, data in contents.items():
            info = zipfile.ZipInfo(name, (2026, 11, 27, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            output.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--state")
    parser.add_argument("--include", nargs="+")
    args = parser.parse_args()
    if args.include:
        if not args.state:
            parser.error("Creating an archive requires --state")
        write_archive(args.root.resolve(), args.archive, args.state, args.include)
    manifest = verify_archive(args.archive)
    print(json.dumps({
        "file": args.archive.name,
        "state": manifest["state"],
        "files_checked": len(manifest["files"]),
        "bytes": args.archive.stat().st_size,
        "sha256": digest(args.archive.read_bytes()),
    }, indent=2))


if __name__ == "__main__":
    main()
