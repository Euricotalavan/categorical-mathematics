# V15 B07 修後固定配對交接

交接ID／文案版／時間：V15-B07-REPAIR-PAIR-R1／v1／2026-11-27T12:15:30.636274+00:00。
發出角色／接收角色／對話：排版工程 v15_editor → 主控 → 同一唯一B07打厚終審者；本Work agent交接，無另造公開對話連結。
卷／方案／階段／狀態：V15 *Multivariable Analysis*，B單一Work；B07初審退修後的固定候選，對應原A10–12回修／複核接口。**工程、導航及修後閱讀就緒；不簽B07數學PASS。**

授權／禁止／凍結：主控完整EXACT CALLBACK授權四章精修hash與B07-10局部L同批合入、實編及重流重核。原B06／B05固定pair均未改；不改來源母表、工具ZIP、分卷、凍結舊卷，不啟動其他卷。no further source/PDF change。
模型及High：實際未核實。
有效基線：B06 source5d224001384c6ae0d05c4f1af28d77cc509f931d9d7a12e02ba7c6808c0f251e／PDF67bb40d1e56e539d115c4f42bdc18b4eb9423929a8230bf4124e687c12d82720；B05 cd9c5a666b63b352e2b54786f87ebf9cec989714aeadddaf69df2953ef2e7d5c。前卷V14止194與本卷195–207／65節沿主控既有固定鏈，本輪未新查遠端Git／改章號。

## 可取固定件與版本

|用途|相對交付根完整檔名|bytes／SHA256|核驗|
|---|---|---|---|
|唯一outer pair|B07-REVIEW-PAIR.json|25685／071093fe41281d2137879c2dc851982f52158cbc06084827b6afb8eb305633c7|固定136source entries、PDF、ledger/callback與首批QA；逐一hash實核，不再改|
|可編來源|book/MANIFEST.json|23232／69fc84be8471d2b577776871da9fd25511a789c69f8bbe3496f24a36bdd27090|136檔bytes/hash；原B05 receipt、B06 manifest/body/tools baseline、字型許可、四校準原稿、精修鏈同包|
|唯一配對PDF|book/V15-Multivariable-Analysis.pdf|209頁，951048／9a67df626cd281b39ceaad8357a1a5bf3a9d227243bcfe1f5fd2562327b45047|3遍aux/toc/out收斂；工程／導航／重流分列核驗|
|主控exact授權|book/qa/B07-CALLBACK.json|2079／5686f3ad8955ceed4e1d63ab992707f9e66339a7dd256aa4572038e502e1c088|實收root消息；只授權候選重建送同一B07複審，不是數學通過|
|初審獨立報告|book/qa/b07-evidence/B07-INDEPENDENT.md|12442／2d512d93ccd7e7a63b2791f601824543cec0c9df9061f050500984ff67c3db84|已實讀01–10穩定缺陷與限制；原B06初審FAIL保留|
|202/205/207精修回執|book/qa/b07-evidence/B07-PRECISION-REPAIRS.md|13488／681ee86a34958bbebf618076c2afc12d06aa0547e8a651939f8445ace6962e3f|全文實讀，三章whole-file逐hash合入|
|206最後精修回執|book/qa/b07-evidence/ch206-REPAIR-HANDOFF.md|8347／8f97e94f67b7c0168822fc3153996d9a92e44ffc1ad960ffcceffb06a5b4f5e8|全文實讀最後326c38…版本與全部diff；非中間稿|
|修補ledger|book/qa/b07-repairs.json|8291／b616d63d9396f737df788e0e805eda53be9ad2959b2bd85a74b830c5e3eca988|明列M/N，B05/B06/before/after整檔SHA與獨立／精修receipt鏈；不假標E|
|模板／依賴|book/provenance/template-source.json、layout/、dependencies/fonts/、licenses/|每檔bytes/hash見source manifest|正式ReadFlow R1 artifact8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3，adoption c749e4867538888d3069346fa055ac2ca834c9e1；11字型、PDF嵌6族|
|QA與覆蓋影響|book/qa/，尤其B07-ISSUE-REVIEW-LOCATIONS.tsv、b07-evidence/ch206-coverage-patch.tsv|每檔bytes/hash見B07-DELIVERY.json|候選新頁與精修六ID補充在列；完整母coverage由主控續接，不把候選計數當來源重審|

## 實際內容合入與保護

四個被接受的全章檔原樣合入：202=70d987fdd61feec5db5582c6520c3d141b71f2fc3980c101facfb0524c0d221c；205=7194aa86c34fc80daf960ffe87ab822d3675aa0b92e9d4b47945fcb1c93ccf4d；206=326c38ade35d041272dbe9420f83be58de0f4dc55ed1a83c67f059b35172b775；207=2e1efeae1f703ff3fe1de8141a46735270db56c123e6be9b3ec0a0d0da749aec。不是排版官另行重寫數學。其餘9章及References逐byte同B06，全部459label與編號environment順序不變；四校準塊仍逐byte包含。既有引用順序保留，206精修新增2個明示引用，總189，aux無懸空。意圖數學變更及來源責任以精修回執交同一終審逐項核，不宣稱所有math與B06相同。

B07-10純L在layout/b07-local.tex、完整section前薄guard，wrapper只載入它。正式R1共同layout與全局字級／行距／密度不變。原工程僅查link in-range的缺口已承認並補成真正對標題檢查。具體閉合：197.4的bookmark/TOC由38→39、實際標題39；202.3由99→100、標題100；204.3由128→129、標題129。三個落點都在標題頁top65.2處，紙面頁碼分別35／96／125。全13章＋65節＋References共79筆的真實大標題、書籤、電子TOC與印頁逐一比對，0剩餘錯配；此三節沒有內文直接section-link，已檢實際annotations而未假稱抽到不存在的引用。全部268 named links可解析。

## 編譯、搬移恢復與閱讀

```sh
cd book
python3 verify.py
python3 build.py --entry volume --clean --debian-unindexed
```

一般已索引TeX Live可省Debian switch。需Python3、PyMuPDF(fitz)及XeLaTeX含fontspec/unicode-math/tcolorbox/titlesec/fancyhdr/geometry/enumitem/tocloft/etoolbox/hyperref/bookmark。11字型二進位與許可隨源提供。實際XeTeX0.999996／TeXLive2025-dev Debian；build記錄所有實載source、字型與外部package hash。3遍收斂；0硬錯誤、0overfull、0頁眉警告；8個既有underfull有相同badness，實圖或B06完全相同內容區證據確認可讀後KEEP。樣式／來源固定與工程／閱讀不代替數學終審。

主控另路徑獨立乾淨重建同69fc84…來源，QA原件quality/B07-INDEPENDENT-REBUILD.json已複製到qa/independent-rebuild.json。209頁文字、逐頁像素、links與書籤全等。另產PDF二進位hash ecba9a8dfa9ae50d78ea91578826a9826242024708e9b3b96d6c623e953d4a2c，與配對9a67df…不同；不宣稱binary相同，唯一交付PDF仍為9a67df…。不猜差異成因。

全209頁像素重流：150頁全頁像素完全相同；另21頁主內容區、頁眉及左頁腳完全相同，只頁碼offset已逐頁核label；總171頁可承接B06真實逐頁實看證據。38頁內容變化需新看，全部已新看；排版官總共個別打開64完整候選頁，涵蓋38變頁、所有直接前後、受影響章縫158/159、192/193及208/209，並實看三個節定位頁及其前頁。每頁記方法與baseline offset，沒有把文字抽取或像素本身冒充初次閱讀。未變其他章縫承接固定B06真實閱讀，不稱這次另看全209頁。

## 保留、OPEN／UNKNOWN與責任

- 候選外觀KEEP：158短章尾；184–185 Fu-/bini跨頁斷字。完整數學可見；不為這兩點重編。
- 多公式Prop206.7在162/163有continued；長Definition206.26在175/176、擴充corner定義206.34在181/182有清楚續接。全部內容及式完整；保留自然長單元跨頁。
- 原B06兩個單字孤尾及部分短尾句仍存在，某些頁因+2 offset改號；不冒稱已修。References209頁眉正確，無前章污染。
- B07-01–09的M/N修正：精修回執已接受且exact合入，但仍待同一唯一B07角色對本source/PDF裁決。本官只確認回調一致、版面可見和工程保護，不簽數學PASS。
- 原B05 SUPPORT OPEN5／source UNKNOWN31及全局未知沿原責任保留；不因局部修稿清零。主coverage行號更新由主控以本固定稿接續，不改母表／來源閱讀史。
- 模型／High實際設定未核實。持久化由主控既有入口續接，本角色未宣稱遠端發布或B08封存成功。

下一角色唯一階段：同一B07打厚終審者實讀本固定pair，按01–10、新頁定位、精修diff、直接與傳遞依賴重核；符合才由其明示針對同一source/PDF的PASS。版面問題退本官，任何語義修後仍回該唯一角色。未通過／未授權不做B08；不重啟其他卷、不改工具ZIP、卷界文獻表或凍結稿，不復活雙NO OBJECTIONS。
待使用者決策：無。已授權候選實作完成；數學裁決正在同一終審責任鏈。
傳遞：外層pair及no-further-change已經agent訊息送主控，主控已就同源另重建並指派同一終審；本完整交接與可下載包隨後送達。接收方是否實讀本件須回執，不以生成檔案代已讀。

【接收回執】
交接ID／版本：V15-B07-REPAIR-PAIR-R1／v1。
實讀／hash：outer071093…、source69fc84…、PDF9a67df…及初審／精修／ledger逐一核。
可讀／缺檔／權限／衝突：據實列。
理解範圍：V15，B單一Work，195–207，65節；候選待同一B07終審；M/N未偽裝E；四校準與B06凍結保留。
接受續作／局部阻塞：據實填，不因單一缺檔全卷重做。
下一步／不重做：只按01–10與受影響傳遞複核；不改固定pair、不重啟上游或其他卷。
