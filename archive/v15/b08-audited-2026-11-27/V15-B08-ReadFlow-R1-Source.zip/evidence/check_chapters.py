"""Check a V15 chapter set against its fixed structure and cross-references."""

import argparse
import csv
import hashlib
import json
import re
from pathlib import Path


parser = argparse.ArgumentParser()
parser.add_argument("book", type=Path)
parser.add_argument("design", type=Path)
parser.add_argument("--report", type=Path)
args = parser.parse_args()

error_messages = []
theorem_types = {
    "definition", "theorem", "proposition", "lemma", "corollary",
    "example", "remark", "problem", "proof", "psolution",
}
label_locations = {}
reference_locations = []
chapter_records = {}

with args.design.open(encoding="utf-8-sig", newline="") as stream:
    section_plan = list(csv.DictReader(stream, delimiter="\t"))

expected = {f"ch{chapter}.tex" for chapter in range(195, 208)}
files = {path.name: path for path in (args.book / "chapters").glob("ch*.tex")}
if set(files) != expected:
    error_messages.append(f"Chapter files differ: missing {expected - set(files)}, extra {set(files) - expected}")

for filename in sorted(expected.intersection(files)):
    path = files[filename]
    chapter = int(filename[2:5])
    data = path.read_bytes()
    text = data.decode("utf-8")
    clean = re.sub(r"(?<!\\)%[^\n]*", "", text)
    chapter_commands = re.findall(r"\\chapter\{", clean)
    if len(chapter_commands) != 1 or f"\\label{{ch:{chapter}}}" not in clean:
        error_messages.append(f"{filename}: requires one chapter with label ch:{chapter}")
    section_labels = [
        label for label in re.findall(r"\\label\{(sec:[^}]+)\}", clean)
    ]
    planned = [r["label"] for r in section_plan if int(r["chapter"]) == chapter]
    if not planned or section_labels != planned:
        error_messages.append(f"{filename}: sections differ: {section_labels!r} versus {planned!r}")
    if re.search(r"\\(?:documentclass|usepackage|setcounter\s*\{chapter\})", clean):
        error_messages.append(f"{filename}: a chapter file contains document-level setup")

    count_by_kind = dict.fromkeys(sorted(theorem_types), 0)
    for lineno, line in enumerate(clean.splitlines(), 1):
        for key in re.findall(r"\\label\{([^}]+)\}", line):
            if key in label_locations:
                error_messages.append(f"Duplicate label {key}: {label_locations[key]}, {filename}:{lineno}")
            label_locations[key] = {"file": filename, "line": lineno}
        for key in re.findall(r"\\(?:ref|eqref|pageref|autoref|nameref)\*?\{([^}]+)\}", line):
            reference_locations.append((key, filename, lineno))
        for kind in re.findall(r"\\begin\{([^}]+)\}", line):
            if kind in theorem_types:
                count_by_kind[kind] += 1

    chapter_records[str(chapter)] = {
        "filename": filename, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
        "sections": section_labels, "environments": count_by_kind,
    }

for key, filename, line in reference_locations:
    if key not in label_locations:
        error_messages.append(f"{filename}:{line}: missing target for {key}")

report = {
    "chapters": chapter_records,
    "labels": label_locations,
    "reference_count": len(reference_locations),
    "errors": error_messages,
}
if args.report:
    args.report.write_text(json.dumps(report, indent=2) + "\n")
if error_messages:
    print("\n".join(error_messages))
    raise SystemExit(1)
print(f"{len(chapter_records)} chapters, {len(label_locations)} labels, {len(reference_locations)} references")
