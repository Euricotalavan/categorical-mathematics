# V15 B-01｜參考書與固定版本

## 五本全文

使用者要求至少三本可讀全文的優質公開教材，並追加于品講義及親自提供 Spivak 全本。前三本已達公開教材門檻。于品與 Spivak 另有各自的版本、存取及採用範圍。

| 代號 | 固定來源 | PDF 頁 | Bytes | SHA-256 |
|---|---|---:|---:|---|
| LS | Lynn H. Loomis、Shlomo Sternberg，*Advanced Calculus*，Jones and Bartlett 1990 修訂版，ISBN 0-86720-122-3，哈佛作者公開檔。 | 592 | 31730715 | `00fba27efa15a1ef378975db0d2ccfbe2564c62c18003f1c493f543f4182a70d` |
| LB | Jiří Lebl，*Basic Analysis II: Introduction to Real Analysis*，2026-05-15 v6.3 作者公開檔。 | 217 | 1564040 | `a89e544f4010781f16ad39721eb916ecf3d51d9e9d3b91793a66df09b1809da3` |
| MT | Michael Taylor，*Introduction to Analysis in Several Variables*，UNC 作者公開版。其書有 AMS 2020 出版版，該版書目僅旁證教材身分。工作頁碼固定 UNC 檔。 | 462 | 1953833 | `2b988fe04c21051a75c03deb138f972e534b85b9a1e9627b632b65c59d9ccfb4` |
| YP | 于品，《數學分析之課程講義（丘成桐數學英才班試用）》，2020-12-27 三學期稿。從 V14 既有來源恢復及重取同指紋。 | 1001 | 9141321 | `6f2b9dc65d45728472908f12a74d5f5434e51458600f945a7236b53cead58888` |
| SP | Michael Spivak，*Calculus on Manifolds*，Addison–Wesley ©1965，第 24 次印刷，1995-01，ISBN 0-8053-9021-9。使用者所附完整掃描。 | 158 | 7018515 | `1fa428e31bf6ab1e6f16a8d53cc34dd66920b9e1fc287ddc1a172caa7eed4862` |

- **LS** 的數字印頁與 PDF 實體頁相差 12（PDF＝印＋12）。OCR 公式應回看原圖。作者頁可取完整書，並列該頁相關授權，出版 PDF 本身仍有權利聲明。[哈佛作者頁](https://people.math.harvard.edu/~shlomo/) · [全文 PDF](https://people.math.harvard.edu/~shlomo/docs/Advanced_Calculus.pdf) · [賓大書目](https://onlinebooks.library.upenn.edu/webbin/book/lookupid?key=olbp53325)
- **LB** 印頁＝PDF 頁。作者列 CC BY-SA 4.0 或 CC BY-NC-SA 4.0。§§8.2–8.6 及 §§9.2、10.1–10.7 是本次選用的多元部分。[作者頁](https://www.jirka.org/ra/) · [全文 PDF](https://www.jirka.org/ra/realanal2.pdf) · [AIM 開放教材推薦](https://textbooks-dev.aimath.org/textbooks/approved-textbooks/lebl-ra/)
- **MT** 的阿拉伯數字印頁以 PDF＝印＋13 對照。活用 §3.1 中在 Stokes 之前的獨立換元證明，§4.5 的證法另留比較。末有 bibliography 和 index。[UNC 作者 PDF](https://mtaylor.web.unc.edu/wp-content/uploads/sites/16915/2018/04/analmv.pdf) · [MAA 書目](https://old.maa.org/press/maa-reviews/introduction-to-analysis-in-several-variables-advanced-calculus)
- **YP** 的工作範圍印頁＝PDF。先核 1–8 頁版本與作者對筆誤的說明，再選讀 335–424 的微分/逆隱/極值、524–546 的換元/曲面、553–594 的散度與 Riemann 習題及 618–622、644–646。原檔的公開入口是第三方彙整，原件以內部文獻比對使用，發布授權仍待核。清華作者頁與復旦課程書目另用於身分佐證。[清華作者頁](https://www.math.tsinghua.edu.cn/info/1125/2640.htm) · [復旦課程書目](https://jwc.fudan.edu.cn/_upload/article/files/d4/56/707002a8413b8a3cc690244c1118/5f39341f-9c23-496e-807b-cc7ae77cd970.pdf)
- **SP** PDF 1–12 為卷首，PDF 13–158 對印頁 1–146。PDF 12、150 回影像確認為空白。章 1–5、書目、索引及印頁 145–146 的 Addenda 均在。PDF 原本無文字層，本輪以辨識文字定位、公式回掃描。PDF 8 的 1968 年修訂前言指出，定理 3-11 後的材料已重修。印刷版與先前 CRC 2018 版兩頁試閱另記。使用者附件為內部核讀的固定來源。[版次背景與出版商書目](https://www.routledge.com/Calculus-On-Manifolds-A-Modern-Approach-To-Classical-Theorems-Of-Advanced/Spivak/p/book/9780805390216)

## 補充資料與留待補核版本

| 代號 | 來源 | PDF 頁 | Bytes | SHA-256 |
|---|---|---:|---:|---|
| FR | Daniel S. Freed，*Multivariable Analysis*，2019 大學部課程、2021-02-02 檔。Banach 證明與例題對讀。 | 199 | 3851715 | `228eaccab2ea641f6a39b426c89cfc7c09c8bb825254a1577e7e8ae17646c0f3` |
| MIT | Victor Guillemin，MIT OCW *18.101 Analysis II*，Fall 2005 合訂筆記。形式、定向、積分與 Stokes 局部比對。 | 161 | 1688453 | `7941e598833dbedf0b31ae824a26e3c77407f73b9204e317812c2b58a7318429` |
| MIT-COV | 同課補講的 C² 換元證明，依賴微分形式。 | 30 | 351589 | `47615ea1382ec5f82395f9ba508cce799cf098d0d9842f2f5929f246c41a65fc` |
| SP-PRE | CRC 2018 電子零售試閱，正文印 1–2，歷史取得紀錄。 | 17 | 11246453 | `f107dc2f48cb027ce51891f49a85d2391da7448f49070dc9e8d0e680362f4388` |

[Freed 原檔](https://web.ma.utexas.edu/users/dafr/multi-with-homework.pdf) · [MIT 課程資料](https://ocw.mit.edu/courses/18-101-analysis-ii-fall-2005/pages/lecture-notes/) · [OpenStax §5.7 算例](https://openstax.org/books/calculus-volume-3/pages/5-7-change-of-variables-in-multiple-integrals) · [Spivak 歷史試閱](https://api.pageplace.de/preview/DT0400.9780429970450_A37409959/preview-9780429970450_A37409959.pdf)

Shifrin *Multivariable Mathematics*（Wiley 第 1 版，ISBN 9780471526384）保留原書目，目錄與勘誤已知，正文 UNKNOWN，無正式逐題責任。Spivak 的 2018 試閱限制仍只適用該試閱，1995 使用者掃描全本另有逐項核讀範圍。[Shifrin 作者頁](https://math.franklin.uga.edu/directory/people/theodore-shifrin)

本冊參考資料包含書目、原頁定位、條件、證明依據與自寫說明，不附原書、掃描裁圖及 OCR 全文。
