# Volume 15 · Multivariable Analysis

Chapters 195–207, 65 sections, 209 pages. English ReadFlow R1 edition, 2026-11-27. The independent B-07 reviewer accepted the manuscript and the exact matching PDF, with all ten initial findings resolved.

- Read the fixed PDF at `book/V15-Multivariable-Analysis.pdf`.
- Open the editable entry at `book/volume-15.tex`. The chapter sources, relative font dependencies, and notices are under `book/`.
- The paired edition and review fingerprints are in `B08-PAIR.json`. Find the independent verdict at `evidence/B07-FINAL.md` and the 990 source locations at `evidence/V15-B07-Coverage.tsv`. The source and edition register is `references/SOURCES.md`.

## Verify and rebuild

Run `python3 book/verify.py`. Then from `book/` run `python3 build.py --entry volume --clean` using XeLaTeX. Use the additional `--debian-unindexed` option for the documented unindexed TeX Live installation. The independent recovery build used three converged passes. Page text, page pixels, bookmarks and link destinations all matched the approved PDF. Its signed binary is retained exactly here.

The archive supplies the 529 covered core source items and the recorded boundaries of the optional and unknown source items. Edition-specific originals and OCR have separate access records in the source register. This public archive contains the audited edition and its review evidence.
