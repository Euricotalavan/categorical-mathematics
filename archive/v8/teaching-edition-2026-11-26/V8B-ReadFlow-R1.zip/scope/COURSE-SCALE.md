# V8 — Mathematical Logic and Model Theory

課量先鎖；來源未簽核，不寫稿。id="V8"> V8 數理邏輯與模型論 2 學期預估 · 12 章 逐卷正式定界待核 先備 集合與證明；基本代數 教完落點 證明核心元定理並完成一個模型論應用。 預估 2 學期，96 接觸小時；其中新內容 72、例題 12、專題 6、評量 6 小時。課量為規劃估算。 章號 章名 印頁／預估課時 1 命題語言與推演 6.0 小時 2 量詞、項與一階語言 6.0 小時 3 語法、語義與元理論 6.0 小時 4 一階演算 6.0 小時 5 完備性 6.0 小時 6 緊緻性 6.0 小時 7 Löwenheim–Skolem 定理 6.0 小時 8 初等等價與初等嵌入 6.0 小時 9 型與實現 6.0 小時 10 飽和模型 6.0 小時 11 可定義性 6.0 小時 12 代數中的模型論例 6.0 小時

| 章 | 正文（每格 90 分） | 例題課 |
|---|---|---|
| 114 命題語言與推演 | inductive formula grammar ／ unique parsing and structural induction ／ valuations, truth tables and valid consequence ／ natural deduction with a soundness check | 60 分 |
| 115 量詞、項與一階語言 | signatures and term evaluation ／ free places and capture-avoiding substitution ／ assignments and quantifier satisfaction ／ countermodels and the substitution lemma | 60 分 |
| 116 語法、語義與元理論 | object language vs metalanguage ／ satisfaction and semantic consequence ／ finite derivations and syntactic consequence ／ countermodels and roles of a metatheorem | 60 分 |
| 117 一階演算 | introduction and elimination rules ／ eigenvariable conditions and derivations ／ induction proving soundness ／ diagnose an invalid proof step and repair | 60 分 |
| 118 完備性 | consistent syntactic theories and maximal extension ／ Henkin constants and witness extension ／ quotient term model with a truth lemma ／ completeness and the provability/consequence distinction | 60 分 |
| 119 緊緻性 | finite satisfiability vs syntactic consistency ／ derivation from completeness ／ elementary-diagram or nonstandard example ／ why finite satisfiability does not yield finite models | 60 分 |
| 120 Löwenheim–Skolem 定理 | downward witness closure ／ Tarski–Vaught proof with cardinal bound ／ upward argument with distinct constants ／ size and countability pitfalls | 60 分 |
| 121 初等等價與初等嵌入 | distinguish isomorphism and elementary equivalence ／ preservation by elementary embedding ／ elementary diagrams and umbrella examples ／ back-and-forth scope and examples | 60 分 |
| 122 型與實現 | types over parameters and definable conditions ／ consistent partial types and extensions ／ realized vs omitted examples ／ compactness and realization in extensions | 60 分 |
| 123 飽和模型 | define fixed-cardinal saturation over small parameter sets ／ explicit missing type in a nonsaturated model ／ construction under stated cardinal hypotheses or a countable-stage example ／ compare saturation, homogeneity and universality without conflating them | 60 分 |
| 124 可定義性 | parameters and definable sets ／ closure and invariance under automorphisms ／ quantifier elimination criterion with explicit restrictions ／ work out a definability and nondefinability example | 60 分 |
| 125 代數中的模型論例 | field language and algebraically closed fields by characteristic ／ one-variable quantifier elimination or exact adopted criterion ／ a worked transfer result with proof ／ delimit assumptions and non-generalizations | 60 分 |

合計 96 小時：正文 72、例題 12、整合專題 6、評量 6。先校準第 118 章。

- Every session maps to actual manuscript anchors with definitions and hypotheses, a teachable proof or construction with steps, worked reasoning, in-class check and answer. Proof and hour gates independent of PDF page count.
- One new step-by-step example and three graded practice exercises with full solutions per chapter.
- 4 sessions of 90 minutes; authentic problem, checkpoints, instructor solution and 100-point rubric.
- Question sheets and worked answer keys on separate pages; total 6 hours means two 120-minute sittings plus two 60-minute debriefs; total 3 hours means one 90-minute sitting and 90-minute debrief.
- B-01 primary-source decision before calibration. Calibrate one complete chapter, including teaching materials, before any full production.
- Pass exact scope, assigned chapter, mathematical source evidence, verified dependencies and approved notation to every job. Attach actual text, hash it, and stop if a required document is missing. Independent anchored math and depth audit sees full draft.
- Build and rasterize XeLaTeX PDF, verify manuscript counts and all hour plans, package exact source hashes, publish only when explicitly requested. Teaching hours remain planning estimates, not classroom measurements.

原參考卡書目候選（非原文證據）：
- A Mathematical Introduction to Logic
- Model Theory: An Introduction
- A Shorter Model Theory
