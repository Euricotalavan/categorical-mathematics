# Current font dependency notice

The font files are redistributed unmodified with their existing filenames and internal naming. PagellaX uses its upstream newpx/LPPL notices, Asana and STIX use their included OFL notices, Noto uses its included copyright/OFL notice, and DejaVu uses its included copyright/license. See `licenses/` here and the file-level hashes in `../provenance/font-sources.json`. `FONT-COPYRIGHTS.txt` and the original font documentation are retained. No license is asserted over the user's manuscript.

The notices under the package-root `licenses/` are exact historical R1 notices, some describing earlier fonts that R1 itself did not bundle. They are not a list of fonts active in this V19 shell.
