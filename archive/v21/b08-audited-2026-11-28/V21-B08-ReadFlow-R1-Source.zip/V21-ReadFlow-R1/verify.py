#!/usr/bin/env python3
"""Check the archived source and the exact paired publication PDF."""
import argparse
from hashlib import sha256
from pathlib import Path, PurePosixPath
import json

ROOT = Path(__file__).resolve().parent


def verify_one(root, entry):
    relative = PurePosixPath(entry["path"])
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Unsafe manifest path {relative}")
    path = root.joinpath(*relative.parts)
    if not path.is_file():
        raise FileNotFoundError(relative)
    digest = sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    if path.stat().st_size != entry["bytes"] or digest.hexdigest() != entry["sha256"]:
        raise ValueError(f"Fingerprint mismatch for {relative}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=ROOT / "MANIFEST.json")
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    if manifest["chapters"] != list(range(270, 282)):
        raise ValueError("Chapter interval is not Volume 21")
    entries = manifest["files"]
    paths = [entry["path"] for entry in entries]
    if len(paths) != len(set(paths)):
        raise ValueError("Manifest contains duplicate paths")
    for entry in entries:
        verify_one(args.manifest.resolve().parent, entry)
    for chapter in manifest["chapters"]:
        if f"chapters/ch{chapter}.tex" not in paths:
            raise ValueError(f"Missing chapter {chapter}")
    if manifest["paired_pdf"] not in paths:
        raise ValueError("Paired PDF is missing from manifest")
    print(f"Verified {len(entries)} files and paired PDF for Chapters 270–281.")


if __name__ == "__main__":
    main()
