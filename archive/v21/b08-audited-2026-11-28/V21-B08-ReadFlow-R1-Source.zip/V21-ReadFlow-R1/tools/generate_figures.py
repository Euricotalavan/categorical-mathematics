"""Regenerate the three original plots used in Volume 21."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

DESTINATION = Path(__file__).resolve().parents[1] / "figures"
DESTINATION.mkdir(exist_ok=True)
INK = "#112b39"
BLUE = "#176e91"
RED = "#a94828"
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9,
    "text.color": INK,
    "axes.labelcolor": INK,
    "axes.edgecolor": INK,
    "xtick.color": INK,
    "ytick.color": INK,
    "pdf.fonttype": 42,
})
METADATA = {"Creator": "V21 source", "CreationDate": None, "ModDate": None}


def style(axis):
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(alpha=0.18, linewidth=0.6)
    axis.set_axisbelow(True)


def fourier_kernels():
    degree = 8
    t = np.linspace(-np.pi, np.pi, 2401)
    modes = np.arange(1, degree + 1)[:, None]
    cosines = np.cos(modes * t)
    dirichlet = 1 + 2 * cosines.sum(axis=0)
    fejer = 1 + 2 * ((1 - modes / (degree + 1)) * cosines).sum(axis=0)
    assert abs(dirichlet[len(t) // 2] - (2 * degree + 1)) < 1e-12
    assert abs(fejer[len(t) // 2] - (degree + 1)) < 1e-12
    assert fejer.min() >= -1e-12
    fig, ax = plt.subplots(figsize=(5.8, 2.55), layout="constrained")
    ax.plot(t, dirichlet, label=r"$D_8(t)$", color=RED, linewidth=1.6, linestyle="--")
    ax.plot(t, fejer, label=r"$F_8(t)$", color=BLUE, linewidth=1.8)
    ax.set(xlabel=r"Angle $t$", ylabel="Kernel value", xlim=(-np.pi, np.pi))
    ax.set_xticks([-np.pi, -np.pi / 2, 0, np.pi / 2, np.pi],
                  [r"$-\pi$", r"$-\pi/2$", "0", r"$\pi/2$", r"$\pi$"])
    ax.axhline(0, color=INK, linewidth=0.6)
    ax.legend(frameon=False)
    style(ax)
    fig.savefig(DESTINATION / "circle-kernels.pdf", metadata=METADATA)
    plt.close(fig)


def laplace_vertical_lines():
    # L{e^{-t} 1_{t>0}}(c+i tau) = 1/(1+c+i tau).
    tau = np.linspace(-7, 7, 1801)
    fig, ax = plt.subplots(figsize=(5.8, 2.4), layout="constrained")
    for c, color, dash in ((-0.45, RED, "--"), (0.65, BLUE, "-")):
        magnitude = 1 / np.sqrt((c + 1)**2 + tau**2)
        ax.plot(tau, magnitude, label=fr"$c={c}$", color=color,
                linewidth=1.7, linestyle=dash)
    ax.set(xlabel=r"Imaginary coordinate $\tau$", ylabel=r"$|(1+c+i\tau)^{-1}|$")
    ax.legend(frameon=False)
    style(ax)
    fig.savefig(DESTINATION / "laplace-vertical-lines.pdf", metadata=METADATA)
    plt.close(fig)


def radon_cutoff():
    # f(x) = exp(-pi |x|^2); noise is flat on a <= |sigma| <= b.
    a, b, amplitude = 0.55, 1.35, 0.18
    omega = np.linspace(0, 1.9, 1200)
    bias_sq = 0.5 * np.exp(-2 * np.pi * omega**2)
    noise_sq = np.pi * amplitude**2 * np.maximum(np.minimum(omega, b)**2 - a**2, 0)
    assert noise_sq[0] == 0 and abs(noise_sq[-1] - np.pi * amplitude**2 * (b*b-a*a)) < 1e-12
    fig, ax = plt.subplots(figsize=(5.8, 2.55), layout="constrained")
    ax.plot(omega, bias_sq, label="Squared bias", color=BLUE, linewidth=1.5, linestyle=":")
    ax.plot(omega, noise_sq, label="Squared propagated noise", color=RED, linewidth=1.5, linestyle="--")
    ax.plot(omega, bias_sq + noise_sq, label="Squared total error", color=INK, linewidth=1.8)
    for edge in [a, b]:
        ax.axvline(edge, color=INK, linewidth=0.7, alpha=0.4)
    ax.set(xlabel=r"Cutoff $\Omega$", ylabel="Squared reconstruction error",
           xlim=(0, omega[-1]), ylim=(0, 0.52))
    ax.legend(frameon=False)
    style(ax)
    fig.savefig(DESTINATION / "radon-cutoff-error.pdf", metadata=METADATA)
    plt.close(fig)


if __name__ == "__main__":
    fourier_kernels()
    laplace_vertical_lines()
    radon_cutoff()
