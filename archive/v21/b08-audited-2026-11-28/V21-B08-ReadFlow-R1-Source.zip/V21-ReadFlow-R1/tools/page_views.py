#!/usr/bin/env python3
"""Prepare fixed-PDF page views, 2x2 review sheets and navigation. No review status inferred."""
from pathlib import Path
import argparse,hashlib,json,re,fitz
from PIL import Image,ImageDraw,ImageFont

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('pdf',type=Path);p.add_argument('--out',type=Path,required=True);p.add_argument('--start',type=int,default=1);p.add_argument('--end',type=int);p.add_argument('--dpi',type=int,default=135);a=p.parse_args()
 a.out.mkdir(parents=True,exist_ok=True)
 doc=fitz.open(a.pdf);end=a.end or len(doc)
 if not 1<=a.start<=end<=len(doc):p.error('Invalid physical page range')
 identity=sha(a.pdf);pages=[];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22)
 for n in range(a.start,end+1):
  page=doc[n-1];f=a.out/f'page-{n:04d}.png'
  page.get_pixmap(matrix=fitz.Matrix(a.dpi/72,a.dpi/72),alpha=False).save(str(f))
  spans=[s for b in page.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans'] if s.get('text','').strip()]
  footer=lambda s: s['bbox'][1]>695 and (s['text'].startswith('V21 /') or re.fullmatch(r'[ivxlcdm0-9]+',s['text']))
  body=[s for s in spans if s['bbox'][1]>45 and not footer(s)]
  rows=[l for b in page.get_text('dict')['blocks'] for l in b.get('lines',[]) if l['bbox'][1]>45 and l['bbox'][3]<695]
  pages.append({'physical_page':n,'pdf_sha256':identity,'image':str(f),'image_sha256':sha(f),'page_label':page.get_label(),'characters':len(page.get_text()),'body_max_bottom':max([s['bbox'][3] for s in body],default=0),'footer_risk_spans':[{'text':s['text'],'bbox':list(s['bbox'])} for s in body if s['bbox'][3]>690],'white_spans':[{'text':s['text'],'bbox':list(s['bbox'])} for s in body if s['color']==0xffffff],'outside_page_spans':[{'text':s['text'],'bbox':list(s['bbox'])} for s in body if s['bbox'][0]<0 or s['bbox'][2]>page.rect.width+.2 or s['bbox'][1]<0 or s['bbox'][3]>page.rect.height+.2],'top_text':' '.join(s['text'] for s in body[:5]),'bottom_text':' '.join(s['text'] for s in body[-5:]),'status':'NOT_YET_REVIEWED'})
 sheets=[]
 for offset in range(0,len(pages),4):
  batch=pages[offset:offset+4];imgs=[Image.open(x['image']).convert('RGB') for x in batch];w=max(x.width for x in imgs);h=max(x.height for x in imgs);gap=14;label_h=36
  canvas=Image.new('RGB',(2*w+3*gap,2*(h+label_h)+3*gap),'#d2d9d7');draw=ImageDraw.Draw(canvas)
  for j,(record,im) in enumerate(zip(batch,imgs)):
   x=gap+(j%2)*(w+gap);y=gap+(j//2)*(h+label_h+gap)
   draw.text((x+8,y+3),f'Physical page {record["physical_page"]} | PDF {identity[:12]}',font=font,fill='#142825');canvas.paste(im,(x,y+label_h))
  q=a.out/f'sheet-{batch[0]["physical_page"]:04d}-{batch[-1]["physical_page"]:04d}.jpg';canvas.save(q,quality=94,subsampling=0)
  sheets.append({'path':str(q),'physical_pages':[r['physical_page'] for r in batch],'sha256':sha(q)})
 rec={'pdf':str(a.pdf.resolve()),'pdf_sha256':identity,'total_pdf_pages':len(doc),'range':[a.start,end],'dpi':a.dpi,'status':'REVIEW_VIEWS_ONLY_NOT_A_VISUAL_PASS','sheets':sheets,'pages':pages}
 (a.out/'view-manifest.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
 heads=[]
 for level,title,page in doc.get_toc():
  if level==1:heads.append({'title':title,'physical_page':page})
 (a.out/'chapter-navigation.json').write_text(json.dumps(heads,indent=2)+'\n')
 summary={'pdf_sha256':identity,'total_pdf_pages':len(doc),'prepared_range':[a.start,end],'sheets':len(sheets),'footer_risk_pages':[r['physical_page'] for r in pages if r['footer_risk_spans']],'white_pages':[r['physical_page'] for r in pages if r['white_spans']],'outside_pages':[r['physical_page'] for r in pages if r['outside_page_spans']],'chapter_navigation':heads}
 (a.out/'view-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
