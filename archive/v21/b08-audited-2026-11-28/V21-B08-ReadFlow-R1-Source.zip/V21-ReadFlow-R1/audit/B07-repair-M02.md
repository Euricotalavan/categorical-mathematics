# B07-M02 targeted repair receipt

Status: canonical source correction applied; pending B06 reflow and independent B07 recheck. Role: precision. Scheme: B single Work, V21 Chapters 270–281. Date: 2026-11-28 UTC.

File: `/tmp/v21-work/chapters/ch279.tex`.

- Input SHA256: `f228ce3cacad2882329c228ea8880471d414a01eaa185a97ad21ddb347caf1bb`.
- Output SHA256: `4575717c1d83621f3ac6d8dd915738779e8eaa8e5640e5547ee4f8e38f5a32bd`.
- Affected passage begins at source line 358.
- File size: 46324 → 46751 bytes.

## Defect and correction

The general ellipse formula asserts a value at every line position, while the cited general affine theorem only declares an everywhere extension for continuous compactly supported or Schwartz objects. The proof now applies the same line-parameter substitution directly to these particular bounded indicators, justifies absolute integrability at every fixed line, and covers tangent and empty intersections. The general affine theorem scope is unchanged.

## Verification

The preceding disk calculation already gives the tangent singleton value zero. Invertible affine maps take disk chords, tangent singletons and empty intersections to their ellipse counterparts; the line-parameter change of variables is therefore valid for each fixed line. The existing determinant/normal factor and ellipse formula were left unchanged.

Only the stated passage was replaced. Reversing that single byte replacement recovers the exact input hash; every other byte is unchanged. No frozen candidate directory, unrelated author passage, or earlier volume was edited. The canonical input was captured immediately before this repair. Exact patch is `audit/B07-repair-M02.diff`.

The controller authorized this return repair. Layout should consume the output hash in its next B06 snapshot. The independent B07 lead must verify the correction and its rendered text; this receipt is not a B07 pass or final archival authorization.

```diff
--- ch279.tex before M02
+++ ch279.tex after M02
@@ -355,7 +355,11 @@
 \end{proposition}
 
 \begin{proof}
-Let $A=C^{1/2}$, so $E=c+A D_1$. The affine formula gives the factor $\det A/|A^T\omega_\theta|=\sqrt{\det C}/a_\theta$, while the unit-disk formula is evaluated at $(s-c\cdot\omega_\theta)/a_\theta$. Combining the two expressions proves the assertion.
+Let $A=C^{1/2}$, so $E=c+A D_1$.
+
+For each fixed $s$ and $\theta$, the same affine line-parameter substitution applies directly to the bounded disk and ellipse indicators. Their intersections with the corresponding lines have finite length, so the line integrals are absolutely convergent. A tangent intersection is a singleton of zero line measure, and an empty intersection contributes zero. Thus the affine identity used here holds at every line position.
+
+The affine formula gives the factor $\det A/|A^T\omega_\theta|=\sqrt{\det C}/a_\theta$, while the unit-disk formula is evaluated at $(s-c\cdot\omega_\theta)/a_\theta$. Combining the two expressions proves the assertion.
 \end{proof}
 
 The range of line positions has width $2a_\theta$, while the central chord has length $2\sqrt{\det C}/a_\theta$. A wider interval in $s$ is accompanied by a smaller central chord. Their product is $4\sqrt{\det C}$, independent of the direction. More precisely, substituting $u=(s-c\cdot\omega_\theta)/a_\theta$ gives
```
