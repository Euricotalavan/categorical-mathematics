# B07 M05 · Mellin continuation example in the source audit

The B05 responsibility entry V21-277-X01 treated the noninjectivity example as deferred in full. The fixed Ch277 includes the constant-input counterexample in the remark “Continuation does not automatically preserve injectivity.” Splitting at one yields the continued halves 1/s and −1/s. This is a contextual warning about the generalized prescription. A full treatment of generalized Mellin theory remains outside the chapter.

The B05 ledger is retained as the historical integration receipt. The final ledger in B08-coverage.tsv records this actual passage. Its other line locations and source file fingerprints follow the final manuscript after the B06–B07 revisions. M05 did not alter the typeset chapter.
