# V21 B-03 controller decision

**Approved for B-04.** English Fejér averages calibration at planned §271.3. In this Work the user delegated the manual approval to the controller. The controller read the fixed LaTeX and the mathematics. The mathematical review of the final volume remains B-07.

- Candidate `roles/B03-ch271-fejer-expansion.tex`, SHA-256 `5b1182430bbca9f6b68df73b68c45dd81a0b063024f61a0f3ff062ea6107e497`.
- Independent proof review `audit/B03-independent.md`. Precision checked the original sources and definitions in `audit/B03-precision-review.md`.
- Calibrated XeLaTeX PDF 6 pages, SHA-256 `66fa4f4e67dcd25fa9e13dc016faeeac24bb5e93e56df3a79d86eb1334603cdf`. The layout role inspected all six pages and verified zero hard or overfull diagnostics. See `roles/B03-engineering-preflight.md` and `qa/B03-visual-receipt.json`.
- The controller independently confirmed the triangle count and geometric sum, the endpoint value, the continuity-point and (L^1) far-field estimates, the use of translation continuity without importing the theorem being proved, the midpoint limit, and the lower bound on a positive-measure neighborhood for the step example. The triangular and square expressions, mass, and quantitative envelope were also evaluated numerically for (N=0,1,2,8,64).

The full chapter must supply translation continuity before the representative section. In the merged §271.3, use essential bounds when data may fail to attain extrema, state the Lipschitz rate as (O(\log(eM)/M)), and retain the actual rate proof. The full-volume design fixes the Fourier convention, the enumeration 270–281, and the order of prerequisites.

The calibration estimates approximately 26–30 pages of content per chapter under ReadFlow R1. Complete proof sequences and genuinely different solved problems carry the page budget. Actual section and chapter pages will be checked before B-06.
