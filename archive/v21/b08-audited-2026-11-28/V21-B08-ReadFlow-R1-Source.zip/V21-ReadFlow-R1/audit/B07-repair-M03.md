# B07-M03 targeted repair receipt

Status: canonical source correction applied; pending B06 reflow and independent B07 recheck. Role: precision. Scheme: B single Work, V21 Chapters 270–281. Date: 2026-11-28 UTC.

File: `/tmp/v21-work/chapters/ch278.tex`.

- Input SHA256: `90f798d1900c8c9ba88eb56a59f40c5e9c81c89c8ab1ca0d9ea13dc0289c7592`.
- Output SHA256: `e13f238e65b971faeb29f139403ec74aa4acf43646d5394ba7f7255ad6f150fe`.
- Affected passage begins at source line 494.
- File size: 44629 → 44753 bytes.

## Defect and correction

The weighted spectral cutoff proposition used f_R without a local definition, after the preceding inverse theorem used a different symbol for its Mellin inverse. Its statement now explicitly defines f_R as the Mellin inverse of the truncated line data and explicitly assumes R>0. The proposition and proof retain their existing consistent local f_R notation.

## Verification

The referenced theorem ch278:thm-l2inverse defines the weighted Mellin L2 inverse of these bilateral cutoffs. The displayed tail integral, derivative multiplier and R^(-m) estimate match this local definition. The noise argument still uses the same cutoff and weighted Plancherel norm. The M01 corrected absolute-inverse sentence was checked present before and after this repair. The incoming canonical hash differs from the M01-only hash because other controller-authorized work had already arrived; this patch preserves every byte of that incoming canonical version except the requested M03 insertion.

Only the stated passage was replaced. Reversing that single byte replacement recovers the exact input hash; every other byte is unchanged. No frozen candidate directory, unrelated author passage, or earlier volume was edited. The canonical input was captured immediately before this repair. Exact patch is `audit/B07-repair-M03.diff`.

The controller authorized this return repair. Layout should consume the output hash in its next B06 snapshot. The independent B07 lead must verify the correction and its rendered text; this receipt is not a B07 pass or final archival authorization.

```diff
--- ch278.tex before M03
+++ ch278.tex after M03
@@ -491,7 +491,7 @@
 
 \begin{proposition}[A weighted spectral cutoff error]
 \label{ch278:prop-cutoff}
-Suppose $f\in X_c^2$ and its log-coordinate function $h=U_cf$ has $m\geq1$ weak derivatives with $h^{(m)}\in L^2$. Here the $m$th weak derivative is specified by $\int h(u)\varphi^{(m)}(u)\,du=(-1)^m\int h^{(m)}(u)\varphi(u)\,du$ for every smooth compactly supported test function $\varphi$; lower weak derivatives have the analogous meaning. Denote $\Theta_c^mf=U_c^{-1}h^{(m)}$. Then the exact-data cutoff satisfies
+Suppose $f\in X_c^2$ and its log-coordinate function $h=U_cf$ has $m\geq1$ weak derivatives with $h^{(m)}\in L^2$. Here the $m$th weak derivative is specified by $\int h(u)\varphi^{(m)}(u)\,du=(-1)^m\int h^{(m)}(u)\varphi(u)\,du$ for every smooth compactly supported test function $\varphi$; lower weak derivatives have the analogous meaning. Denote $\Theta_c^mf=U_c^{-1}h^{(m)}$. For $R>0$, let $f_R$ be the Mellin inverse of the line data truncated to $[-R,R]$, as in Theorem~\ref{ch278:thm-l2inverse}. Then the exact-data cutoff satisfies
 \[
  \|f-f_R\|_{X_c^2}\leq R^{-m}\|\Theta_c^mf\|_{X_c^2}.
 \]
```
