# B07 M06 · Support in the Laplace overview

The original overview referred to Fourier data “on a half-line.” The frequency variable ranges over the full real line. The revised sentence assigns half-line support to the damped, zero-extended input and preserves the reflected frequency in the Mellin comparison.

Origin: independent B07 review; correction by controller as front-matter author.

Before SHA-256 `97e511976ac3f0c8af9c10d411e8a438a65ae7d88feb9408a4855f6ba939b032`

After SHA-256 `85f4450c34b6b59e52f7d2ffdea9bb16a726692da672320c770e6b4da9c64507`

The corresponding Ch278 formulas and data domains are unchanged. Recheck by B07 after the paired build.
