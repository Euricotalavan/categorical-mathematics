# V21 B-07 數學終審與交接

**通過。** 本結論由獨立打厚終審官作出，適用於 V21 第 270–281 章的唯一固定正文及配對的 B06-r2 PDF。PDF 為 V21-B06-Reading-r2.pdf，301 個實體頁，1,312,643 bytes，SHA-256 為 0c2c26f442dcb494fb75de233a386cb6d66a38a55f82109819732edf368b81ec。正文回修與覆蓋表修正已複核。可依本次授權進 B-08。

【交接及接收回執】

| 欄位 | 記錄 |
| --- | --- |
| 交接 ID、文案及日期 | V21-B07-FINAL-v1，2026-11-28 UTC。 |
| 發出、接收與傳遞 | 獨立打厚終審官交 V21 單一 Work 主控。同一 Work 的角色分派、退修、回執和決定訊息可查。最終交付包的存取連結由主控封存後回報。 |
| 方案與卷界 | 依使用者本次授權採 B 單一 Work，全程 B-01 至 B-08。B-07 對應原 A 整卷驗收與複核步驟 10 至 12。卷名 *Fourier Analysis and Integral Transforms*，第 270–281 章。 |
| 固定基線 | 分卷表與書目 v4、B-01 來源責任表、B-02 V21 敘事與依賴 v3。前卷末章 269，前卷固定於 Git commit 5e06e3e15db0e6192d4146c44501ff78be7a1914 的 V20 B-08 路徑。 |
| 接收版本 | 已實讀 B-06 初版有序章稿快照、PDF 的數學承載頁及正文依賴，再讀 B-04／B-05 修補史、來源責任和本輪退修回執。收妥 B06-r2 各檔，重新核對內容差異與固定 PDF。各實際使用檔案在後表。 |
| 授權與凍結 | 只審 V21 及本卷直接受影響的依賴。主控維持唯一正文，精修回修數學或表述，排版官處理版面。任何正文或配對 PDF 重變須回這一打厚終審。既有凍結內容按固定版保存。 |
| 模型與推理模式 | 實際執行模型和 High 設置在本審查回執中未核實。 |

## 每章核讀證據

先從 B-06 初版快照順讀定義與證明，檢查型別、量詞、依賴、逆運算、代表元、相位及收斂方式。再檢視歷史修補及有關原文責任。以下為各章獨立核對的具體落點與手算。頁碼皆為 r2 的實體頁。

| 章及頁 | 正文實核 |
| --- | --- |
| 270，8–34 | ch270:periodic 把 Lᵖ 類與選定代表分清。ch270:best-projection 從有限正交殘差取得投影與 Bessel，完備性在 271 才引入。重算 ch270:derivative 的端點項及 ch270:jumps 的跳躍正負號，以週期斜坡係數 i(−1)ⁿ/n 對算。ch270:case-positive-moments 的等號迫使質量落在有限集合，排除 L¹ 密度，兩點質量例成立。 |
| 271，35–58 | ch271:young 的三個 Hölder 倒數和為一，省略零次因子涵蓋重合指數。r=1 用 Tonelli，r=∞ 用共軛 Hölder。兩個 L¹ 因子仍可能在一點發散，與 a.e. 存在相容。ch271:prop-fejer-formula 的 N+1 項、質量與遠弧界給跳點半質量。先證 Fejér 密度，再從 ch271:parseval 得普通部分和的 L² 完備性。檢查 Abel 半群與有號保頻帶核的端點係數。 |
| 272，59–81 | ch272:bv-lemma 證小區間變差消失及有界 Dirichlet 原函數，ch272:jordan 據此取跡中值。以無窮變差例和兩組顯式截斷誤差檢查 Dini／BV 的不同假設。Gibbs 用 N+1/2，Fejér 用 N+1，後者的平方 sinc、質量與遠端跳躍 O((N+1)⁻²) 相符。有號核尾項保留正弦項，先固定移動尺度參數再取極限。ch272:fejer-lebesgue 的二倍環估計可加總。 |
| 273，82–107 | ch273:sec-definition 的 L¹ 變換逐點有意義。區間 sinc 例檢查頻域未必 L¹。ch273:prop-covariance 重算 A⁻ᵀ、行列式和高斯配對。ch273:prop-moments 用差商可積控制，並核 (1+\|x\|)⁻² 的轉換原點尖角。ch273:thm-convolution 及共軛因子命題限定不同輸出空間。週期化取樣係數來自 Tonelli 及分割平移區間。 |
| 274，108–131 | ch274:lem-regularized 的 Gaussian 阻尼令 Fubini 可用，ch274:thm-absolute-inversion 取得連續代表。ch274:thm-plancherel 用雙範數逼近識別經典變換，再用雙向逆得滿射。L² 但非 L¹ 的例子把截斷範數和零頻點值分清。Hermite 的 BA−AB=I/π、特徵值 (−i)ᵐ、正交性和規範常數逐步對算。ch274:case-window-spectrum 先核每點絕對配對，再用 Tonelli 得 a.e. 的 L² 切片，sinc 範例由頻帶交長算出。 |
| 275，132–157 | ch275:lem-finite-bound 與分佈變換採雙線性轉置，與 Hilbert 配對不同。導數、乘法及反射符號與 step 主值中的 δ₀/2 核對。ch275:thm-hausdorff-young 把解析冪、條帶邊界及雙線性配對一一對上。共振題核 Schwartz 的整體除法、L² 不可積例及分佈主值的調和自由度。Poisson 求和藉 Schwartz 晶格衰減、可積改序和 Fejér 乘積核辨識。 |
| 276，158–182 | ch276:prop-halfplane 及 ch276:thm-holomorphic 的絕對域和邊界，用條件收斂和高窄尖峰兩例驗明。導數初值、ch276:prop-green 的因果遞推及有限點質量例用 h′(0)=1、Fubini 和跳躍項交核。ch276:thm-rational 關閉左框時，水平邊由 Ceᶜᵗ/(Rt) 控制，左邊有指數衰減。重極點與部分分式的各項一致。 |
| 277，183–205 | ch277:prop-log-isometry 的權重由 dx/x=du 決定。ch277:eq-fourier 的反號、反演相位及 Euler 乘子 −iτ 相容。ch277:thm-subtraction 驗兩端可積餘項和對數主部符號，keyhole 驗負實軸留數及圓弧消失。兩個膨脹管道的穩定性用 2x²+x−1 的最小值，L² Mellin 滿射在本節從 274 推出。單管道近零例的支撐和資料範數對上。 |
| 278，206–226 | ch278:thm-plancherel 的量測為 dτ/(2π)，Mellin 滿射與 Laplace 因果子空間各有域。ch278:thm-causal-projection 的正交殘差正是負時間能量。ch278:thm-local-inverse 用本地 BV／Dini 及遠端 L¹ 控制，零時刻經因果延拓取得半值。矩形右邊向上給 I(c₂)−I(c₁) 為留數和，π/sin(πs) 範例在 x=1 的餘項有大小 1/2。四種反演與 Mellin 截斷誤差在回修後再次複核。 |
| 279，227–249 | ch279:lines、ch279:existence 查相反法線、切向弧長、a.e. 與聯合可測代表。零類的單線可以積出無窮。固定支撐 Hölder 常數 (2a)^(1−1/p) 有長方形逼近例。仿射切向比例 \|det A\|/\|Aᵀω\| 和橢圓面積交核。整圈方向上的變動總質量可否決具正確冗餘對稱的資料。 |
| 280，250–273 | ch280:slice 的固定角度 L¹ 論證直接改變積分變數。帶正負半徑的半圈用一次，整圈用兩次，Gaussian 原點驗濾波回投 1/2。ch280:normal 得 2/\|ξ\| 倍率與低頻限制。ch280:cutoff 的原點核值 Ω² 與有號 1/s 尾核清楚。有限角度零空間、徑向 beta 積分 π、平面 Poisson 核的質量、剖面、乘子及收斂各有直接驗算。 |
| 281，274–299 | 核半導數平方的 \|σ\| 權重及固定支撐的正階前向估計。高頻環證逆向常數 1/√2 最優。資料冗餘投影與物件頻帶投影各有定義，最優 cutoff 範數 √(Ω/2)、正交偏差及雜訊、確定性下界指數 2q/(2q+1) 和二輸入的常數均重算。Gaussian 平滑保留交叉項。數值表重算得最小點 0.7388080214、平方誤差 0.0409687195。角向變快的固定偵測帶例先構造可實現的 Radon 資料。 |

## 問題單與回修複核

| ID 與初版落點 | 原文／問題及影響 | 已合入處置及終審證據 |
| --- | --- | --- |
| M01，Ch278 初版 260–262，PDF 213 | “integrates the absolute value of the spectral integrand” 把絕對收斂的判準誤當逆運算，會消去符號和相位。 | 精修改為積分原頻譜被積函數，要求其絕對值可積。r2 p214 實讀。同章對稱及 Abel 段落與 274、276、277 已證的絕對逆積分相容。 |
| M02，Ch279 初版 342–357，PDF 235 | 橢圓命題要求所有線位，但原證直接用仿射命題的公式。原仿射命題只保證一般 L¹ 代表在幾乎所有線位的等式，點點版本的額外類別不包含指示函數。 | 精修加入圓盤／橢圓各條線的直接弧長換元。兩側線段有限，切點單元素弧長為零，故含所有切點及空截面。r2 pp236–237 視讀命題、證明、面積核對與數值例。 |
| M03，Ch278 初版 490–499，PDF 221 | Mellin 誤差命題首次使用 f_R，前一反演定理用 f_R 表 Laplace、g_R 表 Mellin，未就地定義截斷或指定 R>0。 | 精修在相應誤差式前固定 R>0，將 f_R 指為截至 [−R,R] 的 Mellin 反演，並連至定理 278.15。r2 pp221–222 核聲明、引用、−iτ 的導數乘子及噪聲估計同域。 |
| M04，Ch280 初版約 349，PDF 260 | PΩ 在正交近似首式先用後定，未明確交代影像 L² 投影與適用逆公式的資料物件類。 | 精修首列 ℬΩ，再以乘子定義 PΩ，先證正交投影，再對 Schwartz f 接前述公式。r2 p261 視讀。Ch281 的 P 是資料冗餘投影，PΩ 沿用物件頻域乘子，偏差分解仍成立。 |
| M05，B05-coverage.tsv 的 V21-277-X01，正文 PDF 195 | 歷史稽核列稱無此定義並把反例列作延後。正文確有把兩端分開續開時常數例相消的警示。 | 主控更新 B08-coverage.tsv，實核第 71 行指向 ch277:sec-poles，Ch277 413–415 及 r2 p195。核其 1/s 與 −1/s 相消，廣義理論仍為排除範圍。歷史 B-05 表保留。 |
| M06，前言初版約 14 行，PDF 1 | “Fourier data on a half-line” 容易把因果時域支撐誤讀為只量測半條頻率線。 | 精修訂為受阻尼的函數支撐在非負時間軸，Mellin 的對數座標另有反射頻率。r2 p1 及 Ch276/277/278 的兩條角頻率公式實核。 |

以上已複核。初版無通過結論，通過指定於 r2。比較兩版來源，語義改動對應上述五處正文或前文回修，Ch271、276、278 各另插入一項分頁控制。前一版本在 Ch277 的分頁保護也在最終比較範圍內。B-06 改頁映射以像素查驗，B-07 另實際目視 p1、38–39、179–180、213–214、221–222、236–237、261 並核其 TeX 片段，截斷、定義與證明仍相連可讀。既往 B-04/B-05 修補的重新打開條件是相應假設或證明真的改動。

## 來源責任、舊修補與限制

- 已讀優先責任落點與原文作交叉對照。Stein–Shakarchi Ch. 2 §§5.2–5.4 的 Fejér 正性和密度採 N 個和式，核換成本文的 N+1。Doetsch Theorem 24.4 及其前文給局部 BV 和因果零時刻半值，核入 278。Zagier §1 Example 1 證純冪在分端正則化下消去，核入 277。Paternain–Salo–Uhlmann Theorems 1.1.5、1.1.8–1.1.9、Exercises 1.1.10–1.1.11 的切片、半導數和支撐假設與 280–281 的實際公式及證明核對。本文限定正階前向證明，且由本卷正規化重算係數。其餘來源逐項精修範圍的已讀證據見 B-01 與 B-05。
- 追核 B-04／B-05 的指定改項。270 整數階與端點極限，271 係數反射對稱與指定代表實際界 2B，272 開片 C¹ 的端點條件，273 奇異 Gaussian 的標量極限，274 兩個 L² 因子的卷積與本地測試識別，275 微分共振的定義域，276 有限點質量，277 就地 Mellin L² 建構，279 可積分離例的 a.e. 等式，280 有號極座標及低頻乘法的實際域，281 Gaussian 濾波的 Schwartz 假設，均見現行正文。
- 卷界保留平面 Radon 與通常的絕對 Mellin。一般局部分佈嵌入、廣義 Mellin 理論、Paley–Wiener、深層普通部分和 a.e. 理論、較高維重建、完整 Radon 值域、微局部與統計 CT 等責任維持原裁定。
- 來源 UNKNOWN 按原責任保留。Grafakos 第三版完整正文未取得，第二版入口失敗。Bracewell 原頁公式忠實度未核。F1 只計指定段落，R1 低品質 OCR 的雜訊常數未挪用，正文使用可重算的模型與數值。Stein 與 Doetsch 只計實際查對段落。這些已由相同責任的可核正文、固定公開主源或本卷自足證明處理。
- 16 主題與 22 章映射、六全局門檻名稱仍是舊卷的既有待決。V21 B-07 數學和數學承載已知 OPEN 為零。仍有遠端可見性、封存、包件核驗及發送回執等 B-08 工作。

## 來源、PDF 配對與排版

- 正式 ReadFlow R1 artifact commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3，來源 ZIP 7,007,679 bytes，SHA-256 5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732。模板採納紀錄的固定路徑為 archive/v0/readflow-r1-editorial-2026-11-17/TEMPLATE-ADOPTION.md。實際三個 template .tex 重算一致。V21 適配器、主檔、字體依賴及各向量圖於清單定位。
- B06-r2 的直接建置輸入快照是 tools/runs/B06-r2/inputs，配對紀錄為同目錄 build-report.json。19 個章稿／正文附屬資料／圖檔的建置快照逐檔與原路徑比較，主檔另核版本鎖。輸出 build/entry.pdf 與 dist 同雜湊。編譯為 XeLaTeX 三遍，標準命令如下。需本包的 fontconfig 和依賴及 ReadFlow R1 適配器。

    python3 tools/build.py --full --preamble notation.tex --front frontmatter.tex --back bibliography.tex --name rebuild

- 工程報告無 hard、overfull 或頁頭錯誤。各章章界、閱讀目錄、定理及引用在 PDF 上有相符位置。排版官以初版逐頁視檢及 r2 改頁視檢交回。B-07 每個終審回修點和相關公式另外複核。最終像素改頁表見 qa/B06-r2-visual-diff.json。

| 可取路徑，依同一交付來源根目錄 | 用途及版本 | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| layout/v21-adapter.tex | 唯一固定 r2 輸入 | 723 | ad067c8abb4c9642f58c514887170f6e04e1c602a7029e6284158079e3f329b0 |
| main.tex | 唯一固定 r2 輸入 | 989 | baf0c34a1dffc2f573d68ee8943f7b01c31e0efbfa239064737120a62e66c91b |
| notation.tex | 唯一固定 r2 輸入 | 104 | c268f6b71a1d74c22c8e7020f0a8df94255a01b7b1dfce813dcbe6ed009b2988 |
| frontmatter.tex | 唯一固定 r2 輸入 | 3,114 | 85f4450c34b6b59e52f7d2ffdea9bb16a726692da672320c770e6b4da9c64507 |
| bibliography.tex | 唯一固定 r2 輸入 | 3,103 | 496cf0583207e5168e067d99c61d05509db9f0833d14c5173bfbe8ec66392221 |
| chapters/ch270.tex | 唯一固定 r2 輸入 | 53,732 | 2116447199518dd06d21d91b40bd0cfaf98a39a564c8b242001ab34ea224899b |
| chapters/ch271.tex | 唯一固定 r2 輸入 | 49,864 | 7e2f72f5a6b8a0668ee7d8977f809590d56598998747cd899b1e24c445b4e563 |
| chapters/ch272.tex | 唯一固定 r2 輸入 | 48,657 | ddac6f35baf3cab557d75cf92c64bae29bb1d66a190a148d489de82d7e492637 |
| chapters/ch273.tex | 唯一固定 r2 輸入 | 52,697 | 6fdf87441ff02663c423bec732c360d3de03383a8d78122c9d3c361b7ea41fd8 |
| chapters/ch274.tex | 唯一固定 r2 輸入 | 49,066 | 39a61eaf2a00f7595e3132e0e5c83d3df261f45daf344fbfaafdb6b278ed3176 |
| chapters/ch275.tex | 唯一固定 r2 輸入 | 57,316 | 7805b2db1b0e78b47292d64ab6a925204f767594c057a60bb661245c5d3cd6d0 |
| chapters/ch276.tex | 唯一固定 r2 輸入 | 47,487 | 4323a14a38b0bac673d9ee65f883db5df95059276f837f18c3448dca54ec43e8 |
| chapters/ch277.tex | 唯一固定 r2 輸入 | 45,168 | e8c51be5a33bd998f6e33a9375126d70180a8e131a454f83848a55b1978f6b13 |
| chapters/ch278.tex | 唯一固定 r2 輸入 | 44,753 | e13f238e65b971faeb29f139403ec74aa4acf43646d5394ba7f7255ad6f150fe |
| chapters/ch279.tex | 唯一固定 r2 輸入 | 46,751 | 4575717c1d83621f3ac6d8dd915738779e8eaa8e5640e5547ee4f8e38f5a32bd |
| chapters/ch280.tex | 唯一固定 r2 輸入 | 48,349 | 2c87b2a3ad36e33387ad0a74040733ef40de8d3996d1b895f01037e22e379d79 |
| chapters/ch281.tex | 唯一固定 r2 輸入 | 52,632 | 3a8776d15925c951032018500ca9ea50e2873fc95925f0fc8d94b0fe1eae0e51 |
| figures/circle-kernels.pdf | 唯一固定 r2 輸入 | 16,821 | 747a86b5a620c5efdacf61f5f3f969cf58ee0aeafe2bfbeedf8df645ec007d84 |
| figures/laplace-vertical-lines.pdf | 唯一固定 r2 輸入 | 15,317 | 24e7148e617620e4b335378c6adb773a40c2ab3d34609b207731f3405b65db4a |
| figures/radon-cutoff-error.pdf | 唯一固定 r2 輸入 | 11,966 | f17e4cc047f9f3f9573737947b9d91a1751e0f53e7c3acdf8dfd6b3237ea442b |
| template/V0-ReadFlow-R1/layout/study/config.tex | R1 編譯樣式 | 507 | fdccf765bbb70ff9f8b178a81af841d721cb4f962c9d90ddb476d5728e1c0424 |
| template/V0-ReadFlow-R1/layout/study/readflow-layout.tex | R1 編譯樣式 | 5,892 | b04bf2f5bb7611b8a4899c9a582050681d36d71fba8b0c44a31f8d87d2924f69 |
| template/V0-ReadFlow-R1/layout/shared/readflow-base.tex | R1 編譯樣式 | 6,857 | cc9cc678504651f8f1baa196a714a70de1331684589d71b14353c77ec6f6f63b |
| dist/V21-B06-Reading-r2.pdf | 終審閱讀 PDF，B-08 可沿用相同 PDF bytes | 1,312,643 | 0c2c26f442dcb494fb75de233a386cb6d66a38a55f82109819732edf368b81ec |
| audit/B06-r2-input-lock.json | 正文版本鎖 | 2,917 | dcfccf05157c250ac3ee2f3e24beb985b56b75d66204ffd3711248a20f28c656 |
| tools/runs/B06-r2/build-report.json | 建置與快照配對 | 7,032 | 4d5c862efd12528fc629747b989269ddbeee51361d811770a826459251917ff0 |
| audit/B01-coverage.tsv | 固定逐項文獻責任 | 95,220 | 1a1378c808ff6a3f5d2e891bb6b6094b32f2eba9f20ad9df6198c6c354ffbfdb |
| audit/B01-source-access.md | 文獻來源與限制 | 3,959 | c8f2206d26e856a1b1dc9cf4b3b0e034d2bace0194e8742ff68e82d908d9acd2 |
| audit/B02-design.md | B-02 敘事與依賴 v3 | 36,471 | 3737ff063368b358abf7dd44712135421228e786de656826271f2ed4502c8afc |
| audit/B05-coverage.tsv | B-05 覆蓋歷史 | 89,418 | 0f159c84054f44419a6a91c852b2d291ed72de950ce08be598927f89cc827053 |
| audit/B08-coverage.tsv | 整合 r2 落點及 M05 | 83,106 | b07556e7a20266fdaf66cab3ed77f0e00f9855348e8cec73156b3c83e228e335 |
| qa/B06-r2-visual-diff.json | r2 像素改頁證據 | 16,219 | 47c8755a6e3630c092e2d4ae00c79b9264ee19375c1b13756a95eb008fa204f2 |
| qa/dependencies-manifest.json | 字體安裝與相依檔核對來源 | 3,919 | 6fe0a1b52eafae2ba8977db225fe254d67a55c9a93afa93a74799eaaeba028b0 |

## 次一階段與接收回執

接收者為主控，建議以此文件及正文版本鎖核對 B-08 封存的 PDF bytes 與學習正文，查授權庫可見性、下載及可恢復驗證。來源包應包括成稿、配對 PDF、來源責任與修補紀錄以及模板和依賴。受限教材原頁、圖片和非公開認證資料留在受控來源。主控收妥後回報實際取得檔名、SHA-256、配對及封存狀態，遇版本差異只退回受影響部分給同一打厚複核。

目前無待使用者決策。不得重啟 B-01 至 B-06、改章號、取代唯一正文、解凍前卷或另開其他卷。數學終審與來源雜湊、工程、上傳及回執各有證據，合併後維持此決定的固定版號。
