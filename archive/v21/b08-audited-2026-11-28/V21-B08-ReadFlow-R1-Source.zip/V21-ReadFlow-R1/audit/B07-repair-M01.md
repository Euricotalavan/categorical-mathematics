# B07-M01 targeted repair receipt

Status: canonical source correction applied and byte-verified; pending independent B07 recheck and B06 PDF reflow/pairing. Date: 2026-11-28 UTC. Role: precision. Scheme: B single Work, V21 Chapters 270–281.

Unique canonical file: `/tmp/v21-work/chapters/ch278.tex`.

- Before SHA256: `15c3a8d87e772dce2b1b5c40466621d18afd77bf5bdd34728991941a412a48ae`.
- After SHA256: `5582b7d88e096a667774f367ad799550b48aacd6201122531e7f7317e6a6cfb2`.
- Location: line 261, definition **Four meanings of inversion**, lines 260–262; enclosing section label `ch278:sec-pairing`.
- Byte delta: +28; file size 44495 → 44523 bytes.

## Defect and repair

Original wording: “An absolute inverse integrates the absolute value of the spectral integrand over the whole line.”

Impact: this describes integration of a magnitude, which changes the inverse operation and loses phase/sign. The earlier B05 precision pass missed this semantic defect. The valid inverse formulas elsewhere do not make this definition correct.

Corrected wording: “An absolute inverse integrates the spectral integrand over the whole line when the integral of its absolute value is finite.” The existing LaTeX emphasis around “absolute inverse” is preserved.

Only the unique sentence was replaced. Reversing that one byte replacement restores the exact before hash, so every other byte is preserved. The frozen integrated-v2 directory was not edited. Exact diff: `audit/B07-repair-M01.diff`.

## Immediate surrounding check

The remaining definitions on the same line were read directly. The symmetric inverse is stated as a limit of integrals over [-R,R], so it retains the signed/complex integrand. The Abel inverse inserts the stated positive damping factor before the limit; it does not replace the integrand by its magnitude. The L2 inverse states convergence in the object norm under the corresponding bounded spectral operations. No analogous magnitude-versus-integrand error was found in these three descriptions. The following paragraph, line 264, correctly distinguishes symmetric convergence from separately convergent tails using an odd integrand. The preceding paragraph, line 258, correctly distinguishes equivalence classes, continuous representatives and jump averages. No surrounding text was changed.

## Handoff

The controller requested and authorized this exact B07 return repair. Pass the new canonical snapshot to layout for the next B06 reflow. The independent B07 lead must recheck the corrected definition and its rendered text. The prior B05 release cannot be treated as final approval for this new hash. No new whole-volume acceptance or archive authorization is declared; no unrelated edit, source-map rewrite or prior-volume restart was performed.

```diff
--- ch278.tex (B05 integrated v2)
+++ ch278.tex (B07-M01 repair)
@@ -259,5 +259,5 @@
 
 \begin{definition}[Four meanings of inversion]
-An \emph{absolute inverse} integrates the absolute value of the spectral integrand over the whole line. A \emph{symmetric inverse} is the limit of integrals over $[-R,R]$ as $R\to\infty$. An \emph{Abel inverse} first inserts $e^{-\varepsilon|\tau|}$ and then lets $\varepsilon\downarrow0$. An \emph{$L^2$ inverse} is a limit in the object norm after applying the corresponding bounded spectral operations. Unless specified by a further theorem, these four meanings are not interchangeable.
+An \emph{absolute inverse} integrates the spectral integrand over the whole line when the integral of its absolute value is finite. A \emph{symmetric inverse} is the limit of integrals over $[-R,R]$ as $R\to\infty$. An \emph{Abel inverse} first inserts $e^{-\varepsilon|\tau|}$ and then lets $\varepsilon\downarrow0$. An \emph{$L^2$ inverse} is a limit in the object norm after applying the corresponding bounded spectral operations. Unless specified by a further theorem, these four meanings are not interchangeable.
 \end{definition}
 
```
