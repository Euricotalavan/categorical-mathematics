# B07-M04 targeted repair receipt

Status: canonical source correction applied; pending B06 reflow and independent B07 recheck. Role: precision. Scheme: B single Work, V21 Chapters 270–281. Date: 2026-11-28 UTC.

Canonical file: `/tmp/v21-work/chapters/ch280.tex`. Location: subsection **The exact cutoff is an orthogonal approximation**, revised lines 349–356, within section `ch280:cutoff`.

- Input SHA256: `c64d8b6012703d90747b6e53c927d238aac5eff82e6f4f25cdc462c43f255989`.
- Output SHA256: `2c87b2a3ad36e33387ad0a74040733ef40de8d3996d1b895f01037e22e379d79`.
- Size: 48060 → 48349 bytes.

## Defect and correction

The subsection wrote T_Omega Rf=P_Omega f before defining its local P_Omega notation or declaring the object domain of that equality. It now first defines the disk subspace, then the disk-indicator Fourier multiplier on object L2 and its orthogonal-projection meaning. The preceding polar/filtered-backprojection formula is explicitly invoked for Schwartz f. The following Pythagorean identity is explicitly stated for every object f in L2 and every competitor h in the disk subspace.

## Verification and scope

Multiplication by a measurable indicator is self-adjoint and idempotent on frequency L2. The unitary object transform transfers this orthogonal projection to object L2, so its range is exactly the stated disk subspace. For Schwartz f, the preceding absolutely justified polar formula identifies the cutoff reconstruction with the inverse transform of the disk-truncated spectrum. For arbitrary object L2, the Pythagorean statement only uses this defined projection and does not require restricting an arbitrary L2 object transform to a line. The displayed identity, argument, Gaussian numerical value, and later noise discussion are unchanged.

Only the subsection's initial paragraph and immediately following quantifier phrase were replaced as one exact passage. Reversing that byte replacement restores the input hash, proving that all other bytes are preserved. No Ch278 or frozen source was edited in this repair. Exact patch: `audit/B07-repair-M04.diff`.

The controller authorized the correction. Layout should use this output snapshot for the next B06 reflow, and the independent B07 lead should recheck it. This receipt does not declare a B07 pass or archival authorization.

```diff
--- ch280.tex before M04
+++ ch280.tex after M04
@@ -346,9 +346,13 @@
 
 \subsection{The exact cutoff is an orthogonal approximation}
 
-The formula $T_\Omega Rf=P_\Omega f$ has a useful approximation interpretation that is independent of a noise model. Let $\mathcal B_\Omega$ be the closed subspace of object $L^2$ consisting of functions whose Fourier transforms vanish outside the disk $|\xi|\leq\Omega$. Multiplication by the disk indicator is an orthogonal projection in frequency $L^2$; Plancherel transfers that property to $P_\Omega$ in object space.
-
-For every $h\in\mathcal B_\Omega$,
+For $\Omega>0$, let $\mathcal B_\Omega$ be the closed subspace of object $L^2$ consisting of functions whose Fourier transforms vanish outside the disk $|\xi|\leq\Omega$. Define $P_\Omega$ on object $L^2$ by the Fourier multiplier
+\[
+ \widehat{P_\Omega f}(\xi)=\mathbf1_{\{|\xi|\leq\Omega\}}\widehat f(\xi).
+\]
+Multiplication by this indicator is an orthogonal projection in frequency $L^2$; Plancherel makes $P_\Omega$ the orthogonal projection onto $\mathcal B_\Omega$ in object space. For Schwartz $f$, the preceding polar filtered-backprojection formula gives $T_\Omega Rf=P_\Omega f$. This identity has a useful approximation interpretation that is independent of a noise model.
+
+For every object $f\in L^2$ and every $h\in\mathcal B_\Omega$,
 \[
  \|f-h\|_2^2
  =\|f-P_\Omega f\|_2^2+\|P_\Omega f-h\|_2^2.
```
