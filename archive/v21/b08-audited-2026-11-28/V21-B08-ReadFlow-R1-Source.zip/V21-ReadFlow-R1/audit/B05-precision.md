# V21 independent B05 precision and integration handoff

Decision: **PASS TO B06 LAYOUT**, for the exact `B05-integrated-v2` inputs listed below. This is an independent precision release of the manuscript to layout. It is not B07 acceptance, a PDF visual pass, or authorization to archive a final volume.

Reviewer: precision. Scheme: B single Work. Volume: V21, Fourier Analysis and Integral Transforms, Chapters 270–281. Date: 2026-11-28 UTC. The controller retains the unique manuscript. This reviewer did not modify author chapters. Actual model/High configuration is UNVERIFIED.

## Receipt and fixed version

The nineteen files in `/tmp/v21-work/frozen/B05-integrated-v2/INPUTS.json` were read or delta checked and their byte sizes and SHA256 values were verified against that manifest. The twelve chapters were independently read in full at the earlier snapshots preserved in `audit/read-snapshots/`; every difference leading to the fixed v2 chapters was subsequently read and checked. Final small changes in 271 and 272 were checked against integrated v1. The 273, 275 and 281 clarifications and the entire 280 Poisson addition were checked, not inferred from author receipts.

Manifest SHA256: `39f34e858774c3ac35d14298b665b2b6c3553cf4b54c3d82b3182ca18ddd5450`.

| Chapter | SHA256 | Source lines |
|---|---|---|
| 270 | `2116447199518dd06d21d91b40bd0cfaf98a39a564c8b242001ab34ea224899b` | 834 |
| 271 | `f69582342f5001842bc1f619b8876fcd27d8b223dadb0be2e0c529e81ae004d6` | 800 |
| 272 | `ddac6f35baf3cab557d75cf92c64bae29bb1d66a190a148d489de82d7e492637` | 737 |
| 273 | `6fdf87441ff02663c423bec732c360d3de03383a8d78122c9d3c361b7ea41fd8` | 867 |
| 274 | `39a61eaf2a00f7595e3132e0e5c83d3df261f45daf344fbfaafdb6b278ed3176` | 848 |
| 275 | `7805b2db1b0e78b47292d64ab6a925204f767594c057a60bb661245c5d3cd6d0` | 726 |
| 276 | `2e87c3ce3ed76329bd92159a4a4d0ca75edda773780a7e1c79c899287be7c5cb` | 771 |
| 277 | `0bc17a6ac412c16883450f4a9cd6fb5c807b3c4a72d67e37a0edab5057eab864` | 796 |
| 278 | `15c3a8d87e772dce2b1b5c40466621d18afd77bf5bdd34728991941a412a48ae` | 611 |
| 279 | `f228ce3cacad2882329c228ea8880471d414a01eaa185a97ad21ddb347caf1bb` | 848 |
| 280 | `c64d8b6012703d90747b6e53c927d238aac5eff82e6f4f25cdc462c43f255989` | 707 |
| 281 | `3a8776d15925c951032018500ca9ea50e2873fc95925f0fc8d94b0fe1eae0e51` | 946 |

The remaining seven manifest inputs are the front matter, bibliography, notation helpers, main file, and three figures. Their pairing is verified by the manifest. This review checks the mathematical descriptions and numerical kernel/noise values associated with the figures; screen rendering and page flow remain B06/B07 work.

## Responsibility result

`B05-coverage.tsv` has exactly 179 unique B01 IDs, with no lost or added source-responsibility ID. It records the fixed file, full hash, real section/statement label or actual environment title, source lines, definitions, statements, necessary proofs, applicable examples, and explicit disposition. Rows ending in `-P` separately preserve necessary proof obligations; they are not extra theorems.

The final states are 154 direct body checks, one independent derivation check, two scoped alternative contour-proof checks, two rows whose regular-function core is checked while the general compact-support distribution claim is deferred, one excluded generalized-Mellin boundary, eleven other scope decisions, one historical source-access gap now closed, and seven continuing source-access limitations. These counts describe the ledger; the acceptance rests on direct reading and mathematical checks. No row remains unread or partially awaiting another chapter.

`B05-original-items.tsv` supplies 774 exact manuscript environment locators, including definitions, propositions, proofs, examples, problems and their solutions. The inventory includes both source-derived and original pedagogical material. Each environment was included in the complete chapter and delta reading; the count itself is not a quality criterion.

The following intentional transfers are closed by actual body evidence:

| Responsibility | Actual landing and result |
|---|---|
| Finite Fourier geometry to completeness | 270 finite projection/Bessel precedes 271 density, Parseval, reconstruction and the abstract Hilbert tests. |
| Poisson pair originally planned in 273 | 274 proves the exponential/rational pair after its inverse theorem. The pair is used legitimately by 280's new planar Poisson example. |
| Schwartz space originally planned in 275 | Defined and controlled in 273; inverse automorphism in 274; topology recalled before S-prime in 275. |
| General symmetric Bromwich criterion | 276 supplies absolute and rational inversion; 278 proves local BV/Dini symmetric inversion and the causal zero half-trace. |
| Mellin line decay and weighted inversion | 277 gives the log-Fourier identity and absolute inverse; 278 supplies L1 mapping decay, weighted Plancherel, pairings and bilateral cutoffs. |
| Radon backprojection originally planned in 279 | 280 defines the adjoint on a stated domain and proves the adjoint pairing and normal operator. |

## Mathematical and sequential checks

The full readings checked types, domains, quantifiers, equality meanings, operations on equivalence classes, definitions before use, proof completeness, example identification, and solved computations. No unresolved substantive mathematical defect was found in the fixed integrated scope.

270's finite sampling formulas, exact evaluation norm, Toeplitz positivity and strict moment-disk inequality were independently checked. In particular the strict inequality for densities uses the zero mass of finite point sets and does not incorrectly exclude point measures. The window construction has the required phase and normalized measure.

271's three-factor Young proof handles endpoints and establishes the required integrability. Fejér uses N+1 terms throughout. Density precedes Parseval. The signed flat-top kernel has the correct endpoint multipliers, L1 bound, near-best estimate and L-infinity counterexample. The final representative repair correctly uses an actual bound B rather than the essential supremum at a specified point.

272's local BV/Dini arguments, logarithmic Dirichlet norm, uniform boundedness proof, continuous divergence construction, ordinary Gibbs profile and Lebesgue-point Fejér proof were checked. The new averaged profile has O(M^-2) compact-scale error; the Hölder rate, Lipschitz logarithm and signed-profile overshoot are justified. The last overshoot proof correctly expands T(y)=1/(pi y)+sin(y)/(pi y^2)+O(y^-3), fixes a sufficiently large y first, then takes the reconstruction limit. The arc conclusion explicitly requires a neighborhood of the jump.

273–275 establish the Euclidean transform in dependency order: L1 definition, decay/calculus, Schwartz closure, regularized inversion, core Parseval, classical/L2 compatibility, a genuinely onto unitary extension, then dual operations. All finite-energy convolution outputs are assigned the proper function class. The moving-window case in 274 uses absolute L2 pairings before almost-everywhere Plancherel slices; the two energy identities, sinc overlap and Gaussian tail bound are correct. The simple-zero case in 275 distinguishes Schwartz, L2 and tempered solutions and declares the differential symbol unbounded on L2. The strip proof supplies the particular interpolation needed for Hausdorff–Young. Schwartz Poisson summation, uncertainty, regularity thresholds and all solved resonance calculations were checked.

276–278 declare the absolute convergence strip or half-plane and separately record boundary lines. Holomorphy majorants, conditional convergence, shift signs, uniqueness, causal convolution and Green kernels were checked. The delayed impulse is explicitly a finite point measure. Mellin uses the whole logarithmic axis, and the two-end scale equation has the correct boundary-selected Green solution. Endpoint subtraction, pole residues, beta/gamma examples and the two-channel cancellation model were checked. In 278 the causal L2 range is a proper closed subspace; the nearest-data projection is proved locally. Symmetric inversion includes the global L1 tail, the local BV or Dini condition, and half-values at causal zero. No continuity-only unqualified Bromwich formula is used.

279–281 keep the object plane, line measure and full-circle angular measure explicit. Affine covariance, singular-line exceptions, ellipses, moments, radial Abel inversion, all-directions uniqueness and finite-angle null examples were checked. The adjoint/normal kernel has factor 2, while full-circle filtered backprojection has factor 1/2 with symbol abs(sigma). The normal operator is not falsely asserted to be bounded on all L2 at zero frequency. The planar Poisson kernel, mass, projection, transform, regularized reconstruction, convergence modes, semigroup and L2 norm are all proved with correct constants. Its divergent first absolute moment is explicitly identified before any higher moment test could be reused.

281 distinguishes exact Radon data from arbitrary L2 detector errors. Weighted half-derivative energy, fixed-support forward estimates restricted to nonnegative orders, the sharp inverse constant, parity projection, cutoff norm and orthogonal bias/noise decomposition were checked. The two-point lower bound has the correct exponents. Gaussian gradual filtering uses 0<q<=2 with a declared Schwartz input and retains the possible cross term. The displayed numerical table and optimum were independently recomputed. No random acquisition or clinical interpretation is imported.

## Dependency graph and global conventions

The proof dependency graph is acyclic:

- 270 supplies finite coefficient/projection geometry to 271; 271 density and completeness support 272.
- 271 Euclidean Young/translation tools support 273; 273 Schwartz and Gaussian tools support 274; 274 inversion/Plancherel supports 275.
- 273–274 support 276 Laplace lines and 277 Mellin log coordinates. 278 combines 276 and 277 with 274, adding its own local inversion proof. The 277 two-channel case derives its L2 construction directly from 274, avoiding dependence on the later 278.
- 279 supplies Radon geometry to 280; 273–274 provide its slice/inversion tools. 281 uses 279–280 and the already established 274–275 frequency framework.

All formal ref/eqref/autoref targets resolve, all manuscript labels are unique, and no formal reference points to a later chapter. Explanatory previews of later terminology do not serve as needed proofs: the singular Gaussian preview in 273 contains its own scalar test limit, and the former 274 distribution-dependent contradiction now follows a locally proved test-function identification lemma.

The circle uses dm=dt/(2pi), modes exp(int), and F_N averages D_0 through D_N. Euclidean space uses exp(-2pi i x dot xi). Laplace lines satisfy F(c+2pi i xi)=Fourier(J_c f)(xi); Mellin lines satisfy M(c+2pi i xi)=Fourier(U_c f)(-xi). Distribution pairings are bilinear; Hilbert pairings are linear in the first slot. These signs and conjugates were checked at the actual formulas, not only in the front matter.

The standard 275 Sobolev weight is 1+4pi^2 abs(xi)^2; the 281 object/detector weights use their declared local 1+abs(xi)^2 convention. They define equivalent scales but do not share exact constants. 281 declares its convention before the estimates, so no constant is silently transferred. Detector-only derivatives are not angular derivatives. Fixed support is retained wherever used in a forward estimate.

## Exclusions, source UNKNOWNs, and closed repairs

General compact-support D-prime to S-prime is deferred because the local distribution framework is not developed. Polynomial-growth regular functions and finite measures are fully proved. This scoped boundary was explicitly accepted by the controller; the broad B01 source row is not falsely marked wholly proved.

General interpolation theory is outside the volume, while the particular strip lemma and Hausdorff–Young result are proved. Generalized regularized Mellin noninjectivity, general Paley–Wiener theory, deep almost-everywhere partial-sum theorems, complete Radon range conditions, higher-dimensional reconstruction, microlocal inversion and statistical CT algorithms remain excluded as specified in B01. The planar boundary supersedes the obsolete optional 3D paragraph in B02. A single representative kernel or cutoff calculation does not claim these broader theories.

Grafakos third-edition full text, the unavailable second-edition alternative, and Bracewell's unverified OCR remain source UNKNOWNs. Other source-reading limits and R1 OCR/noise-constant restrictions remain item-specific. They are not used as proof authority for unverified statements. The approved Stein and Doetsch files were acquired; the historical Stein gap is closed, with no claim that all pages of either book were read. Stein's copyright year and file-production metadata remain distinct. The original M2 v1 domain/cutoff misprints are preserved in B01 and corrected by independent log-Fourier derivation, not silently quoted.

Repairs independently closed include: 279 separable equalities qualified in L1/a.e.; 271 reflection symmetry stated as a_-n=a_n; 271 point continuity uses an actual representative bound; 274 two-L2 convolution proof uses absolute inversion and the non-L2 example has a preceding local identification proof; 273 singular Gaussian limit has its own scalar-test verification; 275 resonance declares its acting spaces; 280 signed polar boundary wording is corrected; 281 Gaussian filter theorem declares f in Schwartz. None remains a blocker.

## Handoff, next step, and invalidation rule

Role/stage: independent precision, B05 (the source/rigor refinement and whole-volume integration function corresponding to the original A precision pass). Adopted scheme: explicitly authorized B single Work. Unique body: the controller's frozen integrated v2 manifest; this reviewer only wrote audit artifacts.

Next step is B06 R1 layout of this exact candidate, followed by the sole strict thickening B07 review and any required return/recheck. The controller should carry these source/hash locators into the B06 handoff. PDF compilation, visual page/figure inspection, navigation, release visibility, final package hash/PDF pairing and B07 mathematical final acceptance remain OPEN at this handoff. They are stage-specific work, not hidden B05 mathematical defects.

Any mathematical author-source change requires a new fixed hash and a review of the changed statement/proof plus affected dependencies. Pure layout changes still require pairing and visual verification. Do not restart B01, change chapter numbering, revive old three-officer closure, alter frozen earlier volumes, or treat this release as B07/final archival approval. Do not publish private third-party source files or the private M2 image.

Deliverables: B05-coverage.tsv; B05-original-items.tsv; B05-precision.md; B05-read-snapshots.json; B05-integration-checks.json; B05-manifest.json. Earlier batch reports remain historical evidence only. The exact fixed manuscript is in the integrated v2 directory, and the earlier source-responsibility evidence remains in B01 artifacts.
