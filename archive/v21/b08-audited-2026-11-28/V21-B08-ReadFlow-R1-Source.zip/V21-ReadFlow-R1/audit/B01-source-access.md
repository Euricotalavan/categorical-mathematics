# V21 B-01 fixed source access and versions

User approval received in the same Work conversation, followed by instruction to run B-01–B-08 and route the former user review to the controller. Source preparation was V21-PRE-B01-LITERATURE-20261128 v1. The fixed report title is V21-Pre-B01-Literature-v1.md. It records entry links, exact file checks, page ranges, and original work roles.

## Scope of the reading set

Use the approved openly readable F1–F3, L1–L3, T1, M1–M2, R1–R2 and selected original textbook cross-checks. The scope is Fourier on the circle and Euclidean space, one-sided Laplace and Mellin on the half-line, and planar Radon transform with worked stability. Fourier series and Euclidean Fourier use the adopted negative exponential signs with their respective measures. Stroock uses the positive sign with angular frequency. Paternain–Salo–Uhlmann use angular frequency with the opposite sign from Stroock. These conventions require explicit input changes before comparing inversion constants.

| ID | Edition and access | Handling |
| --- | --- | --- |
| S1 | Stein–Shakarchi, Princeton 2003 text, independently retrieved typesetting marked October 2007, 326 physical pages, SHA-256 `7abcc4b610625b0c63e5ca62d019c519e8d466da0e8a849fba23c79d3d285a52` | Selected chapters 2–3 and 5–6, physical page = printed page + 17 through relevant sections. Cite the publisher edition. |
| D1 | Doetsch, English translation 1974, 334 physical pages, SHA-256 `d6bf995c58b0317422aee6bbd4b8d8a36d4d22c3cd0b6fcff50418ed051c0a9e` | Read selected convergence and inverse-transform sections. Physical page = printed page + 7 through relevant sections. Cite the Springer edition. |
| G3 | Grafakos, Springer 2014, third edition. Official front matter and author errata retrieved and compared. | The approved Machakos file link goes to a Request a Copy form. Complete third-edition source-text review is UNKNOWN. F1–F3 and S1 cover applicable Fourier responsibilities. |
| G2 | Grafakos, Springer 2008, second edition. Official bibliographic entry checked. | The approved candidate returned HTTP 503. This separate edition is not used in place of G3. |
| B3 | Bracewell, McGraw-Hill, third edition, copyright 2000. Verified catalog and opened selected indexed OCR segments. | The underlying access returned an HTML viewer shell locally. Formula and layout fidelity against original pages remain unverified. Use the public F1, L1 and R1 sources for mathematical proof. |
| T1 | NIST DLMF 1.2.8, §1.14(i), (iii), (iv). | Read equations and hypotheses in the open HTML. DLMF HTML SHA-256 `0a5d540d84f97b7ae19101522a533e41cd0ea82847701399b5a4ad189febc005`. |
| F1–F3, L1–L3, M1–M2, R1–R2 | See V21-PRE-B01 v1 and the extractor summary. | Read the passages linked to each responsibility. R2 author draft and Cambridge preview are identified separately. |

The unchanged math-extractor v0.4 ran locally with zero model calls over selected windows from 13 matched PDFs. The engineering evidence records physical ranges and counts. Mathematical source checks and disposition live in the responsibility ledger, including evidence from sources the PDF tool could not parse. Unread portions are not represented as reviewed. The book and release package contain original exposition and cite the primary bibliographic entries. Raw source texts, scans, screenshots of copyrighted pages, and temporary access links are omitted from the release.

## Source comparison added during review

F1 Osgood's printed p.63 (PDF p.69) contains a numerical discrepancy in the displayed evaluation of `(2/π) Si(π)`. The original print was checked visually. Independent evaluation gives 1.17897974447217. The limiting peak for the 0-to-1 step used in this volume is instead about 1.08948987223608. Ch272 derives its own integral profile. It does not use the printed numerical estimate. The scanned reference region stays with the working source evidence.
