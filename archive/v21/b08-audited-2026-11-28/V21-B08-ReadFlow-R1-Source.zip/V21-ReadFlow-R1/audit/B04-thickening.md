# V21 B-04 independent mathematical review

Role and scope: mathematical thickening of the V21 B workflow, Ch270–281. Inputs are the fixed B-02 v3 design, chapter contract, and the numbered chapter snapshots listed below. The preceding Git anchor is V20 at `5e06e3e15db0e6192d4146c44501ff78be7a1914`, ending at Ch269. The role did not modify chapter sources. Chapter checks and supplements are independent from author self-review. Hardware model/reasoning-mode settings are not independently exposed. Review of a chapter below concerns the named snapshot only. The book's integrated source and paired PDF are reviewed at their later stages.

## Ch279 · Radon Transform

Read `chapters/ch279.tex` in full, 507 lines and 29,304 bytes, SHA-256 `957570e8607994174dadd823d9fa7f8c6f3d171eef89c612f971c2b9a0328b7d`. First standalone layout diagnostic reported 17 pages. Eight sections and six complete solutions were present.

| Section | Evidence and mathematical review |
| --- | --- |
| 279.1 | Orthonormal oriented frame and determinant one give the sign of the normal and arc-length parameter. The full circle counts each line twice. The separable example correctly swaps coordinates at angle \(\pi/2\). Make its two displayed formulas a.e. in \(s\) for the stated \(L^1\) classes. |
| 279.2 | Fixed-angle Tonelli bound, total mass, null-set independence, fixed interval for differentiation under the integral, and uniform Schwartz tail estimate are valid. Explicitly construct the jointly measurable representative by taking Borel input and setting output to zero where the absolute integral fails. The support implication uses a strict exterior line condition and asserts only the justified direction. |
| 279.3 | The changes of variables for translation, rotation, and dilation have the correct signs and factors. For the affine statement specify the input class and a.e. equality at each normal. Expand the cofactor step as \(A^{-1}J\omega=(\det A)^{-1}JA^T\omega\), where \(J\) rotates a vector by \(\pi/2\). This gives the absolute tangent factor even when \(\det A<0\). Apply the same pointwise-versus-a.e. wording to the other covariance proposition. |
| 279.4 | Disk tangent lines have a zero-length intersection, the shifted disk tests redundancy, and the ellipse uses \(C^{1/2}\), width \((\omega^TC\omega)^{1/2}\), and mass \(\pi\sqrt{\det C}\). The numerical checks agree independently. |
| 279.5 | The rotated Gaussian quadratic form has determinant \(ae-d^2\), the completed square leaves \((\det A)s^2/e\), and inverse formula gives \(b_\theta=e/\det A\). For \(A=\operatorname{diag}(4,1)\) and \(\theta=\pi/4\), this yields \(b_\theta=5/8\) and amplitude \(\sqrt{2/5}\). The Gaussian integral is a dependency from Ch273. |
| 279.6 | The moment identity and polynomial expansion are correct. Display finite second absolute moment before listing all three moments. Assume a nonnegative object in the centroid/covariance example to match the use of covariance as a nonnegative normalized integral. The mass and harmonic counterexamples satisfy redundancy, and the latter correctly concerns the finite-first-absolute-moment class. |
| 279.7 | The four-variable absolute integral factorizes into the product of the \(L^1\) norms. The convolution identity and compactly supported tangent derivative construction are valid. Linearity criterion uses fixed-angle \(L^1\) equality. |
| 279.8 | Recomputed all six solutions. Shifted-disk first moment is \(9\pi/4\). The angle pair in the second-moment contradiction forces opposite mixed moments. The signed Gaussian moment is \(1/(2\pi)-2\). |

### Ch279 pending refinements

| ID | Original source location | Impact and requested correction | Re-review |
| --- | --- | --- | --- |
| TH-279-01 | Lines 49–56 and 64–84 | Make the separable \(L^1\) example a.e. and spell out the representative on exceptional lines. | Pending revised snapshot. |
| TH-279-02 | Lines 145–181 | State the input class and a.e. convention in both covariance statements. Supply the signed two-by-two matrix identity in the affine proof. | Pending revised snapshot. |
| TH-279-03 | Lines 323–355 | Record finite second absolute moment for the entire three-moment display. Put the centroid exercise within the nonnegative positive-mass class. | Pending revised snapshot. |
| TH-279-04 | B02 279.4 versus role plan and Ch279 final section | The adjoint and normal operator proof is intentionally assigned by the role's actual plan to Ch280, following the geometry. Add preview and reconcile the source responsibility landing. | Verify Ch280 placement and exact Ch279 transition. |

### Ch279 independent supplement

`audit/B04-ch279-expansion.tex` adds material with separate mathematical purposes. Part A belongs after the first \(L^1\) estimate and mass identity, before the smooth and Schwartz assertions. It demonstrates the exceptional-line issue, proves angular continuity in \(L^1\), and proves the sharp fixed-direction \(L^p\) estimate for objects supported in a disk. Part B belongs after the ellipse examples and before the Gaussian section. It derives the radial chord formula, checks a singularity producing an exceptional central line, and computes the projected edge profiles for integer taper powers. Part C belongs in the solved exercises before the source notes. It applies the projection to mass on a strip and reconstructs a radial quadratic using two exact data values.

The support estimate supports the fixed-support language of Ch281 without importing its frequency-side results. The radial chord formula is a forward formula and does not change the later inversion boundary. No existing chapter file was changed.

## Ch273 · The Euclidean Fourier Transform

Read the full preliminary snapshot, 775 lines, SHA-256 `d01dde05a722041acb0b977c47c45415986c94bb0c10475d651ef3272457f5c2`. The author was still adding material, so this report identifies only the read revision.

| Section | Evidence and mathematical review |
| --- | --- |
| 273.1 | Absolute integral fixes a unique continuous frequency representative for every input class. Uniform continuity is dominated by an integrable bound independent of the frequency. The interval phase and harmonic lower bound showing the sinc transform is outside \(L^1\) are correct. |
| 273.2 | Checked translation, modulation, reflection, complex conjugation, matrix inverse transpose, radial covariance, and the shear answer. The chapter-local reflection notation should be marked local, since \(R\) later means the Radon transform. |
| 273.3 | Density is measure-theoretic, independent of inversion. Riemann–Lebesgue follows from smooth approximation and the largest-coordinate integration-by-parts estimate. The moment and derivative bounds use adequate majorants. The cancellation example should explicitly require an integer \(m\ge1\) and \(f\in L^1\). |
| 273.4 | \(I_a'(s)=-(2\pi/a)s I_a(s)\), \(I_a(0)=a^{-1/2}\), Fourier matrix parameter \(Q^{-1}\), and \(q_t\)'s transform all recomputed. Positive definiteness and Jacobians are used. The designated Poisson kernel pair does not occur in this snapshot. |
| 273.5 | The seminorm criterion and Leibniz estimate for stability of Schwartz space are complete. Gaussian polynomial frequency signs and values agree. Identify the seminorm topology explicitly if continuity of the transform is later imported for distributions. |
| 273.6 | Existence via absolute convolution and Minkowski, Fubini product identity, finite-exponent continuity, and Gaussian approximate identities use compatible domains. Replace line 415's claim that interpolation fills the other Young cases with the actual 271.1 three-factor Hölder proof or its exact transfer. No implicit use of later strip interpolation. |
| 273.7 | Continuous-character ODE, finite measure transform and convolution, mollified norm and weak test-function convergence are valid. The atom example properly separates finite measures from integrable densities. |
| 273.8 | Verified all eleven solutions, including Gaussian semigroup by completing the square, exact one-dimensional Lipschitz coefficient \(1/\pi\), fractional moment modulus, compact-cutoff derivative identity, and atomic convolution. |

The fixes were sent to the content owner. Await the revised chapter and any placement of the Poisson pair. It can be calculated in 274 from inversion of the elementary transform of an exponential if doing so would avoid proof duplication.

## Ch276 · The Laplace Transform

Read the full preliminary snapshot, 716 lines, SHA-256 `b8345b4275f155c94949633b682491639b6b0db4be404d7a2e6f1e064c425f57`.

| Section | Evidence and mathematical review |
| --- | --- |
| 276.1 | Upper interval of absolute weights and boundary-line membership, compact-subhalf-plane domination for differentiation, divergent endpoint and thin spikes are valid. To use the oscillatory example as an *exact* conditional abscissa, show failure of the Cauchy criterion for \(\Re s\le0\): on \([n\pi+\pi/6,n\pi+5\pi/6]\), \(u^{-s}=(n\pi)^{-s}(1+O_s(n^{-1}))\) and \(\sin u\) has fixed sign. The integral has magnitude bounded below by a positive constant times \(n^{-\Re s}\). |
| 276.2 | Shift, scaling, time derivative and boundary traces checked. The Abelian initial/final value and finite asymptotic expansion have valid hypotheses and tail estimates. Real-axis uniqueness correctly uses identity theorem followed by 274 Fourier injectivity. |
| 276.3 | The weighted absolute Tonelli integral factorizes. All repeated-pole, beta/gamma convolution, fractional integral, periodic pulse and mass calculations agree. The truncation at time zero is explicit. |
| 276.4 | Critically damped response, resonance, causal Green kernel, and Volterra resolvent have correct formulas. Supply the Green-kernel first differentiation for \(f\in L^1_{\rm loc}\): write \(h(v)=\int_0^v h'(w)\,dw\), apply Fubini on the finite triangle, and note that the resulting differentiated integral is continuous by local dominated convergence. Then the first derivative is valid at every time. The second derivative is a.e. as stated. |
| 276.5 | \(2\pi\) bridge and vertical contour parameterization correct. For absolute inversion at a single continuity point use a sequence in the common full-measure set converging to that point. The text's claim of continuity throughout a neighborhood is stronger than assumed. The left rectangular contour, edge bounds and repeated residue check work for strictly proper rational functions. |
| 276.6 | Recomputed six solutions, including branch of the shifted half-order transform, two signed convolution triangles, jump integration-by-parts sign, resolvent case \(\lambda=2\), and central arctangent giving \(1/2\). The reference to transform of \(\delta_a\) should specify the finite point-measure integral \(\int e^{-st}\,d\delta_a(t)\). This meets the function/measure distinction in the chapter's definition. |

The four proof or type refinements above were sent to the content owner. There were no detected sign or factor errors in the inverses at this revision.

## Ch280 · Section Data and Inversion

Read the full first snapshot, SHA-256 `515eaa6a28ea8a3de84f9ffb5b6ca344ffed3c015dc9e048ae6505aacaed0acf`.

| Section | Evidence and mathematical review |
| --- | --- |
| 280.1 | Fixed-angle Fubini is justified by \(\|f\|_1\) and orthogonal Jacobian one. The Fourier section relation is pointwise for the continuous frequency representative. Generic \(L^2\) representative restrictions along lines are correctly excluded. |
| 280.2 | All directions cover the plane; origin is supplied by mass. The finite-direction counterexample really is compactly supported and nonzero on a subdisk by the product of nonzero directional derivatives on the exponential. Positive-background variant works for small real perturbations. |
| 280.3 | Signed-radius half-circle chart has absolute Jacobian \(|\sigma|\) and full-circle multiplicity two. The even ramp preserves the required redundancy. Gaussian at the origin gives \(B\Lambda Rf(0)=2\). Replace the phrase “one boundary ray” by the null boundary line when discussing a smooth chart, or simply state the a.e. coverage. |
| 280.4 | Kernel \(2/|x-y|\), normal multiplier \(2/|\xi|\), and tail expansion valid. The adjoint proposition states compactly supported input, but the proof later pairs with Schwartz \(h\). Either generalize the identity to \(L^1\) input and bounded Borel data, or repeat the Fubini justification with bounded \(Rf\) and \(h\in L^1\). The radial multiplier acts here on the regular locally integrable transform \(2\hat f/|\xi|\); multiplying an arbitrary tempered distribution by the nonsmooth radial symbol is not claimed. |
| 280.5 | The truncated kernel and its value \(\Omega^2\) at zero are correct. For the non-\(L^1\) claim detail divergence of the first term on intervals with \(|\sin(2\pi\Omega s)|\ge1/2\) and subtract the integrable second term outside a neighborhood of zero. Cutoff maps exact data to a disk Fourier projection, with separately proved uniform and \(L^2\) convergence. |
| 280.6 | The Gaussian central value \(1-e^{-\pi\Omega^2/\alpha}\) and shift are correct. Retitle “A whole-space Gaussian with finite bandwidth” to identify a finite-bandwidth reconstruction, since the Gaussian object itself has infinite frequency support. B02 also planned a scope-limited higher-dimensional hyperplane slice proof, which does not occur in this revision. |
| 280.7 | Verified all six complete solutions. The center threshold is \(1.482837414\ldots\), the disk cutoff \(L^2\) error is \(\tfrac12e^{-2\pi\Omega^2}\), and the zero-mass normal tail bound has constant \(4a\|f\|_1\). |

## Ch281 · Inversion Stability Case Studies

Read the full first snapshot, SHA-256 `6ac19c565379fbef80ddf6f659ff96d9c04096c453e1088b3e8207e26c4e100b`.

| Section | Evidence and mathematical review |
| --- | --- |
| 281.1 | The weight is only in the detector frequency, and the exact full-circle energy factor is \(1/2\). The \(H_T^1\) derivative factor \(1/(4\pi^2)\) is consistent with the adopted convention. |
| 281.2 | Exact data stability holds for every real order on Schwartz objects. The fixed-support forward comparison is correctly limited to \(q\ge0\). In two dimensions the unit-disk integral of \(|\xi|^{-1}\) is \(2\pi\); the separately estimated terms give the stated constant. Expanding spatial supports show the unrestricted forward \(L^2\) bound fails. |
| 281.3 | Annular test gives \(1/N\) to \(2/N\) squared data energy. The compact modulation estimate correctly handles the moving singularity separately from the dominated expanding region. Its real/complex reduction is justified. |
| 281.4 | Parity projection, cutoff, and optimal \(\sqrt{\Omega/2}\) norm all check. Define the partial Fourier transform on product \(L^2\) explicitly by finite tensors/density and 274 Plancherel. Null sets remain null for \(r\,dr\,d\theta\). Narrow the stated smooth-data agreement to regular integrable profiles or show the finite-frequency Fubini argument on general \(L^2\). The inconsistent-data example's continuous a.e. candidate would agree throughout the punctured disk, so direction-dependent limits at the origin rule out an integrable object. |
| 281.5 | Bias and propagated error occupy disjoint frequency supports. Their squared norms therefore add exactly. The optimization power \(\Omega_*^{2q+1}=4qM^2/\delta^2\) and the \(q=1\) error scaling are valid. |
| 281.6 | Recomputed the entire Gaussian/noise table and exact band gains. The stationary minimum value is \(0.040968719472\ldots\) at \(\Omega_0=0.738808021393\ldots\), instead of the draft's \(0.04134\). The beyond-band infimum is \(0.154717155004\ldots\), distinct from the finite value at the endpoint \(b\), and much larger than the minimum. |
| 281.7 | Orthogonality follows because different frequency support bands are disjoint. The finite rectangular bands are properly defined in Fourier data, without imposing an unproved line integral on an arbitrary \(L^2\) object. Verified normalized \(d_j^2=4/(a_j+b_j)\), examples and solved exercises. The optimization example's exact bound is \(0.114946414859\ldots\), rounding to \(0.11495\). |

These points were sent to the content owner for incorporation after draft completion. No contents of the chapter sources were modified by the reviewer.

## Ch270 · Periodic Fourier Data and Finite Reconstruction

Read all 606 lines at SHA-256 `f65de33ad2141847b4379806218ac560f2f90e8da22439ccc020f2377f787d64`. Rechecked the exact source diff at `cab61883d6b55ba8e326d0057ee6db59fb4e0b7358dbbc7dae5d35a8bb54e101`.

| Section | Evidence and mathematical review |
| --- | --- |
| 270.1–270.2 | Normalized circle measure preserves orthogonality and gives the correct (2π) rescaling for arbitrary physical period. Rechecked the period-domain (h\in L^p) for the norm claim and local reflection notation after the author clarified both. |
| 270.3 | Finite Pythagorean projection and Bessel need orthogonality alone. Completeness first arrives in 271. Nonnegative integer projection indices are now explicit. |
| 270.4 | Matched endpoint and jump contributions in integration by parts, with the exact negative sign for the boundary term in the derivative identity. Author now truncates open pieces and passes to endpoint traces by integrable derivative. The mean-zero condition for periodic primitives and constant ambiguity are both proved. |
| 270.5–270.6 | Recomputed the indicator, ramp, quadratic, and tent frequencies and the even/odd split. Tail estimate uses finite/summed Bessel on the derivative, without assuming Parseval in advance. |
| 270.7–270.8 | Verified coefficient-error orthogonality, normal equations with the complex Gram matrix in the correct order, cyclic averaging, and the original problem calculations. Four reported precision issues were corrected without changing the coefficient formulas. |

## Ch271 · Convolution, Fejér Means, and Parseval

Read all 609 lines at SHA-256 `c9824c200aededfee70292ce4823f4c35a455076544c0238ce2378f404ca194e`.

| Section | Evidence and mathematical review |
| --- | --- |
| 271.1 | The finite-output Young proof uses three-factor Hölder with unused exponent-zero factors omitted. The relation ensures (p,q≤r). Tonelli produces the separately normalized powers and gives a.e. convolution. Conjugate (r=∞) case uses the norm bound pointwise after choosing bounded representatives as needed. The same proof works in Euclidean space. |
| 271.2 | Density by continuous approximations of arcs precedes (L^p) translation continuity and does not assume Fourier completeness. Mass one, uniformly bounded absolute norm, and tail concentration imply norm convergence. Line 148 should say that changing an input on a null set preserves the a.e. result. |
| 271.3 | Both Fejér formulas, (N+1) convention, positivity and uniform-tail bound agree with the B03 sample. Checked convergence in each claimed norm, symmetry at a jump, comparison with unsummed data, and the Lipschitz estimate. |
| 271.4 | Geometric series gives the Poisson kernel with absolute convergence at every fixed radius. Compact subdisk differentiations justify the harmonic equation. Boundary convergence uses the proved kernel criterion. |
| 271.5 | Fejér first proves polynomial density. Orthogonal finite projections then give Parseval, polarized pairing and a unique reconstruction from (\ell^2). Clarify at line 461 that the same finite Pythagorean proof gives Bessel for an arbitrary orthonormal family in (H), not only the circle basis. |
| 271.6 | Scaling, mass, and tail arguments work for signed (L^1) kernels. At line 509, compute the Gaussian integral by squaring and using polar coordinates in one line, or label its value as a preview from 273. The general theorem itself has no forward mathematical dependency. |
| 271.7–271.8 | Recomputed the overlap tent ((2a-|x|)_+/(2π)), Poisson semigroup, and six complete solutions. In particular, the indicator Parseval identity is (\sum_{n≥1}\sin^2(na)/n^2=a(π-a)/2), and the Gaussian tail bound has prefactor (ε/(πδ)). |

## Ch274 · Inversion and Plancherel

Read all 671 lines at SHA-256 `0628172ae2196459c7e095788162239ce3725bdd3f8b721222c6e9db9c0d0949`.

| Section | Evidence and mathematical review |
| --- | --- |
| 274.1 | Gaussian regularization uses an integrable frequency factor times the bounded (L^1) transform. The exchange is absolutely convergent. Rechecked uniform and norm recovery, with Lebesgue-point error by scaled Gaussian annuli. |
| 274.2 | Absolute inversion uses a summably convergent (L^1) subsequence and uniform dominated convergence on the inverse integral. Two continuous representatives agreeing a.e. coincide everywhere. The one-dimensional Poisson pair is now proved here from the integrable transform of (e^{-2πt|x|}), including semigroup and approximate-identity claims. |
| 274.3–274.4 | Parseval follows on Schwartz functions without circular dependence on Plancherel. The extension is isometric and onto by dense Schwartz range and closed isometric range. Simultaneous (L^1,L^2) approximation proves compatibility with the classical integral. For the Schwartz-core approximation, use already established absolute inversion or verify that (C_c^\infty*G_t\subset\mathcal S) before applying the Schwartz inverse. |
| 274.5 | The (L^1) kernel and (L^2*L^2) formulas use interlocking Hölder and Plancherel limits. Correlation has the expected conjugation. In the last exercise, make the direct Schwartz-test pairing explicit, instead of relying on the next chapter's theory to establish that the example convolution is not (L^2). |
| 274.6–274.7 | Verified orthogonal frequency projections, support/analytic contradiction, exact finite-band (L^2\to L^\infty) constant, concentration inequalities, stability and general exhaustion. Hermite ladder signs, the commutator (BA-AB=1/π), parity, norms, eigenvalue and frequency pairing are consistent. |
| 274.8 | Recomputed all eleven complete solutions, including analytic matrix and Gaussian inverses, spectral projection endpoints, and the non-(L^2) witness. |

## Ch277 · Mellin Transform and the Multiplicative Axis

Read the complete preliminary snapshot at SHA-256 `0b9058b816df5132b8bb14b1c45af42754975007bd06b381ce9f20d97e0aae27`.

| Section | Evidence and mathematical review |
| --- | --- |
| 277.1 | Isometry (U_cf(t)=e^{ct}f(e^t)) onto the additive (L^p) space, strips and endpoint independence verified. |
| 277.2 | (\mathcal M f(c+iτ)=\widehat{U_cf}(-τ/(2π))). Changing the integration variable in Fourier inversion yields (x^{-c}(2π)^{-1}\int \mathcal M f(c+iτ)x^{-iτ}\,dτ). Dilations, shifts by powers and reciprocals have consistent directions. |
| 277.3 | Multiplicative convolution uses (dy/y) and Euler derivative introduces (-s) when the weighted traces vanish. Apply Minkowski to the absolute integrand before asserting the (L^1)–(L^2) convolution exists a.e. For homogeneous two-end uniqueness, state the locally absolutely continuous solution class. |
| 277.4 | Finite subtraction gives continuation, including logarithmic poles and the gamma recurrence signs. Establish formula equality in the common sufficiently right half-plane first, then continue by the identity theorem. Beta-integral keyhole/separation arguments check. |
| 277.5 | Scaling heat semigroup, weighted generator conjugation to ((E+c)^2), log-Gaussian shift, and uniqueness proof are consistent. Distinguish the chapter’s (q_a) from Chapter 273’s differently parametrized heat kernel, or state the conversion (q_a^{\mathrm{here}}=q_{4πa}^{273}). |
| 277.6 | Recomputed all six solutions. In the gamma-plus-gamma-prime inverse example, the sharp lower strip boundary uses the lower comparison at small (x), not only the upper integrable majorant. Weighted Plancherel is assigned to 278, so its proof and use must be checked at the actual landing. |

Ch273 precision recheck at `6d335649679b6bca2e8d6e6e9b0b4602445796074bf7827533f23be699d619ee`: all three marked changes appear and their arguments hold. Ch276 precision recheck at `ce0f0b8753760945fed65d1f3727a64f46d0b85fbea80219d084927d22bfc98d`: sequence through the full-measure set, derivative via triangular Fubini and finite point-mass type verified. The oscillatory example demonstrates different conditional and absolute behavior without requiring the earlier suggested exact lower-half-plane claim.

## Ch278 · Mapping and Inversion Conditions

Read all 468 lines at SHA-256 `67aa4879dcc90ce84608ee53d1e63cce0fc3082439e1dbb66882ede736c6fa31`.

| Section | Evidence and mathematical review |
| --- | --- |
| 278.1 | Checked (J_c,U_c) isometries, signs and measure (dτ/(2π)), dense-core consistency, Mellin surjectivity and Laplace closed causal range. The (A_c^2) interior estimate, boundary (L^2) convergence, and the Mellin no-strip example follow from their respective coordinate maps. |
| 278.2 | The Mellin sesquilinear pairing has weight (x^{2c-1}) and a spectral conjugate. The bilinear formula uses line (1-c) and opposite angular frequency, so the object weight is ordinary (dx). Checked the translated conjugation example and a symmetric limit whose separate tails diverge. |
| 278.3 | Verified finite sinc integral by Fubini, \(\pi/2\) sine integral by Abel damping with uniform tail, Stieltjes variation theorem by Fubini and dominated convergence, Dini criterion by Riemann–Lebesgue, and transformed traces. Lines 215 and 228 should state the (A_c^1) assumption for the endpoint and restrict the piecewise (C^1) implication to finitely many closed pieces with controlled endpoint derivatives. |
| 278.4 | Kernel computation uses angular convention and gives (P_ε(v)=ε/[π(ε^2+v^2)]). Even mass, fixed-tail majorant, and translation continuity give the claimed pointwise and norm modes. Symmetric-cutoff (L^2) inversion shows causal leakage tends to zero, rather than claiming the finite truncation is causal. |
| 278.5 | Rectangle orientation, both residue sums, and remainder constants verified. At (x=1) the half-integer edge integrand has constant sign and the actual remainder magnitude is (1/2). At lines 349–359, specify the sign \((-1)^m\) for an (m)th derivative tested against \(\phi^{(m)}\), or define order one with induction. The multiplier follows directly from 275. The deconvolution amplification (e^{aR^2}) and real-axis counterexample are correct. |
| 278.6 | Recomputed all six solutions, including both causal signs, (L^1)-divergent angular pulse, exact Parseval constants, and cutoff choice (R^2=\log(M/δ)/(2a)). |

## Ch272 · Pointwise and Uniform Convergence, interim

Read all 396 lines of the writing snapshot SHA-256 `a74302487f3aefa305ff88beef5bfac4bc227f5927156849da2b9c54d0874b1a`. The manuscript was still being completed.

| Section | Evidence and mathematical review |
| --- | --- |
| 272.1–272.2 | Fejér density and finite-interval step approximation give the needed Riemann–Lebesgue results independently of ordinary convergence. Dirichlet kernel signs, normalization, localization, and two-sided logarithmic growth all check. |
| 272.3 | Local Dini criterion controls the absolute amplitude; Dirichlet–Jordan uses an independent uniformly bounded primitive and the continuity of the one-sided variation function at the endpoint. Restrict the piecewise (C^1) example to finitely many pieces with finite endpoint derivative bounds. |
| 272.4 and example | The uniform Dini finite-net argument, absolute coefficient identification, and derivative-energy rate are valid. State (r\in\mathbb N) and each integration-by-parts hypothesis explicitly, e.g. (f^{(j)}) absolutely continuous with matching endpoints for (0≤j<r), and (f^{(r)}\in L^2). Checked the infinite-variation construction, its local Dini convergence, and both worked rates (N^{-1/3},N^{-1/2}). |

## Ch275 · Distributions and Frequency-Side Estimates, interim

Read lines 1–296 at SHA-256 `909c8786953504db6158fcaaee0c0f40f05ad77e4b2ea8d8cf67ea9568ba2f12`, then the additional lines 297–480 at `22d0792cb2183688a61fe5095e475e10d8e5a1abf51957fc93396d85cbd936e9`. The manuscript was still being completed.

| Section | Evidence and mathematical review |
| --- | --- |
| 275.1–275.2 | Finite Schwartz seminorm bound, regular-distribution injectivity, polynomial-growth embeddings, product domain, cutoff density and dual Fourier formula are well typed. Complex-linear test pairings preserve the stated Fourier sign and give both (L^1,L^2) compatibility. Schwartz-convolution passage through the functional uses weighted rapid decrease. |
| 275.3 | Jump mass is right trace minus left trace. Principal-value renormalization, kernel of multiplication by the coordinate, parity eliminating \(c\delta_0\), and \(\mathcal F(\operatorname{pv}(1/x))=-\pi i\operatorname{sgn}\) all check. |
| 275.4 | Sobolev realization by an onto weighted (L^2) map, integer norm comparison, strict embedding threshold, and averaged fractional difference formula are proved with the correct signs and convergence. Ch281 states its equivalent local convention with (1+|\xi|^2) instead of (1+4π^2|\xi|^2). |
| 275.5 | Operator, algebra and quadratic-form identities for bounded (L^2) multipliers verified, including finite-frequency witness for sharp norm. Kernel derivative budget uses (2M>d). The specialized bounded-strip argument proves Hausdorff–Young with both endpoints and complex-valued phases and explicitly reconciles (L^1,L^2,L^p) extensions. |
| 275.6–275.7 partial | Poisson summation uses absolutely convergent lattice sums and an independent product Fejér argument for periodic uniqueness. Checked scale, Gaussian theta identity, uncertainty constant (1/(4π)), and heat derivative multiplier maximum \((m/(2e))^{m/2}\). |

## Rechecks of additional source waves

- Ch271 at `2eb2f372c89b2760dcc8aea7e4ad71877e223da985df213e477ffa3c3e73cea4`. All three reported math precision changes verified in the actual diff. The normalization is now proved before it is used.
- Ch276 at `f24cac9b963cee180f721bf81b66eec7ec9333ff118de2af580af911b4121c9e`. Additional delayed impulse example uses finite signed point measure, verifies the distributional differential equation by parts, and derives uniform convergence of rectangular pulse responses. Computed (Jh'(0)=J), (J e^{-as}/(s^2+bs+d)), and the critical solution independently.
- Ch277 at `8a3bd333436b4de4c33116305426779121580db6a52cb481cb3957391b072c71`. All five precision requests resolved in the exact diff. New two-dilation case defines its own line-(L^2) Mellin map from 274 and (U_0), so use precedes the comprehensive 278 discussion without circular scope. Verified (m_1=1+\alpha z,m_2=1+\alpha z^2,z=e^{-iτ\log q}), all three identifiability cases, (D\geq 2+2\alpha^2-9\alpha/4>0), the inverse norm estimate, and the single-channel concentrating counterexample.
- Ch279 at `d9aa46855167fbe23b670834515733f68e01c910b60a8bd9cd875a33c0f25c92`. Actual merge confirms every substantive requested fix. The independent supplement has line exceptional-set example, angular norm continuity, sharp fixed support projection bound, Abel projection, radial examples and exercises. Checked additional correlated Gaussian covariance and both new moment examples. Two local language refinements were requested on this wave before final author SHA.
- Ch280 at `b8c2c96b3d363d7284e1473693f6720405dd6f593d70c2513ee869c47771f323`. Previous findings on adjoint test type, multiplier domain, nonabsolute ramp tail, and Gaussian bandwidth are resolved. New pointwise cutoff estimate has sharp constant \(\sqrt{π\Omega^3/3}\), justified by a saturated redundant profile and density. Radial Abel inversion gives the beta integral (π) including (r=0), and the signed Gaussian derivative has zero mass and center response (1-(1+π\Omega^2)e^{-π\Omega^2}). Recomputed derivative/cutoff additional exercises. Scope follows the controller's planar decision.
- Ch281 at `1161c9284be245acca220f4deddc91324343616f3817f159af2e1e90653c870a`. Initial findings on partial transform, parity/null sets, class of classical data, inconsistency at origin, and the two numerical values are resolved. Recomputed new positivity instability, weighted optimum, minimax two-input bound, angular regularity/polar modes, and heat estimates, including \(\tau_*^{(2q+1)/4}=δ/(4qe^{1/4}M)\) and exact signed cross term. Requested explicitly Schwartz object hypothesis in the heat estimate, since the homogeneous moment alone does not supply a classical (Rf).

## Final portions examined after the interim receipts

- Ch272 at `91f82d964b94a8bd7bf18fc56d946487e91ff1abd427a5d18237d5da97394873`, 584 lines. The two earlier hypothesis findings were corrected. Read all remaining sections and six solutions. Verified nested complete-space balls and quantitative uniform boundedness, norm of each Dirichlet evaluation by the continuous sign approximation, scaled Gibbs profile and sine-integral overshoot, and the Lebesgue-value Fejér annular proof with the external differentiation theorem disclosed at point of use. The solution about any arc containing the jump requires the negative-moving branch if the jump is its right endpoint, or a restriction to arcs containing a full neighborhood. This was sent to the author.
- Ch274 at `a48d6f498f94c71759bacab8ba9822d3afecaad44af649e879398639cc9e2174`. Both earlier proofs now depend only on already developed results. New window result has the correct conjugation, phase, double integral and translation factors for (L^2) inputs. Parseval in window position and joint Tonelli establish the exact energy identity, sinc windows lose one quarter of the energy outside the signal's own band, and the Gaussian squared error tail has prefactor \(\sqrt2/(2\pi L)\). The author was asked to make the extension of covariance from Schwartz to (L^2) explicit when invoked, and remove an orphaned reference to an alternative argument from a moved problem.
- Ch275 at `e35b6a2a6d31eb1b72c16a351d2d79a37e1217cf324d9475bbbae6c2f0f304d4`, 633 lines. Read all 11 solutions. Transform of the interval derivative, separate regularized-step parts, resolvent jump, uniqueness, critical annulus, exact sinc regularity threshold, Gaussian uncertainty equality, shifted Poisson sum and Hausdorff–Young extension match the earlier statements. The compact multiplier proof needs the notation (M\) positive integer with (2M>d). Requested the deliberately planned resonance counterexample at a zero of a multiplier, as the current positive resolvent alone does not address it.
- Ch276 at `2e87c3ce3ed76329bd92159a4a4d0ca75edda773780a7e1c79c899287be7c5cb`. The exact conditional abscissa paragraph now supplies the interval asymptotic \(\sqrt3(kπ)^{-\Re s}\) for \(\Re s≤0\) and the Cauchy-criterion failure. Earlier corrections remain present.
- Ch278 at `44abcba58c240bc6b56587ca22661ea08fd289389aed16f913baa79ebf4ad110`. The three marked hypothesis and weak-derivative issues and exact contour remainder magnitude are verified. The two additional local examples establish the two separate nonimplications with explicit estimates. Their overlap with the parallel circle cases was flagged for concise cross-reference during integration. Request a direct density phrase when extending the compact-test derivative identity to Schwartz tests, a fact already proved in 275.
- Ch279 at `f228ce3cacad2882329c228ea8880471d414a01eaa185a97ad21ddb347caf1bb` and Ch281 at `b30bcab033b82abb0e984a47d5a774727c841a3f818996534ac47bf81bc68818`. Verified in the actual files that the duplicated measurable-representative proof was removed, the width parameter is properly related to the covariance eigenvalue, and the filter estimate now explicitly assumes a Schwartz object. Ch280 is unchanged from its reviewed `b8c2c96b3d363d7284e1473693f6720405dd6f593d70c2513ee869c47771f323` snapshot.

## Later B04 wave checks

- Ch270 at `9444cc14be42a915f69e1ef6fa1ba364d8cfa82501ae42bcd6a3af4358471d09`. Checked the new finite-polynomial point evaluation theorem and sharp unique minimizer. (D_N) is defined there as a finite sum, so proof needs none of Ch272. The sample grid uses exactly (M=2N+1) consecutive frequencies with distinct residues. Verified both directions of interpolation, exact sample energy, alias witness (e_{N+1}=e_{-N}) on the grid, and three related solutions on sample noise, conjugacy repair and projections under symmetry.
- Ch271 at `a2ce5b0039f505ab39b6adc444805f14382a319dd53cc55bbbc4a32334740394`. The later sequence example explicitly cured the ambiguous term “even-index symmetry” by naming (a_{-n}=a_n). Its operation on (L^2) representatives agrees with Ch270.
- Ch272 at `0fb4bde5dc0aa7c75be838c0fd54b02e0b1c870cd5411882e5cdba0285f3081f`. Verified both parts of the final Gibbs question use an arc containing a neighborhood of the jump. No unproved negative-only arc argument remains.
- Ch273 at `0cb8db17a507e05a0b797996b5760da11a44dce29a2ce8ff9de633fc4258bc75`. The new periodization calculation is a fixed-(L) Tonelli identity and hence uses no interchange of infinite scales. The new cusp example has correct scaling in (h) and integrable domination. The exact one-sided magnitude could also be evaluated as (2π^2) by the sine integral already proved in 272; author informed that the argument is valid without this optional numerical step.
- Ch278 at `15c3a8d87e772dce2b1b5c40466621d18afd77bf5bdd34728991941a412a48ae`. The local-test density issue is now addressed by smooth cutoff approximation, and example repetition is shorter with a direct 272 citation. Read added causal projection in full. Unitarity, orthogonality, norm-error contractivity, overlap pairing and removable pole at \(\tau=-iq\) verify. Both forms of the overlap integral, including (p=q), check. The solved norm identity is (1-2e^{-1}=(1-2e^{-1}-e^{-4}/2)+e^{-4}/2).

- Ch270 at `2116447199518dd06d21d91b40bd0cfaf98a39a564c8b242001ab34ea224899b`. Verified moment positivity with (T_{jk}=c_{j-k}), strict complex variance disc, line–circle intersection in the equality case, impossible data ((1,0.9,0)) and negative square expectation ( -0.31), exactly realizable first coefficient by an arc, and two explicit point masses saturating the second-coefficient test.
- Ch271 at `8acb23c2e0f7e634e5a12a00018040f6d31566b4ac0cb5232bfdba1b90e64303`. Verified normalized de la Vallée Poussin coefficients including (N) and (2N), signed kernel norm at (N=1), near-best approximation with the correct larger output degree, and essential-supremum lower bound for the step.
- Ch272 at `84d1491708cd4a0641029e37dd254760a965fd9bfe2fdad178c7b03bb1d97d38`. Verified the Fejér jump transition locally uniformly with (O_U(M^{-2})), translation to arbitrary local traces, strict profile range, the Hölder lower/upper orders, logarithmic Lipschitz rate, and signed flat-top transition limit (2G(2y)-G(y)). Rematch the final exercise wording with its solution's neighborhood quantifier.
- Ch273 at `76116d2b85e211aae25a90483d720489f552a4510b70c42559ab419aa3ff73b7`. Additional exercise on discrete Fourier samples exactly computes cancellation of the periodization. Degenerating anisotropic Gaussian has the stated singular-limit amplitude and tails. Requested a direct testing argument for the limit, so 275 only supplies later vocabulary for an already demonstrated fact.
- Ch274 at `39a61eaf2a00f7595e3132e0e5c83d3df261f45daf344fbfaafdb6b278ed3176`. Covariance transfer from Schwartz to (L^2) added before moving-window computation. Verified final problem wording and Poisson-pair formula/display.
- Ch275 at `809bb922193f7c1c5e1b48db94b6594830d4743c05fbdd42f40a9c1fe6004033`. Integer multiplier derivative budget clarified. Both resonance calculations pass. The first-order primitive characterizes all tempered solutions and its tails decide finite energy. The positive-resolvent contrast, translated principal-value solution, Schwartz division, Gaussian examples, and second-order punctured-root lower bound have correct domains and factors.
- Ch277 at `0bc17a6ac412c16883450f4a9cd6fb5c807b3c4a72d67e37a0edab5057eab864`. Checked the newly explicit infinity-side logarithmic principal part ( (-1)^{m+1}m!b/(s+\beta)^{m+1}\), with sign opposite to the zero-endpoint expression. Splitting and continuing the constant example legitimately shows why the extended prescription cannot use the earlier ordinary-strip uniqueness theorem.

## B-04 signed handoff to B-05 and B-06

**Decision.** The independent B-04 proof and exercise review is complete for the exact V21 B single-Work source candidate `frozen/B05-integrated-v2`. I read the twelve chapters across fixed waves, then matched every final chapter hash to inspected content and checked the actual intervening changes. The controller retains the unique volume master. V20 commit `5e06e3e15db0e6192d4146c44501ff78be7a1914` remains the published numbering anchor at Ch269. The reviewer runtime model/reasoning setting remains UNVERIFIED.

**Receipt.** Checked all 19 entries for path, byte count, and SHA-256 in `frozen/B05-integrated-v2/INPUTS.json`. The manifest SHA-256 is `39f34e858774c3ac35d14298b665b2b6c3553cf4b54c3d82b3182ca18ddd5450`. Exact chapter checks follow. Earlier locations in this report refer to their named snapshots.

| Chapter | Final SHA-256 | Evidence on the final source |
| --- | --- | --- |
| 270 | `2116447199518dd06d21d91b40bd0cfaf98a39a564c8b242001ab34ea224899b` | Finite projection, trace terms, finite grid and positive-moment Toeplitz arguments checked. |
| 271 | `f69582342f5001842bc1f619b8876fcd27d8b223dadb0be2e0c529e81ae004d6` | Young, Fejér, Parseval and flat-top kernel checked. Final line 148 uses an actual bound (B) for the chosen bounded representative, so the pointwise difference is bounded by (2B). |
| 272 | `ddac6f35baf3cab557d75cf92c64bae29bb1d66a190a148d489de82d7e492637` | Exact Fejér transition, local variation, divergence and all solved rate checks verified. Final exercise question and proof now both name an arc containing a neighborhood of zero. New signed transition expands (1-G(y)=1/(πy)+\sin(y)/(πy^2)+O(y^{-3})) by two integrations by parts. For a single sufficiently large fixed (y_k=2πk+π/2), the first nonzero term of (2G(2y_k)-G(y_k)-1) is positive. Compact-profile convergence then gives genuine finite-reconstruction overshoot. |
| 273 | `6fdf87441ff02663c423bec732c360d3de03383a8d78122c9d3c361b7ea41fd8` | Gaussian and covariance proof, Euclidean Young, periodization and cusp checked. Final degenerate Gaussian exercise proves the scalar Schwartz-test limit by \(\xi_2=\sqrt\varepsilon v\) and an integrable product Gaussian, then names its distributional meaning. |
| 274 | `39a61eaf2a00f7595e3132e0e5c83d3df261f45daf344fbfaafdb6b278ed3176` | Absolute inversion, Poisson pair, unitary Plancherel, moving-window phase/energy, and independent (L^2*L^2) counterexample checked. |
| 275 | `7805b2db1b0e78b47292d64ab6a925204f767594c057a60bb661245c5d3cd6d0` | Bilinear Fourier duality, PV signs, Poisson sum, Sobolev thresholds, and both resonance proofs checked. The final resonant first-order symbol is explicitly unbounded on all (L^2), with actions stated on \(\mathcal S,\mathcal S'\). |
| 276 | `2e87c3ce3ed76329bd92159a4a4d0ca75edda773780a7e1c79c899287be7c5cb` | Laplace open/closed boundaries, complex conditional abscissa, ODE Green bounds and delayed impulse checked. |
| 277 | `0bc17a6ac412c16883450f4a9cd6fb5c807b3c4a72d67e37a0edab5057eab864` | Mellin sign and (2π), strip, Euler derivative, poles at the two endpoints, heat and two-channel inverse checked. |
| 278 | `15c3a8d87e772dce2b1b5c40466621d18afd77bf5bdd34728991941a412a48ae` | Weighted Plancherel and causal range/projection checked, both pairing signs, local BV/Dini, Abel and contour inverse. |
| 279 | `f228ce3cacad2882329c228ea8880471d414a01eaa185a97ad21ddb347caf1bb` | Joint representative, affine cofactor, sharp support norm, radial projection, Gaussian covariance and finite moments checked. |
| 280 | `c64d8b6012703d90747b6e53c927d238aac5eff82e6f4f25cdc462c43f255989` | FBP half factor, normal (2/|x|), Abel inverse, signed ramp and pointwise bound checked. Final addition gives the 2D Poisson mass one, 1D projected Cauchy density, absolute damped inversion bound \(\|f\|_1/(2πa^2)\), and three proved convergence modes. Its semigroup and direct squared norm (1/(8πb^2)) match at the origin. |
| 281 | `3a8776d15925c951032018500ca9ea50e2873fc95925f0fc8d94b0fe1eae0e51` | Exact detector weight, arbitrary-data cutoff, noise minimization, sharp weighted constant, Gaussian damping, angular tests and minimax checked. Final diff in the optimization paragraph moves two existing formulas to displays without affecting their arguments. |

**Integration record.** B-04 performed the full-draft and independent mathematical expansion work represented by the original A drafting and thickening steps. B-05 performs source and whole-volume integration. Adjoint and normal kernel land in 280, one-dimensional Poisson pair in 274, and weighted (L^2) comparison in 278. Ch277 constructs the Mellin transform on one (L^2) log line before using it in its own case. All three forward-use concerns in the reviewed proofs were resolved by a local proof or actual prerequisite. The controller kept planar Radon scope. That decision superseded the original design’s proposed higher-dimensional slice preview. Parallel author input was consolidated into the sole `chapters` directory of the exact candidate.

**Files handed to the controller.** `/tmp/v21-work/frozen/B05-integrated-v2/INPUTS.json` and its listed `chapters/*.tex`, frontmatter, bibliography, notation, entry and three figures. Proof findings and original/revised evidence appear in `/tmp/v21-work/audit/B04-thickening.md`. `/tmp/v21-work/audit/B04-ch279-expansion.tex` and `/tmp/v21-work/audit/B04-ch281-expansion.tex` record the two reviewer supplements already integrated by the owner. They are audit history. Historical defects marked pending in their original rows are resolved by the later exact recheck entries above. The B01 source ledger and B05 coverage map remain the independent source-responsibility evidence.

**Open and next acceptance condition.** B-05 source-location and layout-interaction checks, B-06 paired final PDF, per-chapter and aggregate R1 length, compilation and visual receipts, and B-07 final mathematical decision are separate deliverables. Template authority is adopted ReadFlow R1, artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, source ZIP SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`. Later source edits require an exact diff and review of affected statements and adjacent dependencies. Accept the layout handoff after the ordered chapters, active template, hashes, figures, and report match the actual PDF. Keep this review attached to the fixed candidate. The controller's authorized B-08 archive follows the B-07 decision. Retain earlier source acquisitions and frozen volume history rather than restarting or overwriting them.
