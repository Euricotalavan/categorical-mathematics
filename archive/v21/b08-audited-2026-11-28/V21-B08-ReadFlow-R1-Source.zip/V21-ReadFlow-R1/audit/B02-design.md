# V21 B-02 narrative and dependency design — v3

Status: design for independent refinement; not an approved manuscript. 2026-11-28.
Role: expansion. Scope: V21, Fourier Analysis and Integral Transforms, Chapters 270–281, exactly twelve chapters. B single Work is the instructed execution form. The model and reasoning configuration are not independently observable here and remain UNVERIFIED. The controller retains the single master and controls merging.

## Receipt and fixed inputs

Actually read: `V21-Pre-B01-Literature-v1.md`; source navigation v2.1; A/B v4 B-02/B-03, role and handoff clauses; B single Work v1. Actual source-text inspection for this initial design: F2 introduction and §1; F3 §§1.3–1.6 and divergence proof 1.46; newly retrieved S1 Stein–Shakarchi, 2003 publication, typeset October 20, 2007, Ch2 §5.2–5.4 (print pp.53–55). Other chapters below use the PRE-B01 source locations as planning inputs, not assertions that every responsibility has already been audited. B-01's item-level ledger controls later coverage; this design must be aligned to its first responsibility summary before acceptance. The PRE-B01 waiting language is historical relative to the controller's explicit current assignment, not permission to restart another volume.

Curriculum/references v4; preceding volume ends at Ch269, fixed V20 Git `5e06e3e15db0e6192d4146c44501ff78be7a1914`. V21 source responsibility is the approved public-source group F1–F3, L1–L3, T1, M1–M2, R1–R2 subject to controller/B-01 confirmation. The controller subsequently supplied full authorized S1 text at `/tmp/v21-b01/text/Stein-2003.txt`; its approved-source status supersedes PRE-B01's old Stein acquisition gap, but only inspected portions are counted as actually read. Grafakos and Bracewell unavailable portions are not silently treated as read. All prose, examples, and proof exposition will be newly written; sources identify mathematical responsibilities rather than text to reproduce.

## The reader's path and shared contract

The organizing question is: when does frequency data determine an object, in what sense can it be reconstructed, and how do the hypotheses control the answer? Chapters 270–272 answer on the circle, 273–275 on Euclidean space and distributions, 276–278 under exponential and multiplicative coordinates, and 279–281 for projection data. Every reconstruction statement names the object space, data space, representative, convergence mode and actual hypotheses.

* Circle: `T=R/(2πZ)`, representative `[-π,π)`, normalized measure `dm(t)=dt/(2π)`. `e_n(t)=exp(int)`, `c_n(f)=∫_T f(t)exp(-int)dm(t)`. `S_N f=Σ_{|n|≤N}c_n(f)e_n`; `D_N=Σ_{|n|≤N}e_n`. Inner product is linear in its first argument. Circle convolution `(f*_T g)(x)=∫_T f(x-t)g(t)dm(t)`.
* Fejér indexing is fixed: `F_N=(N+1)^{-1}Σ_{k=0}^N D_k`, `σ_N f=f*_T F_N`, with weights `1-|n|/(N+1)` for `|n|≤N`. No source's alternative `F_n` indexing is imported without conversion.
* Euclidean convention: `hat f(ξ)=∫_{R^d} f(x)exp(-2πi x·ξ)dx`; inverse uses the positive sign. Convolution uses Lebesgue measure and is written `*_R` when the ambient space might be unclear. Dilation `K_ε(x)=ε^{-d}K(x/ε)`; translation `τ_y f(x)=f(x-y)`.
* Complex Laplace variable `s=σ+iτ`, `(Lf)(s)=∫_0^∞ f(t)e^{-st}dt`. Its Fourier comparison uses `s=σ+2πiξ`, not `σ+iξ`. Bilateral and one-sided transforms are never conflated.
* Mellin `(Mf)(s)=∫_0^∞ f(t)t^{s-1}dt`; on the line `Re s=c`, set `g_c(u)=e^{cu}f(e^u)`. Then `Mf(c+2πiξ)=hat g_c(-ξ)`. Weighted measure for `X_c^p` is `t^{pc-1}dt` when `p<∞`; the `L^2` norm and vertical-line measure are fixed explicitly.
* Radon in dimension two: `θ∈S^1`, `p∈R`, `Rf(θ,p)=∫_{x·θ=p}f(x)dℓ(x)`; `(θ,p)` and `(-θ,-p)` encode the same line. Angular integrations must state full circle or half circle, and their constants must be derived before use. `R*` and the ramp multiplier are introduced only with their defining measures.
* Equality of `L^p` elements means equality almost everywhere; point evaluation refers to a stated representative. Distribution brackets are complex bilinear, with no hidden conjugation; Ch275 fixes the transform by duality and checks it against regular distributions. `S` is Schwartz space only after its definition; finite sum symbols are not reused as spaces.

External prerequisites: Lebesgue integration, Tonelli/Fubini and dominated convergence; Hölder/Minkowski; elementary Hilbert-space projections; elementary complex analysis for Ch276; bounded operators and the uniform boundedness principle for the divergence example. Each chapter begins with a short usable recall, proving local lemmas where an earlier-volume assumption is not verified. These are prerequisite bridges, not invented claims that V20 already contains them.

## Chapter and section design

Page budgets below are material budgets under the adopted ReadFlow R1 layout, not acceptance criteria. Target is 28 substantive pages per chapter, 336 chapter pages plus approximately 12–24 front/reference pages. A chapter can move within 26–30 pages by changing the number of distinct fully solved problems, never by omitting hypotheses or proofs. Every chapter has six numbered teaching sections; the last carries complete solutions, not answers alone. Planned worked examples and solved exercises are distinct mathematical tasks. Sources below are responsibility anchors pending B-01 row IDs.

### 270 — Fourier Series and Orthogonality (28 pages)

1. **270.1 Periodic data and coefficient measurements** (4 pp): measurable periodic representatives, normalized integration, complex coefficients; derive sine/cosine conversion. Examples: periodic ramp with endpoint identification; complex exponential and phase translation; changing the period and every normalization factor.
2. **270.2 Orthogonality and finite reconstruction** (5 pp): elementary exponential integral, finite orthogonality, coefficient extraction, real-valued symmetry; prove the finite projection and Pythagorean error identity. Example: exact best approximation of a two-frequency signal without appealing to infinite completeness.
3. **270.3 Bessel estimates and data that cannot occur** (4 pp): Bessel inequality by finite projection, square summability, coefficient functionals; prove minimum-error uniqueness. Distinguish Bessel from Parseval. Examples: rejecting constant nonzero coefficient data; equal finite data from functions differing in an unseen mode.
4. **270.4 Coefficients from regularity and boundary matching** (5 pp): integration by parts with explicit endpoint terms, periodic derivatives; decay for piecewise smooth functions. Examples: ramp versus triangle versus smooth matched periodic function; endpoints determine whether the `1/n` term survives. Do not use Euclidean transform.
5. **270.5 Three expansions and a finite energy calculation** (5 pp): calculate ramp, `|x|`, and an interval indicator on `T`, including parity and phase; finite projection error bound using Bessel. Infinite sum evaluations using Parseval are explicitly deferred to 271.5.
6. **270.6 Solved problems: distinguish data, object, and approximation** (5 pp): six fully derived tasks: period rescaling; phase-shifted indicator; real symmetry test; least squares with missing frequency; endpoint mismatch; a discontinuous representative with unchanged coefficients. State what each task tests.

Dependencies: external integration and finite-dimensional Hilbert geometry. Exports to 271: `c_n,S_N,D_N`, finite projection, Bessel, endpoint-aware coefficient formulas. Completeness/Parseval is not asserted yet. Sources S1 Ch2 §§1–3 and Ch3 §1; F2 §1; F3 §§1.1,1.3,1.8; F1 §§1.9,1.12,1.17.

### 271 — Convolution and Approximate Kernels (28 pages)

1. **271.1 Convolution is a well-defined averaging operation** (4 pp): `L^1*_T L^p`, representatives, a.e. definition, full Young exponent inequality `1+1/r=1/p+1/q` with all endpoints and a complete three-factor Hölder proof, associativity where integrability permits, Fourier coefficient product from Fubini. Examples: two periodic interval indicators with wraparound; convolution against a single mode.
2. **271.2 Kernel criteria and translation continuity** (4 pp): translations in `L^p`, `1≤p<∞`, proved from continuous approximation; signed approximate identities with mass one, bounded `L^1` norm, vanishing off-origin absolute mass. Prove uniform convergence on `C(T)` and norm convergence in `L^p`. Explicitly exclude universal `L∞` norm convergence.
3. **271.3 Fejér averaging as a constructive approximation** (6 pp, B-03 calibration): derive finite triangular coefficients and the square formula; prove positivity/mass/concentration; prove all stated convergence modes, an error estimate, and uniqueness. Worked jump and lacunary-frequency examples; two fully solved criterion tests. No general pointwise assertion for arbitrary good kernels on arbitrary unbounded `L^1` representatives.
4. **271.4 Abel means and the Poisson kernel** (4 pp): geometric-series derivation; positivity/mass/concentration and norm/uniform convergence; harmonic extension on the disk with differentiability justified on compact subdisks. Contrast Abel weighting with finite Fejér weighting, without treating them as partial sums.
5. **271.5 Density completes the orthogonality story** (5 pp): trigonometric density from Fejér; Fourier uniqueness in `L^1`; complete orthonormal family in `L^2`; `L^2` partial-sum convergence and Parseval proved from the projection error; re-open 270's energy computations and evaluate two genuinely different sums. Brief Euclidean approximate-identity version proved from translations, with no transform.
6. **271.6 Solved problems: kernels and convergence modes** (5 pp): six full solutions: box kernel; signed bad-mass kernel; concentration failure; interval overlap; `L∞` failure at a jump; Poisson multiplier and boundary behavior. Reuse formulas, not proof paragraphs.

Dependencies: 270; continuous density in `L^p` with a local proof bridge; Fubini. Exports: convolution estimates; norm approximation; Fejér density/uniqueness/Parseval; Euclidean approximate identities for 274. Sources S1 Ch2 §§4–5 and Ch3 §1; F2 §§1,4–5,7; F3 §§1.3–1.6,2.4–2.5,2.12. General pointwise and uniform partial-sum behavior belong to 272.

### 272 — Pointwise and Uniform Convergence (28 pages)

1. **272.1 Four meanings of reconstruction** (4 pp): norm, pointwise, uniform and summability; implications and counterexamples. A representative changed at one point explains a.e. versus pointwise claims.
2. **272.2 The Dirichlet kernel and localization** (5 pp): derive sine quotient; oscillatory representation of symmetric error; prove localization and the necessary Riemann–Lebesgue lemma using 271 density. Derive `||D_N||_1` logarithmic growth with explicit bounds.
3. **272.3 A local Dini criterion and jump values** (5 pp): prove convergence to half the one-sided limits under the integrable symmetric quotient condition; piecewise `C^1` corollary; local BV/Jordan theorem with an independent Dirichlet integral proof (BV is not silently replaced by Dini); examples of a corner, a jump, and a logarithmic modulus that fails the sufficient test. Failure of a test is not a divergence proof.
4. **272.4 Sufficient conditions for uniform convergence** (4 pp): absolute coefficient summability implies uniform recovery by uniqueness; `C^1` periodic function via derivative Bessel and Cauchy–Schwarz; error estimates for higher derivatives. Endpoint matching is checked separately from interior smoothness.
5. **272.5 Why continuity alone cannot suffice** (5 pp): exact norm of the evaluation functional using continuous approximants of the sign of `D_N`; uniform boundedness gives a continuous function with unbounded partial sums at a prescribed point. State the functional-analytic prerequisite and give its usable form. Gibbs analysis for a step: scaled limiting integral, overshoot constant described by its defining integral, and no false uniform convergence across jumps.
6. **272.6 Solved problems: choose and justify a convergence theorem** (5 pp): six complete solutions: piecewise-linear periodicity; differentiability with mismatched endpoints; absolute-sum estimate; Dini integral test; Fejér versus partial-sum at a jump; `L^2` convergence without uniform convergence. Include Fejér convergence at Lebesgue points with the explicit bound `F_N(t)≤min(N+1,π²/((N+1)t²))` and a dyadic-annulus proof using the defining averaged oscillation. Invoke the Lebesgue differentiation theorem only as a declared integration prerequisite. Each task identifies exact hypotheses and mode.

Dependencies: 270–271; uniform boundedness for 272.5 only. Exports: classical recovery conditions and counterexamples. Carleson/Hunt and general `L^p` partial-sum boundedness are excluded; no unjustified a.e. convergence for all `L^2`. Sources S1 Ch3 §§1–2; F2 §§1,4–5; F1 §§1.14–1.16; F3 1.46 and neighboring local criteria. A repeated ramp/step example is retained only when it tests a newly stated convergence mode or regularity assumption; its coefficient calculation is cited from 270 rather than re-derived.

### 273 — Euclidean Fourier Transform (28 pages)

1. **273.1 From periodic coefficients to continuous frequency** (4 pp): definition on `L^1(R^d)` and bounded continuity by dominated convergence; ambient measure and normalization checks.
2. **273.2 Translation, modulation, scaling, and symmetry** (5 pp): complete substitutions in dimension `d`; orthogonal/linear change of variables including determinant; real/even data. Examples: shifted anisotropic Gaussian and interval/box.
3. **273.3 Convolution and products where integrable** (5 pp): `L^1` convolution theorem from Tonelli/Fubini; multiplication identity only under valid inverse representations, deferred if it needs 274. Examples: triangle and repeated box convolution; never infer inversion here.
4. **273.4 Differentiation, moments, and decay** (4 pp): differentiation under integral under moment assumptions, integration by parts with boundary control, multidimensional derivatives. Examples contrast exponential cusp with a smooth compactly supported bump.
5. **273.5 Gaussian, Poisson, and separable transforms** (5 pp): Gaussian integral and transform by ODE or completed-square justified route; Poisson kernel in one dimension; tensor products in `d` dimensions. Each includes absolute-integrability checks and scaling constants.
6. **273.6 Solved problems: transform computations with hypotheses** (5 pp): six solutions: exponential tail, shifted box, anisotropic Gaussian, a derivative transform, moment estimate, nonintegrable constant for which the `L^1` definition fails. The last anticipates, but does not define, distributions.

Dependencies: 271 convolution and Euclidean averaging lemmas; multivariable integration. Exports: `L^1` transform, algebra and explicit kernels. Sources F2 §§6–7,16; F3 §§2.1–2.3; F1 §§8.1–8.2. Inversion, `L^2` extension and distributions stay in 274–275.

### 274 — Inversion and Plancherel (28 pages)

1. **274.1 Gaussian regularization and a route back** (4 pp): regularized inverse integral; Fubini identifies convolution with a Gaussian approximate identity. Derive all constants.
2. **274.2 `L^1` inversion with integrable frequency data** (5 pp): prove a.e. reconstruction and continuity-point reconstruction; define the continuous inverse representative; no claim that every `L^1` transform is integrable. Example: two-sided exponential; box frequency cutoff.
3. **274.3 Schwartz functions as a safe common core** (4 pp): define seminorms, prove transform preserves Schwartz and inversion there; dense core in `L^2`, using cutoffs and mollification.
4. **274.4 Parseval identity and the `L^2` extension** (5 pp): derive inner-product identity on Schwartz by inversion/Fubini; extend isometrically using density; prove onto and inverse, distinguishing `L^2` limits from improper pointwise integrals.
5. **274.5 Band restriction and physical smoothing** (5 pp): projections as `L^2` multipliers; rectangular or radial frequency cutoff convergence in `L^2`; Gaussian smoothing convergence; examples of transformed non-`L^1` `L^2` data via approximation. No claim of pointwise convergence for arbitrary cutoff data.
6. **274.6 Solved problems: identify the inverse and its mode** (5 pp): Gaussian inverse, frequency interval, norm by Plancherel, failure of absolute inversion for box data, convolution recovery, `L^2` Cauchy construction. Full derivations.

Dependencies: 271 approximate identities; 273 kernels/algebra. Exports: inversion, Plancherel, Schwartz core. Sources F2 §§8,12,16; F3 §§2.7–2.9; T1 §1.14(i). The source Hermite-function route may be replaced by this original Gaussian/density route, with B-01 marking the equivalent responsibility, not falsely claiming its proof was followed.

### 275 — Distributions and Frequency-Side Estimates (28 pages)

1. **275.1 Test functions, topology, and continuous functionals** (5 pp): Schwartz seminorms recalled; define tempered distributions, explicit continuity criterion, embeddings of polynomially bounded locally integrable functions; distinguish local integrability from tempered growth.
2. **275.2 Delta, derivatives, and distributional equality** (4 pp): pairing, signs, regular distribution injectivity, delta translation; derive derivative of a jump and explain representative independence.
3. **275.3 Fourier transform by duality** (5 pp): convention checked against regular functions, inverse and derivative/modulation rules; compute `hat δ=1`, `hat 1=δ`, exponentials and comb only if source/coverage authorizes it. Comb otherwise extension exercise, not silent scope growth.
4. **275.4 Frequency estimates and periodic sampling** (6 pp): specialized Fourier Hausdorff–Young via the full strip interpolation argument from the `L^1→L∞` and Plancherel endpoints; state and prove the needed strip lemma rather than invoke a nameless interpolation step. Include Schwartz Poisson summation proved through uniformly convergent periodization and absolutely summable Fourier coefficients. Fix lattice scaling and evaluation constants.
5. **275.5 Polynomial weights, smoothing, and differential equations** (5 pp): define Sobolev `H^s` via weighted `L^2` Fourier data, establish derivative correspondence, bounded multiplier estimates, and the `s>d/2` continuity estimate with its actual weight integral. Distributional convolution with Schwartz under stated conditions; Gaussian multiplier; one nonresonant resolvent example and the obstruction when a multiplier vanishes. 275 may reach 30 substantive pages to preserve proofs under the authorized extra frequency estimates.
6. **275.6 Solved problems: recognize the correct object** (5 pp): delta derivative, Heaviside derivative, Gaussian regularization, negative Sobolev delta threshold, polynomial multiplier, a growth example not defining a tempered regular distribution. Full pairings and integrability checks.

Dependencies: 274. Exports to 278 and 281: frequency-weighted norms and regularization estimates. Calderón–Zygmund theory, general pseudodifferential calculus and a full PDE theory excluded. Sources F1 Ch4; F2 §§13–16; F3 §§2.12–2.16,3.8–3.10.

### 276 — Laplace Transform (28 pages)

1. **276.1 Causal functions and convergence half-planes** (4 pp): one-sided definition, exponential order as sufficient not necessary, abscissa examples, local integrability at zero.
2. **276.2 Analyticity and elementary transforms** (5 pp): dominated differentiation on smaller half-planes; polynomial/exponential/step transforms; show role of complex `s` and open boundary conditions.
3. **276.3 Translation, differentiation, and causal convolution** (5 pp): delay versus exponential modulation; integration by parts includes initial traces; convolution theorem with absolute convergence. Examples check boundary terms rather than table substitution.
4. **276.4 Initial-value problems and transfer denominators** (4 pp): fully solve a second-order forcing problem with delay, inspect poles and validate by substitution; repeated pole and resonance distinguished.
5. **276.5 Vertical-line inversion under usable assumptions** (5 pp): weighted zero extension and Fourier comparison; prove one sufficient Bromwich inversion theorem from 274, including `2π` conversion and endpoint convention. Residue calculation justified by a specified contour in a rational case; general contour closure not asserted.
6. **276.6 Solved problems: existence before calculation** (5 pp): near-zero singularity, exponential rate, delayed forcing, nonzero initial data, convolution, vertical-line choice and inversion. Complete solutions and checks.

Dependencies: 273–274; elementary complex analysis for residues. Exports to 278: weighted-Fourier bridge and exact sufficient conditions. Sources L1 §§6.1–6.3; L2 §§12.4,12.8; L3; T1 §1.14(iii). Unproved source inversion statements are not imported as proofs.

### 277 — Mellin Transform (28 pages)

1. **277.1 Multiplicative coordinates and fundamental strips** (4 pp): defining integral, endpoint integrability, strip from two end estimates; examples `e^{-t}`, a compact annulus, `1/(1+t)`.
2. **277.2 Dilation and multiplicative convolution** (5 pp): measure `dt/t`, substitutions, Mellin convolution and its convergence; derive dilation law with the chosen `t^{s-1}` convention.
3. **277.3 The logarithmic Fourier bridge** (5 pp): `g_c(u)=e^{cu}f(e^u)`, isometry for weighted `L^p`; sign and `2π` conversion; translated/dilated examples.
4. **277.4 Inversion and weighted Plancherel** (5 pp): prove sufficient pointwise inversion and weighted `L^2` isometry using 274; distinguish vertical absolute integrability from norm-limit inversion.
5. **277.5 Endpoint asymptotics and poles in examples** (4 pp): explicitly split at one, subtract finite asymptotic terms, derive meromorphic continuation and residues for a controlled example; no unsupported general contour shifts.
6. **277.6 Solved problems: strips, weights, and reconstruction** (5 pp): six complete solutions including beta-type integral under verified conditions, step-on-annulus, dilation, multiplicative convolution, endpoint pole, choice of vertical line.

Dependencies: 274; basic complex analysis. Sources T1 §1.14(iv), M1 §1, M2 §2. Paley–Wiener theory and general analytic number theory excluded.

### 278 — Mapping and Inversion Conditions (28 pages)

1. **278.1 A transform statement has five pieces** (4 pp): object space, data space, map, equality notion, inverse mode; exact comparison table for Fourier/Laplace/Mellin using prior proved results.
2. **278.2 Weighted Fourier realization of Laplace data** (5 pp): line restriction on `Re s=σ` as transform of zero-extended `e^{-σt}f`; `L^1` and `L^2` alternatives; uniqueness using a line and analytic continuation only where justified.
3. **278.3 Weighted Fourier realization of Mellin data** (4 pp): log substitution, precise inverse/Plancherel constants; varying `c` changes the domain norm; an example where one line is admissible and another is not.
4. **278.4 Necessary cautions and sufficient hypotheses** (5 pp): conditional versus absolute inversion; an a.e. identity does not recover a chosen point value; strip boundary need not be admissible; injectivity versus stable bounded inverse. Each is accompanied by a concrete example, not just warnings.
5. **278.5 Reconstruction with controlled frequency truncation** (5 pp): `L^2` projection error as a tail integral; weighted smoothness gives error bound; Gaussian frequency damping and bias. Avoid duplicating 281 noise optimization, which is only previewed.
6. **278.6 Solved problems: audit a proposed inverse formula** (5 pp): six complete repairs of under-specified claims, each explicitly verifies domain, transform, hypotheses, mode, and representative.

Dependencies: 274–277. This chapter synthesizes and applies, not re-proves three inversion theorems verbatim. Sources F2 §8; L2 §12.8; L3; T1 iii–iv; M2 §2.

### 279 — Radon Transform (28 pages)

1. **279.1 Lines, orientation, and projection data** (5 pp): geometry, quotient redundancy, coordinate parameterization; define on compactly supported continuous/Schwartz functions and extend only with actual integrability evidence.
2. **279.2 Fubini estimates and basic identities** (4 pp): mass identity, support property, reflection symmetry, translation/rotation/scaling. State quantifiers for each direction and a.e. `p` when needed.
3. **279.3 Disk and Gaussian projection profiles** (5 pp): full geometry and integrals; shifted anisotropic Gaussian with completed-square computation; a shell gives an interpretable difference of disk profiles.
4. **279.4 Adjoint backprojection and the normal operator** (5 pp): define measures first, derive adjoint relation by Fubini; compute normal operator kernel in a stated class and derive constants geometrically. No filtered inverse until 280.
5. **279.5 What projection data can and cannot encode** (4 pp): elementary moment identities and range restrictions; illustrate missing-angle ambiguity without claiming a full range theorem or nonuniqueness for compactly supported exact data without proof.
6. **279.6 Solved problems: geometric and analytic checks** (5 pp): redundancy, translated disk, Gaussian, support bound, moment condition, adjoint identity. All computations complete.

Dependencies: 273 multivariable integration/algebra. Sources R2 §1.1, R1 §3.1, F1 §§8.8–8.9. Fourier slice theorem is reserved for 280; its definition does not enter proofs here.

### 280 — Section Data and Inversion (28 pages)

1. **280.1 Fourier slice theorem with constants** (5 pp): prove one-dimensional transform in `p` equals `hat f(ωθ)` from Fubini, including convention and redundancy.
2. **280.2 Polar frequency geometry** (4 pp): `dξ=|ω|dωdθ/2` under full-circle signed parametrization; derive the half-circle alternative and origin null-set issue.
3. **280.3 Filtered backprojection** (6 pp): derive an inverse for Schwartz `f`, define ramp filter by its Fourier multiplier, justify absolute integrals after suitable regularization and pass to limit. Distinguish ordinary integrals and distributions; no pointwise kernel formula without its interpretation.
4. **280.4 Data windows and regularized filters** (4 pp): compact frequency windows, Gaussian filtering; express recovered transform; derive approximation bias using Plancherel.
5. **280.5 Higher-dimensional slices and representative reconstructions** (4 pp): clearly define hyperplane Radon versus line X-ray transform; one proved higher-dimensional slice formula; recover a radial/Gaussian example. Do not equate the two transforms.
6. **280.6 Solved problems: reconstruction step by step** (5 pp): Gaussian slice, disk transform, angular redundancy factor, ramp filtering, cutoff bias, insufficient theorem hypotheses. Full solutions.

Dependencies: 274, 279, selected 275 distribution vocabulary if used. Sources R2 1.1.5,1.3.3; R1 §§3.2–3.3,3.6; F1 §8.11.

### 281 — Inversion Stability Case Studies (28 pages)

1. **281.1 Stability is relative to two specified norms** (4 pp): continuity/Lipschitz estimates, conditional stability, distinguish existence and uniqueness from bounded recovery; simple diagonal frequency example.
2. **281.2 Radon norm identity and derivative loss** (5 pp): derive slice/polar identity and the relevant weighted data norm; support hypotheses and low-frequency issue made explicit. Translate source theorem conventions; the source `HT^s` weight acts on the signed-distance frequency alone and includes no angular differentiation. The forward fixed-support estimate is scoped to `s≥0`. Do not import its estimate with changed measures, omit the compact-support condition, or assert a negative-order proof without supplying duality.
3. **281.3 A high-frequency instability sequence** (5 pp): construct smooth compactly supported modulated examples, calculate object/data scaling with checked estimates; show what fails for a weaker data norm and what remains bounded in a correct norm.
4. **281.4 Cutoff regularization with noise** (5 pp): explicit noise model and norm, derive bias/noise terms and optimize a parameter under a stated smoothness bound; constants and valid exponent range shown.
5. **281.5 Three complete recovery case studies** (4 pp): smooth projection data; noisy ramp-filtered reconstruction; Laplace or Mellin weighted-line reconstruction as a comparison, with direct link to 278 rather than new inverse-problem theory.
6. **281.6 Solved problems and a final theorem-selection audit** (5 pp): six fully worked tasks on norm mismatch, high frequencies, cutoff choice, smoothing bias, support assumption, and a complete transform/inverse/stability argument.

Dependencies: 275,278,280. Sources R2 1.1.8–1.1.9; R1 §5.2. Full tomography sampling, microlocal visibility, nonlinear inverse problems and unrestricted analytic continuation stability excluded.

## Cross-chapter dependency ledger and merge order

`270 → 271 → 272`; `271 → 273 → 274 → 275`; `274 → 276,277`; `275,276,277 → 278`; `273 → 279`; `274,279 → 280`; `275,278,280 → 281`.

No forward theorem is used silently. Ch270 marks its finite energy statements and sends completeness to 271.5; Ch271's pointwise averaging does not establish ordinary partial-sum convergence. Ch273 postpones product identities needing inversion. Ch276/277 each prove their own usable inverse bridge once; Ch278 changes the question to mapping conditions and comparative examples. Ch279 sets geometry and measures; Ch280 supplies slicing/inversion; Ch281 changes the issue to quantitative perturbations.

Parallel preparations are permitted after B-03 approval only for fixed independent chapters/sections with separate files. Ch276 and Ch277 may prepare from the approved 274 export; Ch279 may prepare from approved 273. No role invents another chapter's lemma or changes common macros. Any assumption change invalidates directly and transitively dependent acceptance, to be recorded by refinement/controller.

## Proof and example acceptance contract

Every core definition must be usable from the already-read text: type, space, measure, quantifiers, equivalence-class/representative distinction, and relevant well-definedness. Every named theorem in scope receives a full proof or an explicit, authorized dependency with a proved local usable statement. Examples show membership, hypothesis checks, actual calculation and meaning of the result. Solved problems give derivations rather than final answers. Repetition is reduced by referencing the exact prior lemma, not by dropping necessary assumptions.

Each main section has at least one fully developed example with a different mathematical role from its neighbors. Each chapter's final six problems span recognition, calculation, theorem application, boundary/failure behavior, and a connecting synthesis. Extra problems may be added only if they test a new distinction. Actual page count, source-row coverage, mathematical correctness and readability are independent checks.

## B-03 calibration proposal and decision fields

Selected scope: 271.3, **Fejér averaging as a constructive approximation**. It is narrow enough to read as one coherent section while exercising definition, finite algebra, positivity, concentration, a complete approximation proof, exact equality mode, quantitative example and failure of uniform convergence at a jump. Draft file belongs under `roles/`; it is not merged formal text until controller calibration acceptance. It assumes 271.1–2 only through locally restated contracts. No other formal section begins before that decision.

Keep scale: full sum counting for triangular weights; square formula; small/large arc split; exact quantifiers; representative warning once where needed; complete jump example and error estimate; two solved tests. Slim scale: do not re-prove convolution Fubini or translation density here; quote the earlier established statements precisely. No decorative extra examples with the same purpose. Page-budget calibration is engineering evidence, not mathematical approval.

## OPEN / UNKNOWN and handoff

* OPEN-B02-01: first B-01 responsibility map received and actually read: `/tmp/v21-work/audit/B01-coverage.tsv`, 163 rows. Companion `B02-responsibility-map.tsv` fixes design landings and cross-chapter splits. Independent refinement acceptance remains pending. This is a responsibility plan, not evidence that the eventual prose is covered.
* CLOSED-B02-02: controller/layout contract received: chapter files `chapters/ch270.tex`–`ch281.tex`, each begins with its own chapter heading; shared definition/theorem/proposition/lemma/corollary/example/remark/problem/proof/psolution environments; no preamble or counter edits; shared macros controlled by controller. B03 is a section fragment for host wrapping, at `roles/B03-ch271-fejer-expansion.tex`.
* OPEN-B02-03: exact source theorem conventions for Radon norms, measures and support await B-01/R2 inspection; no numerical constant accepted at design stage.
* UNKNOWN-B02-01: actual pages under final layout and actual coverage completeness await typesetting/item audit. Twenty-eight pages is a planning target.
* UNKNOWN-B02-02: independent model/mode settings and inherited earlier-volume prerequisites not verified; do not advertise them as checked.

Next role: refinement audits dependencies and coverage; controller adjudicates the authorized B-03 sample. Passing condition: all B-01 responsibilities have a unique or explicit shared landing; no circular prerequisites; global notation frozen; sample meets concrete retain/slim criteria. Prohibited: change chapter range or twelve-chapter count; substitute historical templates; start other volumes; publish or mark B-07 passed; merge a draft without independent thickening and refinement. The role has transmitted this design to the controller by the shared file and internal message; durable project save and source/PDF pairing remain controller responsibilities. No PDF is yet produced for this design; compilation not attempted; no mathematical terminal approval claimed.

## v2 change record

Controller reviewed v1 and accepted the proposed density-before-Parseval structure for continuing independent review. This is not B-02 final independent acceptance. Added newly available S1 with inspected print range, source anchors and explicit repeated-example purpose rule. Received LaTeX contract and produced the B03 section fragment. General Fejér convergence at Lebesgue points is not a core claim; finite one-sided limits and continuous-point recovery are proved directly. Uniform boundedness is disclosed external input for 272.5, with a usable statement to appear there. No B04 formal chapter has begun pending controller calibration go.

## v3 scope decisions and item-level reconciliation

Controller explicitly decided: full-exponent circle Young with endpoints in 271.1; Schwartz Poisson summation and the specialized Fourier Hausdorff–Young proof in 275; Radon forward Sobolev proof for s≥0 with fixed support only. No promise is made to reproduce S1's particular continuous-divergence construction: 272.5 proves the stated mathematical responsibility by the disclosed uniform-boundedness route. The companion responsibility map reads all 163 B01 rows, moves completeness/Parseval to 271.5, and marks source text gaps or scope exclusions without changing B01's historical evidence. The Fejér sample itself remains continuous-point/one-sided-limit scope; the separate Lebesgue-point responsibility is planned in 272.6 with the extra kernel bounds, not inferred from the sample's theorem.

Full proofs of local BV/Jordan convergence, the uniform Dini criterion, and endpoint-aware periodic integration of Fourier coefficients are included in 272.3/272.4 and 270.4 respectively. B01 preliminary section numbers are superseded by B02 design positions for this role's chapters. Other chapter writers may refine section order within their fixed chapter responsibility; they must return their final label mapping before integration, so these provisional positions are never asserted as actual prose evidence.
