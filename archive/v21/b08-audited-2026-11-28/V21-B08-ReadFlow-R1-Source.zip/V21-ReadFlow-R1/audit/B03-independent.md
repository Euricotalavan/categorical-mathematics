# V21 B03 independent mathematical review

**Result: PASS for the reviewed calibration section. No mandatory mathematical correction found.**

This is an independent review of the Fejér calibration fragment, not approval of Chapters 270–281 or a substitute for the designated final whole-volume review.

- Reviewed file: `/tmp/v21-work/roles/B03-ch271-fejer-expansion.tex`
- Actual SHA-256: `5b1182430bbca9f6b68df73b68c45dd81a0b063024f61a0f3ff062ea6107e497`
- Review scope: proof dependency chain; kernel normalization and Fejér limits; the L∞ counterexample; the Lipschitz estimate; both fully solved problems.
- Reviewer: Fourier authoring partition, not the calibration-section author. Review completed 2026-11-28.
- Model/reasoning setting: not independently verifiable in this role; no claim of switching models or settings.

## Checks performed

| Item | Actual independent check | Verdict |
|---|---|---|
| Definitions and normalization | The circle has length 2π and normalized measure dt/(2π); coefficients and convolution use the same convention. There are N+1 averaged sums, M=N+1, and F0=1. | PASS |
| Triangular formula | For fixed n, occurrences in D0,…,DN number M−|n| for |n|≤N; all other coefficients vanish. | PASS |
| Square and sine formulas | Expanding the squared geometric sum counts exactly M−|n| pairs. Its squared modulus gives sin²(Mt/2)/(M sin²(t/2)); at t=0 the value is M. | PASS |
| Positive mass and concentration | The square is nonnegative and even; constant coefficient is one. The denominator lower bound outside δ gives an O(M⁻¹) uniform tail estimate and therefore a vanishing tail integral. Normalized tail measure is at most one, so the stated integral bound is valid. | PASS |
| Continuity-point limit for L1 | Near zero, continuity controls the difference and positivity plus mass controls the integral. Away from zero, the correct majorant is [||f||1+|f(x)|]/[M sin²(δ/2)]. No global boundedness is assumed or needed. A null-set change remains immaterial to the convolution. | PASS |
| Uniform convergence on C(T) | Compactness gives one continuity modulus for all x; replace |f(x)| by ||f||∞ in the remote contribution. | PASS |
| Finite Lp convergence | Minkowski and norm continuity of translations for 1≤p<∞ give the displayed near/far estimate. The stated translation-density proof is independent of Fourier convergence, so there is no circular dependency on trigonometric density. | PASS |
| Jump limit | Evenness places exactly mass 1/2 on (0,π). Pairing ±t gives the correct average (a+b)/2; finite one-sided limits control the local expression, L1 controls the remote expression. The assigned value at x is unused. | PASS |
| Density and uniqueness | Each approximant is a finite polynomial; the preceding uniform/Lp convergence gives density. Zero coefficients imply zero approximants, and their L1 limit gives equality a.e. No uniqueness assumption is used earlier. | PASS |
| Step coefficients | Direct integration gives c0=1/2 and c_n=[1−(−1)^n]/(2πin). Pairing odd ±n gives 2 sin(nx)/(πn); the triangular factor is correct. At x=0 and π the output is 1/2. | PASS |
| Essential-sup failure | For each fixed N, continuity and the value 1/2 at zero imply values arbitrarily close to 1/2 on a positive-measure right-hand interval. There f=1, so the essential-sup error is at least 1/2. An argument based only on the single point zero would have been insufficient; this proof correctly uses nearby intervals. | PASS |
| Lipschitz rate | F_N≤M from the square formula, and F_N≤π²/(Mt²) from sin(|t|/2)≥|t|/π. Normalization and evenness give L/π times the first moment. The split at 1/M yields exactly L/(πM)[1/2+π² log(πM)]. It works at M=1 and has the asserted asymptotic decay. | PASS |
| Single-frequency solution | cos(mx) has two coefficients 1/2. For m≤N its attenuation is 1−m/(N+1) and error m/(N+1); for m>N its output is zero and error one. Combined minimum formula is correct, including m=N+1. | PASS |
| Constant-kernel solution | Tail mass is 1−δ/π, independent of N; convolution with cos x is zero, hence uniform error one. The solution proves actual failure rather than merely citing a failed hypothesis. | PASS |

## Proof-chain assessment

The dependency chain is constructive and closed within the stated prerequisites:

finite exponential sums → kernel formula → positive unit mass and concentration → pointwise/uniform/Lp/jump recovery → density and uniqueness.

The Lp proof recalls finite-p translation continuity and explicitly explains its independent continuous-function approximation argument. This is a legitimate incoming result from the preceding section; it does not use the density conclusion established afterward here. No estimate uses L∞ translation continuity. No conclusion about ordinary partial sums is inferred from the Fejér limit.

## Nonblocking editorial precision

The wording “at order at most log(M)/M” is understandable as an upper error estimate; if desired, write “the error is O((1+log M)/M)” to avoid an informal interpretation that the displayed bound vanishes at M=1 or that a lower rate has been proved. The displayed mathematical bound itself is correct. This is not a required correction.

## Remaining limits

No LaTeX compilation or layout review was performed in this audit. This fragment does not establish the unseen preceding section's actual translation-continuity proof or later chapter coverage. Integration should retain that prerequisite, the exact normalization and labels, and both full solutions. PASS applies only to the file with the hash above.

Handoff: B scheme single Work; B03 independent mathematical calibration review; source fragment read and hashed; no mandatory mathematical OPEN items in this scope. Next: coordinating role decides the B03 gate and sends explicit go for B04. Do not redo the accepted Ch273–275 plan or restart frozen work.
