# V21 Ch276–278 B04 expansion handoff

**Handoff ID:** V21-B04-LM-20261128-v1. **Role:** expansion, assigned Chapters276–278 only. **Scheme:** B, single Work, parent-confirmed user authorization to run B01–B08; B03 controller pass received before these formal files were created. **Stage:** B04 complete for these three chapters; handed to refinement/integration and the sole strict thickening final reviewer. This handoff does not assert B07/B08 approval or final whole-volume acceptance. **Actual model/mode:** not independently observable; UNVERIFIED rather than a claimed switch.

## Receipt and fixed inputs

Actually read PRE-B01 v1; relevant Lebl6.1–6.3, Orloff12.4–12.5/12.8, Lindblad16p1 and derivative context, DLMF1.14iii–iv, Zagier§1pp1–3, Bardaro§2pp3–6, Doetsch1974Ch24pp149–160, Ch25opening, Ch26pp169–172 and Ch37pp250–255. Original source hashes Lebl/Orloff/Lindblad/Zagier/Bardaro/NIST were recomputed and match PRE-B01. Doetsch edition and approved accession are recorded in B01-source-access.md; full chapter37 results are not imported without their contour hypotheses.

The controller's chapter contract and B02 narrative were actually read. Numbering is276,277,278 following V20 ending269 and V21starting270; no reset. Formal R1 template, tool ZIP, curriculum and references were not edited by this role. The only manuscript writes were the three assigned files. The parent-supplied two-dilation case was mathematically checked and incorporated into277 with an explicit Ch274-to-Mellin L2 construction before its first use.

## Unique body files (local frozen expansion snapshot)

| Chapter/file | SHA-256 | Contents |
|---|---|---|
| `/tmp/v21-work/chapters/ch276.tex` | `2e87c3ce3ed76329bd92159a4a4d0ca75edda773780a7e1c79c899287be7c5cb` | Six sections: half-plane/conditional-abscissa distinction; calculus/uniqueness/initial expansion; causal convolution/Gamma family; IVP/Green/Volterra/impulse limit; absolute and rational contour inverses; six fully solved problems. |
| `/tmp/v21-work/chapters/ch277.tex` | `0bc17a6ac412c16883450f4a9cd6fb5c807b3c4a72d67e37a0edab5057eab864` | Seven sections: weighted measure/strips; reflected Fourier bridge/calculus; multiplicative convolution/Euler/two-end equations; endpoint-pole continuation/Gamma/beta; scale heat; two dilation channels; six additional fully solved problems. |
| `/tmp/v21-work/chapters/ch278.tex` | `15c3a8d87e772dce2b1b5c40466621d18afd77bf5bdd34728991941a412a48ae` | Seven sections: L1/L2 maps and causal range; orthogonal projection of arbitrary line data with overlap example and solved exercise; weighted conjugate/bilinear pairings; local BV/Dini inversion; Abel and norm inversion; contour shifts and noise; six additional fully solved audit problems. |

Companion preparation files: roles/laplace-mellin-plan.md; roles/laplace-mellin-proof-checks.md. They are planning/derivation evidence, not alternate bodies. Any further edits after the hashes above require a new snapshot and targeted rereview.

## Evidence and fixes actually completed

- Fourier convention fixed exp(-2πixξ); Laplace line argument +τ/(2π), Mellin −τ/(2π), inverse constants1/(2π), line Plancherel dτ/(2π). Mellin conjugates and complementary bilinear lines explicitly derived.
- All ordinary transforms state absolute domains. Analytic continuation, conditional integrals, symmetric inversion, Abel damping and L2 extension have separate meaning. At causal zero, local-BV inversion gives f(0+)/2.
- Local real-line BV proof is present in278 (sine integral, finite Stieltjes variation measure, dominated convergence and an explicit Riemann–Lebesgue tail). Dini is a separate criterion. The compact-log oscillation mechanism already in272 is cross-referenced, and the BV-but-not-absolute-Dini example is proved separately.
- A_c2 data range is the closed causal Fourier image. New278projection section gives Π, nearest-point/Pythagorean proof, stable noisy inversion, exact residual and shifted negative-time-tail example with nontrivial positive-time overlap. This uses only the earlier Plancherel and causal range statements.
- Ch276 absolute inversion continuity upgrade repaired using a sequence from the common full-measure set. Green-kernel first differentiation justified by finite-triangle Fubini and continuity of its inner integral. Point-mass transform defined through a measure integral before use; impulse weak equation and narrow-pulse approximation proved.
- Ch277 uses γ_a for angular heat time, avoiding the earlier chapter's q_t convention. L1×L2 convolution existence is obtained by applying Minkowski to the absolute integral. Two-end BVP uniqueness states its local-AC solution class. Endpoint-subtraction theorem has an initial overlapping half-plane; Gamma+Gamma′ example includes a lower bound at zero to prove necessity of its strip.
- Ch278 weak mth derivative uses (-1)^m and is explicitly connected to Chapter275's tempered derivative multiplier through Schwartz cutoff approximation. Piecewise-C1 sufficiency requires finitely many pieces with C1 extensions to their closures. Mellin shift sign and exact x=1 remainder are checked.
- All provided rational partial fractions, delayed/critical/resonant/Volterra formulas, Gamma/beta constants, Mellin derivative signs, two-channel dα bound, projection overlap norm, sine-sequence instability and six+seven+seven solved tasks were checked by hand. TeX begin/end environments and labels have no unmatched pairs or duplicate labels in the role's structural scan.

## Integration dependencies and effects

Requires Ch274 Fourier L1 uniqueness, absolute inversion, Plancherel and isometry onto L2. Ch278 cutoff bound invokes Ch275 distributional derivative Fourier identity with the exact negative convention; it includes its own weak-to-tempered compatibility. Ch277 two-channel case uses a locally restated log-Plancherel construction rather than forward dependence on278. Changes to Ch274 convention or Ch275 derivative convention would invalidate dependent formulas and require recheck. Ch278 supplies the actual BV/symmetric inverse responsibility used by276Bromwich and277jump discussions. Chapters279–281 can cite its norm/measurement distinction without a forward inverse-problem assumption.

## R1/layout fields

Each file contains its own chapter heading and body only. Labels use ch276/ch277/ch278 prefixes. No global macro or template changes. Chapter276 uses controller-created figures/laplace-vertical-lines.pdf with the explicit calculated magnitude and a caption explaining its non-L1 tail. The long inline endpoint identities in277 were moved to displays after controller build reported 5.9pt/13.7pt overflow. Actual final page counts, updated source/PDF matching, remaining line breaks, bookmarks, package build and PDF hashes belong to the integrated R1 audit; not claimed from word counts. Parent's earlier276measurement was23pages before the final impulse addition; earlier278was16pages before the substantial new projection section. Those old measurements are not final evidence.

## OPEN / UNKNOWN, next step, and pass conditions

**OPEN-01:** refinement and strict thickening reread of the hashes above, including the new278projection case. **OPEN-02:** integrated R1 recompile and rendered overflow/figure/heading/page-break check at these hashes. **OPEN-03:** actual source-item-to-body landing audit and final whole-volume integration; prior labels alone are not evidence. **UNKNOWN-01:** final per-chapter/substantive whole-volume page count. **UNKNOWN-02:** final paired PDF hashes and durable delivery/publish state. Semantic approval and artifact/hash approval are separate.

Next receiver should acknowledge the exact files/hashes actually loaded, preserve corrected items, then report concrete remaining defects by original location/impact/required text/recheck evidence. Passing requires correct definitions/domains/quantifiers, complete proofs and exercises, usable sequential dependencies, actual responsibility landings and rendered paired artifacts. The controller owns the unique master, whole-volume iteration, persistent artifact delivery and any authorized B08 archival action. Do not reopen frozen V20, alter other volumes, tool ZIP or source tables, or treat this handoff as final mathematical acceptance.

**Transmission:** files written to the shared workspace and this ID/hashes sent to controller and refinement. This proves local availability, not durable delivery or actual receiver reading. Controller must record the actual read receipt and final delivery separately.
