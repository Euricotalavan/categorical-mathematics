# V21-B04-RADON-20261128 · expansion handoff v2

**Sender → receiver:** Radon expansion role → V21 controller, refinement, integration and sole strict thickening reviewer. Delivery is the shared local paths below plus an explicit controller message. This is not a user transmission, archive action, or B07 pass. Model/reasoning configuration: UNVERIFIED by this role.

**Authorization and phase:** V21, workflow B single Work as relayed by controller; Chapters279–281 only. B03 controller pass was explicitly received before formal B04 files were fixed. B04 expansion is complete for this block, pending current R1 page counts and independent revision findings. The controller retains the unique volume master. Last independent thickening reread found the new radial, pointwise, heat, angular and lower-bound calculations sound; its remaining small qualifiers/repetition findings were corrected before the hashes below. No frozen volume, extractor ZIP, source sourcebook table or template was modified.

## Actual receipt / pinned inputs

Read V21-Pre-B01-Literature-v1.md; source text of Paternain–Salo–Uhlmann §1.1, §1.2 necessary moments, §1.3.1 including actual Theorem1.3.3 in author manuscript; Kak–Slaney §§3.1–3.3 and §5.2; Osgood §§8.8–8.9 and §8.11. Formal chapter-interface contract /tmp/v21-work/roles/LATEX-CONTRACT.md read. B02 controller design and responsibility map checked against actual chapter content. Source PDFs independently rehashed on this handoff:

| Source | SHA-256 |
| --- | --- |
| Osgood.pdf | 93579ff2ac4082a38240db3eef7dbd6f3354e58db720ad052692b5b6179c5be1 |
| Kak-Slaney-ch03.pdf | b111122976a3488e609913765db1bf6da199c41b258af3bb4f90e84d9da4ae84 |
| Kak-Slaney-ch05.pdf | c8f9271f7cd43e2a855f7d900f5bc0b58d0e9be19560114697622f29ebf93ab6 |
| Paternain-Salo-Uhlmann-ch1.pdf | 65f05a5daf62952a659b1456ac5cdc942ed9b50ddd0a27c4945291977db41d9c |
| Paternain-Salo-Uhlmann-author.pdf | 58a266e9668ef2268ff14044c30f1975a029a76c8ca3e7479ef59ebebffd80e6 |

These agree with the pre-B01 source inventory. Source limitations remain as catalogued there; whole source files and source images are not redistributed as chapter content. The chapter prose, examples and proofs are independently authored around mathematical facts. The historical pre-B01 waiting status is superseded only by the controller's explicit present authorization, not by inference from a file.

Template authority inherited: adopted ReadFlow R1, Library v3, artifact commit8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3, ZIP hash5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732. This role made no style edits. Layout engine version, font realization, paired output-PDF hash and full-volume pagination are not established by source TeX or these source hashes.

## Unique formal files at this handoff

| File | SHA-256 | Actual structure |
| --- | --- | --- |
| /tmp/v21-work/chapters/ch279.tex | f228ce3cacad2882329c228ea8880471d414a01eaa185a97ad21ddb347caf1bb | 8 sections;14 propositions;14 examples;10 exercises and10 full solutions; about5.7k whitespace words plus displays |
| /tmp/v21-work/chapters/ch280.tex | c64d8b6012703d90747b6e53c927d238aac5eff82e6f4f25cdc462c43f255989 | 7 sections;6 theorems;7 propositions;10 exercises and10 full solutions; about6.0k words plus displays |
| /tmp/v21-work/chapters/ch281.tex | 3a8776d15925c951032018500ca9ea50e2873fc95925f0fc8d94b0fe1eae0e51 | 7 sections;3 theorems;9 propositions;2 corollaries;9 exercises and9 full solutions; about6.7k words plus displays |

Supporting files: /tmp/v21-work/roles/radon-plan.md is pre-B04 planning only; /tmp/v21-work/drafts/*.tex are reproducible scratch fragments, never competing masters. Thickening-supplied /tmp/v21-work/audit/B04-ch279-expansion.tex and B04-ch281-expansion.tex were read, verified and merged by this role; they are records, not additional inputs to include. /tmp/v21-work/roles/additions/ch281-case.tex was likewise verified and merged. The figure is the controller-supplied figures/radon-cutoff-error.pdf, invoked at .94 linewidth; no image was fabricated by this role. Parameters a=.55,b=1.35,A=.18 are printed beside its exact model.

## Actual source responsibility / coverage anchors

| B01 item | Actual location and evidence |
| --- | --- |
| V21-279-D01 | Ch279 ch279:lines, line39 definition and subsequent redundancy geometry; full normal/tangent and measure convention |
| V21-279-T01, -T01-P | Ch279 ch279:existence, smooth-support and Schwartz proofs; ch279:covariance translation/rotation/dilation with classes/a.e. stated |
| V21-279-E01 | Ch279 ch279:shapes, disk chord/shift/ellipse computations and mass checks |
| V21-279-D02 | Explicitly transferred to Ch280 ch280:normal, adjoint identity line165 onward; Ch279 source note previews that transfer |
| V21-280-T01, -P | Ch280 ch280:slice, theorem line24 and complete absolute-Fubini proof |
| V21-280-T02, -P | Ch280 ch280:coverage, theorem line69 and injectivity proof; finite-direction compact null objects proved separately |
| V21-280-T03, -P | Ch280 ch280:normal, theorem line185; geometric2/|x| convolution and test-function Fourier multiplier2/|ξ| |
| V21-280-T04, -P | Ch280 ch280:fbp, theorem line138; absolute polar inversion, half/full angular factor |
| V21-280-E01 | Ch280 ch280:cutoff and ch280:checks; explicit ramp kernel, exact low-pass recovery, positive and signed Gaussian checks; fully solved constant exercises |
| V21-281-D01 | Ch281 ch281:norms; H^q object and H_T^t detector-only norms explicitly defined before use |
| V21-281-T01, -P | Ch281 ch281:stability, corollary line61 and complete weighted proof, with exact identity at line41 |
| V21-281-T02, -P | Ch281 ch281:stability, proposition line84; forward proof explicitly q≥0, fixed compact K; low/high split and constant computed |
| V21-281-T03, -P | Same section, explicit two-sided-comparison paragraph; no negative-order forward claim |
| V21-281-E01 | Ch281 ch281:highfreq; annular and fixed-support modulation proofs; ch281:arbitrarydata sharp sqrt(Ω/2); positivity and angular-norm counterchecks |
| V21-281-E02 | Ch281 ch281:split and ch281:exactcase; exact orthogonal decomposition, optimized smoothness bound, fully computed Gaussian/band error; heat comparison has its own cross term |

Line numbers for Ch280 and early Ch281 refer to the hashes above; Ch279 anchors use section labels after removal of a duplicate explanatory paragraph. Source provenance is not by itself semantic acceptance; refinement and strict review must actually reread the displayed proofs and their hypotheses.

## Checked mathematics and numerical evidence

1. Fourier convention exp(-2πix·ξ), S1 measure dθ with mass2π. Signed full-circle coordinates double count both lines and frequency points.
2. Ramp Λ has multiplier|σ|, so f=(1/2)BΛRf=B0ΛRf. BRf has multiplier2/|ξ|. sqrt(-Δ) has multiplier2π|ξ| and consequently f=(1/(4π))sqrt(-Δ)BRf. Its use on BRf is qualified through the regular locally integrable Fourier representative, not arbitrary nonsmooth S′ multiplication.
3. Normal kernel is2/|x|. Nonzero mass gives a non-L2|x|^-1 tail. Pairing a Schwartz test object in the normal multiplier proof has its own direct absolute-Fubini bound.
4. Partial Fourier transform of arbitrary data L2 is defined by a dense tensor isometry; polar null sets are addressed. P averages redundant representatives. TΩ accepts arbitrary L2 noise, even outside classical Radon range, and its exact norm is sqrt(Ω/2).
5. Sobolev exact weight and inverse bound use detector derivatives only. Forward comparison requires fixed support and q≥0 in the actual proof. High-frequency compact modulation includes explicit control of its moving Fourier singularity.
6. Gaussian+band case: noise norm²=.3257203263241898. Table entries recomputed directly. Ω0=.7388080213926242; exact minimum squared error=.04096871947234486. The beyond-band limit=.15471715500399016 is distinguished from endpoint b error.
7. Heat filter has exact norm1/(2e^(1/4)τ^(1/4)), Gaussian object kernel(π/τ)exp(-π²|x|²/τ), valid q∈(0,2] bias proof, Gaussian bias²=τ²/[2(2π+τ)(π+τ)], and explicitly computed nonzero deterministic cross term.
8. Radial inverse has full absolute double-integral proof of the Beta constantπ; nonsmooth disk/taper cases are checked directly and not silently assigned smooth hypotheses.
9. Fixed-cutoff pointwise norm sqrt(πΩ³/3) and derivative estimates derived by Cauchy–Schwarz, giving a different observable from L2 error. Exact-data cutoff is the unique best L2 approximation in the disk-bandlimited subspace.
10. Controller-requested final Ch280 supplement derives the planar Poisson kernel P_a=a/[2π(a²+|x|²)^(3/2)] with mass1 and Cauchy line projection; the1D Poisson pair plus L1 slice gives exp(-2πa|ξ|). Absolute damped polar inversion is proved for f∈L1; L1/L2/BUC-uniform convergence each has its own proof; semigroup P_a*P_b=P_{a+b} and the full norm-check solution are included. Ch281 final delta only displays two rate expressions to avoid overflow.
11. Environment begin/end multisets and total brace balances checked for all three source files. This does not replace compilation or visual QA.

## B mapping, integration changes, OPEN / UNKNOWN

B04 supplies expanded chapter bodies; this corresponds to the original A full-draft/strict-expansion preparation, not a substitute for B05 integration or B07 sole strict final review. The semantic source boundaries remain those above. Controller-approved layout contract is respected: only own chapter bodies were edited; no counter resets, packages, preamble edits or forced page breaks.

* **OPEN-PAGES:** Initial279 diagnostic was17 pages before the extensive merged supplements. New actual R1 counts remain to be reported by layout. Target26–30 substantive pages is not inferred from word, statement or exercise counts. If current counts exceed the agreed range or remain short, decide through actual pages and unique mathematical content.
* **OPEN-RECHECK:** Current hashes need final independent review after all merged additions. Earlier findings have been corrected: Borel/invalid-line representative; affine L1/a.e. qualifiers/cofactor identity; finite-moment/nonnegative centroid hypotheses; adjoint test-function Fubini; non-L1 cutoff-kernel proof; arbitrary-L2 Fourier typing; direction-dependent continuous-origin contradiction; numeric stationary error and rounded optimized bound.
* **OPEN-MAP:** B02 old279.4 adjoint/normal is now280 ch280:normal. B02 old280.5 higher-dimensional slice formula is omitted under controller's later explicit planar-scope instruction; source notes distinguish3D transforms. The controller explicitly reconfirmed the planar boundary and must record the design-map adjustment. Heat smoothing is supplied in281, not280. Necessary moment checks are included; full Helgason range/support converses remain excluded.
* **UNKNOWN-PDF:** Latest paired PDF, PDF hash, converged compile status, final pages, overflow audit and page-by-page visuals are not claimed by this role.
* **UNKNOWN-DEPENDENCY:** Whole-volume forward/back references and notation consistency with final270–278 remain for B05 integration. This block depends on previously proved Fourier inversion, Plancherel, derivative/multiplication rules and Riemann–Lebesgue, each of which is named when used. There are no custom macros to merge.
* **EXCLUDED:** Full range/support/local-uniqueness converses; wavefront/PDO/Funk/geodesic theory; fan/cone beams and full3D reconstruction; signal-dependent clinical/Poisson acquisition models; full sampling theory and unrestricted analytic-continuation results.

## Next action and pass conditions

Controller/layout should compile only the unique current bodies, pair the source snapshot with the resulting PDF, report actual per-chapter substantive counts and inspect any overfull display/table. Refinement must reconcile the coverage anchors against B01/B02. All mathematical corrections return to the sole strict thickening reviewer; no two-objection or parallel-role approval closes the volume. No archival or freezing action is authorized by this subrole handoff.

**Do not redo:** Do not restart B01 source retrieval, the adopted-template choice, frozen volumes, or unrelated chapters. Retain the exact source hashes, approved convention, already correct derivations and original sufficient-hypothesis qualifiers. Do not feed draft fragments separately into the build or count source-note pages as substantive body. A receiving role should acknowledge the actual hashes and files it has read before using this handoff as evidence.

## Final author-wave amendment

Controller requested the planar Poisson supplement after the mixed full-volume diagnostic found Ch280 at20 pages. The supplement is merged; /tmp/v21-work/drafts/ch280-poisson.tex is a change record only, not an extra build input. New page count and PDF pairing remain OPEN. The Ch280 polar-geometry phrase was clarified from “one boundary ray” to “a null boundary line”. Ch281 mathematical content is unchanged after the explicit Schwartz-domain fix; only the two optimized-rate expressions now use display math. All three chapter files are now stable at this v2 handoff.
