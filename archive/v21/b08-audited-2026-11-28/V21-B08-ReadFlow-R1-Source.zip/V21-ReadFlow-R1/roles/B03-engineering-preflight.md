# B-03 / V21 layout engineering preflight

2026-11-28. Role: independent layout officer. Scope: engineering setup and representative-section presentability only; no chapter body authored or edited here.

## Actual input receipt

Read project_sources/21-v2.1.txt, 20-Git-QA-v3.txt, 13-A-B-v4.txt third part and B layout responsibilities, 05-ReadFlow_Editor_Operating_Draft_v1.md, the relevant full textual report of 04-Math_Readability_System_Study_v1.html, and 07 delivery manifest. Read fixed Git SUCCESS-ANALYSIS.md and REUSE-GUIDE.md at dde82ab6b14859774b7f26283bf15b6f2000847e, METHODOLOGY-v1.md and EDITOR-QA-v1.md at f4969cc5336bf761d5f80ff616531f85b357a475. Local reference snapshots are in refs/.

ReadFlow research screen sample: all seven pages rendered at 90 dpi equivalent and actually inspected in order. Observed the short final answer tail and R.4 heading/prerequisite separation at pp5–6; these are research limitations, not new V21 findings. No frozen manuscript changed.

Template archive: /tmp/v21-template.zip, 7,007,679 bytes, SHA256 5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732. Fixed artifact commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3. Complete original verify.py PASS: 913 release files and 668 frozen-math source records; zero discrepancies. No V0 body is input by the V21 adapter.

Font/tool recovery: roles/layout_final tooling and dependencies from verified /tmp/v21-b01/prior-v20.zip; dependencies/ and qa/dependencies-manifest.json preserve exact files and licenses. Installed TeX files were present; missing system filename databases and xelatex format were bypassed with explicit TEXMF and a generated local format. No alternate fonts or style parameters used. Tectonic cannot fetch its bundle (HTTP403), so it is not the active compiler.

## Engineering result

Minimal temporary fixture `layout/study/smoke.tex` compiled by `tools/build.py --fixture`; two converged XeLaTeX passes, zero hard/overfull/header/underfull diagnostics. Output: tools/runs/fixture/build/entry.pdf; SHA256 6e1a24073748b38a8a99497203c6ff2afb0bc9468e713d7aa8df3842739fd3a7. The one page was actually inspected: chapter270/volume21 metadata, definition, proposition, proof, exercise and solution visible; no clipping or footer collision. This fixture is test data, not V21 body.

Three pinned styles have unchanged original hashes, listed in LATEX-CONTRACT.md. R1 body10.4/16pt, 190×260mm geometry, colors and breakability remain unchanged. Runtime builds use XeTeX 0.999996, TeX Live2025/dev/Debian; actual model/reasoning-strength setting was not exposed for independent verification.

## OPEN / next step

- Actual B-03 representative mathematical section: received and preflight completed below; the engineering fixture alone did not replace this calibration.
- B-05 fixed chapter/whole-volume integrated input and manifest: pending. No whole-volume B-06 status claimed.
- Mathematical status: not reviewed by layout; unique B-07 whole-volume strict final reviewer remains thickening.
- Full V21 page count and target300–400: not measured; content substance must determine page count, no added empty pages/spacing.

Chapter contract is complete in roles/LATEX-CONTRACT.md and sent to writing roles. Representative-section preflight is complete below. Once B-05 arrives, fix exact input hashes, compile, perform complete physical-page visual inspection and chapter reading, then deliver paired source/PDF plus B06-layout.md only to B-07. Any semantic issue returns to the content owner. Do not restart unrelated/frozen volumes or alter the R1 baseline.

## B-03 fixed representative section received and inspected

Actual author file: `roles/B03-ch271-fejer-expansion.tex`, v1, 12,483 bytes, SHA256 `5b1182430bbca9f6b68df73b68c45dd81a0b063024f61a0f3ff062ea6107e497`. The author confirmed this version is fixed. Layout did not change it. Separate minimal header sets Chapter271 and section counter2 before input; the sample appears as §271.3.

Direct-snapshot build: `tools/runs/B03-fixed-v1/build-report.json`; two converged XeLaTeX passes; zero hard, overfull/header and underfull diagnostics. Six-page PDF: `tools/runs/B03-fixed-v1/build/entry.pdf`, SHA256 `66fa4f4e67dcd25fa9e13dc016faeeac24bb5e93e56df3a79d86eb1334603cdf`. Every page1–6 was rendered at110dpi and actually inspected in order, including the full theorem/proof at pp3–4 and Example271.6 continuation at pp4–5. No cropped formula, missing text, white text, isolated heading or footer collision observed. P3 last formula lower limit ends at682.55bp while footer numeral starts699.84bp, giving17.29bp separation. The example continuation repeats its identity. The theorem proof continues naturally without a repeated theorem label; full-volume continuation navigation remains a point to check after final reflow. No sample patch was made.

Native figure path preflight: `tools/runs/asset-path-preflight/build-report.json`, two passes, zero engineering warnings, two pages actually rendered and inspected. All three native PDF figures appear at normal linewidth with readable axes/legends/captions; no crop. Recorder `entry.fls` confirms all three assets were read from immutable `inputs/figures/` copies, with original asset hashes recorded. PDF SHA256 `dc51f3ef7317d38a8a113a3a5b45f28ff168257b1829652e8dd6a511ffb824b7`. This is a separate engineering fixture, not manuscript content.

B-03 presentability preflight: PASS within the six-page fixed sample and two-page asset test. B-03 mathematical calibration is the content roles' responsibility; this does not clear B-05/B-06/B-07.

## Engineering negative controls

Separate artificial fixtures under qa/negative confirmed the checks detect an undefined reference, an overfull vbox (255.86pt), intentional white text, and ten missing expected row markers. The repaired breakable align control preserves all45 markers, with zero white/out-of-page spans and zero compiler warnings. Results: qa/negative/control-results.json. These are not manuscript pages and do not claim visual acceptance of the controls.

Additional source receipt: 06-ReadFlow_Study_Handoff_v1.md and 08-ReadFlow_Evidence_v1.json read, including research-only status, three-profile locality, original negative controls, same-environment restore scope, and retained OPEN/UNKNOWN. Their historic non-adoption wording does not override the formal R1 adoption.
