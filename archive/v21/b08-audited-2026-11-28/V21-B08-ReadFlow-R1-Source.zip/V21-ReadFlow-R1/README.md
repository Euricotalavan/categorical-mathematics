# Categorical Mathematics · Volume 21

*Fourier Analysis and Integral Transforms* · Chapters 270–281 · ReadFlow R1

Volume 21 covers periodic Fourier series, Euclidean transforms and distributions, Laplace and Mellin transforms, and the planar Radon transform. The reading PDF in this archive is paired with the exact source in its manifest.

## Read or verify

Open `V21-B08-ReadFlow-R1.pdf`. Run `python3 verify.py` from the extracted archive to verify the archived source and paired PDF by SHA-256. `MANIFEST.json` lists every member, its byte count and its digest. `audit/` records sources, proof and example responsibilities, ordering of prerequisites, review actions and scope decisions.

## Rebuild

On a TeX Live Linux environment with XeLaTeX and fontconfig, the fixed-font build adapter uses the fonts and licenses in `dependencies/`.

```sh
python3 tools/build.py --full --preamble notation.tex --front frontmatter.tex --back bibliography.tex --name rebuild
```

The rebuilt PDF is `tools/runs/rebuild/build/entry.pdf`. The adapter writes an input snapshot and build report. TeX Live package updates can change the byte digest of a newly built PDF. The archived PDF digest remains available in the manifest.

`main.tex` is a relative-path XeLaTeX entry point. In a TeX installation with the archived font families available, compile it from the extracted root and rerun until cross-references settle. The three fixed ReadFlow style files are under `template/V0-ReadFlow-R1/layout/`. The source anchor for that template is artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`.

The original figures are included as vector PDFs. Regenerate them when needed with `python3 tools/generate_figures.py`, using NumPy and Matplotlib. The LaTeX build uses the archived PDFs directly.
