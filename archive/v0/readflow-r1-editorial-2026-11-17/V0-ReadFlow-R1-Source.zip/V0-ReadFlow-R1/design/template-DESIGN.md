# Design decisions v0.2

This is a substantive template upgrade from the verified v0.1, with two
different reading treatments applied to identical representative content.
It remains an independent proposal for user review and dot's controlled
integration. No author or content-refinement source has been changed.

## Book: editorial continuity

The smaller page, Pagella text and its matching mathematical font establish
a coherent book texture. Chapter titles are serif, left aligned and never
hyphenated; section headings use a restrained dark green. Statement labels
are bold and identifiable, while proof-stage labels run into the paragraph.
Indentation and modest paragraph gaps preserve continuity through a long
argument. The running title uses real small capitals; the centered page
number is quiet and predictable.

This direction favors a compact bound-book reading rhythm. The font remains
11 TeX points, with 14.2-point baseline spacing and a 143 mm measure. A smaller
physical page is part of the design, so pages should not be compared merely
by fitting both PDFs to the same viewport. Actual size and fit-width checks
are both relevant. Page count is not a measure of mathematical coverage.

## Study: visible logical stages

The A4 page uses Schola, a different serif design, with its matching Schola
Math. Main text is 11.5 TeX points on a 15.8-point baseline. The reading measure
is 147 mm, with a 36 mm outside margin. Unindented paragraphs have a 4-point
gap. The hierarchy uses a restrained sans serif, and theorem headings and
proof stages receive their own readable line where appropriate.

The larger apparent letterforms, shorter measured prose lines and stronger
stage cues are intended for deliberate reading and note-taking. They do not
rely on enlarging empty areas. Keep only the actual space needed to identify
data, make a test, check each projection and invoke uniqueness.

## Mathematical presentation

Both variants load one common specimen. A source-level comparison checks the
normalized mathematical expressions against v0.1. It ignores layout alignment,
horizontal/vertical spacing and terminal sentence periods; it does not claim
formal theorem verification.

- The supplied comparison data distinguish arrow types from compatibility
  equations in separate display rows.
- Dense composite calculations break at valid intermediate equalities.
- Two inverse identities and both pairs of round-trip projection checks use
  aligned rows, making each verification independently traceable.
- Two short auxiliary assignment pairs remain inline. Core tests and dense
  verification chains stay displayed. No formula is reduced with resizebox,
  scalebox or a smaller mathematical font to fit its line.
- Long proofs break naturally. A short proof-stage opening stays with enough
  of its argument to avoid a stranded label or unexplained equation.
- Setup diagrams precede their related statements; diagrams retain exact
  arrows, labels and mathematical geometry.
- The numbered environments, `pf`, `problem` and `psolution` conventions are
  retained. Equations and theorem references remain live local destinations.

## Color and reading checks

Exact values and calculated contrast ratios are in design-values.json.
The Book palette is F8F4EA paper / 25251F body / 4A4C45 secondary / 315B55
structure. Study is F5F1E7 paper / 242A28 body / 454D49 secondary / 2D5660
structure. Body text stays dark; secondary text also retains strong contrast.
Headings, labels and layout identify mathematical roles without depending
on color. Both variants can be built with black ink on white paper.

Contrast is calculated from sRGB relative luminance using
(L_high + 0.05) / (L_low + 0.05), following the definitions linked from the
W3C explanation of contrast minimum:
https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html

These ratios are a color check, not a declaration of complete PDF accessibility
or medical eye protection. Font weight, size, line length, anti-aliasing,
screen brightness, ambient light, zoom and individual preference also affect
the experience. Warm paper or a darker background is not itself evidence of
a health benefit. No subjective beauty score is reported as a measured fact.

## What changed from v0.1

The former Latin Modern-only typography is replaced by two deliberately
matched text/math pairs. The hierarchy, page proportions, paragraph rhythm,
proof stages, caption sizes, running furniture and notebook organization are
designed as systems. Both provide PDF bookmarks for the guide, prerequisites,
chapters/sections and construction record.

The lengthy opening scope/rights explanation remains present as secondary
paratext; it flows into local prerequisites rather than forcing a nearly
empty solution-only page. No mathematical material is shrunk in that change.
The final notebook record retains all original prompts and its filled example.

The method of explicit roles, reusable values and actual specimens continues
the earlier adaptation of VoltAgent/awesome-design-md. Its IBM/Notion analyses
are third-party website analyses, not official brand standards. No website
card, hero, CTA or decorative frame is imported. Attribution is retained in
licenses/THIRD-PARTY-NOTICES.md.

## Review and adoption boundary

Measure actual PDFs and inspect every page, including long proofs and the
notebook. Read contrast and line-length statistics alongside the pages, not
as a substitute for viewing them. Preserve the independent v0.1 baseline
and source hash. Adoption requires the user's review and dot's integration;
neither specimen is automatically applied to any volume.
