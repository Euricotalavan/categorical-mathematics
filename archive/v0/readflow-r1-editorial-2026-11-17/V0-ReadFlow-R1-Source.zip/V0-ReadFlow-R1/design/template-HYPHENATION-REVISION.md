# v0.2-r1: minimal English hyphenation correction

The verified v0.2 source is the sole starting point; its ID, version and exact
ZIP hash are in provenance/revision-baseline.json. It remains unchanged and
available for rollback. The printed design edition stays v0.2; r1 identifies
these delivery filenames. This is not a new template design or volume edit.

## Measured diagnosis

The running XeLaTeX format loaded hyphen.tex into language 0 (English). The
format log reports a hyphenation trie with 181 operations for language 0.
English patterns were present. At the actual document start, however,
lefthyphenmin and righthyphenmin were both 0. Before/after probe logs are in
review/hyphenation; the probe's intentionally underfull showhyphens box is
not a production-document layout diagnostic.

| Test | Language | Left / right minimum | Reported discretionary breaks |
| --- | --- | --- | --- |
| Original config | 0, English | 0 / 0 | s-tate-men-t; U-nique-ness; ques-tion-s; I-den-ti-fy |
| Babel English in same toolchain | 0, English | 2 / 3 | state-ment; Unique-ness; ques-tions; Iden-tify |
| Final shared config | 0, English | 2 / 3 | state-ment; Unique-ness; ques-tions; Iden-tify |

Thus the observed zero minima explain the isolated letters; a missing English
pattern set was not the cause. The fix uses Babel English, selects English
explicitly at document start and declares minima 2/3. No word exceptions were
added. Existing hyphenpenalty, exhyphenpenalty, paragraph justification and
emergencystretch are unchanged. A captionsenglish hook retains pf after
Babel language selection; problem and psolution conventions are unchanged.

## Actual final checks

Both representative PDFs remain 9 pages. Only the independent specimens,
white print entry points and one-page authoring/notebook entries were built.
No author/refinement manuscript or historical volume build was touched.
Both sample builds converged in two passes, with no overfull/underfull boxes,
missing characters or unresolved-reference diagnostics. The existing enumitem
negative-labelwidth advisory remains in the notebook definition; labels and
text were visually checked and do not collide.

Both variants still read byte-identical representative content, diagrams,
variant configs and entry points. All 298 normalized mathematical expressions
match v0.1 fingerprints; no prose wording or mathematical expressions changed.

Updated prose line characters (median / p90 / maximum):

- Book: 76 / 84 / 90.
- Study: 72 / 79 / 83.

These are measured from the final PDFs by check.py, not carried over from
v0.2. Design values and contrast values are unchanged. The exact current
measurements are in review/metrics.json.

Changed text-layout pages versus original v0.2:

- Book: 4, 9.
- Study: 1, 3, 9.

All 18 final pages were rendered with Poppler and inspected, including each
changed page and its neighboring page boundaries. The reported isolated-letter
breaks on Study pages 1, 3 and 9 are corrected. No new stretched-looking gaps,
clipping, missing mathematical glyphs, collisions or unintended sparse pages
were observed. Normal hyphenation remains enabled. Literal hyphens such as
split-r1 are source punctuation, not discretionary dictionary breaks.

Print checks confirm the same text and pagination as the warm specimens.
Both authoring templates and blank notebook entry points still compile to
one page. Font embedding, links, bookmarks and page bounds pass check.py.
Visual judgment is not a universal comfort or medical-effect measurement.

## Delivery integrity

The final source package includes English editorial rules, design values,
the two editable variants, common content, fonts/notices, blank notebook entry
points and QA records. A separate delivery verification records exact native
IDs, versions, SHA256 values and the redownload comparison. Platform C2PA
attachments can change standalone PDF bytes; page equivalence is verified
separately. Original v0.1 and v0.2 deliveries are retained, not repacked here.
