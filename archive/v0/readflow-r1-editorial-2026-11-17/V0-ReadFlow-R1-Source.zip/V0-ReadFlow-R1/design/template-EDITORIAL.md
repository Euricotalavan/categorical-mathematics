# English editorial conventions retained for v0.2

Retained from the verified v0.1 source. This design round changes presentation only; it does not repeat the completed prose-editing passes.

These are project-specific writing decisions. They extend the design-document
method; awesome-design-md does not provide mathematical prose standards.

## Voice and sentence structure

Write direct, precise English for a reader learning to use the mathematics.
Prefer a concrete subject and verb: “The square equation gives ...”, “Apply
the property of P ...”, “Since m is monic ...”. Use “we” for a shared proof
strategy when useful, without making every sentence begin “We now ...”.

Avoid empty introductions such as “It is important to note that”, “It is
easy to see that”, “We can clearly observe that”, or “This is precisely the
key point”. Replace them with a reason or delete them. Do not mechanically
ban ordinary connecting words if they express a real logical relationship.

Keep necessary quantifiers and assumptions even when the result becomes a
little longer. Never edit “supplied pullback” into “the pullback exists”,
“compatible isomorphism” into “the unique isomorphism”, or a given-set model
into a general internal construction. Concision cannot strengthen a claim.

## Paragraphs and mathematical roles

Each paragraph should have a principal task: introduce a problem, state data,
make a construction, verify it, prove uniqueness, or interpret a conclusion.
Combine related tasks when short. Add a transition when the proof changes
test source, target universal property or direction of factorization.

State motivation in terms of the problem being solved. A construction may
start with “We want to preserve the map into B” when that is what determines
the test. Avoid claims that a topic is “powerful”, “elegant” or “fundamental”
without a concrete explanatory role.

Definitions state the ambient setting and separate data from properties.
Theorem statements expose hypotheses and conclusions. Proofs identify a
competitor before invoking uniqueness. Examples state their interpretation;
ordinary supplied sets are not silently promoted to a foundation for the book.

## References and terminology

Use stable terms from the author source: supplied, compatible, monic,
comparison, test and factor. Do not alternate among names just for variety.
An informal word such as “portion” belongs in motivation; the formal claim
must specify the actual monomorphism and comparison relation.

Use “Lemma 0.2” or “Proposition 8.5” with a real local link when available.
An outside result must be identified honestly, with its relevant assumptions.
Do not invent a local label or a live-looking destination for an excerpt.
Do not use an exercise as an unproved theorem. Add a local proof, cite an
established result with its conditions, or flag the dependency for the author.

Use id consistently as an operator with the object subscript. Composition is
written with circ. Explain the direction of a comparison once, and preserve
the source and target of every constructed arrow through the argument.

## Examples of editing decisions

| Weak wording | Preferred revision | What is preserved |
| --- | --- | --- |
| It is clear by the universal property that the arrows agree. | Both arrows factor the same test X, alpha, beta; uniqueness gives their equality. | Source, two maps and reason for equality |
| We now proceed to construct the required induced comparison map. | Test P_n with u composed with p_m and q_m. | Actual construction step |
| The two objects are the same. | The constructed maps are inverse and preserve the specified projections. | Isomorphism and compatibility, without literal equality |
| The pullback construction exists. | Supply a pullback of these two arrows. | Local existence assumption |
| This proves the result in a straightforward manner. | Delete, or name the precise conclusion proved. | Mathematical conclusion without commentary |

The table uses plain-text notation for brevity. The LaTeX specimen uses
mathematical symbols and typed equations.

## Two passes

First pass: check the route through the argument. Add only the motivation,
transition or stage label that resolves a real reading obstacle. Identify
where cancellation, compatibility and uniqueness have different jobs.

Second pass: read every sentence aloud internally, shorten unnecessary
phrases, and remove repeated summaries that add no interpretation. Check
that a line broken for typography still belongs to the same sentence and
that a short label cannot be stranded at a page foot.

Keep an exact diff for excerpt changes and a short rationale. If a suspected
mathematical defect cannot be resolved without changing the claim, mark it
for the content editor rather than silently rewriting the theorem. This
delivery checks the representative local arguments only; it is not a full
mathematical audit of Volume 0.
