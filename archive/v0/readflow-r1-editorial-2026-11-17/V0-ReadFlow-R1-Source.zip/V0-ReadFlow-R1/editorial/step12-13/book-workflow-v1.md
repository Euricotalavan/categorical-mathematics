---
contract: categorical-mathematics-three-agents
version: 1.0
language: en-primary
boundary_return_max: 1
boundary_requires_consensus: true
large_gap_return_max: 1
refinement_batches_target: 3
refinement_batches_max: null
checkpoint_minutes: 15-20
checkpoint_blocks_work: false
dot_role: [coordinate, verify_handoff_identity, deliver, write_closure]
dot_reaudits_math: false
current_volume: V0
current_stage: editorial
current_input: F1
restart_current_volume: false
archive_repository: https://github.com/Euricotalavan/categorical-mathematics
archive_visibility: private
cloud_retention_target_mb: 150
immediate_deletion_authorized_by_this_contract: false
---

# 三線工作契約 v1.0

依使用者 14 步流程及已確認五項修正整合。後續以本契約交接，不重開第 0 卷已完成的定界、擴展、精修；F1 已進編輯，繼續當前工作。

## 14 步狀態流程

```mermaid
flowchart TD
 S1[1 精修提出覆蓋表] --> S2{2 擴展審核並達成共識}
 S2 -->|同意| S3[3 擴展提出敘事順序]
 S2 -->|意見單；至多退回一次| S1
 S2 -->|一次退回後仍無共識| U[使用者協調]
 U -->|確定邊界| S3
 S3 --> S4[4 擴展完成敘事粗稿]
 S4 --> S5{5 精修檢查覆蓋表}
 S5 -->|完成或少量缺口自補| S6[6 精修審查嚴謹性與完整性；報告及方針]
 S5 -->|大缺口：一次合併意見單| S4
 S5 -->|已退回仍無法解決| C[dot 先協調；無果交使用者]
 S6 --> S7{7 精修任務與問題已解決}
 S7 -->|否：依方針集中修補| S6
 S7 -->|無法解決| C
 C -->|決策後回到對應步驟| S7
 S7 -->|是| S8{8 編輯核對問題清單}
 S8 -->|未解或新數學疑問：問題單| S7
 S8 -->|已解| S9[9 編輯提出排版及行文方案]
 S9 --> S10[10 編輯產出第一版；分交擴展與精修]
 S10 --> S11{11 兩線分別回覆意見}
 S11 -->|均無意見| S14[14 結案；dot 撰寫結案說明]
 S11 -->|有意見；保留兩份| S12{12 編輯決定採納與改進方針}
 S12 -->|純編排意見不採納並說明| S14
 S12 -->|採納或更佳方案| S13[13 編輯完成第二版]
 S12 -->|數學含義或內容遺失等未解| S7
 S13 --> S14
```

圖中回到第 7 步的協調結果依實際決策落到所需步驟，不表示可跳過未完成的第 4–6 步。第 13 步仍須解決已採納問題；不得把未解阻礙當作結案。

## 角色與輸入輸出

| 角色 | 輸入 | 自主責任 | 輸出 |
|---|---|---|---|
| 內容精修 | 文獻、既有矩陣、粗稿、編輯問題單 | 定界；判定完整度；少量缺口自補；嚴謹化與粗編排；解決數學問題 | 覆蓋表、集中意見單、精修來源、審查報告與問題狀態、編輯交接 |
| 內容擴展 | 覆蓋表、集中缺口單 | 形成邊界共識；敘事順序；約 3–4 批流暢粗稿；編輯首版回饋 | 同意或具體意見單、完整粗稿與覆蓋落點、獨立編輯回饋 |
| 行文編輯 | 精修來源、問題清單、修改方針 | 核清單而不重證；行文、排版與可讀性；首版送兩線；決定純版面意見；形成次版 | 可編輯來源與對應 PDF、問題處理表、版面驗收與最終交接 |
| dot | 各線交付及阻礙 | 決策、協調、確認版本更新及實際接收、交付與結案 | 正確版本交接、必要仲裁、結案說明；不逐批重審數學或編輯 |

## 執行與仲裁規則

1. 邊界表列定義、命題等名稱或敘述、文獻原文定位、現稿落點及 `covered / partial / missing / later-volume / unknown`。未取得正文必標 `unknown`，不得宣稱所有文獻無遺漏。
2. 邊界必須有共識；第 2 步至多退回第 1 步一次。仍無共識由使用者協調，不自行強制定界。
3. 少量缺口由精修自行補；大缺口一次集中退擴展，不連串碎片派工。判斷由精修負責，不等待 dot 重審。
4. 精修約 3 批為目標，**不封頂**；必要修補持續至完整性、嚴謹性達標。無法解決先交 dot 協調，仍無果再交使用者，不把假設冒充證明。
5. 編輯核問題清單及已解狀態，不重做證明。新數學疑問以具體問題單交精修。
6. 編輯有版面與行文決定權，可處理兩線相互衝突的純編排意見；但數學含義、內容遺失、可讀性問題不可純以美感否決。未解則回相應責任人，必要時由 dot 協調。
7. 各角色合併階段工作，自主完成，不逐 checkpoint 等批准。每主要節或約 15–20 分鐘保存可恢復來源；checkpoint 是防失存檔，**不是正式迭代，也不是停工點**。
8. 第 10 步第一版須分別交精修與擴展；第 11 步須取得兩線各自明確回覆（意見單或明確無意見），缺回應不等於無意見，不可因此直接結案。
9. 不打斷正在生成的工作。新流程於閒置或正常可接收且不中斷時傳達；交接需實際接收回覆，不以送出泡泡代替確認。

## 交接資料契約

每次正式交接附以下 YAML；只列變更與必要資訊，不重打包歷史 ZIP。

```yaml
handoff:
  volume: V0
  stage_from: refinement
  stage_to: editorial
  source_version: F1
  parent_version: "exact prior version"
  source_id_or_commit: "persistent source identifier"
  source_sha256: "actual hash"
  changed_paths_or_sections: []
  outputs:
    editable_source: "identifier"
    pdf: null # 尚未生成時保持 null，不填舊版冒充
    coverage_table: "identifier"
    issue_list: "identifier"
  unresolved: [] # 真實未知、阻礙、責任人；不得省略
  requested_next_action: "one consolidated stage"
  recovery_reference: "verified recoverable parent/archive"
  receiver_ack: null # 接收者回覆後才填版本及後續行動
```

若內容未變，只報狀態或確認，不人為產生新內容版次。不同角色使用獨立後繼副本，不覆蓋在途來源；合併核對前置版本，版本衝突不得盲目覆寫。

## 版本、封存與結案

- 中間來源、審查與交接資料以私人 GitHub 封存為目標；完成卷的完整來源與對應 PDF 可形成正式結案版本。中間提交不得標成已完成卷。
- 實施封存前先盤點檔案、核對私人遠端、來源版本及安全恢復能力，避免重複、巢狀 ZIP 和遺失。不得把計畫上傳當作已上傳或把存在遠端當作已驗恢復。
- GPT 雲端保留必要文獻、最終結案說明及最終 PDF，以不超過 150 MB 為目標。具體清理範圍、恢復核驗及必要確認完成前，**不刪檔、不搬移現用資料**；容量目標不是犧牲內容或文獻的理由。
- 結案說明由 dot 記錄卷別、交付版本、來源與 PDF、兩線回饋及編輯決策、已完成範圍、真實未解或未知、封存與恢復狀態。不得把局部候選、批次或版面認可稱為整卷完成。
- 第 0 卷目前沿用 F1 → Study 編輯；不因新契約重做，不重啟已停止的舊作者。英文本優先，保留使用者已認可版面方向。
