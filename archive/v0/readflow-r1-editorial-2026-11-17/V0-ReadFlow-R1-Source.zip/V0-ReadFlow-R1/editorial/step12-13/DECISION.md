# Workflow steps 12–13: editor decision and second edition

Both required independent Step 11 replies and the full contract v1.0 were actually received and read. Their exact Library identities, versions and SHA256 are recorded in `receipt-and-decision.json`; originals are retained alongside this decision. Contract SHA256 and the supplied expansion-feedback SHA256 matched. The refiner response SHA256 was computed from the actual received file.

| Source | Original position | Editor decision | Resolution |
| --- | --- | --- | --- |
| Content refiner | Explicit NO OBJECTIONS; no correction requested | Accept the response as given | No mathematical task, proof reread or expansion return |
| Expansion agent | No blocking objection; one optional P2 readability suggestion at physical page 2 | Adopt: separate reading route from history/provenance and working assumptions/open scope | Exact first-edition wording partitioned and reordered under three bold lead-ins; complete history and limitations retained |

The adopted solution is a reader-navigation improvement. It changes no source canonical text or mathematical qualification. Every original guide fragment appears exactly once; `reading-guide-layout.json` records all before/after bytes, fragment order and paragraph joins. The verifier reconstructs the exact layered output and matches the original content through its unchanged source. The historical 381-page edition, actual CP001 source, unrecovered 97 pages, CP58 convention, accepted Study direction, Chinese pause, OPEN formal/publication gates and UNKNOWN LR body coverage all remain explicit.

Only the reader-facing guide and editor-owned cover/footer/PDF identification changed. All 115 derived mathematical body files and complete upstream tree are byte-identical to the fixed first edition. Accepted font/config/style, notes/template entries, proofs, answers and labels are unchanged. All AUX values/folios/destinations, all 291 bookmarks and all links match.

The real second-edition PDF has 367 pages. Incremental build diagnostics are clean. Physical 1–3 were actually inspected from final Poppler renders, plus white-print page 2. The other 365 above-footer page renders/text geometry match the accepted first edition, with page 3 overlap. No fresh whole-volume visual/proof review is claimed. A provisional nearly empty limitation spill was corrected by joining same-layer fragments, retaining all words and global typography.

Step 13 resolves the sole adopted issue. There is no blocking Step 11 feedback left in this round. Handoff is to dot for the Step 14 closure explanation, with unchanged formal/literature limits; this is not EN-STABLE or complete-volume acceptance. No additional independent feedback round, boundary round or proof audit is initiated.

The private-archive/150 MB objective received only a scoped read-only inventory and source recovery check. No GitHub access/submission, cleanup, file movement or permission change occurred; remote identity/visibility/recovery is not claimed verified. The fixed first edition v4 and PDF v0 remain available for rollback.
