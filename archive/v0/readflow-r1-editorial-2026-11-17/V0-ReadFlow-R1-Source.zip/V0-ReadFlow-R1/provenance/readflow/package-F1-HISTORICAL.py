#!/usr/bin/env python3
"""Package this current editable integration tree; do not nest historical ZIPs."""
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parent
excluded={'.build','.review','__pycache__'}
files=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(R.rglob('*')) if p.is_file() and not excluded.intersection(p.relative_to(R).parts) and p!=R/'MANIFEST.json' and not (p.parent==R/'editorial' and (p.name.startswith('read-') and p.suffix=='.txt' or p.name.startswith('narrative-read-') and p.suffix=='.txt' or p.name=='narrative-inventory.json'))]
(R/'MANIFEST.json').write_text(json.dumps({'files':files},indent=2)+'\n')
out=R.parent/(R.name+'-source.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for x in files:z.write(R/x['path'],R.name+'/'+x['path'])
    z.write(R/'MANIFEST.json',R.name+'/MANIFEST.json')
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'manifest_items':len(files)}))
