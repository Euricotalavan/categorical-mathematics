#!/usr/bin/env python3
"""Audit approved F1 over historical CP58, reversible editorial changes and actual PDF."""
from pathlib import Path
import argparse,hashlib,json,re,unicodedata,sys
from editorial_tools import protected_regions,math_regions,sha_text,answer_regions
R=Path(__file__).resolve().parent
U=R/'upstream'
sys.path.insert(0,str(R))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def normalized(s):
 s=re.sub(r'(?<!\\)%[^\n]*','',s)
 for title in ['Projection monicity','Construct the comparison','Monicity of the comparison','Existence','Uniqueness','Construct the two arrows','The round trip on Q','The round trip on R','The monicity conclusion']:
  s=s.replace(r'\ProofStep{'+title+'}','')
 s=re.sub(r'\\Needspace\{\d+\\baselineskip\}','',s)
 s=s.replace(r'\vspace{-\baselineskip}','')
 s=re.sub(r'\\(?:begin|end)\{(?:aligned|gathered|samepage)\}','',s)
 s=re.sub(r'\\\\(?:\[[^\]]*\])?','',s)
 s=re.sub(r'\\(?:qquad|quad|enspace|allowbreak|par|noindent|medskip|leavevmode|newpage)\b|\\[,;!]','',s)
 s=s.replace(r'\text{and}','and')
 s=s.replace(r'\[','').replace(r'\]','').replace('$','').replace('&','')
 return re.sub(r'\s+','',s)
def contrast(a,b):
 def lum(h):
  c=[int(h[i:i+2],16)/255 for i in [0,2,4]];c=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in c]
  return sum(x*y for x,y in zip(c,[.2126,.7152,.0722]))
 la,lb=sorted([lum(a),lum(b)]);return (lb+.05)/(la+.05)
def main():
 p=argparse.ArgumentParser();p.add_argument('--pdf',action='store_true');p.add_argument('--refresh-map',action='store_true');a=p.parse_args()
 manifest=json.loads((U/'MANIFEST.json').read_text())['files'];assert len(manifest)==631
 for n,x in manifest.items():assert (U/n).stat().st_size==x['bytes'] and sha(U/n)==x['SHA256'],n
 historical=json.loads((R/'provenance/baseline-cp58/upstream-MANIFEST.json').read_text())['files'];assert len(historical)==630
 approved=json.loads((R/'provenance/content-f1/editor-handoff/STUDY-MERGE-MAP.json').read_text())['files']
 replacements={x['path'].split('/upstream/',1)[1]:x for x in approved if '/upstream/' in x['path']}
 assert len(replacements)==6
 assert set(manifest)-set(historical)=={k for k,v in replacements.items() if v['before_SHA256'] is None}
 assert not set(historical)-set(manifest)
 for n,x in historical.items():
  if n in replacements:assert x['SHA256']==replacements[n]['before_SHA256'] and sha(U/n)==replacements[n]['after_SHA256']
  else:assert sha(U/n)==x['SHA256']
 rows=json.loads((U/'source/author-volumes/source-view-manifest.json').read_text());alllabels=[]
 for x in rows:
  c=U/'source'/x['canonical'];v=U/'source'/x['view'];assert sha(c)==x['canonical_SHA256'] and sha(v)==x['view_SHA256']
  cl=re.findall(r'\\label\{([^}]+)\}',c.read_text());vl=re.findall(r'\\label\{([^}]+)\}',v.read_text());assert cl==vl;alllabels+=cl
 assert len(rows)==249 and len(alllabels)==len(set(alllabels))==2139
 mapping=json.loads((R/'provenance/source-map.json').read_text());assert len(mapping)==115;changed=[];labels=[]
 base_map={x['logical']:x for x in json.loads((R/'provenance/editorial-base-map.json').read_text())}
 ledger=json.loads((R/'editorial/edits.json').read_text());digests=json.loads((R/'provenance/protected-region-digests.json').read_text())
 answers=json.loads((R/'provenance/answer-region-digests.json').read_text())
 for x in mapping:
  v=U/'source'/x['view'];d=R/x['layout_view'];s,t=v.read_text(),d.read_text()
  base=t
  for edit in reversed([e for e in ledger if e['logical']==x['logical']]):
   assert base.count(edit['after'])==1,edit
   base=base.replace(edit['after'],edit['before'],1)
  assert sha_text(base)==base_map[x['logical']]['sha256'],'Unrecorded editorial mutation: '+x['logical']
  assert normalized(s)==normalized(base),'Base differs from approved F1 author content: '+x['logical']
  assert [sha_text(z) for _,_,z in protected_regions(t)]==digests[x['logical']]
  assert math_regions(base)==math_regions(t),'Math expression changed: '+x['logical']
  assert [sha_text(z) for z in answer_regions(x['logical'],t)]==answers[x['logical']]
  assert answer_regions(x['logical'],base)==answer_regions(x['logical'],t),'Accepted answer changed: '+x['logical']
  assert re.findall(r'\\label\{([^}]+)\}',s)==re.findall(r'\\label\{([^}]+)\}',t)==x['labels'];labels+=x['labels']
  assert re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',s)==re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',t)
  if a.refresh_map:x['layout_view_SHA256']=sha(d)
  else:assert x['layout_view_SHA256']==sha(d)
  if sha(v)!=sha(d):changed.append(x['logical'])
 assert len(labels)==len(set(labels))==1018
 if a.refresh_map:(R/'provenance/source-map.json').write_text(json.dumps(mapping,indent=2)+'\n')
 for entry in json.loads((R/'provenance/template-map.json').read_text()):
  assert sha(R/entry['integration_path'])==entry['sha256']
 guide=json.loads((R/'provenance/reading-guide-map.json').read_text())
 assert sha(R/guide['source'])==guide['source_SHA256'] and sha(R/guide['derived'])==guide['derived_SHA256']
 if guide.get('step12_13_overlay'):
  layer=json.loads((R/guide['step12_13_overlay']).read_text())
  assert sha_text(layer['before'])==layer['before_SHA256'] and sha_text(layer['after'])==layer['after_SHA256']
  assert (R/guide['derived']).read_text()==layer['after']
  assert normalized((R/guide['source']).read_text())==normalized(layer['before'])
  fragments=layer['fragments'];order=layer['original_order'];neworder=[k for x in layer['sections'] for k in x['fragments']]
  assert sorted(order)==sorted(neworder)==sorted(fragments)
  compact=lambda t:re.sub(r'\s+','',t)
  assert compact(layer['before'])==compact(''.join(fragments[k] for k in order))
  def guide_section(x):
   keys=x['fragments'];joins=x['joins'];assert len(joins)==len(keys)-1 and all(z in [' ','\n\n'] for z in joins)
   return r'\textbf{'+x['heading']+'} '+fragments[keys[0]]+''.join(sep+fragments[k] for sep,k in zip(joins,keys[1:]))
  rebuilt='\n\n'.join(guide_section(x) for x in layer['sections'])+'\n'
  assert rebuilt==layer['after'],'Unexpected guide mutation beyond exact fragment layering'
 else:
  assert normalized((R/guide['source']).read_text())==normalized((R/guide['derived']).read_text()),'Reading-guide content changed beyond presentation'
 orig=R.parent/'math-template-v0.2-r1'
 if orig.exists():
  assert (orig/'shared/style.tex').read_bytes()==(R/'layout/shared/style.tex').read_bytes()
  assert (orig/'study/config.tex').read_bytes()==(R/'layout/study/config.tex').read_bytes()
 report={'current_F1_upstream_manifest_items':631,'historical_CP58_manifest_items':630,'approved_upstream_merge_files':6,'canonical_source_view_mappings':249,'unique_labels_all_frozen_volumes':2139,'volume0_selected_sources':115,'volume0_labels':1018,'editorial_base_matches_approved_author_content_after_layout_normalization':True,'editorial_changes_reversible_to_exact_base_hashes':True,'editorial_prose_edits':len(ledger),'protected_regions_byte_unchanged':sum(map(len,digests.values())),'all_ordered_math_expressions_unchanged':True,'normalization':'Reverse the finite explicit English editorial ledger, then check the original accepted layout normalization (spacing/display wrappers and nine listed proof navigation headings). No unknown prose mutation accepted. Labels/ref order, protected statement/example/proof/problem/solution regions and math expressions checked separately.','changed_derived_views':changed,'template_Study_config_and_style_unchanged':True,'contrast':{'paper':'F5F1E7','body':'242A28','secondary':'454D49','body_ratio':contrast('F5F1E7','242A28'),'secondary_ratio':contrast('F5F1E7','454D49')}}
 if a.pdf:
  import fitz
  path=R/'categorical-mathematics-volume-0-f1-study-l2-editorial-candidate.pdf';doc=fitz.open(path);fonts=set();lens=[];pages=[];links={'internal':0,'URI':0,'remote':0};names=doc.resolve_names()
  for i,page in enumerate(doc):
   assert '??' not in page.get_text() and '\ufffd' not in page.get_text();pl=[]
   for bl in page.get_text('dict')['blocks']:
    for line in bl.get('lines',[]):
     spans=line['spans'];bb=line['bbox'];assert bb[0]>=-1 and bb[1]>=-1 and bb[2]<=page.rect.width+1 and bb[3]<=page.rect.height+1,(i+1,bb)
     body=[s for s in spans if 'Schola' in s['font'] and 'Math' not in s['font'] and abs(s['size']-11.5*72/72.27)<.2]
     if body:
      pl.append(line);st=unicodedata.normalize('NFKC',''.join(s['text'] for s in spans));n=sum(len(s['text']) for s in body)
      if len(st)>=30 and n>=.55*len(st):lens.append(len(st))
   for lk in page.get_links():
    if lk['kind'] in [fitz.LINK_GOTO,fitz.LINK_NAMED]:
     assert 0<=lk['page']<len(doc)
     if lk['kind']==fitz.LINK_NAMED:assert lk['nameddest'] in names
     links['internal']+=1
    elif lk['kind']==fitz.LINK_URI:links['URI']+=1
    elif lk['kind']==fitz.LINK_GOTOR:links['remote']+=1
    else:raise AssertionError(lk)
   fonts.update((f[0],f[3]) for f in page.get_fonts(full=True))
   pages.append({'physical_page':i+1,'printed_label':page.get_label(),'body_lines':len(pl),'body_bottom_fraction':round(max([l['bbox'][3] for l in pl] or [0])/page.rect.height,3)})
  for f,n in fonts:assert doc.extract_font(f)[3],n
  assert any('ScholaMath' in n or 'Schola-Math' in n for _,n in fonts),fonts
  auxpath=R/'.build/volume/volume-0-study.aux'
  if not auxpath.exists():auxpath=R/'qa/build-evidence/volume-0-study.aux'
  from aux_labels import labels as read_aux_labels
  actual=read_aux_labels(auxpath)
  expected=json.loads((R/'qa/label-semantics.json').read_text())['entries']
  for entry in expected:
   assert actual[entry['label']]['value']==entry['printed_value'] and actual[entry['label']]['destination']==entry['destination']
  aux=auxpath.read_text();built=set(re.findall(r'\\newlabel\{([^}]+)\}',aux));assert set(labels)<=built
  assert re.search(r'\\newlabel\{eq:proof-test-specification\}\{\{1\}',aux)
  assert not re.search(r'\\newlabel\{eq:[^}]+\}\{\{\d+\.\d+',aux),'Keep CP58 global equation numbering'
  pct=lambda q:sorted(lens)[min(len(lens)-1,round((len(lens)-1)*q))]
  report['PDF']={'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path),'pages':len(doc),'page_mm':[round(doc[0].rect.width*25.4/72,2),round(doc[0].rect.height*25.4/72,2)],'embedded_fonts':sorted(n for _,n in fonts),'all_1018_labels_built':True,'links':links,'bookmarks':len(doc.get_toc()),'prose_line_sample_count':len(lens),'prose_characters_p50':pct(.5),'prose_characters_p90':pct(.9),'prose_characters_max':max(lens),'pages_for_actual_visual_review':pages}
 (R/'qa/source-and-pdf.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='PDF'},indent=2))
 if a.pdf:print(json.dumps({k:v for k,v in report['PDF'].items() if k!='pages_for_actual_visual_review'},indent=2))
if __name__=='__main__':main()
