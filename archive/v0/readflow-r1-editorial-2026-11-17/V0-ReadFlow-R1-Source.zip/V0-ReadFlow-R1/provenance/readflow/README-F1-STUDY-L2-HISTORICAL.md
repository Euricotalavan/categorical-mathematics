# Volume 0 — F1 / Study L2 editorial integration candidate

This is the real 367-page F1 Study L2 second editorial edition under contract v1.0, steps 12–13. Its fixed parent is first-edition source v4 / PDF v0. The first edition’s four consolidated editorial batches are retained; they were not repeated. Only the one existing optional P2 reading-guide suggestion was adopted. All original guide words are retained in three labeled layers; mathematical body files are exact parent bytes. The refiner judged the content sufficient and completed the F1 content-refinement stage. This candidate does not claim EN-STABLE status, final volume acceptance, a common adopted foundation, or exhaustive literature coverage.

## Read and recover

- Read `categorical-mathematics-volume-0-f1-study-l2-editorial-candidate.pdf`.
- `layout/study/volume-0-study.tex` is the current warm Study entry; `print.tex` uses white paper and black text with the same pagination.
- `layout/study/notebook.tex` and `template.tex` retain the accepted blank notes/template entries.
- `upstream/source/` is the complete supplied F1 author tree, including canonical/source-view relations. Edit only the explicit derived layout layer for editorial work; generated views are not new canonical sources.
- `provenance/inputs.json`, `rebase-map.json`, `source-map.json` and `editorial/edits.json` identify all inputs and reversible overlays. `provenance/content-f1/` retains the exact eight-file merge payload, guards, original receipt, and before payload. The preserved original guard script is historical: do not rerun it blindly on this already-merged and edited tree.
- `MANIFEST.json` records every packaged file except itself. The source contains one current raw PDF and no nested historical PDF/ZIP. CP58 and earlier delivered versions remain separately available for rollback; the CP58 upstream manifest is retained as historical evidence.
- `QA.md`, `DESIGN.md`, `qa/` and `editorial/step12-13/DECISION.md` explain this second edition. `editorial/REVIEW-SUMMARY.md` describes the retained first-edition four-batch work; `provenance/first-edition/` marks prior QA as historical. The companion second-edition delivery-verification JSON and step-14 handoff YAML record actual saved IDs, versions, hashes and recovery results; the first-edition verification remains a separate historical record.

## Build

Use Python 3.10+ and a current full XeLaTeX installation (TeX Live or equivalent). Include `fontspec`, Babel English patterns, `unicode-math`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `geometry`, TikZ/`tikz-cd`, `fancyhdr`, `titlesec`, `needspace`, `enumitem`, `caption`, `etoolbox`, `booktabs`, `array`, `xcolor`, `hyperref` and `placeins`. Seven OTF font files and their licenses are included; Latin Modern Mono is supplied by TeX. Source/PDF verification also needs PyMuPDF; optional page rendering uses Poppler.

From this directory:

```sh
python3 verify.py --pdf
python3 build.py
python3 build.py --entry print
python3 build.py --entry notebook
python3 build.py --entry template
python3 render_review.py
python3 package.py
```

`verify.py --pdf` checks the included built PDF and recorded AUX evidence without rebuilding. `build.py` uses incremental XeLaTeX passes, disables shell escape and rejects hard errors/overfull/header diagnostics; it places intermediates under `.build/`. The warm volume output is refreshed only after a successful build. Alternate entry outputs stay under `.build/<entry>/`; only the warm current PDF is included in this package. Fonts and layout remain as accepted; PDF binary hashes may differ across TeX toolchains/timestamps, so examine the resulting layout and references as well as source hashes.

## Remaining scope

`provenance/content-f1/REMAINING-GATES.json` preserves the refiner's named limitations: common formal-framework adoption; genuine large-range/size and choice realizations; book-level acknowledgement of comparisons and finite capabilities; and Lawvere–Rosebrugh body coverage UNKNOWN. The CP58 working empty-category convention is already decided, with required local witnesses retained. It is not reopened here. No other volume or external author/refiner working copy was changed. No GitHub submission was made.
