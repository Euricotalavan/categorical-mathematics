# F1 Study L2 second editorial edition — bounded QA

## Scope and actual inputs

The full approved `book-workflow-v1.md` v1.0, explicit refiner NO OBJECTIONS and the expansion agent's single nonblocking P2 were received/read in full. Exact IDs/versions/hashes and Step 12 decisions are in `editorial/step12-13/receipt-and-decision.json`. Only this existing suggestion is addressed. No new mathematics review, third boundary round, whole-volume rereading or first-edition rebuild/review repetition was initiated.

The frozen parent source v4 was freshly downloaded with SHA256 `8fa1adc1a994d6e81a7294e723bb29390602904eb5f3b9bf9fbed8efe92c94d1`, safely extracted, and all 874 manifest entries verified. A separate successor was made; first edition source v4 / PDF v0 and CP58 remain available for rollback.

## Adopted local change and preservation

The scope guide now has three bold lead-ins: Reading route; Edition and provenance; Working assumptions and open scope. All original guide wording appears exactly once, partitioned/reordered with recorded paragraph joins; `verify.py` reconstructs this exact overlay and checks its original against the unchanged F1 source. No CP001/CP58 history, unrecovered-97-pages warning, non-final status, local witness requirement, OPEN or UNKNOWN limitation was removed. The original canonical guide is unchanged.

All complete upstream source files and all 115 derived V0 body files are byte-identical to the fixed first edition. Accepted fonts, math, global spacing, color, notes and blank template entries are unchanged. The original 31 English edits remain reversible; 902 formal and 51 complete-answer preservation guards still pass. These are preservation checks, not mathematical re-proofs.

## Actual build and visual coverage

The real second-edition PDF is 367 physical pages. Final raw SHA256 is `60bd18d285587e6c28a7e7ad7e9432f3c24168789e3e026736c3a73affc6ad3b`. The incremental volume build converged in two passes; hard/missing-glyph/reference/overfull/header/underfull diagnostics are empty. A provisional 368-page layout spilled two limitation sentences onto a nearly empty page; actual inspection identified it, and joining adjacent same-layer fragments fixed it without changing words or global typography.

Final physical pages 1, 2 and 3 were actually inspected from full-page Poppler 1500px PNGs: cover identification, complete layered guide and following contents. No clipping, collision, missing text or residual spill was observed. All 365 remaining above-footer page rasters and extracted text geometry are exact matches to first-edition PDF pages; page 3 is also actually reviewed, so overlap is one. The comparison includes the entire width above 94% page height, including running headers and body. The edition footer is intentionally different, not claimed byte/pixel-identical. Its text/folio and page bounds were checked on every page and visually on the affected/neighbor pages.

All 1,018 label values, folios and destination identifiers are unchanged; all 291 bookmarks, page labels and page-link targets match the first edition. `qa/pagination-deltas.json` has no label folio or anchor changes. The global equation numbering is retained.

## Actual measurements and alternate entries

Fresh PDF measurements: 9,405 prose-line samples using the exact documented verifier rule; character median 75, 90th percentile 80, maximum 88. Contrast recomputes to body 12.957966 and secondary 7.722961 against F5F1E7. This is a diagnostic rather than a quantified aesthetic or medical effect claim. Babel English left/right minima remain 2/3; supplementary normalized body scanning reports only the unchanged explicit E-action and acted-on compounds. No automatic single-letter English word break was observed.

The current white-print entry was built incrementally and passed diagnostics. All 367 pages match warm output in nonspace glyphs, positions, bounds, font sizes, folios, bookmarks and link semantics. White page 2 was actually viewed. Exact unchanged blank notebook/template entries reuse accepted prior one-page build/review evidence. Only the warm PDF is delivered; no redundant print variant is packaged.

## Delivery, recovery and remaining limits

The current package retains the three original Step 11/contract documents, independent decisions, exact guide overlay, design/English rules, editable XeLaTeX entries/fonts/licenses, source/view maps and current QA. No historical ZIP/PDF is nested. The first-edition manifest and selected QA records are explicitly historical. Final saved source ZIP CRC/manifest/recovery and PDF C2PA byte-versus-page-equivalence results are recorded separately after download in the companion second-edition delivery verification and Step 14 handoff YAML.

No adopted Step 11 issue remains unresolved. The unchanged six formal/publication gates and LR body UNKNOWN remain in `provenance/content-f1/REMAINING-GATES.json`; working empty-category admission stays decided. No EN-STABLE or complete-volume acceptance claim is made. Scoped archive inventory/recovery checks occurred, without GitHub access/submission, deletion, movement of active data, permissions changes or an account-wide quota claim. Dot may now use these actual results for the Step 14 closure explanation; no further approval checkpoint is requested.
