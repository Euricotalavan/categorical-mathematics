#!/usr/bin/env python3
"""Reproduce page images and overview sheets without overwriting delivered QA."""
from pathlib import Path
import argparse,hashlib,json,subprocess
import fitz
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=R/'.review');a=p.parse_args()
out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
pdf=R/'categorical-mathematics-volume-0-f1-study-l2-editorial-candidate.pdf';doc=fitz.open(pdf);digits=len(str(len(doc)))
subprocess.run(['pdftoppm','-scale-to','1250','-png',str(pdf),str(out/'page')],check=True)
rows=[]
for i in range(1,len(doc)+1):
    png=out/f'page-{i:0{digits}d}.png';im=Image.open(png)
    rows.append({'physical_page':i,'printed_label':doc[i-1].get_label(),'png_sha256':hashlib.sha256(png.read_bytes()).hexdigest(),'size':list(im.size)})
for start in range(1,len(doc)+1,4):
    sheet=Image.new('RGB',(960,1370),'#d5d5d5');draw=ImageDraw.Draw(sheet)
    for j,i in enumerate(range(start,min(start+4,len(doc)+1))):
        im=Image.open(out/f'page-{i:0{digits}d}.png');im.thumbnail((454,642));x=12+(j%2)*480;y=6+(j//2)*685;sheet.paste(im,(x,y));draw.text((x,y+647),f'Physical {i} / {doc[i-1].get_label()}',fill='#111111')
    sheet.save(out/f'sheet-{start:03}.png')
(out/'render-manifest.json').write_text(json.dumps({'PDF_SHA256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'pages':rows},indent=2)+'\n')
print(out)
