"""Conservative F1 editorial invariants and narrative inventory helpers."""
import re,hashlib
PROTECTED={'definition','proposition','theorem','lemma','corollary','example','remark','proof','problem','psolution','solution','exercise'}
def protected_regions(s):
    stack=[];regions=[];start=None
    for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',s):
        action,name=m.groups()
        if action=='begin':
            if name in PROTECTED and start is None:start=m.start()
            stack.append(name)
        else:
            assert stack and stack[-1]==name,('Unbalanced environment',name)
            stack.pop()
            if start is not None and not any(x in PROTECTED for x in stack):
                regions.append((start,m.end(),s[start:m.end()]));start=None
    assert not stack and start is None
    return regions
def narrative_only(s):
    for a,b,_ in reversed(protected_regions(s)):s=s[:a]+s[b:]
    s=re.sub(r'(?<!\\)%[^\n]*','',s)
    s=re.sub(r'\\\[.*?\\\]', ' [display] ',s,flags=re.S)
    s=re.sub(r'(?<!\\)\$[^$]*?(?<!\\)\$', ' [math] ',s,flags=re.S)
    return s
def math_regions(s):
    return re.findall(r'\\\[.*?\\\]|\\\(.*?\\\)|(?<!\\)\$[^$]*?(?<!\\)\$',s,flags=re.S)
def answer_regions(logical,s):
    if logical.startswith('solutions/'):return [s]
    if logical=='reading-aids/03-reading-the-constructions.tex':return [s[s.index('\\Needspace{11\\baselineskip}'):]]
    result=[]
    for m in re.finditer(r'\\section\*\{(?:Full solutions|Solutions?)[^}]*\}',s):
        next_section=re.search(r'\\section\*?\{',s[m.end():])
        end=m.end()+next_section.start() if next_section else len(s)
        result.append(s[m.start():end])
    return result
def sha_text(s):return hashlib.sha256(s.encode()).hexdigest()
