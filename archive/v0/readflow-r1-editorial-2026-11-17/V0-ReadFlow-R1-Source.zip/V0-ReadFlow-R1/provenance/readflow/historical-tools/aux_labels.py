"""Read balanced LaTeX AUX groups without treating nested tags as plain braces."""
import re

def group(s, i):
    assert s[i] == '{'
    level, j = 1, i + 1
    while j < len(s):
        if s[j] == '\\':
            j += 2
            continue
        if s[j] == '{': level += 1
        if s[j] == '}':
            level -= 1
            if not level: return s[i + 1:j], j + 1
        j += 1
    raise ValueError('Unbalanced AUX group')

def labels(path):
    s = path.read_text()
    found = {}
    for m in re.finditer(r'\\newlabel(?=\{)', s):
        name, end = group(s, m.end())
        data, end = group(s, end)
        fields, i = [], 0
        while i < len(data):
            if data[i] == '{':
                value, i = group(data, i)
                fields.append(value)
            else: i += 1
        if len(fields) >= 4:
            found[name] = {'value': fields[0], 'page': fields[1], 'destination': fields[3]}
    return found
