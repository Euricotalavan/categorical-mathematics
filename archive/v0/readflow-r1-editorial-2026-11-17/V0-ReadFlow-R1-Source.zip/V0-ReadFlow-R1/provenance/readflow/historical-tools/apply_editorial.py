"""Apply a finite, reviewed prose ledger to derived views only, with preservation guards."""
from pathlib import Path
import argparse,json,datetime
from editorial_tools import protected_regions,math_regions,sha_text,answer_regions
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('request',type=Path);a=p.parse_args();edits=json.loads(a.request.read_text());mapping=json.loads((R/'provenance/source-map.json').read_text());by={x['logical']:x for x in mapping};pending={};records=[]
for e in edits:
 logical=e['logical'];assert not logical.startswith('solutions/'),'Accepted full answer file is immutable'
 path=R/by[logical]['layout_view'];s=pending.get(logical,path.read_text());before,after=e['before'],e['after'];assert s.count(before)==1 and s.count(after)==0,(logical,before)
 start=s.index(before);end=start+len(before)
 assert all(end<=x or start>=y for x,y,_ in protected_regions(s)),('Protected statement/proof/example/exercise/solution',logical)
 if logical=='reading-aids/03-reading-the-constructions.tex':assert end<s.index('\\Needspace{11\\baselineskip}')
 t=s.replace(before,after,1);assert math_regions(s)==math_regions(t)
 assert [z for _,_,z in protected_regions(s)]==[z for _,_,z in protected_regions(t)]
 assert answer_regions(logical,s)==answer_regions(logical,t),'Full answer region changed'
 records.append({**e,'before_file_SHA256':sha_text(s),'after_file_SHA256':sha_text(t),'applied_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});pending[logical]=t
for logical,t in pending.items():(R/by[logical]['layout_view']).write_text(t);by[logical]['layout_view_SHA256']=sha_text(t)
ledger=json.loads((R/'editorial/edits.json').read_text());(R/'editorial/edits.json').write_text(json.dumps(ledger+records,indent=2)+'\n');(R/'provenance/source-map.json').write_text(json.dumps(mapping,indent=2)+'\n');print(json.dumps({'reviewed_edits_applied':len(records),'derived_files_changed':len(pending),'canonical_files_changed':0,'formal_regions_or_math_expressions_changed':0}))
