# Volume 0 F1 — execute one controlled content integration

**Content refinement is complete for the established V0 objectives and retained units. Integrate the supplied final content delta into an independent successor of accepted CP58 Study L2 v1. Do not restart content expansion or request dot approval for each small edit.** The approved Study design remains the design direction. This handoff does not certify the open foundation/reference/publication gates.

## Exact base and completed payload

Base Study source:Library `libfile_fde3_f-dd4adeade70c8191ab0d16754826367e_383d682b1c388191a1961becbec9fb77`,version1,SHA256 `672984065756711281b49fba082d7f61046eda36b73577cda9784976e589f20c`. Its367-page PDF remains a frozen candidate. This delivery creates no F1 PDF.

`editor-handoff/STUDY-MERGE-MAP.json` gives eight exact source/member before/after hashes and `files/` contains all after bytes. Six paths synchronize the unified upstream F1 source/context;two update the reader-facing layout content. The latter are only the existing continuity-guide view and factual scope/review-status text. No theme,box,font,colour,macro,chapter ordering,numbering,exercise or answer is changed. `STUDY-CONTENT-F1.patch` has already been applied with zero fuzz to an isolated sparse successor and all eight after hashes verified. That test did not edit the Study archive.

Extract a fresh copy of the exact base. Run `editor-handoff/merge_study_content.py --root <extraction-parent>` to validate every before hash. Then use `--apply` in that independent successor. The tool validates all guards before writing,preserves overwritten files under `F1-content-rollback`,recognizes already-applied after hashes,and creates a receipt. Repeating an already applied merge preserves that receipt. Use `--rollback` to restore only this recorded merge after verifying its after hashes;later edits cause a guarded stop. If any actual before hash differs,compare that specific file and merge the known textual delta;do not overwrite an entire later version or rerun the old CP58 patch.

## Editorial work to complete autonomously

- Retain the accepted Study L2 direction and all fixed source labels. Incorporate this one complete content delta,including upstream maps/view provenance,then update the editor-owned current-version/provenance records,including CURRENT.json,the current source/package manifests and frontmatter edition wording. Preserve the original CP58 input manifest as provenance rather than testing F1 bytes against an obsolete CP58 identity. Keep the pipeline safeguards;do not suppress a before-hash mismatch or treat the old367-page PDF as the rebuilt result.
- Do the remaining writing and layout passes as consolidated volume work. Preserve the new chapter-route/supply distinctions and every accepted proof/solution. Routine wording decisions need no dot micro-review. A genuinely new mathematical defect should be recorded once with canonical location,before hash and minimal corrected argument.
- Build the integrated current PDF using the existing Study pipeline. Review the affected Chapter0 guide and frontmatter,their continuation pages and contents/links. If pagination moves,update/check page-dependent navigation in the same successor. Maintain the approved warm background,dark text and clear formula contrast. Do not promise that F1 remains367pages before rebuilding.
- Complete the editor's final whole-volume reading/layout acceptance in its normal3–5consolidated passes,with checkpoints for recovery and no per-checkpoint waiting. Deliver the matching editable source and actual current PDF;do not relabel the old candidate as the integrated result.

## Items this handoff preserves as unfinished

The six gates' precise current residuals are in `REMAINING-GATES.json` and the accepted r71 register:formal framework adoption,genuinely larger data/typed-family realizations and the full common-foundation claim are not resolved by the comparison model. LR body remains UNKNOWN,so exhaustive LR/reference completeness is not certified. CP58 empty admission and all local witnesses stay as written. No policy change,third boundary round,new B53,EC expansion or new selection axiom is requested. These limitations remain visible until actually resolved;they do not reopen all accepted V0 proofs or justify another expansion return.

Status after this merge:content-refined source ready for integrated editorial validation;not EN-STABLE or a completed-volume GitHub release. Do not submit an unfinished volume or alter repository visibility/permissions.
