"""Validate/apply the F1 content payload in an independent extracted Study successor."""
from pathlib import Path
import argparse,json,hashlib,shutil
P=argparse.ArgumentParser();P.add_argument('--root',type=Path,required=True,help='Extraction parent containing categorical-mathematics-cp58-study-l2');mode=P.add_mutually_exclusive_group();mode.add_argument('--apply',action='store_true');mode.add_argument('--rollback',action='store_true');a=P.parse_args();H=Path(__file__).resolve().parent;m=json.loads((H/'STUDY-MERGE-MAP.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pending=[]
if a.rollback:
 receipt=a.root/'F1-content-merge-receipt.json';assert receipt.is_file(),'No F1 merge receipt'
 saved=json.loads(receipt.read_text());restore=[]
 for r in saved['files']:
  dest=a.root/r['path'];assert dest.is_file() and sha(dest)==r['after_SHA256'],'Modified post-merge file:'+str(dest)
  old=a.root/'F1-content-rollback'/r['path']
  if r['before_SHA256'] is not None:assert old.is_file() and sha(old)==r['before_SHA256'],'Invalid rollback bytes:'+str(old)
  restore.append((r,dest,old))
 for r,dest,old in restore:
  if r['before_SHA256'] is None:dest.unlink()
  else:shutil.copyfile(old,dest)
 receipt.rename(a.root/'F1-content-merge-receipt.rolled-back.json')
 print(json.dumps(dict(status='ROLLED BACK',files=len(restore),PDF_built=False)));raise SystemExit(0)
for r in m['files']:
 dest=a.root/r['path'];src=H/'files'/r['path'];assert sha(src)==r['after_SHA256'],str(src)
 if dest.exists() and sha(dest)==r['after_SHA256']:continue
 if r['before_SHA256'] is None:assert not dest.exists(),'Unexpected existing destination:'+str(dest)
 else:assert dest.is_file() and sha(dest)==r['before_SHA256'],'Before-hash mismatch:'+str(dest)
 pending.append((r,src,dest))
if a.apply and not pending:
 print(json.dumps(dict(status='ALREADY APPLIED',pending_files=0,existing_rollback_receipt_preserved=True,PDF_built=False)));raise SystemExit(0)
if a.apply:
 assert not (a.root/'F1-content-merge-receipt.json').exists(),'An existing receipt must be preserved;compare this successor first'
 rollback=a.root/'F1-content-rollback'
 for r,src,dest in pending:
  if dest.exists():b=rollback/r['path'];b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(dest,b)
  dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);assert sha(dest)==r['after_SHA256']
 (a.root/'F1-content-merge-receipt.json').write_text(json.dumps(dict(edition='V0-F1',files=[r for r,_,_ in pending],original_Study_archive_modified=False,PDF_built=False),indent=2)+'\n')
print(json.dumps(dict(status='APPLIED' if a.apply else 'VALIDATED ONLY',pending_files=len(pending),base_version=1,styles_or_theme_changes=False,PDF_built=False),indent=2))
