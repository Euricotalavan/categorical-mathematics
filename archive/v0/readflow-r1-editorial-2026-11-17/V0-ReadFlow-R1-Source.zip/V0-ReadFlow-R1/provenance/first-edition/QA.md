# F1 Study L2 editorial candidate — QA

## Baseline and integration

The exact source ZIP, handoff and report hashes were checked before integration; IDs, versions and SHA256 are in `provenance/inputs.json`. The independent successor started from CP58 Study L2 source v1, SHA256 `672984065756711281b49fba082d7f61046eda36b73577cda9784976e589f20c`. That original remains unchanged for rollback. The supplied eight-file guarded merge passed without conflict; the old CP58 patch was not reapplied. Current upstream/source equals the complete supplied F1 source. Its 631-item manifest is checked; the prior 630-item CP58 manifest is retained separately, never relabelled F1.

All 249 canonical/source-view relationships, 2,139 unique frozen labels and 115 V0 selected sources remain. Other-volume source bytes are unchanged. The generated views remain generated views. The F1 guide has one explicit derived whitespace paragraph boundary, recorded independently of the exact payload hashes.

## Editorial and content preservation

Four consolidated batches are recorded in `editorial/batches.json`. Narrative review covered all 13 excerpt parts through Chapters 0–9; 31 exact reversible English/status edits affect 28 derived files. All 902 protected formal regions, 51 whole-answer regions, ordered delimited mathematical expressions, labels and reference order remain unchanged. This is preservation evidence, not a new proof of the mathematics. The F1 refiner's sufficient-content judgment is accepted; no expansion return or third scope boundary round was opened.

## Actual current build

The final F1 PDF is 367 physical pages, including cover, scope, contents and notes. SHA256 of the raw bundled PDF is `05706b566ae37f5101726cc801c44852892cc82239ec80bdeeb7e3376c175a0b`. It is a real F1 build, not the CP58 or CP10 PDF. Incremental XeLaTeX converged in two final passes. Final log checks found zero hard errors, missing glyphs, unresolved/duplicate references, overfull/header diagnostics or underfull diagnostics. All seven used fonts are embedded.

The first provisional build had a 3.9438 pt scope-guide overflow and a duplicated editor-owned status paragraph spilling to a nearly empty page. Both were corrected locally. Final physical pages 2–3 were actually rechecked. Font, column, color, math and accepted global spacing remained unchanged.

All 1,018 V0 label display values are preserved and current destinations resolve. There are 952 internal links, four URI links and 291 bookmarks. Actual pagination comparison records 67 label folio changes and 23 internal anchor serial changes in `qa/pagination-deltas.json`; total pages remain 367. Reference targets and contents were checked after convergence, without treating page count as new content.

## Visual coverage

`qa/render-manifest.json` records all 367 actual final Poppler-rendered pages, hashes and coverage origins. Ninety-two above-footer page rasters changed. All changed pages and immediate neighbors (142 pages) were actually viewed, plus the final notes page: 143 actual current-page inspections. There are 275 exact full-width RGB matches above 94% page height to accepted CP58 pages, with 51 also inspected now. Together these cover all 367 pages. Original full CP58 PNG hashes were checked before comparing. The bottom edition/folio band differs and is explicitly excluded from the carry comparison: this is not full-page hash identity. All final edition/folio texts and bounds were checked separately; footers were also viewed on inspected pages.

Full-page details were additionally inspected on physical 2, 31, 113, 159, 259, 330, 355 and 367. Coverage includes long proofs, consecutive aligned equations, diagrams, worked tests and full solutions, scope wording, contents, cross-page continuations and notes. No unresolved clipping, glyph loss, overlap, diagram-label collision, detached heading or unintentional blank page was observed. Some shorter chapter endings/full-answer pages intentionally retain white space; the unchanged accepted layout is preserved.

The supplementary English scan retains Babel English left/right minima 2/3. Running-furniture transitions were excluded and ligatures normalized before fragment counting. Remaining short-fragment hits are explicit `$E$-action` and `acted-on` compounds, not automatically split single-letter English word fragments. Raw false hits entering the F1 footer remain classified in `qa/hyphenation-scan.json`. This scan supplements actual review rather than replacing it.

## Measurements and alternate entries

Current PDF metrics were recomputed: 9,403 sampled prose lines, median 75 characters, 90th percentile 80, maximum 88 under the documented rule. Body and secondary contrast ratios recompute to 12.957966 and 7.722961 against paper F5F1E7. Full parameters and actual glyph/baseline samples are in DESIGN.md and `qa/reading-measurements.json`. These are readability diagnostics, not medical effects or universal comfort claims.

The white print entry was incrementally built and passed the same diagnostics. All 367 pages match the warm version in text, nonspace glyph geometry, folios, bookmarks and link semantics. White physical page 2 was actually inspected. Exact accepted blank template/notebook entries, shared style/config and fonts were verified unchanged, reusing their prior one-page build/review evidence without redundant rebuilding. No extra print PDF is delivered.

## Recovery and remaining limits

The package includes the design/English editorial rules, editable XeLaTeX template, blank notes, included fonts/licenses, canonical/view maps, eight-file payload/rollback, finite English ledger, current PDF, build scripts and QA. `verify.py --pdf` supports restored-source verification without rebuilding; source ZIP manifest/CRC, PDF equivalence and persistent redownload checks are recorded in the companion delivery-verification JSON after saving.

This is an editorial integration candidate. Common formal framework and genuine large-range/size/choice realization gates remain as named in `provenance/content-f1/REMAINING-GATES.json`; Lawvere–Rosebrugh body coverage is UNKNOWN. The working empty-category convention has already been adopted; only the named larger-scope/common-book-model acknowledgement issues remain. No EN-STABLE, exhaustive-reference or complete-volume acceptance claim is made. Author/refiner originals, later upstream, other volumes and GitHub remain untouched.
