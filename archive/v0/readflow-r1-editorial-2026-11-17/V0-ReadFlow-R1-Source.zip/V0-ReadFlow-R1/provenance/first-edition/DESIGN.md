# Retained Study L2 design — F1

The user accepted Study L2. This edition reuses the exact v0.2-r1 Study style, configuration and font hashes recorded in `provenance/template-map.json`; it introduces no redesign. F1 content integration and finite English overlays are separate from canonical author text.

| Parameter | Retained value |
| --- | --- |
| Page / text width | A4 / 147 mm |
| Margins L/R/T/B | 27 / 36 / 23 / 23 mm |
| Body / baseline | 11.5 / 15.8 TeX pt |
| Body / math / structural face | TeX Gyre Schola / Schola Math / Heros |
| Paragraph indent / separation | 0 / 4 pt with accepted glue |
| Display skip | 7 pt plus 2 pt minus 2 pt |
| Paper / body / secondary / accent | F5F1E7 / 242A28 / 454D49 / 2D5660 |
| Recomputed body / secondary sRGB contrast | 12.957966 / 7.722961 |
| English language / hyphen minima | Babel English / left 2, right 3 |
| Proof / exercise conventions | pf; problem; psolution |

Existing aligned displays, bounded statement keep policies, nine proof-stage navigation headings, counters and notes remain. Formal statements, proofs, worked examples and complete answers retain their post-merge bytes; long proofs remain breakable. No global tracking, font reduction or added blank-space padding was used. Page count is a build result, not an amount of new mathematics.

Editorial typography corrections were confined to the new scope frontmatter: one natural paragraph boundary before the literature limitation, shorter editor-owned integration status, and removal of a duplicated editor-owned scope paragraph. The full supplied F1 guide wording remains; the author's corresponding canonical file is exact F1. This fixes the actual provisional overfull line and near-empty spill page without redesign.

Fresh measurements in `qa/reading-measurements.json` use the actual final 367-page PDF: 9,403 sampled prose lines; median 75 characters, 90th percentile 80, maximum 88 under the documented sampling rule. These are diagnostics, not quantified aesthetic superiority. Actual body PDF font size is about 11.457 PostScript points (11.5 TeX points); baseline spacing is recorded from current glyph geometry.

White printing is retained by `print.tex`; all 367 print pages have the same text, nonspace glyph geometry, folios, bookmarks and link targets as the warm version. The guide page was actually inspected on white paper. Warm color, contrast and spacing are measurable readability choices; they imply neither a medical eye-protection effect nor universal screen comfort.

Prior design-method attribution and font licenses remain under `design/` and `licenses/`. Third-party website analyses are not official brand standards; no website hero, card or CTA pattern is transplanted.
