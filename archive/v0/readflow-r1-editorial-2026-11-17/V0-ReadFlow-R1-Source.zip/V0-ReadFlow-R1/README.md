# V0 / F1 ReadFlow R1 — isolated whole-volume editorial trial

This is **not** a new mathematics volume, an EN-STABLE book, an adopted common
Study template, or a mathematical acceptance certificate. It is a *separate*
reading/typography successor to the published 2026-11-13 V0 F1 Study L2
second-editorial candidate. Original material was neither overwritten nor
pushed to GitHub. The previous source manifests and audit records are retained
as historical evidence in this package. All unresolved mathematical/publication
gates remain unresolved.

## Exact baseline identity

- Volume: V0, *Language and given constructions*, Chapters 0–9.
- Git archive: `archive/v0/f1-study-l2-second-editorial-2026-11-13/`;
  commit `2fd60dfecd1eb970e6b62a6fbea66e3bb05fa7ae`.
- Original source Library version 5, ZIP SHA256
  `0a0d81675a5c494c14480136321fe53bb9a74e985c7b6b19f9cbd84c25680dfe`.
- Original PDF Library version 1, 367 pages, SHA256
  `d4d7996be987225b6d90266a905a60e910d747254f729d97df8f3f4019b6f459`.
- Readability research `Math_Readability_Study_v1.html`, SHA256
  `6fabd79bb71279356f363587ebb70767771200e53f1e2d2740dab0c0679fb142`.
- Research source ZIP SHA256
  `e288a7831ec7a6b101e560a2c09b5c733f29a23ad145baa754998d88ab7b50fb`.
- Scheme: A/v3 editor-equivalent 08–09, with the research's reader-function
  conventions. **No switch to B is inferred.** The final mathematical review
  remains with the thickening reviewer, not the editor.

## What is and is not changed

- **Frozen math:** `layout/views/v0/` and `upstream/source/` mathematical
  `.tex`, `.tikz`, `.sty`, `.bib`, `.md` assets. Their reference SHA256 manifest
  is `qa/READFLOW-FROZEN-MATH.json`; the compiler uses the exact same 668
  matching items. Definitions, theorem statements, proofs, worked examples,
  exercises, and solutions were not rewritten or reordered.
- **Changed:** `layout/study/config.tex`, `layout/study/readflow-layout.tex`,
  `layout/shared/readflow-base.tex`, edition metadata, and the historically
  outdated V3/V4 series labels in `layout/study/reading-guide.tex`.
- **Intentionally preserved:** original `layout/shared/style.tex`, earlier
  `provenance/`, first/second editorial decisions, previous content limitations,
  and every math/body file. No cross-volume content was reactivated.
- The original released PDF's pagination is NOT preserved. The book is
  reflowed from the original 367-page A4 format to the S2.1-inspired
  190 × 260 mm reader format. Any new page count is a *layout metric*.

## Source of the visual rules

This is an isolated implementation of architecture II (small functional layer,
fixed profile, regression tests) from the 2026-11-17 readability report. It
inherits the S2.1 *reading relationships*, not a claim that the new volume
achieves the previous subjective 93/100 rating.

- Main text 10.4pt / 16pt leading; TeXGyrePagellaX, Noto Sans, Asana Math
  with STIXTwoMath fallback for only two mathematical glyphs missing in Asana.
- Main paper 190×260mm, left/right nominal 27mm, top 23mm, bottom 21mm. The 1mm bottom
  margin increase in text area is a **documented V0-specific fitting exception**
  to the S2.1 22mm nominal bottom margin; it avoids observed 2pt tall pages.
- An explicit very small right-padding adjustment for exercises, and a 0.5pt text-width fitting buffer, are also
  recorded in `layout/study/readflow-layout.tex`.
- Definitions are breakable, teal-backed and marked; results are quieter;
  examples have a narrow gold rule; long `pf` remains breakable without a
  large unbreakable box. Long content can show a `(continued)` heading.
- `\ReadFlowKeyIdea{topic}{key point}{reason}` is provided for **explicitly
  authored short remarks** and keeps the two parts together. It is not
  automatically grafted onto math or currently unmarked V0 prose.
- The baseline `\ProofStep` and theorem/label numbering are preserved.
- If structural or mathematical changes become necessary for better reading,
  they must be referred to the content/refinement owners rather than edited
  silently in this layout branch.

## Build from source (without bundled fonts)

All source and code are present, but **no font files are distributed**. Install
TeX Live XeLaTeX plus `mathtools`, `unicode-math`, `tcolorbox`, `needspace`,
`tikz-cd`, `bookmark`, `fancyhdr`, `titlesec`, `geometry`, `fontspec`, and
other packages listed in the retained baseline `README` under
`provenance/readflow/`. The required *locally installed* font faces are:

1. TeXGyrePagellaX Regular/Italic/Bold/BoldItalic (TeX Live `newpx`)
2. Noto Sans
3. DejaVu Sans Mono
4. Asana Math
5. STIXTwoMath Regular (two-symbol fallback)

From this directory, run:

```sh
python3 verify.py                 # package/source provenance checks
python3 build.py                 # XeLaTeX whole-volume reading PDF
python3 qa/readflow_qa.py        # math-source fingerprints + PDF engineering
python3 build.py --entry print   # optional monochrome profile
```

Compiler outputs go under `.build/`, with delivered snapshots copied to the root under the `V0-ReadFlow-R1` names. The **source/PDF hashes and runtime
verification** are in `qa/READFLOW-V0-QA.json` and top-level delivery manifest.
The `print` profile was independently built (3 converged XeLaTeX passes) and
all 464 pages have matching extracted text with the reading profile. Its
engineering scan reports no detected near-white text, outside-page spans,
missing glyphs, missing chapter anchors or broken local links.

**Distribution note:** Font files from the frozen original ZIP are not
included in the R1 distribution. Historical SHA manifests under
`provenance/readflow/` describe *the original complete source* and are
for historical reference only; use root `MANIFEST.json` and `verify.py` for
this independently packaged R1. The original body/diagrams remain
fingerprinted by `qa/READFLOW-FROZEN-MATH.json`.

The 20 downsampled contact sheets were used as an editing aid but are
excluded from this editable-source ZIP to avoid redundant image files.
Their index remains in `qa/READFLOW-RENDER-INDEX.json`. The full 464-page
PDF still needs professional continuous-reading acceptance beyond the
selected contact sheets inspected during this R1 editorial round.

The separate end-user PDF may receive platform-added content credentials
and thus have a different binary hash from the raw, reproducible compiler
PDF inside this ZIP; compare its extracted text, navigation and render,
not the two different PDF byte streams as if unchanged.


## Scope of validation and OPEN items

Content identical to a fixed source ≠ source is mathematically correct. This
R1 has NOT performed a new full literature item audit, theorem-by-theorem proof
review, or final thickening-stage independent review. OPEN items from F1,
including formal framework/size/choice and Lawvere–Rosebrugh coverage UNKNOWN,
are not cleared. The full revised reader version still needs a separate strict
math whole-volume final review after editorial checks.

No claim is made for cross-machine or paper-print fidelity, screen-reader / UA
compliance, user comprehension, or a universal default font size. Optional
non-readability source files are preserved only to support traceability.
