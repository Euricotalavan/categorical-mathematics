#!/usr/bin/env python3
"""Render every page to image contact sheets for human review; no automatic aesthetic score."""
from pathlib import Path
import fitz,json
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
PDF=ROOT/'V0-ReadFlow-R1.pdf'
OUT=ROOT/'qa/visual-contact'

def main():
    OUT.mkdir(exist_ok=True)
    d=fitz.open(PDF)
    allpages=[]
    # 24 page montage, 4 x 6, display at roughly 45% for catching gross defects.
    for start in range(0,len(d),24):
        sheet=Image.new('RGB',(1860,4020),'#d9dddd')
        pen=ImageDraw.Draw(sheet)
        for sub in range(start,min(start+24,len(d))):
            p=d[sub]
            pix=p.get_pixmap(matrix=fitz.Matrix(.72,.72),alpha=False)
            im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
            im.thumbnail((451,620))
            col=(sub-start)%4;row=(sub-start)//4
            x=col*465+(465-im.width)//2;y=row*670+35
            sheet.paste(im,(x,y));pen.text((col*465+12,row*670+12),f'V0 / ReadFlow R1 / physical p.{sub+1}',fill='#223')
            # 2 pixel page edge has no black rule; any unexpected dark pixels indicate near-page clip.
            band=im.crop((0,0,min(4,im.width),im.height))
            allpages.append({'physical_page':sub+1,'width':p.rect.width,'height':p.rect.height,'render_size':[pix.width,pix.height]})
        name=OUT/f'contact-{start//24+1:02d}.jpg'
        sheet.save(name,quality=82,optimize=True)
    rec={'pdf_sha256':__import__('hashlib').sha256(PDF.read_bytes()).hexdigest(),'page_count':len(d),'page_index':allpages,'contact_sheets':sorted(x.name for x in OUT.glob('contact-*.jpg')),'render_engine':'PyMuPDF fitz '+fitz.VersionBind,'judgment':'automated render completed; sheets must be visually inspected to make any human-visual claim'}
    (ROOT/'qa/READFLOW-RENDER-INDEX.json').write_text(json.dumps(rec,indent=2))
    print(f"{len(d)} pages, {len(rec['contact_sheets'])} contact sheets at {OUT}")
if __name__=='__main__':main()
