#!/usr/bin/env python3
"""Source preservation and rendered-PDF engineering tests; NOT math endorsement.
This runner is also useful for clean-room PDF regeneration.
"""
from pathlib import Path
import sys,json,re,hashlib,collections
import fitz

ROOT=Path(__file__).resolve().parents[1]
PDF=ROOT/'V0-ReadFlow-R1.pdf'
INDEX=ROOT/'qa/READFLOW-FROZEN-MATH.json'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def source_integrity():
    manifest=json.loads(INDEX.read_text())
    failures=[]
    for name, h in manifest['items'].items():
        p=ROOT/name
        if not p.exists():failures.append({'path':name,'issue':'missing'})
        elif sha(p)!=h:failures.append({'path':name,'issue':'changed','expected':h,'actual':sha(p)})
    return {'checked_items':len(manifest['items']),'failures':failures,'all_unchanged':not failures}


def is_light(color):
    r=(color>>16)&255;g=(color>>8)&255;b=color&255
    return min(r,g,b)>=232


def scan_pdf(pdf):
    doc=fitz.open(pdf)
    fonts={}; anomalies=[]; pages=[];links=0; text_parts=[]
    for ix,page in enumerate(doc):
        pg=ix+1
        page_text=page.get_text()
        text_parts.append(page_text)
        bbox=page.rect
        light=[];out=[];tiny=[];spans=0
        for block in page.get_text('dict').get('blocks',[]):
            if 'lines' not in block:continue
            for line in block['lines']:
                for s in line['spans']:
                    txt=s['text'].strip()
                    if not txt:continue
                    spans+=1
                    r=fitz.Rect(s['bbox'])
                    if is_light(s['color']): light.append({'text':txt[:55],'rgb':format(s['color'],'06x')})
                    if not fitz.Rect(bbox.x0-2,bbox.y0-2,bbox.x1+2,bbox.y1+2).contains(r): out.append({'text':txt[:55],'bbox':[round(x,1) for x in s['bbox']]})
                    if s['size']<5.0: tiny.append({'text':txt[:55],'pt':round(s['size'],2)})
        broken=[]
        for l in page.get_links():
            links+=1
            if l['kind']==fitz.LINK_GOTO and not 0 <= l.get('page',-1) < len(doc):broken.append(l)
        for f in page.get_fonts():
            if f[0] not in fonts:
                try:
                    info=doc.extract_font(f[0]); emb=len(info[3]) if info[3] else 0
                except Exception:emb=-1
                fonts[f[0]]={'font':f[3],'embedded_bytes':emb,'type':f[2]}
        record={'page':pg,'characters':len(page_text),'spans':spans,'light_text':light[:20],'out_of_bounds':out[:20],'tiny_text':tiny[:20],'broken_links':len(broken)}
        pages.append(record)
        if any([light,out,tiny,broken]):anomalies.append(record)
    toc=doc.get_toc()
    chapters=[{'level':lev,'title':name,'page':pg} for lev,name,pg in toc if lev==1 and re.match(r'^(?:Chapter\s+)?(?:[0-9]+\s+)?(?:Proof language|Functions and|Inverses and|Terminal objects|Models, functors|Monomorphisms|Pullbacks|Representatives|Changing the target|Why existence)',name,re.I)]
    text='\n'.join(text_parts)
    # This is a navigation check; it does not prove the absence of uncaptured off-page expressions.
    anchors=['Proof language and external finite expressions','Functions and the axioms of a category','Inverses and calculations with arrows','Terminal objects and products','Models, functors, and categorical constructions','Monomorphisms and equalizers','Pullbacks and pasting','Representatives and given intersections','Changing the target of given constructions','Why existence needs assumptions']
    anchors_found=[a for a in anchors if a.lower() in text.lower()]
    return {'path':str(pdf),'bytes':pdf.stat().st_size,'sha256':sha(pdf),'pages':len(doc),
            'toc_entries':len(toc),'toc_chapters':chapters,'anchored_chapter_headings':len(anchors_found),
            'missing_chapter_anchors':[a for a in anchors if a not in anchors_found],
            'internal_and_external_links':links,'text_chars':len(text),
            'light_text_pages':[p['page'] for p in pages if p['light_text']],
            'out_of_bounds_pages':[p['page'] for p in pages if p['out_of_bounds']],
            'tiny_text_pages':[p['page'] for p in pages if p['tiny_text']],
            'broken_link_pages':[p['page'] for p in pages if p['broken_links']],
            'fonts':list(fonts.values()),'anomalies':anomalies,'pages_detail':pages,
            'under_350_character_pages':[p['page'] for p in pages if p['characters']<350],
            'continued_word_page_count':sum('continued' in t.lower() for t in text_parts)}


def inspect_log():
    p=ROOT/'.build/volume/volume-0-study.log'
    if not p.exists():return {'status':'missing'}
    s=p.read_text(errors='replace')
    return {'missing_chars':re.findall(r'Missing character:.*',s),
            'overfull':re.findall(r'Overfull \\[hv]box.*',s),
            'underfull':re.findall(r'Underfull \\[hv]box.*',s)[:100],
            'undefined_refs':re.findall(r'LaTeX Warning: Reference.*',s),
            'other_warning_count':len(re.findall('Warning:',s)),
            'length_bytes':p.stat().st_size}


def run():
    data={'scope':'V0 ReadFlow R1 isolated full-volume editorial candidate; source preservation and PDF engineering checks, NOT math-semantic final exam',
          'source':source_integrity(),
          'pdf':scan_pdf(PDF),
          'latex':inspect_log()}
    hard=[not data['source']['all_unchanged'], bool(data['pdf']['missing_chapter_anchors']),bool(data['pdf']['light_text_pages']),bool(data['pdf']['out_of_bounds_pages']),bool(data['pdf']['broken_link_pages']),bool(data['latex'].get('missing_chars')),bool(data['latex'].get('undefined_refs'))]
    data['engineering_pass']=not any(hard)
    (ROOT/'qa/READFLOW-V0-QA.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    minimal={k:data['pdf'][k] for k in ['pages','toc_entries','anchored_chapter_headings','missing_chapter_anchors','light_text_pages','out_of_bounds_pages','tiny_text_pages','broken_link_pages','under_350_character_pages']}
    print(json.dumps({'sources_checked':data['source']['checked_items'],'source_ok':data['source']['all_unchanged'],'pdf':minimal,'overfull':data['latex'].get('overfull'),'engineering_pass':data['engineering_pass']},ensure_ascii=False,indent=2))
    return 0 if data['engineering_pass'] else 1

if __name__=='__main__':sys.exit(run())
