# ReadFlow R1 — editing decisions and exceptions

This is an **editorial-only** full-V0 candidate, not a formal math review.

| ID | Location | Original condition | R1 action | Math impact | Retest |
|---|---|---|---|---|---|
| RF-001 | `layout/study/config.tex` | A4 / 11.5pt Schola, 15.8pt leading, broad margins | 190×260mm profile; PagellaX 10.4/16, S2.1-inspired spacing/colors | None intended, full PDF reflow | Full rebuild + all pages |
| RF-002 | `layout/shared/readflow-base.tex` | Original font file paths bundled in manuscript | External installed font names, no font files distributed | None; glyph coverage changes must be checked | Font/glyph audit |
| RF-003 | `layout/study/readflow-layout.tex` | All statement roles typographically similar | Teal definitions; quiet results; gold examples; breakable long blocks | Numbering/labels unchanged | Label/contents comparison |
| RF-004 | same | No explicit same-page functional key/reason unit | Introduce opt-in `ReadFlowKeyIdea`, keep Key + Why together | Not applied automatically to original content | Independent adjacency fixture |
| RF-005 | same | Long statements may lose identity after page break | Add `(continued)` headers for theorem-like blocks; long proofs remain unboxed | No content rewrite | Multi-page definition fixture |
| RF-006 | same | 13.5pt very long section titles could overrun | Ragged-right multi-line section titles; reserve 7 lines for next content | No source text rewrite | Overfull log + page visual audit |
| RF-007 | same | Text may unexpectedly become near-white after boxes | Explicit body ink in boxes; PDF span color diagnostic | No change | Light text QA |
| RF-008 | same | Asana Math misses U+25A1 and U+0338 | STIXTwoMath *only* for those two glyphs | Glyph fallback only; mathematical symbols preserved | Missing-glyph warnings |
| RF-009 | `config.tex` | S2.1 baseline bottom margin 22mm | V0 adjustment bottom 21mm to avoid 2pt vertical overrun | No change | Strict overfull vbox log |
| RF-010 | `layout/study/reading-guide.tex` | Outdated text calls V3 Linear Algebra I and V4 Analysis I | Correct the series map to V3 new LA and V4 categorical continuation | Editorial metadata only | Exact diff + Git mapping |
| RF-012 | `layout/study/readflow-layout.tex` | A line in the unboxed solutions section exceeds width by 0.146pt at full 136mm text area | Add 0.5pt printable line-width buffer, much less than 0.2mm, retaining the same body size and no omitted text | No semantic change | No overfull \\hbox + render |
| RF-011 | study frontmatter/integration | Identifies 2026-11-13 second editorial release | Label a separate 2026-11-17 ReadFlow R1 editorial trial | Edition description only | PDF cover, footer and metadata |

No previous mathematical defect is declared repaired by any row above.

## Interface to v3

- Actual scheme: A/v3, editorial role (08–09 equivalent) in a separately
  authorized successor. The user has not selected B for V0.
- The ReadFlow architecture II describes presentation technology, not the B
  mathematical production workflow.
- The only mathematical final decision remains with the thickening reviewer
  under v3 10–12. If reviewer returns a math/content issue, send to refinement;
  a structural/scope issue goes to expansion; presentation returns to editor;
  all changes return to thickening for recheck.
- Retained F1 publication OPEN issues must not be erased by this layout effort.

## Honest technical limitations

- Very small overfull warnings should be resolved or recorded as explicit
  exceptions, not hidden by PDF cropping or deleting source.
- Rendered page/floating diagram adjacencies require actual visual audit. The
  tools cannot prove a diagram conveys the intended mathematics.
- A multi-page proof's *exact theorem name* is not automatically inserted
  as a running header. More specific context cues would require an authored
  semantic annotation and are not guessed from the last counter.

## Regression RF-013: white continuation header

Full-volume QA found 53 continuation title pages with RGB FFFFFF on a light background. This was a *real* readability bug even though PDF extraction and XeLaTeX compilation succeeded. The thin style has been amended with explicit `coltitle=bodyink`, `colbacktitle=rf-paper`, and a readable title font. The next PDF must be rescanned across every page; no source/statement text may be changed to conceal the bug.
