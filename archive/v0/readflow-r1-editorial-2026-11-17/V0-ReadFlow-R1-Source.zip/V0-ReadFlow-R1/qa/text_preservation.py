#!/usr/bin/env python3
"""Natural language token preservation in rendered PDF; supporting evidence only.
The first (stronger) evidence is byte-identical source; token comparison tests
potential clipping/render failures, but does not certify proofs or math meaning.
"""
from pathlib import Path
import fitz,re,json,collections,sys,hashlib
ROOT=Path(__file__).resolve().parents[1]
BASELINE=Path('/mnt/data/v0_baseline/categorical-mathematics-volume-0-f1-study-l2-editorial-candidate.pdf')
CURRENT=ROOT/'V0-ReadFlow-R1.pdf'

def normalize(p):
    d=fitz.open(p)
    s='\n'.join(x.get_text() for x in d)
    # Avoid math font encoding and page-header differences; use visible English words.
    tokens=re.findall(r"[A-Za-z][A-Za-z\-']{3,}",s)
    return d,s,collections.Counter(t.lower() for t in tokens)

def main():
    if not BASELINE.is_file():
        print('The optional local original reference is not available. Source hash verifier remains primary.');return 2
    a,sa,ca=normalize(BASELINE);b,sb,cb=normalize(CURRENT)
    inter=ca & cb
    total=sum(ca.values());matching=sum(inter.values())
    rec={'method':'PDF English word-token multiset match; supplemental clipping alarm, not proof semantics or ordered text certification',
        'baseline_pdf_sha256':hashlib.sha256(BASELINE.read_bytes()).hexdigest(),
        'candidate_pdf_sha256':hashlib.sha256(CURRENT.read_bytes()).hexdigest(),
        'baseline_pdf_pages':len(a),'candidate_pdf_pages':len(b),
        'original_text_characters':len(sa),'candidate_text_characters':len(sb),
        'original_tokens':total,'candidate_tokens':sum(cb.values()),
        'matched_tokens':matching,
        'matched_fraction':matching/total,
        'unmatched_top':(ca-cb).most_common(100),
        'limitation':'New page headers and continuation labels add tokens. Math font differences, hyphenation, text extraction order, and corrected editorial guide may create differences. A high ratio is not evidence of mathematical correctness.'}
    (ROOT/'qa/READFLOW-TEXT-PRESERVATION.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:rec[k] for k in ['baseline_pdf_pages','candidate_pdf_pages','original_tokens','candidate_tokens','matched_tokens','matched_fraction','unmatched_top']},ensure_ascii=False,indent=2)[:10000])
    return 0 if rec['matched_fraction']>=.97 else 1

if __name__=='__main__':sys.exit(main())
