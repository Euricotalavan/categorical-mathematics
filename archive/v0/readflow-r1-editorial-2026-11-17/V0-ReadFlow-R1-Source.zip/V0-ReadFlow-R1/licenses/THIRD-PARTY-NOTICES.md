# Integration subset note

This integration includes seven unmodified Schola, Schola Math and Heros fonts
from the accepted Study source. The following retained template notice also
describes the separate Book font family, which is not bundled here.
No official brand endorsement or brand standard is claimed.

# Attribution and bundled font notices

The specification method continues the v0.1 adaptation of
https://github.com/VoltAgent/awesome-design-md
at revision fcc70284932276d085f01ef9f83edde90b1258cb.
The reviewed README, contribution guide and IBM/Notion analyses are independent
third-party website analyses, not official brand standards. No brand palette,
proprietary font, card, hero, CTA or decorative UI component is copied here.
The upstream full MIT notice is retained in VoltAgent-MIT-LICENSE.txt. It applies
to upstream material, not to the user's mathematical manuscript or the entire book.

This package includes 12 unmodified TeX Gyre OpenType fonts: Pagella and Schola
regular/bold/italic/bolditalic, their two matched math fonts, and Heros
regular/bold for structural typography. Original family names, font contents and
embedded notices are retained. Their source URLs, archive/font hashes and
version information are recorded under provenance/.

Source packages and license classification:
https://ctan.org/pkg/tex-gyre
https://ctan.org/pkg/tex-gyre-math

The GUST Font License is included with the retrieved font documentation.
The included README and MANIFEST files retain the original math-font authorship
and source information. Text-font package README and the original GUST notice
are also included. The Latin Modern Mono dependency is supplied by TeX Live,
not redistributed here. Retain the relevant font licenses and notices when
redistributing the source package. No font binary has been renamed or modified.

The mathematical text is the user's supplied manuscript/sample material. No new
public redistribution license or ownership claim is added for that content.
The v0.1 source identity is pinned in provenance/baseline.json.

Contrast-definition reference used for calculation only:
https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html
No W3C endorsement, complete accessibility certification or medical benefit is
claimed. No third-party website text or image is reproduced as book decoration.
