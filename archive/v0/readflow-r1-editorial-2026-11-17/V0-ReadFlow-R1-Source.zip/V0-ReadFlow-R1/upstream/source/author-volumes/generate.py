#!/usr/bin/env python3
"""Generate the live author reading entries from verified canonical selections.

Never regenerates a historical entry and never edits canonical prose.
"""
from pathlib import Path
import hashlib, importlib.util, json, re
R=Path(__file__).resolve().parents[1]
H=R/'author-volumes'
def sha(b): return hashlib.sha256(b).hexdigest()
def main():
    spec=importlib.util.spec_from_file_location('preserved_presentation', R/'reading-v15/generate-reading.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    active=json.loads((H/'active.json').read_text()); report=[]
    for v in active['volumes']:
        n=v['volume']; chapters=json.loads((R/v['chapters']).read_text())
        selected=json.loads((R/v['selected_sources']).read_text())
        byname={x['logical']:x for x in selected}
        assert len(byname)==len(selected)
        lines=[r'\documentclass[11pt,oneside,openany]{book}',r'\usepackage{xr-hyper}',
            r'\input{config}',r'\input{author-volumes/cross-volume-links}',
            r'\newtheorem{corollary}[definition]{Corollary}',
            rf'\input{{author-volumes/v{n}/layout}}',r'\hypersetup{filecolor=ink}',
            rf'\hypersetup{{pdftitle={{Categorical Mathematics - Volume {n} - Author draft}}}}']
        if n>=2: lines.append(r'\providecommand{\ev}{\operatorname{ev}}')
        for p in active['volumes']:
            if p['volume']<n: lines.append(rf'\externaldocument{{author-volumes/build/volume-{p["volume"]}}}[volume-{p["volume"]}.pdf]')
        lines.extend([r'\begin{document}',r'\frontmatter',r'\begin{titlepage}\centering\vspace*{28mm}',
            r'{\Huge\sffamily Categorical Mathematics\par}\bigskip',
            rf'{{\LARGE Volume {n}\par}}\medskip',rf'{{\Large {v["title"]}\par}}\vfill',
            r'{\large English author reading draft\par}\medskip',
            r'12 November 2026\par Draft; independent review of additions pending.\par',
            r'\end{titlepage}',r'\chapter*{Scope and reading order}'])
        lines.append(r'\input{author-volumes/reading-guide}')
        lines += [r'\begingroup\small\tableofcontents\endgroup',r'\mainmatter',rf'\setcounter{{chapter}}{{{v["first_chapter"]-1}}}']
        used=[]
        for c in chapters:
            lines.append(r'\chapter{'+c['title']+'}')
            for f in c['files']:
                s=byname[f]; assert s['chapter']==c['number'] and s['volume']==n
                b=(R/s['selected_source']).read_bytes(); assert sha(b)==s['selected_SHA256'],s['selected_source']
                raw=b.decode(); view=mod.presentation(raw,f)
                if s.get('lower_sections_once',False): view=s.get('presentation_prefix','')+view.replace(r'\section{',r'\subsection{')
                else: assert not s.get('presentation_prefix','')
                assert re.findall(r'\\label\{([^}]+)\}',raw)==re.findall(r'\\label\{([^}]+)\}',view)
                dest=H/'views'/f'v{n}'/f; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(view)
                lines.append(r'\input{'+dest.relative_to(R).with_suffix('').as_posix()+'}')
                report.append({'volume':n,'chapter':c['number'],'logical':f,'canonical':s['selected_source'],
                    'canonical_SHA256':sha(b),'view':dest.relative_to(R).as_posix(),'view_SHA256':sha(view.encode()),
                    'baseline_view_match':sha(view.encode())==s.get('tested_view_SHA256') if 'tested_view_SHA256' in s else None})
                used.append(f)
        assert len(used)==len(byname) and set(used)==set(byname)
        lines.append(r'\end{document}')
        (R/v['entry']).write_text('\n'.join(lines)+'\n')
    (H/'source-view-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'selected':len(report),'baseline_views_matched':sum(x['baseline_view_match'] is True for x in report),
        'new_views':sum(x['baseline_view_match'] is None for x in report),'historical_targets_modified':False}))
if __name__=='__main__':main()
