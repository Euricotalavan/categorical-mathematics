#!/usr/bin/env python3
"""Default author build: four live draft volumes. Historical U01 driver is preserved."""
from pathlib import Path
import subprocess,sys
def run(cmd,cwd,env,log):
    # Retained API required by the historical book_pipeline drivers.
    r=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    log.write_text(r.stdout,encoding='utf-8')
    if r.returncode:
        print(r.stdout[-9000:],file=sys.stderr)
        raise SystemExit(r.returncode)
    return r.stdout
if __name__=='__main__':
    subprocess.run([sys.executable,str(Path(__file__).resolve().with_name('build-author-volumes.py')),*sys.argv[1:]],check=True)
