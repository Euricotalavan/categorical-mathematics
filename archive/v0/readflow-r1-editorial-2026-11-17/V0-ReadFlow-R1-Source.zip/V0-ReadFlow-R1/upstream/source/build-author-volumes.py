#!/usr/bin/env python3
"""Build live author volumes, in order 0,1,2,4, without historical targets."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys
R=Path(__file__).resolve().parent
B=R/'author-volumes/build'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def environment():
    # Same local-format fallback as the preserved book_pipeline_v2.
    env=os.environ.copy();kpse=shutil.which('kpsewhich');engine=shutil.which('xetex')
    if not kpse or not engine:raise SystemExit('XeTeX/TeX Live required')
    if not subprocess.run([kpse,'article.cls'],capture_output=True,text=True,env=env).stdout.strip():
        roots=[p for p in ['/usr/share/texmf','/usr/share/texlive/texmf-dist','/var/lib/texmf'] if Path(p).is_dir()]
        if not roots:raise SystemExit('TeX packages not discoverable')
        env['TEXMF']='{'+','.join(roots)+'}'
    fmt=subprocess.run([kpse,'-format=fmt','xelatex.fmt'],capture_output=True,text=True,env=env).stdout.strip()
    if not fmt:
        from build import run
        fd=R/'.build/format';fd.mkdir(parents=True,exist_ok=True);fmt=str(fd/'xelatex.fmt')
        if not Path(fmt).exists():run([engine,'-ini','-etex','-jobname=xelatex','-progname=xelatex','xelatex.ini'],fd,env,fd/'author-format-console.txt')
    return env,engine,fmt
def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--volumes',nargs='+',type=int,choices=[0,1,2,4],default=[0,1,2,4])
    args=a.parse_args(); assert args.volumes==sorted(set(args.volumes))
    subprocess.run([sys.executable,str(R/'author-volumes/generate.py')],check=True)
    B.mkdir(exist_ok=True);runs=[];env,engine,fmt=environment()
    for v in args.volumes:
        prev=None
        for n in range(1,7):
            p=subprocess.run([engine,'-fmt='+fmt,'-progname=xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',
                '-file-line-error','-output-directory=author-volumes/build',f'volume-{v}.tex'],cwd=R,env=env,capture_output=True,text=True)
            (B/f'volume-{v}-pass-{n}.txt').write_text(p.stdout+p.stderr)
            if p.returncode:print(p.stdout[-7000:]);sys.exit(p.returncode)
            state=[sha(B/f'volume-{v}.{ext}') for ext in ['aux','toc','out']]
            if n>=3 and state==prev:break
            prev=state
        else:raise RuntimeError(f'Volume {v} did not converge')
        runs.append({'volume':v,'converged_pass':n,'PDF_SHA256':sha(B/f'volume-{v}.pdf')})
        print(f'Volume {v} converged at pass {n}',flush=True)
    (B/'convergence.json').write_text(json.dumps(runs,indent=2)+'\n')
if __name__=='__main__':main()
