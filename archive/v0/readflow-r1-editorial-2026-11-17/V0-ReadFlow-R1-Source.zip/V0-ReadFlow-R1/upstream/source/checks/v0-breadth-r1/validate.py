#!/usr/bin/env python3
"""Check the actual clean-built author draft without certifying its semantics."""
from pathlib import Path
import argparse,hashlib,json,re
import fitz
from pypdf import PdfReader
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def groups(s):
    result=[];i=0
    while i<len(s):
        if s[i]!='{':i+=1;continue
        start=i+1;depth=1;i+=1
        while depth:
            if s[i]=='\\':i+=2;continue
            if s[i]=='{':depth+=1
            if s[i]=='}':depth-=1
            i+=1
        result.append(s[start:i-1])
    return result
def main():
    p=argparse.ArgumentParser();p.add_argument('source_root',type=Path);p.add_argument('--evidence',type=Path,default=Path(__file__).parent);a=p.parse_args()
    R=a.source_root.resolve();B=R/'author-volumes/build';D=a.evidence.resolve();D.mkdir(parents=True,exist_ok=True)
    original=json.loads((Path(__file__).parent/'original-label-numbers.json').read_text())
    docs={};labels={};selections=[];volumes=[];internal=external=0;toc_count=0
    for v in [0,1,2,4]:
        selected=json.loads((R/f'author-volumes/v{v}/selected-sources.json').read_text());selections+=selected
        for s in selected:assert sha(R/s['selected_source'])==s['selected_SHA256']
        doc=fitz.open(B/f'volume-{v}.pdf');docs[v]=doc;names=doc.resolve_names();pl=PdfReader(B/f'volume-{v}.pdf').page_labels
        assert pl==[x.get_label() for x in doc]
        for i,page in enumerate(doc):
            foot=page.get_text(clip=fitz.Rect(0,page.rect.height-57,page.rect.width,page.rect.height)).strip()
            if foot:assert foot==pl[i],(v,i,foot,pl[i])
        local=[]
        for line in (B/f'volume-{v}.aux').read_text().splitlines():
            if not line.startswith(r'\newlabel{'):continue
            name,outer=groups(line)[:2];fields=groups(outer);assert name not in labels,name
            assert fields[3] in names,(v,name)
            page=names[fields[3]]['page'];assert pl[page]==fields[1],(v,name)
            row={'volume':v,'label':name,'number':fields[0],'printed':fields[1],'physical':page+1,'anchor':fields[3]}
            local.append(row);labels[name]=row
        for line in (B/f'volume-{v}.toc').read_text().splitlines():
            if not line.startswith(r'\contentsline '):continue
            x=groups(line);assert x[3] in names and pl[names[x[3]]['page']]==x[2],(v,x);toc_count+=1
        bad=[x for x in (B/f'volume-{v}.log').read_text().splitlines() if re.search(r'LaTeX Warning|Package .* Warning|Overfull|Missing character|undefined references',x)]
        assert not bad,(v,bad)
        volumes.append({'volume':v,'pages':len(doc),'body_pages':sum(x.isdecimal() for x in pl),'SHA256':sha(B/f'volume-{v}.pdf'),'bytes':(B/f'volume-{v}.pdf').stat().st_size,'labels':len(local),'warnings':[]})
    for name,number in original.items():assert labels[name]['number']==number,(name,number,labels.get(name))
    for s in selections:
        raw=(R/s['selected_source']).read_text()
        for name in re.findall(r'\\(?:eqref|ref|pageref|autoref)\*?\{([^}]+)\}',raw):
            assert name in labels,(s['logical'],name)
            assert labels[name]['volume']<=s['volume'],(s['logical'],name,'later-volume dependency')
    for v,doc in docs.items():
        for i,page in enumerate(doc):
            for link in page.get_links():
                if link['kind'] in (fitz.LINK_GOTO,fitz.LINK_NAMED):
                    assert 0<=link['page']<len(doc),(v,i,link);internal+=1
                elif link['kind']==fitz.LINK_LAUNCH:
                    m=re.fullmatch(r'volume-(\d+)\.pdf#nameddest=(.+)',link['file']);assert m,(v,i,link)
                    assert m[2] in docs[int(m[1])].resolve_names();assert '/GoToR' in doc.xref_object(link['xref']);external+=1
                elif link['kind']==fitz.LINK_GOTOR:
                    m=re.fullmatch(r'volume-(\d+)\.pdf',link['file']);assert m,(v,i,link);target=docs[int(m[1])]
                    if link['page']>=0:assert link['page']<len(target)
                    else:assert link.get('to') in target.resolve_names()
                    external+=1
    assert len(original)==1365 and external==14
    original_members=selections[:]
    info={'status':'PASS','semantic_scope':'Author checks only; new units independently pending','volumes':volumes,
        'selected_sources':len(selections),'original_label_numbers_preserved':len(original),'total_labels':len(labels),
        'TOC_destinations_checked':toc_count,'internal_links':internal,'cross_volume_links':external,'EN_STABLE':False}
    (D/'validation.json').write_text(json.dumps(info,indent=2)+'\n')
    (D/'label-locations.json').write_text(json.dumps(labels,indent=2)+'\n');print(json.dumps(info,indent=2))
if __name__=='__main__':main()
