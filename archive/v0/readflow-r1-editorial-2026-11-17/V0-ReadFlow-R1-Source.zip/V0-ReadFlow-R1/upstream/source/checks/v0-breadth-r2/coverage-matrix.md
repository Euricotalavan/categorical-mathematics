# Volume 0 breadth intake and cross-volume coverage matrix — r2 (2026-11-12)

Evidence base: exact source ZIP SHA256 `199ac490b5f89253773b5e9ac7936d751cf4f154b7aa2139230052f396af1aa1`, 489/489 manifest files verified; `author-volumes/v{0,1,2,4}/chapters.json` and actual current section source headings. Judgments below are scoped to **the existing selected manuscript**, not a claim about external textbook coverage. Lawvere–Rosebrugh body comparison remains UNKNOWN. No whole-volume review is claimed.

| V0 ch | Already present in r1 | Open adjacent breadth / allocation | Later volume already provides | Decision |
|---|---|---|---|---|
| 0 | Bounded proof obligations, classical negation, supplied finite construction records and finite-list induction | Formal external metatheory, wider proof-language and PL09 remain unresolved | V2 ch28–35 internal natural-number and arithmetic recursion, which does not prove the external meta rule | Do not alter existing foundation policy |
| 1 | Typed functions, category axioms, diagrams, elementary finite/failed models | How *new* categories are generated from graphs and finite paths | No path-category construction found in mapped V1 chapters | **B07** new category model |
| 2 | Inverse equations, bijective functions, automorphisms, triangle transport; B01 subcategories/core groupoid | Opposite category, functorial maps of categories and natural comparisons; avoid assuming initial objects | Initial objects and coproducts at V1 ch26 | **B08, B10, B11, B12 drafted**; no global functor-category size axiom |
| 3 | Terminality, global points, binary products, comparison; B02 triple products, rebracketing/swapping | Product-arrow calculus is partially in existing exercises; avoid doubling later diagonal | V1 ch11 has diagonal and equalizer-as-diagonal pullback; ch12–14 exponentials | Defer overlap |
| 4 | Monoids, preorders, posets, discrete categories; B03 involutive sets and source tests | Additional structure-preserving examples only if they sharpen a new method | V1 later structured predicates and relations | No duplicate model-only padding |
| 5 | Monicity, equalizers, B04 retracts, idempotents and structured equalizers | Split epicity and diagonal representation would collide with later allocation | V1 ch11 diagonal construction; ch22 regular/split epi | Avoid duplicate |
| 6 | Pullbacks, pasting, functions, B05 fibers and parameter objects | A category of arrows over a fixed base provides a coherent interpretation of all given pullback diagrams | V1 ch10–11 supply conditional constructions, not a slice-category axiomatization | **B09, B13 drafted** |
| 7 | Subobject representatives, given intersections, B06 finite meet calculus | Coherent comparison in slices would generalize common-target factor tests, if scoped | V1 ch15–18 classifiers/predicates, ch26 unions | Avoid duplicate Sub(A)/union claims |
| 8 | Inverse-image comparisons, pullback pasting, intersection stability | Actual base-change of individual objects and arrows in a fixed slice, with explicitly supplied pullbacks | V1 later quantifier and descent theory, not a general slice-category construction | **B09, B13 drafted** |
| 9 | Finite countermodel refuting automatic terminal/product/equalizer/pullback existence | No new global existence axioms without decision | V1 ch10–11 conditional existence packages | Preserve closing boundary |

V1 ch10–28: conditional existence, exponentials, power objects, classifiers, relations, graphs, quotient/effective descent, coproducts/unions and NNO **already present**. V2 ch29–51: arithmetic through completed real-number construction **already present**. V3: Linear Algebra I explicitly **reserved and unfilled**. V4 ch52–64: Analysis I **already present as a draft**; continuation paused. Blank plan areas are not claimed absent from mathematics; they describe this manuscript only.

Next evidence: add B07 as a separate canonical file at `continuations/v0-breadth-r2/sections/b07-path-categories.tex`; append it to V0 chapter 1 while retaining existing selections; preserve B01–B06 unchanged. B08/B09 were saved as CP02. B10/B11 were saved as CP03; B12 and B13 were subsequently appended for full/faithful tests and the category of commuting squares. Independent review remains pending.

BR01 already solved in r1, not replayed. BR02 stays open for coordinator decision: B01's subcategory object selection versus ch4 empty-category presentation. Depth review files `05-global-elements.tex` and `16-posets-and-monotone-maps.tex` remain unchanged, separate and unmerged. Historical lost 97 pages remain unrecovered. No EN-STABLE status and no GitHub release.

## Incremental update after CP19 (B21–B24)

The r1 rows above are retained as historical intake evidence and should not be
read as the current selection status. CP19 had already added B14–B23, including
supplied equivalences, natural transformations, adjunctions, comma categories,
right-adjoint preservation, and a diagonal–product adjunction. Independent CP19
review passed, but no whole-volume completeness finding follows.

* **B24 (new)**: category presentations from supplied typed path congruences,
  externally available equivalence classes and quotient composition, and the
  universal factorization of compatible path evaluations. This is distinct
  from the **object-level quotients and effective descent** in V1 Chapters 22–27.
* **B25 candidate**: practical functor/naturality verification for categories
  presented by generators and relations, extending the already supplied
  edge-level criterion without assuming all functors form a set.
* **B26 candidate**: connected components and zigzags using explicit external
  finite zigzag data; no formation of a global set of all components without
  an external assumption. This does not repeat V1 exponentials/classifiers/NNO.
* **Boundary**: V1 already supplies coproducts, regular quotients,
  classifiers, relational compositions, power objects and NNO; do not
  repackage these as allegedly absent. V3 remains reserved for Linear Algebra I.
* **Presentation status**: CP19 is the verified pre-B24 baseline. Study v0.2-r1
  is independently under review and not merged into these canonical sources.

* **B27 (new)**: skeletons of supplied categories, explicit representative
  isomorphism families, and reduction of a connected groupoid to a selected
  object. This completes the local B24–B27 arc without adding object-choice
  or universe axioms.
* **Chapter 4 dependency check (incremental)**: B24 uses B07, B10 and the
  category axioms; B25 uses B24 and B11/B12; B26 uses B01, B24–B25 and
  finite external lists; B27 uses B14 and B26. In the actual selected order
  all these prerequisites precede the new units. The opening of B24 marks
  the deliberate return from advanced functor methods to presentations.
  This is an incremental audit of the new arc, not a whole-chapter PASS.

## CP23 extension: local algebra and supplied actions

* **B28**: Endomorphisms at a fixed supplied object, local monoid and automorphism group laws (set language only when such sets are externally supplied), and explicitly isomorphism-dependent conjugation. The earlier BM construction does not give this fixed-object calculus in an arbitrary category.
* **B29**: Monoid actions as functors BM into the supplied ordinary-function model, group actions by bijections, involutive/idempotent actions, and equivariant maps as natural transformations. This is distinct from B10's functors BM→BN and complements B03/B04 without overwriting them.
* Dependency: B28 uses the Chapter 2 inverse laws, Chapter 3 product comparison and Chapter 4 monoid/core terminology; B29 uses B28, B10/B11, B03/B04. Both are appended at the end of Chapter 4. No new hom-set or global functor-category size assumption is made.
* CP22 independently reviewed by dot; B28–B29 newly drafted and await independent mathematics review. V1's classifier, exponential, quotient, coproduct and NNO chapters remain untouched; V3 reserved.

## CP24 local corrections and B30–B31: Chapter 4 dependency/motivation audit

This is an **incremental cross-unit inspection of the selected Chapter 4**; it is NOT a whole-chapter completeness review. CP22's B24–B27 and CP23's B28–B29 have independent review stages as stated by the coordinator, with CP23 PDF readback still separately pending.

* **Arc 1: presentations, B24–B27.** B24 uses the externally supplied complete finite paths of B07 and the functor definition B10. B25 uses B24 plus B11's generating-arrow naturality proof; its reference to that proposition has been corrected. B26 uses the earlier groupoid/core and finite zigzag convention; B27 uses B14's conditional equivalence and B26's groupoid connectivity. The B24 opening now says *following units* rather than an obsolete exact count. The B27 chain exercise tests *every* functor out of a one-object source for essential surjectivity, not only inclusions. Proposition 4.89 has a local keep-with-next control; this is typography, not mathematical revision.
* **Arc 2: local algebra, B28–B29.** B28 develops the monoid at one supplied object and automorphisms/conjugation; B29 identifies an externally supplied monoid action with a functor BM→Set and equivariant arrows with natural transformations. It does **not** duplicate B10's monoid-homomorphism functors BM→BN, B03's direct involution example, or B04's idempotent-splitting theorem. B28 Exercise 4 is now explicitly a *review after Chapter 6*, citing the later supplied-product-functor section and its componentwise interpretation. Chapter 3 already defines products, but the later perspective is signposted. B29's retract/splitting sentence is explicitly a later Chapter 5 reference.
* **Arc 3: action categories, B30–B31.** B30 uses B29 and a *supplied nonempty* action set, and retains each labelled move rather than only the corresponding ordinary function. B31 uses B30, the earlier B26 zigzag criterion, and group inverses. Orbits/stabilizers are supplied ordinary external subsets, not general categorical quotients or a globally chosen orbit collection. This differs from the object-level quotient and classifier topics in Volume 1.
* **Reading order:** Chapters 1–3 provide paths and supplied products; Chapter 4 first supplies monoids, preorders, functors, transformations, and equivalence data, then these three arcs. B28's product review is explicitly deferred to Chapter 6. B29 points forward to Chapter 5 for the retract connection. B30/B31 introduce no fresh forward dependencies. The manuscript still permits non-linear optional review, but essential assumptions are stated where used.
* **Not asserted:** whole Chapter 4 certified; all action categories exist without externally supplied arrow records or a nonempty object collection; all orbit subsets or all quotient structures exist internally; global choice, size, empty-category or foundation policies settled. Study v0.2 remains independent.

## CP25: B32 follow-up after audited Chapter 4 gap map

B32 reconstructs a natural arrow rule from its identity input, avoiding any Hom-set/smallness assumptions. This addresses the all-source generalized-element gap recorded in `chapter4-open-breadth-and-dependencies-cp25.md` and does not claim a complete Yoneda lemma.

## CP26: B33 follow-up after audited Chapter 4 gap map

B33 specializes all-source arrow comparison to chosen generators and jointly monic/epic families, with explicit model counterexamples; Chapter 5 monic links remain forward reading pointers. The action branch B28–B31 is not extended.

## CP28: conditional diagram and element categories (B34--B35)

* **B34 (Volume 0, Chapter 8)** constructs a category from a **supplied** family of functors and a complete collection of natural transformations between every selected pair; proves category laws, evaluation functors and the componentwise isomorphism test. A restricted-arrow countermodel shows why retaining all transformations matters. Walking-arrow and discrete-pair examples only compare already supplied diagrams, and do not introduce a global functor-category size axiom.
* **B35 (Volume 0, Chapter 8)** constructs a category of elements for a **supplied** ordinary-set-valued contravariant functor. Object/arrow records and an object witness are explicit external hypotheses. It proves the forced backward-label lift, the representable/slice identification under locally supplied hom-sets, and functorial transport along a supplied natural transformation. No presheaf category, complete Yoneda lemma, global hom-set collection or empty-category convention is inferred.
* **Placement and dependencies:** Chapter 8 follows Chapter 4 functors/naturality/B32 probe tests, Chapter 5 opposite categories, Chapter 6 product-functor work, and the already selected B09 slice/B13 arrow/B20 comma material in Chapter 8. Both new units are appended after B20. They do not reproduce Volume 1's classifiers, exponentials, regular images, relations, quotient/descent, coproducts or NNO.
* **Reading route:** The original Chapter 4 survey has been retitled *Models, functors, and categorical constructions* to acknowledge its approved breadth. B34/B35 are optional extensions to Chapter 8, not compulsory prerequisites for the earlier comparison/pullback chapters. Whole-volume completeness and global foundations/choice/size/PL09/empty-category/LR-body gates remain OPEN.

## CP29: B36 — graph morphisms and transported paths

* Prior selected manuscript B07 supplies externally given multigraph path categories; B10 supplies individual edge assignments to path functors. **B36** adds the missing category of supplied multigraphs and endpoint-preserving graph morphisms, componentwise identities/composites, induced path-functor transport, reflection of graph-map equality, and the strict distinction between sending an edge to a single edge or to a composite path.
* This is a concrete foundational model, not a category-of-categories or an internal free-category existence claim. It does not duplicate V1's object-level quotients/relations/classifiers/exponentials/NNO. Vertices are locally nonempty, edges may be empty; externally supplied finite paths and finite-list induction are prerequisites.
* Actual placement at the end of V0 Chapter 4, following B07 and B10 and before the optional B34/B35 Chapter 8 extensions. No new essential forward prerequisite. Four exercises with full solutions.
* B36 requires independent mathematics review. Global foundations/size/choice/empty-category/PL09/Lawvere–Rosebrugh-body/whole-volume gates remain open. Study candidate is separate.

## CP30: B37 — groups as objects, homomorphisms as arrows

* B37 is a concrete algebraic category complementary to the one-object group/monoid category already given in Chapter 4 and B29's actions. It verifies all group-homomorphism category laws, derived preservation of identity and inverses, and the faithful but generally non-full forgetful functor.
* Its conditional group-product theorem checks every universal test with actual componentwise group homomorphisms; the restricted two-object family of groups of orders 2 and 3 is a genuine missing-product countermodel. No closure of all supplied group objects under products is silently assumed.
* Located at the end of Chapter 4 after B36; depends on Chapter 2 invertible-function theorem, Chapter 3 product definition, Chapter 4 group definition. No Chapter 6 or later prerequisites. Neither V1 categorical quotients/classifiers nor V3 reserved linear algebra is duplicated.
* Local Chapter 4 bridge: graph morphisms (B36) and group homomorphisms (B37) both require checking closure before the category axioms, but differ in preservation of edges versus multiplication; comparison with the earlier posets and involutions makes assumptions explicit. This is an incremental cross-unit review; not Chapter 4/Volume 0 completeness certification.

## CP32: concrete rings, algebraic structure, and Chapter 4 scope

* B37 originally states the product group exists in the selected family; the condition is now spelled out as $G,H\in\mathcal K$ and $G\times H\in\mathcal K$, without changing the proof.
* B38 adds externally supplied **unital** rings as structured objects, the local category of all specified homomorphisms, a faithful but not generally full underlying-set functor, recognition of isomorphisms, and a conditional product. The two- and three-element modular rings provide a missing-arrow and missing-product countermodel. This is a categorical treatment of a **given external algebraic model**; it neither constructs integer/rational/real rings (V2) nor introduces internal ring objects (V3 reserved).
* Chapter 4 dependency order: B38 uses Chapter 4 groups, Chapter 2 inverses, Chapter 3 products and B37's construction pattern. The first three precede B38; B37 immediately precedes it. No new dependence on V1's quotient/relations/coproduct/classifier/exponential/NNO content is introduced.
* This is an **incremental new-unit audit** only; whole-chapter review, formal foundations, size, choice, empty-category, PL09 and Lawvere--Rosebrugh-body comparison remain OPEN. Study styles remain separate.

## CP33: external deterministic transition systems after rings

* B39 develops a concrete category of supplied rooted deterministic labelled transition systems and state-preserving transition morphisms. These are not merely the directed multigraph maps of B36: each input letter prescribes one transition at each state, and each object has a distinguished initial state. The full finite-word family, concatenation and finite-list induction are given **externally** as in Chapter 0.
* Word extension satisfies $\delta_{uv}=\delta_v\circ\delta_u$ (right action convention). Morphisms preserve runs. Reachability of a source implies **at most one** morphism into any supplied target; the two-/three-cycle obstruction shows no morphism need exist, and an unreachable-state example shows the hypothesis matters.
* No new quotient, coproduct, classifier, exponential or internal NNO theory is introduced (V1). V2 number-system constructions and V3 reserved linear algebra are unchanged. Unlike B29's general supplied monoid actions, B39 proves concrete rooted-state reachability and uniqueness tests. Dependency: Chapter 0 finite syntax, Chapter 1 functions, Chapter 4 B29 and B36; all occur earlier in actual Volume 0 reading order. Chapter 4 cross-unit checks remain incremental, not a whole-chapter or complete-volume certification.

## CP35: finite spaces and continuous maps

* B39 Example 4.147 heading corrected to describe the reachable-source existence failure; the 2-cycle/3-cycle proof is unchanged.
* B40 supplies finite topological spaces as external finite structures and a category of continuous maps with explicit object-family scope. Proofs cover inverse-image composition, faithful/non-full forgetful maps, and homeomorphism versus bijective continuous functions. No construction of all topological spaces or new finite limits.
* V4 Chapter 56 concerns continuous functions on compact real sets, but does not develop finite topological spaces as categorical models. This bridge is foundational and scoped. B41 will connect finite topologies to Chapter 4 preorders.

## CP36: finite spaces and preorders

* B41 compares finite spaces and finite preorders via explicit orientation $x\preceq y$ iff every open containing $x$ also contains $y$. Proves upward-set reconstruction, continuous iff monotone, and $T_0$ iff antisymmetric. No choice of a global category of spaces/preorders.
* B40 precedes B41 in the actual Chapter 4 selected-source map; both rely only on supplied finite data and Chapter 4 order definitions. The source proof follows the external finite-intersection/union convention, not the internal NNO of V1/V2. This is an incremental cross-unit dependency check, not whole-chapter PASS.

## CP38: finite-space connectivity (B42)

* **B42** adds the clopen-set criterion for nonempty supplied finite spaces, proves that clopen subsets are unions of specialization-order zigzag classes, and establishes equivalence of topological connectedness with connectedness of the supplied preorder category. This bridges B26 and B40/B41, not Volume 1's quotient/classifier theory or Volume 4's compact-real continuity.
* Proves connected images under supplied continuous maps with an explicitly supplied subspace topology, and finite $T_1$ implies discrete. The image subspace need not lie in the selected object family; this distinction is stated. Four exercises with full answers supply finite countermodels and tests.
* Chapter 4 audit `chapter4-cross-unit-audit-cp37.md` identifies the dependency route; after adding B42, the local route B26, B40, B41 -> B42 is now implemented. This remains a scoped dependency audit, **not** full-chapter completeness certification.
* Literature: the CP35 May orientation pointer is retained as a limited background reference. Neither the connectedness proof's page-level source nor Lawvere–Rosebrugh body coverage is independently verified; mark such coverage **UNKNOWN**. No global foundations, size, choice or empty-category policy is selected.

## CP40: a partial-map model for the Chapter 5 universal tests

* **B44** is assigned to Chapter 5 (not another Chapter 4 model appendix): a supplied finite-carrier category of partial functions where equality includes domain of definition, a locally checked composition law, monomorphisms as total injections, and conditional agreement-locus equalizers.
* Its direct prerequisites are Chapter 1's typed categories and ordinary functions, Chapter 2's inverse equations, and Chapter 5's monomorphism/equalizer universal properties. No Chapter 6 or Volume 1 results are required.
* The externally finite agreement subset is not assumed to be a retained object. Its possible omission is tested by an explicit one-object countermodel; this does not duplicate V1's internal power objects, quotients or existence package.
* The local chapter dependency/motivation audit is in `chapter5-partial-maps-cp40.md`. It is not a chapter/volume PASS. Literature source-to-manuscript comparisons belong to the independent review line, not this coverage log.

## CP41: terminal-to-initial arrow exercise at B20

The existing Chapter 8 comma/initial-object treatment now has a short complete review exercise: a **given** arrow from the chosen terminal to initial object is forced to be the inverse of the unique initial-to-terminal arrow. It is a conditionally stated exercise, not an existence claim. It supplies no new need for global choice, empty-category or further universal constructions.

## CP42: B45 externally supplied finite stochastic maps

B45 adds a genuinely non-deterministic model of categorical composition, with finite rational column-stochastic tables, categorical isomorphism exactly deterministic bijections, and a specified ordinary-product cone whose uniqueness fails due to correlations. It builds on Chapter 1 function calculus, Chapter 2 inverses, Chapter 3 given products, and Chapter 4 model comparison; no later quotient, coproduct, classifier, NNO, internal rational construction or probability-measure theory is duplicated. All coefficients and finite carriers are externally supplied. The global foundations/size/choice/empty-category/PL09/LR and whole-chapter/whole-volume gates remain open.


## CP43: algebraic inverse images, kernels and pullbacks (B46)

* **Existing bridge:** Chapter 4 B37 explicitly supplies group-homomorphism categories; Chapter 5 supplies categorical monomorphisms and equalizers; Chapter 6 supplies pullbacks and uniqueness tests; Chapter 8 already supplies set inverse-image calculations and changes of target. None of these sections carries out the subgroup-closed fiber-product construction or group-kernel test in the algebraic model.
* **B46 (new, Chapter 8 after B35):** externally supplied homomorphisms $A\to C$, $B\to C$ yield the subgroup of compatible pairs inside $A\times B$. When the resulting group is selected into $\mathcal K$, the two projection homomorphisms satisfy every categorical pullback test, existence and uniqueness. Subgroup preimages give a more specialized pullback; a retained kernel gives a conditional categorical equalizer and, when the trivial group is retained, a pullback.
* **Precision and dependence:** an ordinary injective group homomorphism is monic for any chosen full group category, while the converse is proved only when its kernel group is an available test source. The subgroup/kernel/group-fiber-product structures are shown by explicit closure under units, multiplication and inverse. All finite cyclic examples are externally supplied finite groups.
* **Volume boundaries:** Volume 1 already covers regular images, effective quotients, predicates and descent; B46 does not construct quotient groups, normal-subgroup correspondences or general all-pullbacks existence. Volume 2 constructs arithmetic internally later, which is not invoked as a premise here. The limited literature/terminology delta remains to be absorbed by the separate reference-to-manuscript audit; this is not a duplicate global bibliography.
* **Cross-unit route and local review:** B37 (group homomorphisms) -> Chapter 5 (mono/equalizer) -> Chapter 6 (pullback) -> B09 and existing Chapter 8 inverse-image exercises -> B46. Chapter 8's B34/B35 diagram and category-of-elements constructions have different input data and are not overwritten. No compulsory forward dependency or circular prerequisite has been introduced. This is an incremental Chapter 8 dependency/coverage audit, NOT whole-chapter or whole-volume PASS.
* **Unresolved:** global foundations, size, choice, empty-category, PL09, Lawvere--Rosebrugh body check, all-volumes completeness and Study template integration remain OPEN.

## CP45: B47 base-change functors and postcomposition adjunction (Chapter 8)

* A genuinely supplied objectwise family of pullbacks for one fixed $f:B\to A$ extends the **local** B09 reindexing calculus to a functor $f^*:C/A\to C/B$; different such families are canonically naturally isomorphic. No simultaneous all-base family or choice principle is assumed.
* Postcomposition $f_!$ exists without pullbacks and is left adjoint to this $f^*$ when supplied; proof tests naturality at both slice variables and both triangles via the two pullback projections. Iterated base change compares up to canonical coherent isomorphism.
* Concrete finite sets show $f^*$ need not be faithful; a nonempty three-object poset shows $f_!$ need not possess any right adjoint when the relevant pullback does not exist.
* Prerequisites B09 + B18 + Ch6 precede this section; B46 remains separately about group kernels. V1 advanced/further existence chapters not duplicated. Only incremental Chapter 8 dependency audit, not chapter completeness or independent math review.

## CP47 delta (B48): idempotent completion after Chapter 5 splitting criterion

* Chapter 5 B04 already proved that split idempotents give an equalizer of `(e,id)` and supplied a 2-element monoid idempotent that does not split. **B48** gives the conditional Karoubi envelope and proves that each admitted idempotent splits, with a fully faithful embedding of the original supplied category. Four fully solved exercises test a concrete completion, idempotent equalizer, groupoid case, and the special embedding's preservation/reflection of monicity.
* Actual reading prerequisites: B04 and earlier category/functor/equivalence material. Its final exercise explicitly marks the B16 full-subcategory counterexample as a Chapter 8 **later comparison**. No unsupplied all-objects/arrow-sets or family of splittings is asserted.
* This is not the quotient/regular-image theory already in Volume 1. No reference-to-manuscript total matrix was duplicated. Chapter 5 and Volume 0 completeness remain OPEN, English DRAFT, all global foundation/size/choice/empty-category/PL09/LR-body gates unchanged.

## CP48 delta (B49): equalizers in supplied diagram categories

* **Existing interface:** Chapter 5 defines and tests supplied equalizers; B11/B17 supplies natural-transformation laws; Chapter 8 B34 constructs diagram categories only from explicitly selected functors and *all* transformations between them. No selected V0 section proves the componentwise equalizer theorem for that category. V1 Chapters 10–11 handle separate existence packages and pullback/equalizer constructions, not this diagram-category test.
* **B49** (Chapter 8 after B47) uses *externally supplied* equalizers for every indexing object to force the arrows of a new functor, proves functoriality and naturality by uniqueness, and checks the full diagram equalizer universal property **only if the resulting functor is included in the selected diagram family**. It also compares two supplied choices by a unique natural isomorphism.
* **Examples:** an involutive-set action shows an invariant equalizer; a one-object selected diagram family containing only a two-element-set-valued functor lacks an equalizer despite its ordinary component equalizer, because the required singleton-valued diagram is omitted. Four exercises with complete answers test a walking arrow, involution action, pointwise monic implication, and missing-object obstruction.
* **Prerequisite route:** B11 -> Chapter 5 equalizer and monicity -> B34 (supplied diagram category) -> B49. Chapter 8 B47 reindexing is independent; no hidden forward dependency. Original Chapter 8 unit order retained with B49 appended.
* **Scope:** no all-functor category, no global chosen family of equalizers, no set of all natural transformations constructed. This is not a claim that all diagrams have limits, a duplicate of V1 general existence, or an externally verified bibliography entry. Whole-chapter and whole-volume gates remain OPEN; English DRAFT; Study and independent literature matrix remain isolated.

## CP50 delta (B50): reindexing categories of elements, not general limits

The new Chapter 8 unit B50 fills the change-of-**index-category** interface between B35's contravariant categories of elements and B20's comma categories. It proves an induced functor on labelled objects and arrows, the strict commuting projection square, full/faithful implications and missing-label counterexample, the interaction with natural changes of labels, and a conditional representable/comma/slice identification. It cites B47 only to distinguish the separate fixed-base slice pullback operation; B49's pointwise equalizer theorem is neither duplicated nor generalized. Direct prerequisites B08, B10, B11, B20, B35 all appear earlier. All labels and choices are externally supplied and B35's nonempty-pair condition remains intact. See `chapter8-reindexing-elements-cp50.md`. Global gates and chapter/volume completeness remain OPEN; English DRAFT.

## CP51 delta (B51): supplied Yoneda evaluation and universal labels

* **Actual adjacent gap:** B32 proves the elementary identity test only for natural rules between two arrow-test objects; B35 constructs supplied contravariant set-valued element categories; B50 changes their index. None of these chapters treats natural rules from a supplied representable $H_A$ to an **arbitrary** supplied label functor $P$, or relates representability to terminal objects of $\int P$. The mapped V1 ch10--28 develops different conditional existence, classifiers, quotients and arithmetic interfaces, and does not contain this concrete supplied Yoneda evaluation.
* **B51 (new, Chapter 8 after B50):** proves that natural rules $H_A\Rightarrow P$ are reconstructed by $a\in P(A)$ through $\alpha_T(u)=P(u)(a)$; checks changes of $P$ and $A$ with explicitly typed variance; proves that the component maps are bijective iff $(A,a)$ is terminal in the supplied category of elements; proves the resulting representing pair unique up to a unique compatible isomorphism. A walking-arrow nonrepresentable functor and a finite-monoid action test keep the boundaries concrete. Four fully solved exercises.
* **Prerequisites/order:** Chapter 4 B10/B11 (functors/naturality), B32 (identity test), Chapter 8 B35 (supplied $P$ and $\int P$), and B50 (index-change comparison) all precede B51. No forward dependency. Only selected hom-arrow sets $H_A(T)$, specified component-function supply, and previously admitted pairs are required. We do not form the collection of all natural transformations, a presheaf category, or any global size/choice policy.
* **Scope:** complete new local proofs and exercises, not a general limits/colimits chapter, a duplicate V1 theorem, an authoritative literature certification, or a Chapter 8/full-volume PASS. Global foundations/size/choice/empty-category/PL09/LR-body gates remain OPEN; English DRAFT; Study and content-review work are independent.
