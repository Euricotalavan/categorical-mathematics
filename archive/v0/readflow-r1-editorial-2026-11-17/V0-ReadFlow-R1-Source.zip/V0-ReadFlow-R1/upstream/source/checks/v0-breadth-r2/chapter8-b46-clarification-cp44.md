# CP44 — B46 targeted mathematical terminology and notation delta

The accepted CP43 source and all selected predecessors remain unchanged except two precise B46 edits:

1. The forgetful functor from the supplied full group category **reflects** monicity unconditionally (underlying injectivity implies categorical monicity). Under the specified availability of the kernel test group, it **preserves** monicity at the displayed homomorphism (categorical monicity implies underlying injectivity). The kernel is sufficient for this argument, with no necessity claim.
2. For an arbitrary multiplicatively written source group X, the solution to B46 Exercise 2 now uses `t(xy)` while C4, C6 retain additive notation.

No quotient-group construction or V1 epi theory is moved into V0. This is an editorial correction, not a new global foundations/size/choice/empty-category policy and not a Chapter 8 or volume completeness assertion.
