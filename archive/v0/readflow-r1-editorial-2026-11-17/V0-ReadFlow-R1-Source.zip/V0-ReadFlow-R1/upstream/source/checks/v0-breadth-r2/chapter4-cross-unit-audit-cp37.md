# Chapter 4 cross-unit reading and scope audit — CP37

Status: **scoped dependency and breadth audit only**. It does not re-review every proof and does not imply a whole-chapter or whole-volume PASS. Baseline: CP36 exact source; B01–B41 remain in their selected order.

## Main reading routes

| Route | Selected source span | Core dependencies and conceptual purpose | Boundary / remaining gap |
|---|---|---|---|
| Models | original monoid, preorder, poset, discrete models; B03 | Typed category axioms, morphism preservation, points versus probes | Empty-category convention deferred; finite examples are externally supplied |
| Functor language | B10–B14, B17–B19 | Models precede functors; naturality, full/faithful, equivalences, adjunctions and two transformations | Do not presume global functor categories, hom-set sizes, or representative choice |
| Presentations | B24–B27 | B07 finite-path data; B10–B14 functor and equivalence tests | Typed path quotient availability externally supplied |
| Algebra and actions | B28–B31 | monoid/core, groupoid, finite zigzags; labelled action records | B28 product-functor exercise is explicitly later review; avoid duplicating internal V2 algebra |
| Generalized tests | B32–B33 | B11 naturality, global-element limits, monicity | All-source tests are not internal representable functors; Set-valued diagrams in Chapter 8 are separately scoped |
| Concrete models | B36–B41 | graph morphisms/path functors; group/ring homomorphisms; deterministic transitions; finite topologies/preorders | V1 covers universal constructions and classifiers; V4 covers compact real continuity, not finite-topology classification |

## Verification of critical noncycles

1. B36 follows B07 and B10; the graph-to-path functor proof does not require a global graph category.
2. B37/B38 use B10–B12 for forgetful functors, B03 for structure-preserving checks, and earlier Chapter 3's given-product property.
3. B39 uses external finite-word induction in Chapter 0 and typed composition; this is not V2's internal NNO recursion.
4. B40 first proves continuity of supplied functions; B41 then uses B40's opens, earlier preorder definitions, and finite external intersections. No later Chapter 5–8 categorical limit theorem is assumed.
5. B26's zigzag test is available earlier than B41, permitting a **new B42 bridge** from finite topological connectedness to preorder zigzags without importing a general topological connectedness theory.

## Coverage/repetition assessment and next unit

**B42 candidate:** finite connectedness via clopen sets and specialization-order zigzags; a nontrivial bridge between B26, B40, and B41. Neither V1's classification/quotients nor V4's continuity of compact real sets develops this particular finite space / order connectivity criterion in the present selected source map. This is a targeted source-scope finding, not a claim about every textbook or external literature.

No new foundations, size, choice, empty-category, or global family-formation conventions. PL09, Lawvere–Rosebrugh body comparison and global completeness remain OPEN/UNKNOWN. The historical Study layout branch is separate.

## Literature status

Existing limited pointer: J. P. May, *Finite Spaces and Larger Contexts*, §1.6 as recorded in `finite-topology-literature-cp35.md`, with its order-orientation caveat. The current check does **not** independently establish its page-level proof coverage of the proposed B42 connectedness theorem. Author citations for B42 should therefore remain scoped, with bibliographic comparison marked **UNVERIFIED**, and Lawvere–Rosebrugh body coverage **UNKNOWN**.
