# Finite topology/preorder scoped literature cross-check (CP35–CP36)

- Source manuscript V0 ch4 has nonempty preorders/posets, monotone functions, discrete categories; B40/B41 add finite topological models. V4 ch56 treats continuous maps on real compact sets, with a different role. No duplication of V1 classifier/quotient/NNO sections.
- J. P. May (with collaborators), *Finite Spaces and Larger Contexts*, §1.6 (Alexandroff spaces, preorders, order-preserving maps); https://math.uchicago.edu/~may/FINITE/FINITEBOOK/FINITEBOOKCollatedDraft.pdf . **Orientation caution:** this draft uses downward-closed basic opens, while these new notes use upward-closed opens, i.e. the opposite convention. This is a limited subject-level correspondence, not a line-by-line proof audit.
- F. W. Lawvere and R. Rosebrugh, *Sets for Mathematics*: body comparison remains UNKNOWN; no claim about its exact coverage.
- All sets, open-set families, finite intersections/unions and functions are supplied by the external ordinary model. Global size/choice/empty-category policies are unchanged.
