# Author review of the six breadth units

Status: author review only. Independent review of these additions and complete
independent review of Volume 0 remain pending. No EN-STABLE or publication gate
is passed by this report. The original selected sources were not edited.

## Mathematical and dependency check

The six new units were checked against their displayed equations, the existing
definitions they cite and their owning chapters. This is a local semantic check,
not a full reread of unchanged chapters. The proof checks made were:

| Unit | Main obligations checked | Boundary/edge cases |
|---|---|---|
| B01 | Endpoint/identity/composition closure; inverse of composite in reversed order; inverse retained inside the core; maximality and full-subcategory inverse test | A finite two-singleton example replaces a draft integer-translation example to keep the prerequisite contract elementary; nonfull selections can omit inverses; discrete groupoid need not connect distinct objects |
| B02 | Triple factor built by two pairings; uniqueness at both stages; both reassociation inverse equations by all three legs; swap inverse equations; concrete projection information; its cancellation exercise is assigned to B04 | All four intermediate products are separately supplied; empty A allows a monic first projection even with a nonterminal second factor |
| B03 | Structure-preserving maps closed under identities/composition; bijective inverse satisfies the preservation equation; global elements exactly fixed values; two-label source detects every value | K is a supplied nonempty family; empty carriers allowed; no closure under new objects is inferred; nonempty D has no global elements |
| B04 | Retraction yields idempotence and full equalizer factor test; given equalizer of e and identity yields a splitting by a monic cancellation; uniqueness and compatible splitting comparison | Explicit two-arrow nonsplitting model; no blanket idempotent-splitting axiom; stable subset and membership in K checked separately; empty agreement object matters |
| B05 | Any point 1->C is monic by terminality; fiber factor iff output condition; general parameter retains both projections; stable structured pairs and structure-preserving mediators | Empty fibers, repeated parameters, absent global points and nonfixed underlying values; not every underlying singleton parameter is an allowed arrow |
| B06 | Meet comparison test applied only to monic representatives; explicit repeated/top pullbacks; symmetry; monotonicity; compatible equivalence; both directions of three-condition characterization | Four nested pullbacks supplied locally; no Sub(A) set or global intersection selection; pairwise overlaps do not give a simultaneous witness |

Automated structural checks before compilation: all 203 selected canonical
hashes match; 197 original transformed views still match their pinned hashes;
no duplicate label or unresolved source reference; no new breadth reference
depends mathematically on a later chapter. No statement uses an exercise as an
unproved theorem: the existing left-inverse and pairing calculations are already
fully solved before the additions, and new calculations include their proofs.
The abstract core and finite selections are restrictions of supplied data;
formal metatheory and class-existence policy remain open as in the baseline.

## Motivation and two prose passes

The initial drafts of B01--B06 were persistently saved, with download checks
after each unit (CP002 versions 1--6). An author prerequisite pass replaced
the unnecessary integer example and made discrete terminology local.

Prose pass 1 revised all six units. It brings the reader's task into each
transition: retaining composites, testing common-source components, checking an
inverse's structure, solving the retained-value equation, recording parameters,
and comparing nested factorization conditions. It also explains where a closure
or witness obligation enters the proof.

Prose pass 2 revised all six resulting files. It shortened repeated scope
phrases, made the actual inverse-preservation obligation explicit, clarified
that reparenthesized objects can differ, and retained the empty and no-point
qualifications where they affect a conclusion.

The exact sequential diffs and per-file before/after SHA256 values are in
revision-evidence/. They document real changes, not retrospective invented
draft stages. The math/prerequisite pass is separate from the two prose passes.
These author passes do not replace the other worker's independent depth work.

## Freeze and build boundary

After these checks, freeze the six-unit batch and save/download-verify it before
the first long clean build. Build only the four new live author targets in
0,1,2,4 order. Check original numbering, source references, contents/page labels,
remote destinations and all new or affected pages. The historical calculus-r1
target and PDFs are not regenerated. Any subsequent compilation repair must be
logged and saved before the corresponding rebuild.

The bounded six-unit scope is finished at the author-draft level; page count is
an output measurement, not an acceptance quota. Future broadening requires a
new evidenced gap, while Lawvere--Rosebrugh coverage and the global-policy
questions stay open.

## Late checks actually performed

A visual/dependency pass found the new projection-cancellation exercise in Chapter3 used monicity before its Chapter5 definition. The complete exercise and answer were moved into new Chapter5 material; the Chapter3 example uses concrete component language. The exact diff is retained. Final downloaded-v9 sources were clean-built in prerequisite order; all four targets converged at pass3. Structural/navigation checks passed with1365oldnumbers preserved and14remotePDFlinks. All53new/front/join pages were inspected, then the4raster-changed repair pages were inspected again. This does not claim independent mathematical approval.
