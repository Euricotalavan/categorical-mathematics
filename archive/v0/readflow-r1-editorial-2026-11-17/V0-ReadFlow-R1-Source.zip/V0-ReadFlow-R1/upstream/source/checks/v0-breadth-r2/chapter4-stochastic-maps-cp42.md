# CP42: Finite stochastic map model—cross-unit motivation and dependency delta

Baseline: CP41, itself an exact extension of independently verified CP40. This is an author-incremental audit, **not** a whole-Chapter-4 or bibliography PASS.

## Concrete gap and interface

Chapter 4 already contains discrete models and order categories, graph homomorphisms, deterministic transition systems, groups, unital rings, finite topological spaces and action categories. Yet none of its selected sources has arrows encoding **genuinely probabilistic** finite outputs. B45 supplies a different finite category whose arrows are nonnegative rational column-stochastic tables. The deterministic ordinary-function functor is fully constructed and verified to be faithful and, with a supplied two-element carrier, non-full. Matrix composition, invertibility, and failure of uniqueness for the ordinary Cartesian-product cone are established without relying on any later probability or limit theory.

Prerequisites: Chapter 1 typed identities/composition and external finite index operations; Chapter 2 categorical isomorphism; Chapter 3 **supplied** products and their uniqueness test; Chapter 4 deterministic model discussion. B45 is placed at the end of Chapter 4, before Chapters 5–9; it introduces no essential forward-prerequisite cycle. The later arithmetic Vol2 obtains rational numbers internally, but here the nonnegative rational coefficient system is **explicitly external**, as is already permitted for model calculations. The model is not an internal construction of that field or a measure-theoretic probability space.

## Distinctness from later volumes

V1 Chapters 10–28 already study chosen universal constructions, exponentials, classifiers, general relations, quotients, coproducts and NNO. B45 does not reproduce their general theory, assert existence of stochastic products, construct a category of all finite sets, or prove a hom-set size policy. The two joint distributions with identical marginals disprove the **specified ordinary-product cone** only, not every hypothetical cone. Volume 3 remains reserved for later linear algebra and V4 is real analysis, neither is silently imported into the finite-table proof.

## Proof checks and boundaries

- Column sums and associativity follow from finite sums and commutative nonnegative rational arithmetic.
- Faithful deterministic embedding transports each ordinary function to a 0-1 column and explicitly exhibits a non-deterministic endomorphism.
- The two-sided stochastic-isomorphism proof uses nonnegativity to force each column deterministic, then applies faithfulness to reconstruct the inverse bijection. Mere linear invertibility of a stochastic matrix is not confused with a two-sided stochastic inverse.
- Examples distinguish random composition, idempotent averaging, and correlation/marginal uniqueness failure.
- Four exercises and fully typed complete solutions; no global foundations/size/choice/empty-category policy selected.

Literature reference-to-manuscript table continues independently in the content-refinement line. This file is only a B45 delta, not a parallel master bibliography. Keep PL09 and Lawvere–Rosebrugh body comparison UNKNOWN, Study isolated, English DRAFT and no completion release.
