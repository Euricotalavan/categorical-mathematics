# Chapter 8 incremental cross-unit audit — CP43 B46

Status: scoped source inspection, not full-Chapter 8 completeness or mathematical independent review.

## Motivation and grouping

The preexisting Chapter 8 starts with change of target in the ordinary-function model, then gives slices/arrow/comma and externally supplied diagram and elements categories. A second natural testing ground is the structure-preserving group model already established at B37. Its pullback object is an external subset only after closure under multiplication and inverse has been checked. B46 supplies that proof and gives kernels a concrete universal interpretation without migrating Volume 1's quotients here.

## Dependency check

B37 group homomorphisms and group inverses occur in Chapter 4. Monomorphism/equalizer universal properties occur in Chapter 5; the full pullback test in Chapter 6; subgroup inverse-image and fixed-target comparison context in Chapter 8 before appended B46. No use is made of Volume 1 regular or effective quotients. Every group used as a categorical object must be among the explicitly supplied family, including the fiber-product or kernel group when needed. The singleton group is independently required for the terminal pullback view.

## Types and test obligations

For homomorphisms f:A->C, g:B->C the compatible pairs P are a subgroup of the external A x B. Projection homomorphisms p:P->A, q:P->B are typed; a test X has u:X->A, v:X->B with f u=g v, and its unique factor X->P has coordinates (u,v). For subgroup inclusion S->H and f:G->H, R=f^{-1}(S) has a restricted arrow R->S. A retained kernel K->G equalizes f and the trivial homomorphism z:G->H; if a singleton group is retained it also gives a pullback with 1->H. The converse mono implication uses the two distinct candidate arrows from the kernel source, so its availability is explicit.

## Redundancy and boundary

Set-theoretic pair pullbacks are treated earlier; B46's closure and homomorphism uniqueness steps are new, as are the retained-kernel mono criterion and subgroup preimage tests. No hidden construction of all subgroups or global group category. V1 quotient/regular image and V2 construction of internal finite arithmetic remain untouched.

## Editorial handoff

The reference-by-reference matrix belongs to the independent depth/editorial line and has not been regenerated. Study local layout may later revise Chapter 8 breaks without changing the canonical mathematical proof. CP42 is the frozen known-good source baseline.
