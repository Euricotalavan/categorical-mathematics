This directory preserves the original independent review of the 333-page completion-r1 edition. Its physical-page locators refer to that older edition, and its original “not adopted” status describes the review handoff at that time.

The present split edition adopts the three specified corrections in new reading copies. See ../adoption.json for the exact changes and all three locator systems: the original 333-page review, the 381-page calculus-r1 baseline, and the new split PDFs. Do not apply the preserved review patch a second time to these split sources.
