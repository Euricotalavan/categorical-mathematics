# CP46: identity base-change precision repair (B47)

CP45 was independently accepted for B47; this checkpoint changes only the identity-base-arrow passage of Proposition `prop:breadth-base-change-composition` and its generated view / selection hash. For `x:X\to A` and bottom `\id_A:A\to A` the pullback object is `X`, its two projections are `\id_X:X\to X` and `x:X\to A`, respectively. The universal test has unique factor `a:Y\to X` for every pair `(a:Y\to X,b:Y\to A)` with `xa=b`. The proof no longer calls both projections identities.

No other mathematical proof claims changed. No clean volume rebuild; next author unit will be added separately. All foundation, size, choice, empty-category, PL09, LR-body, Study, and completeness gates remain open.
