# CP49 controlled B49 typing clarification — English DRAFT

Baseline: independently accepted CP48 source SHA256 `623c0441f1fedb7a626cdcfd76e0b453c598bab3b41264b3e9c50e293132961e`.

In the full solution to `ex:breadth-diagram-equalizers-involution`, explicitly distinguish the supplied involution `sigma_S:S -> S` from its restriction `sigma_E=sigma_S|_E:E -> E`, where `i:E -> S`. Naturality/equivariance of the test arrow `h:H -> S` is verified by the typed chain `i t rho(z) = h rho(z) = sigma_S h(z) = i sigma_E t(z)`, then cancellation with the injective inclusion gives `t rho = sigma_E t`.

This changes only the notation and typing of an already mathematically accepted proof; CP48 component equalizer and full universal property arguments are retained. The external selected-family and all-natural-transformations assumptions are unchanged. No broader pointwise-limit theorem is being claimed. The global foundations, size, choice, empty-category, PL09, Lawvere--Rosebrugh body comparison, literature reference matrix and chapter/volume completeness remain OPEN.
