# CP39 — Chapter 9 relative universal properties: local dependency / coverage delta

Status: **author incremental audit, not independent whole-chapter review**. Baseline CP38 SHA256 `56dbc94479d14d2cb74d8847c4bf5271a149c9299f0d0ee8cd200873e65d26a6`.

## Genuine gap and allocation

The preexisting Chapter 9 tests failures of terminal objects, products, equalizers and pullbacks in a two-arrow category. Volume 1 Chapters 10–11 already develop the *global existence requirements*, their quantifier order and order-category existence models. These remain unchanged.

B43 instead tests **relative versus ambient** universal properties when a fixed full subcategory omits sources or representing objects. It gives a conditional inheritance theorem for *supplied* constructions, and three distinct finite counterexamples: a relative terminal object not ambient terminal, a relative product not ambient product, and an ambient product whose object has been omitted. Its fourth exercise demonstrates why fullness is an actual hypothesis even when both projections survive. None of these statements chooses all limits, a global family of subcategories, an empty-category convention, or a size/foundation/choice axiom.

## Internal prerequisite sequence

- Chapter 2 B01 defines full subcategories, with local nonempty scope.
- Chapter 3 supplies terminal objects and the full universal product tests.
- Chapter 4 defines order categories from externally supplied preorders.
- Chapter 5 establishes equalizers and monicity.
- Chapter 6 supplies pullbacks and their two-component uniqueness tests.
- Chapter 9's existing finite nonexistence witness and B43 come **after all these** in Volume 0's actual selected order.
- Volume 1 Chapter 10 then articulates outer existence requirements, and Chapter 11 separately analyzes order-existence models. The explanatory transition is forward, not a prerequisite for B43.

## Proof and boundary checks

The inheritance proof checks all relative sources and uses fullness only to retain ambient factors between retained endpoints. The counterexamples use nonempty explicitly supplied posets/categories, not a set of all categories. The finite poset relations have been checked for transitivity; their admitted and omitted arrows are explicitly listed in the solutions.

Literature comparison for B43 remains **UNVERIFIED** and is assigned to the separate literature-review line. Lawvere–Rosebrugh body: **UNKNOWN**. PL09, general foundations, size, global choice, empty-category policy and chapter/volume completeness: **OPEN**. The Study template branch is not merged.
