# CP47 Chapter 5 bridge: split idempotents and Karoubi completion (B48)

## Actual missing interface in the selected manuscript

B04 had defined an idempotent, proven that a **given** equalizer of `(e,id_A)` splits `e`, and exhibited the non-splitting idempotent `a` in a one-object two-element monoid. The existing Volume 0 Chapter 5 did not construct the idempotent-pair category, its embedding, or the exact way that adjoining a retract corrects the example. Scans of selected V1 Chapters 10–28 found no Karoubi/Cauchy completion unit; V1's quotient, epi and NNO discussions are separate and remain untouched. This is an adjacent *constructive completion of an existing counterexample*, not a replacement for Volume 1.

## Scope and prerequisite test

Prerequisites: Chapter 1 category laws; Chapter 2 isomorphism equations; Chapter 5 B04 retracts/idempotents; Chapter 4 B10 functors and B12 fully faithful maps; Chapter 4 B14 equivalence via supplied representatives. All appear before B48 in actual selected reading order. The B16 full-subcategory monic counterexample occurs later in Chapter 8, and the B48 final solution explicitly marks that comparison as later rather than concealing the forward dependence. The construction uses only a separately **supplied** object/arrow family of idempotent pairs, no universe of all idempotents asserted to be a set; naturality and extension results separately require supplied splitting choices in target categories.

## New coverage (B48)

(i) idempotent-pair identities and composition with typed laws; (ii) canonical full and faithful embedding J; (iii) every admitted idempotent splits inside Kar(C); (iv) (A,e) isomorphic to J(R) iff supplied e splits in C; (v) extension of F under specified splittings F(e), plus canonical comparison of two such families; (vi) 4 exercises and full solutions: two-element monoid, equalizer of an idempotent within Kar(C), groupoid boundary, preservation/reflection of monics by this special embedding.

## Still open

No claim that a global category of all idempotent pairs exists without an external size policy, or that all functors extend without chosen splittings. The original Chapter 5 bounded review remains intact; this is a new independent-review candidate. No general literature page verification (the reference-to-manuscript matrix belongs to the refinement workline), no whole-chapter/volume completeness, no Study merge. Foundations, size, choice, empty-category, PL09, LR body remain UNKNOWN/open.
