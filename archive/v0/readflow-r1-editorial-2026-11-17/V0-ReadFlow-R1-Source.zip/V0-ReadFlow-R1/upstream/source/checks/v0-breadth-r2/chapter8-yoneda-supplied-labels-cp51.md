# CP51 — B51: Yoneda identity evaluation with supplied labels

Baseline: CP50 SHA256 cca07292f3de663cf9a33e22764f13b9f512796c46453b9570d305cc77878b85 (dot independently accepted). No old canonical rewritten.

## Chapter 8 adjacent prerequisite route
Chapter 4 B10 (typed functors), B11 (natural transformations), B32 (all-source arrow identity test), Chapter 8 B35 (supplied set-valued functors and categories of elements) -> B50 (change of index) -> B51 (the element at the identity test, universal label criterion). B49 componentwise diagram equalizers and B47 base-change adjunction are independent. No circular prerequisites or forward references required.

## New independent theorems and countermodel
Reconstruction of natural rules from a∈P(A), naturality under change P/Q and representing object A/B, equivalence of a universal label, bijectivity of all H_A(T)→P(T) and terminality of (A,a) in ∫P, uniqueness of a representing pair up to unique compatible iso. The two-object walking-arrow example P(0)={b,c}, P(1)={a}, P(d)(a)=b shows natural rules can exist without a universal label. Four exercises provide full independent computations and test the finite two-element idempotent monoid.

## Supplies and boundaries
Externally supplied hom-arrow sets H_A(T), contravariant set-valued P, component functions and equality records. All explicitly scoped. No object P of a larger category, no collection of all natural rules, no global presheaf universe, no unselected empty-category convention, no choice. V1 existence, quotients and classifiers remain independent. This is an incremental cross-unit check, not a completed Chapter 8 or whole-volume verdict. Bibliography and Study layout remain separately managed.
