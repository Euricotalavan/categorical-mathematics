from pathlib import Path
import json,hashlib,difflib
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
S=R/'continuations/v0-breadth-r1/sections'
def sha(t):return hashlib.sha256(t.encode()).hexdigest()
def run(name,changes):
 rows=[];diff=[]
 for f,repls in changes.items():
  p=S/f;before=p.read_text();after=before
  for a,b in repls:
   assert after.count(a)==1,(name,f,a)
   after=after.replace(a,b,1)
  p.write_text(after);rows.append({'file':str(p.relative_to(R)),'before_SHA256':sha(before),'after_SHA256':sha(after),'replacements':len(repls)})
  diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+f,tofile='after/'+f))
 (D/'revision-evidence'/f'{name}.diff').write_text(''.join(diff))
 (D/'revision-evidence'/f'{name}.json').write_text(json.dumps(rows,indent=2)+'\n')
run('mathematics-and-prerequisites',{
'b01-subcategories-and-groupoids.tex':[(r'A discrete category is a groupoid: each identity is its own inverse, and',r'A category with only identity arrows, called a discrete category, is a groupoid: each identity is its own inverse, and'),('''A subcategory may discard an inverse while keeping an arrow. For instance,
on the supplied external set of integers, retain as arrows only the
translations $t_n(k)=k+n$ with nonnegative integer $n$. Ordinary addition
gives $t_m\\circ t_n=t_{m+n}$ and $t_0=\\id$, so these form a one-object
subcategory of the function model. The arrow $t_1$ is a bijection there
as an underlying function, but its inverse $t_{-1}$ is not retained.
Indeed $t_n\\circ t_1(0)=n+1\\ne0$ for every permitted $n$.
This optional example uses external integer arithmetic as supplied data;
it does not construct the series' internal integer object.''','''A subcategory may discard an inverse while keeping an arrow. For example,
use the full function category on the two distinct singleton sets
$A=\\{a\\}$ and $B=\\{b\\}$. Its four arrows are the two identities
and the unique maps $f:A\\to B$, $g:B\\to A$. Both round trips are
identities because each singleton has only one endomorphism. Retain the
same two objects and just $\\id_A,\\id_B,f$. This selection is closed:
a composable pair contains at most one $f$, and the other factor is an
identity. Thus it is a subcategory. The arrow $f$ is invertible in the
larger category but has no inverse in this one, since it has no arrow
$B\\to A$. This finite example needs no arithmetic beyond distinct labels.''')],
})
run('prose-pass-1-motivation-and-flow',{
'b01-subcategories-and-groupoids.tex':[('A selection must\nsurvive composition: two retained arrows cannot have a discarded composite.','A selection must\nsurvive composition: retaining two composable arrows requires retaining\ntheir composite.'),('The term does not say that all objects are isomorphic to one another.','The term describes reversibility of each arrow, without requiring an arrow\nbetween each pair of objects.')],
'b02-three-components.tex':[('Their universal tests\nwill supply a comparison; typography alone does not make them equal.','We compare them by asking whether they recover the same three arrows\nfrom every test source.'),('The three tests share the same source $X$.','The three component equations share the same source $X$; this common\nsource is what permits us to package the data into one arrow.')],
'b03-involutions.tex':[('The model will also give a concrete test source when terminal points see\ntoo little.','After checking inverses, we use this same model to find a source that\ndetects arrows even when terminal points see too little.'),('The detecting object is $D$, whereas the terminal object is $1$. Their\nroles differ.','The terminal object $1$ detects only fixed values. The exchanged pair $D$\ncan test every underlying value, as the proof has shown.')],
'b04-retracts-and-structured-equalizers.tex':[('Equalizers connect\nthis operation to a precise notion of a retained part.','To identify the retained part, we test the equation $e\\circ h=h$.\nIts universal solution will be an equalizer.'),('The subset must first be stable under the involution to be a candidate\nobject with the restricted structure.','The first step checks that agreement survives the involution. Without\nthat closure check the restricted subset would not yet be an object\nwith the required structure.')],
'b05-fibers-and-parameters.tex':[('Keeping the parameter is essential: different\nparameters may name the same output and must still remain distinct.','The projection to the parameter object records which parameter was used.\nThis matters when two parameters name the same output.'),('A pullback can isolate the inputs of a map with a specified output.','A specified output gives a condition on the input of a map: keep exactly\nthe inputs producing that output.')],
'b06-finite-intersection-laws.tex':[('We can compare two nested constructions\nby asking exactly which given representatives factor through each one.','For two nested constructions, we ask which given representatives factor\nthrough each one. The same factorization test will compare their domains.'),('Three separate witnesses to pairwise conditions\nneed not be one witness to all conditions.','Each pair has a witness, but none of the displayed labels satisfies all\nthree membership conditions.')],
})
run('prose-pass-2-concision-and-precision',{
'b01-subcategories-and-groupoids.tex':[('It introduces no new inverse formula.','The inverse formula is unchanged.'),('In particular, fullness concerns arrows between the retained objects. It\ndoes not require retaining every object.','Fullness tests arrows between the retained objects; the selection may\nstill omit other objects.')],
'b02-three-components.tex':[('The result concerns','The result concerns') ] if False else [('The two\nparenthesizations generally give different objects.','The two\nparenthesizations can give different objects.'),('Three arrows with unrelated\nsources do not constitute eligible data.','Arrows with unrelated sources cannot be used as one triple test.')],
'b03-involutions.tex':[('The proposition proves that one particular source suffices in this model.','Thus this particular source suffices in the supplied model.'),('The model will also','The model will also')] if False else [('The proposition proves that one particular source suffices in this model.','Thus this particular source suffices in the supplied model.'),('The proof identifies the extra obligation on an inverse rather than\nassuming it away.','The inverse must satisfy its own preservation equation, which the proof\nchecks explicitly.')],
'b04-retracts-and-structured-equalizers.tex':[('The two parts describe one supplied idempotent.','Both parts concern the specified idempotent.'),('For a given splitting, its section is monic by the earlier left-inverse\nexercise.','The earlier left-inverse exercise makes the section of a splitting monic.')],
'b05-fibers-and-parameters.tex':[('The second phrase names the supplied data in this section; it introduces\nno new universal property beyond that of a pullback.','The parameter construction uses the original pullback property.'),('This correspondence is a statement about this external set model,','This correspondence holds in the external set model,')],
'b06-finite-intersection-laws.tex':[('Only finitely many supplied representatives occurred in this argument.','The argument used only the displayed representatives.'),('This notation includes that particular choice. It is not a globally\ndefined operation on a set $\\operatorname{Sub}(A)$.','The notation refers to that choice; it defines no global operation on\na set $\\operatorname{Sub}(A)$.')],
})
sp=R/'author-volumes/v0/selected-sources.json';ss=json.loads(sp.read_text())
for s in ss:
 if s.get('author_breadth_unit'):s['selected_SHA256']=hashlib.sha256((R/s['selected_source']).read_bytes()).hexdigest()
sp.write_text(json.dumps(ss,indent=2)+'\n')
print('Actual prerequisite repair and two sequential prose passes recorded with exact diffs.')
