# CP40 — Chapter 5 cross-unit dependencies and B44 coverage delta

Baseline: independently reviewed CP39 source ZIP SHA256
`a445dcb4ed7f017f5b9c82534e09808d2c5d67eea30a821e38a70ecc11c1ba09`.
Scope: author's chapter-level *motivation, dependency, and overlap* check, not a complete chapter or whole-volume mathematics/literature certification.

## Why B44 belongs to Volume 0 Chapter 5

Before B44, Chapter 1 defines typed ordinary functions and composition; Chapter 2 supplies inverse-arrow equations; Chapter 5 defines categorical monomorphisms and the universal test of a supplied equalizer and then works through ordinary total-function and retract examples. It has no selected model of a partially defined function with domain-of-definition as arrow data. B44 supplies that genuinely different concrete category, then tests the **same Chapter 5** universal definitions using all permitted partial-map arrows.

It belongs after the Chapter 5 equalizer and monic material. It makes no forward reference to Chapter 6's pullbacks or Volume 1's general constructions. We keep the existing Chapter 5 reading order, append B44 after B08, and do not reorder previously reviewed work.

## Internal reading route, with dependency and motivation check

1. Chapter 1 typed functions/categories: identity and associativity will be rechecked on domains of definition, rather than assumed from total-function composition.
2. Chapter 2 inverse-arrow calculus: B44 characterizes isomorphisms as total bijections; the two inverse equations both matter.
3. Chapter 5 original monic and equalizer definitions: B44 checks monicity with partial identity tests and equalizers against **all** partial test arrows, not just pointwise set equality.
4. B04 retracts and structured equalizers: retained intact, with its original supplied-object qualifications. B44 does not re-prove idempotent splitting or any categorical completeness theorem.
5. B08 opposite categories: retained intact. B44 does not use its later dual cancellation results.
6. B44: locally supplied category of all partial maps on a **fixed nonempty finite-carrier family**, monics exactly total injections, isos exactly total bijections, and equalizers only when the external agreement carrier is retained. A one-object restricted family is shown to omit a specific equalizer.

No forward prerequisite cycle was found in this Chapter 5 source sequence. The old sections retain their selected canonical files and labels. This is a local **motivation/dependency** result, not a whole-chapter PASS and not a check of every old proof.

## Overlap and exact scope

- The finite carrier family is externally supplied; the finite subsets and partial assignments are ordinary data, not an internal power-object object, all-sets category, global size axiom, or choice principle.
- V1 Chapters 19–27 already contain relations, object-level quotients, regular image/epi/descents, coproducts and gluing: B44 establishes none of these. In particular it deliberately does **not** characterize epimorphisms in the partial-map category or claim an epi/mono factorization theorem.
- V1 Chapters 10–11 regulate global *existence* assumptions. B44 asserts an equalizer only under a supplied agreement-locus membership hypothesis and gives an explicit restricted-object failure when that hypothesis is absent.
- V2 ordinary arithmetic and V4 real analysis are unchanged. B44's motivating partial lookup/operation examples do not claim to build those later mathematics.

## New mathematics and counterchecks

- Category axioms check source-target types, exact domain of each composite, both identities, and associativity at the level of domains and values.
- Monic iff total injective: the partial identity on the map's own domain detects non-totality, and total constant endomorphisms detect non-injectivity; no singleton test carrier is required.
- Isomorphisms are total bijections, checked using both inverse equations.
- The equalizer agreement locus includes simultaneous undefinedness. Its total inclusion has a full **existence and uniqueness** verification against partial tests when retained.
- A one-object two-point partial-map category has no equalizer of the total identity and the partial identity on one point, proving that the retained-object hypothesis cannot be erased.
- Four exercises have separately stated and fully worked solutions. No source text/old labels removed.

## Literature and release limits

This file is only a **new-unit source delta** for the separate literature-review line. No page-level references were independently verified here. Lawvere–Rosebrugh full-body comparison UNKNOWN, PL09 OPEN. Foundations, global size/choice, and empty-category policy OPEN. Study remains separate; English DRAFT, no EN-STABLE, no GitHub release, no whole-book completion claim.
