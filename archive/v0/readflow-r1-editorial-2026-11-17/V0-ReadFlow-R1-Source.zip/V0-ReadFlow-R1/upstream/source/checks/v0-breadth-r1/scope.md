# Volume 0 breadth: scope and prerequisite decision, r1

## Baseline and evidence boundary

CP001, version 0, Library ID
`libfile_fde3_f-19976b6927088191ad2129ad525a24f8_383d682b1c388191a1961becbec9fb77`,
SHA256 `72d0b3c9db286adbeb67a54dc2c718e3df8aa0ec9257f83f92fef385cca1897c`,
was downloaded again in this turn. Its archive CRC passed. All 1,000 manifest
members are verified when taking the baseline comparison; every existing
manuscript/en payload member matches CP001. The 197 selected canonical hashes
match, with 63/35/60/39 inputs in Volumes 0/1/2/4. No active author build or
writing process was found. The only extra local manuscript file was a generated
Python bytecode cache. No newer prose was found in the current author tree.
The Library title search found later copies of the handoff inputs, not a new
author manuscript; this is not a claim to have inspected other workers' drafts.

The prior 97-page batch remains NOT RECOVERED. This work is new author breadth
work on actual CP001 content, not a reconstruction from that lost batch.
The eight previously adopted exact revisions remain selected and are not replayed.

All selected-source maps and all 65 chapter allocations were inventoried.
Volume 0 definition/result/example/exercise headings were inspected across all
63 inputs. Targeted bodies were read where an overlap or dependency judgment
needed them: opening/inverses, global elements, products, monoids, monicity,
pullbacks, fixed-target comparisons, intersections, inverse-image preservation
and practice, and the existence boundary. Volume 1's result headings and the
actual product conventions, arrow-test criterion and order-existence body were
checked. Volumes 2 and 4 were checked by allocated sources and chapter subjects,
not reread mathematically in full. This is a breadth audit, not a new whole-series
correctness certification.

## Reader and ownership

Starting knowledge: school algebra and ordinary function notation. Chapter 0
provides direct proof language, classical bounded-quantifier reasoning and a
conditional external finite-syntax interface. Formal metatheory is still open.
New abstract arguments use category laws and explicitly supplied constructions.
New external finite models name the carrier, operation, subset or function data
they use. They do not select ETCS, ZFC, universes or arbitrary choice globally.

| Volume | Existing chapters and responsibility | Decision |
|---|---|---|
| 0 | 0--9: language, given arrows and constructions, existence boundary | Expand within these chapters only |
| 1 | 10--28: existence requirements, construction packages, exponentials, predicates, relations, quotients, coproducts and NNO | Keep existing ownership; not missing from the series |
| 2 | 29--51: arithmetic, integers, fractions, Cauchy completion and completeness | No new prose in this batch |
| 3 | Linear Algebra I | Reserved; no manuscript claimed |
| 4 | 52--64: Analysis I | Preserve; continuation paused |

## Verified gap decisions

These are author judgments of useful breadth within the existing scope, not a
claim that a textbook requires each item or that a numerical coverage gate passed.

| ID / chapter | Actual existing coverage | Necessary extension and dependency | Status |
|---|---|---|---|
| B01 / 2 | Inverse equations, bijections, automorphisms and triangle transport | Subcategory, full subcategory, groupoid and maximal subgroupoid; verify closure under inverse composition. Supplies vocabulary for comparing which arrows a model retains. Only category laws and existing inverse composition exercise. | Write |
| B02 / 3 | Binary product definition/comparison; pairing after precomposition; terminal factor | Given triple products, swap/reassociation and component checks. Supply each intermediate product explicitly. No general finite-product existence theorem and no functor/coherence theory. | Write |
| B03 / 4 | Functions, pointed counterexample, monoids, preorders, posets, discrete categories | A low-prerequisite structure-preserving model: finite sets with a specified involution, commuting functions, bijective inverse proof, fixed global points and a two-label detecting source. Distinguishes absent global points from absent underlying elements. | Write |
| B04 / 5 | Monicity, supplied left inverse exercise, equalizer classification/practice | Retractions and idempotent splittings, equivalence with a supplied equalizer of e and identity, and explicit nonsplitting countermodel. Add involution-model mono/equalizer checks with closure hypotheses. No blanket splitting axiom. | Write |
| B05 / 6 | Pullbacks, subset model, pasting and failed converses | Fiber over a supplied parameter arrow; ordinary point and whole-family cases; involution-compatible pullback model with full universal test. No exponentials or quotient machinery. | Write |
| B06 / 7 | Binary given intersection as greatest lower representative; representative equivalence | Commutativity, idempotence, top and three-way association for individual supplied monic representatives. No set Sub(A), quotient of representatives, arbitrary intersections or union axioms. | Write |
| D00 / 0 | Proof language and finite-syntax induction are already present | Wider formal logic/metatheory is an open decision, not a missing elementary chapter to duplicate. Depth worker owns local repairs. | Preserve / OPEN |
| D01 / 1 | Typed maps, category laws, models, failed tables, full answers | No demonstrated essential omission in this pass requiring another chapter. Model breadth is addressed by B03. | Preserve |
| D08 / 8 | Comparison pullback, iteration, preservation of binary intersections, exercises including choice changes and absorption | Do not repeat these as new inverse-image theory. B06 may point back to the individual comparison calculus; no rewrite of Ch8. | Covered |
| D09 / 9 | A full finite countermodel for four existence claims; positive tests and full answers | Preserve the closing existence boundary. Further existence packages belong to Volume 1. | Covered |

Old audit G01/G04/G05/G06/G09 are stale as blanket absences: actual sources now
contain bijection equivalence/automorphism, triangle and terminal corollaries,
separate inverse equations, product-comparison practice, and proof language.
They receive specific source mappings, not a blanket declaration that the old
completeness gate is passed. G07 and G10 remain unresolved; G08 review status
stays resolved within its actual scope.

## Literature read and limits

Riehl, *Category Theory in Context*, author's second-edition manuscript at
https://emilyriehl.github.io/files/context.pdf. The local 299-page PDF matches
SHA256 `e4779f34ff0432508f1105912f39a84af3c64799b969507325c80e27c2d994dd`.
The official link was opened this turn. Pagination below is printed pagination;
the PDF viewer index is printed page + 20, verified against the page text.

| Selected body evidence actually read | Relevance and limit |
|---|---|
| Section 1.1, selected passages on pp.3--8, especially p.8, Definition 1.1.12 and Lemma 1.1.14 | B01 terminology and maximal subgroupoid; source bodies read, not contents-only |
| Section 1.1, p.5, model structures and monoid/order models | Motivation for B03; the particular involution model here is our own fully checked example, not claimed to be an item in Riehl |
| Section 1.6, selected diagram/equality and terminal passages on pp.39--45 | Context for component calculations; no claim of full functor/diagram-indexing coverage |
| Section 3.1, selected passages on pp.85--87, product/equalizer/pullback definitions and fiber (3.1.17) | B02/B05 supplied universal tests; general small diagrams and topological examples remain outside this batch |
| Section 3.2, pp.96--97, Example 3.2.14 | B04 idempotent/equalizer/retract connection. Full construction is proved locally without importing the preceding general limit theorem |
| Section 3.5, Remark 3.5.14, pp.113--114 | B03/B05 generalized-element interpretation. No Yoneda theorem or hom-set universe is silently imported |

Lawvere--Rosebrugh, *Sets for Mathematics* (2003), publisher DOI
https://doi.org/10.1017/CBO9780511755460. Only publisher metadata, contents and
previously recorded chapter page ranges are available. The official excerpt
https://assets.cambridge.org/97805218/04448/excerpt/9780521804448_excerpt.pdf
again returned HTTP503 this turn. No reproducible body was obtained. Its exact
definition, theorem, example and exercise coverage remains UNKNOWN. No FULL
coverage or per-paragraph comparison is claimed from its contents or snippets.

B06 is a locally derived extension from the actual greatest-lower-representative
theorem, not a bibliographic coverage claim. All new exercises are original
local practice with full answers; no numerical textbook quota is being filled.

## Acceptance and continuation

Each unit needs complete definitions, hypotheses, proofs, examples/counterexamples
and solutions; author mathematical/dependency check, motivation pass and two
prose passes are recorded separately. Append units at chapter ends to preserve
old statement numbers. Freeze a source checkpoint and download-verify it after
each major unit, and before long builds or visual inspection. Use the same single
author mainline and update the active source maps. Do not write over depth-worker
or template-worker files. No unverified proposal is adopted as reviewed final text.

The six units, rather than 100 pages, determine this bounded batch. Page count is
measured only after the frozen build; do not pad. A later breadth audit can add a
new justified obligation, but any volume-boundary change needs reasons and
dependencies presented to the user first. All volumes remain unfinished drafts.
