# Chapter 8 local coverage/dependency delta — CP45 B47

## Why a new, adjacent foundational unit is needed

Existing B09 supplies slice categories, the terminal slice object, monicity, and a **local** pullback-induced map for individual triangles. Chapter 6 proves individual pullbacks and pasting. B18 supplies adjunction via natural transposition; B46 provides conditional group pullbacks. The selected Chapter 8 manuscript does **not** consolidate an externally supplied pullback family into a functor, or show the adjunction of postcomposition with pullback. B47 fills exactly that interface.

## New coverage and dependency order

B09 (slice and local change of base), B18 (adjunction transposition and triangles), Chapter 6 (pullback comparison and pasting), then B47 in Chapter 8 after B46. B47 proves: for a fixed base arrow f and a genuinely given family of pullbacks, f* is a functor; comparing two supplied families gives a natural isomorphism; f! always exists; f! left adjoint f* with both naturality variables and two triangles; composable base changes compare canonically up to coherent isomorphism. Four exercises have full solutions. Finite-set nonfaithfulness and a 3-object poset missing pullback/right adjoint identify limitations.

## Explicit boundaries and risks

* Does not assume pullbacks exist for every diagram in every category, or a choice of such squares for all base arrows. The object-indexed family is supplied externally for the one chosen f. Several families are separately supplied when making composition comparisons.
* Does not build global categories of all categories or functors, dependent products, fibrations, arbitrary limits, internal quotients, subobject classifiers, internal numbers, or the dependent sum/product theory reserved for later volumes.
* V1 Chapters 10 onward treat existence and internal constructions; their bodies are not rewritten. V2 number-system work untouched, V3 reserved, V4 analysis unchanged.
* The external literature reference-to-manuscript review belongs to the independent content-refinement line; this entry is only a delta of manuscript dependencies and original proofs. No page-level literature certification is claimed.
* Chapter 8 cross-unit dependencies checked for B47 only; no whole-chapter or whole-volume completeness PASS.

Open: foundations, size, choice, empty-category, PL09, Lawvere--Rosebrugh body, Study integration, EN-STABLE, full-volume certification.
