#!/usr/bin/env python3
"""Package only current canonical inputs, generated views and necessary evidence."""
from pathlib import Path
import argparse,hashlib,json,re,zipfile
R=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('destination',type=Path);a=p.parse_args()
    paths={'config.tex','build.py','build-author-volumes.py','tools/package-author-current.py',
        'reading-v15/generate-reading.py','author-volumes/active.json','author-volumes/generate.py',
        'author-volumes/reading-guide.tex','author-volumes/cross-volume-links.tex'}
    for v in [0,1,2,4]:
        paths|={f'volume-{v}.tex',f'author-volumes/v{v}/selected-sources.json',f'author-volumes/v{v}/chapters.json',f'author-volumes/v{v}/layout.tex'}
        for s in json.loads((R/f'author-volumes/v{v}/selected-sources.json').read_text()):
            paths|={s['selected_source'],f'author-volumes/views/v{v}/'+s['logical']}
            raw=(R/s['selected_source']).read_text()
            for f in re.findall(r'\\input\{([^}]+)\}',raw):
                target=R/f
                if not target.suffix:target=target.with_suffix('.tex')
                assert target.is_file(),f
                paths.add(target.relative_to(R).as_posix())
    for folder in ['checks/v0-breadth-r1','checks/author-recovery-r2']:
        for f in (R/folder).rglob('*'):
            if not f.is_file() or '__pycache__' in f.parts:continue
            if f.suffix.lower() in {'.pdf','.zip','.png','.aux','.log','.out','.toc'}:continue
            # Retain real adoption evidence; do not duplicate supplied full bodies.
            if folder.endswith('author-recovery-r2') and 'received-author-handoff' in f.parts:continue
            paths.add(f.relative_to(R).as_posix())
    manifest={f:{'bytes':(R/f).stat().st_size,'SHA256':hashlib.sha256((R/f).read_bytes()).hexdigest()} for f in sorted(paths)}
    a.destination.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(a.destination,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(paths):z.write(R/f,'source/'+f)
        z.writestr('MANIFEST.json',json.dumps({'files':manifest},indent=2)+'\n')
        z.writestr('README.md','# Current author breadth draft r1\n\nUnpack, enter source/, and run `python3 build.py`. Requires Python3, XeTeX/TeXLive with the packages declared in config.tex, Latin Modern OpenType fonts, PyMuPDF and pypdf for validation. The driver supplies a local XeLaTeX format when the installation has package files but no prebuilt format. The build order is0,1,2,4; outputs are source/author-volumes/build/volume-N.pdf. Keep those four PDF names together for cross-volume links.\n\nThis package contains all203current selected canonical inputs, their generated reading views, nested diagrams, source maps, settings and real review/check evidence. Reading views are not canonical. The generator does not edit canonical sources or historical entries. Historical frozen sources/outputs are referenced by ID/hash in checks/v0-breadth-r1/history-references.json rather than nested as ZIPs. The full recoverable author checkpoint CP002 is separately retained.\n\nDraft only. B01--B06 and the whole volume still need independent review. Lawvere--Rosebrugh body coverage, PL09 and global policies remain open. Lost97pages remain unrecovered. Chinese paused. No completed-volume repository release.\n')
    with zipfile.ZipFile(a.destination) as z:
        assert z.testzip() is None
        for f,m in manifest.items():assert hashlib.sha256(z.read('source/'+f)).hexdigest()==m['SHA256']
    print(json.dumps({'path':str(a.destination.resolve()),'files':len(paths),'SHA256':hashlib.sha256(a.destination.read_bytes()).hexdigest(),'bytes':a.destination.stat().st_size,'nested_ZIPs':0}))
if __name__=='__main__':main()
