# CP57 — EC122-NAV-01 controlled navigation adoption (English DRAFT)

**Baseline:** exact CP56 source ZIP SHA256 `938f53ab2390dc7e0959b35e2240a213249458560fe3b8e327c81d86fac454aa`.

**Reviewed evidence:** literature crosswalk r57 / Library v63 ZIP SHA256 `323b61b04ca76b70476df93582f542f817473a8baea4c3d0b42409fe13aafbf0`; includes `review-batches/r57/EC122-NAV-01.patch`. This checkpoint adopts only that named navigation patch. The review ZIP is not nested here.

**Canonical:** `volume-revisions/author-recovery-r2/adopted/incremental-revisions/completion-v1/final/sections/122-external-completion-interface.tex`.

**Before:** `c37abafee40f47e52b5a59dadb4170b8d60a6364a08bca15f0be0b42ce72e7c3`.

**After:** `35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3`.

Canonical lines 122–123 now read:

```tex
This argument establishes the full coequalizer property of
Volume 1, Definition~\ref{def:coequalizer}. Equality on fibres, surjectivity and unique values
```

The following line, the theorem, the proof, and every exercise are unchanged. The new label resolves uniquely in the existing selected Volume 1 coequalizer section.

Only four files in the prior `source/` payload changed: the canonical EC122 file, `author-volumes/v2/selected-sources.json`, generated V2 view, and `author-volumes/source-view-manifest.json`. The four exact diffs are included under `evidence/cp57-EC122-NAV-01/diffs/`. All 249 selected source/view pairs verify and all 2,139 prior labels remain unique and unchanged. Generated volume entry files and Volume 0 content are unchanged.

This source-only checkpoint deliberately contains **no updated PDF**: CP56 Volume 0 (288 pages) is unaffected and remains a valid unchanged reference; existing Volume 2 reading PDF predates this correction and must not be labeled CP57. No Volume 2 XeLaTeX build was made, and no visual validation of a revised Volume 2 PDF is claimed.

No new B53, no other mathematical changes, and no changes to Study/peer review, foundations, size, choice, empty-category, PL09, Lawvere–Rosebrugh, or whole-volume certification.
