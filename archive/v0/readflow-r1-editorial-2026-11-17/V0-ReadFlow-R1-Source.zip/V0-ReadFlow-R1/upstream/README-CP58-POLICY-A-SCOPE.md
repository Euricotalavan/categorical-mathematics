# CP58 — POLICY-A scope working convention, controlled integration

**Base:** CP57-EC122-NAV-01, source SHA256 `2a9fbdcbfc630b8b02fd0d2313cdc8aa1d0c85fd4d2d1f4486e27b0a5c2d7ac5`.

**Review packet:** Library `libfile_fde3_f-080b92fd82dc81919f209c1aba3d3919_383d682b1c388191a1961becbec9fb77`, version 75, SHA256 `0feb6c7b04c21b18c03b4d7a8e47f13cda99332f0eaca0652f6556729ade2fd6`; considered `review-batches/r69/POLICY-A-CANDIDATE.md`, `candidate-patch-manifest.json`, `policy-wording-candidate.patch`.

**Only two canonical edits:** `volume-revisions/v0-v1/final/preliminaries/00-proof-language-I.tex` and `volume-revisions/v0-v1/final/sections/01-opening.tex`. They describe empty-category admission and external supply as an explicit working convention, without adding global choice or unrestricted comprehension. The Chapter 1 insertion expressly says this reveals assumptions, does **not** replace theorem proofs, does **not** establish a shared formal foundation, and does **not** close OPEN gates. The candidate comment `NOT ADOPTED` and the sentence `This is a layered conditional claim` are not reproduced.

**Generated metadata:** `author-volumes/v0/selected-sources.json`, the two V0 presentation views and `author-volumes/source-view-manifest.json` were regenerated via the preserved generator. The source tree differs from CP57 by **exactly six files** (two canonical plus four generated/map files), with no added/removed source paths and no changes in any mathematical theorem or exercise. `evidence/cp58-policy-A-scope/checks.json` records exact SHA256 before/after for all six. Existing 249 selected canonical/view pairs and all 2,139 unique LaTeX labels are preserved. The V2 EC122 canonical SHA256 remains `35cb1c4c98b9b1ae23fa316b2a40befc2df12825eda054d094ca1defa698dee3`.

**Reproducibility:** The prior CP57 ZIP remains unmodified and is the rollback artifact; this ZIP is an independent successor. No PDF was rebuilt. The previous 288-page V0 PDF is an older rendering and is *not* represented as a CP58 layout. All later study/layout merges require a separately reviewed patch and affected-page verification.

**Open:** foundations, unified formal realization, size, choice, empty-category formal semantics, PL09 implementation, Lawvere–Rosebrugh body, V1 and external-completion capabilities, whole-chapter and whole-volume certification remain OPEN/UNKNOWN. English DRAFT; no EN-STABLE and no GitHub completed-volume submission.

**Unrelated old Library overwrite dialog:** exact target `/CategoricalMathematics/Author/r2/categorical-mathematics-r2-cp56-nextsteps.md` (last inspected version 1). This integration does not act on that dialog or overwrite the existing file.
