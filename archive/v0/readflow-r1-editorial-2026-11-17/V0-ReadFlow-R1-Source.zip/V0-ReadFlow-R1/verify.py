#!/usr/bin/env python3
"""Verify this R1 source release manifest and frozen V0 math body; no PDF dependencies."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'MANIFEST.json').read_text())
errors=[]
for x in m['files']:
    p=R/x['path']
    if not p.is_file(): errors.append(['missing',x['path']]); continue
    if p.stat().st_size!=x['bytes'] or h(p)!=x['sha256']:
        errors.append(['mismatch',x['path']])
math=json.loads((R/'qa/READFLOW-FROZEN-MATH.json').read_text())
for f,expected in math['items'].items():
    p=R/f
    if not p.is_file() or h(p)!=expected:errors.append(['frozen-math-mismatch',f])
print(json.dumps({'release_files_checked':len(m['files']),'math_source_checked':len(math['items']),
    'errors':errors[:50],'errors_total':len(errors),'verdict':'PASS' if not errors else 'FAIL'},indent=2))
sys.exit(bool(errors))
