# V20 · Unbounded Operators, Semigroups, and Evolution

Categorical Mathematics, Chapters 258–269, English ReadFlow R1 reading edition.

`manuscript/` is the editable source. The book uses one source for each of
the twelve chapters, with the cover, preface, contents and bibliography in
separate source fragments. `paired/` contains the exact reviewed PDF. The
evidence folder records source responsibility, layout checks and the
independent whole-volume mathematical verdict.

## Verify and rebuild

Extract to a fresh directory. From the extraction root, on a system with
Python 3, XeLaTeX, the normal TeX Live LaTeX packages, and fontconfig:

```sh
python3 verify.py
python3 roles/layout_final/build.py --full --front frontmatter.tex --back bibliography.tex --preamble v20-layout-preamble.tex --name rebuild
```

The new PDF is at `roles/layout_final/runs/rebuild/build/entry.pdf`. The
adapter is configured for the project Linux TeX Live layout. The required
font files and their licenses accompany the source. The three adopted
ReadFlow R1 configuration and layout files are under `template/pinned/`.
The volume preamble supplies only the metadata and table-of-contents
adjustments recorded in the B-06 evidence. The evidence includes the exact
baseline and dependency versions.

The source ledger identifies the selected English editions and exactly
which portions were checked. Required material was written as original
exposition with full proofs, worked calculations and solved exercises.
The third-party reference books are obtained separately via their
publisher or author links in the bibliography.
