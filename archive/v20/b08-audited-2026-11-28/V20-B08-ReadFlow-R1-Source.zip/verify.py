"""Verify the byte manifest of an extracted V20 source archive."""
import hashlib
import json
from pathlib import Path


def main() -> None:
    base = Path(__file__).resolve().parent
    manifest = json.loads((base / "MANIFEST.json").read_text(encoding="utf-8"))
    if manifest["volume"] != "V20" or manifest["chapters"] != list(range(258, 270)):
        raise SystemExit("Unexpected archived volume or chapter list")
    for entry in manifest["files"]:
        relpath = Path(entry["path"])
        if relpath.is_absolute() or ".." in relpath.parts:
            raise SystemExit(f"Unsafe manifest member: {relpath}")
        path = base / relpath
        data = path.read_bytes()
        if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise SystemExit(f"Hash or length mismatch: {relpath}")
    print(f"Verified {len(manifest['files'])} recorded files ({manifest['stage']})")


if __name__ == "__main__":
    main()
