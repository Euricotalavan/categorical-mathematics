# V20 B-03 handoff

V20-B03-20261128-v1. B single Work, isolated calibration after B-01 source responsibility and B-02 scope and narrative, before the per-section B-04 author, thickening and refinement waves. The coordinator received the two exact samples and the independent mathematical receipt, resolved the two domain-wording findings, and exercised the ReadFlow R1 template.

| Representative section | Exact source SHA-256 | Exact paired PDF SHA-256 | Pages |
| --- | --- | --- | ---: |
| 260.3, deficiency spaces and the adjoint domain | `6fcb2d80aa634d8aabb5941fef97b0aab069398f967f81a7c6e5d34ad27d5492` | `5f07c48a12a18f1bb1c2173792d642e56bedfc33804ba675755ef36eceba6386` | 7 |
| 266.2, constructing a contraction semigroup | `29ebf20ca4ddd0a5488e88d29cdd518e7a6dd319ebd302da692274beb7979a45` | `cf75fe91133b608e6e78626e09ca2272b1a390a5bfc46c18684fe1e898218634` | 5 |

The independent mathematical receipt names all fixes and the revised source IDs. The coordinator inspected renderings of all twelve sample pages. The revised 260.3 build recorded one minor loose line without a loss of legibility, clipping, missing glyphs, or reference errors. The 266.2 build recorded zero diagnostics. See the build reports. The source/PDF pairing is for these samples. The book's final pairing and visual review remain B-06 responsibilities.

Retain full hypotheses, the explicit proof of adjoint-composition domain membership, the graph inner product distinction, the orthogonality and boundary computations, bounded approximant estimates independent of approximation parameters, and the reverse generator-domain inclusion. The samples show that a complete domain or limiting argument may take several pages. In B-04, cite the already established statements by precise local labels and keep only setup the reader needs. Do not make a later proof depend on an unproved prerequisite or repeat an entire prior chapter.

The exact ReadFlow template ZIP, v3, SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`, and the adapter are described in the layout receipt. The sample engineering reports record the three unchanged template files. The isolated build commands were `python3 v20/roles/layout/build.py --sample <path> --name b03-260-checked` and `... --name b03-266-evolution`.

Next, each 4-chapter expansion group writes its assigned sections to isolated chapter files. Each accepted chapter receives independent thickening and refinement before promotion to the only canonical source. The independent reviewer receives exact byte fingerprints. Chapter numbers and V18/V19 remain fixed. No approvals outside this Work are pending. The incomplete original-book reading and any source condition differences remain in the responsibility tables and OPEN records.
