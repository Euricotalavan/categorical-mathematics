# V20 limits on source verification

These items constrain original-book coverage claims. They are tracked separately from the correctness of the volume's own statements and proofs.

| ID | Location | What remains open | Actual route in V20 |
| --- | --- | --- | --- |
| S01-BODY | Hille–Phillips, 1957 revised edition | The publisher record and chapter locations are fixed. Relevant book pages remained unavailable. | Bibliography and historical orientation only. The proofs do not require unsighted Hille–Phillips pages. |
| S02-Q04-VERSION | Pazy English reprint shown in Q04 | ISBN and 1983 copyright verified. The exact physical printing reported by the host has not been independently pinned. | Publisher front matter and previews control the section and page numbering. Cross-checks use the author's English text. |
| S02-Q04-IMAGE | The Q04 searchable text and locations identified in B01 | Several formulas are OCR of original pages. Full page images and uninspected book sections are not verified. | Treat verified textual locations and explicit formula checks as separate. The chosen proof uses original derivation and verified KIT conditions. |
| S03-Q01 | Approved UNAM source copy | Server returned HTTP 503 and web retrieval timed out. | The approved Q03 scan, whose version and exact 50-page read range are fixed, supplies the S03 evidence that is used. |
| S03-SCAN | Reed–Simon VII and VIII | In Q03, printed pages 264–271 are reordered. Uninspected sections outside the selected 50-page window remain open. | Consult the exact S03-page-map.tsv and the source-differences record. Volume II coverage is not asserted. |
| AUTHOR-ROUTES | KIT and Teschl readings | The KIT proof with a real resolvent point does not handle every self-adjoint operator. Teschl's online copy is for personal use and was consulted only in selected extension/form sections. | The V18 bounded normal theorem plus V20's proved Cayley transfer gives the general case. Extension proofs track the respective closedness and form-domain hypotheses. |
| LATER | Advanced theory outside the main route | Full nonautonomous unbounded generation, nonlinear evolution, quantitative non-exponential stability, general analytic-semigroup characterization and advanced perturbation theory are outside this volume. | Limited interfaces identify named results or selected proved cases with their actual hypotheses. No later theorem is used as a hidden premise. |

The user confirmed Q01, Q03 and Q04. Copies in Q02 and Q05 did not enter the working sources. No book scans, publisher previews, OCR output or DjVu text are part of the deliverable.
