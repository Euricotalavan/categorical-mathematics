# V20 B-04 獨立精修 262–263｜r1

本輪已獨立順讀固定正文：chapter-262.tex SHA256 `10cf718fda9d6c9298335fd39327e4cdebe1e1beb5bf6569d78b8d9df08abcbb`、chapter-263.tex SHA256 `373c4e185226f8ea03db238052ecf50a906703465876a6145a05cfd74ff9f42f`。先讀正文與B01責任，再讀thick_bridge/chapter-262.md、chapter-263.md與coverage-262.md；未以其PASS代替自己的閱讀。未更改canonical正文或固定B01。模型／模式獨立可核設定回讀仍未提供，不假稱切換。

結論：所選262–263主證與安全閱讀路徑可接受，沒有新發現的數學阻塞。建議合入下列一處精確措辭修補。這是B-04精修回執，不是B-05整卷整合或B-07終審。沒有PDF、工程或全頁視檢判定。

## 精確發現

| ID | 原文位置／原文 | 影響 | 改後文字／處置 | 重核證據 |
| --- | --- | --- | --- | --- |
| RF262-01 | thm:262-compact-resolvent proof，原文“Thus there are only finitely many A eigenvectors with |lambda|<=R.” | 固定有限維eigenspace也有無限多個向量，字面數量說法不正確；上下文實際證的是按multiplicity計數有限。 | 建議替換為“Thus the sum of the dimensions of the A-eigenspaces with |lambda|<=R is finite.” | 前句K有有限個大於指定threshold的eigenvalues counted with multiplicity已給所需結論；不改定理或證明。非新數學阻塞。 |
| RF262-02 | sec:262-bounded-bridge，B01 D01/L01/T01/T02/L02/T03 | 有界連續calculus/roots是前卷重用；KIT monotone-class lemma是另一路線的輔助，不是本卷新證明。 | coverage.tsv分列REUSE與ALTERNATIVE_AUXILIARY_NOT_NEEDED，不能全標“本章已證”。 | V18 thm:243-normal-continuous-calculus、thm:244-positive-square-root與本章PVM integration路線相配。 |
| RF263-01 | lem:263-group-generator / thm:263-stone，相對B01 RS04 | 正文實際選orbit averages + two Laplace inverses，並非來源compact-smooth convolution/deficiency proof。 | 記ALTERNATIVE_FULL_PROOF，不記“已照來源證明”。 | 正反時間給兩signed range，closed graph由integral identity證，maximal adjoint域及mixed product唯一性自足，無264–266前借。 |
| RF263-02 | def:263-strong-commutation，B01 RS09 | 警告已寫；Nelson具體counterexample沒有寫。 | 記WARNING_PRESENT_COUNTEREXAMPLE_DEFERRED，沿B01既定scope保留，不冒稱例子覆蓋。 | 全Nelson construction既已延期；joint multiplication exercise只證product-domain差異，不能充當Nelson反例。 |

## 已核的實際推理

- 262以有限scalar measure與truncation證線性domain、norm identities、dense graph cuts、closedness；bounded-factor localization區分不同composition域。Cayley I-U的range恰D(A)，no atom at1而不錯說1在resolvent；inverse coordinate兩向domain inclusion及完整唯一性均有證。multiplication model轉換L2等價類、不可數direct sum中單向量countable support、separable sigma-finite結論均適當。
- 262 support inverse與approximate vectors符號配R(z,A)=(zI-A)^(-1)；compact resolvent先用positive K，避免未證compact-normal theorem，finite-dimensional invariant blocks與weighted domain充分必要均成立。threshold PVM及step error不把graph approximation誤說成operator norm approximation。
- 263 sum/product closures用simultaneous cuts，adjoint測試cut ranges給maximal domain；normality兩product domains都還原第四矩。real pushforward、power iteration、reciprocal exact range+kernel域及essential-range inverse證明皆保留必要條件。
- 263 primary sign exp(+itA)、generator+iA、Stone A=-iG前後一致。group continuity與derivative domination、Fatou反向exact域、graph continuity、classical uniqueness的moving-vector quotient均檢過。heat smoothing、energy與large-time strong limit不偷渡norm decay，兩例與solved problems計算相符。
- strong commutation四signed resolvents的Cayley signs正確；先後用bounded commutant theorem使兩PVM commute。common-domain formal commutation的警告與joint model域反例沒有被混成同一命題。

## 來源責任與依賴

coverage.tsv逐列列出本角色B01所有262/263責任（含CORE、重用、替代、optional、out/deferred、UNKNOWN），每列有實際label及定義／陳述／證明／例題分欄。沒有把未選multiplicity、sectorial、measurable-group或Nelson construction算成已做。263-E01使用equivalent examples：diagonal unitary識別continuous/classical域，real multiplication heat模型計算同一域障礙，未聲稱逐字完成原先候選的unitary multiplier例子。

依賴待主控整合：262的 thm:261-selfadjoint-resolvent 在本兩章輸入外，需與canonical261精確label核接；V18 labels由先前固定source已實讀，這輪查標號補到Ch243 continuous calculus/Ch244 roots。外卷label採texttt作精確引用，不會自動形成跨卷LaTeX hyperlink。此處未要求重寫前卷。

下一步：主控可合入措辭patch並核實受影響句，持續B04其他章及B05整合。原固定B01、不相關正文、其他凍結卷不改。若主控改數學或共同符號需退本角色核受影響範圍；單字句安全修補無須重跑整批。傳遞：共享目錄輸出並訊息送主控；持久保存及接收回執由主控記。待使用者決策：無。
