# V20 B-01 獨立精修回執／可貼交接 v2

交接 ID：V20-B01-REFINE-SPECTRAL-20261128-v2。發出：獨立精修任務 refine_spectral；接收：主控及 B-02 擴充。卷號：V20 無界算子、半群與演化，本角色258–263。狀態：本角色的逐項來源責任底表可供 B-02 固定；不是全卷 B-01 簽核、正文通過或 B-07 終審。

本次使用 B 單一 Work，B-01 對應原 A 01–02。授權依主控傳達本次使用者指示：Q01/Q03 Reed–Simon、Q04 Pazy 候選可讀，B-01–08及主審已授權；O03 作者個人用版本允許本角色個別查閱。僅建立原創定位、責任及差異紀錄，不改正文、不公開原書。模型／推理模式未取得可獨立查證之設定回讀，故不以角色名聲稱切換或 High 已核。

有效章號沿已核準備檔：V19 固定 Git 79113f78b296251f1adbfd48f89abaed0abb50d2，末章257；V20 258–269。本角色未重做該章號查核，未解凍任何前卷。分卷表v4.1、文獻表v4.1、ReadFlow R1固定模板沿主控基線；工具ZIP未改。

## 實際讀入及核對

| 輸入 | 版本／實讀範圍／結果 |
| --- | --- |
| V20-Literature-Preparation-v1.md | SHA256 e89bddf40cd38e295dd98aa2e1ba620172c907557bba89e8431f2a41dab77310；全文讀入，早先未啟動文字由本次授權接續，不當現行停令。 |
| 來源導覽v2.1 | SHA256 502e706f17c7fa91f0a7addd3fe24e2afc21065afd42888c023b9bde48b7de4b；現行入口／歷史限制已讀。 |
| A/B總規範v4 | SHA256 bb095f08c70f79ecfb84abbabf3f1350ee7f53ba9de707c917a412301bac4fea；共通、B責任及交接已讀。 |
| B單一Work v1 | SHA256 c16755a48b868b6ae1dd1704ccca1a0a61289ab8e81d32835c36acc155379e6b；任務隔離及不代簽已讀。 |
| 文獻v3 | SHA256 4546e8492dd0f4af2dfb3b4b0c148aa6a9e6edeca73ea18d75fe58ce879037b9；逐項、UNKNOWN、條件及來源定位已讀。 |
| O01 Schnaubelt Spectral Theory | 2025-07-30，125 PDF頁，1012304 bytes，SHA256 182cfcf000df4b4d29516bbe7fe8e604c83f4c5ce18cff3737c6f12fcf8b59d7。實讀印頁1–7、10–15、89–108，PDF=印頁+2；§5.2只列後置定位、未語義核讀。 |
| O02 Schnaubelt Evolution Equations | 2026-03-19，118 PDF頁，948351 bytes，SHA256 5451d43af7b329412a0d78835d76230e13e0f6cd9635b1bb1b3be01198f07791。實讀Intermezzo2印頁26–28，PDF28–30，包括closure與core。 |
| S03/Q03 Reed–Simon I | 1980 revised/enlarged，412 PDF頁，4132570 bytes，SHA256 9df2137f5d9733111246d297ba0bb25e9fad099acf55e8ab70ee67b6bd55d865。title、版權1980已核；印頁221–236、249–282共50頁已OCR並實讀，VIII頁眉已視核，ThVIII.3雙符號原圖已核。PDF頁序有錯置，不能概括+12，見S03-page-map.tsv。 |
| O03 Teschl Mathematical Methods in Quantum Mechanics | 作者公開第二版，GSM157、ISBN978-1-4704-1704-8、版權2014；作者PDF metadata2018-03-13，370頁，1784971 bytes，SHA256 ee2cfd1c9fdc41ef5a585ef8e9657dc632f92b557aeb9c052afe5164a02a2917。實讀§2.3印77–83、§2.6印91–94，另讀Lem2.4/Cor2.5印73–74；PDF=印頁+12。Th2.13/2.27關鍵式已看原圖。個人用限制已核，原檔/文字/頁圖均不入本角色交付。 |
| 已發布V18 Ch244 | 主控提供v20/reading/v18-ch244.tex，SHA256 d1f959d702463e6db372e0d3bcb90590dc2486dcd534e8792c52428e4015c7d4。實讀bounded normal multiplication/PVM、bounded Borel、唯一性與強收斂段；可核標號 thm:244-normal-multiplication、thm:244-normal-spectral-theorem、def:244-pvm、prop:244-borel-convergence。適用Git由主控統一固定，V18保留不改。 |

O01/O02原址沿準備檔作者教學頁。O03取自 https://radon.mat.univie.ac.at/~gerald/ftp/book-schroe/schroe2.pdf ，個人用，不授權再散布。S03來源只作本次獲准閱讀入口，禁止原書進公開Git交付。上述都是實際取得／閱讀證據，不能替代新正文逐項覆蓋。

## 可取輸出與證明線

本角色交付只含原創摘要與定位資料：B01.tsv v2有137筆，分章258:20、259:12、260:45、261:12、262:28、263:20；S03-page-map.tsv有50頁對照；source-differences.md記來源條件差異及新證明義務；本回執。各檔bytes/SHA256由manifest.tsv列出。共享路徑 v20/roles/refine_spectral/，主控負責隨正式可恢復交付保存及回取核驗；本機路徑不是持久送達證據。

表逐項列來源ID、印頁、PDF頁、定義／陳述／證明／例題狀態、條件、先備及擬落點。狀態SOURCE_READ只是已讀來源；所有manuscript_coverage仍為NOT_WRITTEN，不得轉成書稿已涵蓋。PARTIAL_SOURCE與ORIGINAL_PROOF_REQUIRED有實質含義，不能用候選數量抹去。

選定主證線：閉圖與graph norm → Banach/Hilbert adjoint及closure → 兩非實移位的自伴判準 → Cayley transform與deficiency延拓／semibounded form-Friedrichs（只用Hilbert Riesz及inverse-adjoint，不前借Ch262） → 套已發布V18 bounded normal PVM到Cayley unitary → 證單點1的投影為零 → 反變換推到R，截斷定義無界積分 → 證精確二次矩domain恰為D(A)、作用及唯一性 → 可測演算與unitary group → Stone smoothing-vector反向證明。

這條線包含sigma(A)=R，不沿O01僅有實預解點的特例冒稱全證。主稿Stone慣例依主控已定exp(+itA)，強生成元+iA；KIT exp(-itH)僅為來源慣例差異，須同步換號。R(lambda,A)沿(lambda I-A)^(-1)；O03相反預解符號須翻譯。形式內積採主稿first-slot linear，S03/O03的second-slot linear須明確翻譯。

## OPEN／下一步／限制

- PROOF-NEW：Cayley domain reconstruction、無界PVM唯一性、可測算子的closure/adjoint/domain law、von Neumann graph decomposition、closed form uniqueness與form-domain density均是B-04打厚的完整證明責任，精修將獨立核。來源的sketch／exercise不等於缺口已補。影響：阻其正文驗收，不阻B-02設計。
- CLASSIFY-CLOSURE：一般extension classification先對closed symmetric A述，未閉者換成closure(A)；O03印92公式不能不加條件沿用。精修／打厚負責，阻錯誤域公式上稿。
- PRIOR-ANCHORS：Ch244前卷實讀標號已核；其他V18/V19各精確先備標號仍待B-02／整合核，尤其AC、trace、weak derivative，不能僅寫「已在前卷」。
- SCOPE-DEFER：multiplicity theory、essential-spectrum細分、full Nelson construction、CCR/Weyl classification、sectorial form/calc、singular potential等已列明後置／可選；B-02必保留本卷必要warning，不自動增章或擴張PDE。
- FORMULA-OPTIONAL：O01 shift圓盤開閉／奇異勢OCR式仍未視核，其例子非主證必要，未核不得使用精確公式。核心雙符號/頁序及O03主條件已視核。
- COVERAGE：本角色並未聲稱指定來源全書已逐句驗畢；未讀範圍不算已核。後續逐實際正文落點驗定義、條件、量詞、相等及證明。

下一角色唯一階段：B-02擴充固定敘事、先備、章節及各條目責任；本角色之B-01來源工作完成至上述範圍，按主控派工續作B-04/B-05獨立精修。通過條件：擬章界與137筆責任可追蹤，新增完整證明／必要例子逐項可定位，實質卷界衝突才請使用者決定。B-07唯一最嚴格整卷終審仍由打厚承擔，精修不代簽。

唯一正文／來源PDF配對／編譯：本B-01角色未產生正文，N/A。正式ReadFlow R1基線仍為8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3，本角色無模板patch、排版或頁面QA。內容保留／工程／閱讀三層核驗尚未執行；不以索引QA冒稱它們通過。

保留不動：所有凍結卷、唯一主稿、工具ZIP、分卷/文獻表、Git及正式模板。相對v1新增S03/O03逐項定位、修正Q03亂序、解除一般延拓來源缺口；仍保留新稿證明義務與未核項。待使用者決策：目前無。

傳遞狀態：同Work已訊息告知主控，檔案已寫共享路徑；主控實讀／hash回執待記。本文存在不代表對話外已送達或接收方已讀。
