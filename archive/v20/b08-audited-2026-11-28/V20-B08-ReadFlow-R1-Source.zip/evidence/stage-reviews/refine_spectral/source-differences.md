# V20 258–263 來源差異與證明選線

| ID | 來源位置 | 差異／影響 | 固定處置與責任 |
| --- | --- | --- | --- |
| SD01 | O01 Th4.21，印105–106/PDF107–108 | 無界multiplication證明有實預解點才完整；sigma(A)=R借外部正常算子定理。 | V18 Ch244已實有bounded normal PVM，經Cayley而非假設實預解點。新無界domain步驟全證，打厚負責。 |
| SD02 | S03 ThVIII.4，印260–261/PDF272–273 | 正常resolvent路線能覆蓋所有自伴；bounded normal版本在該書VII只列練習。 | 前卷實際有完整正常譜定理，簡短精確回引；採Cayley路線，來源作交叉比對。 |
| SD03 | O01 Th4.19/4.22印103/107；S03 ThVIII.6印263–264 | 唯一性或無界積分域部分只引用／略述。 | 正文證second-moment domain、截斷收斂、精確重建、PVM唯一性；不能一句“by spectral theorem”。 |
| SD04 | S03 VIII2印255–259；VIII6印280 | 一般von Neumann延拓和Friedrichs來源實際推到第二冊X1/X3。 | O03 Th2.26/2.27印91–92與Th2.13印80補足。S03不冒稱已含一般證明。 |
| SD05 | O03 Th2.27印92/PDF104 | 對未閉symmetric A的域公式，須用closure(A)，或先假設A閉。 | 主定理先對closed A；一般情形先取closure。新graph分解由正文證，不盲套公式。 |
| SD06 | S03 ThVIII.15印278–279；O03 Th2.14印81 | S03存在證明用unbounded spectral theorem證inverse self-adjoint，放Ch260會前借Ch262；唯一性留練習。 | 改用O03 Lem2.4(iii)/Cor2.5印73–74的graph-adjoint inverse證明；Riesz構造正移位逆、證其有界自伴，再反轉。補form-domain density與唯一性。 |
| SD07 | O01 Ex4.23印107–108；S03 ThVIII.7/8印265–267 | KIT符號exp(-itH)，S03 exp(+itA)。 | 主控已定exp(+itA)、generator+iA；主稿統一此慣例，例子與Stone唯一性同步。 |
| SD08 | O01 Def1.22/Th1.24；O01 Eq4.1–4.3；S03/O03 forms | Banach線性dual transpose不共軛標量；Hilbert adjoint有共軛。S03/O03形式inner product線性第二欄。 | 主稿first-slot linear；保留不同記號、域和scalar conjugation，逐式翻譯。 |
| SD09 | O01 Def1.18，印10–11 | residual spectrum定義為nondense range，容許與point spectrum重疊。S03又另有spectral-type“continuous”定義。 | 主稿明說所用慣例；strong commutation由PVM定義，不混同formal commutator。 |
| SD10 | O01 Th4.9印94 | 此證明要求relative bound<1/2，而尖銳Kato–Rellich可到<1。 | 如選納，只宣稱本來源真正證明的較弱版本；不得悄悄強化。 |
| SD11 | S03/Q03印264–271 | 掃描八頁亂序：264→278、265→279、266→282、267→283、268→276、269→277、270→280、271→281。 | 全表逐頁列真正PDF序號，不能用一個offset；完整50頁map另檔。 |
| SD12 | O03 §2.3印78 example | stated C2 domain只有endpoint zero；敘述卻提compact support。 | 原創例子證明只用實際endpoint zero消掉boundary terms；不沿用不必要敘述。 |

## Cayley與無界域的必證清單

1. 對self-adjoint A，(A+i)從D(A)到H雙射；U=(A-i)(A+i)^(-1)為unitary。
2. I-U=2i(A+i)^(-1)，所以range(I-U)=D(A)，kernel(I-U)=0；不能因此說1不在spectrum(U)。
3. 前卷PVM的atom-eigenspace恆等式給E_U({1})=0。反變換lambda=i(1+z)/(1-z)在unit circle去掉1處為實值；該單點取任何有限值皆不改算子。
4. 原PVM經反變換pushforward仍是normalized real PVM；對每一向量以截斷／norm-square identity建未界積分，D={x: integral lambda² dmu_x finite}。
5. 證D恰為range(I-U)，在域上積分等於A；需兩向包含。唯一性可回推Cayley PVM至前卷唯一性，不能只比較形式積分。
6. 對finite spectral-a.e. Borel f以最大平方可積域建f(A)，證closed、dense、adjoint=conjugate f；等式／和／積的domain分開記，避免formal law錯用。
7. exp(+itA)全H有連續unitary orbit；經dominated difference quotient，強導數存在的向量恰D(A)，值+iA。任意H初值不得假稱classical可微。
8. Stone反向用compact-smooth time averages建dense invariant differentiability domain；兩deficiency kernels消失，再證閉包指數群等於原群，完全避免向後借半群生成定理。

## 延拓與形式的必證清單

- Closed symmetric S之D(S*)在graph Hilbert norm下分成D(S)、ker(S*-i)、ker(S*+i)的正交直和。新的graph分解是本卷證明責任，O03來源實際用Cayley分類而非寫此分解。
- Unit deficiency map給extension的domain/action；反向每個self-adjoint extension都給unit map。先處理closure(S)，零indices iff essential self-adjoint，unequal indices無self-adjoint extension。
- Nonnegative symmetric operator的energy completion注入H：對energy-Cauchy且ambient→0的序列，固定一個大index再令另一index→∞，證energy→0。這是Friedrichs closability關鍵，不可跳。
- Closed semibounded form先加正移位；Hilbert Riesz給ambient inverse，證逆有界自伴、無核且range dense，進而建對應operator。補operator-domain在form-domain稠密及唯一性。
- 區分operator core與form core；Friedrichs只對densely-defined semibounded symmetric適用，保留lower bound；它是form-compatible的特殊extension，未必是唯一extension。
