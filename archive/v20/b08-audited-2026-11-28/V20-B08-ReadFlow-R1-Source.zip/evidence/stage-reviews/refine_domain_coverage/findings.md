# V20 258–261 independent precision and source responsibility receipt

Handoff: V20-B04-B05-REFINE-DOMAINS-20261127-v1. Role: independent precision/source refinement. Plan B, B-04/B-05 (source-boundary and wording responsibilities from original A refinement), no B-07 sign-off. Canonical manuscript, prior volumes, template, tools ZIP and source tables were not edited. Model and reasoning-mode settings have no independently readable verification and are **unverified**.

## Actual intake

Read the complete four chapter drafts independently, then reread all changed 260/261 text against the earlier fixed source. Read all relevant rows of `roles/refine_spectral/B01.tsv`, `source-differences.md`, B-02 design, SOURCE-OPEN, domain outline, and independent thick receipts. The 89 relevant B-01 responsibilities (258:20, 259:12, 260:45, 261:12) are each mapped in `coverage.tsv`; inherited source-reading status is separated from actual manuscript coverage. This review does not assert a fresh read of all original source books or of the entire V18/V19 releases.

Exact reviewed source SHA256 values are in `input-hashes.json`, with matching byte snapshots in `input/`. This report records LaTeX labels where they exist and section plus prose locator for unlabelled material. Output creation and same-Work notification are delivery evidence only; receiving reader/hash acknowledgment remains for the coordinator. No external transmission capability was exercised.

## Math and reading flow

The written main proofs independently check: graph/domain completeness and permanence; weak derivative/trace and both first/second-order cores; graph projection and normal inverse; Banach transpose dual spectrum without reflexivity; Hilbert adjoint conjugations and exact differential/multiplier domains; zero-fiber double-adjoint criterion; deficiency graph decomposition; both directions of unitary extension classification; interval phase-parameter conversion and half-line obstruction; operator-energy completion, exact Friedrichs domain, general closed semibounded form representation, form-domain density and distinguished uniqueness; resolvent algebra/graph-norm analytic series, spectral boundary, nonreal and exact-distance norms, multiplication/Green/compact models and small graph perturbation.

The new form proof is mathematically adequate: injecting the completion by testing against the dense original form domain is a valid alternative to the source-difference record's fixed-index energy argument. The representation corollary proves form-density using `Ran(J*)` and injectivity of `J`; its exact domain equation pins down the associated operator. The added comparison proves Friedrichs can exceed operator graph closure, rather than merely naming the difference. The Hilbert `E*` example now explicitly has adjoint domain `{0}` and appears in 260, so the 259 source responsibility is genuinely covered later.

The dense L2 full/empty derivative models in `ex:261-dense-empty-spectrum` now prove both inverse equations, domain regularity and boundedness. They discharge the Reed–Simon responsibility separately from the earlier C[0,1] examples. The exact distance comparison, zero-parameter exception in the sign exercise, and compact self-adjoint forecast have been clarified.

The new relative-bound threshold `delta<1` is correctly proved directly from the symmetric squared-norm identity. It is an **original strengthening of the selected O01 proof**, whose actual estimate gives `delta<1/2`; the source comparison must preserve this distinction. The `delta=1`, `B=-A` example correctly proves failure of closedness on the proper domain.

## Remaining exact source-scope distinctions

| Responsibility | Reviewed state | Required disposition |
| --- | --- | --- |
| 260-TE11 | Cayley correspondence for the self-adjoint-extension problem is now fully proved, including no fixed vector1, dense inverse domain, exact action and closedness. The arbitrary non-surjective-isometry converse to a merely symmetric operator is not separately proved. | Record chosen extension-correspondence scope, or add that more general converse if intended. Do not claim the entire source theorem solely from its name. The new subsection currently lacks a stable label; `sec:260-cayley-extensions` would make mapping exact. |
| 260-TE14 | Closed symmetric A implies Cayley initial/final shifted ranges closed. Converse is not explicit at reviewed bytes. | Add: if `x_n -> x`, `Ax_n -> y` and `M+=Ran(A+i)` closed, choose `u` with `(A+i)u=y+ix`; the lower-bound bounded inverse on `M+` gives `u=x`, hence `Ax=y`. The isometry makes closedness of initial/final spaces equivalent. |
| 259-TE01 | General graph orthogonality proved; the nonspectral inverse-adjoint proof required for the form theorem is explicitly proved in260. | Treat full general inverse-adjoint identity as an unselected generalization unless it is separately added. The necessary instance is not a gap in the main proof. |
| 260-E01/E02 | Scalar evaluation and L2 derivative closure are deliberately selected alternate models. | Do not assert that source L1 evaluation-times-constant and sup-norm derivative closure retaining derivative traces have themselves been written. |
| 258-RS02 / 259-E01 / 260-TE15 | Optional position/Hermite or full shift-disc / conjugation-real results have partial alternate or no selected coverage. | Keep individual optional/deferred statuses from the table; no global blanket coverage. |

No mathematical blocker was found in the actual revised main theorem paths. The TE14 direction and TE11 generality above are source-responsibility/disposition items; their absence must not be hidden by a general pass label. They were sent immediately to the coordinator. All previously noted missing form and Hilbert recognizer rows are now covered by actual revised text.

## OPEN, next action, checks and restrictions

SOURCE-OPEN remains in force: Hille–Phillips unsighted pages unknown; Pazy printing/image limitations unresolved; original uninspected ranges not covered; Reed–Simon II not inspected and not claimed. S03 page-order mapping and source convention differences remain inherited source evidence. This review does not replace exact prior-anchor verification, layout/PDF checks or whole-volume integration.

Next action: coordinator records the few explicit route dispositions and/or applies the short TE14 addition, then obtains exact-byte independent thick recheck. Any changed draft hash requires refreshing the relevant table row evidence, not redoing sound proofs. B-07 alone decides final strict whole-volume acceptance. Passing conditions for this receipt: all 89 source responsibilities retain individual status, actual statement/proof/example anchors remain locatable, generalizations are not attributed to narrower sources, and substantive open items stay visible. No frozen volume, numbering table, template or other volume is reopened by this report.

Files: `coverage.tsv` (89 rows), `input-hashes.json`, `input/chapter-*.tex` fixed reviewed snapshots, `findings.md`. These are original review material and manuscript snapshots, not source-book scans/OCR/images. Source/PDF pairing and durable archive are coordinator responsibilities; this report does not claim them completed.
