# V20 B-04 independent thickening receipt · Chapter 266

Reviewed every section and solution of `v20/roles/expand_evolution/drafts/chapter-266.tex`. SHA-256 `61f4c00f1208453efb20c1f6bb412bfc0c7c8ee41a398fe6c193d52acf0b1da8`, 31,705 bytes, 740 lines. Scope and conventions checked against the V20 B-02 design. This receipt applies to the isolated frozen draft. Chapter 265 citations still require integration verification. Later additions require independent review of their own exact bytes.

**Verdict.** The mathematical content checked passes independent B-04 audit. Four clarifications below are appropriate when incorporating the already requested development. The text separates the one-power counterexample from the contraction case and the closure version from the closed-operator version. See the source locations below for the independent checks.

| Frozen lines | Check |
| --- | --- |
| 3–42 | From the inclusion (A\subset B), surjectivity of the smaller graph's shifted equation provides a comparison solution and injectivity of the larger shifted equation gives equality of vectors and domains. The norm distinctions for the two growth bounds are correct. |
| 43–215 | For (x\in D(A)), (J_nx-x=R(n,A)Ax) gives convergence, and the uniform norm bound gives extension to all (X). Consistency uses (A_nx=J_nAx) on (D(A)) without assuming (Ax\in D(A)). Exponential expansion is uniformly contractive, the commutation identity yields the Duhamel difference estimate, and density extends uniform strong convergence on bounded time intervals. Moving-vector limits establish the law. The integral identity gives (A\subset G), and the existing semigroup's independent Laplace inverse gives a common resolvent point and exact equality. |
| 217–294 | The negative diagonal operator is dense and closed on the stated weighted domain. The coordinate inverse maps onto that domain in the required sense, and the norm is attained on the first coordinate. The compact-time estimate follows by taking one approximant to its strong compact-time limit. The `k^4` weight and nonconvergence in operator norm are correct. |
| 296–384 | The Gamma-kernel integral carries a single (M), and all powers give a common bound on the entire series for (S_n), including the zeroth term. The (M^2) estimate controls the approximant difference, the shift preserves the domain, and exact generator equality follows from a shared positive resolvent parameter. The (M=1) reduction to the first power is valid. |
| 386–424 | The triangular multiplication operator is closed on the full domain shown. All rational coefficients needed for the inverse and its multiplication by (m) are bounded at every fixed (\operatorname{Re}z>0). At real `lambda > 0` the supremum of `|s|/(lambda²+s²)` is `1/(2 lambda)`. Along a fixed vertical line the norm is at least `n/a²` by a test function with value one at (s=n). If any semigroup existed, its exponential bound and the necessary half-plane bound would contradict this. The example does not merely preclude a single proposed global bound. |
| 426–534 | The norming-functional existence quantifier is correct on a general Banach space. Finite-dimensional support functionals at (x-t_jAx), compact extraction and Hahn–Banach extension prove equivalence with the norm inequality. Open/closed continuation proves surjectivity for every positive shift from one, using the uniform resolvent bound locally. The graph vertical-axis test uses the norm inequality on (x_j+u/\lambda) followed by `j → ∞`, `lambda → ∞`, then density. |
| 536–594 | The two Lumer–Phillips versions make distinct conclusions on the original operator and its closure. Closedness in the onto case follows from the everywhere-defined bounded inverse. The norm estimate turns approximating shifted-range data into a graph limit in the dense case. The finite-support diagonal example witnesses a proper graph extension. |
| 596–629 | The sign in `lambda u - u' = f` and the terminal condition at infinity lead to the upper-tail exponential kernel. Derivation uses bounded continuous integrands and yields a continuous derivative with decay, including a right derivative at zero. The translation semigroup satisfies strong continuity on `C0([0,∞))`; the right-shift derivative agrees with the proposed action on its domain, and the range argument identifies the whole domain. |
| 631–740 | All six remaining solved exercises checked: orbit renorming already uses an evolution, finite Jordan matrix powers and transient bound, the both-endpoint derivative hyperplane obstruction, Banach transpose density criterion, unbounded norms of the bounded approximants, and the energy sign after shifting. |

## Clarifications for the next revision

| Lines | Reason and proposed correction |
| --- | --- |
| 18–23 | Make the lemma's type stand alone. Begin “Let (A:D(A)\subset X\to X) and (B:D(B)\subset X\to X) be linear operators, with (A\subset B).” |
| 548–550 | Write the exact positive shift in the shifted version of the theorem. For (B=A-\omega I), take `lambda0 > omega` and explicitly identify `(lambda0-omega)I-B = lambda0 I-A`. The solution at lines 732–739 already does this correctly. |
| 633 | The equivalent norm exercise starts from a known semigroup and uses orbits only. A title such as “An equivalent norm for an existing semigroup” matches the solution. |
| 728 | Ask for “the resolvent bound on the real axis supplied by this argument.” The proof establishes an upper bound without equality in general. |

Chapter 265 should supply generator structure, uniqueness and the Laplace formula under the exact hypothesis used here, with the three cited labels. The term `rho(A)` for a real Banach space should retain the real-parameter meaning where appropriate, independently of any optional complexification. The systematic proof steps, counterexample and stationary boundary models provide substantive depth. The planned bounded perturbation proof and a worked application could deepen this scope if added with the same exact domain discipline.

## Responsibility locations in this draft

| B-01 item suffix | Exact draft location and coverage |
| --- | --- |
| 01D | L77–88, L91–110. The two compositions are used on their respective domains. |
| 02S, 02P | L90–110 and L326–332 establish convergence under the generation theorem's dense-domain hypotheses. The nondense auxiliary variant is still a scope difference. Its proof consists of approximating in the closure of the domain and testing the same strong convergence on Ax. |
| 03S, 03P | L18–30. |
| 04S, 04P | L301–371. |
| 05S, 05P | L57–206 and L373–384. |
| 06E | L388–424. |
| 07E | L596–629. Reflection gives the coordinate convention of the source's negative half-line. |
| 08D | L426–446. |
| 09S, 09P | L448–487. |
| 10S, 10P | L489–534. |
| 11S, 11P | L538–562 and the shift at L571–572. |
| 12S, 12P | L538–573. |
| 13E | L583–594 uses finite sequences rather than a smooth-function derivative to exhibit a densely defined dissipative restriction that fails closedness. L671–691 gives the distinct dense closed dissipative case where the range is not dense. |
| 14S | L693–707, using the Chapter 259 transpose. |
| 15E | Optional L² translation-closure example is outside this draft. See the continuous-function model in L596–629. |
| 16S | Group and Stone interface are not a result in this chapter version. Stone is owned by Chapter 263. |
| 21S, 22S, 23S | Same mathematical roles as 05S, 11S, and 04S, respectively. Pazy page and imaging qualifications remain those in the B-01 receipt. |
| 24P | The direct Yosida route stays in the main proof. The solved orbit norm in L633–650 starts from an existing semigroup. It does not claim the stationary renorming argument used by Pazy. |

## Delta review · expanded revision

Independently reviewed the delta from the baseline above to SHA-256 427656bb1eba61443d06d1f15ea2bf37eafbc3cec577d2d0b5a74d52ae3aa5c4. The four requested baseline clarifications are applied. The added nondense lemma distinguishes \(\overline{D(A)}\) from \(D(A)\) and proves convergence of \(A_nx=J_nAx\) exactly when \(Ax\) lies in the closure, since every \(J_nAx\) lies in the domain. Thus B01 02S/P has its general scope accounted for.

The Dyson norm estimates retain the correct \(M^{j+1}\) factor and exponential weight. Strong continuity with moving vectors and operator-norm summation on compact time intervals justify the Volterra equation. The restart identity and factorial iteration prove the semigroup law. The averaged force tends to \(Bx\) on a fixed domain vector, giving the generator extension. For real \(\lambda>\omega+M\|B\|\), multiplication of the exact factors of \(\lambda I-(A+B)\) proves the bounded inverse into \(D(A)\). The common resolvent argument identifies the full generator domain. The rank-one model satisfies the stated positivity denominator, weighted-domain inverse and sharp available upper decay estimate. The remainder and commuting-product exercises are mathematically sound.

**Independent delta verdict: PASS.** Two optional text clarifications were passed to the coordinator: the common resolvent parameter can be any real \(\lambda\) above the threshold, and the commuting-product derivative difference is \(T(t)(e^{tB}-I)x/t\to Bx\). Neither changes the theorem or estimates.
