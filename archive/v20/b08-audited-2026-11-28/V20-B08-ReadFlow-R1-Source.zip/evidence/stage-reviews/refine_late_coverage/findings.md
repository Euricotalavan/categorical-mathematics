# V20 B04/B05 264–269 精修覆蓋與整卷接合回執

交接ID：`V20-B04-B05-LATE-COVERAGE-r1`。角色：獨立精修／來源責任覆蓋與順讀接口核對。方案：V20 B單一Work，B-04→B-05支援；不代替B-07唯一打厚終審。接收：主控已透過共享工作區指定本任務；本回執僅回主控，未另向外傳送。未改canonical正文、章序、工具ZIP、書目或其他卷。

**結論：本輪264–269正文、證明、例題與所有解答均已實讀；所列精確版本未發現新的數學錯誤。265及269兩個B05增補也已逐差異核對，其原先範圍問題可關閉。來源的UNKNOWN與刻意不採的替代例／證路仍保留。**

## 唯一正文與精確版本

|章|實讀檔案|SHA256|
|---|---|---|
|264|`v20/roles/expand_bridge/drafts/chapter-264.tex`|`cfe22c8db43a6d0cb62fa5a5c97c85b8f20239926a303fbbcd44494212614b20`|
|265|`v20/engineering/b05-content/chapter-265.tex`|`e7c6cf65836ab99e61cdfbc39fe83b2b75cf0eb2bb191b4d487ee0fcdf59311d`|
|266|`v20/roles/expand_evolution/drafts/chapter-266.tex`|`325786f2fa0ca0e90071ebcd48b110939bbd89631b56e5f515680cfddb110798`|
|267|`v20/roles/expand_evolution/drafts/chapter-267.tex`|`f4fff0f971453c16d2bf7892e6f1a92489a25d4bab367e4fca2836a985c76db4`|
|268|`v20/roles/expand_evolution/drafts/chapter-268.tex`|`947a04813918fd716e91712c1a08bd794f8b56692ac84f4b8ca4d46f984addec`|
|269|`v20/engineering/b05-content/chapter-269.tex`|`79d9654a1c2556a47e89e3f52f341571784b075754981e024d7cd02cd6ab2b36`|

265先完整讀入角色稿`e13421359864402a90f13f4411234cbb0ca385006a70a1247d014d789c802664`，269先完整讀入角色稿`c1e03caf73547c84287b74d9806ce3b7b121a9bec62f5bba5793d5a6de9c602d`，再逐行核B05唯一新增段；diff只含下表兩個增補。因此本回執適用B05上述兩個hash，不把舊角色稿當新主稿。其餘四章未在本輪後續改動。

## 覆蓋、條件與證據

`coverage.tsv`承接原266–269的90列，再加入264–265逐條責任及本輪新增深段。現有150個落點列，對應B01全部117個不同責任ID；沒有遺漏ID。每列另列條件、定義／陳述、證明、例題、替代證路、來源UNKNOWN及target的實讀hash。列數不等於全部外書材料已採或整卷終審通過；DEFERRED/OUT/替代例仍照實標記。

|位置|獨立核對結果|
|---|---|
|264 基礎與先備|半群時間量詞、群逆、UBP取得局部界後再證左右連續、增長inf未必達到、原範數與改範數、有限p/L∞及C0的差異、nilpotent、乘子exact norm均成立。向量Riemann積分／closed graph interchange／orbit averages提供265實需的先備。新增profile段的L1質量集中與C0 kink反例可核；七題解答正確。|
|265 生成元|最大右差商域、density先於closedness、雙向rescale域、classical唯一性、雙逆Laplace與single-M冪、graph core、全部translation精確域／符號／boundary kernel均成立。七題解答獨立核過。|
|266 生成定理|全冪單一M、Yosida compact-time強極限、共同ρ點識別全部域；norming functional存在量詞；LP onto與dense-range closure結論分清。有界擾動Volterra半群律、Neumann domain、rank-one不保域及非稠密Yosida iff條件均正確；題解含remainder與commuting product可核。|
|267 ACP|閉區間／正時端點、state-norm適定、core反向識別、triangular反例、positive gap的wave能量空間與精確域均一致。新增initial layer上下界、backward range與不適定、wave全power hierarchy及嚴格指數／log門檻獨立演算成立；所有題解正確。|
|268 外力|Bochner construction與graph measurability、triangle joint measurability、L1連續及資料估計、integrated equivalence完整。classical兩條路及較弱Af∈L1升級均成立。bounded norm-continuous A(t)的Picard/factorial/composition/雙偏導、chronological pulses及forced polynomial正確；所有題解正確。|
|269 穩定|subadditive limit/radius含nilpotent與−∞；heat Fourier completeness、H2域及sharp norm；general inclusion的雙factorization、bounded及self-adjoint equality；Jordan完整spectrum/domain/exact norm與fixed growing state；uniform/periodic heat forcing所有係數與constant均可核。所有題解正確。|

## 本輪新舊問題的處置

|ID／位置|原範圍或影響|改後文字／精確落點與重核證據|狀態|
|---|---|---|---|
|B01 `V20-265-12E`|原角色稿只有wrong-inflow完整例，無邊界full spectrum與非稠密失敗尚缺精確對應|B05 `ex:265-two-obstructions`：明列L2 unrestricted H1 derivative全平面eigenvalues；C[0,1] initial-trace derivative所有shift可逆卻domain不稠密。定點讀261的C例及`ex:261-dense-empty-spectrum`，實核其inverse/sign/domain；加本章`prob:265-wrong-boundary`，三種失敗均有落點。|CLOSED於265 B05 hash|
|舊EV-B04-F02／B01 `V20-268-24S`|舊稿只graph continuous，Pazy較弱Af∈L1未收|現有`prop:268-integrable-graph-upgrade`：f continuous、a.e.在域、strong measurable Af∈L1。closed interchange得Av為L1卷積且連續，criterion給closed-interval classical。triangular bump實核。|CLOSED於268所列hash；scope表已更新|
|舊EV-B04-F03／B01 `V20-269-25S`|原稿只f→0及常力，未列一般limiting force|B05 `cor:269-limiting-force`明列eventual essential-sup ‖f−g‖→0；q=−A^-1g在域，subtraction後force f−g，early/late split成立。假設保留local L1，無須在早期全域有界。|CLOSED於269 B05 hash|
|舊EV-B04-F01／`prop:269-bounded-spectral-mapping`|V18先備需要真實正文核實|再次定點實讀243 homomorphism、power-series及holomorphic mapping，hash `540fa7247f2daf4b2caf3d71f50564bc02ee76497bdd4e756bc4de3f5e767cb7`。正文概稱V18可由該節支持；精確section引用屬可選文字改善。|先備CLOSED，非必要修改|
|舊EV-B04-F04|267新增深段舊回執未完整核|本輪整章實讀含initial layer/backward/hierarchy，hash明列。|CLOSED於267所列hash|

## 已核順讀與依賴影響

- 264→265：`thm:264-vector-integral`、`prop:264-closed-integral`、`eq:264-shift-integral`先建立，再在265用差商得integrated vector。密度與閉性無循環。
- 265→266：`thm:265-generator-structure`、`thm:265-generator-uniqueness`與`thm:265-laplace-resolvent`先給必要性和single-M；266只在已構造semigroup後用Laplace識別域，不預支生成定理。
- 266→267：先得diagonal與LP工具；267 mild需既有generator，wellposedness反向用265 invariant-core，未把graph-norm依賴替換state-norm依賴。
- 267→268：classical端點規則沿用；268在L1前先建Bochner，再以primitive classical uniqueness證integrated唯一性。新增bounded非自治與一般changing-unbounded-domain明確分界。
- 268→269：stable forced response沿用同一L1 mild/data估計；equilibrium由0∈ρ(A)先落域再代入，B05 limiting-force是已證衰減命題的data差分推論。

另定點讀入258 interval calculus與second-order trace/norm（hash見json），確有有限p弱導數／AC／trace及H2圖範數證據；263的`lem:263-group-generator`、`thm:263-stone`定點實讀，故原Stone接口UNKNOWN可縮至已核該接口，沒有宣稱整263終審。

## OPEN／UNKNOWN及可保留的定界

**沒有新增需先修才能繼續B06的語意OPEN。** 仍保留來源層UNKNOWN：Hille–Phillips正文未讀；Q04 host的printing statement、web-only PDF offset與未影像覆核公式；未因本輪正文自足證明而冒稱原來源已全讀。未重做已知來源擷取。

scope表照實區分：265 moving-vector採semigroup specialization；265 invariant-core採Laplace graph proof代source時間平均；266 source Cc1 derivative restriction改c00 negative diagonal；266 Pazy純resolvent改範數證路未採；268 rough translation例改unitary sequence；269 Lp∩Lq反例改完整Jordan direct sum、periodic C-space例改two-sided ell2；269 energy命題顯式採Hilbert，Banach一般shift工具已在266。這些不是已證結論錯誤，也不冒稱原具體例逐字覆蓋。

eventual norm-continuity full mapping、Datko、dichotomy、point/residual/sun-dual、polynomial/weak general stability、外插與a.e.強解仍後置；coverage修正舊表將269 optional mapping寫成COVERED_ADAPTED的過寬標籤為DEFERRED_EXPLICIT。bounded nonautonomous已新增自足證明，並不解除一般unbounded非自治的後置。

## 交接與檔案清單

可取檔案：本目錄`coverage.tsv`、`findings.md`、`input-hashes.json`。json固定本輪唯一正文與定點先備hash，來源B01與前輪coverage hash亦在內。實際模型／High設定本子任務無獨立查證接口，標為未核實，不以角色文字聲稱切換。

下一步：主控可用上述265/269 B05精確候選及其餘同hash章接續B05整合／B06排版。接收方先核檔案及hash；任一文字變更僅重核受影響delta與接口，不能套本回執到新hash。排版R1模板採納與數學覆蓋分列；本任務未改模板、未聲稱PDF QA或工程build通過。後續唯一打厚終審與修後複核仍必要；PDF及來源須在工程輸出後配對固定。

通過條件：同版source責任落點與依賴不回退，工程版本可恢復且hash/PDF配對，B07唯一打厚全卷終審／修後複核通過後才按授權封存。禁止重做凍結卷、恢復舊三官結案、以來源列數或本回執代終審、另立第二正文，或因本輪讀規範而啟動其他卷。
