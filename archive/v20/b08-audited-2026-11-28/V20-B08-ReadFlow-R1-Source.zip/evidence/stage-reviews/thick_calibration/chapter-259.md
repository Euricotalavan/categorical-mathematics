# Chapter 259 independent B-04 receipt

## Intake

Read all of roles/expand_domains/drafts/chapter-259.tex as revised before this review, 459 lines, 21,270 bytes, SHA-256 7acc4af3b00d7a712c70dc2a6373115b1f655b19cf37650d896ec7a5c096deec. The updated product-adjoint hypothesis and earlier terminology were checked to be present on this version. Read the actual V18 §239.1 Riesz representation in book/manuscript/ch239.tex from the fixed prior release ZIP. Local mathematics and scope are substantially sound. The following typing and cross-reference edits need recheck.

## Section review

| Section | Findings on the fixed source |
| --- | --- |
| 259.1, lines 9–80 | Quantifying the representing functional makes the ambient bound usable and the representing value unique. Closedness follows by limits in the original functional identity on the primal domain. The nonzero scalar rule preserves both domain and action. The zero-scalar exception is modelled with the same original dense domain. The finite-dimensional ambiguity and the \(\ell^p\) coordinate-domain test are valid. |
| 259.2, lines 82–150 | The two conjugate-linear Riesz maps give a linear transported adjoint. Each test and its scalar is on the correct side of the pairing. The product inclusion now quantifies that \(B\) and \(BA\) are densely defined, with \(A\) already dense. This suffices even though the domain of the displayed product of adjoints can be small. The symmetric/self-adjoint/skew-adjoint definitions precede the example. The maximal diagonal adjoint requires exactly \(\bar a y\in\ell^2\), and the signs for \(a_n=in\) check. |
| 259.3, lines 152–184 | Orthogonality to the graph gives the representing vector \(-h\) in the first component, and annihilation of the range gives the zero adjoint value. Closing the range is needed for the converse orthogonal identity. The scalar shift uses \(\bar z\) and a single underlying Hilbert space. The \(1/n\) diagonal is a valid dense nonclosed range counterexample. |
| 259.4, lines 186–254 | Necessity obtains \(H^1\) from compactly supported tests, with the sign verified under first-variable linearity. Necessity of the zero trace for the maximal derivative uses both independent endpoint tests, and sufficiency follows by integration by parts. The same mechanism gives the one-endpoint exchange and same-phase twist because \(e^{i\theta}\overline{v(1)}=\overline{v(0)}\). The minimal derivative and the twisted extension have the asserted distinct domains. |
| 259.5, lines 256–284 | The finite-\(|a|\) cuts determine the adjoint value and recover global \(L^2\) membership from \(z\). The converse uses a direct representing identity. See D259-1 for an inner-product term that needs the existing cutoff. |
| 259.6, lines 286–361 | Defines the unbounded resolvent locally before use, with bijectivity onto the ambient space and exact range \(D(A)\) for its inverse. If \(R\) exists in the primal, both identities for \(R'\) use the correct domains. In the converse, Hahn–Banach norm testing with \(g=Bf\) gives a lower bound. Closedness of \(zI-A\) gives closed range, and injectivity of \(zI-A'\) separately gives dense range. Thus the proof needs no reflexivity or theorem of Chapter 261. Hilbert transport of the same statements conjugates both scalar and spectra. See D259-2 for precise statement type. |
| 259.7, lines 363–452 | Product-domain strictness is valid: \(AB=I\) but \(B^*A^*=I|_{D(A)}\). For nonzero \(\gamma\), the adjoint condition is \(v(1)=\bar\gamma^{-1}v(0)\); symmetry requires \(|\gamma|=1\), which makes the domains equal. The shift shows why primal injectivity alone does not yield dense range. The raw test-function adjoint agrees with the closed zero-trace realization's adjoint. The multiplication test vectors have the claimed decay, and the last norm inequality uses the bounded everywhere defined adjoint to control the primal action on its original domain. |

## Defects and scope follow-up

| ID | Fixed source location and wording | Impact | Requested revision |
| --- | --- | --- | --- |
| D259-1 | Lines 270–276 require \(\langle x,z-\bar a y\rangle=0\) during the proof of global square-integrability of \(\bar a y\). | The uncut second factor need not yet belong to \(L^2\). Its restricted pairing is valid and is all that the proof needs. | Write \(w_N=1_{E_N}(z-\bar a y)\in L^2\) using \(|a|\le N\) on \(E_N\). Use \(\langle x,w_N\rangle=0\) for \(x\) supported in \(E_N\), then choose \(x=w_N\). |
| D259-2 | Lines 346–351 state the resolvent corollary for a “Hilbert-space operator.” | Chapter 259 often permits distinct source and target Hilbert spaces, while this corollary needs a spectrum on one complex space. | State “a closed densely defined operator on a complex Hilbert space \(H\).” This is the exact setting used in the proof. |
| E259-1 | Line 378 prints \(-i,d/dt\) inside the exercise. | A punctuation comma in the operator formula can be read as separating expressions. | Typeset \(-i\,d/dt\). |

The original product-adjoint clause needed a dense \(D(B)\) premise even when \(D(BA)\) is dense. The reviewed SHA has that hypothesis explicitly at lines 113–115. The closed-span and Hilbert graph proof directions need no padding.

B-01 records non-density of an adjoint domain, and 259 presently says enough to avoid asserting density but derives no such example. A useful worked contrast is the closed maximal diagonal \(Ax=(nx_n)\) on \(\ell^1\). Testing coordinates and using \((\ell^1)'=\ell^\infty\) gives \(D(A')=\{b\in\ell^\infty:(nb_n)\in\ell^\infty\}\), whose norm closure is \(c_0\). This yields a closed densely defined primal with non-norm-dense Banach transpose. The distinct Hilbert nonclosable example should remain in Chapter 260, where the relation between adjoint density and closability is proved. The proposed Ch258 graph-projection example would be new content. The diagonal product comparison should remain here because it already establishes a genuine strict adjoint inclusion.

## Handoff

Return for the local corrections and a check that the B-01 adjoint-domain non-density responsibility has a worked location in 259 or 260. Recheck the exact amended source; later 261 must introduce no conflicting definition of the resolvent. The section review does not confer a whole-volume pass or modify the canonical source.
