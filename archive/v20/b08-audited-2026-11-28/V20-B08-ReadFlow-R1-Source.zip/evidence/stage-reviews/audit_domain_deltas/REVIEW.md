# V20 independent B-04 delta audit, Chapters 258–261

I matched the prior independent receipts and their fixed snapshots before reading the changes. This is a mathematics recheck of the displayed hashes and affected dependencies. It is not the B-07 whole-volume decision.

## Chapter 258

Reference accepted from the prior independent delta review at SHA-256 `10eb4518d387bf85006ed7b91a5ceceef151ae5613cf4014976c19dd11e592b3`. The current bytes match that receipt. New uses of the graph-space normal equation and second-order trace closure were checked in the dependent chapters where applicable.

## Chapter 259

Current exact SHA-256 `dc9c213b70b40b601fc9ad45468279a3967d51f3fdb9df7ec2143e0f4e316ff5`. Compared with the fixed independently read v1 snapshot and read each changed section. **PASS.**

- The closed maximal diagonal on \(\ell^1\) is densely defined by finite sequences. Testing its transpose on coordinate vectors gives the necessary boundedness of \((nb_n)\). A bounded \((nb_n)\) in turn represents the pairing on every vector in the maximal domain by absolute summability. Finite sequences lie in the transpose domain and every member tends to zero, so its norm closure is exactly \(c_0\). Weak-star approximation by coordinate cuts is valid by absolute convergence against each \(\ell^1\) vector. The example does not use a Hilbert closability criterion for a Banach transpose.
- Graph projection from the verified preceding chapter gives the weak normal system. Conjugation places the test \(Av\) in the first slot. Ambient continuity in \(v\) gives exactly \(Au-g\in D(A^*)\) before applying \(A^*\). On the product domain, the converse by pairing gives uniqueness. For \(u=Cf\), the real scalar equality \(\|u\|^2+\|Au\|^2=\langle f,u\rangle\) proves boundedness and the \(1/2\) image estimate by completing the square. The mixed identity with \(v=Ch\) establishes self-adjointness and positivity of the everywhere-defined inverse. The derivative examples land in \(H^2\) with the correct separate Dirichlet and Neumann traces.
- The maximal multiplication proof now pairs only with the truncated square-integrable factor. The spectrum/adjoint statement explicitly uses one complex Hilbert space. The derivative problem has corrected operator typography.

## Chapter 260

Current exact SHA-256 `1f77b2a62835970dd55e0e4f36bb13835acd33f3bbbacc31e7c232b21d6358eb`. Read the expansion against the independently reviewed v1 and read the final added adjoint example. **PASS.**

- Point evaluation on the continuous representatives in \(L^2(0,1)\) is densely defined. A potential adjoint value represents the scalar endpoint pairing on every continuous input. Unit tents with vanishing \(L^2\) norms force that scalar to be zero. Density makes the representing vector for zero uniquely zero. This also gives the actual non-dense Hilbert adjoint domain requested in the source map.
- The Cayley isometry has closed initial and final ranges with the stated, correctly signed deficiency complements. An extension unitary has no fixed nonzero vector because \(\operatorname{Ran}(I-W)\) contains \(D(A)\). On this range the inverse transform is well-defined, densely defined and symmetric by the mixed pairing expansion. Its two shifts are onto, and the explicit everywhere-defined bounded inverse of one shift gives closedness by swapping graph coordinates. The prior two-range criterion applies. Composing with the ordinary Cayley transform recovers the self-adjoint extension and its exact domain.
- The endpoint argument now explains all dimensions of endpoint subspaces, including the zero and full cases. The half-line closed-graph proof patches the locally absolutely continuous representatives before taking the trace at zero. All less-routine momentum signs agree with the existing first-slot convention.
- The positive shifted form defines a Hilbert inner product before completion. Its inclusion is injective exactly when the Cauchy-sequence test holds. The tents are form-Cauchy but have nonzero limiting norm and ambient image zero, giving a genuinely nonclosable form. The norm equivalence arguments make the definitions shift independent.
- The general closed semibounded form representation correctly starts with a complete form space. The operator domain, identified in that space, is \(\operatorname{Ran}J^*\), which is form dense by injectivity of \(J\). The operator action and uniqueness are exactly the Riesz domain equation. Restricting another self-adjoint extension to the completed Friedrichs form domain lets the pairing with \(D(A)\) extend continuously to the entire form core closure. This proves operator inclusion, hence equality by maximal symmetry. The added Dirichlet example gives strict extension beyond the graph closure, including the alternative direct integration-by-parts estimate and trace contradiction.
- The source note observes the inspected book locations and retains the unread primary-source boundary.

## Chapter 261

Current exact SHA-256 `65c3070900dba65069131a78b9759a7e1025b434c84bb82f9b092b4814a80e15`. Compared with the prior independently read v1 and checked that the last change names the defined Chapter 262 section. **PASS.**

- Both new derivative realizations are closed and dense by the established weak derivative and single endpoint trace facts. The variation-of-constants integral is absolutely continuous and norm bounded on \(L^2\). Its weak derivative belongs to \(L^2\) and its initial trace is zero. Both inverse equations hold on the required spaces. The maximal realization loses the trace and acquires the nonzero eigenvectors \(e^{zt}\) for every complex \(z\), so the two spectral claims hold even for dense domains.
- The resolvent norm bound has the exact equality condition because the self-adjoint spectrum is closed and real. The bounded-operator prior-volume citations identify the dependencies used in the nonempty-spectrum proof. The reference to `sec:262-compact-resolvent` resolves and limits the claim to self-adjoint operators.
- The exact nonreal norm identity of Chapter 260 gives \(\|AR(it,A)\|\le1\). The perturbed inverse criterion therefore applies to both imaginary signs for the stated threshold and exact domain. Closedness and symmetry then imply self-adjointness by the rescaled two-range test. At relative bound one, the symmetric choice \(B=-A\) preserves only the proper original dense domain for the zero action. Truncations of \((1/n)\) verify failure of closedness as claimed.
- The Green exercise qualifies its change-of-sign claim at nonzero spectral parameters and treats the equality of the exponentials at zero separately.

All four assigned source hashes are clear for the B-05 dependency handoff. Primary-source gaps remain as explicitly scoped. No canonical file was edited during this review.
