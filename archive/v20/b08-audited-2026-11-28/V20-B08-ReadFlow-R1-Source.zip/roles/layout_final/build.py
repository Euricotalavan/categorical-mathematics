#!/usr/bin/env python3
"""V20 build adapter; pinned ReadFlow files remain unchanged.

Examples:
  python v20/roles/layout/build.py --fixture
  python v20/roles/layout/build.py --sample /absolute/path/sample.tex --name b03
  python v20/roles/layout/build.py --chapter 258
  python v20/roles/layout/build.py --full --front frontmatter.tex --back bibliography.tex
"""
from pathlib import Path
import argparse, hashlib, json, os, re, shutil, subprocess
from xml.sax.saxutils import escape

HERE = Path(__file__).resolve().parent
V20 = HERE.parents[1]
PINNED = V20 / 'template/pinned/V0-ReadFlow-R1'
SHA = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    m = p.add_mutually_exclusive_group(required=True)
    m.add_argument('--fixture', action='store_true')
    m.add_argument('--sample', type=Path, action='append')
    m.add_argument('--chapter', type=int, choices=range(258,270))
    m.add_argument('--full', action='store_true')
    p.add_argument('--source', type=Path, default=V20/'manuscript')
    p.add_argument('--name')
    p.add_argument('--front', type=Path)
    p.add_argument('--back', type=Path)
    p.add_argument('--preamble', type=Path)
    p.add_argument('--allow-diagnostics', action='store_true')
    a = p.parse_args()
    source = a.source.resolve()
    name = a.name or ('fixture' if a.fixture else 'sample' if a.sample else f'chapter-{a.chapter}' if a.chapter else 'full')
    if not re.fullmatch(r'[A-Za-z0-9_-]+',name): p.error('Invalid build name')
    # Explicit mode prevents preparation from accidentally compiling manuscript files.
    if a.fixture:
        paths=[HERE/'fixture/layout/study/smoke.tex']
    elif a.sample:
        paths=[x.resolve() for x in a.sample]
    else:
        paths=[source/f'chapter-{n}.tex' for n in ([a.chapter] if a.chapter else range(258,270))]
    extras={k:((source/v) if not v.is_absolute() else v).resolve() for k in ['front','back','preamble'] if (v:=getattr(a,k))}
    for f in paths+list(extras.values()):
        if not f.is_file(): p.error(f'Missing explicitly requested input: {f}')
    root=HERE/'runs'/name
    if root.exists():
        # Retain older runs; unique suffix is recorded rather than overwriting evidence.
        n=2
        while (HERE/'runs'/f'{name}-{n}').exists(): n+=1
        root=HERE/'runs'/f'{name}-{n}'
    work=root/'layout/study';out=root/'build';runtime=HERE/'runtime'
    for d in [work,root/'layout/shared',out,runtime]:d.mkdir(parents=True,exist_ok=True)
    for f in ['layout/study/config.tex','layout/study/readflow-layout.tex','layout/shared/readflow-base.tex']:
        shutil.copy2(PINNED/f,root/f)
    snapshots=root/'inputs';snapshots.mkdir()
    copied=[]
    for i,f in enumerate(paths):
        q=snapshots/f'{i:02d}-{f.name}';shutil.copy2(f,q);copied.append(q)
    extra_copies={}
    for k,f in extras.items():
        q=snapshots/f'{k}-{f.name}';shutil.copy2(f,q);extra_copies[k]=q
    texinput=lambda f:r'\input{'+f.as_posix()+'}\n'
    if a.fixture:
        # The fixture is already a complete TeX document.
        shutil.copy2(paths[0],work/'entry.tex')
    else:
        pre=r'''\documentclass[11pt,oneside,openany]{book}
\usepackage{mathtools}
\input{config}
\providecommand{\square}{\mdlgwhtsquare}
\renewcommand{\CurrentVolume}{20}
\renewcommand{\EditionLabel}{V20 / ReadFlow R1}
\hypersetup{pdftitle={Categorical Mathematics - Volume 20},pdfsubject={Chapters 258--269; ReadFlow R1}}
'''
        if 'preamble' in extra_copies:pre+=texinput(extra_copies['preamble'])
        pre+='\\begin{document}\n'
        if 'front' in extra_copies:pre+='\\frontmatter\n'+texinput(extra_copies['front'])
        pre+='\\mainmatter\n\\setcounter{chapter}{'+str((a.chapter or 258)-1)+'}\n'
        pre+=''.join(texinput(f) for f in copied)
        if 'back' in extra_copies:pre+='\\backmatter\n'+texinput(extra_copies['back'])
        pre+='\\end{document}\n';(work/'entry.tex').write_text(pre)
    env=os.environ.copy()
    env['SOURCE_DATE_EPOCH']='1795737600';env['FORCE_SOURCE_DATE']='1'
    env['TEXMF']='{/usr/share/texmf,/usr/share/texlive/texmf-dist,/etc/texmf}'
    env['TEXMFDBS']='';env['TEXMFVAR']=str(runtime/'texmf-var');env['TEXMFCONFIG']=str(runtime/'texmf-config')
    env['TEXINPUTS']=os.pathsep.join([str(work),str(source),str(snapshots),*[str(f.parent) for f in paths],''])
    fonts=HERE/'dependencies/fonts';env['OPENTYPEFONTS']=str(fonts)+'//'+os.pathsep
    cfg=runtime/'fonts.conf'
    cfg.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><include ignore_missing="yes">/etc/fonts/fonts.conf</include><dir>'+escape(str(fonts))+'</dir><cachedir>'+escape(str(runtime/'font-cache'))+'</cachedir></fontconfig>')
    env['FONTCONFIG_FILE']=str(cfg)
    fmt=runtime/'format';fmt.mkdir(exist_ok=True);env['TEXFORMATS']=str(fmt)+os.pathsep
    if not (fmt/'xelatex.fmt').exists():
        cmd=['xetex','-ini','-etex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-jobname=xelatex','-output-directory='+str(fmt),'xelatex.ini']
        s=subprocess.run(cmd,cwd=work,env=env,text=True,capture_output=True)
        (runtime/'format-generation.txt').write_text(s.stdout+s.stderr)
        if s.returncode:raise RuntimeError((s.stdout+s.stderr)[-7000:])
    prev=None
    for run in range(1,7):
        cmd=['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder','-output-directory='+str(out),'entry.tex']
        s=subprocess.run(cmd,cwd=work,env=env,text=True,capture_output=True)
        (out/f'pass-{run}.txt').write_text(s.stdout+s.stderr)
        if s.returncode:raise RuntimeError((s.stdout+s.stderr)[-7000:])
        state=[SHA(out/('entry.'+e)) if (out/('entry.'+e)).exists() else '' for e in ['aux','toc','out']]
        if state==prev and run>=2:break
        prev=state
    else:raise RuntimeError('Auxiliary state did not converge')
    log=(out/'entry.log').read_text(errors='replace')
    hard=re.findall(r'Missing character:.*|Undefined control sequence.*|LaTeX Warning: Reference.*|LaTeX Warning: There were undefined.*|.*multiply-defined.*|.*destination with the same identifier.*',log)
    over=re.findall(r'Overfull \\[hv]box[^\n]*|Package fancyhdr Warning[^\n]*',log)
    rec={'build_root':str(root),'mode':'fixture' if a.fixture else 'sample' if a.sample else 'chapter' if a.chapter else 'full','passes':run,'hard_diagnostics':hard,'overfull_or_header_diagnostics':over,'underfull_diagnostics':re.findall(r'Underfull \\[hv]box[^\n]*',log),'template_files':[{'path':f,'sha256':SHA(root/f)} for f in ['layout/study/config.tex','layout/study/readflow-layout.tex','layout/shared/readflow-base.tex']],'inputs':[{'original':str(f),'snapshot':str(q),'sha256':SHA(q)} for f,q in zip(paths,copied)],'extras':{k:{'original':str(extras[k]),'snapshot':str(q),'sha256':SHA(q)} for k,q in extra_copies.items()},'pdf':str(out/'entry.pdf'),'pdf_sha256':SHA(out/'entry.pdf'),'status':'ENGINEERING_DIAGNOSTICS' if hard or over else 'ENGINEERING_PASS','visual_status':'NOT_YET_INSPECTED','mathematical_status':'NOT_REVIEWED_BY_BUILD'}
    (root/'build-report.json').write_text(json.dumps(rec,indent=2)+'\n')
    print(json.dumps(rec,indent=2))
    if (hard or over) and not a.allow_diagnostics:raise SystemExit(1)

if __name__=='__main__':main()
