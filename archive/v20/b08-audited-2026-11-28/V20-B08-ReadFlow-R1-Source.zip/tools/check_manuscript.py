"""Report chapter, reference and exercise integrity for the V20 source."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re


def inspect(directory: Path, complete: bool) -> dict:
    paths = {n: directory / f"chapter-{n}.tex" for n in range(258, 270)}
    seen = {}
    errors = []
    refs = []
    metadata = {}
    for n, path in paths.items():
        if not path.is_file():
            if complete:
                errors.append(f"Missing Chapter {n}")
            continue
        raw = path.read_bytes()
        original = raw.decode("utf-8")
        body = re.sub(r"(?<!\\)%[^\n]*", "", original)
        counts = Counter(re.findall(r"\\begin\{([A-Za-z*]+)\}", body))
        end_counts = Counter(re.findall(r"\\end\{([A-Za-z*]+)\}", body))
        if counts != end_counts:
            errors.append(f"Chapter {n}: unmatched environments")
        if len(re.findall(r"(?m)^\s*\\chapter\{", body)) != 1:
            errors.append(f"Chapter {n}: expected one numbered chapter command")
        if re.search(r"\\(?:setcounter|addtocounter)\{chapter\}", body):
            errors.append(f"Chapter {n}: unexpected chapter counter mutation")
        if counts["problem"] != counts["psolution"]:
            errors.append(f"Chapter {n}: problem/solution count mismatch")
        for label in re.findall(r"\\label\{([^}]+)\}", body):
            if label in seen:
                errors.append(f"Repeated label {label!r} in Chapters {seen[label]} and {n}")
            seen[label] = n
        refs.extend((n, label) for label in re.findall(r"\\(?:ref|eqref|pageref|autoref)\{([^}]+)\}", body))
        metadata[str(n)] = {
            "bytes": len(raw),
            "sha256": sha256(raw).hexdigest(),
            "sections": len(re.findall(r"(?m)^\s*\\section\{", body)),
            "examples": counts["example"],
            "proofs": counts["proof"],
            "solved_exercises": counts["psolution"],
        }
    missing_refs = [{"chapter": n, "label": label} for n, label in sorted(set(refs)) if label not in seen]
    if complete:
        errors.extend(f"Chapter {ref['chapter']}: undefined reference {ref['label']!r}" for ref in missing_refs)
    return {"errors": errors, "chapters": metadata, "labels": len(seen), "references": len(refs), "pending_references": missing_refs}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--complete", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = inspect(args.directory, args.complete)
    report = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.write_text(report)
    else:
        print(report, end="")
    raise SystemExit(bool(result["errors"]))
