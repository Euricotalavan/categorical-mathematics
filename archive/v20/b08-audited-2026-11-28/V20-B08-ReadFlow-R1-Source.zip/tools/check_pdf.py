"""Check the completed V20 reading PDF's navigation and physical text bounds."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re

import fitz


def inspect(path: Path) -> dict:
    with fitz.open(path) as document:
        names = document.resolve_names()
        page_count = len(document)
        chapters = []
        bad_links = []
        off_page_text = []
        empty_pages = []
        links = Counter()
        pages_with_text = {}
        expected = list(range(258, 270))
        for level, title, page, destination in document.get_toc(simple=False):
            match = re.match(r"^(25[89]|26[0-9])\s", title.strip())
            if level == 1 and match:
                number = int(match[1])
                chapters.append({"chapter": number, "title": title, "pdf_page": page})
            if not 1 <= page <= page_count:
                bad_links.append({"bookmark": title, "page": page})
        for i, page in enumerate(document, 1):
            blocks = page.get_text("blocks")
            text = [b for b in blocks if b[6] == 0 and b[4].strip()]
            if not text:
                empty_pages.append(i)
            pages_with_text[i] = " ".join(page.get_text().split())
            for block in text:
                if block[0] < -1 or block[1] < -1 or block[2] > page.rect.width + 1 or block[3] > page.rect.height + 1:
                    off_page_text.append({"page": i, "box": list(block[:4])})
            for link in page.get_links():
                kind = link.get("kind")
                if kind == fitz.LINK_GOTO:
                    links["internal"] += 1
                    if not 0 <= link.get("page", -1) < page_count:
                        bad_links.append({"page": i, "link_xref": link.get("xref")})
                elif kind == fitz.LINK_NAMED:
                    name = link.get("nameddest", "")
                    if name and name not in names and not 0 <= link.get("page", -1) < page_count:
                        bad_links.append({"page": i, "named_destination": name})
                    links["named"] += 1
                elif kind == fitz.LINK_URI:
                    links["external"] += 1
                else:
                    links["other"] += 1
        bad_chapter_starts = [
            c for c in chapters if f"CHAPTER {c['chapter']}" not in pages_with_text[c["pdf_page"]]
        ]
        return {
            "path": path.name, "sha256": sha256(path.read_bytes()).hexdigest(),
            "pages": page_count, "chapters": chapters,
            "chapter_order_ok": [c["chapter"] for c in chapters] == expected,
            "chapter_start_text_flags": bad_chapter_starts,
            "bad_links": bad_links, "link_counts": dict(links), "named_destinations": len(names),
            "off_page_text": off_page_text, "empty_pages": empty_pages,
        }


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = inspect(args.pdf)
    report = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.write_text(report)
    else:
        print(report, end="")
    issues = (
        not result["chapter_order_ok"] or result["chapter_start_text_flags"] or result["bad_links"]
        or result["off_page_text"]
    )
    raise SystemExit(bool(issues))
