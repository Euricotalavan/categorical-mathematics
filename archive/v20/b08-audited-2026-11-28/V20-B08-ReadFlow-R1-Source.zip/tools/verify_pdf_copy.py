"""Confirm that retained and delivered V20 PDFs carry the same reading content."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json

import fitz


def pixels(page: fitz.Page) -> str:
    return sha256(page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False).samples).hexdigest()


def compare(original: Path, reading_copy: Path) -> dict:
    differences = {"geometry": [], "text": [], "pixels": [], "links": [], "page_labels": []}
    with fitz.open(original) as raw, fitz.open(reading_copy) as received:
        if len(raw) != len(received):
            raise ValueError("The two PDFs have different page counts")
        for i, (a, b) in enumerate(zip(raw, received), 1):
            if a.rect != b.rect:
                differences["geometry"].append(i)
            if a.get_text() != b.get_text():
                differences["text"].append(i)
            if pixels(a) != pixels(b):
                differences["pixels"].append(i)
            links_a = [{k: v for k, v in item.items() if k not in {"xref", "id"}} for item in a.get_links()]
            links_b = [{k: v for k, v in item.items() if k not in {"xref", "id"}} for item in b.get_links()]
            if links_a != links_b:
                differences["links"].append(i)
            if a.get_label() != b.get_label():
                differences["page_labels"].append(i)
        toc_equal = raw.get_toc() == received.get_toc()
        destinations_equal = raw.resolve_names() == received.resolve_names()
    return {
        "raw_sha256": sha256(original.read_bytes()).hexdigest(),
        "received_sha256": sha256(reading_copy.read_bytes()).hexdigest(),
        "pages": i,
        "outlines_equal": toc_equal, "named_destinations_equal": destinations_equal,
        "different_pages": differences,
        "reading_content_equal": toc_equal and destinations_equal and not any(differences.values()),
    }


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("original", type=Path)
    parser.add_argument("reading_copy", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = compare(args.original, args.reading_copy)
    serialized = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(serialized)
    else:
        print(serialized, end="")
    raise SystemExit(not result["reading_content_equal"])
