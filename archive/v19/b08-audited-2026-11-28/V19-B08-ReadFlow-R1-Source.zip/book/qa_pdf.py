#!/usr/bin/env python3
"""Render and diagnose a fixed PDF; record actual human/model visual review separately.

Preparation never means content or visual acceptance. Geometry/density are locators.
"""
from pathlib import Path
import argparse,csv,datetime,hashlib,json,math,re,statistics
import fitz
from PIL import Image,ImageDraw

MM=72/25.4
EXPECTED=(190*MM,260*MM)
LEFT=27*MM; RIGHT=(190-27)*MM+.5*72/72.27
BODY_TOP=23*MM; BODY_BOTTOM=(260-21)*MM

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def page_set(text):
 out=set()
 for part in text.split(','):
  part=part.strip()
  if not part:continue
  if '-' in part:
   a,b=map(int,part.split('-',1));out.update(range(a,b+1))
  else:out.add(int(part))
 return sorted(out)
def ranges(numbers):
 out=[]
 for n in sorted(set(numbers)):
  if out and n==out[-1][-1]+1:out[-1].append(n)
  else:out.append([n])
 return ','.join(str(x[0]) if len(x)==1 else f'{x[0]}-{x[-1]}' for x in out)

def prepare(a):
 pdf=Path(a.pdf).resolve();out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
 digest=sha(pdf);identity=out/'identity.json'
 if identity.exists() and json.loads(identity.read_text())['pdf_sha256']!=digest:
  raise SystemExit('Output directory belongs to another PDF. Use a new output directory; preserve review history.')
 doc=fitz.open(pdf)
 if a.source_root:
  source_root=Path(a.source_root).resolve();source_files=[]
  for folder in ['manuscript','layout']:
   for path in sorted((source_root/folder).rglob('*.tex')):
    source_files.append({'path':str(path.relative_to(source_root)),'bytes':path.stat().st_size,'sha256':sha(path)})
  write(out/'source-inventory.json',{'source_root':str(source_root),'pdf_sha256':digest,'files':source_files,'note':'Records current source identity. The B05 freeze and clean-build log must establish the authoritative pair.'})
 write(identity,{'pdf':str(pdf),'pdf_bytes':pdf.stat().st_size,'pdf_sha256':digest,'pages':len(doc),'created_utc':now(),'dpi':a.dpi})
 rows=[];flags=[];links=[];fonts={};toc=doc.get_toc(simple=False)
 named_destinations=doc.resolve_names()
 chapter_starts=[]
 for level,title,page,dest in toc:
  if level==1:
   m=re.match(r'^\s*(?:Chapter\s+)?(24[6-9]|25[0-7])(?:\s|[.:])',title)
   if m:chapter_starts.append({'chapter':int(m.group(1)),'title':title,'start_page':page,'bookmark_level':level})
 for i,page in enumerate(doc):
  pn=i+1;spans=[];lines=[]
  for block in page.get_text('dict')['blocks']:
   if block['type']!=0:continue
   for line in block['lines']:
    lines.append(line)
    for s in line['spans']:
     if s['text'].strip():spans.append(s)
  def flag(kind,s,**extra):
   flags.append({'page':pn,'kind':kind,'text':s.get('text','')[:180],'bbox':[round(x,3) for x in s.get('bbox',[])],**extra})
  if abs(page.rect.width-EXPECTED[0])>.8 or abs(page.rect.height-EXPECTED[1])>.8:
   flags.append({'page':pn,'kind':'unexpected-page-size','actual':[page.rect.width,page.rect.height]})
  for s in spans:
   x0,y0,x1,y1=s['bbox']
   if x0<-.5 or y0<-.5 or x1>page.rect.width+.5 or y1>page.rect.height+.5:flag('text-outside-physical-page',s)
   # Furniture sits above 50 bp or below 690 bp; a body glyph crossing 686 bp
   # is a locator for footer collision, not an automatic visual verdict.
   if 50<y0<690 and y1>BODY_BOTTOM+4:flag('body-near-or-beyond-bottom',s)
   if 50<y0<690 and (x0<LEFT-4 or x1>RIGHT+4):flag('body-horizontal-extent',s)
   if s.get('color')==0xffffff and 50<y0<690:flag('white-body-text',s)
   if '\ufffd' in s['text']:flag('replacement-character',s)
  body=[s for s in spans if 50<s['bbox'][1]<690]
  text=page.get_text();plain=''.join(s['text'] for s in body)
  if '??' in plain:flags.append({'page':pn,'kind':'possible-unresolved-reference-mark','detail':'Literal ?? in extracted body text; compare source/log.'})
  body_lines=[l for l in lines if 50<l['bbox'][1]<690 and ''.join(s['text'] for s in l['spans']).strip()]
  chars=sum(not c.isspace() for c in plain)
  if not body:flags.append({'page':pn,'kind':'no-extracted-body-text'})
  if body and max(s['bbox'][3] for s in body)<BODY_TOP+150:flags.append({'page':pn,'kind':'short-body-page','detail':'May be legitimate chapter end/frontmatter; inspect full unit.'})
  if chars>2350:flags.append({'page':pn,'kind':'high-text-density-locator','chars':chars})
  for item in page.get_links():
   rec={'source_page':pn,'kind':item.get('kind'),'xref':item.get('xref'),'from':[round(v,3) for v in item['from']]}
   if item['kind'] in (fitz.LINK_GOTO,fitz.LINK_NAMED) and ('page' in item or 'nameddest' in item):
    destname=item.get('nameddest');rec['named_destination']=destname
    resolved=named_destinations.get(destname) if destname else None
    if destname and resolved is None:rec['error']='unresolved-named-destination'
    target=item.get('page',resolved.get('page',-1) if resolved else -1);rec['target_page']=target+1
    if resolved and resolved.get('page')!=target:rec['error']='named-page-mismatch'
    if not 0<=target<len(doc):rec['error']='invalid-internal-page'
    point=item.get('to')
    if point is not None:
     rec['to']=[point.x,point.y]
     if target>=0 and target<len(doc) and not (fitz.Rect(doc[target].rect)+(-5,-5,5,5)).contains(point):rec['warning']='internal-destination-outside-page'
   elif item['kind']==fitz.LINK_URI:rec['uri']=item.get('uri')
   elif item['kind']==fitz.LINK_NAMED:rec['name']=item.get('name')
   else:rec['detail']='Nonstandard link type: inspect if relevant.'
   links.append(rec)
  for f in page.get_fonts(full=True):
   xref,ext,typ,name,resource,enc,*rest=f
   if str(xref) not in fonts:
    try:embedded=bool(doc.extract_font(xref)[3])
    except Exception:embedded=None
    fonts[str(xref)]={'xref':xref,'extension':ext,'type':typ,'name':name,'embedded':embedded}
  rows.append({'page':pn,'page_label':page.get_label(),'body_nonspace_chars':chars,'body_line_count':len(body_lines),'body_bbox':[round(min(s['bbox'][0] for s in body),3),round(min(s['bbox'][1] for s in body),3),round(max(s['bbox'][2] for s in body),3),round(max(s['bbox'][3] for s in body),3)] if body else None,'chapter_markers':re.findall(r'CHAPTER\s+(24[6-9]|25[0-7])',text)})
  if a.render:
   path=out/'pages'/f'page-{pn:04}.png';path.parent.mkdir(exist_ok=True)
   page.get_pixmap(matrix=fitz.Matrix(a.dpi/72,a.dpi/72),alpha=False).save(path)
 # Fall back to the actual visible chapter opening when bookmark titles omit numbers.
 if len(chapter_starts)!=12:
  visible=[]
  for row in rows:
   if row['chapter_markers']:
    for ch in row['chapter_markers']:visible.append({'chapter':int(ch),'title':'Visible chapter-opening marker','start_page':row['page'],'bookmark_level':None})
  if len(visible)==12:chapter_starts=visible
 chapters=[]
 for n,x in enumerate(chapter_starts):
  x=x.copy();x['end_page']=chapter_starts[n+1]['start_page']-1 if n+1<len(chapter_starts) else len(doc);chapters.append(x)
 navigation_issues=[]
 expected=list(range(246,258));actual=[x['chapter'] for x in chapters]
 if actual!=expected:navigation_issues.append({'kind':'chapter-sequence','expected':expected,'actual':actual})
 for level,title,pn,dest in toc:
  if not 1<=pn<=len(doc):navigation_issues.append({'kind':'bookmark-target-invalid','title':title,'page':pn})
 report={'pdf_sha256':digest,'created_utc':now(),'scope':'Automated geometry, extraction, font and navigation locators; not visual or mathematical acceptance','page_count':len(doc),'page_metrics':rows,'flags':flags,'fonts':list(fonts.values()),'links':links,'link_errors':[x for x in links if x.get('error')],'bookmarks':[{'level':x[0],'title':x[1],'page':x[2]} for x in toc],'chapters':chapters,'navigation_issues':navigation_issues,'named_destination_count':len(named_destinations),'invalid_named_destinations':[{"name":name,"destination":dest} for name,dest in named_destinations.items() if not 0<=dest.get('page',-1)<len(doc)]}
 write(out/'engineering.json',report)
 with (out/'page-metrics.csv').open('w',newline='') as f:
  fields=['page','page_label','body_nonspace_chars','body_line_count','body_bbox','chapter_markers'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 sheets=[]
 if a.render:
  cols=a.columns;per=a.per_sheet;thumbw=700;labelh=28;th=math.ceil(thumbw*EXPECTED[1]/EXPECTED[0]);sheetrows=math.ceil(per/cols)
  for first in range(1,len(doc)+1,per):
   last=min(first+per-1,len(doc));canvas=Image.new('RGB',(cols*thumbw,sheetrows*(th+labelh)), '#E8E8E8');draw=ImageDraw.Draw(canvas)
   for off,pn in enumerate(range(first,last+1)):
    with Image.open(out/'pages'/f'page-{pn:04}.png') as im:
     im=im.convert('RGB');im.thumbnail((thumbw,th),Image.Resampling.LANCZOS);x=(off%cols)*thumbw;y=(off//cols)*(th+labelh);canvas.paste(im,(x,y+labelh));draw.text((x+12,y+7),f'PDF physical page {pn} / label {rows[pn-1]["page_label"]}',fill='black')
   path=out/'sheets'/f'pages-{first:04}-{last:04}.png';path.parent.mkdir(exist_ok=True);canvas.save(path)
   sheets.append({'first_page':first,'last_page':last,'path':str(path.relative_to(out))})
 write(out/'render-index.json',{'pdf_sha256':digest,'rendered_pages':len(doc) if a.render else 0,'pages_dir':'pages','sheets':sheets,'reviewed_pages':0,'note':'Rendering is not review. Use record only after actually viewing images.'})
 if not (out/'review-ledger.json').exists():write(out/'review-ledger.json',{'pdf_sha256':digest,'records':[]})
 flagged=sorted({x['page'] for x in flags});print(json.dumps({'pdf_sha256':digest,'pages':len(doc),'flags':len(flags),'flagged_page_ranges':ranges(flagged),'internal_link_errors':len(report['link_errors']),'navigation_issues':navigation_issues,'sheets':len(sheets),'output':str(out)},ensure_ascii=False,indent=2))

def record(a):
 out=Path(a.out);ident=json.loads((out/'identity.json').read_text());ledger=json.loads((out/'review-ledger.json').read_text());pages=page_set(a.pages)
 if any(p<1 or p>ident['pages'] for p in pages):raise SystemExit('Invalid page range')
 if ledger['pdf_sha256']!=ident['pdf_sha256']:raise SystemExit('Review identity mismatch')
 ledger['records'].append({'utc':now(),'kind':a.kind,'pages':pages,'method':a.method,'reviewer':a.reviewer,'note':a.note});write(out/'review-ledger.json',ledger)
 print('Recorded actual review for pages',ranges(pages))

def summary(a):
 out=Path(a.out);r=json.loads((out/'engineering.json').read_text());l=json.loads((out/'review-ledger.json').read_text());n=r['page_count'];vis=set();read=set()
 for x in l['records']:
  if x['kind']=='visual':vis.update(x['pages'])
  if x['kind']=='continuous-reading':read.update(x['pages'])
 result={'pdf_sha256':r['pdf_sha256'],'pages':n,'visually_reviewed_pages':len(vis),'not_visually_reviewed':ranges(set(range(1,n+1))-vis),'continuous_reading_pages':len(read),'not_continuously_read':ranges(set(range(1,n+1))-read),'chapter_progress':[dict(x,visual_reviewed=sum(p in vis for p in range(x['start_page'],x['end_page']+1)),continuous_read=sum(p in read for p in range(x['start_page'],x['end_page']+1))) for x in r['chapters']],'automatic_flags_require_disposition':len(r['flags']),'link_errors':r['link_errors'],'navigation_issues':r['navigation_issues'],'verdict':'No acceptance inferred. Every flag needs disposition; B07 alone decides mathematical acceptance.'}
 write(out/'review-progress.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))

def main():
 p=argparse.ArgumentParser();s=p.add_subparsers(dest='command',required=True)
 q=s.add_parser('prepare');q.add_argument('--pdf',required=True);q.add_argument('--out',required=True);q.add_argument('--source-root');q.add_argument('--render',action='store_true');q.add_argument('--dpi',type=int,default=110);q.add_argument('--columns',type=int,default=2);q.add_argument('--per-sheet',type=int,default=4);q.set_defaults(func=prepare)
 q=s.add_parser('record');q.add_argument('--out',required=True);q.add_argument('--pages',required=True);q.add_argument('--kind',choices=['visual','continuous-reading','zoom-detail'],required=True);q.add_argument('--method',required=True);q.add_argument('--reviewer',default='layout role');q.add_argument('--note',required=True);q.set_defaults(func=record)
 q=s.add_parser('summary');q.add_argument('--out',required=True);q.set_defaults(func=summary)
 a=p.parse_args();a.func(a)
if __name__=='__main__':main()
