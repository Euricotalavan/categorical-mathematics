# V19 排版準備交接

【交接】
交接ID／文案版本／日期時間：V19-R1-PRE-B06-ENGINE-v1／v1／2026-11-27 UTC。
發出角色／接收角色／對話連結：行文排版→本Work統籌；agent訊息已可送達，非另開Work；對話URL未核實。
卷號卷名／階段／狀態：V19, Locally Convex Spaces, Distributions, and Integral Equations；B單一Work；B06之前的工程準備完成，未開始正式B06，未宣稱B05整合或B07終審。
授權／禁止事項／凍結：僅準備正式R1引擎、依賴、作者接口與可丟棄試片；不得提前修改書稿、移植V0正文、改卷界、替代內容官或重開其他卷。
模型及推理模式：本子代理實際模型／High設定未核實，不宣稱切換；內容及樣式證據按實際操作列。
有效基線：本卷邊界與分卷表以統籌固定件為準，排版此時未接收B05完整基線；前卷末章245與本卷246–257依統籌指定，Git章號適用commit仍待B06正式回執列入。正式模板Git 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3；Library保存v3；ZIP 7007679 bytes，SHA256 5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732，CRC通過。
檔案manifest：provenance/prep-manifest.json 逐檔列用途對應路徑／bytes／SHA256；僅當前準備工程版本，尚無本卷數學正文來源/PDF配對。主要入口 AUTHOR-INTERFACE.md、build.py、verify.py、layout/study/v19.tex、v19-local.tex；原R1三檔與歷史build/verify/manifest另於baseline/保留。字型dependencies/fonts與licenses完整，SHA記font-manifest.json。B03固定數學樣文為qa/pre-b06/b03-body.tex，不是唯一正式正文。
來源PDF配對／編譯：`python book/build.py --entry smoke --clean`、`--entry calibration --clean`、`--entry b03 --clean`；XeLaTeX私有格式、fontconfig及指定字型；無shell escape。三份試片PDF位於build/<entry>/<entry>.pdf，build日誌與每份PDF SHA在qa/build-<entry>.json。正式v19須等作者12個chapter檔出現，預設入口為v19，輸出book/v19.pdf。
完成證據：smoke含全部要求的標準數學環境、公式及連續246→247編號，3頁實際逐頁視檢；calibration為1040純英文詞，3頁實際逐頁視檢；b03為固定Volterra樣文，Chapter253，3頁實際逐頁視檢。全部正向樣本兩輪收斂，零缺字、未解析引用、overfull與underfull。負向negative確實因壞引用及238.50313pt超寬返回失敗，不作成品通過。
相對上次變更／保留：全新V19薄接口與建置器；原R1三檔逐位元保留，字級、行距、幾何、正文與數學字型不動；未建立任何正式ch246–257內容。只增加V19 metadata、exercise別名、有號solution與完整Proof顯示文字。
實讀方法：20-Git-QA-v3、18-v3、13-A-B-v4第三篇與附錄三、04研究報告全文、05草案、06交接及07 manifest；08 Evidence已核結構與相關工程/限制；11研究Kit CRC通過，README及原型style實讀，09 Screen樣本7頁按序縮圖視檢，只作歷史校準。Git指定四份方法全文實讀，後從所指定commit重新取得，Git blob SHA重算一致（reference-git.json）；前卷快取只多末尾空行，不作未核來源替代。

OPEN／UNKNOWN：

| ID | 位置與影響 | 責任與下一步 | 是否阻塞 |
| --- | --- | --- | --- |
| L-B03-001 | 獨立試片第2–3頁，Solution253.1只有兩行續尾 | B06接整合正文時重看完整短題解與前後頁；不因孤立試片改正文或湊頁 | 阻止宣稱此試片排版合格，不阻B04 |
| PRE-B06-INPUT | 尚未接B05正式整合正文、符號、覆蓋表、缺陷史與有效Git章號證據 | 統籌交固定輸入；排版作正式回執 | 阻正式B06，非全Work停止 |
| PRE-B06-VISUAL | 尚無整卷PDF，全頁視檢及整章順讀未執行 | B06全部頁依序視檢、放大異常、查章縫與頁尾；內容保存/工程/閱讀分列 | 阻正式B06通過 |
| MODEL-MODE | 實際模型與推理強度未核實 | 有可觀測設定再補，不中斷生成 | 只阻模式已切換聲明 |
| RESEARCH-LIMIT | 歷史研究S2.1、16/22映射、六全局門檻及未測學習/跨OS/無障礙仍保留 | 不因引擎成功清零或重啟 | 不影響本卷內部工程準備 |

排版估算：無硬性字元或頁數配額。普通行約70–85英文字符僅提示；純散文實測1040詞3頁。B03約348英文詞加數學式共3頁，但一頁是短解尾頁，不能當穩定密度。正式數學可先以每1000詞5–8頁估工期，之後由完整正文實測更新。
下一角色唯一階段／驗收條件：上游照B04/B05製作唯一正文；本排版角色接到固定B05整合版才進B06。B06須完成內容保留、乾淨建置、全頁視檢與沿章順讀；完成後只交打厚B07，回修仍回打厚。
禁止重做：不得將工程完成當數學通過，不重生正式章節、不設逐章等待使用者批准、不修改凍結舊卷、不復活兩份NO OBJECTIONS。
待使用者決策：無。
傳遞狀態：作者接口與工程結果已經agent訊息送達本Work統籌，未送其他Work；完整交接檔供統籌讀入。正式B06接收回執尚未發生。

【本次準備接收回執】
交接ID：父代理V19排版準備任務及B03樣章指派。
已讀及hash：模板ZIP/CRC/SHA實核；三模板逐檔對照；Git方法四檔blob重算一致。字型清單與目前active依賴hash均通過verify.py。
可讀／缺檔／版本衝突：準備依賴可讀；無已知模板版本衝突；正式B05輸入尚未交付且非本階段應有成品。
理解：B，V19，246–257，預排版工程準備；不編入或改動舊卷。
接受續作／受影響部分阻塞：引擎就緒；等待正式B05交接後開始B06，不阻其他角色工作。
下一步與不重做：保留本引擎及已核樣本，正式整卷排版時逐頁核查；不重做模板研究或書稿。
