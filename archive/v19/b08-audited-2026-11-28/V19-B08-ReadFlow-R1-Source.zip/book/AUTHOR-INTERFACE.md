# V19 author interface — pre-B06 engineering preparation

Status: B workflow, pre-B06. The shell is buildable; this is not B05 integration, B06 visual acceptance, or B07 mathematical acceptance.

## Entry and unique manuscript

The final driver is `layout/study/v19.tex`. The sole manuscript files are `manuscript/ch246.tex` through `manuscript/ch257.tex`. Each author file begins with one `\chapter{Title}`. The driver sets `chapter` to 245 once, then inputs the twelve files in order. Do not set chapter counters inside author files. No V0 or prior-volume chapter content has been imported.

Build from any directory with:

```sh
python /absolute/path/to/book/build.py --entry v19 --clean
```

The driver builds after all twelve author files exist. Before B06 use the separate approved samples: `--entry smoke`, `--entry calibration`, or `--entry b03`. `negative` deliberately fails engineering checks. The final exported filename is `v19.pdf`.

## Standard author markup

Use ordinary English prose and standard LaTeX. The following environments are ready:

| Environment | Numbering |
| --- | --- |
| definition, theorem, lemma, corollary, proposition, example, remark | Shared chapter.counter sequence from the exact R1 baseline |
| exercise (alias of original problem) | Independent Exercise chapter.counter sequence |
| solution | Independent Solution chapter.counter sequence |
| proof | Unnumbered Proof with QED |
| equation, align, gather, multline | Standard amsmath/mathtools, chapter.counter equation numbers |

All numbered environments accept the usual optional descriptive heading. Each solution should follow its exercise unless the adopted volume design supplies a clear reason for another location. Prefer `\begin{solution}[Exercise~\ref{ex:246:name}]` and a distinct source label. The solution counter is independent: referencing the exercise explicitly remains correct if one exercise has multiple solutions or none.

```tex
\chapter{Chapter title}
\label{ch:246}
\section{Section title}
\begin{definition}[A descriptive name]\label{def:246:name}
The full definition and its conditions.
\end{definition}
\begin{theorem}\label{thm:246:name}
The complete statement.
\end{theorem}
\begin{proof}
The complete proof, with standard displays as needed.
\end{proof}
\begin{exercise}\label{ex:246:name}
The complete exercise.
\end{exercise}
\begin{solution}[Exercise~\ref{ex:246:name}]
The complete solution.
\end{solution}
```

Do not add another preamble or redefine baseline environments. `mathtools`, `amsmath`, `amsthm`, `unicode-math`, `booktabs`, `enumitem`, `tikz-cd`, and `hyperref` are loaded. Use `\mathbb{C}` and `\mathbb{R}` explicitly unless a separate notation file has been agreed: the historical R1 `\C` means `\mathcal C`, not the complex field. Other inherited short commands include `\id`, `\dom`, and `\cod`. New mathematical notation belongs to an explicit author-owned notation file, not the visual style.

## Page setting

The formal R1 baseline remains 190 × 260 mm, 10.4/16 pt body typography and 27 mm left/right margins. The three live R1 files are byte-identical to the fixed ZIP. `v19-local.tex` only sets V19 metadata, adds the requested exercise/solution interface, and spells out Proof. It does not change geometry, body fonts, or spacing.

There is no character quota or page target. Ordinary prose often occupies roughly 70–85 English characters per line; a colored environment is slightly narrower. This is a rough observation, not a forced line-break rule. For wide formulas use semantically chosen `align`, `multline`, or related environments. An `aligned` or `split` block is not made breakable by `allowdisplaybreaks`. Keep conditions with their formula and preserve every term. Never make a multi-page proof or definition an unbreakable block.

The disposable 1040-word pure prose test compiled to three pages including a chapter heading and partially filled last page (2.88 literal pages/1000 English words). Mathematical exposition should initially be estimated at 5–8 pages/1000 English words only for planning; actual representative content determines the estimate. The actual B03 sample contains approximately 348 English prose words plus formulas and compiles to three pages, but page 3 is only a short solution tail; this is a concrete layout warning, not a stable density measurement. Neither figure is a completeness or readability threshold.

## Fixed source and local dependencies

Template: `V0-ReadFlow-R1-Source.zip`, Library v3, Git commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, 7007679 bytes, SHA256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`. CRC verified. The historical baseline copies of `build.py`, `verify.py`, manifest, README and licensing stay under `baseline/` for provenance; the V19 build adapter is the root `build.py`. Do not run the historical V0 verifier on the selectively extracted V19 tree.

The exact R1 fonts are restored with their original filenames and supplied licenses in `dependencies/`. Build-local fontconfig and TeX search paths resolve them without changing the R1 files. The build generates a private XeLaTeX format and uses `-no-shell-escape`. Font inventory and hashes are in `provenance/font-manifest.json`.

## B06 receipt still required

Before formal visual QA the layout role must receive the fixed B05 whole-volume integrated body, coverage table, notation, content defect history, applicable Git chapter basis, and OPEN/UNKNOWN. Source preservation, PDF engineering, full-page visual inspection, and chapter-order reading will be reported separately. The final paired source/PDF goes only to the unique B07 mathematical final review. Engineering samples do not replace these checks.
