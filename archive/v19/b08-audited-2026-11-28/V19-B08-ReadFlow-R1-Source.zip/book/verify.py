#!/usr/bin/env python3
"""Check the R1 identity and restored font dependency hashes; no content verdict."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
errors=[]
for name in ['layout/shared/readflow-base.tex','layout/study/config.tex','layout/study/readflow-layout.tex']:
 if h(R/name)!=h(R/'baseline'/name):errors.append(['R1 changed',name])
for item in json.loads((R/'provenance/font-manifest.json').read_text()):
 p=R/item['path']
 if not p.exists() or p.stat().st_size!=item['bytes'] or h(p)!=item['sha256']:errors.append(['font dependency changed',item['path']])
print(json.dumps({'verdict':'PASS' if not errors else 'FAIL','errors':errors,'scope':'R1 three-file identity and recorded font dependencies only'},indent=2))
raise SystemExit(bool(errors))
