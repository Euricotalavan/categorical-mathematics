#!/usr/bin/env python3
"""Build the V19 manuscript or a separate engineering sample."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess
ROOT=Path(__file__).resolve().parent
WORK=ROOT/'layout/study'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--entry',default='v19');p.add_argument('--clean',action='store_true');a=p.parse_args()
 if not re.fullmatch(r'[A-Za-z0-9_-]+',a.entry):p.error('Invalid entry')
 state=ROOT/'build'/a.entry
 if a.clean and state.exists():shutil.rmtree(state)
 state.mkdir(parents=True,exist_ok=True)
 runtime=ROOT/'build/runtime';runtime.mkdir(parents=True,exist_ok=True)
 env=os.environ.copy()
 env.setdefault('SOURCE_DATE_EPOCH','1795737600')
 env.setdefault('FORCE_SOURCE_DATE','1')
 env['TEXMF']='{'+str(ROOT)+'/texmf,/usr/share/texmf,/usr/share/texlive/texmf-dist,/etc/texmf}'
 env['TEXMFDBS']='';env['TEXMFVAR']=str(runtime/'texmf-var');env['TEXMFCONFIG']=str(runtime/'texmf-config')
 env['TEXINPUTS']=str(WORK)+os.pathsep+str(ROOT/'manuscript')+os.pathsep
 env['OPENTYPEFONTS']=str(ROOT/'dependencies/fonts')+'//'+os.pathsep
 cfg=runtime/'fonts.conf'
 cfg.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><include ignore_missing="yes">/etc/fonts/fonts.conf</include><dir>'+str(ROOT/'dependencies/fonts')+'</dir><cachedir>'+str(runtime/'font-cache')+'</cachedir></fontconfig>')
 env['FONTCONFIG_FILE']=str(cfg)
 fmt=runtime/'format';fmt.mkdir(exist_ok=True);env['TEXFORMATS']=str(fmt)+os.pathsep
 if not (fmt/'xelatex.fmt').exists():
  cmd=['xetex','-ini','-etex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-jobname=xelatex','-output-directory='+str(fmt),'xelatex.ini']
  s=subprocess.run(cmd,cwd=WORK,env=env,text=True,capture_output=True);(runtime/'format-generation.txt').write_text(s.stdout+s.stderr)
  if s.returncode:raise RuntimeError((s.stdout+s.stderr)[-6500:])
 prev=None
 for run in range(1,7):
  cmd=['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder','-output-directory='+str(state),a.entry+'.tex']
  s=subprocess.run(cmd,cwd=WORK,env=env,text=True,capture_output=True);(state/f'pass-{run}.txt').write_text(s.stdout+s.stderr)
  if s.returncode:raise RuntimeError((s.stdout+s.stderr)[-6500:])
  current=[sha(state/(a.entry+'.'+x)) if (state/(a.entry+'.'+x)).exists() else '' for x in ['aux','toc','out']]
  if current==prev and run>=2:break
  prev=current
 else:raise RuntimeError('Auxiliary state did not converge')
 log=(state/(a.entry+'.log')).read_text(errors='replace')
 hard=re.findall(r'Missing character:.*|Undefined control sequence.*|LaTeX Warning: Reference.*|LaTeX Warning: There were undefined.*|.*multiply-defined.*|.*destination with the same identifier.*',log)
 over=re.findall(r'Overfull \\[hv]box[^\n]*|Package fancyhdr Warning[^\n]*',log)
 rec={'entry':a.entry,'passes':run,'hard_diagnostics':hard,'overfull_or_header_diagnostics':over,'underfull_diagnostics':re.findall(r'Underfull \\[hv]box[^\n]*',log),'pdf_sha256':sha(state/(a.entry+'.pdf'))}
 (ROOT/'qa'/('build-'+a.entry+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))
 if hard or over:raise SystemExit(1)
 if a.entry=='v19':shutil.copy2(state/'v19.pdf',ROOT/'v19.pdf')
if __name__=='__main__':main()
