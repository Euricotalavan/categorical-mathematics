# V19 formal B06 workflow — prepared, not started

The B05 freeze must identify the only integrated manuscript, coverage/notation/defect records, chapter basis and OPEN/UNKNOWN. Record the actual received filenames and hashes before reading. The early 191-page draft is not the formal input.

1. Preserve the B05 frozen source manifest. Read the complete integrated source and defect history in chapter order. Record content preservation separately from engineering and visual status. Classify new problems as L (layout), E (nonsemantic wording), N (narrative/prerequisite), or M (mathematics). Only L/E belong to layout; N/M return to the responsible content role.
2. Clean-build `python build.py --entry v19 --clean`. Keep the actual effective environment, fonts, final build log, source hashes and PDF hash. `SOURCE_DATE_EPOCH` is a reproducibility setting, not a content or layout verdict. A TOC number-column patch must be checked on every affected TOC page and its links.
3. Make a new QA directory for the exact PDF. The command below renders every full page to an individual image and builds sequential contact sheets. It records geometry, accidental white text, density locators, fonts, internal link destinations, bookmarks and chapter page ranges. All flags need explicit dispositions; none is an automatic mathematical or visual failure/pass.

```sh
python qa_pdf.py prepare --pdf v19.pdf --out qa/b06-r1 --source-root . --render --dpi 110 --columns 2 --per-sheet 4
```

4. Actually view every contact-sheet panel in order, preserving the full-page view. Use individual `pages/page-NNNN.png` images at full resolution for formulas, page bottoms, dense units, title/condition separation and all automatic locators. Check chapter seams and frontmatter as well as ordinary body pages. Read each whole chapter continuously against the source. If a local change reflows later pages, follow its propagation until stable; a style change requires all affected pages again.
5. Only after viewing, record the actual checked pages. Rendering a page does not mark it reviewed. Keep visual and continuous-reading records separate. The ledger is tied to one PDF hash and cannot be carried over silently to a later PDF.

```sh
python qa_pdf.py record --out qa/b06-r1 --pages 1-4 --kind visual --method "sequential contact sheet plus individual detail images" --note "Actual findings and disposition IDs"
python qa_pdf.py record --out qa/b06-r1 --pages 9-29 --kind continuous-reading --method "chapter source and paired PDF in order" --note "Chapter 246 actual reading scope and findings"
python qa_pdf.py summary --out qa/b06-r1
```

The page numbers above are examples, not a claim of checked pages. Do not fill the ledger from planned ranges. The `summary` command reports unreviewed pages and per-chapter coverage; it never issues acceptance.

6. Maintain the same defect table: ID, original text/physical page/source lines, reader obstacle, category, responsible role, old/new patch, retained mathematical obligations, disposition, and actual recheck evidence. Include L-B03-001 if the short solution tail remains in the integrated layout. Accepting a legitimate short chapter-end page needs its full reading unit checked, not a numerical density rule.
7. Final B06 handoff includes the fixed source/PDF pair, exact local R1 patches, full-page/continuous-reading ranges, all engineering flags and their dispositions, unresolved N/M, and the complete Appendix III handoff. B07 alone makes the whole-volume mathematical decision; all corrections return there for recheck. Retain previous fixed candidates and review ledgers.

## Tool calibration already performed

`qa_pdf.py` has been exercised on the separate three-page smoke PDF and the intentionally broken one-page PDF. It identifies the smoke's two deliberately short pages and incomplete chapter sequence, and flags the negative sample's excessive horizontal extent and unresolved-reference mark. Those warnings are expected for the samples. These executions are not formal B06 and do not mark the draft book reviewed.

## Early engineering patch review

The 3.4em section-number TOC column remains isolated in `v19-local.tex`; the three R1 baseline files stay unchanged. The build adapter sets `SOURCE_DATE_EPOCH` and `FORCE_SOURCE_DATE` via `setdefault`, so an already-set external value still wins. Record the effective values in the final engineering report rather than infer them from the source line. The reading-routes page must be checked with final frontmatter and its navigation links after B05; it is not yet a formal layout pass.
