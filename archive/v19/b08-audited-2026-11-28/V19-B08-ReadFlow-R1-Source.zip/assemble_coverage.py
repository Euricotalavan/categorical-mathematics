#!/usr/bin/env python3
"""Validate V19 locations against the fixed manuscript and join read/coverage evidence."""
import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read_rows(path):
    with path.open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream, delimiter='\t'))


def write_rows(path, header, rows):
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream, delimiter='\t', lineterminator='\n')
        writer.writerow(header)
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manuscript', type=Path, default=ROOT / 'book/manuscript')
    parser.add_argument('--allow-unassigned', action='store_true')
    args = parser.parse_args()
    evidence = ROOT / 'evidence'
    primary = read_rows(evidence / 'source-responsibilities.tsv')
    primary_ids = {row['source_id'] for row in primary}
    if len(primary_ids) != len(primary):
        raise SystemExit('Duplicate B-01 responsibility identifiers')
    labels, references, duplicates = {}, [], []
    chapters = []
    for path in sorted(args.manuscript.glob('ch*.tex')):
        chapters.append(path.stem)
        for line_number, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
            line = re.split(r'(?<!\\)%', line, maxsplit=1)[0]
            for label in re.findall(r'\\label\{([^{}]+)\}', line):
                if label in labels:
                    duplicates.append(label)
                labels[label] = (path.name, str(line_number))
            for label in re.findall(r'\\(?:ref|eqref|pageref|autoref)\*?\{([^{}]+)\}', line):
                references.append((path.name, line_number, label))
    if chapters != [f'ch{n}' for n in range(246, 258)]:
        raise SystemExit(f'Expected Chapters 246–257, found {chapters}')
    if duplicates:
        raise SystemExit(f'Duplicate labels: {sorted(set(duplicates))}')
    unresolved = sorted(set(ref for _, _, ref in references if ref not in labels))
    sources = defaultdict(list)
    original = []
    invalid = []
    notes_file = evidence / 'scope-dispositions.tsv'
    landing_files = sorted(evidence.glob('ch*-landings.tsv'))
    if notes_file.is_file():
        landing_files.append(notes_file)
    for landing in landing_files:
        for row in read_rows(landing):
            source, label, status, note = (row[k] for k in ('source_id', 'label', 'scope_status', 'note'))
            if label not in labels or not status or not note:
                invalid.append([landing.name, source, label, status])
                continue
            entry = (label, status, note, *labels[label], landing.name)
            if source in primary_ids:
                sources[source].append(entry)
            elif re.match(r'^(OWN|ORIGINAL|V19|B03)[-_]', source):
                original.append((source, *entry))
            else:
                invalid.append([landing.name, source, label, 'unknown source identifier'])
    unassigned = sorted(primary_ids - sources.keys())
    stats = {
        'chapters': chapters,
        'semantic_labels': len(labels),
        'source_tex_references': len(references),
        'unresolved_tex_references': unresolved,
        'primary_source_items': len(primary),
        'assigned_source_items': len(sources),
        'source_landing_rows': sum(len(rows) for rows in sources.values()),
        'original_landing_rows': len(original),
        'source_landing_statuses': Counter(entry[1] for rows in sources.values() for entry in rows),
        'unassigned_source_items': unassigned,
        'invalid_landing_rows': invalid,
    }
    (evidence / 'coverage-verification.json').write_text(json.dumps(stats, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    header = list(primary[0])
    more = ['label','scope_status','editorial_note','tex_file','tex_line','landing_source']
    write_rows(evidence / 'source-disposition.tsv', header + more, (
        (*tuple(row[k] for k in header), *entry)
        for row in primary
        for entry in sources.get(row['source_id'], [('', 'UNASSIGNED', '', '', '', '')])
    ))
    write_rows(evidence / 'original-landings.tsv', ['original_id', *more], sorted(original))
    print(json.dumps({key: value for key, value in stats.items() if key != 'source_landing_statuses'}, ensure_ascii=False))
    if invalid or unresolved or unassigned and not args.allow_unassigned:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
