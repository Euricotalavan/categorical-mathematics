# Locally Convex Spaces, Distributions, and Integral Equations

Volume 19 contains Chapters 246–257. The archive's stage and exact PDF identity are in `MANIFEST.json`. Stage B05 is the integration checkpoint. A formal B08 edition also includes the B06 typesetting, B07 mathematical decision and B08 recovery evidence.

The build uses **ReadFlow R1** and XeLaTeX. The source entry is `book/layout/study/v19.tex`. The only twelve chapter source files are under `book/manuscript/`.

```sh
python book/verify.py
python assemble_coverage.py
python book/build.py --entry v19 --clean
```

The build requires Python 3, XeLaTeX and its standard TeX Live document packages, with fontconfig available. The packaged fonts, their licenses and hashes are under `book/dependencies/` and `book/provenance/`. A compatible environment regenerates `book/v19.pdf`. The PDF build uses a fixed timestamp with `SOURCE_DATE_EPOCH` and `FORCE_SOURCE_DATE` by default. To verify archived bytes without compiling, run `python verify_archive.py path/to/source.zip --pdf path/to/the-paired.pdf`. Add `--rebuild book/v19.pdf` to verify a locally compiled copy, allowing only a PDF trailer ID difference.

`evidence/INPUTS.md` identifies the fixed primary editions and the Git chapter-number basis. `evidence/source-disposition.tsv` joins reviewed sources with exact manuscript labels, editorial scope and notes. Uncertain or uninspected parts keep those designations. Source books, scans and raw extractions are excluded. The archive preserves the template and font notices.
