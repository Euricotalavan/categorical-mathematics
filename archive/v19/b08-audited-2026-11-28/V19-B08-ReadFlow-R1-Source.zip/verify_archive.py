#!/usr/bin/env python3
"""Check every archived file and the matching book PDF, without extracting anything."""
import argparse
import hashlib
import json
import posixpath
import re
import zipfile
from pathlib import Path, PurePosixPath


def digest(stream):
    hasher = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        hasher.update(chunk)
    return hasher.hexdigest()


def normalized_pdf_trailer_id(content):
    # XeLaTeX can choose a different document ID when rebuilt in another directory.
    pattern = rb'/ID\s*\[\s*<[0-9A-Fa-f]{32}>\s*<[0-9A-Fa-f]{32}>\s*\]'
    matches = list(re.finditer(pattern, content))
    if len(matches) != 1 or matches[0].start() < len(content) - 65536:
        raise SystemExit('Cannot establish the single PDF trailer ID field')
    start, end = matches[0].span()
    return content[:start] + b'/ID' + content[end:]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source_zip', type=Path)
    parser.add_argument('--pdf', type=Path)
    parser.add_argument('--rebuild', type=Path)
    args = parser.parse_args()
    with zipfile.ZipFile(args.source_zip) as source:
        names = source.namelist()
        unsafe = [name for name in names if (
            PurePosixPath(name).is_absolute() or posixpath.normpath(name) != name
            or '..' in PurePosixPath(name).parts or '\\' in name)]
        if unsafe or len(names) != len(set(names)):
            raise SystemExit('Archive includes an unsafe or duplicate member name')
        manifest = json.loads(source.read('MANIFEST.json'))
        paths = set(manifest['files'])
        if set(names) != paths | {'MANIFEST.json'}:
            raise SystemExit('Archive and manifest disagree on the file set')
        corrupt = source.testzip()
        if corrupt:
            raise SystemExit(f'Archive CRC failed: {corrupt}')
        for path, expected in manifest['files'].items():
            with source.open(path) as member:
                actual = digest(member)
            if source.getinfo(path).file_size != expected['bytes'] or actual != expected['sha256']:
                raise SystemExit(f'Archive member failed size or hash check: {path}')
        paired = manifest['paired_pdf']
        if 'archive_member' in paired:
            embedded = manifest['files'].get(paired['archive_member'])
            identity = {key: paired[key] for key in ('bytes', 'sha256')}
            if embedded != identity:
                raise SystemExit('Embedded PDF does not match the paired identity')
        if args.pdf:
            with args.pdf.open('rb') as pdf:
                actual = digest(pdf)
            if args.pdf.stat().st_size != paired['bytes'] or actual != paired['sha256']:
                raise SystemExit('The given PDF is not the paired edition')
        rebuild_match = None
        if args.rebuild:
            if 'archive_member' in paired:
                reference = source.read(paired['archive_member'])
            elif args.pdf:
                reference = args.pdf.read_bytes()
            else:
                raise SystemExit('An embedded or external paired PDF is required to verify a rebuild')
            rebuilt = args.rebuild.read_bytes()
            if rebuilt == reference:
                rebuild_match = 'exact-bytes'
            elif normalized_pdf_trailer_id(rebuilt) == normalized_pdf_trailer_id(reference):
                rebuild_match = 'differs-only-in-trailer-id'
            else:
                raise SystemExit('Rebuild differs beyond the PDF trailer ID')
        print(json.dumps({'verdict': 'PASS', 'stage': manifest['stage'], 'members': len(names),
                          'pdf_sha256': paired['sha256'], 'pdf_bytes': paired['bytes'],
                          'pdf_pages': paired['pages'], 'external_pdf_checked': bool(args.pdf),
                          'rebuild': rebuild_match}, indent=2))


if __name__ == '__main__':
    main()
