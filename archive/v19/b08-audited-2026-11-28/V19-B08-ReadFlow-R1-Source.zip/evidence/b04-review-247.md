# Independent B04 mathematical review — Chapter 247

Date: 2026-11-27. Role: independent reviewer after authoring Chapter 254. Scope: the complete Chapter 247 draft, with special attention to gauges/Hahn–Banach separation, annihilator identities, exact weak dual, neighborhood-polar compactness, and complex/Hilbert adjoints. This is a scoped B04 review, not B07 whole-volume final acceptance, source preservation acceptance, or PDF QA. Actual model/reasoning mode is not independently inspectable in this child context and is unverified.

Reviewed file: `v19-work/drafts/ch247.tex`.

Reviewed SHA-256: `422a318a0e63fc8cbc92d32286015dd0d5ecc1de002b5af160ce2ae94d1e6f01`.

The complete current file was read, including the newly added finite-polar, sequence-adjoint, pointwise-net, and sequence-unit-ball subsections. The invoked seminorm Hahn–Banach theorem and norming corollary in `drafts/ch246.tex` were also read to verify the actual dependency used in the separation proof. Kress/Trèves source-item completeness is not inferred from this mathematical review; the corresponding source tables remain separate evidence.

## Section-by-section record

| Section / labels actually read | Mathematical checks | Finding |
|---|---|---|
| `linear-dual-conventions`; `prop:v19:247:riesz`; Hilbert conjugation example | Riesz vector is conjugate of f(v) times v divided by its squared norm; kernel projection argument; norm equality; J conjugate-linear; scalar i test | Correct. Hilbert projection theorem is explicitly named as input. |
| `dual-pair` | Both separating conditions; finite matrix dimensions; finite-support sum types; all lp endpoints treated as designated pairs, not full-dual identifications | Correct. Small optional reading-order improvement below. |
| `annihilator`; `prop:v19:247:annihilator-identities` | Kernel/range annihilator identities typed on correct sides; target dual separation; original-density converse via Hausdorff locally convex quotient; induced-form continuity is necessary in transpose solving | Correct. No unjustified removal of range closure or automatic full-dual representation. |
| `polar` | Complex absolute polar, nonzero scalar scaling, subspace annihilator equality; box phase alignment; norming seminorm and kernel case | Correct. |
| `weak-topology`; `thm:v19:247:weak-dual` | Finite continuity bound; factorization through image Q(E), not assumed surjectivity; algebraic extension in finite dimensions; separation gives unique F element | Correct. Weak-star bidual is explicitly not strong reflexivity. |
| `bipolar-theorem`; `lem:v19:247:separate-disk` | Choose z=x0/(1+delta) outside closed C; choose V with z outside C+V; open absorbing disk has continuous gauge; p(z)>=1 gives strict p(x0)>1; ch246 norming HB gives needed linear separator | Correct. The strict margin repairs the common boundary-only separation problem. |
| Bipolar closure consequences and `eq:v19:247:double-annihilator` | Weakly closed absolutely convex hull; exact weak dual identifies separator with F; canonical weak/original closure comparison; transpose range closure in sigma(E',E) | Correct. The l1-to-l2 proper transpose-range example is valid. |
| `equicontinuity` | Common neighborhood quantifier; gauge domination including seminorm kernel; sequence-space common finite coordinates | Correct. The escaping-evaluation illustration can be made independent of later bump construction; see R247-02. |
| `weak-star-compactness`; `thm:v19:247:alaoglu` | Absorption bounds each coordinate; compact product; linearity and U-boundedness are closed product conditions; limit is continuous from its neighborhood bound; induced topology is exactly pointwise | Correct even for the stated general TVS. For strict epsilon continuity one may use epsilon U/2, which is immediate from the displayed non-strict estimate. No substantive gap. Compactness is not promoted to sequential compactness; separability/metrizability caveat is present. |
| `adjoint-examples`; integral transpose; Hilbert adjoint; designated-adjoint counterexample | Bilinear transpose has no conjugation; Hilbert adjoint does; bounded-kernel finite-product Fubini justified; abstract Hilbert adjoint linearity and norm equality; t^n counterexample | Correct. |
| `ex:v19:247:rank-one` | Nonzero-factor assumption and zero-factor cases | Earlier defect R247-01 is fixed in reviewed SHA. |
| `prop:v19:247:finite-polar` | Finite observations may be dependent; norm-preserving Hahn–Banach extension on Q(E); l-infinity dual norm is coefficient l1 norm; scaling epsilons is in the correct direction | Correct. |
| `subsec:v19:247:sequence-adjoints` | Shift transpose, closed hyperplane range, diagonal dense proper range; harmonic-sum discontinuity of the induced form; exact continuity iff (n a_n) is square-summable | Correct. The truncated conjugate coefficient test yields the stated squared-sum bound. |
| `subsec:v19:247:weak-star-nets` | Finite-dimensional restrictions of E' span full dual; interpolation net eventually fixes each coordinate; limit in algebraic dual may be discontinuous; net is pointwise Cauchy but not confined to an equicontinuous polar | Correct. The incompleteness conclusion concerns nets, with no invalid Banach–Steinhaus inference for unbounded nets. |
| `subsec:v19:247:lp-polars` | Complex phase adjustment; normalization exponent q/p; l1 approximate maximizer; linfinity designated-pair warning | Correct. |
| `practice` and every following solution | Finite-coordinate restriction, dense proper l1 range, finite-set bipolar, scalar adjoint signs, failure of equicontinuity | Correct. |

## Defects and proposed corrections

### R247-01 — zero coefficient in rank-one solvability criterion — RESOLVED in reviewed SHA

Original locator: `ex:v19:247:rank-one`. Earlier wording assumed arbitrary ell and v, then claimed that vanishing of b under every functional killing v was sufficient for b to belong to ran(T). For ell=0 and v nonzero the actual range is zero, while that condition merely places b in span(v). Concrete counterexample: E=R, v=1, ell=0, b=1.

Required repair was to assume v and ell both nonzero before the line-range criterion and treat either zero factor separately. The current text now says exactly this and states that the sole solvable datum in the zero-map cases is b=0. Recheck: nonzero ell is onto the scalar field, hence ran(T)=span(v); the closed-line double-annihilator argument then gives sufficiency. Direct consequence is the example's correct quantifier scope. Transitive consequence is that no later solvability rule may inherit the former degenerate-case error. No further manuscript patch is requested for this issue.

### R247-02 — optional removal of a forward bump-function dependency — OPEN MINOR

Locators: the finite-point-evaluation discussion in `dual-pair`, and the final escaping-evaluation paragraph of `equicontinuity`. Both use smooth compactly supported functions; their construction is scheduled for Chapter 249. The main dual-pair and equicontinuity theorems do not depend on this gap: evaluations are actual functionals, and separation on the functional side follows by their definition. These are illustrative claims that can be justified immediately without importing the later cutoff theory.

Suggested replacement for finite independence at distinct points x_1,...,x_N:

> Their independence can be checked using the smooth polynomials L_j(x)=product over i!=j of |x-x_i|^2/|x_j-x_i|^2, restricted to Omega. These satisfy L_j(x_i)=delta_ij, so testing a linear relation on each L_j forces its coefficient to vanish.

Suggested replacement for the escaping delta_n argument:

> The family delta_n on C-infinity(R) is not equicontinuous. If one zero neighborhood U bounded every delta_n by one, absorption would place c times the function t↦t in U for some c>0. Its values c n are unbounded, a contradiction.

These replacements are mathematically complete with material already introduced. They change no theorem or downstream conclusion; they improve the promised reading order. The reviewer has not edited the chapter.

## Disposition

The requested main proof paths have no remaining mathematical blocker at the reviewed hash after the rank-one repair. R247-02 is a minor local reading-order improvement. This result is not a declaration of whole-volume mathematical approval. Later integrations changing the reviewed statements, conventions, or proof dependencies require hash-specific rechecking. Keep bibliography/source coverage, typesetting engineering, PDF inspection, and B07 acceptance separate.
