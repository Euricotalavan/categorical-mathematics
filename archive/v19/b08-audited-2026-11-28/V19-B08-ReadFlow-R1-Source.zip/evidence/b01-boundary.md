# V19 B-01 scope decisions

Chapter numbering follows the published V18 ending at Chapter 245. The 12 topic titles follow the user-specified V19 card. The following decisions retain the original chapter count and allow each prerequisite to be checked in reading order.

| Ch. | Retained responsibility | Explicit boundary |
|---|---|---|
| 246 | Seminorms, gauges, continuity and boundedness criteria, quotients, first countability, completeness on a defining sequence, Fréchet examples | General nonlocally convex theory beyond useful counterexamples |
| 247 | Pairings separating on both sides, annihilators, transpose, algebraic/continuous dual, polar calculus, Hahn–Banach and elementary bipolar consequences | Higher structure of dual systems where it does not support 248 or 252 |
| 248 | Weak, weak-star and strong dual topologies, bounded-set test, equicontinuity, comparison on examples, compactness and barrelled/Fréchet interface | General Mackey–Arens, bornological and Montel classification only as source pointers where needed |
| 249 | Test spaces on open sets, compact exhaustion, LF continuity and regularity, bump, partition, convolution for test approximation, continuity criterion for distributions, compact support and order | General manifolds and nonlinear pullbacks |
| 250 | Derivatives and smooth multiplication, support, jump/Dirac applications, primitive, compactly supported and fundamental-solution examples | Products of arbitrary distributions, wavefront sets and full PDE existence theory |
| 251 | Hilbert seminorm models of nuclearity, rapidly decreasing sequences, product tensor and completeness bridge, construction of a distribution kernel on Euclidean opens | Full classification/permanence of nuclear LF spaces and arbitrary abstract kernel representation |
| 252 | Finite-rank reduction, continuous compact kernel class, Fredholm compatibility and stability conditional on inverse, adjoint pairing, examples of singular right-hand sides | General unbounded Fredholm and approximation algorithms |
| 253 | Triangular continuous and square-integrable kernels, factorial bounds and Neumann inverse for all complex parameters, causal iteration, a memory model and first-kind contrasts | General nonlinear or long-time Volterra theory |
| 254 | The distinct continuous, square-integrable and weakly singular criteria, operator-norm approximation, adjoints, compactness obstructions | General Calderón–Zygmund theory |
| 255 | Cauchy principal value, real-line Hilbert transform with Fourier, exact constant-coefficient solving conditions, boundary values in an explicit setting, circle model comparison | General variable-coefficient Riemann–Hilbert and rough-contour theory |
| 256 | Resolvent operator versus resolvent kernel, convergence domains, compact exceptional parameters, residue in tractable spectral models, conditional stability | General meromorphic Fredholm theory only to the level proved with source-supported hypotheses |
| 257 | Complete new cases testing the distinctions above, with data classes, derivation, verification and stability | Repeating V18's constant-kernel Volterra or `min(x,t)` Green case as a main example |

Use only original text and examples or explicitly attributed adaptations. Source table statuses distinguish actual read, formula uncertainty, introductory citation of a named theorem, deferred material, and unresolved pages. Scope selection does not turn an unread passage into an exclusion. The T file's distribution rights for its prior third-party host remain unverified. The supplied working copy serves bibliographic verification in this Work.
