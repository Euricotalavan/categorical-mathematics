# B-04 independent audit — Chapter 250

Reviewed file: `v19-work/drafts/ch250.tex`.

SHA-256: `312f52f8d4c5005336a7246b776aac709b01a9dff05a2a6c29046380c981e0b2`.

Status: **The chapter's mathematical statements and calculations pass at the stated scope. One cross-chapter promise needs a localized integration correction.** This is a B-04 independent read, not B-07 whole-volume acceptance. I read the whole file, not only the requested high-risk formulas. I also read the relevant definitions, support-extension, convergence and regularization passages of the current `drafts/ch249.tex` to check actual prerequisite availability.

## Coverage of this read

Every section read: transpose-derivative; smooth-multiplication; jumps; principal-value; log-and-finite-part; constant-distributions; translation-convolution; tensor-distributions; point-support; practice. All displayed computations, proof arguments, examples and exercise solutions were checked. No source/OCR text was copied into this review.

## Required localized integration correction

| ID | Exact location / original text | Effect | Proposed correction | Recheck |
|---|---|---|---|---|
| B04-250-01 | `drafts/ch249.tex`, paragraph immediately before `sec:v19:249:convergence-regularization`: “an order-m compactly supported distribution annihilates a smooth function whose derivatives through degree m vanish on its support” followed by “will be proved in the next chapter.” Current ch250 `thm:v19:250:point-support` proves the statement only when the support consists of one point. | The general statement is true, but the promised full arbitrary-compact-support proof does not land in ch250. This is a real reading-path gap, not an incorrect point-support proof. | Minimal safe fix in ch249: replace that sentence with “For a distribution supported at one point, the next chapter proves that vanishing derivatives through its order force its evaluation to vanish. This is a statement about jets, not a support-only norm estimate on an arbitrary closed set.” Keep the existing exact-support warning. Alternatively add a separately proved general compact-support jet lemma in ch250; that is broader work and unnecessary for its point-support theorem. | Verify the revised ch249 paragraph no longer promises the unprovided general proof; no derivative/convolution theorem needs redoing. If a general lemma is added instead, its arbitrary closed-set cutoff estimates need independent verification. |

No direct or transitive mathematical defect was found in the ch250 operations. The one correction affects the ch249→ch250 scope bridge and any downstream claim that a *general* support-jet theorem was proved. The point-supported representation and its uses are unaffected.

## Detailed mathematical checks

1. **Transpose and topologies.** The derivative on tests is continuous stagewise and preserves support. The negative transpose convention is consistent with the linear distribution pairing. The strong seminorm identity `P_B(partial_j u)=P_{partial_j B}(u)` is exact because of absolute values. Fixed smooth multiplication and fixed translation/reflection map bounded test families to bounded families. Thus weak and strong continuity follow in their proper topologies; no norm on D' is presumed.

2. **Weak sequences and convolution smoothing.** Current ch249 actually proves that a weakly convergent distribution sequence is strongly convergent, using common finite-order estimates on each Frechet stage and total boundedness of bounded test families in the needed derivative seminorm. This makes the last sentence of ch250's translation-convolution section valid. Independently, uniform convergence on the compact family of translated/differentiated fixed tests also proves the stated C-infinity convergence. Nothing here extends that sequence assertion to arbitrary weakly convergent nets.

3. **Jump signs and boundary orientation.** For the right half-line `-∫_0∞phi'=phi(0)`, so H'=delta and the jump coefficient is right minus left. The assumption that the classical derivative is locally integrable across the interface ensures existence of finite one-sided limits. For the graph region t>g(x'), the normal term has components (-partial_i g,1) against dx', agreeing with the *interior* normal and with minus the outward normal. The curved-interface formula has the correct sign. The approximation argument makes its C1 coefficient extension legitimate without defining arbitrary nonsmooth distribution products.

4. **Principal value and finite part.** Pairing the two reciprocal halves yields `[phi(x)-phi(-x)]/x`, hence the finite first-order estimate. The one-sided family shows that zeroth order is impossible. In the logarithm integration by parts, the boundary term is `log(epsilon)[phi(epsilon)-phi(-epsilon)]`, which tends to zero. For the square reciprocal the subtraction is `2phi(0)/epsilon`; the finite remainder contains `-2phi(0)/R`. Differentiating pv(1/x) produces **minus** Pf(1/x²). Multiplication by x then gives x Pf(1/x²)=pv(1/x). These signs agree both directly and by Leibniz applied to x pv(1/x)=1.

5. **Constants and primitives.** A zero-integral test has a compactly supported primitive inside an interval. The adjusted primitive map J preserves a fixed larger compact stage for each fixed source stage and is continuous. Its identity J(phi')=phi gives U' = f for U=-f∘J. Connectedness is correctly retained. The continuous-weak-derivative argument handles parameter slices using continuity; it does not assert pointwise differentiability for an arbitrary L1 representative.

6. **Translation parameter.** The convention tau_h f(x)=f(x-h) gives partial_h tau_h u=-tau_h partial u, with the correct minus sign. Taylor remainder in all derivatives on the common compact support proves strong differentiability. Fixed-h continuity and parameter differentiability are kept separate.

7. **Smooth convolution.** The parameter lemma applies to u_y psi(x-y) because x in any compact set forces one compact y-support. Differentiation in x or moving a y derivative across u gives the two cancelling signs. The family of translated differentiated tests is bounded, giving the asserted map from strong D' to compactwise C-infinity. The support sum is closed because the smooth-test factor has compact support.

8. **Tensor product before kernel theorem.** The parameter lemma gives a compactly supported smooth inner evaluation and explicit mixed derivative bounds. Uniqueness uses only the already-proved local regularization theorem with product mollifiers; it does not use the later Schwartz kernel theorem. This is a noncircular proof of interchange. The support equality follows from product neighborhoods and nonzero factor evaluations. Derivative formulas use the correct variable.

9. **General convolution with one compact factor.** The definition is valid: if supp(v) is compact and phi is compact, a y-cutoff chi=1 near supp(v) makes `chi(y)phi(x+y)` compactly supported jointly, since y lies in supp(chi) and x in supp(phi)-supp(chi). Different cutoffs agree near the tensor support. On each fixed support of phi this is a continuous map to one fixed product stage, so the tensor estimate proves the distribution continuity. Support, commutativity and both derivative identities follow; derivatives of the cutoff vanish near supp(v). Associativity as written uses two compact factors, so each bracketing is defined and the threefold cutoff argument is valid. No assertion that one merely compact distribution factor causes smoothness is made, correctly: delta*delta=delta would refute such an assertion.

10. **Point support and causal examples.** The little-o Taylor estimate of each derivative, combined with the rescaled cutoff derivative bound, tends to zero through order m. The delta-derivative coefficient signs are correct and cutoff monomials prove uniqueness. The solution of xu=1 is pv(1/x)+c delta. For E_a=H exp(ax), (partial-a)E_a=delta; the indicator-data formula matches at 0 and 1, and the differentiated impulse solution aE_a+delta returns delta'. Causal uniqueness follows from the homogeneous integrating-factor equation. The exercises' affine homogeneous second-order terms and the reflection/convolution signs are correct.

## Optional clarity improvement, not a blocking defect

After defining general convolution, explicitly note agreement with the earlier smooth formula: for v=T_psi, use test integration through the distribution pairing to obtain `<u*T_psi,phi>=∫u_y psi(x-y)phi(x)dx`. This follows from the fixed compact-stage Riemann-sum argument already proved in ch249 and is mathematically available, but spelling it out would join the two definitions for the reader. Likewise, for fixed compactly supported v, the test map `C_v phi(x)=v_y phi(x+y)` is continuous D→D and preserves bounded tests, so u↦u*v is weakly and strongly continuous by transposition. The current chapter does not claim this latter general continuity result; adding it would broaden an already correct scope.

## Pass assumptions and handoff

Pass assumes the current ch249 test topology, bounded-set theorem, support-compatible extension and local regularization results remain in the final reading order with their proofs. It also assumes the preliminary Frechet uniform boundedness theorem exists as cited there. Mathematical content review is separate from compilation, source pairing, page layout and later whole-volume integration. No hash, page count or compile status is being used as a substitute for this read.

Next action: parent assigns the one ch249 wording correction, then records the small recheck. No need to rewrite ch250's proofs or restart the volume. The review file is in the shared workspace; external delivery and persistence remain with the parent.
