# V19 B07 repaired-pair layout recheck — PASS

2026-11-27. Role: layout. Scheme: authorized B single Work; B06 layout / B07 return recheck. This receipt accepts layout and engineering only; the unique B07 mathematical verdict is separate.

## Actual input and fixed output

Read B07-returns.md and final-qa/b07-source-changes.txt (17 semantic returns A–Q), B06-v2 history, and authoritative integrated chapter sources. The immutable B07-return-v1 was preserved.

Final paired directory: `v19-work/versions/B07-anchor-v2/`. Mutable build counterpart: `v19-work/b07-build/`.

- PDF SHA256: `b73bf137be341da61c186c68c8edc0649a066013fe1ab924d6d4930b4022e851`; 280 pages, 190×260 mm.
- PAIR.sha256 SHA256: `5171ec5910d0c8cdf6d4b1666e7335fda13c030fbd7f30980d5be9082f31f551`; all19 listed files independently hash-verified.
- Input B07-return-v1 PDF: `0aac9bb98dbe288207d5de76de4106d8700fd537622f13bbee160a0ae72abe59`.
- B06-v2 inherited-body baseline PDF: `e67845763cd893c530b00a50b4f40824459d48e7449e77b7812724ba12a2fb63`.

## Exact layout-only return

Four explicit `\newpage` anchors and explanatory comments were inserted immediately before headings246.9.5,248.9.3,249.4,254.10. This preserves their already visible natural breaks while placing named destinations on the visible heading page. No semantic text edited. Exact before sources, hashes and patch: `final-qa/anchor-repair/`.

| Heading | Old named target | Correct physical target |
|---|---:|---:|
|246.9.5|25|26|
|248.9.3|61|62|
|249.4|72|73|
|254.10|206|207|

Own108dpi MuPDF comparison found **all280 final full-page rasters exactly identical** to B07-return-v1, including TOC and furniture. Only PDF navigation changed. No page reflow was introduced by this repair.

## Actual visual review and carry-forward

All95 body pages changed since B06-v2 were actually viewed in sixteen sequential full-page contact sheets, `final-qa/layout-recheck/changed-sheets/batch-01.png` through `batch-16.png`. The ledger lists exact pages. Remaining185 bodies inherit only proven exact body-pixel matches to the previously actually inspected B06-v2 pages, with per-page mapping in `B06-B07-pixel-map.json`. Six pages also match B06 full rasters.

For the final SHA, actually viewed physical25–26,61–62,72–73,206–207 as whole pages to recheck four heading boundaries. Actually viewed all280 final headers/footers in furniture01–08 strips; automated checks independently match body page1–272 and chapter labels. Cover remains intentionally unnumbered, TOC/frontmatter i–vii. `anchor-final/visual-coverage.json` has280 individual receipts and zero uncovered pages, distinguishing inheritance from new image review.

No clipped display, body/footer collision, unresolved notation glyph, or disorienting short semantic-unit split observed. Explicit continued markers keep split theorems/examples/solutions oriented and are accepted. Physical29 contains only a chapter source-note final line; accepted as a readable source tail, without global pagination changes.

## Engineering and navigation

Clean authoritative rebuild converged in3 passes: zero hard, overfull or header diagnostics. All21 underfull diagnostics have recorded acceptance; output is pixel-identical to the reviewed return. All7 font objects embedded. All32 geometry locators individually disposed in JSON: legitimate short frontmatter/chapter ends or mathematical bottom subscripts/descenders. Minimum measured extracted body/footer gap14.858154bp at physical252; image has visible separation.

All137 numbered section/subsection headings were located from actual bold heading spans and matched to named destinations; all12 chapter starts matched actual uppercase chapter markers. All149 numbered chapter/section/subsection TOC printed page records match those physical pages. All377 internal hyperlinks,931 named destinations and150 bookmarks resolve within page range; actual numbered heading destinations checked separately, avoiding the earlier false confidence of range-only navigation checks. No mismatch remains.

## Files, remaining scope and next step

Core evidence under `v19-work/evidence/final-qa/anchor-final/`: `acceptance.json`, `anchor-navigation-pixels.json`, `visual-coverage.json`, `engineering.json`, `geometry-dispositions.json`, `underfull-dispositions.json`, `review-ledger.json`, source inventory, final heading/furniture images. Scripts: `final-qa/recheck-anchor-final.py`, `compare-layout-return.py`.

No L/E blocker remains. Existing source/provenance/prior-volume UNKNOWNs, model-mode verification limit, historical16-topic/22-chapter and six-gate questions remain as recorded by root; this check does not convert them into acceptance. B07 mathematical PASS must bind to this exact final pair. Next: parent B08 packaging and roundtrip under existing authorization. Do not overwrite immutable B06-v2 or B07-return-v1, restart other volumes, modify sources semantically, or globally repaginate. Any subsequent source/PDF change requires exact-hash recheck and only proven pixel inheritance.
