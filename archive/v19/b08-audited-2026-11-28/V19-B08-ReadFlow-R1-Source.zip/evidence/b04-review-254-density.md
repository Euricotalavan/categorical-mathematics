# V19 B-04 targeted independent read — extended Chapter 254

File actually read: `drafts/ch254.tex`, SHA-256 `1354fed2f2958e7fe147b96ba3fac4f34672e7ebd53648760b0baacebe373f13`.

Scope: targeted mathematical reread of the extended teaching blocks, requested to complement the parent's calculations. This is not the whole-volume B-07 review and does not assert a complete Kress item audit. No chapter edits made by this reviewer.

## Actual read and checks

Read the mapping/Schur preliminaries and kernel Hilbert-space proofs needed by the new blocks. Read the diagonal approximation, cell averages/projection and matrix, dyadic density argument, power cutoff two-stage rate, continuous-output/uniform-tail criterion and counterexample, measure-growth/surface proof, exact sphere model, whole-line tent and spatial cutoff, principal-value concentration, C-versus-L2 and L-infinity examples, interval logarithmic/power comparisons, and all current exercises/solutions.

- Cell-average matrix normalization is `sqrt(mu_i nu_j)c_ij`; the coordinate analysis and synthesis give exact operator norm equality, not only an upper estimate. Kernel squared norm equals the matrix squared Frobenius norm. The cell diameter bound produces omega_k(2h), and on cube cells 2 sqrt(d) h correctly multiplies the cutoff Lipschitz constant.
- Power two-stage constants A=omega_(d-1)/(d-alpha) and B=2^(alpha+2)(1+alpha)sqrt(d) check. Balancing epsilon=h^(1/(d+1)) yields exponent (d-alpha)/(d+1). For d=1, alpha=3/4 the coefficient is 8+7*2^(3/4) and exponent 1/8.
- Uniform-tail continuity proof uses every-point absolute row integrability before taking uniform limits. The concentrated rank-one row example has bounded full row masses but no uniform small tails, exactly as claimed.
- Surface dimension bound from finitely many bounded-Jacobian patches is valid. Sphere row integral is 2*pi*2^(2-alpha)/(2-alpha); cap area is pi*epsilon^2 for epsilon<=2. Multiplying the squared-kernel row by area4*pi gives 8*pi^2*2^(2-2alpha)/(2-2alpha). Norm equality follows from constant input and equal row/column masses.
- Tent convolution g has middle polynomial 1/2+x-x^2. Its square integrates to 9/20 there, outer pieces total1/10, giving 11/20. The translated-input obstruction is valid; long normalized indicators prove exact norm1 independently of Fourier theory.
- Rank-one classification on Lp is exactly ap<1 and bq<1, with claimed norm. The normalized truncated w_N^(q-1) construction proves failure at/beyond the dual exponent threshold. Continuous-space criterion a=0,b<1 is distinct. Unweighted Schur conditions are sufficient and apply to this family only at a=b=0.
- The L-infinity Rademacher example has L2 compactness but outputs separated by1 in essential supremum norm. The C-compact/non-L2 and L2-compact/non-C examples preserve the correct direction of their space failures.
- New solution-error exercise uses the valid noncommuting factorization and bounds the solution difference by |lambda|M^2 delta/(1-|lambda|Mdelta) times data norm. No strong-to-operator-norm substitution occurs.
- Positive-kernel/operator-positivity example, logarithmic HS norm sqrt(7/2), compact-but-not-HS power model, and curve-versus-volume threshold check.

## Findings and exact correction

| ID | Location/original | Effect | Proposed text | Recheck |
|---|---|---|---|---|
| D254-PARAM | `exm:v19:254:sphere-power`, sentence introducing `e_alpha(epsilon)=2*pi integral_0^epsilon ...` has no epsilon restriction. | The exact integral and lower bound use chord radii no larger than2. For epsilon>2 the sphere has no points of chordal radius beyond2, while the written integral can still add mass. Small-cutoff conclusions are unaffected. | Change sentence to: `For the continuous radial cutoff and $0<\\varepsilon\\leq2$, the residual kernel ...`. Alternatively use an upper limit min(epsilon,2) and adjust bounds. | The full claimed exact identity and the following lower/upper bounds then lie within the already-derived cap range. Parent notified; not patched by reviewer. |
| D254-HEADING | `ex:v19:254:rough-rank-one`, heading `A bounded kernel with rough outputs` for k=x^(-1/4). | Kernel itself is unbounded, although the L2 operator is bounded. Exposition could teach a wrong distinction through its heading. | Rename to `A rank-one kernel with rough outputs`. | Computations and solution require no change. Nonblocking editorial correction. |

Conclusion: **targeted mathematics passes after the stated epsilon-domain restriction**; no consequential constant, mapping, compactness or exercise defect found in the selected extended blocks. Recheck the final chapter hash after the parent's correction. No claim of pass for a changed hash is made here.
