# V19 B-04 independent mathematical read — Chapter 252

Reviewed file: `drafts/ch252.tex`.

SHA-256 at actual read: `6778a2f9fcda973fd63cba5fbff391e66d4817558fc9a8284b9005079d3e3384`.

Role: independent B-04 mathematical read, distinct from its expansion author. Source here is the complete existing chapter, read in order; this review does not certify all Kress source coverage, B-05 integration, layout, or B-07 whole-volume acceptance. No edits were made to the chapter by this reviewer.

## Actual read

Every current section was read: equation-types; continuous-kernel; finite-rank-reduction; neumann-solution; compact-fredholm-tool; compatibility; symmetric-kernels; worked-resonance; approximation-stability; practice; dependency/source notes. The Riesz decomposition proposition and ensuing finite-block inverse were read as part of compact-fredholm-tool. All four exercises and solutions were checked, rather than excluded from the mathematical read.

## Result

**PASS for this chapter at this exact hash. No mathematical blocking defects found.** No previously recorded independent defect was assumed fixed merely from its label. The points requested for review were checked as follows.

| Obligation | Actual check and result |
|---|---|
| Continuous-kernel norm and compactness | Upper bound and conjugated row-test lower bound give the exact C-to-C norm. Output interpolation gives genuinely finite-rank operators and operator-norm convergence; it does not substitute quadrature pointwise convergence. Compactness proof closes in the Banach space. PASS. |
| Finite reduction, redundant generators and indexing | K=UV, M=VU uses M_ij=integral q_i p_j. From (I-lambda M)c=Vf, reconstruction gives Vu=c; thus coefficient/function correspondence is bijective even when U is not injective, including lambda=0. PASS. |
| Compactness of the full transpose | Restriction of the dual unit ball to compact closure K(B_E) is uniformly bounded and Lipschitz. Finite node nets give total boundedness in sup norm, which controls the norm of K'F-K'G. Completeness of E' supplies compact closure. No approximation property of general Banach spaces is invoked. PASS. |
| Closed range | Finite kernel established by compact identity on its subspace. Contradicting the quotient lower bound uses representatives with distance one and norm <=2, compact subsequence Kx_j, then x_j=Tx_j+Kx_j. The induced map on complete E/N takes Cauchy cosets to the limiting range value. PASS. |
| Range annihilator | Closedness is proved before Hahn–Banach separation. Full Banach transpose kernel, not the smaller integral pairing, is used at this stage. Finite codimension is obtained from quotient dual dimension with explicit Hahn–Banach extension argument. PASS. |
| Injective iff onto and index zero | Descending closed invariant range chain and ascending kernel chain have the correct nesting directions; the separated compact-image contradictions use K commuting with T. Finite-rank complement perturbation then compares p=dim ker T and q=codim range T without assuming index zero. Both p<q and p>q are covered. PASS. |
| Riesz decomposition | T^j is identity minus compact, so powers have finite kernels/closed ranges. Both chains stabilize by the separated-image argument. N_r=N_2r and R_r=R_2r give zero intersection and all-space sum. Projection boundedness through the finite-dimensional quotient is valid; invariance gives commutation. On R, T is bijective and boundedly invertible. PASS. |
| Nearby parameter and pole order | K restricted to G equals (I-N)/lambda_0, yielding (1-lambda/lambda_0)I+(lambda/lambda_0)N. The finite inverse has the correct minus sign and maximal order r. On R, the stated Neumann factorization is valid because S_R is inverse of T restricted to that invariant subspace. No full analytic Fredholm theorem is silently assumed. PASS. |
| Full dual versus continuous integral transpose | The E-valued integral argument proves each F composed with K has a continuous density. At nonzero lambda, F=lambda K'F therefore has continuous density; substitution establishes its integral transpose eigen-equation. This closes the smaller-pairing compatibility step. At zero the criterion is explicitly vacuous. PASS. |
| Hilbert adjoint and parameter | Inner product linear in first entry produces conjugate-transposed kernel and I-conjugate(lambda)K*. The complex rank-one exercise checks the parameter conjugation at lambda=-i. PASS. |
| C versus L2 | The chapter proves compactness again in L2 by product-kernel norm approximation. Spectral equalities are only L2 equalities. Continuous data recover a continuous representative from u=f+lambda Ku, rather than assumed uniform eigenfunction-series convergence. The x^-1/4 exercise preserves the singular datum and only makes u-f continuous. PASS. |
| Self-adjoint spectral input | Norm attainment from weak subsequence and compactness is justified in the separable Hilbert setting. A^2 norm eigenvector leads to a finite invariant Hermitian block with an eigenvalue +/-||A||. Repeated maximal choices and compactness force eigenvalues to zero and kill the final restriction. Denominators are uniformly bounded away from zero off finitely many resonant indices. PASS. |
| Worked rank-two case | The two displayed functionals are dual to 1,x. Kernel simplifies to -2+6y+x(-6+12y). Jordan matrix and regular coefficients agree. At lambda=1 compatibility is beta=ell_2(f)=0 and u_2=-alpha. The left/right distinction and quadratic inverse growth are real, not an artifact of normalization. PASS. |
| Perturbation and residual estimates | Factorization has the right order without assuming commuting perturbations. Inverse difference is lambda S_tilde(K_tilde-K)S. Residual uses the inverse norm; at resonance normalization is restricted to the range and a bounded complement. PASS. |

## Defect ledger and consequences

No blocking defect found, so there is no proposed correction or falsely claimed patch. The pass is invalidated if the reviewed chapter changes mathematically. Recheck especially the chain arguments, dual identification, lambda placement, adjoint conjugations and Riesz block formula if those interfaces change during B-05. Cross-chapter source landing reconciliation and previous-volume prerequisite locations remain the parent's integration responsibility; they were not converted into a mathematical defect in this self-contained proof.

The chapter contains its own usable compact Fredholm proof and spectral argument. This review relies on the chapter's explicitly invoked standard Banach/Hilbert foundations, Hahn–Banach, finite-dimensional Hermitian diagonalization and Lebesgue integration; it does not verify an external frozen volume or replace a complete source-item coverage audit.
