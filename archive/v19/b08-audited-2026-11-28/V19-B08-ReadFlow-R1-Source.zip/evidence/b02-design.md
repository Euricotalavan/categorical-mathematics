# V19 B-02 整卷設計 v1 — source reconciliation pending; boundary updates incorporated

2026-11-27 · Content expansion role · **Design only; no manuscript and no claim of B-02 approval.**

## 1. Receipt, authority, boundary

Actually read: `V19-Literature-Preparation-v1.md` in full and the B common/role provisions (second part) of `project_sources/13-A-B-v4.txt`. The preparation document is historical preparation evidence; its former waiting state does not override the current parent task. The parent has assigned V19, B single Work, B-02 design. This document neither changes the B workflow nor authorizes B-03/B-04 by itself.

Fixed volume title: **Locally Convex Spaces, Distributions, and Integral Equations**. Preserve exactly the twelve topics and chapter numbers **246–257** below. Adjacent-volume numbering is reported in the preparation file from Git `d9d72a253a9406a42410fa97ea98b6f64d623001`, V18 Chapters 232–245; I have not independently fetched that commit. Existing frozen manuscripts remain read-only.

Source responsibility below is a proposed design allocation using the preparation IDs T/H/K3/P1–P7, not a declaration that the designated source agents have read or approved those items. Uploaded primary-book evidence now exists, but its item-level reports must be reconciled before B-02 is declared complete. No unverified old third-party preview is silently promoted to evidence. Authoritative edition/page/hash assignments come from the source reports.

## 2. Reader contract and depth

The narrative is: **topology makes continuity precise → duality makes generalized functions usable → differentiation and kernels explain linear operations → compactness separates Fredholm equations from Volterra and singular models → complete examples test every hypothesis**.

Working depth is about **320–390 finished pages**, including complete proofs, worked examples and substantial exercises; this is a planning estimate, not a completion condition or a minimum to fill. A book of 400–570 source pages cannot be reduced to a list of theorem names. Conversely the three source books overlap and extend far beyond this volume. Only coverage responsibilities in the fixed boundary are included.

Every section must provide its mathematical purpose, typed definitions with quantifiers, the hypotheses that make its operations valid, a complete proof or a clearly named already-proved input, at least one worked application when first using a technique, and exercises that test the boundary. Exercise statements cannot carry an essential missing lemma in the main proof path. Solutions/hints should cover the less routine exercises and every exercise invoked later.

Assumed previous material must be checked against the actual fixed prior volumes: elementary measure and Lebesgue integration, Banach/Hilbert spaces, Hahn–Banach, Baire/open mapping/uniform boundedness, compact operators and the compact-operator Fredholm alternative. Until those locations are verified, mark them `PRIOR-UNVERIFIED`. Reproduce the exact usable statement locally; supply a local proof when the current argument needs an unverified stronger form. Fourier analysis and complex boundary-value theory are **not** assumed without verification.

## 3. Conventions to fix before drafting

1. Ground field is `K=R or C`, declared per theorem. A locally convex space is Hausdorff unless explicitly called a non-Hausdorff intermediate quotient. A seminorm family separates points precisely when the induced topology is Hausdorff. `E_p` denotes the completion of `E/ker p`; inequalities between seminorms precede maps between completions. Countable families use the explicit metric `sum 2^{-j} min(1,p_j(x-y))` and completion is distinguished from mere metrizability.
2. Continuous dual `E'` consists of **linear** scalar-valued maps. The dual-pair bracket `<x,x'>=x'(x)` is bilinear over C. The transpose `T'` is algebraic/continuous-dual transpose under that bracket. If a Hilbert inner product is used, take it linear in its first entry and conjugate-linear in its second; explain the conjugation in identifying the linear dual. Never replace transpose by Hilbert adjoint without a conversion formula. `(E,F)` is a separating dual pair only after separation on both sides is verified.
3. `sigma(E,F)` is pointwise convergence on F; `beta(E,F)` is uniform convergence on **sigma(F,E)-bounded** subsets of F. For a given lcs E its strong dual is `E'_beta`, uniform convergence on the bounded subsets of the **given topology of E**. Distinguish these definitions before using any theorem that identifies bounded sets for compatible topologies. `tau(E,F)` is the Mackey topology; the Mackey–Arens theorem, if retained, is a named bounded scope theorem with its source/proof responsibility, never an assumed equality `beta=tau`.
4. For open `Omega⊂R^d`, `D_K(Omega)={phi∈C∞(Omega):supp phi⊂K}` with seminorms of all derivatives, K compact; use a specified compact exhaustion with `K_j⊂int K_{j+1}`. `D(Omega)` carries the usual locally convex inductive-limit topology. A sequence converges iff all its terms eventually have support in one K and every derivative converges uniformly there; explicitly say this characterizes **sequences**, not arbitrary nets. The bounded-set theorem needs a proof; it is not part of the definition.
5. Distributions are continuous **linear**, not antilinear, functionals on D; `<u,phi>` has no conjugation. Regular distributions are `<T_f,phi>=∫f phi`. `(partial^alpha u)(phi)=(-1)^|alpha|u(partial^alpha phi)`. Define multiplication only by smooth functions. The canonical map `E'(Omega)→D'(Omega)` uses cutoff extension and identifies compactly supported distributions only after proof. Distinguish `E=C∞` from a generic lcs E by typography/context.
6. Kernel ordering is **output x first, input y second**: `<T_K f,g>=<K,g(x)f(y)>`. This is bilinear. Derivatives give `K_{partial_x T}=partial_x K_T` and `K_{T partial_y}=-partial_y K_T`. Identity has diagonal delta kernel, which is not an L2 function. Compactness of a Hilbert–Schmidt operator and existence of a distribution kernel are separate theorems.
7. Main integral-equation convention is `(I-lambda K)u=f`, `Ku(x)=∫k(x,y)u(y)dy`; therefore the **integral resolvent operator** `R_lambda=K(I-lambda K)^{-1}` satisfies `(I-lambda K)^{-1}=I+lambda R_lambda`. Its series is `sum_{n≥0}lambda^n K^{n+1}`. The operator resolvent `(zI-K)^{-1}` has a different parameter and must be named separately. Resonance `lambda=1/mu` applies to nonzero eigenvalues mu; lambda=0 is always regular. Volterra uses the same lambda placement.
8. Real Fourier convention: `F f(xi)=∫ e^{-ix xi}f(x)dx`, inverse `(2pi)^{-1}∫e^{ix xi}Ff(xi)dx`; Plancherel is `||Ff||_2=sqrt(2pi)||f||_2`. Fourier multipliers may instead be described using the unitary transform, but normalization cannot change mid-proof. `Hf(x)=pi^{-1}pv∫ f(y)/(x-y)dy` has multiplier `-i sgn xi`, hence `H^2=-I` on L2(R). This sign must be checked by deriving it from truncated kernels or an explicitly justified regularization.
9. The circle is oriented counterclockwise. For `z∈T`, `Sf(z)=(pi i)^{-1}pv∮_T f(zeta)/(zeta-z) dzeta`. On modes `z^n`, S is +1 for n≥0 and -1 for n<0, so `S^2=I`. With `C f(w)=(2pi i)^{-1}∮ f(zeta)/(zeta-w) dzeta`, interior/exterior boundary values are `C_+=P_+`, `C_-=-P_-`, and `C_+-C_-=I`, `C_++C_-=S`. Prove these first on trigonometric polynomials and extend in L2. Do not confuse this S with real-line H.

## 4. Chapter plan

The short slug in each row is a stable section-label component. Use `ch:v19:246`, `sec:v19:246:seminorm`, etc.; definitions/theorems/lemmas/examples/exercises use their type prefix followed by the same chapter and descriptive slug. Numeric display counters may change; semantic labels must not. Each chapter ends with a dependency recap and source responsibility checklist; these are editorial records, not substitute content.

### Chapter 246 — 半範數與局部凸拓撲 (Seminorms and Locally Convex Topologies), 24–29 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `why-local-convexity` | Motivation through uniform control of derivatives and moment/evaluation conditions; distinguish a topology from one norm. Work two inequivalent modes of convergence. |
| 2 `seminorm` | Seminorm, gauge, kernel and quotient; prove all basic inequalities and give nonseparating examples. |
| 3 `seminorm-topology` | Finite intersections of seminorm balls define a vector topology; prove local convexity and the Hausdorff criterion. |
| 4 `gauge-reconstruction` | Balanced convex absorbing neighborhoods and Minkowski functional; prove recovery of every lcs topology, including open-ball inclusions. |
| 5 `continuity-estimate` | Linear-map continuity iff each target seminorm is dominated by a finite sum/max of source seminorms. Use it on differentiation and an explicit discontinuous functional. |
| 6 `countability-metric` | Countable families, metric construction, convergence and Cauchy sequences; separate completeness from metrizability. |
| 7 `frechet-examples` | C∞ on an open set via compact exhaustion and D_K; prove completeness, not just name Fréchet spaces. |
| 8 `bounded-quotient-product` | Bounded sets, induced/quotient/product topology; prove boundedness criterion and compute finite-product examples. Avoid treating boundedness as compactness. |
| 9 `separation-toolkit` | Continuous linear functionals separate points; locally convex Hahn–Banach separation in exactly the strength needed by polars/bipolars. |
| 10 `practice` | Worked topology-comparison example and a counterexample to normability; exercises on gauges, equivalent seminorms and non-Hausdorff quotients. |

Proof responsibilities: topology/gauge equivalence, continuity estimate, completeness of C∞/D_K, boundedness criterion. Source responsibilities proposed: T ch7–10/14 and P1; exact extraction to be reconciled.

### Chapter 247 — 對偶配對 (Dual Pairings), 23–28 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `linear-dual-conventions` | Algebraic versus continuous dual, bilinear complex convention, Hilbert-dual conjugation worked explicitly. |
| 2 `dual-pair` | Separating dual pairs; finite-dimensional, l^p/l^q and test-function examples with domains. |
| 3 `annihilator` | Annihilators, transpose and annihilator identities for kernels/ranges; distinguish closure-dependent equalities. |
| 4 `polar` | Absolute polar, bipolar and balanced convex hull; compute polars of a ball and finite seminorm constraints. |
| 5 `weak-topology` | Construct sigma(E,F), prove its continuous dual is exactly F, including the finite-coordinate argument. |
| 6 `bipolar-theorem` | Prove the bipolar theorem from separation, specifying weak closure and absolute convexity. |
| 7 `equicontinuity` | Equicontinuous sets of functionals and neighborhood polars; prove equicontinuity iff a common continuous seminorm bounds the set. |
| 8 `weak-star-compactness` | Alaoglu–Bourbaki for a neighborhood polar via product compactness and closed linearity constraints. Include finite-dimensional and Banach specializations. |
| 9 `adjoint-examples` | Integral-operator transpose with kernel order; rank-one and nonconjugated distribution brackets. |
| 10 `practice` | Work a solvability obstruction from an annihilator; exercises diagnosing wrong duals, missing closures and complex conjugations. |

Proof responsibilities: weak continuous dual, bipolar and polar compactness. Do not redevelop the V18 spectral theorem. Proposed sources: T ch18–19/36, P1 and K3 ch4 for convention comparisons.

### Chapter 248 — 弱與強對偶拓撲 (Weak and Strong Dual Topologies), 25–30 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `weak-convergence` | Weak/weak-star convergence, sequences versus nets, concrete l2 examples. |
| 2 `bounded-dual-pair` | Weakly bounded sets and estimates; prove the locally convex weakly bounded iff bounded theorem for a fixed lcs using its seminormed quotients and uniform boundedness. |
| 3 `uniform-on-sets` | Topologies of uniform convergence on classes of sets, strong-dual seminorms and comparison maps. |
| 4 `banach-strong-dual` | On a normed space the strong dual topology is its norm topology; prove and compare weak-star compactness with norm noncompactness. |
| 5 `barrels-uniform-boundedness` | Barrels/barrelled spaces, Baire proof for Fréchet spaces, pointwise bounded families become equicontinuous. State and prove precisely the version needed later. |
| 6 `bilinear-continuity` | Separately continuous bilinear forms on a product of Fréchet spaces are jointly continuous; give the Baire/equicontinuity proof used in the local kernel theorem. |
| 7 `transpose-topologies` | Continuity of transpose for weak and strong duals; strong case uses preservation of bounded sets. |
| 8 `compatible-topologies` | Compatibility and Mackey topology as an explicitly bounded advanced interface. If full Mackey–Arens proof is not covered, mark this as orientation with no downstream dependence rather than claim coverage. |
| 9 `dual-of-frechet-examples` | Strong dual of C∞ and sequence spaces; distinguish weak convergence, strong convergence and equicontinuity with worked examples. |
| 10 `practice` | Exercises on delta sequences, transpose bounds and false weak-to-strong assertions; include a nonbarrelled boundary only if source evidence supports it. |

Proof responsibilities: bounded-set comparison, Fréchet uniform boundedness, bilinear continuity and strong transpose. Proposed sources: T ch14/19/34–36, P1/P2.

### Chapter 249 — 測試函數與分布 (Test Functions and Distributions), 28–34 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `cutoffs` | Bump functions, compact exhaustions and locally finite partitions of unity; give constructive proofs sufficient for localization. |
| 2 `test-frechet` | D_K with its derivative seminorms; support condition, completeness and inclusions. |
| 3 `test-lf-topology` | D as a locally convex inductive limit; universal continuity property and independence of exhaustion, with the necessary strictness facts justified. |
| 4 `test-bounded-convergent` | Prove the fixed-compact support boundedness theorem and sequential convergence criterion; explain why arbitrary nets cannot be characterized by the same shortcut. |
| 5 `distribution-definition` | Equivalent continuity and finite-order-on-each-compact estimates; order may depend on K. Prove both directions. |
| 6 `regular-and-dirac` | L1_loc embedding and its injectivity using mollifiers; delta, point derivatives as anticipation, measure distributions. |
| 7 `restriction-support` | Restriction, locality, support and gluing with partitions; prove support criteria and uniqueness of gluing. |
| 8 `compact-support` | E topology and E' identification with compactly supported distributions; cutoff-independence, finite global order on a compact neighborhood. |
| 9 `convergence-regularization` | Weak distribution convergence, approximate identities, regularization and density with exact support control. |
| 10 `practice` | Work delta approximation, a distribution with growing local order and support tests; exercises requiring a usable continuity estimate. |

Proof responsibilities include LF bounded sets and local/global order distinction; neither may be replaced by an informal description of D. Proposed sources: T ch10/13/15–16/21, H I–II, P1/P3.

### Chapter 250 — 分布導數 (Distributional Derivatives), 26–31 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `transpose-derivative` | Define derivatives as transposes, prove continuity and agreement with classical derivatives. |
| 2 `smooth-multiplication` | Smooth multiplication, Leibniz formula with multiindices and support inclusions; explain why a general distribution product is unavailable. |
| 3 `jumps` | Heaviside and jump derivatives; piecewise smooth functions and interface delta terms. |
| 4 `principal-value` | Define pv(1/x), prove existence/continuity by subtracting phi(0), distinguish finite part from ordinary improper integral. |
| 5 `log-and-finite-part` | Derive d(log|x|)/dx=pv(1/x); compute one higher derivative with the correct finite-part definition. |
| 6 `constant-distributions` | Prove u'=0 implies constant on an interval; solve u'=f by a distributional primitive and determine the constants. |
| 7 `translation-convolution` | Translation/reflection, convolution when one factor has compact support, support bounds and derivative interchange; justify every exchange of pairings. |
| 8 `tensor-distributions` | Tensor product of distributions, parameter dependence and Fubini-type pairing; establish the tools used in ch251. |
| 9 `point-support` | Prove a distribution supported at a point is a finite sum of delta derivatives using its finite-order estimate and cutoff/Taylor argument. |
| 10 `practice` | Work a fundamental solution for an elementary constant-coefficient ODE; exercises on jump signs, support and invalid products. |

Proposed sources: T ch23–24, H III, P1/P3. General diffeomorphism pullbacks, arbitrary distribution products and microlocal singularities are outside this chapter's responsibility.

### Chapter 251 — 核空間入口 (An Introduction to Nuclear Spaces), 34–42 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `three-kernel-notions` | Distinguish integral kernels, distribution kernels and nuclear decompositions through identity, rank-one and Hilbert–Schmidt examples. |
| 2 `projective-tensor` | Algebraic tensor product and projective seminorms, Hausdorff completion and the continuous bilinear-map universal property; prove the property. |
| 3 `nuclear-maps` | Nuclear maps into Banach spaces and local Banach-completion criterion for nuclear lcs; state exact summability/equicontinuity conventions. |
| 4 `hilbert-schmidt` | Hilbert–Schmidt maps, composition of two Hilbert–Schmidt maps is nuclear; prove via an orthonormal expansion and Cauchy–Schwarz. |
| 5 `rapid-sequences` | Rapidly decreasing sequence space s and Hilbert scale; choose exponent gaps explicitly so inclusions are Hilbert–Schmidt, hence obtain nuclearity. |
| 6 `periodic-smooth` | C∞(T^d) corresponds to rapid Fourier coefficients; prove coefficient decay and convergence of differentiated series, including the Fourier completeness input. This gives a fully proved nuclear example. |
| 7 `test-space-interface` | Describe the nuclearity of C∞, D and S only at the exact source-backed strength. If permanence/localization proof is not written, label the broader statement a named orientation theorem and do not rely on it for the kernel proof. No claim that this constitutes a full abstract nuclear-space course. |
| 8 `local-tensor-density` | Localized double Fourier series of a test function on product boxes converge in D with explicit derivative and coefficient estimates; tensor products are dense. |
| 9 `kernel-theorem-local` | For continuous T:D(Y)→D'(X) with the weak distribution topology, obtain a jointly continuous bilinear form on each D_K×D_L, polynomial coefficient bounds, and construct K locally by the series. Prove the distribution estimate and agreement on simple tensors. |
| 10 `kernel-theorem-global` | Glue local kernels by partition of unity; prove consistency, uniqueness, both directions of the operator correspondence and weak continuity. State stronger topological variants only after fixing their topology and proof. |
| 11 `kernel-examples` | Work multiplication, differential operators, identity and convolution kernels, including x/y signs; show no implication of compactness. |
| 12 `practice` | Exercises on nuclear expansions, failure of naive function-kernel representations, tensor density and reconstructing a derivative kernel. |

**Critical design:** the actual finite-dimensional Schwartz kernel theorem receives a complete direct proof. It does not depend on an unproved abstract nuclear-space theorem. Abstract generalizations remain introductory and precisely delimited. Proposed sources: T ch39–43/47–51, H V §5.2, P2/P3/P4; P7 historical context only unless individually read.

### Chapter 252 — Fredholm 積分方程 (Fredholm Integral Equations), 25–30 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `equation-types` | First/second kind, parameter and operator convention; distinguish a representation from a solvability theorem. |
| 2 `continuous-kernel` | On C[a,b], prove boundedness and compactness of continuous kernels by uniform continuity and Arzelà–Ascoli, or finite-rank approximation. This special proof occurs here to avoid a forward dependency on ch254. |
| 3 `finite-rank-reduction` | Degenerate kernels, exact matrix reduction, reconstruction and dependence/independence issues in the chosen spanning functions. |
| 4 `neumann-solution` | Neumann series with norm convergence, uniqueness and quantitative error bounds. |
| 5 `compact-fredholm-tool` | Recall or prove the exact compact-operator Fredholm alternative needed from V18; distinguish Banach transpose from Hilbert adjoint. |
| 6 `compatibility` | Derive solvability conditions through annihilating adjoint nullspace and describe all solutions at resonance. |
| 7 `symmetric-kernels` | Real symmetric/complex Hermitian kernels on L2, spectral expansion and the exact coefficient convergence used. |
| 8 `worked-resonance` | Rank-two example solved at regular and resonant parameters, with compatible and incompatible right sides. |
| 9 `approximation-stability` | Finite-rank approximation away from resonance; inverse perturbation estimate, not a numerical-method survey. |
| 10 `practice` | Exercises testing nullspaces, correct adjoint kernels and norm versus pointwise convergence. |

Proposed sources K3 §§2.3/3.1/4.3–4.4, P5 §§2.1–2.4. No general determinant theory is required.

### Chapter 253 — Volterra 積分方程 (Volterra Integral Equations), 23–28 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `triangular-domain` | Triangle Delta={a≤t≤x≤b}, bounded continuous kernels and extension choices; fixed operator domain. |
| 2 `initial-value-conversion` | Derive an initial-value equation both directions and track regularity/initial conditions. |
| 3 `iterated-kernels` | Iteration over ordered simplices; prove the (b-a)^n/n! estimate with precise M powers. |
| 4 `entire-inverse` | Show all lambda give an inverse on C[a,b] from factorial convergence and prove uniqueness directly. |
| 5 `volterra-resolvent` | Define iterated kernels and the resolvent kernel with the fixed lambda convention; prove uniform convergence on Delta. |
| 6 `convolution-case` | Convolution Volterra kernels and explicit exponential kernel, without importing an unproved Laplace transform theorem. |
| 7 `stability-gronwall` | Derive Grönwall-type estimates from iteration and connect parameter/data dependence to the kernel norm. |
| 8 `first-kind` | Differentiate a first-kind equation under explicit regularity and nonvanishing diagonal hypotheses; identify compatibility at the initial point. |
| 9 `l2-triangular-factorial` | For triangular k∈L2, set a_0(t)=∫_a^t|k(t,s)|²ds, A(t)=∫_a^t a_0(s)ds and w_n(t)=∫_a^t|V^nf(s)|²ds. Cauchy–Schwarz gives w_n≤∫a_0 w_{n-1}, hence w_n(t)≤||f||²A(t)^n/n!, ||V^n||≤||k||_2^n/sqrt(n!), and an inverse for every lambda. This separate proof is not inherited from the continuous-kernel theorem. |
| 10 `practice` | Work a forced first-order ODE, its integral solution and residual; exercises on factorial bounds and failed first-kind inversion. |

At lambda≠0, V has no nonzero eigenvalue; spectrum={0} requires the ambient complex Banach-space and noninvertibility-at-zero argument, not just the estimate. For the L2-triangular operator, ch253 proves the elementary kernel norm bound locally; ch254 later generalizes it. Compactness then supplies noninvertibility in the infinite-dimensional space, or that conclusion waits until ch254. Proposed sources K3 §3.3, P5 §4.1/§1; the L2 extension has its own proof responsibility.

### Chapter 254 — 積分核與緊性 (Integral Kernels and Compactness), 27–33 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `mapping-before-compactness` | Space/measure/kernel matrix: C, L2 and Lp claims each need their own hypotheses. |
| 2 `continuous-compact` | Generalize ch252's interval proof to compact metric domains; no duplicate full proof. |
| 3 `schur-estimate` | Schur test with explicit two integral bounds; boundedness precedes compactness. |
| 4 `hilbert-schmidt-kernels` | k∈L2(X×Y) defines a bounded Hilbert–Schmidt operator; prove norm identity in the stated separable setting. |
| 5 `l2-finite-rank` | Density of finite tensor sums, compactness and operator-norm error ≤L2 kernel error. |
| 6 `weak-singular-l2` | On bounded domains, kernels dominated by C|x-y|^{-alpha}, alpha<d, with stated off-diagonal regularity; cut out a diagonal band, prove compactness on L2 via Schur tail control and compact truncations. |
| 7 `weak-singular-continuous` | Give the stronger uniform-integrability/off-diagonal continuity assumptions needed for C→C compactness; avoid falsely extending the L2 result by assertion. |
| 8 `noncompact-models` | Identity, real-line translation-invariant kernels and principal-value kernels as counterexamples to naive compactness claims; use only elementary noncompactness arguments here. |
| 9 `model-comparison` | Work a logarithmic kernel and a power kernel, determine exactly which criterion applies, and state what remains undecided. |
| 10 `practice` | Exercises on tails, kernel approximation, failure at the threshold and a kernel that is compact but not Hilbert–Schmidt. |

The phrase weakly singular never implies compactness without domain, exponent and regularity hypotheses. Proposed sources K3 §§2.3–2.5, P5 §2.2 and V18 compactness interface.

### Chapter 255 — 奇異積分方程的模型 (Models of Singular Integral Equations), 32–40 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `cancellation-vs-absolute` | Contrast weak singularity, Cauchy principal value and finite parts with exact definitions; connect pv(1/x) from ch250. |
| 2 `fourier-bridge` | Establish the stated real-line Fourier normalization, inversion/Plancherel in the needed class and L2 extension. Cite verified previous proofs or supply them; never say "by Fourier analysis" with no input. |
| 3 `hilbert-multiplier` | Derive the Hilbert multiplier using a justified regularization/truncation; define H on L2 by extension, prove boundedness and H²=-I. |
| 4 `principal-value-meaning` | For a safe dense class identify the multiplier with pv convolution. Distinguish convergence in L2 from pointwise a.e. principal values; the latter general theorem is excluded unless proved. |
| 5 `hilbert-equation` | **Actually solve** `(aI+bH)u=f` on complex L2, for constants with a²+b²≠0, inverse `(aI-bH)/(a²+b²)`. Explain the real-coefficient case. |
| 6 `hilbert-resonance` | At a²+b²=0 analyze positive/negative frequency projections and give exact compatibility, homogeneous solutions and failure of finite-dimensional Fredholm behavior. Include a=b=0 separately. |
| 7 `circle-fourier` | Define trigonometric basis, P+ and P-; derive normalized circle Cauchy singular operator eigenvalues directly on modes. |
| 8 `circle-boundary-values` | Prove radial L2 interior/exterior Cauchy boundary values by Fourier series, including exterior minus sign; no general contour theorem is smuggled in. |
| 9 `circle-equation` | **Actually solve** `(aI+bS)u=f` when a±b≠0; classify resonant data with P±. Compare S²=I with H²=-I. |
| 10 `practice-scope` | Worked right sides with positive and negative Fourier modes; exercises checking normalization/signs. Delimit curved-contour Hölder theory, variable coefficients, index/winding-number theory and Riemann–Hilbert problems. |

Thus the Cauchy entry is a genuine Cauchy-kernel model with an equation and compatibility conditions, not just an analogy to H. K3's broader smooth-contour Cauchy treatment is not claimed covered by a circle model. Proposed sources: K3 §§7.1–7.5, H VII selected Fourier sections, P6; source agents must identify the exact model substitutions and exclusions.

### Chapter 256 — 預解與可解條件 (Resolvents and Solvability Conditions), 25–30 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `two-resolvents` | Integral resolvent R_lambda versus spectral resolvent (zI-K)^-1, domains and conversion formula for lambda≠0. |
| 2 `resolvent-identities` | Prove inverse identity and R_lambda-R_mu=(lambda-mu)R_lambda R_mu; no commutation assumed before proof. |
| 3 `neumann-domain` | Norm convergence and continuation along regular parameter sets; distinguish a sufficient disk from the full resolvent set. |
| 4 `resolvent-kernel` | Conditions ensuring a genuine function resolvent kernel; show Neumann iterated kernels with uniform/L2 convergence where valid. Do not infer function kernels from bounded-operator inverses alone. |
| 5 `compact-resonances` | Discrete nonzero compact spectrum, finite-dimensional generalized eigenspaces and solvability. Use exact verified V18 theorem or supply the needed proof. |
| 6 `selfadjoint-case` | Spectral formula, compatibility at each resonance and bounds away from spectrum. |
| 7 `nonnormal-case` | Fixed Jordan poles plus a proved local analytic compact-family Schur reduction on complete Hilbert splittings, effective compatibility, transverse residue and tangential crossing; actual L2 kernel realization with resonant-block-preserving truncation errors. Global analytic continuation remains outside scope. |
| 8 `volterra-comparison` | Entire lambda-dependence from factorial estimates; compare with meromorphic compact Fredholm behavior. |
| 9 `singular-comparison` | Revisit ch255 resolvents/projections; H/S are bounded noncompact and have infinite-dimensional resonant nullspaces, so compact Fredholm conclusions do not transfer. |
| 10 `practice` | Work a parameterized family through regular/resonant values; exercises on resolvent sign errors, radius of convergence and data compatibility. |

General analytic Fredholm theory for arbitrary analytic compact families is outside scope unless the source responsibility explicitly requires it. Proposed sources K3 §§2.4/3.2/4.3/5.2–5.3, P5 §§2.4–2.5/4.1.

### Chapter 257 — 完整積分方程案例 (Complete Integral-Equation Case Studies), 28–34 pages

| § / slug | Content and required evidence of understanding |
|---|---|
| 1 `case-contract` | Every case must give model, spaces, parameter, derivation both ways, mapping properties, solvability, computation and back-substitution with error/regularity conclusions. |
| 2 `rank-two-model` | New nonorthogonal separable kernel K=UV with an explicitly computed 2×2 matrix VU; derive the exact finite system and reconstruction without assuming U injective. |
| 3 `rank-two-resonance` | Vary lambda and forcing through unique, compatible nonunique and incompatible regimes. Include a forcing perturbation that destroys compatibility and an inverse estimate. |
| 4 `damped-memory-model` | Use a new memory kernel such as `(t-s)e^{-gamma(t-s)}` on a finite interval. Introduce auxiliary memory variables and derive the finite ODE system plus all initial conditions. |
| 5 `damped-memory-solution` | Solve for a nonconstant datum, compute the resolvent by elementary convolution/ODE methods, verify by substitution and quantify data/parameter sensitivity. No unproved Laplace transform input. |
| 6 `weak-singular-case` | Logarithmic equation with certified Neumann remainder, plus a damped Abel second-kind kernel outside the Hilbert–Schmidt class; prove A_gamma squared equals exponential Volterra and solve at every finite parameter. |
| 7 `cauchy-complete-case` | Choose explicit positive/negative circle modes; solve in regular and resonant coefficient regimes, compute interior/exterior Cauchy fields and verify the boundary jump. |
| 8 `real-line-comparison` | A nontrivial Schwartz/L2 datum in the Hilbert model, with solution/frequency support computed explicitly. Verify the equation in L2 and compare circle signs. |
| 9 `abel-first-kind` | Complete weighted Abel inversion and sup-norm inverse instability, followed by a causal delay/distribution-kernel case with explicit local convolution extension, impulse response, every half-line L2 parameter regime, compatibility and perturbation estimates. |
| 10 `synthesis-exercises` | Compare which conclusions come from triangularity, compactness or cancellation. Exercises require choosing the correct theorem and rejecting an inapplicable one, with full/hinted solutions for longer cases. |

Proposed sources K3 §§1.1/4.4/6.3–6.4 (7.4–7.8 only to the selected singular-model extent), P5 §1 and relevant examples. Boundary review reports V18 ch245 already treated constant-kernel Volterra and min(x,t) Green models; neither is a main V19 case. General boundary-integral methods for multidimensional PDEs, numerical quadrature and inverse problems are excluded.

## 5. Forward-dependency audit and anti-circularity fixes

| Potential cycle / hidden prerequisite | Exact repair and validation |
|---|---|
| Ch252 uses compact integral operators before ch254 | Ch252 proves the restricted continuous-kernel C[a,b] result locally. Ch254 generalizes it; ch252 does not cite a future proof. |
| Ch251 kernel theorem relies on nuclearity of D, whose proof already uses a kernel theorem | Actual D→D' theorem is proved by localized Fourier expansions and Fréchet bilinear continuity from ch248. No tensor nuclearity theorem is used in that proof. Abstract nuclearity statements cannot be cited to close it. |
| Localized Fourier-series proof secretly uses ch255's Fourier transform | Ch251 proves the compact periodic Fourier-series estimates and required completeness separately. Real-line inversion/Plancherel remain in ch255. These are distinct interfaces. |
| D topology is only a sequence convention | Ch249 defines the actual lcs inductive-limit topology, proves its needed universal property and bounded-set theorem, then derives sequence statements. |
| Joint bilinear continuity is assumed from separate continuity | Ch248 provides the Fréchet theorem with Baire proof. Ch251 applies it only to fixed D_K×D_L and supplies the resulting finite derivative estimate. It makes no blanket claim for arbitrary lcs products. |
| Tensor-distribution construction relies on the kernel theorem | Ch250 constructs u⊗v directly using smooth parameter dependence on fixed supports and derivative bounds. Ch251 uses that construction/density later. |
| Singular operators are treated as compact Fredholm operators | Ch254 separates weakly singular compact kernels from principal-value operators. Ch255 proves boundedness/invertibility by Fourier projections. Ch256 explicitly compares the different spectral behavior. |
| Circle Cauchy model imports general complex analysis | Ch255 works on the circle by geometric series/Fourier modes, proves the interior/exterior formulas and radial L2 convergence, and restricts the conclusion to that model. General contour deformation and nontangential boundary theorems are excluded. |
| Equation examples need later resolvent theory | Ch252/253 prove their own basic solution formulas. Ch256 synthesizes/generalizes. Ch257 references only established results. |
| L2 Volterra proof quietly cites future Hilbert–Schmidt theory | Ch253 supplies the Cauchy–Schwarz bound and w_n induction itself. Ch254 proves general Hilbert–Schmidt theory. L2 resolvent-kernel convergence via the ideal estimate belongs in ch256 after both. |
| Green kernel BVP assumes hidden spectral completeness | Derive Green function directly. Verify the sine completeness theorem in a prior volume or prove it using the elementary interval Fourier theory; otherwise obtain compatibility by the ODE and integration by parts directly. |
| Weakly bounded = bounded or strong = norm used outside valid setting | Ch248 specifies the given lcs and dual pair, proves the bounded-set result and restricts strong=norm to normed E. No equality beta=tau is assumed. |

Internal drafting order is chapter order. Inside ch251 the abstract introductory blocks can be drafted before or after the direct proof, but the reader sees each premise before use. Ch255 Fourier bridge is a local substantive teaching unit, not a one-line imported assertion.

## 6. Main proof chain, examples and assessment

The nondelegable main-text proof chain is:

`seminorm topology/gauges → dual separation/polars → Fréchet uniform boundedness and bilinear continuity → D topology/estimates/localization → distribution operations and tensor products → localized kernel theorem`;

and independently

`continuous-kernel compactness → finite rank/Neumann/Fredholm → Volterra factorial estimate → Schur/Hilbert–Schmidt/weak singularity → Hilbert and circle multipliers → resolvent distinctions → IVP/BVP/singular full cases`.

Each chapter needs approximately 2–4 substantial worked examples integrated with its proofs, plus shorter counterexamples. The design tables name the mandatory ones. Exercises should span direct checks, proof reconstruction and boundary/counterexample questions; counts are not acceptance criteria. Repeating an identical rank-one example in three chapters is not textbook depth. Later use may refer to the same evolving example only when the new chapter asks a materially different question.

The new rank-two case tests compatibility under perturbation; the damped-memory case checks causal iteration against an auxiliary ODE system; the weak-kernel case demonstrates a rigorous solution and remainder without a closed form; the complete Cauchy case joins Fourier modes to actual boundary values and resonant solving. The source-backed Abel case supplies a complete first-kind contrast in weighted spaces without repeating V18 main models.

## 7. Scope exclusions and responsibility boundaries

Excluded, with no claim of source coverage: a full classification of locally convex spaces; a complete Mackey/Schwartz/Montel/bornological theory; the whole theory of tensor topologies and all nuclear permanence results; hyperfunctions, Sobolev/microlocal wavefront theory and pseudodifferential operators; arbitrary pullback/product of distributions; general smooth-curve Plemelj theory, variable-coefficient singular equations and their winding-number index; full analytic Fredholm theorem for analytic operator families; numerical integral-equation methods and ill-posed inverse problems; multidimensional boundary-potential theory. A historical note may name these subjects but cannot mark their source items covered.

Specific source chapters may contain more than the volume's scope. Every extracted item must be individually mapped to a section or excluded with a reason; chapter title coincidence is insufficient. In particular T ch50–51 are much broader than a direct Euclidean distribution kernel theorem, H VII is much broader than the real-line Fourier bridge, and K3 ch7 includes boundary/contour theory beyond the two constant-coefficient singular models.

## 8. Label and integration plan

Unique document root: `v19-work/manuscript/` when B-04 is authorized; no manuscript exists from this task. Reserve one `chapter-246.tex` through `chapter-257.tex` and a single shared notation file. All patches target these same files; no role gets a rival formal manuscript.

Labels: `ch:v19:<n>`, `sec:v19:<n>:<slug>`, `def:v19:<n>:<slug>`, `thm:v19:<n>:<slug>`, `lem:v19:<n>:<slug>`, `prop:v19:<n>:<slug>`, `ex:v19:<n>:<slug>`, `eq:v19:<n>:<slug>`, `prob:v19:<n>:<slug>`. Examples: `thm:v19:251:schwartz-kernel`, `eq:v19:253:iterated-kernel`, `thm:v19:255:hilbert-equation`, `thm:v19:255:circle-plemelj`, `ex:v19:257:rank-two-resonance`. Prohibit labels containing only a display number. Global notation and external-volume references require actual fixed-source locations.

B-05 integration must trace: each definition's first use; each forward reference; real/complex conversions; weak/strong topology changes; compact support and kernel order; lambda signs; H versus S; operator resolvent versus integral resolvent; exact assumptions in every return from an integral equation to a differential equation. A changed pairing convention affects ch247–257 and invalidates all associated adjoint/kernel proofs; a changed Fourier normalization affects ch251 periodic conventions separately from ch255 real-line conventions and all singular cases.

## 9. Boundary review receipt and immediate drafting gates

After v1 creation, actually read `b01-boundary.md` and `proof-risk-notes.md`. They agree on the fixed twelve chapters, concrete kernel proof, real-line Hilbert/circle models, and introductory nuclearity boundary. This revision incorporates the separate L2-triangular factorial proof and V18 overlap exclusions. Full source-row reconciliation remains separate.

Drafting gates: (1) maintain this exact chapter order/section-label skeleton; (2) fix the nine conventions before a dependent section; (3) never use a source item still marked unread as proof evidence; (4) close local prerequisite estimates before use; (5) every completed subsection gets proof/example/coverage evidence in its single formal text; (6) chapter integration and B-07 remain later independent obligations. No gate creates a new per-section user approval requirement.

## 10. OPEN / UNKNOWN and next handoff

| ID | Status and responsible next action |
|---|---|
| OPEN-SOURCE-MAP | Parent/B-01 reconcile the three source agents' actual item-level reports with all rows above; this v1 does not certify a single unseen page. |
| PRIOR-UNVERIFIED | Parent/B-01 verify exact prior-volume locations for the functional-analysis and integration inputs. Supply local proofs for unverified strengthened versions. |
| OPEN-NUCLEAR-SCOPE | Exact nuclearity permanence scope to be fixed from T/P2 evidence. The direct kernel proof remains mandatory independent of that decision. |
| OPEN-FOURIER | Verify existing Fourier/complex-analysis curriculum; otherwise retain the substantive local Fourier bridge and circle-only boundary proof as designed. |
| OPEN-LV | Parent requested "exact LV conventions"; this draft explicitly fixes locally convex conventions and lambda/Volterra conventions. If LV denotes a different named convention, parent must specify its source and this row stays OPEN. |
| UNKNOWN-MODEL | Runtime model/reasoning details were not independently inspected by this role; no claim of a model switch or High verification. |
| OPEN-FINAL-BOUNDARY | Parent/B-01 must confirm source mapping and scope substitutions, especially circle Cauchy versus full K3 contour theory. No boundary conflict is silently decided by this design. |

Handoff: expansion role → parent/B-01 precision role, B-02 (A original steps 02–04 design component). Actual read receipt is above. Unique design is this file v1; unique formal manuscript, source/PDF pairing, page inspection and B-05 evidence do not yet exist. Formal layout remains V0 ReadFlow R1, artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, but this role has not inspected or modified template bytes and creates no local style patch.

Next unique action: **reconcile actual source responsibilities and return the dependency/scope objections once to the design role**. Acceptance for B-02: each included source item has a meaningful location; all essential proofs have a noncircular path; prior inputs and exclusions are explicit; only then freeze the design and enter the already authorized next B stage through the parent. Do not redraft V18, alter chapter numbers, edit extractor ZIP/curriculum/reference tables, claim B-07 approval, publish, or start another volume.

Delivery/receipt distinction: file produced in the shared workspace and parent notified; user delivery and Library persistence are the parent's responsibility. This note is not an external message and is not a receipt that another role has read it.
