# V19 B-06 完整交接與接收回執

【交接】
交接ID／版本／日期：V19-B06-LAYOUT-v1／v1／2026-11-27 UTC。
發出／接收：本Work行文排版角色→本Work統籌及唯一B07打厚終審角色；agent訊息可送達；對話URL未核實。
卷號卷名／方案階段狀態：V19, Locally Convex Spaces, Distributions, and Integral Equations；B單一Work，B06（對應原A08–09）完成。這是版面/內容保留/工程交付，不是B07數學通過。
授權與凍結：接V19-B05-Integrated-v1完成整卷排版；只修實見L/E，N/M交內容角色。未改卷界、章次、受限來源或其他卷。B07後續回修使用獨立候選；本交接固定對保留。
模型／模式：實際live模型與High設定未獨立核實；不以文字宣稱切換。
有效基線：B05固定章稿12檔與b05-manuscript.sha256實核，零不符；V18末章245與V19起訖246–257承B05固定Git index d9d72a253a9406a42410fa97ea98b6f64d623001之證據，不繼承前卷正文。R1 artifact commit 8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3、Library v3、ZIP7007679bytes、SHA256 5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732。三R1檔及字型依賴verify.py仍通過。

固定成品與manifest：

| 用途 | 檔案（相對v19-work） | bytes | SHA256 |
| --- | --- | ---: | --- |
| 最終配對PDF | book/v19.pdf；只讀副本book/qa/b06-input/B06-final.pdf | 1200264 | e67845763cd893c530b00a50b4f40824459d48e7449e77b7812724ba12a2fb63 |
| 來源逐檔身份 | evidence/B06-source-manifest.json | 9044 | a1af17a8cc7594b07f5821edcae37022e204b5ebfcd95f35df805535658055ff |
| 獨立可讀QA總報告 | evidence/B06-REPORT.json | 11053 | 1f818b617c97a98cb5008285288f239f3a88c89f44386d9bd654797bb45e1610 |
| 最終12章身份 | evidence/b06-manuscript.sha256 | 1104 | 2c427d89668bb6fa0c6b626e1aa51902225c3e27bff71d541973558ece248c82 |

來源/PDF配對：B05輸入PDF SHA866560ff5e23bab456c1e677697bd16074c93e1ee1c9ca9bc2a65138f24b0e42（279頁）先乾淨重編，3輪後逐位元相同。四項局部L修後再次乾淨重編3輪，得到上列固定PDF。編譯指令`python book/build.py --entry v19 --clean`；XeTeX3.141592653-2.6-0.999996、TeX Live2025/dev/Debian，字型檔與授權在dependencies，實際PDF7個字型物件全嵌入。SOURCE_DATE_EPOCH1795737600、FORCE_SOURCE_DATE1為此環境未覆寫時採用的預設值；相同環境已核可重建B05。PDF頁盒190×260mm；正文10.4/16TeX pt，常見PDF實測字級約10.361bp；單位分列，不當成偷縮字。

實際完成與證據：

- 內容保留：11章完全同B05；ch255.tex只有第404行少一反斜線的排字修正，舊`U_0=U/g_+,qquad V_0=g_-V.`改成`U_0=U/g_+,\qquad V_0=g_-V.`，由統籌另行核實授權，所有label/ref/eqref序列不變。新ch255 SHA c13101734871beefb2c2a35291901545602fbb72715fba575755ba07d01b4333。精確差異qa/b06-final-r2/layout-only.patch。
- 工程：零hard/缺字/壞引用/overfull/header警告；20個underfull全部保留並逐項對來源/實體頁及實看接受理由，見underfull-dispositions.json。最高6825在物理196頁Example254.12長題名行；可讀、無裁切，不為清警告改全域間距。
- 導航：373個實際PDF named-destination連結逐一解析，930個命名目標無失效頁；150個bookmarks與246–257章目標皆正常。named-navigation.json實核LINK_NAMED而非誤當一般GOTO；工具已補強此類型。
- 版面初審：279頁全部渲染，以47張順序contact sheets實際逐頁看每個完整頁面；原14個優先異常頁個別放大。按12章順序閱讀PDF以查閱讀連續、條件與式子/題解距離，並在具體疑點核來源；不把這說成獨立全卷數學重證或557列來源表逐條審核。
- 修後複核：最終與B05只有實體1–8、229頁像素及文字不同；這9頁已實際重看，229另放大重讀。其餘270頁以同MuPDF1.26.6/108dpi全部逐頁像素與文字一致明確承接既有實看回執；outline相同，不是默認沿用。baseline-final-comparison.json逐頁含像素SHA。
- 全部279頁、12章與章縫無漏檢頁。初審帳qa/b06-r1/review-ledger.json，最終帳qa/b06-final-r2/review-ledger.json及review-progress.json。最終28個幾何/短頁locator逐一接受，未以字元密度給分或刪文。頁底下標/積分下限未碰頁腳；最小抽取間隔15.330bp在物理214頁，已實看。
- 可量測庫存：24定義、41定理、41命題、14引理、5推論、68例題、74習題、74詳解、100proof環境；是literal環境計數，不把條目數當完備。另見measured-units.json。正文548個唯一label、214個ref/eqref，無未解參照。

實際L變更與KEEP：封面改整字斷行；TOC章/小節號欄清楚分隔；前言頁眉不稱Chapter0；上述單一qquad漏斜線。未做全域分頁改造，頁數仍279。已看到的短框/長證明跨頁有清楚continued標記與可辨識條件，遵統籌最新指示KEEP；短章末來源/範圍尾頁亦依完整單元實看接受。獨立B03樣章的L-B03-001不機械套用到整合正文。所有缺陷與接受理由在defects.json；舊候選短題ID已澄清為C-UNIT-01，避免與最終L-B06-004排字缺陷混淆。

實讀輸入與限制：全文讀B05-HANDOFF、INPUTS、b01-boundary、coverage-verification；核來源責任/處置表結構與落點脈絡、讀相關角色修補史/OPEN；不冒稱重新逐條核全部文獻正文或557處置列。版面方法、R1固定來源及Git指定QA文件已在準備交接列實讀與hash。全頁順讀/視檢、內容保留及工程三層分列。

OPEN／UNKNOWN與下一步：

| ID | 影響／責任／下一步 | 阻塞範圍 |
| --- | --- | --- |
| B07-PENDING | 唯一打厚角色對本固定對最嚴格整卷數學終審；後續14項回修另成版本，不能回寫本QA聲明 | 阻最終數學通過；不阻本B06交付 |
| OPEN-PRIOR-LOCATIONS | 一些古典輸入的前卷精確位置未核實，承原B05來源記錄 | 不由排版清零 |
| UNKNOWN-SOURCE-RANGES | 未讀/不確定來源範圍維持來源表與access receipts | 不以工具/頁數當覆蓋通過 |
| OPEN-T-PROVENANCE | Trèves工作本公開再散布權利未核實，排版未發布受限文獻 | 阻相應公開散布 |
| UNKNOWN-MODEL | live模型/推理強度未獨立曝露 | 阻模式已核聲明 |
| HISTORICAL/RESEARCH | 16/22映射、六全局門檻、理解測試、跨OS、手機、實體印刷、screen-reader/PDF-UA未在本輪驗收 | 各對應聲明維持未知 |

下一角色唯一階段：B07。通過條件是對固定來源/PDF及全部必要內容/依賴/來源責任的唯一整卷數學驗收；全部修正回B07複核。本B06沒有以hash、頁數、編譯或美觀替代終審。
禁止重做：不重建R1、不重生已好章、不改卷界或章號、不啟動其他卷、不復活雙NO OBJECTIONS、不抹去原OPEN。B07新版本只核其直接及傳遞影響。
待使用者決策：無；統籌承已授權Work決策。
傳遞狀態：候選PDFhash已透過agent訊息送達統籌並由其固定版本目錄；本完整交接及QA檔案現在可供統籌實讀。未送其他Work或公開Git。永久封存與回讀由後續B08處理，未在本角色冒稱已完成。

【接收回執】
交接版本：V19-B05-Integrated-v1→V19-B06-LAYOUT-v1。
實際讀入與hash：B05交接/12章hash/PDF實核；R1及字型verify.py通過；B05乾淨重編逐位元同；B06最終對身份如上。
可讀/缺檔/衝突：正式輸入可讀，無本B06工程缺檔或模板衝突；來源/模式未知如實保留。
理解：B單一Work，V19，246–257，章級/整卷整合後B06；唯一B07終審，其他卷凍結不動。
接受續作與範圍：B06完成；後續B07局部回修候選由統籌另給固定hash後，只作版面/工程直接與傳遞複核。

版本隔離補記：共享evidence來源/覆蓋表在B07回修時前進。本B06所指舊覆蓋資料已由統籌的CRC/hash核驗durable checkpoint恢復至versions/B06-v2/evidence，再實核舊hash並另存evidence/B06-fixed-context；本manifest改指該只讀副本，不覆寫B07的主表。章稿及PDF配對未變。
