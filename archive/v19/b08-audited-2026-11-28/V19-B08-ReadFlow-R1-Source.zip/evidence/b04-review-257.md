# B-04 independent mathematical review: Chapter257

Reviewed in full: `v19-work/drafts/ch257.tex`, SHA-256 `5977edb84eaf09141f4e1b27affcfe9a4f8cedc79a2c5fcdfc5df2a9d574e32e`, 2026-11-27. Reviewer: independent Kress/source role after authoring252–253. This is a chapter-content review, not B-07 whole-volume clearance or layout acceptance.

Decision: **no mathematical defect found in the reviewed257 body**. Every displayed parameter regime, side-boundary sign, computed moment, Abel inversion and solution reconstruction was checked. Preconditions imported from255 remain integration responsibilities; this review does not assert255 has passed.

Sections actually read: all ten, `case-contract`, `rank-two-model`, `rank-two-resonance`, `damped-memory-model`, `damped-memory-solution`, `weak-singular-case`, `cauchy-complete-case`, `real-line-comparison`, `abel-first-kind`, `synthesis-exercises`, and source notes, including every solution.

## Direct mathematical checks

- **Moment matrix/ranks** (`eq:v19:257:moment-matrix`, `finite-system`): integrals give [[1,1],[0,2]]. Applying V back to reconstruction proves sufficiency and injectivity of solution correspondence. Kernel r=6x²−6x+1 has both moments zero. Eigenvectors1 and1+x have eigenvalues1 and2.
- **Compatibility** (`resonance-one`, `resonance-half`): atλ1 equations both−c2=g1,g2, so g1=g2; atλ1/2 secondrow0=g2. Left eigenrows(1,−1) and(0,1) give actual functional densities a−b andb. General function solutions and every listed f datum follow. Free-constant renaming for f=1+x is legitimate.
- **Data/parameter limits** (`compatibility-perturbation`): eigenvector terms have denominators1−2λ and1−λ. Pathsε0 andε1−λ give different compatible limiting solutions as stated. Direct K substitution checks signs.
- **Memory equivalence** (`memory-ode`): w'=q−γw andq'=u−γq imply (D+γ)²w=u. Both zero initial conditions retained; reconstruction and exponential conjugation prove the converse for merely continuousf. No hidden f derivative.
- **Memory inverse and explicitf** (`memory-explicit`): hλ''=λhλ, hλ(0)=0,hλ'(0)=1; r=e^−γt hλ solves correct homogeneous equation and supplies unit forcing under convolution. The quotient sinh(ρt)/ρ is root-sign independent and has t limit atλ0. Atλγ² the r formula andγ0 limit are correct. Dominating powers T^(2n)/(2n)! and cosh bound are correct. Damping perturbation bound uses |e^−ηs−e^−γs|≤|η−γ|s and hence T³/3; subtraction gives displayed bound withu on right.
- **Log kernel** (`log-row-integral`, `log-solution`): row integral1−xlogx−(1−x)log(1−x), maximum1+log2. Cutoff band estimate→0 uniformly; continuous target and compactness are justified. Product-square norm is7/2: 2[2−1/4]. All parameter1/10 Neumann estimates, positivity, reflection, residual sign and endpoint derivative failure verified.
- **Circle channels and boundary fields** (`circle-channels`, `circle-explicit`): S positive on n≥0, negative on n<0; a±b coefficients and every degenerate case correct, including a=b0. Explicit solution2/3+z+z^−2 has interiorC=2/3+w and exteriorC=−w^−2. Interior minus exterior equals density; sum equalsS. Infinite-dimensional degeneracies distinguished from compact Fredholm. Exact inverse norm follows orthogonal projections.
- **Real-line signs** (`real-line-comparison`): H multiplier−isgnξ gives Hp=q,Hq=−p. Inverse(2I−H)/5 and rational solution correct. Inverse transforms ofπe^−|ξ| and−iπsgnξe^−|ξ| have the stated signs. For a=i,b1, positive channel vanishes, negative channel2i. P±=(I±iH)/2 and p−=(p−iq)/2 correct.
- **Periodic comparison**: cot((θ−φ)/2) has multiplier−isgnn by the displayed sine identity. Hper²=−I+P0; S=P0+iHper. Mean-zero compatibility, free constant, explicit sine/cosine solution and angular endpoint identification are correct. Kress's opposite-order cot kernel is not silently used.
- **Abel** (`abel-square`, `abel-inverse`): growthCt^−1/2 makes absolute double integration finite. Beta integralπ, inversion, existence substitution and weighted bound(|f0|+2T||f'||)/π correct. For f_n=n^−1/2sin(nx), substitution atx1/n cancels all n factors and gives the displayed positive lower bound; solutions continuous through0 for eachn. f=x andf1 examples correct. Natural weighted class is not an unchanged-space bounded inverse assertion.
- **Exercises**: simultaneous compatibility gives both ordinary moments zero; derivative w.r.tγ has co-varying datum and exact differentiated kernel; residual certificate controls full residual, not samples; circle/Abel/compact first-kind comparison correct.

## Defects, corrections, consequences

No defect requiring a257 text correction was found. There is no group/semigroup theorem or group-continuity assertion in this file, so that requested audit category has no target here; scalar parameter dependence and the entire memory series were checked instead.

Cross-chapter issue found: the then-current253 draft repeated the complete Abel derivation appearing here. The253 author is replacing that duplicate with a different endpoint-degenerate first-kind continuous kernel k(t,s)=s, while257 retains this full Abel case. No257 change is required. The earlier253 hash is superseded by the forthcoming expanded chapter revision. This is a content-allocation correction, not a mathematical failure of the Abel proof.

Remaining integration responsibilities: verify exact255 labels/statements for L² Fourier/radial extensions, and reconcile source landings against the fixed full-volume body. No restricted source-book text or images are to be included in the archive.
