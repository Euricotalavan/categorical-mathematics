# Trèves B-01 access and independent reading record

Received the parent's assignment of V19 B-01 for global chapters 246–251. Read `project_sources/19-v3.txt` and `V19-Literature-Preparation-v1.md`. The user-supplied local PDF is the internal research source; no remote third-party copy was fetched. Unique item table: `treves-b01.tsv` (138 thematic records, with definitions, statements, proof arguments and examples distinguished). The records are source reading evidence, not manuscript acceptance, proof certification, or an assertion of exhaustiveness.

## File and version actually inspected

- File: `upload/TopologicalVectorSpacesTreves.pdf`; 17,513,867 bytes; 564 PDF pages.
- SHA-256: `77a9485851a640bc841d60036ac8fb91fdf3df3ab4c031bcfcf77d725c9fc4e5`.
- Title page (actual PDF 1): François Trèves, *Topological Vector Spaces, Distributions and Kernels*, Academic Press, Inc., Harcourt Brace Jovanovich, Publishers. Copyright page (PDF 2): ©1967 Academic Press; ISBN 0-12-699450-1; print number/date line visibly `90 91 92 93 94` and `9 8`. This identifies an Academic Press printing of the 1967 text; the precise printing year is not proved by that line alone. It is not verified as the Dover 2006 reprint. Preserve this distinction from the preliminary source document.
- PyMuPDF extracted every page to a private transient reading aid. Extraction alone is not reading. Neither PDF images nor OCR excerpts belong in the manuscript or public archive.

## Page map

Actual PDF indices in the TSV are 1-based and refer to the supplied bytes. The PDF has omitted blank/front transition leaves, so a single offset is wrong. Textual running headers and printed page numbers were inspected within each reading interval, and images of PDF 61 / printed57, PDF182 / printed181, and PDF403 / printed403 were directly inspected. The map used in the table is:

| Printed interval used | Actual PDF interval | Rule |
|---|---|---|
| 57–173 | 61–177 | actual=printed+4 |
| 181–394 | 182–395 | actual=printed+1 |
| 403–534 | 403–534 | actual=printed |

The chapter 21 opening is printed216 / actual217. The distributions subsection starts printed222 / actual223, so the preparation document's pointer to p222 is a useful subsection pointer, not chapter start. Chapter23 is printed240 / actual241, differential operators printed247 / actual248. Chapter50 begins printed509 / actual509; chapter51 printed526 / actual526. Do not apply these rules to unverified front/back leaves.

## Exact inspected intervals and depth

Full extracted text was read at actual PDF 61–70, 72–79, 87–97, 130–152, 182–190, 194–202, 217–230, 241–264, 356–378, 403–445, 477–534. PDF71 was read through the statements, but the end of its proof was lost in output truncation; PDF191–193 were partially exposed and are not counted as full reading. Front matter PDF1–2 was read and imaged; the introductory text PDF3–14 was partially exposed only and does not receive complete-reading credit. The private text directory contains all pages, including many never read.

Images actually inspected: PDF1,2,61,182,223,247,252,258,403,510,511,531,532. These verify title/copyright, page map anchors, the distribution continuity estimate, first derivative minus sign, support inclusion, nuclear definition, completed tensor statement and kernel ordering. Images saved but not viewed, such as PDF249, do not count as inspection. Most other formulas were read from extraction and synthesized semantically; table entries explicitly preserve formula uncertainty where primes, hats, comparison glyphs or sums were damaged. No manuscript may copy such a damaged display without repair and proof checking.

## Important boundaries and cautions

1. Scalar convention in the source is complex; continuous dual and distribution pairings are linear and bilinear, not sesquilinear. Hilbert adjoint requires the conjugate-linear Riesz conversion.
2. LF means **strict** countable inductive limit of Fréchet spaces here. The bounded-set and sequence-in-one-step conclusions are not declarations about arbitrary inductive limits.
3. Weak and strong dual topology coincide on bounded subsets of a Montel dual and on its convergent sequences, not globally on all duals or automatically for arbitrary nets.
4. The source’s PDF258/printed257 support estimate is inclusion. OCR displayed equality in the smooth multiplication line; the image verifies inclusion.
5. PDF247/printed246 asserts noninjectivity of the C∞ restriction for every proper open inclusion. That broad claim is not generally usable: if Ω is dense in Ω′, a continuous function vanishing on Ω is zero on Ω′. The text/image was checked; do not adopt that assertion without the necessary complement hypothesis. Restrictions of distributions and compact support extensions have different behavior.
6. Full abstract Mackey theory, Montel classification, tensor permanence, integral operator ideals and abstract kernel representation exceed the fixed introductory V19 boundary. They are read as supporting evidence, not automatically adopted.
7. Theorem51.7 has output variable x first and input y second: pairing of the operator value on u is pairing K with u(x)v(y). `L_b` uses bounded convergence and the distribution spaces use strong dual topology. This is separate from L2 kernels and Hilbert–Schmidt compactness.
8. PDF478,484 and521 contain historical remarks about then-unknown tensor injectivity/approximation-property questions. They are publication-era context, not current claims to teach.
9. The exact proof of nuclearity of rapid sequences uses a weighted sequence norm whose OCR completion notation is not safe to reproduce directly. The general proposition and its use are read, but any adopted constructive proof needs image reconciliation or an independently proved Hilbert seminorm argument.

## UNKNOWN / open responsibilities

- Uninspected actual intervals outside the list above remain UNKNOWN, even when full extracted text exists. In particular chapter8 ending printed76–77, chapter10 ending printed94–96, chapter14 ending printed149–150, chapter15–17 approximation/partition/open mapping proofs, chapter32–33 equicontinuity/Alaoglu/barrelledness proofs and chapter44–46 tensor completion results were not fully read in this task.
- Chapter24 ending printed264 onward was not inspected; no claim to cover all local structure corollaries, point-support classification or examples there.
- Source proof paragraphs are not independent rigorous acceptance. Every manuscript theorem needs its own proof obligations checked, including any missing source proof or exercise-only statement. The global abstract nuclear/kernel theorem source proof depends on chapter45 compact tensor hulls, still UNKNOWN here.
- General dual-pair definitions beyond a space and its continuous dual require another actual source or a complete local construction. This source's selected chapters mainly use the canonical pair.
- Source access legality for redistribution is not established; supplied PDF is for this user's internal reading. Do not include it, screenshots or extracted text in public source archives.

## Handoff

Role: independent Trèves source reader. Stage: B-01 source evidence, not B-07. Version: local evidence v1, source hash above, fixed V19 chapter allocation 246–251 as assigned by parent. New manuscript: none at B-01 completion. OPEN/UNKNOWN: listed above, source formula flags in TSV. Next authorized work received from parent: expansion author for chapters246–248 under the now calibrated B-04 contract; those drafts are distinct artifacts and do not retroactively change B-01 read status. Parent owns consolidation/persistence and user delivery. No upload, publication, source redistribution, template edit, earlier-volume revision or chapter renumbering occurred. Formal ReadFlow template remains R1 by project authority; this reader did not verify template bytes. Actual runtime model/reasoning setting was not independently observable; no model-switch claim.
