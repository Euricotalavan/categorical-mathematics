# V19 B08 fixed edition handoff

**V19-B08-ReadFlow-R1-v1** is the result of the authorized single-Work B-01 through B-08 workflow. *Locally Convex Spaces, Distributions, and Integral Equations* contains the original English manuscript for Chapters 246–257. The source and paired PDF carry 12 chapters, 122 numbered sections and 74 exercises with solutions. The reader PDF has 280 physical pages. The material was expanded from the first 191-page compilation through additional proofs, full worked examples and linked exercises.

## Exact accepted edition

| Record | Identity |
|---|---|
| Independent mathematical decision | B-07 PASS on `B07-anchor-v2`, with A–Q resolved and rechecked. See `B07-FINAL.md`. |
| Pair manifest of the reviewed candidate | SHA-256 `5171ec5910d0c8cdf6d4b1666e7335fda13c030fbd7f30980d5be9082f31f551`. `final-pair.sha256` maps those same hashes to the archive paths. |
| Paired reading PDF | `V19-B08-ReadFlow-R1.pdf`, 1,205,975 bytes, SHA-256 `b73bf137be341da61c186c68c8edc0649a066013fe1ab924d6d4930b4022e851`. The archive embeds these exact PDF bytes in `paired/`. |
| Previous published numbering | V18 Git index `d9d72a253a9406a42410fa97ea98b6f64d623001` ends at 245. `INPUTS.md` identifies the local predecessor-copy distinction. |
| Fixed R1 template | V0 archive Library v3, artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`. The three baseline TeX files are byte-identical and the bundled font hashes are verified. |
| Sources and labels | `source-disposition.tsv` accounts for 453 distinct B-01 responsibilities at 557 actual dispositions; `original-landings.tsv` records 170 local contributions. The map carries exclusions and source uncertainties explicitly. |

## Review and recovery

B-06 initial whole-page inspection and ordered reading are recorded in `B06-HANDOFF.md` and `qa-b06/`. B-07 independent return, correction and re-review evidence is in `B07-first-pass.md`, `B07-returns.md`, `B07-FINAL.md` and the final QA directory. The four documented page-break marks before headings repair table-of-contents and bookmark targets without changing the rendered prose or mathematics. All 137 numbered section and subsection headings were tested against their actual rendered pages and printed TOC destinations. Layout verification of the revised sheets and opening/closing seams is recorded in `B07-layout-recheck.md`. No separate mathematical decision comes from the layout stage.

`MANIFEST.json` fixes the archive members, content sizes and hashes. `verify_archive.py` checks CRC, member hashes, paired PDF identity and an optional independent rebuild. The final content was clean-built in a second directory. The rebuilt copy differs only in the PDF trailer ID field; the comparison and normalized digest are in `final-qa/b08-rebuild.json`. A separate completion receipt documents the exact remotely retained files and the read-back tests of this local package.

## Remaining limits and handoff scope

`INPUTS.md`, the primary source read logs and the exact source dispositions retain uninspected ranges, formula uncertainties and unavailable exact earlier-volume loci for some named classical prerequisites. The book contains the chosen scope, with complete local proofs and explicit hypotheses for its retained results. The general curved-contour singular-kernel theory, global analytic Fredholm continuation, broad nuclear permanence and reference-book material outside this volume are separate subjects. The manually read editions were identified, and the book archives only the V19 manuscript and derived evidence. It contains no source-book scans, screenshots, raw OCR or account material.

This is a private archive at the approved boundary. The original chapters, neighboring volumes, formal template source and extraction tool are frozen. B-08 is the completion target for this Work, with no other volume or publication step in scope.
