# V19 fixed inputs

Work authorization covers V19 B-01 through B-08 in the single-Work variant. The coordinating agent makes the decisions otherwise sent to the user and records those decisions. An independently assigned reviewer makes the mathematical decision on the fixed B-07 pair. The scope ends at a private archive of original material. It contains bibliographic locations for the restricted inputs and leaves the source PDFs at their existing locations.

## References supplied for this Work

| ID | Edition identified from the file | PDF pages | SHA-256 |
|---|---|---:|---|
| T | François Trèves, *Topological Vector Spaces, Distributions and Kernels*, Academic Press, copyright 1967, later printing of the original text, ISBN 0-12-699450-1 | 564 | `77a9485851a640bc841d60036ac8fb91fdf3df3ab4c031bcfcf77d725c9fc4e5` |
| H | Lars Hörmander, *The Analysis of Linear Partial Differential Operators I: Distribution Theory and Fourier Analysis*, second edition, Springer Classics 2003 reprint, DOI 10.1007/978-3-642-61497-2 | 454 | `295fd9ad33aebc5d0aeea354f3725afd8124e9f7257f5b0cabd938aa89c9020e` |
| K | Rainer Kress, *Linear Integral Equations*, third edition, Springer 2014, DOI 10.1007/978-1-4614-9593-2 | 427 | `d25f40b9b25047f6bfadb72a33ab1e7fcdd3d9b2621ed631eb6f7434b6e7ac6b` |

The user supplied all three files. H and K are the exact editions identified through the NTHU Springer route. The T attachment is identified from its title and copyright pages. Any prior point about third-party hosting or public redistribution remains unverified. Page numbers in the read logs are printed book pages and one-based PDF pages in separate columns.

The unchanged `math-extractor-v0.4.zip` (SHA-256 `c2d47e097447a836bcad63d5a030106b1ec261bac4ffe32a6aecc783aca244f3`) produced candidate results on 323 T pages (1,403 candidates), 107 H pages (486 candidates) and 129 K pages (318 candidates). No model-based window call ran inside the extractor. The candidate counts are a locating aid. They are separate from the reviewers' itemized source readings. Candidate tool output, raw source extraction and image crops are temporary working data.

## Boundary and predecessor

The `V19` cards in the v4 Git-aligned curriculum and bibliography give twelve local chapters. The published V18 index at Git commit `d9d72a253a9406a42410fa97ea98b6f64d623001`, `archive/v18/b08-audited-2026-11-27/README.md`, identifies its chapters as 232–245. V19 takes chapters 246–257 accordingly. The predecessor's archive contents were checked separately from the Library v0 copy `64cbd1a3c04004a4c909bee448a57047abc353630fc0ceaa25ce41ffef9fa078`; that copy contains the same numbering and the already treated constant-kernel Volterra and `min(x,t)` Green models in ch245. The checksum file for the published Git source archive gives `00dc668247d81b3600187a9f7968da6074704c041e4012f8856f5fc8224b607d`. It is a distinct byte version. Exact published ZIP bytes were not returned by the Git contents endpoint. We use the fixed published index for numbering, read the recovered Library copy for the overlap check, and do not inherit either predecessor manuscript.

## Typesetting baseline

V0 ReadFlow R1 source archive, Library v3, Git artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`, 7,007,679 bytes. Archive and hash were checked against the retrieved bytes. The layout role records each substitution or volume-specific adaptation in its build and QA notes.
