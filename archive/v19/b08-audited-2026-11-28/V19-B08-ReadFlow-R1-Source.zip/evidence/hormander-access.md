# Hörmander V19 B-01 independent source read — v1

## Receipt and identity

Read `project_sources/19-v3.txt` and `V19-Literature-Preparation-v1.md`. Task is the assigned Hörmander contribution to B-01, not a final mathematical acceptance of V19. The user-supplied source is `upload/978-3-642-61497-2.pdf`, 34,253,331 bytes, 454 PDF pages, SHA-256 `295fd9ad33aebc5d0aeea354f3725afd8124e9f7257f5b0cabd938aa89c9020e`.

Actual title and rights pages PDF4–7 identify Lars Hörmander, *The Analysis of Linear Partial Differential Operators I: Distribution Theory and Fourier Analysis*, reprint of second edition 1990, Classics in Mathematics, Springer 2003. e-ISBN 978-3-642-61497-2, DOI 10.1007/978-3-642-61497-2. PDF4 and PDF5 were image-inspected. This is not a filename-based edition assertion. The earlier preparation's chapter-body access gap is resolved for this supplied upload only; it does not establish prior semantic reading.

## Page mapping and actual inspection

Actual PDF page = printed page +15 for every recorded body locator. Checked anchors include printed14/PDF29, 33/48, 54/69, 126/141, 158/173, 243/258. PDF pages are 1-based. Front matter has outer reprint and original-edition pages, so do not use roman-page offset guesses.

Text read: printed14–31 (PDF29–46; §§1.2–1.4), 33–52 (48–67; §§2.1–2.3), 54–76 (69–91; §3.1 and selected §3.2), 126–132 (141–147; §§5.1–5.2), 158–170 (173–185; §7.1 beginning), and 240–247 (255–262; §7.9 prelude, multiplier theorem and beginning of PDE application). Batched text truncation was repaired for central source statements by page images; advanced formulas not repaired are explicitly UNKNOWN in the table. Reading an interval does not imply every formula or every proof was audited.

Actual page images inspected: PDF4,5,29,31,32,33,40,42,43,48,49,50,53,54,60,61,62,63,66,67,70,71,75,76,78,80,87,88,142,143,144,146,147,175,178,179,182,183,258,260. These resolve support/derivative conventions, the support-only counterexample, Whitney conditions, jump orientations, kernel ordering, PV signs, Fourier hats/phases, and multiplier hypotheses. No source image is part of the authored book.

OCR risks: isolated equations can disappear entirely; D-prime, E-prime and Schwartz S become misleading letters; Fourier hats and conjugates vanish; bar-z can become z; integer upper/lower signs and inequalities can corrupt. Do not treat copied OCR equations as checked mathematical text. The TSV is an original mathematical synopsis, not a verbatim extraction.

## Deliverable and status meaning

`hormander-b01.tsv` contains 117 individually located rows, including explicit UNKNOWN ranges. `SOURCE_READ` means a source statement/argument was read to the stated degree; it never means a V19 manuscript covers it or that B-07 has passed. `IMAGE_CHECKED` applies to the listed claim's critical formulas, not every page in a range. `V19_LANDING_PENDING` awaits the final chapter labels and responsibility mapping. Optional/outside-core rows preserve inspected advanced material without silently adopting it. Combined theorem/proof rows report whether an argument was read, and identify precise formula/proof limitations when it was not. This is a manual source responsibility table; it is not an extractor-v0.4 index nor an exhaustive all-book inventory.

The exact relevant end-of-book exercises/answers remain uninspected; their coarse row is a search boundary only. The remaining §3.2 and §§3.3–3.4, remainder of §7.1 and §§7.2–7.8, and unneeded later §7.9 material remain UNKNOWN or outside proposed scope. Do not expand a selected-page report into a full-chapter or full-book coverage claim.

## Mathematical boundaries and independent findings

- Ch249 responsibility: bumps/cutoffs, test-function compactwise estimates, distribution continuity, regular-function embedding, restriction/support/gluing, compactly supported distributions, convergence and counterexamples. A complete LF bounded-set proof is not supplied by Hörmander's statement of the sequential criterion; the author must provide it or use a separately read topological source. A sequence's fixed-support rule must not be asserted for all nets.
- Distribution order in Definition2.1.1 is local in the compact set. A single global derivative order is an additional property. A discrete sum of increasingly high point-jet evaluations is a usable counterexample. Uniform boundedness gives one common order for a convergent sequence on each fixed compact, not necessarily one order on the whole domain.
- Theorem2.3.1 bounds on a compact neighborhood of the support. Example2.3.2 shows why replacing that neighborhood by the exact support is generally false. Finite-jet vanishing on the support is nevertheless enough for annihilation (Theorem2.3.3). These are different statements.
- Ch250 responsibility: transpose derivative, classical agreement, smooth multiplication, commutation, Leibniz, one-dimensional jumps, zero derivative, parameter dependence, optional domain-boundary jump and elementary Cauchy/PV entry. Positive jump has positive Dirac coefficient. Hörmander uses interior normal, so his Gauss–Green boundary flux has a minus; translating to outward normal reverses both relevant signs.
- No product of arbitrary distributions is defined. Smooth multiplication is unconditional; finite-order distribution times C^k is separately qualified. Disjoint singular supports give one additional sufficient local product condition, not a general product theory.
- Ch251 responsibility: tensor product exists for arbitrary distributions in separate variables, with equality of product supports. This is not same-variable multiplication. The kernel ordering is output x first, input y second: (T phi)(psi)=K(psi tensor phi). The converse kernel proof relies on separate-to-joint continuity on fixed Fréchet test spaces and regularization. A distribution kernel does not imply a continuous/L2 integral kernel, compactness, nor a right to apply the operator to arbitrary distributions.
- The smooth-kernel theorem5.2.6 uses a compact-support distribution domain E-prime. Its topology/continuity wording needs alignment with the authored volume's exact chosen strong versus weak/sequential conventions; source statement should not be stretched into a weak-topology-to-Fréchet assertion without verification. This is an integration caution, not a defect attributed to the source.
- Nuclear locally convex spaces, completed tensor topologies and nuclearity permanence need Trèves or another independently read source. Hörmander chV's elementary distribution kernel theorem is not a substitute proof of abstract nuclearity.
- Ch255 responsibility: PV(1/x) is the derivative of log|x| with symmetric cutoff; (x+i0)^-1=PV(1/x)-i pi delta and (x-i0)^-1=PV(1/x)+i pi delta. With Fourier exp(-ix xi), Fourier(PV(1/x))=-i pi sgn xi. This matches H=(1/pi)PV(1/x)* and H²=-I on L2 after a justified Fourier/regularization bridge.
- §7.9 Theorem7.9.5 is an optional broader multiplier route with annular L2 derivative hypotheses through integer s>n/2; it is not a blanket singular-kernel theorem and does not give strong endpoint L1/Linfinity bounds. Its use would require the local Fourier/L2 and decomposition prerequisites. The simple L2 Hilbert model can avoid this added theory.
- Hörmander does not by these selected pages supply Kress's general smooth-contour Cauchy singular integral equation/index theory. Circle Fourier models, general contour boundary results, and real-line Hilbert transforms must retain separate scope statements.

## Handoff

Role: independent Hörmander source read, V19 B-01. Chapter allocations 249/250/251/255 follow the parent's fixed assignment and design; no new numbering decision, frozen-volume edit, public upload, or V19 acceptance is made here. Source hash above is byte-verified. Body/PDF pairing, formal R1 layout and mathematical final approval belong to later stages. Model/reasoning settings were not independently verified by this role.

Next: parent merges these rows with T/K evidence and resolves final included/optional/excluded responsibilities; chapter authors replace `V19_LANDING_PENDING` with exact formal text labels. Proof gaps or topology ambiguities block only the dependent claim, not unrelated drafting. No need to reread already checked pages absent a changed claim, bad OCR formula or new boundary. Parent owns final persistence and delivery. Files were produced in the shared workspace and parent notified; that is not a user-delivery or next-role read receipt.
