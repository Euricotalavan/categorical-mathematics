"""Compare a clean rebuild with the fixed Volume 13 PDF."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re

import fitz


def binary_match(fixed_path, rebuilt_path):
    original = fixed_path.read_bytes()
    rebuilt = rebuilt_path.read_bytes()
    if original == rebuilt:
        return "exact"
    identifier = re.compile(rb"/ID\s*\[\s*<[0-9a-fA-F]{32}>\s*<[0-9a-fA-F]{32}>\s*\]")

    def remove_trailer_id(data):
        # XeTeX's PDF driver puts the cross-reference dictionary at the end.
        split = max(0, len(data) - 16_384)
        tail, matches = identifier.subn(b"/ID [<PDF-ID><PDF-ID>]", data[split:])
        if matches != 1:
            return None
        return data[:split] + tail

    original_payload = remove_trailer_id(original)
    if original_payload is not None and original_payload == remove_trailer_id(rebuilt):
        return "identical except for the PDF trailer identifier"
    return "different PDF serialization"


def surface_links(page):
    values = []
    for entry in page.get_links():
        rect = tuple(round(value, 4) for value in entry["from"])
        point = entry.get("to")
        if isinstance(point, fitz.Point):
            point = tuple(round(value, 4) for value in point)
        values.append((
            entry["kind"], rect, entry.get("page"), point,
            entry.get("nameddest"), entry.get("zoom"), entry.get("uri"),
        ))
    return values


def check_link_targets(document):
    named = document.resolve_names()
    counts = {"internal": 0, "external": 0, "destinations": len(named)}
    issues = []
    for page in document:
        for entry in page.get_links():
            kind = entry["kind"]
            if kind == fitz.LINK_URI:
                counts["external"] += 1
                continue
            if kind not in (fitz.LINK_GOTO, fitz.LINK_NAMED):
                issues.append({"page": page.number + 1, "unexpected_link_kind": kind})
                continue
            counts["internal"] += 1
            if kind == fitz.LINK_NAMED:
                name = entry.get("nameddest")
                if name not in named or named[name]["page"] != entry.get("page"):
                    issues.append({"page": page.number + 1, "unresolved_link": name})
            if not 0 <= entry.get("page", -1) < len(document):
                issues.append({"page": page.number + 1, "invalid_target_page": entry.get("page")})
    return counts, issues


def compare(fixed_path, rebuilt_path):
    with fitz.open(fixed_path) as fixed, fitz.open(rebuilt_path) as rebuilt:
        if len(fixed) != len(rebuilt):
            raise SystemExit("The rebuilt page count differs.")
        counts, issues = check_link_targets(fixed)
        _, rebuilt_issues = check_link_targets(rebuilt)
        issues.extend({**item, "in_rebuild": True} for item in rebuilt_issues)
        if fixed.resolve_names() != rebuilt.resolve_names():
            issues.append({"attribute": "named destinations"})
        for index in range(len(fixed)):
            fixed_page = fixed[index]
            rebuilt_page = rebuilt[index]
            for label, left, right in (
                ("media box", fixed_page.mediabox, rebuilt_page.mediabox),
                ("visible page label", fixed_page.get_label(), rebuilt_page.get_label()),
                ("text", fixed_page.get_text(), rebuilt_page.get_text()),
                ("links", surface_links(fixed_page), surface_links(rebuilt_page)),
                ("72 dpi pixels", fixed_page.get_pixmap().samples, rebuilt_page.get_pixmap().samples),
            ):
                if left != right:
                    issues.append({"page": index + 1, "attribute": label})
        bookmarks_match = fixed.get_toc() == rebuilt.get_toc()
        if not bookmarks_match:
            issues.append({"attribute": "bookmarks"})
        return {
            "page_count": len(fixed),
            "bookmarks": len(fixed.get_toc()),
            "internal_links": counts["internal"],
            "external_links": counts["external"],
            "named_destinations": counts["destinations"],
            "retained_pdf_sha256": sha256(fixed_path.read_bytes()).hexdigest(),
            "rebuilt_pdf_sha256": sha256(rebuilt_path.read_bytes()).hexdigest(),
            "binary_comparison": binary_match(fixed_path, rebuilt_path),
            "issues": issues,
        }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("fixed_pdf", type=Path)
    parser.add_argument("rebuilt_pdf", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = compare(args.fixed_pdf, args.rebuilt_pdf)
    text = json.dumps(result, indent=2)
    args.output.write_text(text + "\n")
    print(text)
    if result["issues"]:
        raise SystemExit(1)
