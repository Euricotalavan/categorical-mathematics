# Descriptive Set Theory

Categorical Mathematics, Volume 13. ReadFlow R1 audited edition. Chapters 167–178, 106 pages, 2026-11-27.

- [Audited reading PDF](V13-B08-ReadFlow-R1.pdf)
- [Source coverage and PDF locations](COVERAGE.tsv)
- [Audit scope and fingerprints](AUDIT.md)

## Build from the published source

Use Python 3 and XeLaTeX with a complete TeX Live installation. From this directory, run:

```sh
python verify_sources.py
python build_pdf.py
```

The build recovers the exact fonts from the bundled files and writes `build/V13-B06/V13-B06.pdf`. It can run offline after TeX Live is installed. `PUBLIC-INPUTS.json` pins the published files, and `dependencies/licenses/` gives the font licenses. The fixed reading PDF is included. A clean build in the tested XeTeX environment reproduces its pages and navigation.

The LaTeX entry is `layout/study/V13-B06.tex`. The build driver also accepts `--debian-unindexed` for the Debian environment used to verify this edition.
