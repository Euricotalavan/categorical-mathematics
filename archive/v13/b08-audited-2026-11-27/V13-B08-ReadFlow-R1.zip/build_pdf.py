"""Compile the fixed public V13 reading edition with XeLaTeX."""

import argparse
from hashlib import sha256
import os
from pathlib import Path
import re
import subprocess

import prepare_fonts
from verify_sources import verify


ROOT = Path(__file__).resolve().parent
ENTRY = "V13-B06"


def build(debian_unindexed):
    verify(ROOT)
    prepare_fonts.main()
    working = ROOT / "layout/study"
    output = ROOT / "build" / ENTRY
    output.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment.update(SOURCE_DATE_EPOCH="1795737600", FORCE_SOURCE_DATE="1")
    for key in ("FONTCONFIG_FILE", "OSFONTDIR", "OPENTYPEFONTS"):
        environment.pop(key, None)

    if debian_unindexed:
        local_format = ROOT / "build/format"
        local_format.mkdir(exist_ok=True)
        environment.update({
            "TEXMF": "{/usr/share/texlive/texmf-dist,/usr/share/texmf}",
            "TEXFORMATS": str(local_format) + os.pathsep,
            "TEXMFVAR": str(ROOT / "build/texmf-var"),
        })
        if not (local_format / "xelatex.fmt").is_file():
            subprocess.run(
                ["xetex", "-ini", "-etex", "-jobname=xelatex", "-interaction=nonstopmode",
                 "-output-directory=" + str(local_format), "*xelatex.ini"],
                cwd=working, env=environment, check=True,
                stdout=subprocess.DEVNULL,
            )

    previous_state = None
    for run in range(1, 7):
        log = output / f"pass-{run}.txt"
        with log.open("wb") as diagnostics:
            result = subprocess.run(
                ["xelatex", "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", "-recorder", "-output-directory=" + str(output), ENTRY + ".tex"],
                cwd=working, env=environment, stdout=diagnostics, stderr=subprocess.STDOUT,
            )
        if result.returncode:
            raise SystemExit(log.read_text(errors="replace")[-5000:])
        auxiliary = [output / f"{ENTRY}.{suffix}" for suffix in ("aux", "toc", "out")]
        state = tuple(sha256(path.read_bytes()).hexdigest() if path.is_file() else None for path in auxiliary)
        if previous_state == state:
            break
        previous_state = state
    else:
        raise SystemExit("XeLaTeX auxiliary files did not converge in six passes.")

    log_text = (output / f"{ENTRY}.log").read_text(errors="replace")
    bad = re.compile(
        r"Missing character:|Undefined control sequence|undefined references|Reference .* undefined|"
        r"multiply-defined|Overfull \\[hv]box|fancyhdr Warning|Font shape .* undefined", re.I,
    )
    if any(bad.search(line) for line in log_text.splitlines()):
        raise SystemExit("A blocking XeLaTeX diagnostic was found. See the build log.")
    print(f"XeLaTeX converged in {run} passes. Reading PDF: {output / (ENTRY + '.pdf')}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--debian-unindexed", action="store_true")
    build(parser.parse_args().debian_unindexed)
