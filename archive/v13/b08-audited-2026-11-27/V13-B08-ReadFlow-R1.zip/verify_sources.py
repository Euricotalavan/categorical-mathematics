"""Verify the published source files and the original audited reading PDF."""

from hashlib import sha256
import json
from pathlib import Path


def verify(root):
    records = json.loads((root / "PUBLIC-INPUTS.json").read_text(encoding="utf-8"))["files"]
    names = set()
    for record in records:
        name = Path(record["path"])
        if name.is_absolute() or ".." in name.parts or name in names:
            raise SystemExit(f"Invalid manifest path: {name}")
        names.add(name)
        target = root / name
        if not target.is_file() or target.stat().st_size != record["bytes"]:
            raise SystemExit(f"Missing or wrong-sized published file: {name}")
        if sha256(target.read_bytes()).hexdigest() != record["sha256"]:
            raise SystemExit(f"Published file fingerprint mismatch: {name}")
    required = {Path(f"content/ch{chapter}.tex") for chapter in range(167, 179)}
    required.add(Path("V13-B08-ReadFlow-R1.pdf"))
    if not required.issubset(names):
        raise SystemExit("The public manifest lacks a required chapter or reading PDF.")
    print(f"Verified {len(records)} published files.")


if __name__ == "__main__":
    verify(Path(__file__).resolve().parent)
