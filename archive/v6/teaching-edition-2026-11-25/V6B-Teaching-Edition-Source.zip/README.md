# Building the Volume 6 teaching edition

From the repository's archived Volume 0 ReadFlow R1 source package
(archive/v0/readflow-r1-editorial-2026-11-17/V0-ReadFlow-R1-Source.zip),
place the nine matching font files in this package's source/fonts directory
(names and SHA-256 in QA/readflow-fingerprints.json). Font files are not
redistributed here.

With the ReadFlow R1 LaTeX font/layout packages available, change directory to
source/layout/study and run:

    xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode V6-ReadFlow-R1.tex

Repeat until the table of contents stabilizes. The body and the teaching
companion are separate LaTeX inputs. No operational logs or API receipts
are included in the public package.
