#!/usr/bin/env python3
"""Verify the recorded V18 source files, paired PDF, and review records."""

import hashlib
import json
from pathlib import Path


def verify(root):
    manifest_path = root / "MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    failures = []
    for name, expected in manifest["files"].items():
        path = root / name
        if not path.resolve().is_relative_to(root) or not path.is_file():
            failures.append(f"{name}: missing or outside source root")
            continue
        data = path.read_bytes()
        if len(data) != expected["bytes"]:
            failures.append(f"{name}: incorrect byte count")
        if hashlib.sha256(data).hexdigest() != expected["sha256"]:
            failures.append(f"{name}: incorrect SHA-256")
    for failure in failures:
        print(failure)
    if failures:
        raise SystemExit(1)
    print(f"Verified {len(manifest['files'])} files.")
    print(f"Paired PDF: {manifest['paired_pdf']}")
    print(f"Chapters: {manifest['chapters'][0]}–{manifest['chapters'][-1]}")


if __name__ == "__main__":
    verify(Path(__file__).resolve().parent)
