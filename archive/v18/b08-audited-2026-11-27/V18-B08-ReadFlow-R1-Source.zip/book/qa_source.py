#!/usr/bin/env python3
"""Check chapter numbering, stable labels and exercise pairings in a V18 source tree."""

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

REFERENCE = re.compile(r"\\(?:ref|eqref|autoref|pageref)\{([^{}]+)\}")
LABEL = re.compile(r"\\label\{([^{}]+)\}")
ENVIRONMENT = re.compile(r"\\(begin|end)\{([^{}]+)\}")
CHAPTER = re.compile(r"^\\chapter\{(.+)\}", re.M)
SECTION = re.compile(r"^\\section\{([^\n]+)\}", re.M)
META_COMMAND = re.compile(r"\\(?:documentclass|usepackage|setcounter|addtocounter|includeonly)\b")
DEFINITIONS = {
    "definition", "lemma", "proposition", "theorem", "corollary",
    "example", "remark", "problem", "psolution", "proof",
}


def strip_comments(source):
    return re.sub(r"(?<!\\)%[^\n]*", "", source)


def inspect(path, chapter_number, all_labels, errors):
    data = path.read_bytes()
    text = strip_comments(data.decode("utf-8"))
    title = CHAPTER.findall(text)
    chapter_label = f"ch:{chapter_number}"
    if len(title) != 1 or chapter_label not in LABEL.findall(text):
        errors.append(f"{path.name} needs exactly one chapter and label {chapter_label}")
    if META_COMMAND.search(text):
        errors.append(f"{path.name} contains a driver-level command")

    for occurrence in LABEL.finditer(text):
        label = occurrence.group(1)
        line = text.count("\n", 0, occurrence.start()) + 1
        location = f"{path.name}:{line}"
        if label in all_labels:
            errors.append(f"Duplicate label {label} at {location} and {all_labels[label]}")
        all_labels[label] = location

    counts = Counter()
    opened = []
    last_exercise = None
    for command, name in ENVIRONMENT.findall(text):
        if command == "begin":
            opened.append(name)
            counts[name] += 1
            if name == "problem":
                if last_exercise == "problem":
                    errors.append(f"{path.name} has consecutive problems without a solution")
                last_exercise = name
            elif name == "psolution":
                if last_exercise != "problem":
                    errors.append(f"{path.name} has a solution without a matching problem")
                last_exercise = name
        elif not opened or opened.pop() != name:
            errors.append(f"{path.name} closes an unmatched environment {name}")
    if opened:
        errors.append(f"{path.name} has unclosed environments: {opened}")
    if counts["problem"] != counts["psolution"]:
        errors.append(f"{path.name} has {counts['problem']} problems and {counts['psolution']} solutions")

    return {
        "chapter": chapter_number,
        "title": title[0] if title else "",
        "name": path.name,
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "lines": len(data.splitlines()),
        "sections": SECTION.findall(text),
        "labels": len(LABEL.findall(text)),
        "references": sorted(set(REFERENCE.findall(text))),
        "items": {name: counts[name] for name in sorted(DEFINITIONS)},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("chapters", type=Path)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    errors = []
    records = []
    labels = {}
    for number in range(232, 246):
        path = args.chapters / f"ch{number}.tex"
        if not path.is_file():
            errors.append(f"Missing chapter {path.name}")
            continue
        records.append(inspect(path, number, labels, errors))

    for record in records:
        for reference in record["references"]:
            if reference not in labels:
                errors.append(f"{record['name']} references absent label {reference}")

    totals = Counter()
    for record in records:
        totals.update(record["items"])
    report = {
        "chapters": records,
        "label_locations": labels,
        "sections": sum(len(record["sections"]) for record in records),
        "totals": dict(totals),
        "errors": errors,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"{len(records)} chapters, {report['sections']} sections, {len(labels)} labels")
    print(f"{totals['problem']} exercise/solution pairs, {totals['proof']} explicit proofs")
    for error in errors:
        print(error)
    raise SystemExit(bool(errors))


if __name__ == "__main__":
    main()
