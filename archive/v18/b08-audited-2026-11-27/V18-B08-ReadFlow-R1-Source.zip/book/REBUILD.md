# Volume 18 — ReadFlow R1 source

The single driver is `layout/study/v18.tex`. It builds Volume 18, *Functional Analysis and Bounded Operators*, Chapters 232–245, from the fixed B-05-v2 integrated manuscript with the recorded B-06 typography patches and the independently refined B-07 round1 corrections to Chapters242 and243 and the round2 corrections to Chapters237,238,240 and243. The successor PDF is pending recheck by the same independent B-07 reviewer; this engineering rebuild gives no mathematical pass. Chapter files under `manuscript/` are the sole typeset body; the driver sets the chapter counter to231 once. Front matter and bibliography are in `frontmatter/`. The received author's source identity, each typeset chapter's identity, and the exact layout diff are recorded in `records/B05-FIXED.json`, `records/LAYOUT-PATCHES-v1.json`, `records/B05-to-B06-layout.patch` and the B-06 fixed manifest.

## Requirements

Use XeLaTeX, Python3.10+ for the Linux helper and verification, and these standard TeX Live/MiKTeX packages and their dependencies: `mathtools`, `geometry`, `fontspec`, `babel` with English, `amsmath`, `amsthm`, `unicode-math`, `microtype`, `booktabs`, `array`, `enumitem`, `etoolbox`, `tikz-cd`/PGF, `fancyhdr`, `titlesec`, `needspace`, `xcolor`, `placeins`, `caption`, `hyperref`, `tcolorbox` with its most library, and `bookmark`. PyMuPDF and Pillow are needed only for optional PDF engineering and pixel comparison, not to compile the book.

The unmodified local font files under `dependencies/fonts/` are required: TeXGyrePagellaX Regular/Italic/Bold/BoldItalic, NotoSans Regular/Italic/Bold/BoldItalic, DejaVuSansMono, Asana-Math and STIXTwoMath-Regular. They are explicitly selected through relative filenames; do not silently substitute fonts. Preserve `dependencies/licenses/` and its notices. Exact font provenance is in `provenance/font-sources.json`.

The actual Linux engineering environment used XeTeX0.999996, TeX Live2025/dev Debian, LaTeX2024-11-01 patch2, Python3.12.14 and PyMuPDF1.26.6. Exact outputs can depend on engine and package versions. Windows and Prism commands below are standard instructions, not a claim of having tested those environments.

## Linux helper

Run from this source root:

```sh
python verify.py
python build.py --entry v18 --clean
```

The helper creates `build/v18/v18.pdf`, converges the auxiliary state, and writes a build report under `qa/`. It exits unsuccessfully on missing glyphs, undefined references, duplicate destinations or overfull diagnostics. Underfull diagnostics remain in the report for local visual assessment. PDF compilation and identity checks do not certify mathematical correctness.

This workspace's Debian TeX tree lacks its system ls-R database and formats. The helper creates a local XeLaTeX format under `build/v18/format` and searches the installed TeX trees without changing system files. `build/` is disposable and need not be distributed. No `TEXINPUTS` override is needed: all book inputs are explicit relative paths.

## Standard XeLaTeX on Windows or Prism

Keep the complete source tree. On Windows MiKTeX/TeX Live, open a terminal in `layout/study`. On Prism, select XeLaTeX and configure `layout/study` as the compilation working directory with `v18.tex` as the input file. Configure the working directory rather than rewriting manuscript or font paths.

From `layout/study`, run:

```sh
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error -recorder v18.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error -recorder v18.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error -recorder v18.tex
```

Run again if the last log requests another pass. These commands put `v18.pdf` beside the driver, whereas the helper puts it under `build/v18/`. No absolute author-machine path or custom `TEXINPUTS` is required. A normal TeX installation supplies its own XeLaTeX format; it does not use the Linux helper's generated one.

Check the final log for missing characters, undefined references/citations, repeated destinations, overfull boxes and package warnings. The inherited `mathtools`/`unicode-math` notices about bracket and colon-like commands are documented separately in the engineering report. Standard TeX engine exit0 alone is insufficient.

## Source, template and QA

The adopted ReadFlow R1 is artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, Library version3, source ZIP SHA256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`. Exact original template cores, build and verification programs and manifest are retained under `baseline/`. The historical baseline verification program expects the complete V0 source and is not the V18 verifier. No V0 body or chapter list is imported.

R1 keeps190×260mm geometry and10.4/16pt body. The core patch uses explicit relative font paths; `config.tex` explicitly inputs its sibling layout file. V18-specific metadata, front/back running heads and wider ToC number labels are separate in `layout/study/metadata.tex`. No hard page-capacity, body-leading or margin adjustment is used.

Optional engineering commands from this root:

```sh
python qa_source.py manuscript --report qa/chapters-rebuilt.json
python qa_pdf.py build/v18/v18.pdf --out qa/rebuilt --expect 'Functional Analysis'
```

`qa_source.py` checks chapter structure, labels, references and exercise/solution pairings. `qa_pdf.py` checks extracted text coordinates, near-white spans, internal page targets and supplied expected text, and renders every page. These checks have explicit limits: content outside the page can be absent from extracted text; a preserved label cannot prove a theorem; a high-density page is not automatically defective. The original B-06 sequential visual ledger and content-preservation evidence belong with the delivered source/PDF. All later changes must be traceable and return to the independent B-07 reviewer.

## Successor provenance

The delivered round2 paired PDF is `V18-ReadFlow-R1-B07-R2.pdf`. It contains only the coordinator-authorized, independently refined replacements for Chapters237,238,240,242 and243, with exact source identities in the round1/round2 repair manifests and current successor manifest. Chapter243 additionally has one authorized presentation-only `\Needspace{8\baselineskip}` before Definition243.15, recorded in `records/B07-R2-LAYOUT-PATCH.json`; removing that line restores the approved content candidate byte-for-byte; all nine other chapter bytes match the B06 checkpoint. The original B06 PDF is retained at that separate checkpoint and is not distributed inside this successor source. `records/B05-COVERAGE.tsv` is upstream B05 provenance, not a newly recomputed successor coverage table; the coordinator supplies the final258-row archive coverage. Current pair identity and engineering disposition are in the successor fixed manifest; the same B07 reviewer must review this pair before any mathematical pass.
