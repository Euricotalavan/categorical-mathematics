# V18 B07 round2 Chapter243 local repair receipt

2026-11-27 UTC. ID `V18-B07-R2-CH243-SQUARE-ROOT-POSITIVITY-v1`. Role: assigned local refinement repair → coordinator → same B07 reviewer. Scheme B single Work; scope is exactly the requested B02 analytic-square-root example and the subsequently assigned continuous-calculus nonnegative-form consequence. No other chapter, source boundary, frozen volume, style or counter was changed. Model/mode not independently verifiable.

Actually read round1 repaired input `b07/book/manuscript/ch243.tex`, SHA `15c38d9a107dc64f24657d4ab68cc1ed16aee4503b0ecc0c6cd3ffdb61ac4927`, and its relevant homomorphism/power-series/nilpotent/spectral-mapping/composition/logarithm/continuous-calculus passages. The round1 generated-algebra repair is retained exactly. The original B03 source is not byte-identical to round1 because that prior repair was authorized; no false original-B03 equality is asserted.

## Analytic square-root example

Immediately after `ex:243-logarithm` and before the next section, new label **`ex:243-analytic-square-root`**, output line171. Given a specified holomorphic logarithm ell on an open neighborhood U of sigma(a), with exp(ell(z))=z, define f=exp(ell/2). Since f² is the coordinate function, the existing homomorphism theorem gives f(a)²=a. U excludes zero by the explicit hypothesis; no logarithm is inferred for every invertible element. The log choice is part of the data, and adding2pi*i changes the root's sign, with no positivity claim. The worked J in the general unital Banach algebra with J²=0 uses the normalized disk log series. Termwise differentiation yields ell'(z)=1/z, so z exp(−ell(z)) is constant and equals1 at1, explicitly verifying exp(ell(z))=z. With f(1)=1 and f'(1)=1/2, the existing finite nilpotent formula gives1+J/2; direct squaring verifies it.

## Continuous nonnegative-form consequence

Immediately after the full proof of `thm:243-normal-continuous-calculus`, output line385, let real-valued f≥0 and g=sqrt(f) in C(K). The already proved algebra/adjoint laws give f(N)=g(N)*g(N); the first-slot inner-product convention gives its quadratic form norm(g(N)x)²≥0. The paragraph does not use the later positive-square-root theorem or require the word positive as an undefined operator term. No extra label is added for this short consequence.

## Verification and handoff

All incoming text is preserved exactly: removing only these two inserted blocks reproduces the full fixed round1 input byte for byte. All old labels remain in order, the section count is unchanged, no duplicate labels occur, and environments balance. No incoming theorem/proof/example/solution or round1 repair was rewritten. Both additions use only earlier scalar/calculus results in the same chapter. No new source acquisition, PDF/source pair, compilation or page/render QA performed.

Output `records/b07/repairs/round2/ch243/ch243.tex`, **39664 bytes**, SHA **`d5077db3774055008c7262513df25e003fe1ed1482aa9730bab492fb1dee28d3`**. Unified patch `records/b07/repairs/round2/ch243/ch243.patch`, SHA `524b33a649684b0cf5a67a0989ff27e36fafdf29d7cd1326f4050e4ee41fbeca`. `manifest.json` records exact input/output/patch bytes/hashes and new locations. Main B07 manuscript remains untouched by this role. ReadFlowR1 template and established chapter continuation232–245 after231 are unchanged; inherited Git baseline c27f36064ae039a23e03a7093684bfbf789179ef and template artifact8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3 are not new commits.

Status: local repair candidate ready for the same B07 recheck, with no unresolved mathematical defect identified in the two additions. This receipt is not B07 acceptance. Next unique action: coordinator hash-checks/merges the exact candidate, the assigned layout route builds the paired successor PDF, and the same B07 reviewer checks the actual successor and affected uses. Do not redo prior chapters/calibration or treat this as publication authority. No user decision required. Delivered to coordinator by direct agent message; actual recipient reading and B07 recheck remain separate states.
