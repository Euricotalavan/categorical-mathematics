# V18 B-06 正式交接 v1

交接ID：V18-B06-20261127-v1。時間：2026-11-27 UTC。發出：行文排版官；接收：主控與全新獨立打厚 B-07。方案：使用者已明確授權 V18 B 單一 Work，主控承接原使用者審核決策。階段：B-06 完成，對應原 A08–09；狀態為可交 B-07 的固定排版候選，並非整卷數學驗收／已封存。模型與 High 的實際後端設定未獨立核實，不自稱切換。

## 固定正文及版本回執

本次實讀並重新核驗 B05-v2 `B05-FIXED.json`，SHA256 `3ceb12fb80dd803354c2ab1c44735fc3a3cff339f15514b5dd29f43d701b3907`。14章及管理方前言／書目共16筆 bytes／hash 全部吻合後，原樣覆蓋工程快照才開始正式 B-06；實際接收證據在 `records/RECEIPT-B06-v1.json`。覆蓋表258責任之全部 label 均在實際正文，110節、587 labels、62題／62解、232個 proof 的結構檢查通過。這是內容保留及落點存在證據，不將上游已審標籤或本次 label 核對冒稱重新逐項來源／數學驗收。

唯一 typeset 正文為 `manuscript/ch232.tex` 至 `ch245.tex`，唯一 driver 為 `layout/study/v18.tex`；未另創競爭正文或改上游 B-05。每章原作者 B-05 檔名／bytes／hash 及本次 B-06 檔名／bytes／hash 對照，完整列於 `records/B06-FIXED.json` 和 `qa/content-preservation.json`。反向套用8筆已記排版補丁可逐位元恢復全部 B-05 作者文字；前言和書目保持 B-05 原始 bytes 不變。

前卷及章號依主控已實核的 Git commit `c27f36064ae039a23e03a7093684bfbf789179ef`：V17實際末章231，本卷232–245。本人本輪沿用該固定實核證據，沒有另取一次 Git 冒稱重核。driver只設一次 chapter counter231，未重排章序或從章1起。分卷／邊界和文獻版本按 B05-v2 交入的有效來源責任，不因排版改界、改先備或解凍其他卷。

模板是已採納正式 ReadFlow R1，Library保存版本3、artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`，ZIP大小7,007,679 bytes、SHA256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`。原樣三核心與原build/verify/MANIFEST留 `baseline/`；實際使用的 font-path patch 及本卷metadata patch 分列 `provenance/font-path.patch` 和 `records/STYLE-PATCHES.json`。R1的190×260mm、10.4/16pt正文、色彩和自然可分頁環境未變，沒有硬頁數、全局行距或頁面容量調整。

## 固定交付、來源／PDF配對及可取檔案

交付根：`/workspace/scratch/a0aed8e79dc9/v18/b06/book/`。

- 正式候選 PDF：`V18-ReadFlow-R1-B06.pdf`，255頁，1,122,006 bytes，SHA256 `5b2bf49fa275746a0867a2d4c23289b652ff5bbcedcc71c5fea947b159f8736a`。
- 正式固定manifest：`records/B06-FIXED.json`，與主控 `v18/records/b06/B06-FIXED.json` 同 bytes；SHA256 `71fa22df8e62a7a1ed662731652b9d56f8349d98c0f56e89f87b0195577b85aa`。
- `records/B06-GATE.json`：PASS_TO_INDEPENDENT_B07；只給排版／工程gate，不給數學終審通過。
- 重建 source：fixed manifest的87個列入檔；逐檔用途以其路徑、bytes和SHA256識別。另納入本交接、B06-FIXED、B06-GATE及書內 verified `MANIFEST.json`。build、PNG渲染、舊probe及工程快照紀錄不需入最終包，詳 fixed manifest 的 exclude_from_B08。
- `REBUILD.md`：正式實用編譯及依賴說明，Linuxhelper、Windows／Prism標準XeLaTeX都從明示相對路徑工作，不需TEXINPUTS。Windows／Prism未實機驗證，無跨環境保證。
- `records/LAYOUT-PATCHES-v1.json`、`B05-to-B06-layout.patch`：可逐項追查數學正文的8筆純呈現改動。
- `qa/engineering-final.json`、`build-v18.json`、`build-final.log`、`chapters-final.json`、`content-preservation.json`、`visual-ledger.csv`、`visual-summary.json`、`final-body-regression.json`、`clean-rebuild-regression.json`：各層實際證據。

編譯：從book根執行 `python build.py --entry v18 --clean`；在layout/study用標準XeLaTeX亦有完整指令。實際Linux：XeTeX0.999996／TeX Live2025-dev Debian、LaTeX2024-11-01 patch2、Python3.12.14；PDF QA用PyMuPDF1.26.6。11個字型檔連同授權、來源和hash包含於dependencies/provenance；不靜默代換。最後乾淨format／aux重建3pass收斂，與已視檢同來源的前一建置255頁文字、outline及72dpi像素逐頁完全一致；兩PDF二進位hash因建置時間不同，並未混稱同檔。

## 改動、保留與缺陷處置

8筆正文補丁只涵蓋：Goldstine兩個有限測試tuple改成兩行display；241 exact sequence及其dimension alternating sum分行、保留所有項與箭頭標籤；244既有複合字及eigenspaces增加安全可斷點；兩個數學節題指定清楚PDF書籤L²／Lᵖ而不改印出標題；234八處 `B_\mathbb R` 補上unicode-math必要的下標花括號，仍是同一實數下標，主控已明確確認屬排版語法。補丁逐一記舊文／新文／理由／負責／重核；沒有新增假設、刪證明、改量詞、調換運算順序或自行解決數學疑問。

本卷樣式補丁只處理字型解析、三位數章號與兩位數節號的目錄數字寬度、前後文頁眉、主控指定正式長卷名 *Functional Analysis and Bounded Operators*、中性footer/date及PDFsubject。章題與頁號清楚分隔；不追頁數。沒有移植V0正文、章號、整合宏或URL規則。

三層核查分列：

1. 內容保留：全部587個source labels有實際PDF destination，258責任落點存在，作者source可精確反向恢復，題解配對與章序保持；數學真偽及完整性最終仍由B07獨立核查。
2. 工程：缺字／undefined／duplicate／overfull均0，875個named destinations目標頁有效，285個named links全部實際解析（不是只掃LINK_GOTO），3個HTTPS URI annotations逐一匹配固定書目target；128項outline、14章首末頁、印頁1–248與前言／目錄Roman頁標已核。PDF用到的字型全部嵌入，未見近白字、超出頁界的已抽取span、正文與頁尾相撞。HTTP站點當下可用性沒有另抓，外連scope如實限於annotation target核對。
3. 閱讀：255個實體頁全部實際render，在64張依序四頁圖中逐頁查看，非抽樣；沿章檢章縫、定義／公式／條件、題解和continued標記。Goldstine、Banach-limit下標、241兩個長式及244證明另以108dpi細看。最後封面／五頁目錄變更在108dpi重看，所有final頁尾另逐序看過七張strip；其餘正文頁上半像素與原全頁視檢逐頁一致。這是版面與閱讀連續性screening，不是每條公式從像素重證或真人學習效果測驗。

## OPEN／UNKNOWN與下一步

阻塞排版／工程項：無。19筆underfull均在 `qa/engineering-final.json` 有章／來源行／原段落摘錄／最近label與PDF實體頁定位；全頁實看後保留自然兩端對齊與行內數學，不靠改行距處理。繼承的mathtools/unicode-math括號與colon-like命令通知亦保留於log，非缺字或未定義。這些接受理由逐項可追查，不把警告數清零。

非阻塞閱讀取捨：部分短續接仍有明確continued標記，部分自然章末頁較短，具體頁記入ledger。量詞／條件沒有消失，不為消滅所有留白加入硬換頁或省文。若B07或使用者指出具體閱讀阻力，再按定位最小修補並回B07複核。

尚未知／未清零：獨立整卷數學B07、真人理解與延後保留、跨OS、印刷、手機／screen-reader及原專案16/22映射、六全局門檻、既有來源UNKNOWN。排版不把其中任何一項標為通過。

唯一下一階段：由主控將上述固定manifest、PDF、唯一source、B05邊界／覆蓋責任及完整缺陷史交全新獨立打厚B07；依規先獨立讀固定正文與重要OPEN，之後才核先前補丁與歷史，不由本官代作終審。B07發現數學／敘事問題交內容責任官，版面問題退本官，所有修正再回打厚複核。B08封裝／遠端可見性和上傳授權由主控處理，只有B07通過後按授權封存。

禁止重做／凍結：不改已固定正文/PDF、不重開其他卷、不重做已核內容、不改卷界或章號、不復活雙NO OBJECTIONS、不把工程／hash／頁數／AI一致當整卷數學通過。待使用者決策：本B06無新增決策；主控依既有授權續B07。

傳遞：已透過代理訊息向主控送達B06 fixed manifest、gate及最終PDF身份；主控尚須回執實際讀入版本。本文及檔案產出不代表B07已讀入。沒有對外發訊、推Git或冒稱封存，持久保存及B08包裝由主控負責。
