#!/usr/bin/env python3
"""Verify the V18 engineering shell, not mathematical correctness."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parent
m=json.loads((R/'MANIFEST.json').read_text());errors=[]
for x in m['files']:
 p=R/x['path']
 if not p.is_file(): errors.append({'missing':x['path']});continue
 if p.stat().st_size!=x['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=x['sha256']:
  errors.append({'mismatch':x['path']})
print(json.dumps({'files_checked':len(m['files']),'errors':errors,'engineering_identity':'PASS' if not errors else 'FAIL','mathematical_acceptance':'NOT_ASSESSED'},indent=2))
sys.exit(bool(errors))
