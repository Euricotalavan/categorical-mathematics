#!/usr/bin/env python3
"""Build the fixed V18 ReadFlow R1 source with converged cross-references."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess

ROOT=Path(__file__).resolve().parent
WORK=ROOT/'layout/study'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def environment(state):
    env=os.environ.copy()
    # Debian's packaged files exist here but the system database/formats do not.
    # Enable filesystem search locally instead of modifying shared system state.
    env['TEXMF']='{'+str(ROOT)+'/texmf,/usr/share/texmf,/usr/share/texlive/texmf-dist,/etc/texmf}'
    env['TEXMFDBS']=''
    env['TEXMFVAR']=str(state/'texmf-var')
    env['TEXMFCONFIG']=str(state/'texmf-config')
    env.pop('TEXINPUTS',None)  # All local inputs are explicit relative paths.
    env['TEXFORMATS']=str(state/'format')+os.pathsep
    return env

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--entry',default='v18')
    parser.add_argument('--clean',action='store_true')
    args=parser.parse_args()
    if not re.fullmatch(r'[a-zA-Z0-9_-]+',args.entry): parser.error('Invalid entry stem')
    if not (WORK/(args.entry+'.tex')).exists(): parser.error('No such approved driver')
    state=ROOT/'build'/args.entry
    if args.clean and state.exists():
        import shutil
        shutil.rmtree(state)
    state.mkdir(parents=True,exist_ok=True)
    env=environment(state)
    fmt=state/'format'; fmt.mkdir(exist_ok=True)
    if not (fmt/'xelatex.fmt').exists():
        cmd=['xetex','-ini','-etex','-no-shell-escape','-interaction=nonstopmode',
             '-halt-on-error','-jobname=xelatex','-output-directory='+str(fmt),'xelatex.ini']
        proc=subprocess.run(cmd,cwd=WORK,env=env,text=True,capture_output=True)
        (state/'format-generation.txt').write_text(proc.stdout+proc.stderr)
        if proc.returncode: raise RuntimeError((proc.stdout+proc.stderr)[-6500:])
    previous=None
    for run in range(1,7):
        cmd=['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',
             '-file-line-error','-recorder','-output-directory='+str(state),args.entry+'.tex']
        proc=subprocess.run(cmd,cwd=WORK,env=env,text=True,capture_output=True)
        (state/f'pass-{run}.txt').write_text(proc.stdout+proc.stderr)
        if proc.returncode: raise RuntimeError((proc.stdout+proc.stderr)[-6500:])
        current=[sha(state/(args.entry+'.'+ext)) if (state/(args.entry+'.'+ext)).exists() else '' for ext in ['aux','toc','out']]
        if current==previous and run>=2: break
        previous=current
    else: raise RuntimeError('Auxiliary state did not converge in six passes')
    log=(state/(args.entry+'.log')).read_text(errors='replace')
    hard=re.findall(r'Missing character:.*|Undefined control sequence.*|LaTeX Warning: Reference.*|LaTeX Warning: There were undefined.*|.*multiply-defined.*|.*destination with the same identifier.*',log)
    overflow=re.findall(r'Overfull \\[hv]box[^\n]*|Package fancyhdr Warning[^\n]*',log)
    result={'entry':args.entry,'passes':run,'hard_diagnostics':hard,'overflow_diagnostics':overflow,
            'underfull_diagnostics':re.findall(r'Underfull \\[hv]box[^\n]*',log),
            'pdf':str(state/(args.entry+'.pdf')),'pdf_sha256':sha(state/(args.entry+'.pdf'))}
    (ROOT/'qa'/('build-'+args.entry+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if hard or overflow: raise SystemExit(1)
if __name__=='__main__': main()
