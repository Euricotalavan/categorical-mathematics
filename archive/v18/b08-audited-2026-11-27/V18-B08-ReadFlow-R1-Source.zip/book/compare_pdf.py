#!/usr/bin/env python3
"""Locate exact body-pixel reuse and every changed page of a successor PDF."""
from pathlib import Path
import argparse,collections,hashlib,json
import fitz

p=argparse.ArgumentParser();p.add_argument('baseline');p.add_argument('successor');p.add_argument('--out',required=True);a=p.parse_args()
out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
old=fitz.open(a.baseline);new=fitz.open(a.successor)
def body_hash(page):
    pix=page.get_pixmap(dpi=72,clip=fitz.Rect(0,0,page.rect.width,690))
    return hashlib.sha256(pix.samples).hexdigest()
lookup=collections.defaultdict(list)
for i,page in enumerate(old):lookup[body_hash(page)].append(i+1)
reuse=[];changed=[]
for i,page in enumerate(new):
    same=lookup.get(body_hash(page),[])
    if same:
        match=i+1 if i+1 in same else same[0]
        reuse.append({'successor_page':i+1,'successor_printed_label':page.get_label(),'baseline_page':match,'baseline_printed_label':old[match-1].get_label(),'physical_page_shift':i+1-match,'upper_body_pixels_exact':True})
    else:changed.append(i+1)
review=sorted({q for n in changed for q in [n-1,n,n+1] if 1<=q<=len(new)})
for n in review:new[n-1].get_pixmap(dpi=108).save(out/f'page-{n:03}.png')
record={'baseline_pdf':str(Path(a.baseline)),'baseline_sha256':hashlib.sha256(Path(a.baseline).read_bytes()).hexdigest(),'successor_pdf':str(Path(a.successor)),'successor_sha256':hashlib.sha256(Path(a.successor).read_bytes()).hexdigest(),'baseline_pages':len(old),'successor_pages':len(new),'reuse_boundary':'Exact72dpi upper-page pixel equality through y690pt, including headers, body, boxes and equations; page-number footer excluded and checked separately.','reusable_pages':reuse,'changed_upper_pages':changed,'required_visual_review_pages_with_neighbors':review,'visual_review_completed':False,'mathematical_acceptance':'RESERVED_FOR_SAME_B07_REVIEWER'}
(out/'comparison.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'reusable_pages':len(reuse),'changed_upper_pages':changed,'required_visual_review_pages_with_neighbors':review},indent=2))
