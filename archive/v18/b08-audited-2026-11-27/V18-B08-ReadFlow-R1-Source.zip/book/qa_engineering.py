#!/usr/bin/env python3
"""Engineering evidence for V18; this does not decide mathematical correctness."""
from pathlib import Path
import collections, hashlib, json, re
import fitz

R=Path(__file__).resolve().parent
P=R/'V18-ReadFlow-R1-B07-R2.pdf'
D=fitz.open(P)
N=D.resolve_names()
issues=[];links=[];fonts={};pages=[]
for name,target in N.items():
    if not 0<=target.get('page',-1)<len(D):issues.append({'invalid_named_destination':name,'target':target})
for level,title,page in D.get_toc():
    if not 1<=page<=len(D):issues.append({'invalid_outline_target':title,'page':page})
for i,p in enumerate(D):
    for l in p.get_links():
        row={'physical_page':i+1,'kind':l['kind'],'target_page_zero_based':l.get('page'),'named_destination':l.get('nameddest'),'uri':l.get('uri')}
        if l['kind']==fitz.LINK_NAMED:
            name=l.get('nameddest');target=N.get(name)
            row['resolved']=bool(target and 0<=target.get('page',-1)<len(D) and target['page']==l.get('page'))
            if not row['resolved']: issues.append({'bad_named_link':row})
        elif l['kind']==fitz.LINK_GOTO and not 0<=l.get('page',-1)<len(D):issues.append({'bad_direct_link':row})
        elif l['kind']==fitz.LINK_URI:
            row['uri_syntax_valid']=bool(re.fullmatch(r'https://[^\s]+',l.get('uri','')))
            if not row['uri_syntax_valid']:issues.append({'bad_uri':row})
        links.append(row)
    body=[]
    for b in p.get_text('dict')['blocks']:
        for ln in b.get('lines',[]):
            for s in ln['spans']:
                if not s['text'].strip():continue
                rect=fitz.Rect(s['bbox']);text=s['text'].strip();c=s['color'];rgb=[(c>>k)&255 for k in (16,8,0)]
                if not p.rect.contains(rect):issues.append({'outside_page':i+1,'text':text,'bbox':list(rect)})
                if min(rgb)>235:issues.append({'near_white':i+1,'text':text})
                is_footer=rect.y0>690 and (text=='Volume 18 · ReadFlow R1' or text.isdigit() or re.fullmatch('[ivx]+',text))
                is_header=rect.y0<42 and (text=='Categorical Mathematics' or text.startswith('Volume 18'))
                if not is_footer and not is_header:
                    body.append(rect)
                    if rect.y1>690:issues.append({'body_footer_zone':i+1,'text':text,'bbox':list(rect)})
    pages.append({'physical_page':i+1,'page_label':p.get_label(),'body_bottom':max((b.y1 for b in body),default=0),'body_footer_collision_flag':False})
    for f in p.get_fonts(full=True):
        if f[0] not in fonts:
            name,ext,typ,data=D.extract_font(f[0]);fonts[f[0]]={'pdf_font':f[3],'extension':ext,'embedded_bytes':len(data),'embedded':bool(data)}
            if not data:issues.append({'unembedded_font':f[3]})

def groups(text):
    out=[];depth=0;start=None
    for i,c in enumerate(text):
        if c=='{':
            if depth==0:start=i+1
            depth+=1
        elif c=='}':
            depth-=1
            if depth==0:out.append(text[start:i])
    return out

aux=(R/'build/v18/v18.aux').read_text();labels={}
for line in aux.splitlines():
    if line.startswith('\\newlabel{'):
        g=groups(line[len('\\newlabel'):]);v=groups(g[1]);labels[g[0]]=v
source_labels=[]
for p in sorted((R/'manuscript').glob('ch*.tex')):source_labels.extend(re.findall(r'\\label\{([^}]+)\}',p.read_text()))
for label in source_labels:
    a=labels.get(label)
    if not a or len(a)<4 or a[3] not in N:issues.append({'unresolved_source_label':label})

toc=D.get_toc();chapters=[]
for level,title,page in toc:
    m=re.match(r'^(23[2-9]|24[0-5]) ',title)
    if level==1 and m:chapters.append({'chapter':int(m[1]),'title':title,'physical_first_page':page})
assert [x['chapter'] for x in chapters]==list(range(232,246))
for i,x in enumerate(chapters):
    x['physical_last_page']=(chapters[i+1]['physical_first_page']-1) if i+1<len(chapters) else next(p-1 for lev,title,p in toc if lev==1 and title=='Bibliography')
    x['first_printed_page']=D[x['physical_first_page']-1].get_label();x['last_printed_page']=D[x['physical_last_page']-1].get_label()

log=(R/'build/v18/v18.log').read_text(errors='replace');under=[]
opens=list(re.finditer(r'manuscript/ch(\d+)\.\s*tex',log))
for m in re.finditer(r'Underfull \\[hv]box \(badness (\d+)\).*?lines (\d+)--(\d+)',log):
    ch=next((z[1] for z in reversed(opens) if z.start()<m.start()),None)
    a,b=map(int,m.group(2,3));source=(R/f'manuscript/ch{ch}.tex').read_text().splitlines() if ch else []
    prefix='\n'.join(source[:a]);labs=re.findall(r'\\label\{([^}]+)\}',prefix);label=labs[-1] if labs else None
    dest=labels.get(label,[]);target=N.get(dest[3]) if len(dest)>3 else None
    under.append({'chapter':int(ch) if ch else None,'source_lines':[a,b],'badness':int(m[1]),'source_excerpt':'\n'.join(source[a-1:b]),'preceding_label':label,'label_physical_page':target['page']+1 if target else None,'disposition':'KEEP: viewed full paragraph/context; no lost text, clipping or footer collision. Short justified lines and inline mathematics can give this warning; no global spacing/page-capacity change.'})

report={'pdf':P.name,'pdf_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'physical_pages':len(D),'outline_entries':len(toc),'outline':toc,'chapters':chapters,'named_destinations':len(N),'links_by_kind':dict(collections.Counter(x['kind'] for x in links)),'links':links,'external_link_scope':'All three HTTPS URI annotations checked against the fixed bibliography targets; HTTP availability not re-fetched in B06.','source_labels_resolved':len(source_labels),'fonts':list(fonts.values()),'pages':pages,'underfull_diagnostics':under,'issues':issues,'mathematical_acceptance':'RESERVED_FOR_SAME_B07_RECHECK'}
expected_uri=set(re.findall(r'\\href\{([^}]+)\}',(R/'frontmatter/bibliography.tex').read_text()))
actual_uri={x['uri'] for x in links if x['kind']==fitz.LINK_URI}
if actual_uri!=expected_uri:issues.append({'bibliography_uri_mismatch':{'expected':sorted(expected_uri),'actual':sorted(actual_uri)}})
(R/'qa/engineering-final.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:report[k] for k in ['pdf_sha256','physical_pages','outline_entries','named_destinations','links_by_kind','source_labels_resolved','issues']},indent=2))
raise SystemExit(bool(issues))
