#!/usr/bin/env python3
"""PDF engineering flags and sequential renders; never a reading acceptance test."""
from pathlib import Path
import argparse, hashlib, json
import fitz

def scan(pdf, expected):
    doc=fitz.open(pdf); flags=[]; texts=[]
    for index,page in enumerate(doc):
        texts.append(page.get_text())
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines',[]):
                for span in line['spans']:
                    if not span['text'].strip(): continue
                    rect=fitz.Rect(span['bbox'])
                    if not page.rect.contains(rect):
                        flags.append({'page':index+1,'kind':'outside-page','text':span['text'],'bbox':list(rect)})
                    color=span['color']; rgb=[(color>>shift)&255 for shift in (16,8,0)]
                    if min(rgb)>235:
                        flags.append({'page':index+1,'kind':'near-white-text','text':span['text'],'rgb':rgb})
        for link in page.get_links():
            if link.get('kind')==fitz.LINK_GOTO and not 0<=link.get('page',-1)<len(doc):
                flags.append({'page':index+1,'kind':'broken-local-link'})
    text='\n'.join(texts)
    for token in expected:
        if token not in text: flags.append({'kind':'missing-expected-text','text':token})
    return doc,{'pdf_sha256':hashlib.sha256(Path(pdf).read_bytes()).hexdigest(),'pages':len(doc),'flags':flags,
                'expected_text':expected,'reading_acceptance':'NOT_ASSESSED','mathematical_acceptance':'NOT_ASSESSED'}

def main():
    p=argparse.ArgumentParser();p.add_argument('pdf');p.add_argument('--out',required=True)
    p.add_argument('--expect',action='append',default=[]);p.add_argument('--dpi',type=int,default=144)
    a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    doc,rec=scan(a.pdf,a.expect)
    for i,page in enumerate(doc):
        page.get_pixmap(dpi=a.dpi).save(out/f'page-{i+1:04}.png')
    (out/'engineering.json').write_text(json.dumps(rec,indent=2)+'\n')
    (out/'review-ledger.csv').write_text('physical_page,inspected,chapter_reading,defect_ids,notes\n'+''.join(f'{i+1},NOT_YET,NOT_YET,,\n' for i in range(len(doc))))
    print(json.dumps(rec,indent=2))
    raise SystemExit(bool(rec['flags']))
if __name__=='__main__': main()
