# V18 B05 scoped source-gap scan

2026-11-27 UTC. Role: independent refinement support; source-to-manuscript evidence only. Scheme B. This is **not a whole-volume signature**, not a B07/strict final review, and not a claim to have read all of Rudin 10–12 or Conway VII–IX.

## Result and action

The selected high-risk chain is **maximal ideals / quotient Banach algebras → characters / inverse permanence → normal continuous calculus**. Actual manuscript proofs supply the essential spectrum-detection, conjugation, inverse-permanence, approximation and isometry arguments. No missing major theorem or mandatory worked example was found in this selected chain. Different notation and a shorter local route are genuine coverage, not omissions.

One small, concrete prerequisite issue remains **OPEN_LOCAL_BRIDGE**: `ch243.tex:298` first uses general proper/maximal ideals without a general definition in V18 ch232–244; `ch243.tex:300` uses the quotient algebra and its submultiplicative norm without explaining the general construction. The Calkin special case is explicitly proved in `ch242.tex:407–412`, so this is not a new algebraic theory or a missing spectral theorem. Add the short bridge proposed below, then independently recheck the affected character proof. This finding should be resolved locally; it gives no reason to restart source collection or delay B06 for a new broad audit.

The controller was notified immediately of this precise issue. This role did not edit the manuscript.

## Inputs and actual read states

Read first: `book/chapters/ch242.tex`, `ch243.tex` (continuous calculus proof in full, comparison proof in full), and relevant receiving passages of `ch244.tex`. Then source original-page images, then prior source landing map. Authority read: `records/b01/V18-B01-fixed-boundary-v3.md`, `V18-B01-Rudin-source-links-v4.md`; semantic-register rows 099–102 were crosschecked afterward. The broad source map is not substituted for evidence.

Original page images actually visually read in this pass:

* Rudin PDF146 right = printed275; PDF147 left/right = printed276/277; PDF148 left = printed278. Read 11.1–11.5, including the complete 11.5 proof continuing on278. Printed279 11.7 and printed278 lower Wiener-lemma material were only seen incidentally; neither is claimed fully audited. Printed274 is not claimed as an audited range.
* Conway PDF232–234 = printed218–220, VII.8.1–8.9 (8.7 proof continued on220); PDF248–253 = printed234–239, VIII.1.10–1.14 and VIII.2.1–2.7 with actual conjugation bars checked. The opening fragment of the unitization proof on234 is not an audit of VIII.1.9. No IX original body page was read in this pass.
* Rendered source-page evidence is private at `private_sources/b05-gap-scan/`. These are source derivatives, not manuscript/public artifacts.

Read snapshot hashes (before any controller repair):

| File | SHA-256 |
|---|---|
| `private_sources/rudin.pdf` | `aa31e887a2533fd5d6e60d15d072f8a694c31b55e268847999ead8cf284e10b2` |
| `private_sources/conway.pdf` | `c224068060b1386543141a9469d2fd32f8e39f462f09e76977cee2b82f51412d` |
| `book/chapters/ch242.tex` | `02faaebd25ea97c009734a6e6c3f653411893fa115ea3a3d41351cc25ac57fd6` |
| `book/chapters/ch243.tex` | `530dc223baffb9454222a9d932df1154ac7346a79a8aeca144c87491d9ebb0d1` |
| `book/chapters/ch244.tex` | `d7c5d34634ce49c4e6e2ee5900662df775b1f099c28a7e639e2ed3cef760eb36` |

The task folder itself has no Git HEAD; this role invents no commit. Line numbers below refer to the above snapshots.

## Item-by-item evidence within the selected chain

| Source item / actual print / PDF | Fixed responsibility | Actual manuscript landing | Status and substantive check |
|---|---|---|---|
| Rudin11.1,11.2 /275 /146 right | Minimal ideal definitions needed for calculus; full algebra course excluded | `lem:243-characters`, ch243:298; Calkin special case `sec:242-essential-spectrum`, ch242:407–412 | **OPEN_LOCAL_BRIDGE.** The needed ideal/proper/maximal definitions are unstated. General closure-is-an-ideal follows by norm continuity; make this explicit in the short bridge. |
| Rudin11.3 /276 /147 left | Maximal ideal existence and closedness | `lem:243-characters`, ch243:298 | **COVERED_PROOF, subject to bridge.** Zorn chain union and exclusion of I, Neumann-series argument for closedness are present. Source uses Hausdorff maximality; manuscript Zorn is the same mathematical obligation. |
| Rudin11.4 /276–277 /147 | Well-defined quotient algebra and quotient norm | `sec:242-essential-spectrum`, ch242:407–412; `lem:243-characters`, ch243:298–300 | **PARTIAL_GENERAL_BRIDGE.** Special-case representative independence, infimum estimate and quotient completeness already occur for Calkin; the general commutative quotient is asserted later. Add explicit general formula and one norm estimate. |
| Rudin11.5(a),(c),(e) /277–278 /147 right–148 left; ConwayVII.8.1–8.2 /218 /232; VII.8.6 spectral-value part /219 /233 | Characters detect every spectral point, via maximal ideals and scalar division-algebra quotient | `lem:243-characters`, ch243:288–303 | **COVERED_PROOF, subject to bridge.** Principal ideal, maximal quotient division property, and scalar quotient are proved. Manuscript proves the scalar division step via the nonempty operator spectrum of left multiplication, not by citing an unproved Gelfand–Mazur theorem. |
| ConwayVII.8.3–8.4 /219 /233 | Character boundedness (source norm1) | `lem:243-characters`, ch243:289–296 | **COVERED.** Spectral inclusion gives absolute-value bound; chi(I)=1 and normalized identity yield norm1 immediately. No need to duplicate source proof. |
| ConwayVIII.1.10,1.11(e) /234 /248 | Normality and norm/radius identity needed for calculus | `def:243-generated-cstar`, ch243:242–248; `thm:243-normal-continuous-calculus`, ch243:353–360 | **COVERED_PROOF.** Manuscript proves the C-star identity and dyadic powers for every normal B; not just a self-adjoint assertion imported from source. |
| ConwayVIII.1.12(a),(b),1.13 /235 /249 | Character adjoint preservation and real self-adjoint values | `lem:243-inverse-permanence`, ch243:252–285; `lem:243-characters`, ch243:302 | **COVERED_PROOF.** Real spectrum established independently for actual self-adjoint operators; inverse permanence transfers it to the subalgebra, and A=S+iT proves chi(A*)=conjugate chi(A). Conjugation bars visually verified in source. |
| ConwayVIII.1.14 /235–236 /249–250 | Inverse permanence, same identity and inherited norm | `lem:243-inverse-permanence`, ch243:258–285 | **COVERED_PROOF.** Local operator route uses Q=A*A, positive lower form bound and Neumann series. It does not invoke a later spectral theorem or source's omitted general C-star representation theory. |
| ConwayVIII.2.1,2.3–2.6 /236–239 /250–253 | Isometric normal continuous calculus and uniqueness | `lem:243-stone-weierstrass`, ch243:305–332; `thm:243-normal-continuous-calculus`, ch243:335–366 | **COVERED_LOCAL_SPECIALIZATION.** Scalar character values identify all lambda in sigma(N); polynomial evaluation has exact norm; locally proved Bernstein/lattice approximation extends onto C*(N). No compact maximal-ideal-space theorem or Gelfand transform topology is secretly required by this alternative proof. |
| ConwayVIII.2.6(c) /238–239 /252–253 | Agreement with holomorphic calculus | `prop:243-calculi-agreement`, ch243:383–397 | **COVERED_PROOF.** Bounded continuous calculus passes through norm contour integration; scalar Cauchy formula proves agreement. Source uses Runge; local proof avoids that deferred dependency legitimately. |
| ConwayVIII.2.7 /239 /253 | Continuous spectral mapping in operator ambient algebra | `thm:243-normal-continuous-calculus`, ch243:365 | **COVERED_PROOF.** Nonvanishing criterion in C(K), isomorphism and inverse permanence are explicit. |
| Required explanatory model for this construction | Distinguish continuous from holomorphic calculus and retain normal hypothesis | `ex:243-absolute-value-calculus`, ch243:368–372; `rem:243-nonnormal-obstruction`, ch243:374–379 | **COVERED_WORKED_EXAMPLES.** Multiplication model proves its spectrum; absolute value and jump distinguish function classes; nilpotent derivative term rules out false singleton-spectrum isometry for nonnormal operators. No additional obligatory example detected here. |
| Boundary to receiving spectral-measure construction | Continuous calculus must precede244 without using its theorem | `thm:244-cyclic-model`, ch244:151–174; `thm:244-normal-multiplication`, ch244:176–180 | **INTERFACE_CHECK_ONLY.** Receiving passages use the completed continuous calculus. This pass does not certify all244 measure/PVM proof obligations. |

## Precisely excluded / not audited

The fixed B01 v3 permits only the necessary commutative-algebra bridge, not the entire Rudin11 course. Rudin11.6 Wiener lemma,11.7 polydisc corona-type application, the full character-space/Gelfand theory, and ConwayVII.8.5–8.9 topological/representation generality are **DEFERRED_GENERALITY / NOT_REQUIRED_BY_LOCAL_ROUTE** except the scalar spectrum and norm consequences recorded above. This is not the status UNKNOWN. The exact destination volume number remains UNKNOWN.

ConwayVIII.2.2 nonunital representation and VIII.2 exercises (finite generators, totally disconnected spaces, L-infinity character spaces) are not used by the fixed unital single-normal-operator proof: **DEFERRED_EXTENSION**. ConwayVIII.1.9 general unitization is likewise unnecessary here. No full ideals/GNS/abstract representation branch is silently imported.

Rudin10 detailed holomorphic calculus and Rudin12 detailed spectral theorem pages, and ConwayIX PVM/multiplicity/separability pages were **NOT_READ_IN_THIS_PASS**, hence remain outside this report's coverage claim. Prior B04 maps remain prior evidence, not newly verified source reading. This bounded scan cannot discharge all B01 source-completeness OPEN items.

## Concrete small repair proposal

Insert before `lem:243-characters` (or explicitly before its first ideal use), and retain the existing proof:

> In a commutative unital algebra, an ideal J is a linear subspace such that a j belongs to J whenever a belongs to the algebra and j belongs to J. It is proper if J is not the whole algebra, and maximal if no larger proper ideal contains it. The ideal generated by b is b A; it is proper exactly when b is not invertible. Norm continuity of multiplication makes the closure of an ideal an ideal. For a closed proper ideal J, define (a+J)(b+J)=ab+J. Changing either representative changes the product by an element of J. The quotient is complete by Chapter232, and its quotient norm satisfies ||(a+J)(b+J)|| <= ||a+J|| ||b+J||: use representatives a+j,b+k within epsilon of their separate quotient norms and let epsilon decrease to zero. Its identity is I+J, which is nonzero. A division algebra means that every nonzero element has a multiplicative inverse.

This is a proposed local teaching bridge, not an applied edit. It also makes the existing maximal-quotient division argument readable without guessing terminology. After insertion, recheck the principal ideal is proper, maximal ideal is closed, quotient is Banach, and the existing left-multiplication spectral argument. No need to repeat the calculus proof or add the full source applications.

## Pasteable scoped handoff

* Role/stage: independent source-gap support, B05; source evidence does not replace sole strict final review. Original A-step mapping: late refinement/source coverage support before typesetting, not a new expansion round.
* Scheme/adoption: B as assigned; B01 v3 fixed responsibility controls this scan. No chapter renumbering or source boundary change.
* Unique manuscript: `book/chapters/ch232.tex`–`ch244.tex` as controller's current source; this role read relevant portions of242–244 and edited none.245 is outside scope.
* Versions/hashes: above source/manuscript hashes; no Git commit available in task directory. Prior chapter maps read only after direct prose, and their non-exhaustive flags retained.
* Deliverable: this report. Private evidence: `private_sources/b05-gap-scan/rudin-146.png`–`rudin-148.png`, Conway232–234 and248–253 images actually read. Conway235–236 were rendered but not reviewed and carry no coverage claim.
* Verified: the selected calculus chain has actual proof landings and two worked contrasts; no new major theorem/example gap found.
* OPEN: one local ideal/quotient teaching bridge, patch and independent affected-proof recheck. Broader Rudin/Conway every-item source completeness is not signed by this bounded pass. No test/build/PDF/hash acceptance claim.
* Next action/pass condition: controller may add the short bridge; a refinement reader rechecks that definitions precede first use and quotient multiplication/norm are justified. This resolves this report's only concrete OPEN item.
* Dependency impact: local prerequisite only; no change to243 theorem statements or244 interface. No reason to reopen other chapters or defer B06 for a broad new audit.
* Layout: no typesetting change performed; R1 template unchanged; PDF correspondence untested in this role.
* Prohibitions: do not treat this as full source census, all244 PVM review, whole-volume acceptance, or permission to publish source-page images; do not restart frozen earlier work.
* Delivery/read receipt: report saved in shared workspace and controller notified. No independent receipt from an external recipient is claimed; any external transfer remains controller/user action.
