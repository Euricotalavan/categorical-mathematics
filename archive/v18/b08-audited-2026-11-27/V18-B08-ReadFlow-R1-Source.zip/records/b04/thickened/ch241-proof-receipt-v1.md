# Chapter 241 independent B-04 mathematical proof review

The proof-development reviewer independently read all eight sections of the fixed middle draft and prepared the replacement for independent refinement. The two compact-operator inputs were checked against Chapter 240's proof-development replacement.

| Field | Record |
|---|---|
| Source | v18/drafts/middle/ch241.tex |
| Source SHA-256 | 5f65ebb77a664b1167a219e143f8e4d3e7de0fccaca5da8622080a7df95141d9 |
| Replacement | v18/records/b04/thickened/ch241.tex |
| Replacement SHA-256 | a0f5da55ccd5b49c4860e870bf875e2d202fd251f3b5c49b24bccb51756f438c |
| Diff | v18/records/b04/thickened/ch241.patch |
| Label consistency | The 39 source labels are retained in order. |
| Workflow | V18, B single Work, B-04 section proof development. Original middle candidate retained. |

| Original section | Result | Evidence |
|---|---|---|
| 241.1, lines 8–64 | Thickened | Identifies the compact closed unit ball of the kernel, normalizes a failing distance estimate before choosing bounded representatives, and completes via the quotient. The closed range yields compatibility and the quotient dual yields finite defect. Distinct notation separates Banach annihilators from Hilbert orthogonality. |
| 241.2, lines 65–116 | Thickened | Shows that the compact restriction is into the closed invariant space in the strict descent proof. The dual injectivity argument and finite-rank correction were checked. The inequality on the dual and the canonical embedding are explicit, with no reflexivity requirement. |
| 241.3, lines 117–152 | Thickened | Types the generalized inverse as linear. Finite kernel and finite defect give explicit bounded projections, and bounded inverse applies to the restriction between Banach spaces. The identities select a unique bounded solution in the complement. |
| 241.4, lines 153–192 | Thickened | Gives the ideal calculation for converting separate left and right candidates into one parametrix. Checks the kernel bound from \(ST\), closed range via the distance contradiction, and the cokernel bound from the transpose of \(TS\). Compact perturbation and Calkin identities use the correct two-sided ideal. |
| 241.5, lines 193–254 | Thickened | Types both Gaussian elimination factors, identifies how kernels and quotient ranges transform, and estimates the perturbation of the invertible block. The continuous compact path proves index stability. Transpose and Hilbert sign reversal use the verified annihilator and Riesz map identities. |
| 241.6, lines 255–301 | Thickened | Computes both parametrix errors with their identity spaces. The maps in the exact sequence are well-defined, and each kernel equals the preceding image. The alternating-sign rank sum and direct-sum dimension computations yield the two index formulas. |
| 241.7, lines 302–336 | Thickened | Computes the entire rank-one transpose, identifies \(T^*\) as the operator represented by the conjugate-transposed integral kernel, and fixes the previous diagonal-example reference. The unilateral row shift witnesses failure of a one-sided parametrix to imply Fredholmness. |
| 241.8, lines 337–380 | Pass | Checks the solution bound, finite-rank coefficient equivalence, shift composition, changing nullity with fixed index, and injectivity at index zero. |

Chapter 236 supplies the distance-to-kernel closed-range theorem. Chapter 240 supplies the compact-unit-ball criterion, Riesz's lemma, the ideal property, the transpose theorem, and the compact integral-kernel model. Chapter 241 establishes the quotient-algebra equivalence before Chapter 242 uses it for the essential spectrum. Independent refinement receives the fixed replacement and diff with no open mathematical issue found in this review. Combined references and PDF rendering go through the later integration and layout stages.
