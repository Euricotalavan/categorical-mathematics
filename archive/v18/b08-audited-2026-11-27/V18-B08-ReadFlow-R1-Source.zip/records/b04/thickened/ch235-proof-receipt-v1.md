# V18 B-04 proof-development receipt for Chapter 235

2026-11-27, Taipei · Read all 405 lines of records/b04/expansion/ch235.tex. Input SHA-256 a5e2395349ef13c2392323f47663356351893d48b0626598323c8002fe22e24d. Replacement SHA-256 dfac805f43b8ce4091ffd3425a68e59160701eadf23880dc0236a340dba8e779. Unified patch SHA-256 19824dd5d8e2ba898c872ba23d47153fae71b16e45b0523506ec00cc5aa166a1. All 23 author labels retained. Runtime model and reasoning settings are unverified.

| Section | Original lines | Proof-development result and evidence |
| --- | --- | --- |
| 235.1 | 11–74 | Verified Baire closed-ball nesting, Cauchy centers and density in all nonempty open subsets. The incomplete finite-support counterexample is an explicit countable closed nowhere-dense cover. |
| 235.2 | 75–152 | Verified closed test levels for arbitrarily indexed families, the interior-ball difference estimate and the case of a zero domain. Made the meagre complement in condensation explicit. The incomplete-domain counterexample retains a complete scalar target. |
| 235.3 | 153–239 | Verified the norm lower-limit inequality and compact-set uniform estimate from a finite net. The dense-set limit proof reuses the already established Chapter 233 estimate, with domain completeness applied separately only to generate the common bound. The c0 example gives the explicit single vector missed by density alone. |
| 235.4 | 240–291 | Verified the two different domains for Banach–Steinhaus. Canonical evaluation has norm equal to the vector norm by Hahn–Banach, and the dual is Banach even when the primal space is incomplete. |
| 235.5 | 292–346 | Expanded the scalar continuity modulus estimate for Riemann sums and constructed the precise bump witness for norm difference two. Verified joint continuity from the one complete input of a separately continuous bilinear form. Added an incomplete-input counterexample failing continuity at zero. |
| 235.6 | 347–405 | Verified all three solutions, including construction of a single c0 witness and the closed covering by finite initial Hamel spans. |

Next recipient is independent refinement. Chapter 236 can import Baire unchanged.
