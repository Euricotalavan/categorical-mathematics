# Chapter 240 independent B-04 mathematical proof review

The proof-development reviewer independently read all seven sections of the fixed middle draft and prepared the replacement for independent refinement.

| Field | Record |
|---|---|
| Source | v18/drafts/middle/ch240.tex |
| Source SHA-256 | 86a194a3096eebc5d352054bcac9ffebdbd639a63e81ceca3e50e7f3544493c2 |
| Replacement | v18/records/b04/thickened/ch240.tex |
| Replacement SHA-256 | baefa2f3762936f44ad02ad280f20ab4dc90fc68fbcd3cf0ad265f89eb6495b3 |
| Diff | v18/records/b04/thickened/ch240.patch |
| Label consistency | The 37 source labels are retained in order. |
| Workflow | V18, B single Work, B-04 section proof development. Original middle candidate retained. |

| Original section | Result | Evidence |
|---|---|---|
| 240.1, lines 8–57 | Thickened | The separated sequence construction now links the ambient subsequence criterion directly to total boundedness. The diagonal Cauchy construction, completeness and open-cover arguments give the other implications. Riesz's lemma uses the defining infimum and gives the strict separation used in Chapter 241. |
| 240.2, lines 58–94 | Thickened | Types the Banach domain and both continuous linear factors for the ideal property. The compact closure in the target, norm limit via a finite net, and uniform convergence on compact sets all pass. |
| 240.3, lines 95–113 | Pass | Weak limits are identified by weak continuity, bounded sequence compactness and Hausdorffness. The converse invokes reflexivity and weak sequential compactness from Chapter 237. The net statement explicitly assumes boundedness. |
| 240.4, lines 114–146 | Thickened | The finite net construction uses Hilbert best approximation. The Schauder projection argument now constructs the complete coefficient space and applies bounded inverse. The general approximation property remains a target assumption. |
| 240.5, lines 148–177 | Thickened | The forward Schauder proof uses only finite evaluation vectors and the norm estimate. The reverse proof uses compactness of the bidual transpose, the isometric intertwining and the closed canonical image of the Banach target. The Hilbert case names both spaces and cites the verified relation in Chapter 239. |
| 240.6, lines 179–236 | Thickened | The square kernel proof checks Fubini measurability and equality almost everywhere under representative changes. It proves the finite rectangle density by the needed Dynkin system argument, computes the finite-rank operators, and derives the adjoint explicitly with first-slot linearity. The diagonal, Ascoli, continuous kernel and compact inclusion arguments pass. |
| 240.7, lines 238–290 | Pass | Checks Volterra compactness, adjoint and infinite rank, weights, the single test functional in Schur's gliding-hump proof, compact maps bounded below, and both sides of the uniform projection approximation. |

The 241 dependency includes the finite-dimensional criterion, norm-closed ideal, Riesz lemma, and both directions of the compact transpose theorem. The square-kernel model gives a complete local route to Fredholm compatibility on \(L^2\). Independent refinement receives the fixed replacement and diff with no open mathematical issue found in this review. The later integration and layout stages still verify references and rendering.
