# V18 B-04 proof-development receipt for Chapter 239

2026-11-27, Taipei · Read all 340 lines of drafts/middle/ch239.tex. Input SHA-256 95d3423fa5fbb7efa320ba5a9b00b6423e340b09bc79c017bb7de0c3e7d3951f. Replacement SHA-256 2ff16db124a2e48a34165dca69a6f932d25fcb77be1531d09e1d51c53b95842f. Unified patch SHA-256 9ab40192645128c5aecfc0d831ea0a64875b69e7036bed586ee79f907c6c8e25. All 35 author labels retained. Runtime model and reasoning settings are unverified.

| Section | Original lines | Proof-development result and evidence |
| --- | --- | --- |
| 239.1 | 8–66 | Verified projection onto the kernel, conjugated representative under the first-slot convention, uniqueness and exact norm in both fields. Restricted the complex conjugate-linear corollary to its stated field and made the real bidual argument use symmetric Riesz. Hilbert and measure Riesz inputs stay distinct. |
| 239.2 | 67–125 | Verified adjoint linearity, norm equality by double adjoint, product order and conjugate scalar law. Typed compatible operators and established the multiplier's bound without using an undefined L-infinity notation. The transpose is linked by the conjugate-linear Riesz maps. |
| 239.3 | 126–166 | Verified both orthogonality pairs and the clause retaining closure. Closed-range lower bound comes from the bounded inverse on the orthogonal domain component. The converse uses Cauchy lifts there, and representing a functional on the closed range proves the adjoint range is closed. |
| 239.4 | 167–233 | Verified bounded-form operator construction in both fields, including the zero Hilbert space, Hermitian adjoints, coercivity lower bound and closed dense range, and minimization only in the Hermitian case. The nonsymmetric and merely strictly positive examples are correct. |
| 239.5 | 234–283 | Verified the real variational inequality projection identity and geometric Cauchy iteration, uniqueness, energy characterization and load stability. The replacement explicitly treats a zero Hilbert space and obtains a nonnegative contraction factor from alpha ≤ M. |
| 239.6 | 284–304 | Verified weighted norm and representation formula. Showed that the pivot embedding is bounded, injective, and conjugate-linear over the complex field. The own-space map uses weighted coefficients and remains distinct. |
| 239.7 | 305–340 | Verified five solved problems. The point-evaluation exercise now uses [0,1], with the evaluated point 0 in the measurable domain, and retains the precise L2 norm computation. |

Next recipient is independent refinement. Prior Hilbert-space geometry and Banach bounded inverse are used explicitly. The later positive-functional measure representation lies in Chapter 244.
