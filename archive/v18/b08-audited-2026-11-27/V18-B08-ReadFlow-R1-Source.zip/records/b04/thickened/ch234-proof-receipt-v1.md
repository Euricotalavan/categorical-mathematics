# V18 B-04 proof-development receipt for Chapter 234

2026-11-27, Taipei · Read the chapter's 796 lines, with the previously reviewed calibrated block directly verified as unchanged. Input SHA-256 3d9f6eb6bba00de6a49777cd652f47293feac71e589a2d7124953437d397469d. Replacement SHA-256 5a7afc05c4d5c2849aab3cc0866bbb1db47e8955290258ca555372b467bacc27. Unified patch SHA-256 a894ffc5f2133e3f4e5a2192f136c1161539abe5a034d15e3e6d6092e757f905. All 35 labels and the fixed refined B-03 block retained. Runtime model and reasoning settings are unverified.

| Section | Original lines | Proof-development result and evidence |
| --- | --- | --- |
| 234.1 | 14–88 | Verified the bilinear evaluation, the dual's target completeness, and the three sequence-space isometries. In the finite q-norm test, p(q−1)=q and the conjugate phase give a unit p-vector with value equal to the finite q-norm. Truncation identifies the functional uniquely. |
| 234.2 | 89–164 | Explicitly handled the full-domain case and the finite lower and upper bounds for the admissible interval. Verified domination separately for positive, negative, and zero scalar coordinates. The chain union preserves domain, linearity and pointwise domination. |
| 234.3–4 | 172–484 | The fixed independently reviewed B-03 block is unchanged in the replacement. The existing receipt covers the complex reconstruction, norming and distance, annihilation, and nonattainment examples. |
| 234.5 | 487–630 | Verified gauge homogeneity, subadditivity, strict sublevel equality and continuity. Open separation uses the real extension on the span of a point outside the gauge set, then openness precludes attaining the first supremum. The compact-versus-closed gap follows by thickening one set and taking the real functional supremum over an open ball. Added the exact norm identity for complex realification. |
| 234.6 | 631–741 | Checked all dual ranges and norm estimates. Typed transpose composition. Quotient duality uses approximate norm-minimal lifts, and restriction norm in the quotient is achieved by a norm-preserving extension. The canonical embedding is isometric and complete images are closed. The limit functional on c extends to a functional on ell-infinity outside the sequence-coefficient image. |
| 234.7 | 742–796 | Verified both complementary projection constructions and the closed-kernel criterion. Added the independence calculation for quotient representatives in the finite-codimension solution. |

The next recipient is independent refinement. Chapter 232 quotient norms, finite-dimensional analysis and the Chapter 233 operator norm enter as fixed prerequisites. Chapter 237 may use the exact continuous point separation, canonical bidual map, and sequence-space duals.
