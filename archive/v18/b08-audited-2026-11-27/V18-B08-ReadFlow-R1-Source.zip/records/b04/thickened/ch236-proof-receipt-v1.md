# Chapter 236 independent B-04 mathematical proof review

The proof-development reviewer independently read all seven sections of the fixed expansion draft. The replacement is ready for independent refinement. This receipt concerns the section-level B-04 mathematical review.

| Field | Record |
|---|---|
| Source | v18/records/b04/expansion/ch236.tex |
| Source SHA-256 | 6bf1a242f1353ad6906b324af7102f8f2b6be251d19736c4df7d6558b67f4aea |
| Replacement | v18/records/b04/thickened/ch236.tex |
| Replacement SHA-256 | c927f5b9d4d5b5c959101ee19ee4a81b8287b808bc573780e907e010f680caee |
| Diff | v18/records/b04/thickened/ch236.patch |
| Label consistency | The 28 source labels are retained in order. |
| Workflow | V18, B single Work, B-04 section proof development. Original expansion candidate retained. |

| Original section | Result | Evidence |
|---|---|---|
| 236.1, lines 11–93 | Pass | Scaled closure inclusions and a summable choice of lifts give an actual preimage with norm strictly below the ball radius. Completeness of the domain closes the series, and the Baire argument provides a uniform ball in the target. |
| 236.2, lines 94–133 | Pass | Inverse continuity follows from the open bijection. The smooth-function counterexample has bounded forward norm, sup-norm convergence to zero, and derivative sup norm exactly \(n\). |
| 236.3, lines 134–204 | Pass | The graph norm is the sum-product norm, completeness is checked in both directions, and the proper-domain derivative is handled by its integral identity. |
| 236.4, lines 205–261 | Thickened | Gives the pairwise estimate on quotient cosets explicitly. Completeness now follows on the page, and convergence of the induced map identifies the limit with an actual image. |
| 236.5, lines 262–347 | Thickened | Types the restriction map and computes its transpose factorization on a vector. Checks both Banach spaces for the bounded inverse, separates the zero target case early, and gives the phase and scaling argument for the real-part supremum over the open ball used by strict separation. |
| 236.6, lines 348–437 | Thickened | Makes bounded linearity of each inverse explicit and checks both idempotent constructions, kernel or range identities, and the closed direct complements. The antiderivative illustrates the bounded selection from a named complement. |
| 236.7, lines 438–511 | Pass | Checks the solutions of the six end-of-chapter problems against the estimates and hypotheses used above. |

Chapter 234 supplies Hahn–Banach, annihilator identities and strict separation. Chapter 236 now explicitly obtains surjectivity onto the closure before identifying it as the actual range, which is used to justify compatibility in Chapter 241. Independent refinement receives the fixed replacement and diff with no open mathematical issue found in this review. Full-volume numbering, references and rendering remain due at the later integration and layout stages.
