# V18 B-04 proof-development receipt for the Chapter 242 supplements

2026-11-27. B single-Work, B-04 proof development. The two additions were independently read after the core Chapter 242 review. B-01 boundary v3 and B-02/B-03 decisions governed the scope. Actual runtime model settings are unverified.

| Role | File | SHA-256 |
| --- | --- | --- |
| Fixed scalar bridge, all 108 lines read | v18/drafts/spectral/ch242-scalar-bridge.tex | 897bd87ad578167a2900092235b17c2cf3e4b18a56b7823ded730ec9369300cf |
| 116-line proof-developed bridge | v18/records/b04/thickened/ch242-scalar-bridge.tex | 16e464fd8cbbff0e3073a25211f7af9f0dabcb2ba29ea1ca58455a440adcde8b |
| Unified patch | v18/records/b04/thickened/ch242-scalar-bridge.patch | 7f49a9363a746189ecfef1d15cdf76350b9b722cb370fb91b2b46e88ca7a4f3c |
| Fixed additions source, complexification segment read at lines 2–16 | v18/drafts/spectral/ch242-author-additions.tex | 8571c46fd6b77946bd8deb529a9f00e60a5c76ccaa0c7a6a15b3d9856916d212 |
| 15-line proof-developed complexification extract | v18/records/b04/thickened/ch242-complexification.tex | 543daa55f26766f035a2533a58d40839dd50bf84c4a8170150d82a68487c6d15 |

| Proof block | Independent evidence |
| --- | --- |
| Goursat and disk primitives | The nested triangle estimate scales both diameter and boundary length by \(2^{-n}\), so the chosen lower bound and remainder bound share the \(4^{-n}\) factor. The affine terms have explicit primitives. A straight segment integral and the triangle identity give the disk primitive without presupposing continuity of the complex derivative. |
| Index and Cauchy's theorem for cycles | A lifted continuous argument makes the index an integer, and the integral makes it locally constant off the trace. Specified a Lebesgue-number subdivision in parameter space, so each replaced piece and its chord lie in a single disk. For an oriented edge the difference of the two local integrals is \(4i\arctan(a/\eta)\), giving index jump \(+1\); coefficients and orientation extend the calculation to repeated edges. After splitting all crossings and overlaps, this jump gives the weighted oriented boundary identity. Nonzero-index faces have closures in the domain. The vertical-strip subdivision into triangles applies to faces with holes and cancels internal edges. |
| Cauchy formula, estimates, Liouville and scalarization | Protected the factor \(k\) in the small-circle proof: the circle integral itself tends to \(2\pi i f(w)\), while the original cycle integral is \(k\) times that expression in the limit. Uniform geometric and differentiated series on smaller disks yield the derivative estimates. The first derivative estimate gives Liouville, and scalarization by all continuous linear functionals passes the needed contour identities to Banach-valued analytic maps. |
| Complexification | The rotation norm is equivalent to the component norm and agrees with the real norm on fixed vectors. Made the two directions of completeness explicit. For real \(\lambda\), an inverse over the complexification must commute with conjugation, whose isometry and fixed vectors are exhibited. Restriction is then a bounded real inverse. The rotation example distinguishes the complex spectrum from its real part. The nonzero Banach-space convention matches the adjacent nonempty-spectrum statement. |

Static checks passed for environment nesting, displays and unique labels, and the scalar patch applies to its exact original source. The scalar bridge belongs immediately before the nonempty-spectrum theorem and supplies the cycle theorem used in Chapter 243. The separate complexification extract supplies the real-scalar convention. Integrate each once and carry forward the already reviewed Calkin and pseudospectrum portions through their existing proof-development path. Independent refinement and integrated reference checking remain open.
