# Chapter 236 addendum proof receipt

V18 Functional Analysis and Bounded Operators, B single Work, B-04.
2026-11-27, Taipei. Independent proof development review of the three newly
added units in Chapter 236. The receiving role is refinement. The reviewing
task's actual model and reasoning settings were not independently verified.

| Input or output | Local locator | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| Earlier author draft | expansion/ch236.tex | 19,685 | 6bf1a242f1353ad6906b324af7102f8f2b6be251d19736c4df7d6558b67f4aea |
| Author addendum candidate | expansion/ch236-v2.tex | 22,808 | 17da16b198bf552ed7f78d9b3b4bc728aff12acc0635ddfb6fb5de1b63c31390 |
| Previously proof-reviewed base | thickened/ch236.tex | 20,236 | c927f5b9d4d5b5c959101ee19ee4a81b8287b808bc573780e907e010f680caee |
| Proof-reviewed integrated candidate | thickened/ch236-extended-v2.tex | 23,724 | f8a42fc5b73f4d7d2a42d5e0460ec0f8bdcbd6c3b794302c60d91c13a824afe3 |
| Patch relative to the proof-reviewed base | thickened/ch236-extended-v2.patch | 4,108 | d797cc6d630ee08294f0c6694b0e804ac85b3da1f4302331bc9e45fc24770719 |

Input locations are relative to records/b04. The author v1→v2 diff consists
of two insertion hunks containing the three units. This review read those
hunks, their insertion-site context in the proof-reviewed base, and the
targeted reference labels. Earlier proof passages are preserved.

## Findings and dispositions

| Unit and new line | Independent mathematical check and changes |
| --- | --- |
| Closed-graph test at zero, line 206 | The forward implication tests the graph limit at zero. The converse subtracts the candidate domain limit, which belongs to the everywhere-defined domain, and uses linearity. Both norms are now named, and the local closed graph theorem is linked precisely. Completeness appears only in its subsequent application. |
| Incomplete target example, line 227 | The chain union and maximal spanning argument justify the Hamel basis extension by Zorn's lemma. The functional's values on normalized unit vectors are fixed at one, so the ratio of the two norms grows as \(n+1\). The stronger target norm forces any putative product limit onto the identity graph. Differences of the displayed Cauchy sequence lie in the kernel of the algebraic functional, while its candidate limit zero has positive distance in the target norm. |
| Everywhere-defined infinite matrix, line 501 | Each finite row sum is bounded by \(\sum_{j\le N}|a_{ij}|\) times the domain norm. The Chapter 235 pointwise-limit theorem yields a continuous linear functional for each row. The range hypothesis produces a genuinely everywhere-defined linear operator into \(\ell^p\). Coordinate evaluations and the zero test then give closedness. Both failure mechanisms are explicit, including at \(p=\infty\). |

Verified that removing the two insertion hunks reproduces the original
proof-reviewed base byte for byte. All 28 original labels retain their order
and all three new labels are unique. New internal and Chapter 235 references
resolve against the fixed source files. Newly inserted TeX environments are
balanced. Both versions retain Chapter 236 and no other file was altered.
This small handoff has no paired PDF. Full-volume build, pagination, coverage,
and final mathematical acceptance are pending their respective stages.

The three units may proceed to independent refinement. Use the integrated
candidate at the stated digest, with the two-hunk patch available for
provenance. Retain the base file and prior proof receipt, and review the added
dependencies and examples only where this addendum affects them.
