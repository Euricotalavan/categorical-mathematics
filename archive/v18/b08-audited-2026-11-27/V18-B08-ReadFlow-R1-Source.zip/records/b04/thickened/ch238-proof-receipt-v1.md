# V18 B-04 proof-development receipt for Chapter 238

2026-11-27, Taipei · B single Work · Read all 393 lines of drafts/middle/ch238.tex. Input SHA-256 df093ea9333f100b4ecf27b42c71e0e96914b2491d91a03e5f420bec8223e63a. Replacement SHA-256 e41b65a6cfc9c1a85260488fb506279f8457302f44a96783d887deb3e80259c4. Unified patch SHA-256 cb32b4c20940376611c8b5abd1207700174988cf62765588f389ffe5d5cb5a34. All 38 author labels retained. Runtime model and reasoning settings are unverified.

| Section | Original lines | Proof-development result and evidence |
| --- | --- | --- |
| 238.1 | 8–80 | Verified equality in Cauchy–Schwarz, correct sign of complex polarization under first-slot linear convention, norm and continuity estimates, and well-defined completion inner product. Quantified inputs explicitly. |
| 238.2 | 81–125 | Verified sequence example and complex L2 bridge using the verified real L2 completeness input at V16 Ch218. The product integral is absolute without sigma-finiteness. Algebra and norm pass to a.e. classes and completeness follows from the squared norm splitting into real and imaginary parts. Expanded arbitrary-index sequence completeness by passing to a coordinate limit on each finite subset before the global supremum. |
| 238.3 | 126–203 | Expanded the minimizing-sequence bound and qualified the positive closed-ball nonlinear example. Verified the variational inequality using real t and the firm nonexpansivity cross term. Proved positive cone closedness by the continuous positive-part fixed-point description. Expanded exact open-ball distance and the incomplete inner-product counterexample, with the scalar orthogonality condition preceding orthogonal-complement notation. |
| 238.4 | 204–256 | Verified complex orthogonality from real and imaginary directions, decomposition, operator norm equality on a nonzero range, double-complement identities, first-slot Gram matrix order and its invertibility. The quotient norm uses Pythagoras on the orthogonal representative. |
| 238.5 | 257–332 | Verified finite Bessel bounds, countable support in arbitrary index families, norm convergence by square-summable tails and Parseval in both directions. Zorn existence treats zero space and maximality, and the span/density argument for Gram–Schmidt discards zero residuals. |
| 238.6 | 333–393 | Verified uniform convexity, reflexivity via Ch237, weak-plus-norm convergence and all six exercise solutions. Made the conjugate coefficient in the pre-Riesz coordinate weak test explicit, so no later representation theorem is silently used. |

The next recipient is independent refinement. The fixed Volume 16 dependency supports real L2; this chapter proves the complex bridge locally. Later 239 Riesz can now use all Hilbert-space structure without circularity.
