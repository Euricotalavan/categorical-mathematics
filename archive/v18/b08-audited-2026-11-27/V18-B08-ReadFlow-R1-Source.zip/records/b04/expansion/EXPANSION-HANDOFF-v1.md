# V18 B-04 expansion handoff — Chapters 232–236

**Handoff ID:** V18-B04-EXP-232-236-20261127-v1. **Date:** 2026-11-27 UTC. **Sender → receiver:** isolated expansion task → controller → isolated thickening task, then refinement. Task messaging is available; a conversation URL is not exposed. This is an author handoff, not a mathematical acceptance report.

## Authority and receipt

The controller explicitly assigned English original drafting of Chapters 232–236 under V18 B single Work, after the controller's B-02 reconciliation and selection of B-03 samples. I read the project navigation v2.1, A/B v4, B single-Work v1, readiness v1, and relevant fixed book text. Their fingerprints, actual reading scope, and output fingerprints are recorded in `EXPANSION-MANIFEST-v1.json`.

The controller supplied the adopted conventions: continuous linear dual `X^*`, Banach transpose `T'`, Hilbert adjoint `T^*`, inner product linear in the first slot, annihilator `M^\circ`, labels `ch:<number>` and `sec:<number>-*`, native definition/theorem/proof/example/problem/psolution environments, no shared macro changes. Chapter 232 does not assume Lp completeness; the controller reserves the short complex L² bridge for 238 and the full treatment for 245. Chapter 236 includes both the quotient-distance closed-range criterion and the full bounded Banach closed range theorem needed by 241.

The controller directed reuse of the independently refined 234 B-03 fragment. I actually read it and checked its SHA-256 `90d2fc1189dcd7d113d474512c3f1e57a082e64efdcf23a52a1ec53be78ee645` before embedding its complete contents unchanged in `ch234.tex`, between explicit comment markers. Its two sections and all examples, including the closed hyperplane with no nearest point, are preserved. The new preceding real Hahn–Banach proof discharges its previously stated prerequisite. This incorporation is not a claim that the new surrounding material has passed review.

The original instruction not to inspect other role outputs was obeyed apart from this later explicitly authorized refined fragment. I did not read the thickening self-assessment/checklist, another author's chapters, or independent review reports. I did not spawn agents, modify the unique manuscript, sources, shared macros, templates, prior frozen volumes, tool ZIP, or curriculum.

**Model/mode:** the project requests GPT-6.1 Sol for expansion. Actual selected model and inference/High setting are not independently verifiable by this task; preserve UNKNOWN rather than infer them from a role label.

## Manuscript delivery and version choice

The five complete author candidates are `ch232.tex`, `ch233.tex`, `ch234.tex`, `ch235.tex`, and **recommended `ch236-v2.tex`**. The earlier `ch236.tex` is retained at its previously sent hash as review history. Only one 236 version should be included in the parent manuscript. `ch234-prefix.tex` and `ch234-suffix.tex` are assembly aids, not competing manuscripts and not extra chapters. No other source file should be included alongside `ch234.tex`.

Each chapter includes narrative, definitions and theorem statements, full author proofs, diagnostic examples, and solved problems. 'Complete author candidate' means the authorized chapter route has been drafted; it does not assert completion of independent thickening, source/semantic refinement, B-05 integration, R1 layout, B-07 acceptance, or B-08 archival.

| Chapter | Concrete coverage and stable outputs | Particularly important review points |
|---|---|---|
| 232 | Norm/metric/equivalent norms; Banach and closed-subspace criteria; absolute series; finite Hölder/Minkowski and ellp completeness; c/c0/c00; separability; C(K) and C1; completion construction and uniqueness; products and quotient norm including open quotient map and complete quotient; three-space completeness; finite-dimensional norm comparison; Riesz lemma and compact-unit-ball criterion; solved problems | Quotient representative independence and summable correction; no open mapping used early; norm versus seminorm for a nonclosed subspace; no unproved Lp completeness |
| 233 | Full boundedness/continuity equivalences; exact operator-norm formulas; completeness B(X,Y) with only target complete; composition/rank one; dense extension; Neumann series/two-sided inverse; inverse perturbation estimate; shifts with one-sided inverses; norm versus strong convergence; convergence from dense data with common bound; sequence inclusions/diagonal nonclosed range; evaluation/composition; continuous-kernel norm exactly computed | A finite-rank algebraic map is not automatically bounded; strong convergence depends on a fixed vector; dense extension requires target completeness; preserve multiplication order in inverse formulas |
| 234 | Basic dual and explicit onto isometries for ell1/c0/ellp; real one-dimensional Hahn–Banach and full Zorn step; complete fixed refined complex/norming/distance fragment; gauge and open convex separation; compact/closed strict separation and failure example; transpose equality of norms and closure; subspace and quotient duals; canonical bidual embedding; strict largeness of linfty dual; finite-dimensional and finite-codimensional complements | Bilinear dual pairing versus conjugated coefficient convention; all complex phase signs; separation gives closure of range before a closed-range proof; distinguish maximizing functional from nearest vector |
| 235 | Baire nested-closed-ball proof; arbitrary-family uniform boundedness with normed target; incomplete counterexample; dense residual set of unbounded tests; pointwise limits and liminf norm; dense and compact convergence; vector weak-boundedness without completeness of original X; family of dual functionals with complete X; Riemann sums with norm difference exactly 2; separate bilinear continuity; solved problems | Family need not be countable; countable level sets supply Baire; dual X* automatically complete; dense tests alone do not imply a common bound; conclusions about sequences do not assert the same boundedness for arbitrary nets |
| 236 v2 | Closure-to-exact ball lifting with geometric residuals; open mapping/Baire; bounded inverse and comparison of complete norms; graph norm/closed graph/proper-domain derivative; zero test and explicit incomplete-target closed unbounded identity; distance-to-kernel iff closed range; four-way Banach closed range theorem with a nonreflexive proof; complements/bounded projections; bounded left/right inverse characterization; antiderivative model; everywhere-defined infinite-matrix boundedness via UBP then closed graph; Fredholm-ready complement problems | Ball lifting must construct an actual sum; no linear solution selector from open mapping alone; quotient estimate does not require a nearest representative; transpose compatibility detects closure unless range closed; graph theorem requires whole complete domain and complete target |

The proof route for Banach closed range is local and bounded: closed range gives a functional on the range and Hahn–Banach lift; closed transpose range gives an injective bounded-below transpose on the closure of the range; separation gives an image-ball closure inclusion; the already proved ball-lifting lemma yields onto-ness. No reflexivity or unbounded transpose theory is silently imported.

## Actual source reading and source-responsibility limits

The independently fixed full PDFs are present under `v18/private_sources`; this task reads their extracted local text where recorded. I actually read Conway III.1–6 and III.12–14 in the portions used, including original source arguments and exercises for completion/quotients, duals/Hahn–Banach, open mapping/closed graph, complements, and uniform boundedness. I read Brezis 1.1–1.2 and 2.1–2.4, and the bounded specialization of the closed-range material 2.7, Theorems 2.19–2.20/Remark 18. The refined sample records the additional Brezis complex-theory source responsibility checked by refinement, rather than by this task.

Rudin's local extracted text is only 221 bytes and is not usable for a direct source reading by this task. Its fixed PDF exists, but I did not reread it visually; Rudin per-item verification belongs to the independent refinement source table and must not be relabeled as this author's actual reading. The chapter proofs are original exposition of the mathematics; no source prose was copied into the new author material.

| Author section(s) | Source orientation actually read | Responsibility evidence |
|---|---|---|
| 232 norm/Banach/C(K), finite dimension, quotients | Conway III.1, III.3–4 | Statements and source proof routes checked; author supplied omitted exercises/details and independent sequence/completion arguments |
| 233 bounded maps and extension | Conway III.2 and associated exercises | Author full proofs for results left to exercises; Neumann/perturbation derived directly from Banach-series criterion |
| 234 duals and extension | Conway III.5–6; Brezis 1.1 | Real extension/Zorn and coefficient proofs independently expanded; fixed refined complex fragment incorporated at checked hash |
| 234 geometry | Brezis 1.2, Thms1.6–1.7/gauge lemmas | Full local gauge, phase reconstruction, strict-gap proof and nearby failure example |
| 235 Baire/UBP | Brezis 2.1–2.2; Conway III.14 | Brezis closed-level proof route; Conway confirms normed target and arbitrary normed X for vector weak-boundedness |
| 236 open/graph/complements | Brezis 2.3–2.4; Conway III.12–13 | Full exact-lift stage and complement characterization; additional explicit failure examples |
| 236 bounded closed range | Brezis 2.7 Thm2.19, Remark18, Thm2.20 | Restriction to bounded everywhere-defined Banach operators; independent separation/ball-lifting proof avoids unbounded theory |

This table does not substitute for the B-01 per-item index or claim that all 118 source candidates are resolved. The controller reports its newer B-01 v3 and added responsibilities; the final fixed row IDs must be reconciled by refinement against the actual author labels. New source obligations outside these chapters are not silently brought into scope.

## Engineering and delivery evidence

Static checks on the five initial chapter files verified that all LaTeX begin/end environments nest and close correctly and that their 151 labels are unique. The v2 additions in 236 are separately included in the final manifest check. No shared preamble changes were made.

An optional author-only syntax stub in `engineering/author-syntax-check.tex` was attempted with `/usr/bin/xelatex -interaction=nonstopmode -halt-on-error author-syntax-check.tex`. The executable failed before reading the manuscript because its default environment could not locate `xelatex.fmt`. The initial command also attempted to use a workdir before creating it; the directory was then created and the command rerun, producing the explicit missing-format error. No installation or configuration was changed. This is not a text-syntax failure, a successful build, or a substitute for the controller's already working official R1 build.

**PDF pairing:** no PDF was produced by this task; every candidate is source-only until the parent compiles it. **Content preservation QA:** only the fixed 234 fragment's exact bytes and author source/labels have been checked. **Engineering QA:** static checks only; naked XeLaTeX environment failed. **Reading QA:** no rendered-page review. **Mathematical review:** pending isolated thickening then independent refinement for every new section. None of these statuses may be replaced with another.

The current scratch files have been delivered to the parent by exact path/hash in task messages. Durable snapshot, authorized destination ID, recovered-download/hash evidence, and any archival commit are controlled by the parent and have not been claimed by this task. No restricted book PDF or credential was uploaded or published.

## OPEN / UNKNOWN and the next action

| ID | Position / impact | Owner and next step | Blocks |
|---|---|---|---|
| EXP-U01 | New 232–236 sections have only author proofs, no independent acceptance | Thickening reads fixed chosen files, expands necessary steps; refinement independently verifies source/semantics | Marking any new section refined or accepted |
| EXP-U02 | B-01 v3 row IDs and final cross-source conditions are parent-controlled; this task did not read another role's source report | Refinement aligns every actual source responsibility with stable author labels; report any specific gap | Source-complete claims/B-05 integration |
| EXP-U03 | Prior-volume published 231→232 baseline is inherited from controller/readiness | Controller retains actual fixed Git read/version evidence | Formal numbering certification by this role |
| EXP-U04 | Bare XeLaTeX default missing format; no author PDF | Parent uses its working R1 build and records exact source/PDF versions | Engineering/layout acceptance, not mathematical reading of source |
| EXP-U05 | Chapter references to 237–245 unresolved in the isolated partial set | Parent resolves against actual full-volume labels after merge | Clean full-volume reference check |
| EXP-U06 | Model/mode not independently inspectable here | Parent records observed settings or preserves UNKNOWN | Truthful settings certification |
| EXP-U07 | Durable remote destination/recovery not established by this task | Parent includes source/records in authorized recoverable snapshot and rechecks fingerprints | Calling the task remotely saved/archived |

**Unique next stage:** controller selects `ch236-v2.tex` (recommended) or the retained original, fixes one version of each chapter, sends those exact versions to thickening, then to refinement in the authorized B-04 sequence. Routine merging/engineering remains with the controller. No need to ask the user separately for each section.

**Pass conditions:** definitions usable from already read text; every hypothesis/quantifier/type explicit where needed; all necessary proofs and worked examples complete in the actual draft; exact B-01 source row coverage verified; all defects and transitive dependency effects recorded; same single manuscript updated through trackable patches. A chapter author handoff is not B-07 or B-08.

**Change scope:** these are new English chapters at the fixed 232–236 numbers, plus the preserved calibrated 234 fragment. The sole v2 source change is the three added 236 units described above; the original `ch236.tex` retains its already delivered SHA. No accepted source was overwritten. If kernel/range definitions, dual conventions, quotient norm, or theorem hypotheses are changed, recheck downstream 237–245 dependencies identified in B-02, especially 241.

**Forbidden redo:** do not replace the fixed refined 234 fragment with the old expansion sample, include prefix/suffix as extra manuscript copies, include both 236 versions, rebuild source tools, reopen frozen volumes, reset numbering, publish restricted sources, or have the controller sign mathematical acceptance. Preserve already verified 234 corrections and historical UNKNOWNs.

**Pending user decision:** none requested; routine decisions are within the controller's current authorization. Any substantive source/boundary conflict should be presented with exact competing statements rather than hidden as a stylistic choice.

**Transmission/receipt:** exact candidates and hashes have been sent by task message, but a message is not a read receipt. Receiver should return actual filenames/hashes read, selected 236 version, missing inputs/conflicts, understanding of B-04/KEEP, and the next unique action. No falsely implied read receipt is supplied by the sender.
