# V18 Chapter232 independent refinement — v1

Input `v18/records/b04/thickened/ch232.tex`, 28057 bytes, SHA-256 `ce360cd223d3cfe9a8e63798d4e5ec7567bb869a7dd47df29d43b331d7fbf2d1`. Expected ce360cd223d3cfe9a8e63798d4e5ec7567bb869a7dd47df29d43b331d7fbf2d1 matched: True. Entire actual chapter read independently before any historical thickening assessment. Source follow-up actually read ConwayIII printed63–66,69–72/PDF77–80,83–86, including necessary exercise responsibilities; Brezis11 and Rudin4 source conditions read in B01 as recorded. No whole prior volume was changed.

**Decision: PASS with small definition/source-coverage additions in refined/ch232.tex.** No incorrect proof was found in the incoming chapter. The additions make its first-use vocabulary and admitted sequence/function-space responsibilities complete at this local level; global every-source coverage and volume integration remain separate.

## Changes and evidence

Added explicit seminorm, norm-bounded set and separability definitions before first named use; added the source seminorm ball-comparison lemma with scaling proof, including zero-q vectors (ConwayIII.1.4). Added separability of c via c0 plus the constant sequence (Brezis11.16). Added Cb(S) and C0(S) completeness: compact level sets give boundedness, level-set unions give linear closure, uniform approximation gives closedness. This matches ConwayIII.1.6–1.7 and supplies actual definitions instead of relying on a later Riesz–Markov chapter. These are independent original paragraphs; source prose not reproduced.

## Independent full-chapter proof checks

Norm axioms/metric, sequential continuity of operations in metric domains, closure of subspaces, and equivalence of norms checked. Bounded/compact/Cauchy consequences use correct metric/topological distinctions. Integral-versus-uniform peak example computes norms1 and1/(2n) without importing Lp completeness.

Absolute-series criterion correctly selects strictly increasing indices beyond nondecreasing Cauchy thresholds and telescopes. Sequence-space Holder proof handles zero normalization; Minkowski division handles zero sum; coordinate limits plus finite partial-sum bounds prove lp completeness without assuming the result. c/c0 are closed in ell-infinity; truncation density is correct, and c00 incompleteness includes infinity norm. Countable rational vectors versus disjoint indicator balls prove separability distinctions.

Uniform limits preserve continuity on an arbitrary topological domain; bounded-function completeness and C1 derivative completeness use the stated uniform estimates/Fundamental Theorem of Calculus. The uniform C1 counterexample has the correct 1/sqrt(n) error.

Completion is the algebraic quotient of Cauchy sequences by null sequences; equivalence, norm independence, dense embedding, completeness and unique onto isometry are each proved. No quotient-completeness theorem or dense-extension theorem is borrowed from the future. Product proof correctly treats finite factors and equality of product/norm topologies.

Quotient equality/operations and representative independence checked. Formula is definite exactly for closed M. Open-ball equality is proved directly, so quotient openness/completeness is independent of236 open mapping. Corrected representatives have summable increments; Cauchy subsequence convergence transfers to the original sequence. Three-space completeness proof takes a quotient limit representative, selects near minimizers and uses completeness only on the subspace; no nearest-representative assumption.

Finite-dimensional norm lower bound uses compact scalar coordinate sphere only; Riesz separation retains a strict uniform lower bound after taking infimum. Compact-ball characterization uses pairwise separated unit vectors and metric subsequence compactness. The even-coordinate quotient formula is an actual onto isometry. All three problem solutions, including closed-plus-finite, compact zero-neighborhood and separable quotient, were checked.

## Source landing and handoff

`ch232-source-landings-v1.json` maps responsibilities to exact current labels and lines. Shared results with several books need only one original complete theorem. Infinite Banach direct-sum generality is not claimed by this finite-product section; Hilbert sums/nonseparable Hilbert examples belong238. General Sobolev source examples remain outside the fixed boundary. The exact first-use/global notation joins with233/234/237 are still checked in B05.

Next unique action: parent verifies input hash, merges this minimal patch/refined file, records output hash and accepts local232 content. No source/PDF compilation pair, page QA or whole-volume mathematics accepted here. Actual model/mode not independently verifiable by this task. No user decision required.
