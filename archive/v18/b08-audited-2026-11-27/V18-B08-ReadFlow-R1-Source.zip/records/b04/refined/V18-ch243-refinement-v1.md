# V18 Chapter243 independent refinement — v1

Input `v18/records/b04/thickened/ch243.tex`, 36806 bytes, SHA-256 `be6547373bf59ca94bc0a1d5e7d5d0b67792b965797b3ee2c4e3801b9ca45c6c`; expected be6547373bf59ca94bc0a1d5e7d5d0b67792b965797b3ee2c4e3801b9ca45c6c matched: True. Actual new contour/calculus/projection/pole/multiplicity text and chapter joins read independently. Accepted B03 continuous-calculus block compared to refined/spectral.tex: exact byte equality before the next section = True; equality after trimming boundary whitespace = True. Its mathematical content and approved two patches are retained; no requirement to re-prove unchanged accepted material was imposed.

**Decision: PASS with small definition/scope clarifications, no incorrect incoming proof found.** The Chapter242 forward algebraic-multiplicity responsibility is now fulfilled at actual label `prop:243-compact-algebraic-multiplicity`, with finite-dimensional Riesz range and complete original proof. This is chapter content refinement, not B05/B07 or PDF acceptance.

## Changes

Added operational norm-analytic derivative definition at its first general use; stated nonzero complex Banach X before operator spectral decomposition; defined the Banach-valued pole-order convention; explicitly included the singleton-spectrum P=I convention in compact multiplicity proof. None changes a theorem conclusion, contour value or the accepted B03 block. Minimal patch supplied.

## Independent check of the new mathematics

Polygonal contours: finite square unions covering K_r have boundary outside K; edge cancellation leaves finite directed cycles. Pointwise square indices and local constancy give index1 near K and0 outside the actual open domain. The delta and2delta constructions have disjoint traces with the required nested indices, including holes/disconnected domains. No assumed global holomorphic extension across a spectral gap.

Contour independence: difference indices vanish on the excluded spectrum and outside the function domain, so scalarized Cauchy applies on U minus K. Different germs/domains are compared through a third cycle inside their common neighborhood of agreement. Norm continuity estimates use total variation/absolute cycle multiplicities.

Multiplicativity: signs in the resolvent identity checked; outer w integral gives2pi*i*g(z), while the other inner z integral vanishes because w has inner index0. Continuous integrands on disjoint compact traces permit norm Riemann-sum interchange. Entire monomials permit the large-circle series; rational reciprocal follows from the product law. Power-series radius larger than r(a), rather than necessarily larger than norm(a), is valid by spectral-radius bounds and the chosen circle.

Holomorphic mapping: reciprocal near spectrum gives one inclusion; removable divided difference and commuting-product invertibility give the reverse, even across disconnected neighborhoods. Composition shrinks f's source domain into the outer contour's index-one region and away from its trace, so the scalar double-integral formula applies throughout the inner trace.

Riesz splitting: idempotent and commutation from holomorphic scalar identities; nonzero pieces from spectrum of the projection; closed complemented invariant ranges; inverse germ on each component supplies restricted inverses. Block inverse equivalence establishes exact restricted spectra, not just inclusions. Oblique triangular-matrix projection computed correctly.

Isolated point: on the Riesz range, Q is quasinilpotent. Its radius-zero inverse series converges normally on every compact punctured annulus; complementary block analytic near lambda. Uniqueness of scalarized Laurent coefficients makes finite pole order exactly the stated nilpotence order. Singleton spectrum uses P=I. No claim isolated means pole without extra structure.

Compact algebraic multiplicity: nonzero compact spectral point isolated by242; restricted compact map has singleton nonzero spectrum, so boundedly invertible. Compact identity forces finite dimension; Cayley–Hamilton then gives nilpotence. Complement is invertible at lambda, so all generalized kernels lie in the finite Riesz range and stabilize there. The resolvent pole and geometric/algebraic distinction follow. No circular use of the later self-adjoint spectral theorem.

After retained B03: continuous map into C(K) along the trace is uniformly continuous away from spectrum, and the isometry commutes with the norm integral; scalar Cauchy gives agreement of calculi. Normal resolvent norm and orthogonal gap projection estimates follow correctly. All four problem solutions checked, including norm differentiable exponential uniqueness, stable left-half-plane contour estimate, holomorphic eigenvectors without normality, and continuous composition via star-polynomial approximation.

## Dependencies and next action

Uses actual242 radius/nonempty-spectrum/polynomial mapping, prior239 adjoints and orthogonality, and local complex-L2 bridge238 for its multiplication example. Scalar complex Cauchy/winding/removable-singularity inputs are explicitly declared; controller reports a local scalar appendix is being added. Their original proof completeness remains that appendix's own check, not an invented acceptance here. Sources with multiple book links map to one original conclusion.

Parent verifies input/output hashes and merges this refined file; `ch243-source-landings-v1.json` gives exact labels/lines for the additions and retained calibration. Then resolve the paired242 forward-result row and continue B05 chapter joins. No source PDF or restricted raw excerpts included. No compilation/PDF/page QA performed. Model/mode not independently verifiable; no user decision requested.
