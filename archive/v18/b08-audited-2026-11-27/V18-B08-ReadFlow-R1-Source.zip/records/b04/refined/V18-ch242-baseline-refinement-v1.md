# V18 Chapter242 independent refinement — baseline v1

2026-11-27 UTC. Input `v18/records/b04/thickened/ch242.tex`, 24619 bytes, SHA-256 `014b40f2317619d8bf513af889d8922896951435b3c557e2abf1f86cb4762c8e`. Controller expected014b40f2317619d8bf513af889d8922896951435b3c557e2abf1f86cb4762c8e: MATCH. Read the actual entire chapter before consulting any historical proof review. No historical review read for this pass. This is the pre-addition baseline; Calkin/essential spectrum and algebraic multiplicity additions are explicitly not merged or assessed here.

**Decision: the mathematical content actually present passes independent refinement, with no semantic change required. The chapter as a whole remains OPEN until the admitted additions and source responsibilities are integrated and checked.** An unchanged refined copy was produced for a concrete mergeable result. Do not mark this whole242 complete merely from this baseline review.

## Proof and definition evidence

* Algebra definition supplies nonzero unit, complex field, associativity/bilinearity, completeness/submultiplicativity and normalized identity. One-sided shift example correctly distinguishes inversion. Nonzero X avoids spectrum-empty zero-space degeneration.
* Neumann proof computes both products, preserves factor order for noncommutative perturbation and gives the stated difference estimate.
* Spectrum names its ambient algebra. The circle-polynomial example correctly proves failure of inverse permanence with contour integration, without assuming holomorphic extension of an arbitrary boundary limit.
* Local resolvent series signs, derivative factorials and first resolvent identity checked. Outside expansion gives disk bound and norm estimate. Nonemptiness uses scalarization, scalar Liouville, vanishing at infinity and Hahn–Banach point separation; no vector theorem hidden.
* Submultiplicative root lemma includes zero powers. Radius proof first obtains convergence outside root limit, then constructs the needed Banach-valued norm integral before using it. Uniform outside-series integration gives a^n; annulus lies fully in the resolvent; final integral estimate yields reverse inequality. No future243 is cited as a proof.
* Polynomial mapping handles constants separately; commuting factor invertibility and rational denominator/inverse independence retain multiplication order. No unproved subalgebra spectral permanence is used.
* Banach transpose spectrum uses exact dual norm formula, inverse bound, range closedness and annihilator density. Complex Hilbert adjoint is conjugate-linear Riesz transport, so its spectral conjugation differs from the transpose. This matches visually checked Rudin4 conventions after translating his T* to this volume T'.
* Spectrum partition gives point priority; continuous case is injective/dense/proper, residual case injective/nondense. Approximate point lower bound equivalence uses Banach domain/range. Boundary resolvent blowup proof and normalized inverse-vector construction checked.
* Shift recurrence and conjugation checked: S residual disk/continuous circle; L point disk/continuous circle/no residual. M_t calculation on L2 uses positive-measure localized intervals, a.e. injectivity and adjoint kernel density; all interval points are continuous spectrum.
* Compact theorem proves nonzero eigenvalues using earlier Fredholm alternative; eigenspace compact-ball argument; finite values away from0 by separated vectors in growing finite-dimensional invariant spaces; countability/isolation and0 in infinite dimension. No eigenbasis claim for general compact operators.
* All four problem solutions checked: bounded diagonal spectrum closure and endpoint0 classification; commuting radius product/sum and noncommuting counterexample; resolvent-distance direction; similarity with varying norm. Volterra is only an explicit later application pointer, not a proof dependency.

## Required inputs and remaining obligations

| ID | Exact location / impact | Status and next action |
|---|---|---|
|242-O01|No Calkin/essential-spectrum section in reviewed baseline|Known pending separate source-author addition; inspect final merge including infinite-dimensional/nonzero quotient conventions and compact-perturbation invariance|
|242-O02|No finite algebraic multiplicity/generalized eigenspace decomposition|Required by B01v3; inspect separate addition with stabilization and correct topological direct sum|
|242-O03|Real-space spectrum interface only rotation example|If real operator spectra are used later, provide explicit complexification definition and boundedness; otherwise keep every general theorem explicitly complex|
|242-O04|Earlier inputs|Need final local complex-L2 bridge238, completed Banach adjoint239/234, closed-range236, full compact Fredholm241; this review does not assert those earlier texts already passed|
|242-O05|Source responsibility completeness|Brezis6,ConwayVII,Rudin4/10 finer unnamed source items remain B01 audit; every admitted item needs exact final landing, not just chapter number|

**Next unique action:** parent matches this exact input hash and retains accepted baseline; merge the separately authored additions then send final chapter hash for affected/new-section independent review and chapter integration. No full rerun of unchanged correct paragraphs is needed unless an addition changes their hypotheses. No source/PDF pair, compilation or page QA examined. No B05/B07 signature. Model/mode not independently verifiable in this task. No user decision requested.
