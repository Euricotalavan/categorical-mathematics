# V18 Chapter237 independent refinement — v1

Input `v18/records/b04/thickened/ch237.tex`, 47376 bytes, SHA-256 `daad689c6e9e59fefb305a2c42cbbde5d52c26a86e9a4a50618124e0e350f831`; expected daad689c6e9e59fefb305a2c42cbbde5d52c26a86e9a4a50618124e0e350f831 matched: True. The actual entire chapter was read in order; truncated tool output was supplemented with targeted reads before this decision. No historical thickening self-assessment was read. Scope: full fixed chapter and its local prerequisite order, with source links and original proofs checked.

**Decision: PASS after small source-coverage/definition patches in refined/ch237.tex.** This is content/refinement of the fixed chapter, not whole-volume B05/B07, source-exhaustiveness or PDF/engineering acceptance.

## Actual findings and changes

* Added the finite intersection property definition before its first use. Specified open neighborhoods in the ultrafilter proof; arbitrary neighborhoods follow by upward closure.
* Added the reverse weak-continuity implication for everywhere-defined linear maps on a Banach domain, with pointwise dual family and uniform boundedness proof (Brezis3.10).
* Added X* separable implies X separable, and the reflexive converse, with norming-vector/separating-functional arguments (Brezis3.26–3.27). Placed this after reflexivity is defined and proved to inherit, so it creates no first-definition inversion.
* Added an explicit weak-star-but-not-weak sequence in ell-infinity using the Hahn–Banach extension of the ordinary limit functional; no later Hilbert representation is used.
* Unified this chapter's annihilator in the finite-dimensional distance lemma as M-circ, matching accepted234 sample and avoiding Hilbert-perpendicular confusion. Mathematical meaning unchanged.

## Independent verification of difficult arguments

The Eberlein–Smulian proof is sound. The finite-dimensional distance lemma is obtained by extending the restriction in X** and using the finite-dimensional quotient of X*; it does not invoke arbitrary annihilator identifications. A hypothetical weak-star closure point outside the norm-closed canonical image has positive norm distance. The lemma gives bounded f_n annihilating prior chosen vectors while taking a uniformly positive real value on that closure point. Weak-star closure supplies the next triangular test row. A weak subsequence limit lies in the closed span of the x_j; f_n therefore tends to zero on it, contradicting the fixed positive lower bound. The reverse direction uses a countable separating family on the separable span of the sequence and compact-to-Hausdorff embedding, correctly extracting weak subsequences. No blanket compact implies sequential compact argument is used. Both source books state the hard equivalence without proof; this chapter provides an independent original proof, which has now been actually checked.

Milman–Pettis is sound. Its small slice has pairwise distance below epsilon by uniform convexity. Goldstine approximates the extra finite tests together with the slice test, retaining its strict inequality. The fixed-center epsilon ball in X** is weak-star closed; closure gives norm distance at most epsilon, then closed canonical image and arbitrary epsilon give surjectivity. The proof does not claim a norm-open set is weak-star closed.

The c0 initial-one sequence is weakly Cauchy by the locally proved ell1 representation of every c0 functional. Every subsequence retains coordinate limits1 outside c0, so it has no weakly convergent subsequence. The new ell-infinity example contrasts this with a weak-star limit that does belong to the ambient space, and exhibits the continuous functional obstructing weak convergence.

All remaining definitions/proofs/examples were also checked: finite tests/Hausdorff and scalar operations; weak boundedness including incomplete X dual-completeness argument; moving pairings; net/subnet construction and compactness equivalence; unbounded weak-null net; ultrafilter extension and product theorem; convex closure/Mazur; Alaoglu coordinate closedness; both metrizability converses; Goldstine finite-dimensional separation; reflexive quotient using r>1 representatives; dual inheritance and direct method including minus-infinite infimum contradiction; weak sequential completeness; Radon–Riesz; faces/Krein–Milman and c0 lack of extreme points; all five worked problem solutions.

## Source landings and handoff

`ch237-source-landings-v1.json` maps conceptual source responsibilities to exact labels and lines of this refined copy. One conclusion with several source links is one original theorem, not repeated source-by-source prose. The table is not a claim that every unnamed source assertion/exercise has already been audited. Source-scope residual items remain B01. No actual source PDF, restricted excerpt or source image is included in these outputs.

Next unique action: parent verifies the fixed input hash, applies the minimal patch or takes the refined file as the same accepted chapter, records the output hash, and uses these labels in B05. The whole-volume join with234 and later240 is still independently checked at B05; no need to re-run unchanged accepted proofs unless their inputs change. No build, PDF pair or full-page visual QA performed here. Model/mode not independently verifiable in this task. No user decision requested.
