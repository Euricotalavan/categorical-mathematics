# V18 B-02 narrative and dependency design — reconciled v2

Date: 2026-11-27 UTC. Author: expansion role in an isolated task. Status: **B-02 v2 incorporating the controller's explicit reconciliation instructions. The controller fixes the authoritative design and merges outputs; this document is not a B-01 source-coverage certificate or mathematical acceptance.**

## Revision v2 — controller-directed resolution

The controller delivered refinement's required scope on 2026-11-27. This version incorporates it: a local ultrafilter product-compactness proof in 237; a short complex L² bridge in 238 using verified real Lp completeness at V16 Ch218; Hilbert Riesz in 239; full Banach Fredholm/Atkinson/index stability in 241; normal continuous calculus in 243; Riesz–Markov/cyclic L²/PVM/Borel in 244; and complete Lp assumptions, translation, convolution, mollifiers and compactness in 245, with Radon–Nikodym imported from V16 Ch217. Exact source locations remain the independent refinement role's responsibility. The 234 B-03 fragment has separately been delivered for review and does not freeze this entire book.

## 1. Receipt, authority, and scope

Actually read: `V18-Literature-Readiness-v1.md`, navigation v2.1, A/B production rules v4, and B single-Work appendix v1. The input file hashes appear in `V18-B02-input-manifest.json`. Controller instructions supplying verified V16 Ch217/218 imports and the new scope were received by task message; those prior-volume texts have not independently been reread by this expansion task. The V18 card and adjacent V19 card of curriculum v4.1 were inspected. No other role's draft, self-assessment, or output was read or edited.

The main task assigns V18, English original exposition, B single Work, Chapters 232–245, near-reference-book depth, and preparation of B-02 and its controller-directed v2 reconciliation while independent source item checks continue. This record implements that instruction. The parent controls source admission, formal chapter baseline, the unique manuscript, and merging. I do not certify B-01, mathematical correctness, full coverage, or final acceptance.

The readiness record reports V17 ending at Chapter 231 at commit `c27f36064ae039a23e03a7093684bfbf789179ef`, `archive/v17/b08-audited-2026-11-27/README.md`. **That remote source has not been independently fetched in this task.** Chapters 232–245 are inherited planning inputs; the parent must confirm the published baseline before fixing B-02. A reference to a preceding volume does not authorize reusing or changing its frozen text.

Model requested for the expansion role by the project: GPT-6.1 Sol; actual selected model and inference setting/High status: **not independently verifiable here**. This sentence is a disclosure, not evidence of switching a model or mode.

## 2. The book's single route

The central question is: **When does a linear equation in an infinite-dimensional space have a solution, how stable is it, and how can the operator be understood?**

1. Chapters 232–233 establish objects on which limits and linear operations work. They distinguish completeness, boundedness, and compactness before any global existence theorem uses them.
2. Chapters 234–236 show how scalar observations and completeness control operators: Hahn–Banach, uniform boundedness, open mapping, and closed graph. Every theorem gets its exact completeness hypothesis and a failure example.
3. Chapter 237 introduces weak limits as a substitute for norm compactness, with genuine topology rather than a sequence-only definition.
4. Chapters 238–239 add Hilbert geometry and representation. Orthogonality turns geometric constraints into explicit dual formulas and adjoints.
5. Chapters 240–241 exploit compactness to make infinite-dimensional equations behave partly like finite-dimensional ones. The Fredholm alternative is established for `I-K` before general spectrum terminology is used.
6. Chapters 242–244 move from invertibility to spectrum, holomorphic calculus, and the spectral description of bounded self-adjoint operators. Compact eigenvector expansions are placed inside the larger continuous-spectrum picture.
7. Chapter 245 supplies the systematic Lp-space and approximation theory, then applies the complete route to concrete function spaces and equations. It performs the checks rather than merely naming applications.

Repeated models acquire one new role each time: sequences (`c00`, `c0`, `ell^p`), continuous functions, Lebesgue spaces, multiplication operators, shifts, diagonal compact operators, and integral operators. Later occurrences cite the earlier definition and identify the new conclusion; they do not recreate the same elementary example.

## 3. Scope and adjacent-volume interface

| Interface | What V18 must supply or recall explicitly | What is kept outside V18 |
|---|---|---|
| Linear algebra and metric topology | Scalar field, quotient vector space, completion prerequisites, finite-dimensional linear algebra, compact metric sets, Cauchy and completeness; local bridges when the fixed prior text has not been checked | Rewriting prior linear algebra or topology volumes |
| V16/V17 and prior measure/complex analysis | Controller/refinement verified Radon–Nikodym at V16 Ch217 and real Lp Banach at Ch218. State the imported versions; provide the short complex L² bridge in 238 and systematic complex Lp construction/duals in 245. Other topology, scalar Cauchy and approximation imports require exact accessible locations or local proofs | Assuming the V17 title or an 'already covered' label proves any particular theorem is available |
| V19 locally convex spaces | V18 defines weak and weak-star topology concretely on normed spaces, including finite-test neighborhoods, nets, compactness, and the topology actually needed for Alaoglu and reflexivity, including a local ultrafilter proof of product compactness with the choice input explicitly stated | General locally convex theory, arbitrary families of seminorms as a separate theory, barrelled/bornological/nuclear spaces, strong dual topologies |
| V19 distributions | V18 may use an elementary weak derivative in a worked function-space model only if defined locally and required by the admitted scope | Test-function topologies, distribution theory and derivatives, kernel theorem, general distributional PDE |
| V19 integral equations | V18 proves abstract Fredholm alternatives and gives one or two bounded compact-kernel examples with explicit compactness and solvability checks | A systematic course on Fredholm/Volterra integral equations, singular integral equations, detailed numerical quadrature |
| Later unbounded operator theory | A closed unbounded derivative is a counterexample showing the domain hypothesis of closed graph | Unbounded spectral theorem, self-adjoint extensions, Stone's theorem, semigroups as a full theory |

These are proposed boundaries. The B-01 exclusions and cross-source differences must be reconciled before they become fixed. An omitted source item needs an explicit destination and reason, not a silent exclusion.

## 4. Shared decisions to fix before concurrent drafting

* Scalars are `F=R` or `C` through Chapter 241 unless explicitly specialized. General spectral theory from Chapter 242 uses complex Banach spaces. Real operators require an explicitly defined complexification before a complex spectrum is mentioned.
* Inner products are **linear in the first variable**. Duals are written `X^*` and consist of continuous linear scalar-valued maps. In the Hilbert representation `f(x)=<x,y>`, the map `y -> f_y` is conjugate-linear over `C`; do not label it a linear isomorphism. The parent fixed this convention by task message on 2026-11-27.
* Distinguish the Banach transpose `T':Y^* -> X^*`, `T'f=f o T`, from the Hilbert adjoint `T*:K -> H`, characterized by `<Tx,y>=<x,T*y>`. Annihilators, orthogonal complements, and closure are not interchangeable symbols.
* The quotient `X/M` has the quotient **norm only for closed M**; before that the same formula is a seminorm. Prove representative independence and definiteness where introduced.
* `L^p` consists of almost-everywhere equivalence classes. Integral and multiplication formulas require representative independence. `C(K)` uses pointwise equality. Neither equality convention is left implicit.
* A compact operator maps the closed unit ball to a relatively norm compact set. 'Maps bounded sets to bounded sets' is insufficient. Finite rank implies compact, but approximation of every compact Banach-space operator by finite-rank operators is **not** asserted.
* Weak topology is defined by all continuous functionals, with finite-test neighborhoods and nets. Sequences are introduced as a useful test with explicit limitations. Weak-star compactness is not silently replaced with sequential compactness.
* Banach-algebra spectra in Chapter 242 belong to the specified unital algebra. Operator spectra belong to `B(X)`; no unproved spectral permanence for subalgebras is assumed.
* Norm convergence, strong operator convergence, weak operator convergence, and convergence of spectral integrals are named at their first use. 'Converges' alone is prohibited where these alternatives matter.

## 5. Chapter-level plan and complete local routes

The page ranges below are capacity estimates for R1 text with proofs and worked examples, **not quotas, acceptance criteria, or grounds to cut material**. Source responsibility IDs and precise book theorem numbers remain pending B-01. The source columns give orientation only, based on the readiness input.

### Chapter 232 — Normed and Banach Spaces (about 22–30 pages)

**Question:** Which spaces retain limits of approximations? **Prerequisites:** vector spaces, metric Cauchy sequences, real/complex completeness, elementary sums and integrals for the relevant examples.

1. `232.1 Norms, metrics, and topology.` Norm axioms, induced metric, open/closed balls, continuity of vector operations, reverse triangle inequality; equivalent norms and the exact topology/completeness consequences. Show norm calculations rather than quote them.
2. `232.2 Complete spaces and closed subspaces.` Banach definition; a subspace of a Banach space is Banach iff closed. Absolute-series criterion for completeness, proved in both directions. Completion by Cauchy sequences: equivalence relation, vector operations, norm, isometric dense embedding, universal uniqueness.
3. `232.3 Product and quotient constructions.` Finite direct products with max/sum norms; quotient by a closed linear subspace; quotient map, representative independence, norm definiteness, quotient completeness via a summably corrected representative sequence. This proof must not invoke open mapping from Chapter 236.
4. `232.4 Function and sequence models.` `c00`, `c0`, `ell^p`, `ell^infinity`, and `C(K)`; verify completeness for `c0`, `ell^p`, and `C(K)`. Explain why `c00` with the inherited `ell^p` norm is incomplete. In accordance with the parent's fixed boundary, `L^p` construction and completeness belong to 245 and are not assumed here or used as an earlier proof prerequisite.
5. `232.5 Finite dimension is exceptional.` Equivalence of finite-dimensional norms, closedness of finite-dimensional subspaces, compactness of their closed bounded sets. Riesz lemma with its strict approximation constant; an infinite-dimensional normed unit ball is not compact.

**Mandatory worked examples:** Cauchy truncations escaping `c00`; a quotient-distance calculation; inequivalent function norms demonstrated without assuming Lebesgue-space completeness; Riesz-lemma construction of separated unit vectors. **Proof obligations:** completion and quotient completeness are not one-line claims. **Feeds:** every subsequent chapter, especially 233, 235–236, 240. **Source orientation:** Conway III, Rudin 1–2.

### Chapter 233 — Bounded Linear Maps (about 20–28 pages)

**Question:** Which linear maps respect limiting operations? **Prerequisites:** 232.

1. `233.1 Boundedness and continuity.` Linear maps, kernel/range, continuity at zero versus everywhere, equivalence with a global norm bound, operator norm and its infimum/supremum descriptions; discontinuous linear functionals require an explicit algebraic construction if used.
2. `233.2 Spaces of operators.` `B(X,Y)`, vector space and norm, completeness when `Y` is Banach even if `X` is not; composition and submultiplicativity. Extension from a dense subspace to a Banach target, with independence of the approximating sequence and uniqueness.
3. `233.3 Invertibility and quantitative perturbation.` Banach algebra `B(X)`, identity, convergent Neumann series, left and right inverse computation, open group of invertibles, inverse norm bounds and continuity. No spectral terminology is necessary yet.
4. `233.4 Modes of operator convergence.` Operator-norm and pointwise/strong convergence, norm implies strong, failure of the converse, why pointwise limits may need Chapter 235 for boundedness. Weak operator convergence is deferred until Hilbert duality is available or defined through scalar functionals explicitly.
5. `233.5 Concrete operator calculations.` Multiplication, shifts, inclusion maps, evaluation on `C(K)`, and an integral map under stated kernel hypotheses; compute exact norms where instructive, prove all bound estimates used later.

**Mandatory worked examples:** unilateral shift, coordinate truncation converging strongly but not in norm, diagonal operator with a nonclosed range, differentiation on `C^1` under competing domain norms. **Feeds:** 234 transpose, 235–236, 240, 242. **Source orientation:** Conway II–III/VI, Rudin 1.

### Chapter 234 — Duality and Hahn–Banach (about 30–40 pages)

**Question:** Can scalar observations detect all vectors and constraints? **Prerequisites:** 232–233, order/Zorn lemma with an explicit statement of its use.

1. `234.1 Dual spaces and elementary identifications.` Continuous dual and dual norm, dual completeness; `ell^1` dual `ell^infinity`, `c0` dual `ell^1`, finite-dimensional duals. Do not identify `(ell^infinity)'` with `ell^1`.
2. `234.2 Analytic Hahn–Banach.` Real sublinear domination, one-dimensional extension, maximal extension via Zorn; complex extension by real parts with an explicit reconstruction and norm calculation. State separately the dominated and norm-preserving versions.
3. `234.3 Norming and distance.` Norming functional, norm recovery as a dual supremum, extension from a subspace, `dist(x,M)` as a supremum over annihilating functionals, including `x in closure M` and nonclosed `M`. Derive canonical isometry into the bidual without prematurely defining reflexivity.
4. `234.4 Geometric separation.` Minkowski functional for an open convex neighborhood, continuity and domination; separation of a point and an open convex set, closed convex separation, and strong separation with the actual hypotheses. Explain complex spaces through real parts of linear functionals.
5. `234.5 Transposes and annihilators.` Banach transpose, equality of transpose/operator norms, annihilator/preannihilator relations, `closure(range T)` detected by `ker T'`, quotient/subspace dual identifications with all restriction and quotient maps well-defined.

**Mandatory worked examples:** annihilator of a finite constraint, best scalar observation of a quotient distance, failed strict separation when distance is zero, `c0` and `ell^infinity` dual distinctions. **Feeds:** 237, 239, 241. **Source orientation:** Brezis 1, Conway III, Rudin 3–4.

### Chapter 235 — The Uniform Boundedness Principle (about 18–26 pages)

**Question:** When do pointwise bounds force one common operator bound? **Prerequisites:** 232–234; Baire is proved here unless an exact usable prior theorem is verified.

1. `235.1 Baire's theorem.` Nested-ball proof for complete metric spaces; category terminology only as needed; a nonempty complete metric space is not a countable union of closed sets with empty interior.
2. `235.2 Uniform boundedness.` Family in `B(X,Y)`, `X` Banach, pointwise boundedness; closed level sets, an interior ball, subtraction and scaling to a uniform norm bound. `Y` need not be Banach.
3. `235.3 Pointwise limits and double estimates.` Boundedness of a pointwise limit, extension of convergence from a dense set under a uniform bound, comparison of strong/norm limits; precise roles of completeness and density.
4. `235.4 Weak boundedness is norm boundedness.` Apply uniform boundedness to canonical evaluations on the Banach dual; no reflexivity assumption and no circular use of 237. A weakly convergent sequence is norm bounded once weak convergence is defined in 237.
5. `235.5 Failure and applications.` Explicit incomplete-domain counterexample on `c00` to uniform boundedness; a family of coordinate multipliers and an approximation/convergence application with quantified estimates.

**Mandatory worked examples:** `T_n x=n x_n` on finitely supported sequences with the sup norm; norm-bounded operators converging on a dense subspace; functional series or partial-sum behavior only with its extra prerequisites proved. **Feeds:** 236–237, weak operator limits, 244. **Source orientation:** Brezis 2, Conway III, Rudin 2.

### Chapter 236 — Open Mapping and Closed Graph (about 22–30 pages)

**Question:** When is a solution operator automatically continuous? **Prerequisites:** 232–235.

1. `236.1 Open mapping.` Bounded surjection between Banach spaces; Baire gives a ball in closure of an image; iterative correction turns approximate preimages into a convergent exact preimage. This second step is mandatory.
2. `236.2 Bounded inverse and stability.` Bounded inverse theorem, equivalent complete norms, quotient maps, quantitative preimage estimate with its noncanonical choice, and induced bijection `X/ker T -> range T` when the range is closed. Prove the precise equivalence: for bounded `T:X -> Y` between Banach spaces, `range T` is closed iff there is `C>0` with `dist(x,ker T)<=C||Tx||` for every `x in X`; prove both directions through the complete quotient. This is the stable input required by 241.
3. `236.3 Closed graph.` Graph as a closed subspace of a Banach product, projection and bounded inverse, closed graph theorem; the graph need not be checked by sequences unless metrizability is explicitly in force.
4. `236.4 Closed operators and graph norms.` Graph norm completeness for closed operators on their domains, distinction between everywhere-defined and proper-domain operators, a derivative with closed graph that is unbounded under the ambient norm.
5. `236.5 What fails when hypotheses fail.` Incomplete norm on a domain or target; continuous injective map with nonclosed range and unbounded inverse on that range; discontinuous bijection between a space with two non-equivalent norms when one is incomplete.

**Mandatory worked examples:** inverse estimate for a multiplication/diagonal model, `C^1[0,1] -> C[0,1]` derivative and graph norm, the inverse of a compact diagonal inclusion on its range. **Feeds:** 237 closed-range arguments, 239 Lax–Milgram, 241, 242. **Source orientation:** Brezis 2, Conway III, Rudin 2.

### Chapter 237 — Weak Topologies and Reflexivity (about 40–54 pages)

**Question:** How can bounded families have usable limits without norm compactness? **Prerequisites:** 232–236, a locally supplied topology bridge for nets/products/compactness if the previous volume's exact statements are not checked.

1. `237.1 Weak and weak-star topologies.` Initial topology, finite-test neighborhoods, convergence of nets and sequences, separation/Hausdorff property, comparison with the norm topology, uniqueness and boundedness statements with their correct scopes. A convergent arbitrary net need not have a globally bounded range; sequence boundedness cannot be copied blindly to nets.
2. `237.2 Convex sets and Mazur's theorem.` Norm-closed convex sets are weakly closed via 234 separation; weakly convergent sequences admit norm-convergent convex combinations of tails, with a complete separation proof.
3. `237.3 Compact products and Alaoglu.` Define filters, ultrafilters, and convergence. State the ultrafilter extension lemma and derive it from Zorn (choice input); prove the finite-intersection and ultrafilter characterizations of compactness, then prove arbitrary products of compact spaces compact by projecting an ultrafilter, choosing coordinate limits, and checking a finite-coordinate neighborhood. Embed the dual unit ball in a product of compact scalar disks, prove its image closed by preservation of linearity and bounds, and identify the product-induced topology with weak-star topology. No unproved Tychonoff import is allowed. On a separable predual, supply an explicit dense-test metric and prove it induces weak-star topology on bounded dual sets. Avoid a false metrizability claim for the whole dual.
4. `237.4 Bidual and Goldstine.` Canonical isometric embedding, finite-dimensional separation proof of weak-star density of the unit ball image, precise topology and ball radius.
5. `237.5 Reflexivity.` Surjectivity definition; reflexive iff closed unit ball weakly compact, proof of both directions; closed subspaces and appropriate quotient/dual consequences, without hidden compactness claims.
6. `237.6 Sequential compactness and minimization.` Decide from B-01 whether Eberlein–Smulian is an admitted full theorem. If admitted, reserve a separate complete proof section; if not, make only sequential compactness deductions actually supplied by separability/metrizability or a locally proved reflexive sequence argument. Prove weak lower semicontinuity of the norm and attainment for a coercive weakly lower semicontinuous functional on an appropriate reflexive closed convex set.
7. `237.7 Distinguishing examples.` Standard unit vectors in `ell^p` for `1<p<infinity`, `ell^1` and the Schur phenomenon with proof if used, weak-star coordinate convergence on the `ell^infinity` ball, nonreflexivity of `c0`/`ell^1`, and weak-versus-norm closed nonconvex sets.

**Critical choice:** Eberlein–Smulian must not be silently asserted to replace a proof or to equate all weak compactness with sequence compactness. **Feeds:** 238 minimization, 240 compact mapping of weak limits, 245 variational existence. **Source orientation:** Brezis 3, Conway V, Rudin 3–4.

### Chapter 238 — Hilbert Spaces and Projection (about 24–32 pages)

**Question:** What extra structure turns approximation into orthogonal geometry? **Prerequisites:** 232–233, optionally 237 for comparisons, with core proofs independent of weak compactness.

1. `238.1 Inner products and completion.` Convention, Cauchy–Schwarz including equality, triangle inequality, parallelogram and polarization; Hilbert definition and main models. Before using complex L², state the verified real Lp completeness input at V16 Ch218 and prove a short local bridge: real and imaginary parts of a complex L² Cauchy sequence converge in real L², their sum gives a complex limit by the pointwise modulus inequalities; define the a.e. quotient and integral inner product and check representation independence/definiteness. This bridge does not move the complete Lp treatment out of 245.
2. `238.2 Projection onto closed convex sets.` Existence by a parallelogram Cauchy argument, uniqueness by strict convexity, variational characterization using real parts. Nonexpansiveness and the special linear case are proved rather than transferred from all convex sets.
3. `238.3 Closed subspaces and orthogonality.` Orthogonal decomposition, projection linearity/boundedness, `M double-perp = closure M`, distances and least squares. Nonclosed subspaces need a closure.
4. `238.4 Orthonormal systems and bases.` Bessel, finite partial sums, convergence of Fourier expansions, Parseval, maximal complete systems. Define sums over arbitrary index sets or explicitly limit the first theorem to separable spaces; separability does not hold for every Hilbert space.
5. `238.5 Approximation models.` Least squares, finite-dimensional normal equations, projection of a sequence/function onto a specified subspace, completeness tests for an orthonormal family.

**Mandatory worked examples:** projection onto a closed hyperplane; an unattained distance to a nonclosed subspace; Fourier coefficients with a checked completeness hypothesis; nonseparable `ell^2(I)`. **Feeds:** 239–241 and 244. **Source orientation:** Brezis 5, Conway I.

### Chapter 239 — Riesz Representation (about 25–35 pages)

**Question:** How do linear observations become vectors and forms become operators? **Prerequisites:** 233–234, 236, 238.

1. `239.1 Hilbert dual representation.` Zero functional separately, kernel projection argument, unique representing vector, norm equality, conjugate-linearity convention, reflexivity of Hilbert spaces and comparison with 237.
2. `239.2 Bounded sesquilinear forms.` Form norm, representation by a unique bounded operator, exact variable conventions, symmetry and coercivity. No pointwise equality is confused with equality almost everywhere.
3. `239.3 Hilbert adjoint.` Existence, uniqueness, algebraic identities, norm equality, `T*T` norm identity, kernel/range orthogonality, normal/self-adjoint/unitary/positive definitions to support later chapters.
4. `239.4 Lax–Milgram.` Bounded coercive sesquilinear forms on a Hilbert space, full proof through the representing operator: lower bound gives injectivity and closed range; apply coercivity to the adjoint kernel or orthogonality to obtain surjectivity. State complex coercivity with `Re a(x,x)` and prove the adjoint step under the chosen convention.
5. `239.5 Recognition and calculation.` Finite matrices, multiplication, unilateral shift adjoint, a weak variational problem with all domain and boundedness/coercivity checks.

**Mandatory distinction:** Hilbert Riesz representation versus Riesz–Markov representation of functionals on `C(K)`; both names may occur but have different domains and conclusions. **Feeds:** 240–241, 244–245. **Source orientation:** Brezis 5, Conway I and bounded-operator chapters.

### Chapter 240 — Compact Operators (about 30–40 pages)

**Question:** Which operators restore compactness lost in infinite dimension? **Prerequisites:** 232–233, 236; Hilbert-specific part uses 238–239.

1. `240.1 Definition and criteria.` Relative norm compactness, bounded-sequence subsequences in metric targets, finite epsilon-net criterion; compact implies bounded for linear operators, finite-rank operators compact.
2. `240.2 Permanence and limits.` Sums/compositions with bounded maps, closedness in operator norm into a Banach target, failure for strong limits, identity compact iff finite dimension.
3. `240.3 Duality and weak limits.` Schauder theorem `T` compact iff `T'` compact with a complete proof; compact operators take weakly convergent sequences to norm-convergent images, and the exact limitations of the converse characterization.
4. `240.4 Hilbert approximation and singular values.` Finite-rank approximation of compact Hilbert-space operators via finite-dimensional projections, compact adjoint; do not generalize the approximation argument to all Banach spaces. Singular-value decomposition is deferred until 244 supplies the compact self-adjoint theorem, with an explicit forward destination rather than circular use.
5. `240.5 Concrete compactness.` Diagonal `ell^2` operators iff entries tend to zero, continuous-kernel integral operators by finite-rank uniform kernel approximation or a proved Arzelà–Ascoli route, Hilbert–Schmidt kernels by an `L^2` approximation proof. Multiplication on a nonatomic `L^2` space provides a noncompact contrast.

**No premature spectrum:** use 'eigenvalue' in its algebraic sense if needed; general spectral assertions wait until 242. **Feeds:** 241, compact spectrum in 242, 244 and 245. **Source orientation:** Brezis 6, Conway II/VI, Rudin 4.

### Chapter 241 — Fredholm Solvability (about 40–54 pages)

**Question:** When does an equation have only finitely many obstructions? **Prerequisites:** 232–236, 238–240. Work with `I-K` first; complex spectral language is unnecessary.

1. `241.1 Finite-dimensional obstructions.` Kernel and cokernel, closed range, Fredholm definition and index; quotient dimension and the bounded inverse estimate on a quotient or a chosen complement.
2. `241.2 The compact alternative.` Finite-dimensional kernel of `I-K`; range closed by quotient-distance/Riesz argument; ascending kernels and descending ranges stabilize as needed; injective iff surjective, with the full contradiction argument.
3. `241.3 Transpose and compatibility.` Range annihilator, finite codimension, dual compatibility conditions, equality of nullity and deficiency for `I-K`; make the closed-range step explicit before replacing closure of range by range.
4. `241.4 Hilbert Fredholm alternative.` `range(I-K) = ker(I-K*)^perp`; solution set, nonuniqueness, estimate on the kernel complement, perturbations and well-posedness for compatible right sides.
5. `241.5 Finite-rank and integral equations.` Solve a finite-rank model by a finite matrix, exhibit compatible/incompatible data and a nonunique solution; one continuous-kernel equation with compactness traced to 240.
6. `241.6 General Banach Fredholm theory and Atkinson.` For bounded `T:X -> Y` between Banach spaces, define Fredholm by finite-dimensional kernel, closed range and finite-dimensional cokernel; define index as nullity minus deficiency. Prove bounded finite-dimensional complements using coordinate functionals/Hahn–Banach. Prove Atkinson in its rectangular parametrix form: `T` is Fredholm iff some bounded `S:Y -> X` has `ST-I_X` and `TS-I_Y` compact. Forward: construct S on complements; reverse: compactness yields finite kernel/cokernel and a quotient-distance proof of closed range, avoiding an unjustified inference from algebra alone. For X=Y identify the equivalent invertibility of the coset in the Calkin algebra; first verify the compact ideal is closed and its quotient algebra complete.
7. `241.7 Index stability.` Prove local constancy under sufficiently small operator-norm perturbations through the block decomposition `X=ker T + X0`, `Y=range T + Y1`, an invertible large block, and finite-dimensional Schur complement; count both finite-dimensional kernel and cokernel of the remaining block so index stays fixed. Use Atkinson to keep compact perturbations Fredholm and local constancy along `T+tK` to prove compact-perturbation invariance. Record any extra index-additivity source obligation explicitly; never infer constancy just from unchanged nullity. Include a finite-rank perturbation and unilateral shift index model.

**Feeds:** nonzero compact spectral points in 242 and operator equations in 245. **Source orientation:** Brezis 6, Conway XI.

### Chapter 242 — Spectra of Bounded Operators (about 30–42 pages)

**Question:** Which scalars obstruct inversion? **Prerequisites:** 233, 236, 241 for compact specialization, scalar complex analysis through a checked bridge.

1. `242.1 Complex Banach algebras and spectrum.` Unital algebra, invertibility, spectrum/resolvent set, definition of spectral radius. Distinguish the zero-dimensional space convention if used.
2. `242.2 Resolvent analyticity and spectral nonemptiness.` Neumann expansion outside the norm ball, local resolvent series and resolvent identity, boundedness on compact resolvent subsets. Nonempty compact spectrum via scalarized Liouville with norming functionals and an explicit vanishing-at-infinity argument.
3. `242.3 Spectral radius formula.` Submultiplicative limit and infimum, first radius inequality, reverse inequality using scalar/Bochner contour integration and Cauchy estimates. Supply a minimal Banach-valued integral construction locally before this proof; 243 later develops the full calculus.
4. `242.4 Types of spectral behavior.` Point, continuous, residual spectra with a declared convention that partitions the spectrum; approximate eigenvectors, bounded-below criterion and range information. Explain where conventions differ across sources.
5. `242.5 Compact operator spectrum.` Nonzero spectral points are eigenvalues, finite-dimensional eigenspaces, isolation and possible accumulation only at zero, using 241. State and prove the stronger finite algebraic multiplicity/generalized eigenspace conclusion if admitted, with stabilized kernels.
6. `242.6 Worked spectra.` Diagonal compact operator, multiplication operator and essential range, unilateral shift and its adjoint with point/continuous/residual classification under the fixed convention, finite-dimensional comparison.

**Feeds:** 243–244. **Source orientation:** Conway VII, Rudin 10.

### Chapter 243 — Resolvents and Functional Calculus (about 50–68 pages)

**Question:** How can functions of an operator be defined without an eigenbasis? **Prerequisites:** 242, scalar complex Cauchy theory and contour topology in their exact needed versions.

1. `243.1 Banach-valued analytic tools.` Norm integral of continuous functions on rectifiable piecewise smooth curves, estimates, linearity, differentiation and scalarization; Cauchy theorem/formula in this setting with proofs from checked scalar statements.
2. `243.2 Resolvent identities and contour choices.` First/second identities as needed, resolvent expansion, contour orientation and admissible finite contours around the spectrum; independence under changes of contour and changes of the holomorphic neighborhood.
3. `243.3 Holomorphic functional calculus.` `f(T)` by contour integral, constants, identity function, polynomials and rational functions with poles off the spectrum; linearity, multiplicativity by nested contours and resolvent identity, norm estimates and continuity in the appropriate function topology.
4. `243.4 Spectral mapping and composition.` Holomorphic spectral mapping with factorization on a neighborhood and invertibility arguments; composition theorem only after proving its domain conditions. Disconnected spectral neighborhoods and locally constant functions are handled explicitly.
5. `243.5 Riesz projections.` Projection for an isolated spectral component, commutation, closed invariant range/kernel, direct sum, spectra of restrictions. A spectral projection need not be orthogonal for a general operator.
6. `243.6 Functions and perturbations.` Operator exponential, analytic square root under an explicit admissible branch, resolvent perturbation and contour estimates, a Jordan-block calculation showing derivatives enter `f(T)`. No logarithm is asserted without branch conditions.
7. `243.7 Normal continuous functional calculus` (fixed label `sec:243-continuous-calculus`). For a bounded normal N on a nonzero complex Hilbert space, construct an isometric unital star homomorphism `C(sigma(N)) -> B(H)` carrying the coordinate function to N. Supply the exact noncircular route: build the commutative C*-algebra generated by I,N,N*, prove its needed character/maximal-ideal facts using the Banach-algebra theory already proved, establish spectral permanence for this algebra, identify its character space with sigma(N), derive polynomial norm equality, and extend from polynomials in z and conjugate-z by the complex Stone–Weierstrass theorem with a locally proved or verified exact prerequisite. Prove positivity, uniqueness, continuous spectral mapping and agreement with the holomorphic calculus. This section is before, and independent of, 244's spectral measure theorem. In particular it may not use PVM or Borel calculus to prove its norm identity. The controller reports a separate representative draft already delivered for this section; that draft is not read or edited by this task.

**Feeds:** 244 scalar measures and spectral representation, and 245. **Source orientation:** Conway VII–IX, Rudin 10–12; source differences in calculus scope must be reconciled by B-01.

### Chapter 244 — Bounded Self-Adjoint Operators (about 44–62 pages)

**Question:** What replaces diagonalization when the spectrum is continuous? **Prerequisites:** 238–243, especially the independently established normal continuous functional calculus `sec:243-continuous-calculus`. Scalar measure representation is built here, not in the Hilbert Riesz chapter.

1. `244.1 Order and spectral geometry.` Reality of quadratic forms and real spectrum, numerical radius equality, `||A|| = r(A)` for self-adjoint `A`, positivity and spectral positivity, lower bounds and invertibility. Prove the norm identities before using them to construct a calculus.
2. `244.2 Compact self-adjoint theorem.` Extremal quadratic-form/eigenvector argument, invariant orthogonal complements, countable nonzero spectrum with finite multiplicities, orthonormal eigenvectors spanning the closure of the range, kernel included, norm-convergent finite spectral sums with quantified tail norm. Treat real Hilbert spaces directly here if required.
3. `244.3 Riesz–Markov bridge.` State and prove the needed compact-metric positive-functional representation theorem, or explicitly reconstruct the proof from verified preceding measure results: for a positive linear functional on `C(K)`, construct its unique finite regular positive Borel measure and integral equality, verify boundedness and regularity. Keep this separate from Hilbert Riesz (239). Apply it to `f -> <f(A)v,v>` using the positivity supplied by 243; polarized measures use the first-slot-linear convention.
4. `244.4 Cyclic L² representation and spectral measures.` On a cyclic subspace generated by v, identify `f(A)v` with f in `L²(mu_v)`, prove the norm equality and density of continuous functions in this L² space, extend to a unitary, and show A becomes coordinate multiplication. Decompose H into orthogonal reducing cyclic subspaces using Zorn with its choice input stated, and assemble multiplication by characteristic functions to obtain a projection-valued measure. Prove strong countable additivity, the integral representation of A, and uniqueness. Do not simply postulate a passage from continuous functions to characteristic functions; derive it in the cyclic model. A normal-operator variant may be recorded with the same machinery if its exact responsibility is admitted, without replacing the self-adjoint chapter route.
5. `244.5 Bounded Borel calculus and spectral consequences.` Define bounded measurable functions up to the spectral measure's null ideal, integral estimates, multiplicativity via simple functions/limits, spectral projections and limits, eigenvalues as atomic projections; convergence topology explicit.
6. `244.6 Square roots, polar decomposition, singular values.` Positive square root and uniqueness, `|T|`, partial isometry with specified initial/final spaces, compact singular-value expansion from 244.2, best finite-rank error where admitted. This closes the explicit deferral from 240.
7. `244.7 Continuous and discrete models.` Multiplication by `t` on `L^2[0,1]` has spectrum `[0,1]` without eigenvectors; diagonal compact comparison; compute a projection `E(B)` and `f(A)`; distinguish spectral measure from a scalar probability distribution.

**Scope guard:** bounded normal operator extensions only if B-01 includes them; unbounded spectral theory excluded. **Source orientation:** Conway IX, Rudin 12, Brezis 6 for compact self-adjoint case.

### Chapter 245 — Applications to Typical Function Spaces (about 46–64 pages)

**Question:** Can the reader independently check and use the abstract machinery? **Prerequisites:** the appropriate earlier chapters, measure and elementary integration results explicitly fixed.

1. `245.1 Lp construction, measure hypotheses, and completeness.` Specify the measure space, a.e. equivalence, operations, norms and essential supremum. Give the complex construction, Hölder/Minkowski and completeness with the controller-verified V16 Ch218 real Banach theorem stated precisely and the complex passage proved. Distinguish arbitrary, finite, sigma-finite and locally finite regular measures at each theorem, not as a blanket hidden assumption.
2. `245.2 Concrete duals and reflexivity.` Prove `L^p` duality for `1<p<infinity` under its actual measure hypotheses, using the Radon–Nikodym theorem verified by refinement at V16 Ch217, with finite/local exhaustion and gluing steps stated where needed. Treat `L^1` dual under a declared sufficient measure hypothesis, avoid unrestricted claims on arbitrary measure spaces, and give the `L^infinity` warning; include norm attainment/nonattainment models. Every identification includes construction, surjectivity, and norm equality rather than just a formula.
3. `245.3 Translation, convolution, mollifiers, and compactness.` Work on R^d with Lebesgue measure where appropriate. Prove strong continuity of translations in Lp for p<infinity through dense simple/continuous approximants, contrast L-infinity failure; define convolution, justify a.e. existence and Fubini/Tonelli uses, prove the required Young estimate and approximate identity convergence. Define standard mollifiers and derive smoothness/derivative identities under exact hypotheses. Supply the relevant compactness criterion for bounded function families (for example Kolmogorov–Riesz with uniform translation control and tight tails) with a full local proof if used, and distinguish local from global compactness. These are formal responsibilities, not optional names in an application list.
4. `245.4 Minimization and variational equations.` Direct-method theorem in a reflexive space with all coercivity/closedness/lower-semicontinuity checks, a constrained norm minimization example, and a full Lax–Milgram example on an explicitly defined Hilbert function space. If a Sobolev model is included, define the weak derivative and prove the limited completeness/density/inequality facts it uses; broader Sobolev/PDE theory stays outside.
5. `245.5 Compact kernels and solvability.` Finite-rank approximation or Hilbert–Schmidt estimate, adjoint kernel, homogeneous solutions and compatibility conditions. Select a concrete kernel whose solution can be computed or reduced to an explicit finite matrix and checked by substitution.
6. `245.6 Approximation and Galerkin.` Orthogonal projections, stability and convergence, Céa estimate under stated coercive form assumptions, exact versus approximate solution; identify where an unproved density assumption would invalidate convergence.
7. `245.7 Spectral calculations in function spaces.` Multiplication, a compact Green-type integral model when its kernel and boundary interpretation are derived, resolvent and `f(A)` calculations; stable and unstable inverse problems distinguished through estimates.
8. `245.8 A connected final investigation.` One model carried from defining its function space through boundedness, compactness, adjoint, solvability, spectral expansion, and truncation error. Include an explicit audit of every hypothesis and one nearby model for which the argument fails.

**No content dumping:** this chapter supplies new applications, not delayed prerequisites required by 232–244. `L^p` construction and completeness are placed here; earlier examples may mention a measurable formula only with the local space and facts explicitly supplied, and cannot use unproved `L^p` completeness. **Source orientation:** Brezis 4–6, Conway III/Appendix B, Rudin 5 relevant examples.

## 6. Dependency graph expressed as a dispatch table

| Unit | Fixed inputs needed before writing its proofs | Required output used downstream |
|---|---|---|
| 232 | Verified linear algebra/metric/measure bridge | Complete quotient, completion, Riesz lemma, function-space baseline |
| 233 | 232 | Operator norm, dense extension, Neumann inverse |
| 234 | 232–233, Zorn statement | Separation, norm recovery, transposes/annihilators |
| 235 | 232–234 | Baire, uniform boundedness, dual boundedness test |
| 236 | 232–235 | Open mapping including exact correction, graph norm, closed-range inverse estimate |
| 237 | 234–236; explicit choice/Zorn | Ultrafilters/product compactness, weak/weak-star convergence, Alaoglu, Goldstine, reflexivity, actual sequential theorems admitted |
| 238 | 232–233; fixed convention; verified V16 Ch218 real Lp Banach | Complex L² bridge, projection and orthogonal expansions; geometric core independent of 237 |
| 239 | 234,236,238 | Hilbert representation, adjoint, Lax–Milgram |
| 240 | 233,236,238–239; 237 for weak-limit claims | Compact criteria, Schauder, concrete kernels |
| 241 | 234,236,239–240; quotient algebra tools | Banach Fredholm/Atkinson/index stability, compact alternative and adjoint compatibility |
| 242 | 233,236,241, scalar analytic bridge | Spectrum, radius, compact spectrum, minimal contour integration |
| 243 | 242 plus full analytic/C*-algebra/approximation bridges | Holomorphic and normal continuous calculus, spectral mapping, Riesz projections |
| 244 | 238–243 normal continuous calculus | Riesz–Markov bridge, cyclic L² model, bounded self-adjoint spectral theorem, PVM, Borel calculus |
| 245 | Selected 237–244; V16 Ch217 RN and Ch218 real Lp | Complete Lp/duality assumptions, translation/convolution/mollifiers/compactness, worked spectral-solvability synthesis |

Independent writing can be dispatched only after notation and the named input statements are fixed. In particular 238 may be drafted while 237 is reviewed; 244 cannot independently invent a conflicting calculus convention. All references must target stable labels, not guessed theorem numbers.

## 7. Two proposed B-03 calibration units

### Candidate F — foundational: `234.3 Norming functionals and quotient distance`

**Recommended first sample.** It tests definitions, quotient representatives, nonattainment, real/complex conventions, exact quantifiers, and a short proof whose missing steps are easy to hide.

**Fixed sample inputs:** completed 232 quotient-norm proposition and closed-subspace completeness, 234.1 dual norm, and 234.2 Hahn–Banach. If these are not yet drafted, include their exact theorem statements as clearly marked input cards; do not pretend the sample proves all its prerequisites.

**Complete sample content:**

1. Define `M^perp` as the annihilator in `X'` with a notation distinct from Hilbert orthogonality.
2. Establish `dist(x,M)=dist(x,closure M)` and handle distance zero separately.
3. Define a functional on `span{x+closure M}` in the quotient; verify its definition and norm, extend by Hahn–Banach, compose with the quotient map.
4. Prove the exact formula `dist(x,M)=sup{|f(x)|: f in X', ||f||<=1, f|M=0}` and explain the maximizing functional for positive distance.
5. Derive separation of a point from a closed subspace and the canonical norm formula for `X -> X''`.
6. Work a finite-codimension constraint and a `c00`-inside-`ell^2` example showing why closure matters; include a nearby invalid inference about attaining a nearest vector.

**Expected capacity:** 7–11 R1 pages with two substantial worked examples, not a target count. **Calibration questions:** Can a reader construct the quotient functional without guessing? Does norm attainment of a functional get confused with attainment of a nearest point? Is the complex scalar convention right? Can any paragraph be deleted without losing a necessary inference? **Pass evidence:** expansion → thickening → independent refinement on one fixed sample version, retaining every necessary argument.

### Candidate S — spectral: `243.7 Normal continuous functional calculus`
+
+The controller moved the second calibration unit to the earlier, stronger normal-operator calculus section, with fixed label `sec:243-continuous-calculus`, and reports its representative draft already routed to thickening. That draft is independent of this task. The calibration checks noncircular derivation of the polynomial norm identity, the precise C*-algebra/spectral permanence bridge, density by complex Stone–Weierstrass, extension by operator-norm limits, spectral mapping and agreement with holomorphic calculus. It must not borrow 244's cyclic/PVM/Borel theorem. Multiplication by the coordinate on a function space should show a normal operator without an eigenbasis. This supersedes the earlier `244.3` candidate without discarding its warnings about convergence or false operator-Lipschitz claims.
+
+## 8. B-01 reconciliation and open obligations

| ID | Location and reader impact | Owner / next action | Blocks |
|---|---|---|---|
| B02-U01 | Parent reports all three fixed local full texts and a 118-candidate responsibility table; this task has not received a final B-01 table | Parent/refinement provide fixed admitted source inventory and per-item responsibility table | Fixing B-02/source-complete claims |
| B02-U02 | Published V17 baseline only inherited, not independently checked here | Parent confirm actual fixed commit/source and last chapter | Formal numbering confirmation |
| B02-U03 | Prior-volume topology/measure/complex-analysis coverage not verified at item level | Refinement map exact imports or require local proof bridges | Affected proofs, not unrelated early drafting |
| B02-U04 | Eberlein–Smulian proof scope still requires an exact B-01 decision; advanced Fredholm is now FIXED in 241 | Refinement settle the remaining sequential compactness responsibility | Affected 237 coverage only |
| B02-U05 | RESOLVED design: normal continuous calculus in 243; Riesz–Markov/cyclic L²/PVM/Borel in 244 | Independent refinement check exact source responsibility and the noncircular proof chain | Does not block starting fixed earlier chapters |
| B02-U06 | RESOLVED by parent message: `X^*`, `T'`, Hilbert `T^*`, first-slot linear inner product, labels `ch:<number>` and `sec:<number>-*` | Implement in every subsequently dispatched unit | No longer blocks |
| B02-U07 | Actual model inference mode unavailable to this task | Parent record observed task settings if available; otherwise preserve UNKNOWN | Truthful role-setting record, not mathematical generation |
| B02-U08 | This record is a local role output; durable remote artifact location not established here | Parent include in authorized snapshot and recover/hash-check | Calling it remotely preserved/archived |

No issue here is a request to restart a frozen volume. Page estimates do not resolve any of these obligations.

## 9. Complete internal handoff

**ID/version/time:** V18-B02-EXP-RECONCILED-20261127-v2 / v2 / 2026-11-27 UTC.

**Sender → receiver:** isolated expansion role → parent controller, then independent refinement of dependency design. Conversation link not exposed to this task. This file has been delivered by task messaging; actual file read/hash receipt remains to be returned.

**Volume/stage/status:** V18, Functional Analysis and Bounded Operators, B single Work; B-02 reconciled v2 design. The 234 B-03 sample has separately been delivered for actual sequential review; the normal continuous-calculus sample is controlled by the parent. B-02 corresponds to original A boundary/expansion planning; it does not replace B-01 or authorize bypassing B-03–07. Not mathematical acceptance.

**Authorization/KEEP:** prepare 14-chapter narrative, dependencies and two calibration candidates. Do not change sources, tool ZIP, curriculum, numbering, frozen prior manuscripts, any other role's files, or the parent manuscript. No other work initiated. No agents spawned.

**Effective baseline:** curriculum v4.1; readiness v1; navigation v2.1; A/B v4; B single-Work v1; reported V17 commit and 231→232 continuity as above, remote reading still unverified by this role. Source-coverage and formal boundary version pending B-01.

**Manifest:** input manifest in `V18-B02-input-manifest.json`; output hashes/bytes in `V18-B02-output-manifest.json`. This markdown is a design record, not the source manuscript, coverage table, or source index. Those have not been produced here. Template baseline is the project-mandated R1 artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, reported ZIP SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`; not extracted or compiled by this task.

**Source/PDF/build:** no TeX or PDF produced in this preparatory task; no build, engineering pass, full-page reading QA, or mathematical pass claimed. Content preservation/engineering/reading layers: not applicable yet; no invented zero-warning result.

**Completed/evidence:** actual readings and input fingerprints; candidate full chapter/subsection routes; explicit proof and example obligations; prerequisite/import interface; two bounded calibration plans; late proof circularity risks identified.

**Change/impact:** v2 incorporates the explicit controller/refinement requirements listed in the revision note; v1 retained unchanged for history. The design changed, but no accepted manuscript was overwritten. Subsequent changes to quotient norm, scalar/inner-product conventions, dual/adjoint policy, weak topology, or functional calculus propagate according to Section 6; the parent must invalidate affected downstream checks. No existing acceptance has been overwritten.

**OPEN/UNKNOWN:** B02-U01–U08, with owners and block scopes in Section 8. The absence of further listed defects does not certify completeness.

**Next unique action/acceptance:** parent fixes this B-02 v2 against refinement's responsibility table and receives the independent 234 sample review, while expansion proceeds under the controller's explicit instruction to prepare 232–236 candidate chapter files. The shared convention is `ch:<number>`, `sec:<number>-*`, native definition/theorem/proof/example/problem/psolution environments, no shared macro edits. Acceptance requires every B-01 responsibility to have a real planned location and all prerequisite imports to have checked locations or explicit local proofs.

**Prohibited redo:** do not reopen prior volumes, rebuild project source tools, change volume numbering, treat a planning table as completed prose, or have the controller sign mathematical acceptance. Do not conflate a candidate sample with whole-volume B-07 acceptance.

**Pending user decision:** none requested by this role; the parent has the current user's authority to resolve routine design choices. Substantive source/boundary conflict must be reported with exact alternatives rather than concealed.

**Receipt to return:** actually read filenames and hashes; agree reconciled-design status and stage; name any missing B-01 inputs; confirm chapter/interface conventions accepted or amended; state the next unique action. Delivery of this message is not evidence of that receipt.
