# V18 B-01 source semantic register — v2

Partial source responsibilities actually inspected. These are independent paraphrases, not source reproductions. All formal manuscript locations remain PLANNED. Source statement reading is distinct from proof verification and manuscript coverage. Unnamed source material and relevant exercises remain under continuing review; no claim of exhaustive coverage.

| ID | Source location (printed / PDF) | V18 | Responsibility | Conditions / difference | Read state |
|---|---|---:|---|---|---|
| V18-SR-001 | Brezis 1.1 (1 / 16) | 234 | Dominated extension for real linear functionals | Real vector space; sublinear finite-valued dominating functional; initial functional dominated on its subspace | TEXT_CHECKED |
| V18-SR-002 | Brezis Lemma 1.1 (2 / 17) | 234 | Zorn maximal-extension principle | Every chain has an upper bound; distinguish maximal from greatest; state choice dependency | TEXT_CHECKED |
| V18-SR-003 | Brezis dual notation (3 / 18) | 233 | Continuous dual, norm and evaluation pairing | Normed domain; scalar field explicit; dual complete even if domain is incomplete | TEXT_CHECKED |
| V18-SR-004 | Brezis 1.2 (3 / 18) | 234 | Norm-preserving extension from a linear subspace | Initial functional continuous; subspace need not be closed | TEXT_CHECKED |
| V18-SR-005 | Brezis 1.3 (3 / 18) | 234 | Existence of a norming functional | For every chosen vector including the zero vector; do not infer uniqueness | TEXT_CHECKED |
| V18-SR-006 | Brezis 1.4 (4 / 19) | 234 | Dual functionals recover the original norm | Supremum over dual unit ball is attained for a fixed vector; distinguish this from attainment of a fixed functional on the original ball | TEXT_CHECKED |
| V18-SR-007 | Brezis hyperplane definition and 1.5 (4 / 19) | 234 | Affine hyperplanes and continuity criterion | Nonzero algebraic functional; closedness equivalent to its continuity; bounded dual is a restriction | TEXT_CHECKED |
| V18-SR-008 | Brezis 1.6 and Lemmas 1.2–1.3 (5 / 20) | 234 | Separation using an open convex set and its gauge | Disjoint nonempty convex sets; at least one open; nontrivial real functional | TEXT_CHECKED |
| V18-SR-009 | Brezis 1.7 (7 / 22) | 234 | Strict convex separation | Disjoint nonempty convex sets; one closed and the other compact | TEXT_CHECKED |
| V18-SR-010 | Brezis 1.8 / Remark 5 (8 / 23) | 234 | Annihilator test for density | Non-dense linear subspace; closure is essential | VISUAL_CHECKED |
| V18-SR-011 | Brezis bidual notation (8 / 23) | 234 | Canonical embedding into the bidual | Evaluation J(x)(f)=f(x); canonical embedding is an isometry; arbitrary isomorphism to bidual is not the definition of reflexivity | VISUAL_CHECKED |
| V18-SR-012 | Brezis annihilator notation (9 / 24) | 234 | Two annihilator operations and their ambient spaces | Annihilator of a subset of E lies in E*; preannihilator of a subset of E* lies in E, not automatically E** | VISUAL_CHECKED |
| V18-SR-013 | Brezis 1.9 / Remark 6 and following page (9 / 24) | 234 | Double annihilator and closure distinctions | For M⊂E obtain norm closure(M); for N⊂E* get weak-star closure, generally larger than norm closure | VISUAL_CHECKED |
| V18-SR-014 | Brezis 1.4 introductory definitions (10 / 25) | 237 | Lower semicontinuity, epigraph and convexity bridge | Extended values exclude minus infinity; sequence criterion converse requires metric domain; use closed sublevels | TEXT_CHECKED |
| V18-SR-015 | Brezis 2.1 (31 / 46) | 235 | Baire category theorem | Complete metric space; countable family; nonempty open test set | TEXT_CHECKED |
| V18-SR-016 | Brezis 2.2 (32 / 47) | 235 | Uniform boundedness for arbitrary operator families | Brezis assumes both domain and target Banach; Conway III.14.1 only requires Banach domain and normed target | TEXT_CHECKED |
| V18-SR-017 | Brezis 2.3 (33 / 48) | 235 | Pointwise limit of bounded linear operators | Every vector has a norm limit; obtain bounded limit and uniform norm bound, not operator-norm convergence | TEXT_CHECKED |
| V18-SR-018 | Brezis 2.4 (33 / 48) | 235 | Weakly bounded sets are norm bounded | Brezis states Banach ambient; explain evaluation maps and dual completeness | TEXT_CHECKED |
| V18-SR-019 | Brezis 2.5 (34 / 49) | 235 | Pointwise bounded dual families are norm bounded | Banach predual; arbitrary dual family | TEXT_CHECKED |
| V18-SR-020 | Brezis 2.6 (35 / 50) | 236 | Open mapping theorem | Bounded surjective map between Banach spaces | TEXT_CHECKED |
| V18-SR-021 | Brezis 2.7 (35 / 50) | 236 | Bounded inverse theorem | Bijective bounded linear map between Banach spaces | TEXT_CHECKED |
| V18-SR-022 | Brezis 2.8 (35 / 50) | 236 | One-sided norm comparison becomes equivalence | Both norms complete; same vector space | TEXT_CHECKED |
| V18-SR-023 | Brezis 2.9 (37 / 52) | 236 | Closed graph theorem | Everywhere-defined linear map between Banach spaces; graph closed in product norm | TEXT_CHECKED |
| V18-SR-024 | Brezis 2.10 (37 / 52) | 236 | Uniform bounded decomposition in sum of subspaces | Both subspaces closed; their sum closed; ambient Banach | TEXT_CHECKED |
| V18-SR-025 | Brezis 2.11 (38 / 53) | 236 | Distance estimate for intersection of closed subspaces | Retain the hypotheses of 2.10 | TEXT_CHECKED |
| V18-SR-026 | Brezis 2.12 (39 / 54) | 236 | Existence of a bounded right inverse | Surjectivity plus complemented kernel | TEXT_CHECKED |
| V18-SR-027 | Brezis 2.13 (40 / 55) | 236 | Existence of a bounded left inverse | Injectivity plus closed complemented range | TEXT_CHECKED |
| V18-SR-028 | Brezis 2.14–2.16 (40 / 55) | 236 | Annihilator relations for sums and intersections | Closed subspaces in Banach space; closure bars need original-page recheck before exact formulas are signed | TEXT_CHECKED |
| V18-SR-029 | Brezis 3.3–3.4 (57 / 72) | 237 | Weak topology is Hausdorff and has finite-test neighborhoods | Brezis works with Banach E; Hahn–Banach separates points; tests are finite | TEXT_CHECKED |
| V18-SR-030 | Brezis 3.5 (58 / 73) | 237 | Weak sequence convergence, boundedness and norm lower bound | Brezis Banach convention; moving functional may converge in norm | TEXT_CHECKED |
| V18-SR-031 | Brezis 3.6 (58 / 73) | 237 | Finite-dimensional weak and norm topologies agree | Finite dimension is essential | TEXT_CHECKED |
| V18-SR-032 | Brezis 3.7 (60 / 75) | 237 | Weak and norm closedness agree for convex sets | Convexity essential; the sphere is a useful failure example | TEXT_CHECKED |
| V18-SR-033 | Brezis 3.8 (61 / 76) | 237 | Mazur convex combinations recover norm convergence | Weakly convergent sequence; distinguish convex hull of full sequence from tail refinements | TEXT_CHECKED |
| V18-SR-034 | Brezis 3.9 (61 / 76) | 237 | Convex norm lower semicontinuous functions are weakly lower semicontinuous | Closed convex sublevels; properness only where necessary | TEXT_CHECKED |
| V18-SR-035 | Brezis 3.10 / Remark 7 (61 / 76) | 237 | Bounded linear maps preserve weak continuity | Brezis Banach hypotheses; converse proof uses closed graph; nonlinear maps do not share this property | TEXT_CHECKED |
| V18-SR-036 | Brezis 3.11–3.13 (63 / 78) | 237 | Weak-star Hausdorff topology, neighborhoods and convergence | A specified predual; finite evaluation tests; distinguish weak from weak-star | TEXT_CHECKED |
| V18-SR-037 | Brezis 3.14 / Lemma 3.2 / 3.15 (64 / 79) | 237 | Weak-star continuous linear functionals are evaluations | Full weak-star continuity, not norm continuity alone; finite-test algebraic lemma | TEXT_CHECKED |
| V18-SR-038 | Brezis 3.16 (66 / 81) | 237 | Alaoglu compactness of the dual unit ball | Topological compactness; proof uses arbitrary-product compactness | TEXT_CHECKED |
| V18-SR-039 | Brezis 3.18 (69 / 84) | 237 | Reflexive bounded sequences have weakly convergent subsequences | Reflexive Banach space; do not derive this from abstract compactness alone | TEXT_CHECKED |
| V18-SR-040 | Brezis 3.19 (70 / 85) | 237 | Sequential compactness criterion for reflexivity | Brezis omits proof; Conway V.13 is required if full proof is adopted | TEXT_CHECKED |
| V18-SR-041 | Brezis 3.20–3.21 (70 / 85) | 237 | Reflexivity passes to closed subspaces and is equivalent for the dual | Canonical maps and closed subspaces; closure hypothesis cannot be dropped | TEXT_CHECKED |
| V18-SR-042 | Brezis 3.22 (71 / 86) | 237 | Closed bounded convex sets in reflexive spaces are weakly compact | Reflexivity plus norm closedness and convexity | TEXT_CHECKED |
| V18-SR-043 | Brezis 3.23 (71 / 86) | 245 | Direct method for a convex minimization problem | Nonempty closed convex feasible set; proper convex lower semicontinuous coercive objective; reflexive Banach space | TEXT_CHECKED |
| V18-SR-044 | Brezis 3.25–3.27 (73 / 88) | 237 | Separability of subsets and duality implications | Metric ambient for hereditary separability; E* separable implies E separable; converse needs reflexivity | TEXT_CHECKED |
| V18-SR-045 | Brezis 3.28–3.29 (74 / 89) | 237 | Metrization on weak/weak-star unit balls | Weak-star ball metrizable iff predual separable; weak ball criterion uses separability of dual | TEXT_CHECKED |
| V18-SR-046 | Brezis 3.30 (76 / 91) | 237 | Weak-star convergent subsequence from a bounded dual sequence | Separable Banach predual | TEXT_CHECKED |
| V18-SR-047 | Brezis 3.31 (77 / 92) | 237 | Uniform convexity implies reflexivity | Banach completeness and uniform convexity; uniform convexity is a property of the chosen norm | TEXT_CHECKED |
| V18-SR-048 | Brezis 3.32 (78 / 93) | 237 | Weak convergence plus norm control yields strong convergence | Uniformly convex space; limit norm is approached from above in limsup | TEXT_CHECKED |
| V18-SR-049 | Brezis 4.6 (92 / 107) | 245 | Holder inequality including endpoint exponents | Conjugate exponents; a.e. equivalence classes; identify product as integrable | TEXT_CHECKED |
| V18-SR-050 | Brezis 4.7–4.8 (93 / 108) | 245 | Lp norm and completeness | 1≤p≤infinity; sigma-finite convention in this source; quotient by equality a.e. | TEXT_CHECKED |
| V18-SR-051 | Brezis 4.9 (94 / 109) | 245 | Norm convergence gives a.e. convergent dominated subsequence | Lp convergence; subsequence rather than whole sequence | TEXT_CHECKED |
| V18-SR-052 | Brezis 4.10 (95 / 110) | 245 | Reflexivity of Lp | 1<p<infinity; source proof uses Clarkson inequalities and Milman–Pettis | TEXT_CHECKED |
| V18-SR-053 | Brezis 4.11 (97 / 112) | 245 | Lp dual representation for interior exponents | 1<p<infinity; dual pairing convention; uniqueness modulo equality a.e. | TEXT_CHECKED |
| V18-SR-054 | Brezis 4.12 (97 / 112) | 245 | Continuous compact-support density | Lp on Euclidean Lebesgue space; 1≤p<infinity | TEXT_CHECKED |
| V18-SR-055 | Brezis 4.13 (98 / 113) | 245 | Separability of Lp | Separable measure space; 1≤p<infinity; Euclidean proof supplied in source | TEXT_CHECKED |
| V18-SR-056 | Brezis 4.14 (99 / 114) | 245 | L1 dual representation | Sigma-finite measure convention from p89; target L-infinity; uniqueness a.e. | TEXT_CHECKED |
| V18-SR-057 | Brezis 4.15 (104 / 119) | 245 | Convolution as a bounded operator on Lp | L1 convolution kernel; 1≤p≤infinity; Euclidean Lebesgue space | TEXT_CHECKED |
| V18-SR-058 | Brezis 4.16 (105 / 120) | 245 | Pairing identity for convolution | Conjugate exponents; reflected kernel; verify integrability before Fubini | TEXT_CHECKED |
| V18-SR-059 | Brezis 4.17 (105 / 120) | 245 | Essential support of a measurable function | Ignore null changes; use largest open zero-a.e. region | TEXT_CHECKED |
| V18-SR-060 | Brezis 4.18 (106 / 121) | 245 | Support containment for convolution | Minkowski sum and closure typography require visual confirmation | TEXT_CHECKED |
| V18-SR-061 | Brezis 4.19–4.20 (106 / 121) | 245 | Continuity and smoothness of convolution with smooth compact-support kernels | Kernel continuity or Ck; other factor locally integrable | TEXT_CHECKED |
| V18-SR-062 | Brezis 4.21 (108 / 123) | 245 | Mollifier approximation of continuous functions | Uniform convergence on compact sets; support and normalization of mollifier | TEXT_CHECKED |
| V18-SR-063 | Brezis 4.22–4.23 (109 / 124) | 245 | Mollifier Lp approximation and smooth compact-support density | 1≤p<infinity; open Euclidean domain; no L-infinity norm claim | TEXT_CHECKED |
| V18-SR-064 | Brezis 4.24 (110 / 125) | 245 | Vanishing test-function integrals imply vanishing a.e. | Locally integrable function; all smooth compact-support tests; no distribution theory assumed | TEXT_CHECKED |
| V18-SR-065 | Brezis 4.25 (111 / 126) | 240 | Arzela–Ascoli compactness bridge | Bounded equicontinuous family; compact metric domain; C(K) supremum norm | TEXT_CHECKED |
| V18-SR-066 | Brezis 4.26 (111 / 126) | 245 | Local Lp compactness from uniform translation control | Bounded family in Lp of whole Euclidean space; 1≤p<infinity; restrictions to finite-measure set | TEXT_CHECKED |
| V18-SR-067 | Brezis 4.27 (113 / 128) | 245 | Global Lp compactness with tail control | Add uniform small tails to translation control | TEXT_CHECKED |
| V18-SR-068 | Brezis 4.28 / Lemma 4.3 (114 / 129) | 245 | Convolution produces local compactness | Fixed L1 kernel and bounded Lp family; prove translations are continuous for finite exponents | TEXT_CHECKED |
| V18-SR-069 | Brezis 5.2 (132 / 147) | 238 | Metric projection to closed convex subsets | Nonempty closed convex subset of a complete Hilbert space; use real part for complex space | TEXT_CHECKED |
| V18-SR-070 | Brezis 5.3 (134 / 149) | 238 | Projection is nonexpansive | Convex projection; do not assert linearity except for a subspace | TEXT_CHECKED |
| V18-SR-071 | Brezis 5.4 (134 / 149) | 238 | Orthogonal projection to closed subspaces | Closed linear subspace; linearity, orthogonal residual and direct-sum decomposition | TEXT_CHECKED |
| V18-SR-072 | Brezis 5.5 (135 / 150) | 239 | Hilbert-space Riesz representation | Continuous linear functional; unique representing vector; norm equality; complex convention alters conjugation | TEXT_CHECKED |
| V18-SR-073 | Brezis 5.6 (138 / 153) | 239 | Stampacchia variational inequality | Real Hilbert space; bounded coercive bilinear form; nonempty closed convex subset; symmetry only for minimization formula | TEXT_CHECKED |
| V18-SR-074 | Brezis 5.8 (140 / 155) | 239 | Lax–Milgram solvability | Bounded coercive bilinear form; symmetric case gives energy minimization; complex variant needs sesquilinearity and real-part coercivity | TEXT_CHECKED |
| V18-SR-075 | Brezis 5.9 / Lemma 5.1 (141 / 156) | 238 | Orthogonal Hilbert sums and Parseval | Countable closed orthogonal subspaces with dense span; squared-norm summability | TEXT_CHECKED |
| V18-SR-076 | Brezis 5.10–5.11 (143 / 158) | 238 | Orthonormal basis expansions and separable existence | Countable Hilbert basis; distinguish Hilbert basis from Hamel basis | TEXT_CHECKED |
| V18-SR-077 | Brezis 6.1–6.2 (157 / 172) | 240 | Norm-closed compact operators and finite-rank approximants | Banach target; converse finite-rank approximation fails in general | TEXT_CHECKED |
| V18-SR-078 | Brezis 6.3 (159 / 174) | 240 | Compact operators form an operator ideal | One compact factor and the other bounded; domain/codomain compatible | TEXT_CHECKED |
| V18-SR-079 | Brezis 6.4 (159 / 174) | 240 | Schauder compact-adjoint theorem | Banach adjoint and original map; retain both directions | TEXT_CHECKED |
| V18-SR-080 | Brezis Lemma 6.1 / 6.5 (160 / 175) | 232 | Riesz lemma and finite-dimensional compact ball criterion | Proper closed subspace; distance arbitrarily close to one; normed space | TEXT_CHECKED |
| V18-SR-081 | Brezis 6.6 (160 / 175) | 241 | Compact Fredholm alternative | Compact endomorphism of Banach E; I-K has finite kernel, closed range, dual annihilator obstruction and index zero | TEXT_CHECKED |
| V18-SR-082 | Brezis 6.7 (163 / 178) | 242 | Real-spectrum compactness and norm bound in Brezis convention | Brezis defines real resolvent/spectrum here; V18 complex theory must not inherit real-interval bound | TEXT_CHECKED |
| V18-SR-083 | Brezis 6.8 / Lemma 6.2 (164 / 179) | 242 | Nonzero compact spectrum consists of isolated finite-multiplicity eigenvalues | Infinite-dimensional Banach space; adapt source real formulation to complex version via Conway | TEXT_CHECKED |
| V18-SR-084 | Brezis 6.9–6.10 (165 / 180) | 244 | Self-adjoint spectral interval, endpoint and norm properties | Hilbert operator; quadratic form extrema; zero-spectrum self-adjoint map vanishes | TEXT_CHECKED |
| V18-SR-085 | Brezis 6.11 (167 / 182) | 244 | Compact self-adjoint spectral decomposition | Brezis assumes separable Hilbert space; kernel may be infinite-dimensional | TEXT_CHECKED |
| V18-SR-086 | Brezis 6.12 / comments (169 / 184) | 240 | Hilbert–Schmidt kernel operators | Separable L2 setting; kernel in L2 of product; kernel uniqueness is a.e. | TEXT_CHECKED |
| V18-SR-087 | Brezis 4 opening convention (89 / 104) | 245 | Measure space and sigma-finiteness convention | Source globally assumes sigma-finite; where V18 weakens this it must supply a valid proof | TEXT_CHECKED |
| V18-SR-088 | Brezis 4.3 Remarks 6–8 (101 / 116) | 245 | Endpoint reflexivity, separability and duality failures | Finite-dimensional atomic exceptions; source uses sigma-finite setting; evaluate representatives only on continuous subspace before Hahn–Banach extension | TEXT_CHECKED |
| V18-SR-089 | Brezis 6.1 Remark 1 (158 / 173) | 240 | Compact need not be approximable by finite-rank linear maps | Positive Hilbert-target case proved by finite-dimensional projections; nonlinear finite-rank approximation is a different statement | TEXT_CHECKED |
| V18-SR-090 | Brezis 6 comments (a)–(d) (168 / 183) | 241 | Fredholm parametrix, openness, index stability and composition | Banach domain/codomain; define Fredholm with closed range and finite kernel/cokernel; source states these as comments without full proof | TEXT_CHECKED |
| V18-SR-091 | Brezis 11.22–11.24 (361 / 376) | 234 | Real-to-complex functional reconstruction and separation | Reconstruction f(x)=phi(x)-i phi(ix); norm equality; real hyperplane for complex convex separation | TEXT_CHECKED |
| V18-SR-092 | Brezis 11.4 complex inner-product convention (364 / 379) | 238 | Complex Hilbert scalar convention | Linear in first variable; conjugate-linear in second; complex projection uses real part | VISUAL_CHECKED |
| V18-SR-093 | Conway I.1.1 (1 / 15) | 238 | Real/complex semi-inner product conventions | Linear first variable and conjugate-linear second; positive semidefinite distinguished from positive definite | TEXT_CHECKED |
| V18-SR-094 | Conway I.3 introduction (11 / 25) | 239 | Two meanings of Riesz representation | Hilbert-space representation distinct from measure representation on continuous functions | TEXT_CHECKED |
| V18-SR-095 | Conway II.2.1–2.4 (31 / 45) | 239 | Bounded sesquilinear forms and Hilbert adjoints | Hilbert domain/codomain; conjugate-linear in second variable; proof uses conjugated functional | VISUAL_CHECKED |
| V18-SR-096 | Conway III.10.1 (88 / 102) | 234 | Restriction identifies dual quotient with subspace dual | Closed subspace convention; quotient norm; Hahn–Banach gives norm-preserving lift | TEXT_CHECKED |
| V18-SR-097 | Conway III.12.1 (90 / 104) | 236 | Banach open mapping theorem | Continuous linear surjection between Banach spaces | TEXT_CHECKED |
| V18-SR-098 | Conway III.14.1 (95 / 109) | 235 | Uniform boundedness with normed target | Banach domain; target need not be complete; arbitrary pointwise-bounded operator family | TEXT_CHECKED |
| V18-SR-099 | Conway VIII.2.1 (236 / 250) | 243 | Commutative unital C-star algebra representation | Isometric star-isomorphism through Gelfand transform; prove necessary Banach algebra and Stone–Weierstrass prerequisites | TEXT_CHECKED |
| V18-SR-100 | Conway VIII.3.1–3.5 (240 / 254) | 244 | Positivity, positive and negative parts, positive roots | Self-adjoint element with nonnegative spectrum; positive root uniqueness includes positivity condition | TEXT_CHECKED |
| V18-SR-101 | Conway IX.1 introduction (255 / 269) | 244 | Representations produce projection-valued measures | Prior VIII.5.1–5.8 definitions explicitly requested by source; supply needed representation bridge if GNS is omitted | TEXT_CHECKED |
| V18-SR-102 | Conway IX.8 opening convention (285 / 299) | 244 | Additional separability in late bounded normal calculus | Conway assumes Hilbert spaces separable from IX.8 onward; do not silently generalize conclusions | TEXT_CHECKED |
| V18-SR-103 | Conway XI introduction (347 / 361) | 241 | Hilbert-space Fredholm scope and Calkin algebra | Chapter is Hilbert-specific; quotient by compact ideal; cannot treat its proof as a Banach-space proof | TEXT_CHECKED |
| V18-SR-104 | Conway XI.2.1 (349 / 363) | 241 | Parametrix definition of semi-Fredholm and Fredholm | Two Hilbert spaces; left/right inverses modulo compact; source permits one-sided notions | TEXT_CHECKED |
| V18-SR-105 | Conway XI.2.4–2.6 (352 / 366) | 241 | Fredholm characterization and open classes | Closed range; kernel and adjoint kernel finite; quotient-algebra formulation | TEXT_CHECKED |
| V18-SR-106 | Conway XI.4.1–4.2 (358 / 372) | 242 | Essential spectrum via Calkin algebra | Hilbert endomorphism; complex unital quotient algebra; compact perturbation invariance | TEXT_CHECKED |
