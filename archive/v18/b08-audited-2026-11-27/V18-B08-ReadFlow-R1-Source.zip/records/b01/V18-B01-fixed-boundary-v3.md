# V18 B-01 fixed responsibility boundary — v3

2026-11-27 UTC. Decision type: **source responsibility and design boundary fixed for B-02/B-03 preparation; continuing fine-grained source audit remains OPEN.** This fixes what the volume must teach. It does not claim every source paragraph was read, every source candidate was reconciled, or any manuscript was accepted.

## Fixed inputs and honest read states

Readiness v1 and project v4/single-Work/v3 were actually read. All three user-admitted PDFs are now locally present. Their hashes were independently recomputed in `V18-B01-source-semantic-register-v2.json`. Brezis and Conway have text layers with missing closure bars and conjugates; targeted original-page checks were performed. Rudin has no text layer; controller OCR exists, but this role has not yet visually checked Rudin body pages. Therefore Rudin per-item hypotheses remain UNKNOWN. This limits source-completeness claims, not independent mathematical drafting within the fixed chapter responsibilities.

Brezis: 614 PDF pages; printed p = PDF page −15 on the checked body ranges. Conway: 414 PDF pages; printed p = PDF page −14 on the checked body ranges. Rudin: 221 PDF spreads, two printed pages on many spreads; printed/PDF relation must be checked page by page.

Conway actual PDF says Second Edition; publisher page lists hardcover 1990, ebook 2019, copyright metadata 2007. Do not replace an actual PDF copyright date with the publisher web field. Brezis English edition uses copyright 2011 with ebook released 2010. Rudin actual page verification remains on the controller OCR/visual worklist.

## Fixed chapter responsibility

Use the fourteen-chapter table in responsibility-boundary v1 with these binding additions/clarifications:

1. **232:** all norm/completeness/finite-dimensional/quotient constructions have proofs; Brezis11.1–11.3 supply additional source responsibility, not merely an optional appendix. Quotient completeness cannot borrow open mapping.
2. **233:** operator spaces, dense extension and Neumann series; Banach transpose is introduced after dual definition in234. Hilbert adjoint waits for239. Scalar field is always stated.
3. **234:** real dominated Hahn–Banach and complex norm-preserving extension; geometric separation, norm recovery, annihilator/quotient duality; distinguish norm closure on E from weak-star closure on E*. Convex conjugate/Fenchel duality is deferred (below) except elementary convex/lower-semicontinuity definitions needed by237.
4. **235:** arbitrary-family uniform boundedness with Banach domain and normed target (Conway stronger formulation); pointwise limits, dense-set extension, weak boundedness and completeness failure models.
5. **236:** open mapping including exact iterative correction; bounded inverse; closed graph and graph norm; complemented subspaces and left/right inverses; closed-range quotient estimate. The bounded operator special case of transpose range/annihilator formulas is included; general unbounded adjoint theory is deferred.
6. **237:** explicit initial-topology/finite-test/net/compactness bridge, a local proof of arbitrary-product compactness or a precisely verified preceding proof; Alaoglu, Goldstine, reflexivity, weak/weak-star metrizability, closed-subspace/quotient/dual reflexivity, Mazur, uniform convexity/Milman–Pettis, and the full Eberlein–Smulian equivalence with an actual proof. Include Krein–Milman for weakly compact convex subsets of normed spaces with its required proof, rather than silently omit this major source branch. General locally convex formulation stays V19.
7. **238:** complete Hilbert projection/orthogonal decomposition/basis theory, real/complex conventions and nonseparable qualification. First-slot linear convention fixed. A local complex-L2 bridge belongs here: controller reports verified V16 Ch218 printed150–154 supplies real Lp Banach; extend real L2 to complex L2 explicitly (or supply a short independent proof). This role has not independently re-read V16 yet, so the inherited-evidence claim remains controller-verified, not a new source-reading claim.
8. **239:** Hilbert Riesz representation, bounded forms and adjoints, Lax–Milgram with Re coercivity over C. Include the real closed-convex variational inequality (Stampacchia) as a worked theorem/application, using a proved contraction principle. Distinguish Hilbert Riesz, Lp Riesz and Riesz–Markov.
9. **240:** compact ideal, norm closure, Schauder, weak-to-strong sequence behavior, Hilbert finite-rank approximation, Arzela–Ascoli and verified kernel examples; Hilbert–Schmidt norm/kernel/basis independence if used. No general approximation-property assertion.
10. **241:** Banach compact Fredholm alternative with all four parts (finite kernel, closed range/annihilator, injective iff surjective, equal nullity/deficiency). General Banach Fredholm parametrices, openness/local constancy of index, compact perturbation invariance and index additivity are included responsibilities; do not mark them optional after accepting Conway XI/Brezis6 comments. Hilbert one-sided variants may be a clearly delimited refinement. Calkin essential spectrum belongs after complex spectral algebra in242, not in a proof in241.
11. **242:** complex unital Banach algebra spectrum, nonemptiness, compactness, radius, polynomial mapping, compact spectral isolation and finite algebraic multiplicity, concrete spectrum partitions; Calkin essential spectrum as a concluding specialization using241. Real spectra use explicit complexification; Brezis real-interval bound is not a complex-spectrum theorem.
12. **243:** holomorphic calculus, resolvent identity, contour independence, algebra homomorphism, spectral mapping/composition and Riesz projections; define the required norm integral before use. Add normal continuous calculus in243, independently of244: self-adjoint quadratic-form norm and real-spectrum lemma, inverse permanence, characters/maximal ideals, local Stone–Weierstrass approximation, normal norm=radius, then the isometric C(sigma(N)) calculus. This is the fixed preparation for244; its proof must not invoke the later spectral theorem.
13. **244:** bounded self-adjoint compact and general bounded-normal spectral theorems, bounded Borel calculus, PVM reconstruction/countable strong additivity, positivity/square root, polar decomposition and compact singular values. Continuous normal calculus is proved in243. Chapter244 constructs cyclic L2 models and spectral measures/PVM from it, then the bounded normal spectral theorem. General normal scope is included, not left optional. No unbounded spectral theorem.
14. **245:** actually construct Lp as a.e. classes, prove norm/completeness, density and interior/endpoint duality/reflexivity/separability with measure assumptions; convolution/Young, translation continuity, smooth regularization/density, essential support and compactness criteria from Brezis4.4–4.5; full direct method, Galerkin/Cea, finite-rank/integral Fredholm and spectral worked applications. Integration prerequisites may be precisely imported if actually verified, otherwise supply the required local bridge.

## Excluded or deferred source branches and reasons

| Source branch | Decision | Destination / reason |
|---|---|---|
| Brezis1.4 Fenchel–Moreau/Rockafellar and conjugate examples | Deferred except needed l.s.c./convex definitions | Convex optimization/duality treatment, later destination number UNKNOWN; not needed for normed-operator core and would add a second theory |
| Brezis2.6 general unbounded adjoints;3.24;7–10 | Deferred | Unbounded operators/Sobolev/PDE/evolution work; local closed-derivative counterexample permitted |
| Brezis4.1 integration results | Import-or-prove prerequisite | Earlier measure theory location UNKNOWN until verified; no claim they are already present |
| Conway II.6 Sturm–Liouville; III.8 Runge | Deferred applications | Depend on ODE/complex approximation theory beyond the selected concrete bounded-operator applications |
| Conway III.7 Banach limits | Include selected original example in234/245 | Distinguishes duality and nonreflexivity; prove any existence/properties actually used |
| Conway III.9 ordered spaces | Selected bridge only | Order definitions needed for positive operators included244; general order-unit theory deferred |
| Conway IV general locally convex theory;V.1–2 dual-pair generality | Normed-space specialization only | General theory and distributions are V19 responsibility; weak topology needed in237 stays local |
| Conway V.6 Stone–Cech;V.9–12 fixed points/Haar/Krein–Smulian | Deferred except any explicitly selected auxiliary theorem | General topology/group integration/locally convex advanced branches; no hidden reliance in the V18 proofs |
| Conway V.7 Krein–Milman,V.13 weak compactness | Include normed-space form | Substantial source responsibilities for237 with full proof |
| Conway V.8 Stone–Weierstrass | Required bridge if used by calculus | Prove usable approximation theorem locally or verify exact prior location |
| Conway VI.2 Banach–Stone;VI.4 invariant-subspace research | Deferred except basic invariant/reducing definitions/examples | Classification/research branches not needed by this volume's core |
| Conway VI.5 weakly compact operators | Include bounded-operator characterization if invoked; otherwise explicit deferred row | Relation to reflexivity belongs237/240, not a license to claim all general weak compact operator theory |
| Conway VII.9 group algebra | Deferred | Harmonic analysis beyond unital spectral core |
| Conway VIII.4–5 ideals/GNS | Minimal definitions only if needed by chosen244 proof | Full representation/C-star course outside scope; no theorem may borrow an omitted dependency |
| Conway IX.7 von Neumann algebras;IX.10 multiplicity classification | Deferred | Operator algebra and classification extension; bounded spectral theorem itself stays included |
| Conway X; Rudin13 | Deferred | Unbounded spectral/evolution theory outside V18 |
| Conway XI.5–6 path components/finer spectral classification | Selected consequences only | Index local constancy/essential spectrum included; full classification and research extensions deferred |
| Rudin1 general TVS,3 general convex/dual-pair structure | Normed specializations included, general theory deferred | V19 interface; fine hypotheses still require OCR+visual source check |
| Rudin5 fixed-point/Haar/vector-measure applications | Selected application rows only | Retain examples serving current normed/operator tools; general topological group/vector integration topics deferred |
| Rudin10 Lomonosov;11 full commutative algebra applications;12 ergodic/invertible-group extensions | Minimal calculus bridge and selected bounded-operator consequences only | Full research/operator-algebra/ergodic developments not automatic from reference chapter admission |

These are topic-level decisions, not an assertion that every unnamed paragraph in these ranges is catalogued. The per-item table must retain candidates that refine these decisions, with exact proof/example locators and manuscript landings as they become available. A newly found relevant item is added to the responsibility table; omission is not normalized by the present list.

## Gate and continuing work

B02 design and representative calibration may proceed on the fixed responsibilities. B01 every-item source coverage remains partial: 106 actually inspected responsibility rows in semantic-register v2, plus the 118 earlier planning candidates; these are different evidence classes and must not be summed as a completeness measure. Brezis unnamed proofs/examples and full Conway/Rudin detailed reconciliation remain OPEN. B04 chapter work must resolve the relevant source rows and exact manuscript locations before those chapters pass refinement. B05 cannot pass with unresolved relevant source-completeness items. Nothing here is an entire-volume or B07 mathematical signature.

## Controller decisions received after v2

* 237 proves Tychonoff locally through ultrafilters; define filter/ultrafilter, extension via Zorn, convergence/compactness criterion, product projections and the product proof before Alaoglu.
* 241 proves the full bounded Banach Fredholm/Atkinson and index core; 242 introduces essential spectrum after spectral algebra.
* 243 includes holomorphic and normal continuous calculi; the shared label is `sec:243-continuous-calculus`. 244 consumes this theorem for cyclic L2/PVM/spectral representation; it does not re-prove continuous calculus as a competing first construction.
* 238 includes explicit local complex-L2 construction from the verified real Lp prerequisite (or independent proof), so 240/242/243 examples do not import future245.
* Controller reports V16 RN Ch217 printed99–109 is for finite signed measures with sigma-finite base; complex versions need real/imaginary assembly. Keep these exact measure restrictions in245.

## Source correspondence for the revised calculus route

| Local responsibility | Actual fixed source orientation | Source-read status in this role |
|---|---|---|
| 237 ultrafilter product bridge | Brezis3.16 proof printed66–67 invokes Tychonoff; Conway Appendix A topology | Brezis source proof invocation text read; local proof must be original and independently verified |
| 238 complex-L2 bridge | Brezis4 printed89–103;11.4 printed361–364; Conway I.1 | Brezis assumptions and complex convention read,364 visually checked; V16 prior proof controller-verified only |
| 241 Banach Fredholm | Brezis6.6 printed160–162; comments168–169; ConwayXI Hilbert refinement347–358 | Key statements/conditions read; full original Banach proof obligations remain B04 |
| 243 maximal ideals and scalar characters | ConwayVII.8 printed218–223; Rudin11 printed275ff | Conway chapter localization checked; Rudin finer item hypotheses UNKNOWN |
| 243 inverse permanence/continuous calculus | ConwayVIII.1–2 printed232–239 | Opening conventions and key theorem read; spectral sample independently read below |
| 243 positivity bridge | ConwayVIII.3 printed240–245 | Key statements read; local proof may instead derive by continuous calculus |
| 244 PVM and normal spectral theorem | ConwayIX.1–2 printed255–268,IX.8 285–290; Rudin12 306ff | Conway scope and separability convention read; detailed reconstruction still to review |
| 245 general Lp/regularization/compactness | Brezis4.2–4.5 printed91–114; ConwayAppendixB375–377 | Major numbered statements/measure convention read; exhaustive unnamed-item reconciliation remains open |

The earlier 106-row register is retained unchanged for provenance. Rows mapped to244 continuous calculus are remapped to243 in this boundary v3; formal manuscript labels take precedence once B02 is fixed.
