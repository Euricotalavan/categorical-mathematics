# V18 B-01 source responsibility and boundary — preliminary v1

2026-11-27. Self-written planning responsibilities; not a source-exhaustiveness or mathematical-approval claim. Three source bodies have not yet arrived locally. Publisher chapter ranges below were actually checked; fine-grained item locations remain UNKNOWN. All textbook definition/statement/proof/example coverage is PLANNED, with no formal manuscript yet.

## Status vocabulary

`TOC_CHECKED` means publisher chapter location only; `SOURCE_CHECKED` requires reading actual source body. `TOOL_CANDIDATE` never implies source checking. `PLANNED` is a proposed manuscript landing point; definition/statement/proof/example states remain separate.

## Responsibilities

| Ch. | English working title | Fixed-edition source locator | Required original treatment | Prerequisites | Boundary / condition warning |
|---:|---|---|---|---|---|
| 232 | Normed and Banach spaces | Conway III 63–98; Rudin 1–2 | scalar field; norm; induced metric; subspace and quotient norms; completeness; completions; equivalent norms; finite-dimensional norms; standard sequence/function examples | Metric completeness, vector spaces, quotient vector spaces | Use only normed-space topology; general locally convex spaces belong to V19 |
| 233 | Bounded linear maps | Conway II 26–62, III 63–98, VI 166–186; Rudin 1 | linearity and boundedness; continuity equivalence; operator norm; completeness of B(X,Y); extension from dense subspace; isomorphism; quotient map; adjoint and dual map | 232 | Closed unbounded operators only as counterexamples to omitted hypotheses; no general unbounded operator theory |
| 234 | Duality and Hahn–Banach | Brezis 1 1–29; Conway III 63–98; Rudin 3–4 | real dominated extension; complex extension; norm-preserving extension; norming functional; separation; annihilator; quotient dual; bidual and canonical embedding | 232–233; real/complex linearity | Introduce only the convex separation machinery needed for normed spaces; conjugate convex analysis beyond these applications deferred |
| 235 | Uniform boundedness | Brezis 2 31–54; Conway III 63–98; Rudin 2 | Baire category; uniform boundedness; Banach–Steinhaus; pointwise operator limits; failure without completeness; resonance example | 232–233; completeness | State arbitrary-family and sequence forms separately; no exchange of weak and norm convergence |
| 236 | Open mapping and closed graph | Brezis 2 31–54; Conway III 63–98; Rudin 2 | open mapping; bounded inverse; quotient by kernel; closed graph; graph norm; failure examples | 232–235; Baire proof | Full Frechet-space forms belong to V19; Banach specializations must retain surjectivity/completeness |
| 237 | Weak topology and reflexivity | Brezis 3 55–87; Conway V 124–165; Rudin 3–4 | weak/weak-star topology; finite-test neighborhoods; nets versus sequences; weakly bounded sets; weak closed convex sets; Alaoglu; canonical embedding; reflexivity; weak compactness; separability; metrizability; uniform convexity | 234–236; product compactness or supplied proof | General locally convex dual pairs and distributions to V19; include necessary topology as an explicit bridge |
| 238 | Hilbert spaces and projection | Brezis 5 131–156; Conway I 1–25 | inner-product convention; Cauchy–Schwarz; parallelogram law; orthogonality; convex projection; orthogonal decomposition; orthonormal sets; Bessel/Parseval; Hilbert basis; separability | 232; metric completeness | Do not assume finite or countable orthonormal basis without a hypothesis |
| 239 | Riesz representation | Brezis 5 131–156; Conway I 1–25, II 26–62 | Hilbert-space functional representation; uniqueness and norm; adjoint; bilinear/sesquilinear forms; Lax–Milgram; Riesz–Markov as explicitly identified measure prerequisite/bridge | 233–234,238 | Riesz Hilbert representation and Riesz–Markov are distinct; complex conjugation convention must be fixed |
| 240 | Compact operators | Brezis 6 157–179; Conway II 26–62, VI 166–186; Rudin 4 | relative compactness; compact maps; finite rank; norm-closed compact ideal; composition; compact adjoint; compact embeddings; integral and diagonal examples | 233,236,238–239 | Finite-rank approximation is not automatic for arbitrary Banach targets; flag approximation-property dependency |
| 241 | Fredholm solvability | Brezis 6 157–179; Conway XI 347–368 | I-K alternative; finite-dimensional kernel; closed range; annihilator solvability; Fredholm operators; index; parametrix modulo compact; compact stability; integral equation example | 234,236,239–240 | Do not identify compact Fredholm alternative with all Fredholm theory; unbounded/PDE realizations to later volumes |
| 242 | Spectrum of bounded operators | Conway VII 187–231; Rudin 10 | unital complex Banach algebra; invertibility; Neumann series; spectrum/resolvent; nonempty compact spectrum; spectral radius; polynomial mapping; point/continuous/residual spectrum; compact spectrum | 233,236,240–241; complex analysis prerequisites | Real spaces require complexification; state complex base before nonempty-spectrum theorem |
| 243 | Resolvent and functional calculus | Conway VII 187–231, VIII 232–254, IX 255–302; Rudin 10–12 | resolvent identity; analyticity; Cauchy contour calculus; contour independence; homomorphism; spectral mapping; Riesz projections; continuous calculus for normal/self-adjoint operators | 239,242; Cauchy theorem; enough C*-algebra bridge | Include only C*-algebra machinery required by bounded normal calculus; broad C*-algebra theory deferred with reasons |
| 244 | Bounded self-adjoint operators | Conway IX 255–302; Rudin 12; Brezis 6 157–179 for compact case | self-adjoint/normal/unitary/positive; real spectrum; quadratic forms; positive square root; norm and order; compact spectral theorem; continuous functional calculus; spectral measures; spectral integral; normal spectral theorem scope | 238–243; measure-theory bridge | No unbounded spectral theorem; distinguish compact eigenbasis from continuous spectral resolution |
| 245 | Function-space applications | Brezis 4–6 89–179; Conway III 63–98 and Appendix B; Rudin 5 | Lp equivalence classes; Holder/Minkowski; completeness; density; duality incl p=1 and infinity limitations; reflexivity/separability; weak convergence examples; multiplication/shift/integral operators; variational and Fredholm applications | 232–244; measure integration fixed prerequisites | Sobolev/PDE/unbounded semigroup machinery belongs to later volumes; application must verify its actual hypotheses |

## Cross-source differences that must survive design

* Brezis primarily develops real Banach/Hilbert tools for applications. Conway and Rudin supply complex operator spectrum/calculus. A complex theorem must not silently inherit a real convention.
* Hilbert inner product and adjoint conventions must be selected once; a functional representation map may be linear or conjugate-linear depending on convention.
* Weak compactness is topological compactness. A sequence criterion requires a proved appropriate theorem; nonmetrizable weak-star compactness cannot be reduced to sequences without justification.
* Compact, finite-rank and Fredholm are three distinct properties. Compactness does not generally imply norm approximation by finite-rank maps on an arbitrary Banach space.
* Every Fredholm solvability statement must identify ambient Banach spaces, annihilator/adjoint pairing, range closure and finite-dimensional obstruction.
* Holomorphic calculus applies in a complex unital Banach algebra. Continuous/spectral-measure calculus needs normal or self-adjoint Hilbert operators and cannot be claimed for a general bounded operator.
* Lp duality must distinguish 1≤p<∞, p=∞, measure assumptions, equivalence classes and the use of Radon–Nikodym.

## Material still required

Actual PDFs, copyright pages, full contents, source fingerprints and page mapping; all relevant source statements including unnamed assertions, proof dependencies, examples, exercises selected as necessary, and source differences. Need actual V17/earlier prerequisite bodies to assert inherited prerequisites already supplied. General topology/complex-analysis/measure gaps must be supplied in V18 as bounded bridges or marked open; they cannot be presumed from a volume title.

## Provisional gate decision

B-02 may use this as a design input while B-01 continues. B-01 is IN PROGRESS, not passed. No B-03/04 or B-07 approval is expressed. Only source-body reading can settle every-item coverage. Publisher TOC checking is complete for Brezis chapters 1–6 and Conway I–XI; Rudin fine location not independently checked yet.

Publisher URLs actually opened: https://link.springer.com/book/10.1007/978-0-387-70914-7 and https://link.springer.com/book/10.1007/978-1-4757-4383-8. Conway publisher metadata currently displays ©2007, hardcover first publication 1990, ebook 2019, edition 2; this is an imprint difference to retain rather than silently overwrite the copyright page of the actual PDF.
