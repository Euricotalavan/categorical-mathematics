# V18 B-01 fixed responsibility boundary — v2

2026-11-27 UTC. Decision type: **source responsibility and design boundary fixed for B-02/B-03 preparation; continuing fine-grained source audit remains OPEN.** This fixes what the volume must teach. It does not claim every source paragraph was read, every source candidate was reconciled, or any manuscript was accepted.

## Fixed inputs and honest read states

Readiness v1 and project v4/single-Work/v3 were actually read. All three user-admitted PDFs are now locally present. Their hashes were independently recomputed in `V18-B01-source-semantic-register-v2.json`. Brezis and Conway have text layers with missing closure bars and conjugates; targeted original-page checks were performed. Rudin has no text layer; controller OCR exists, but this role has not yet visually checked Rudin body pages. Therefore Rudin per-item hypotheses remain UNKNOWN. This limits source-completeness claims, not independent mathematical drafting within the fixed chapter responsibilities.

Brezis: 614 PDF pages; printed p = PDF page −15 on the checked body ranges. Conway: 414 PDF pages; printed p = PDF page −14 on the checked body ranges. Rudin: 221 PDF spreads, two printed pages on many spreads; printed/PDF relation must be checked page by page.

Conway actual PDF says Second Edition; publisher page lists hardcover 1990, ebook 2019, copyright metadata 2007. Do not replace an actual PDF copyright date with the publisher web field. Brezis English edition uses copyright 2011 with ebook released 2010. Rudin actual page verification remains on the controller OCR/visual worklist.

## Fixed chapter responsibility

Use the fourteen-chapter table in responsibility-boundary v1 with these binding additions/clarifications:

1. **232:** all norm/completeness/finite-dimensional/quotient constructions have proofs; Brezis11.1–11.3 supply additional source responsibility, not merely an optional appendix. Quotient completeness cannot borrow open mapping.
2. **233:** operator spaces, dense extension and Neumann series; Banach transpose is introduced after dual definition in234. Hilbert adjoint waits for239. Scalar field is always stated.
3. **234:** real dominated Hahn–Banach and complex norm-preserving extension; geometric separation, norm recovery, annihilator/quotient duality; distinguish norm closure on E from weak-star closure on E*. Convex conjugate/Fenchel duality is deferred (below) except elementary convex/lower-semicontinuity definitions needed by237.
4. **235:** arbitrary-family uniform boundedness with Banach domain and normed target (Conway stronger formulation); pointwise limits, dense-set extension, weak boundedness and completeness failure models.
5. **236:** open mapping including exact iterative correction; bounded inverse; closed graph and graph norm; complemented subspaces and left/right inverses; closed-range quotient estimate. The bounded operator special case of transpose range/annihilator formulas is included; general unbounded adjoint theory is deferred.
6. **237:** explicit initial-topology/finite-test/net/compactness bridge, a local proof of arbitrary-product compactness or a precisely verified preceding proof; Alaoglu, Goldstine, reflexivity, weak/weak-star metrizability, closed-subspace/quotient/dual reflexivity, Mazur, uniform convexity/Milman–Pettis, and the full Eberlein–Smulian equivalence with an actual proof. Include Krein–Milman for weakly compact convex subsets of normed spaces with its required proof, rather than silently omit this major source branch. General locally convex formulation stays V19.
7. **238:** complete Hilbert projection/orthogonal decomposition/basis theory, real/complex conventions and nonseparable qualification. First-slot linear convention fixed. Whether a self-contained L2 model is introduced here or all L2 examples wait until245 must be fixed by B02 (cannot borrow 245 completeness silently).
8. **239:** Hilbert Riesz representation, bounded forms and adjoints, Lax–Milgram with Re coercivity over C. Include the real closed-convex variational inequality (Stampacchia) as a worked theorem/application, using a proved contraction principle. Distinguish Hilbert Riesz, Lp Riesz and Riesz–Markov.
9. **240:** compact ideal, norm closure, Schauder, weak-to-strong sequence behavior, Hilbert finite-rank approximation, Arzela–Ascoli and verified kernel examples; Hilbert–Schmidt norm/kernel/basis independence if used. No general approximation-property assertion.
10. **241:** Banach compact Fredholm alternative with all four parts (finite kernel, closed range/annihilator, injective iff surjective, equal nullity/deficiency). General Banach Fredholm parametrices, openness/local constancy of index, compact perturbation invariance and index additivity are included responsibilities; do not mark them optional after accepting Conway XI/Brezis6 comments. Hilbert one-sided variants may be a clearly delimited refinement. Calkin essential spectrum belongs after complex spectral algebra in242, not in a proof in241.
11. **242:** complex unital Banach algebra spectrum, nonemptiness, compactness, radius, polynomial mapping, compact spectral isolation and finite algebraic multiplicity, concrete spectrum partitions; Calkin essential spectrum as a concluding specialization using241. Real spectra use explicit complexification; Brezis real-interval bound is not a complex-spectrum theorem.
12. **243:** holomorphic calculus, resolvent identity, contour independence, algebra homomorphism, spectral mapping/composition and Riesz projections; define the required norm integral before use. Any Gelfand/C-star bridge needed by244 must have a named local location, not an unexplained source import.
13. **244:** bounded self-adjoint compact and general spectral theorems, continuous and bounded Borel calculus, PVM reconstruction/countable strong additivity, positivity/square root, polar decomposition and compact singular values. Bounded normal extension remains an explicit B02 design decision: either include a complete bounded-normal theorem with a local commutative-C-star bridge, or record an explicit deferred responsibility with a reason; do not suggest all Conway IX/Rudin12 is covered by a self-adjoint theorem. No unbounded spectral theorem.
14. **245:** actually construct Lp as a.e. classes, prove norm/completeness, density and interior/endpoint duality/reflexivity/separability with measure assumptions; convolution/Young, translation continuity, smooth regularization/density, essential support and compactness criteria from Brezis4.4–4.5; full direct method, Galerkin/Cea, finite-rank/integral Fredholm and spectral worked applications. Integration prerequisites may be precisely imported if actually verified, otherwise supply the required local bridge.

## Excluded or deferred source branches and reasons

| Source branch | Decision | Destination / reason |
|---|---|---|
| Brezis1.4 Fenchel–Moreau/Rockafellar and conjugate examples | Deferred except needed l.s.c./convex definitions | Convex optimization/duality treatment, later destination number UNKNOWN; not needed for normed-operator core and would add a second theory |
| Brezis2.6 general unbounded adjoints;3.24;7–10 | Deferred | Unbounded operators/Sobolev/PDE/evolution work; local closed-derivative counterexample permitted |
| Brezis4.1 integration results | Import-or-prove prerequisite | Earlier measure theory location UNKNOWN until verified; no claim they are already present |
| Conway II.6 Sturm–Liouville; III.8 Runge | Deferred applications | Depend on ODE/complex approximation theory beyond the selected concrete bounded-operator applications |
| Conway III.7 Banach limits | Include selected original example in234/245 | Distinguishes duality and nonreflexivity; prove any existence/properties actually used |
| Conway III.9 ordered spaces | Selected bridge only | Order definitions needed for positive operators included244; general order-unit theory deferred |
| Conway IV general locally convex theory;V.1–2 dual-pair generality | Normed-space specialization only | General theory and distributions are V19 responsibility; weak topology needed in237 stays local |
| Conway V.6 Stone–Cech;V.9–12 fixed points/Haar/Krein–Smulian | Deferred except any explicitly selected auxiliary theorem | General topology/group integration/locally convex advanced branches; no hidden reliance in the V18 proofs |
| Conway V.7 Krein–Milman,V.13 weak compactness | Include normed-space form | Substantial source responsibilities for237 with full proof |
| Conway V.8 Stone–Weierstrass | Required bridge if used by calculus | Prove usable approximation theorem locally or verify exact prior location |
| Conway VI.2 Banach–Stone;VI.4 invariant-subspace research | Deferred except basic invariant/reducing definitions/examples | Classification/research branches not needed by this volume's core |
| Conway VI.5 weakly compact operators | Include bounded-operator characterization if invoked; otherwise explicit deferred row | Relation to reflexivity belongs237/240, not a license to claim all general weak compact operator theory |
| Conway VII.9 group algebra | Deferred | Harmonic analysis beyond unital spectral core |
| Conway VIII.4–5 ideals/GNS | Minimal definitions only if needed by chosen244 proof | Full representation/C-star course outside scope; no theorem may borrow an omitted dependency |
| Conway IX.7 von Neumann algebras;IX.10 multiplicity classification | Deferred | Operator algebra and classification extension; bounded spectral theorem itself stays included |
| Conway X; Rudin13 | Deferred | Unbounded spectral/evolution theory outside V18 |
| Conway XI.5–6 path components/finer spectral classification | Selected consequences only | Index local constancy/essential spectrum included; full classification and research extensions deferred |
| Rudin1 general TVS,3 general convex/dual-pair structure | Normed specializations included, general theory deferred | V19 interface; fine hypotheses still require OCR+visual source check |
| Rudin5 fixed-point/Haar/vector-measure applications | Selected application rows only | Retain examples serving current normed/operator tools; general topological group/vector integration topics deferred |
| Rudin10 Lomonosov;11 full commutative algebra applications;12 ergodic/invertible-group extensions | Minimal calculus bridge and selected bounded-operator consequences only | Full research/operator-algebra/ergodic developments not automatic from reference chapter admission |

These are topic-level decisions, not an assertion that every unnamed paragraph in these ranges is catalogued. The per-item table must retain candidates that refine these decisions, with exact proof/example locators and manuscript landings as they become available. A newly found relevant item is added to the responsibility table; omission is not normalized by the present list.

## Gate and continuing work

B02 design and representative calibration may proceed on the fixed responsibilities. B01 every-item source coverage remains partial: 106 actually inspected responsibility rows in semantic-register v2, plus the 118 earlier planning candidates; these are different evidence classes and must not be summed as a completeness measure. Brezis unnamed proofs/examples and full Conway/Rudin detailed reconciliation remain OPEN. B04 chapter work must resolve the relevant source rows and exact manuscript locations before those chapters pass refinement. B05 cannot pass with unresolved relevant source-completeness items. Nothing here is an entire-volume or B07 mathematical signature.
