# V18 B-02 independent dependency review / binding amendments — v1

2026-11-27 UTC. Input actually read: `v18/records/b02/V18-B02-candidate-design-v1.md`; 48670 bytes; SHA-256 `1852011d6ecbad73224d16523037072f91748535f9ab144d4b21741eef2d6106`. Reviewer: isolated refinement task. Model/mode in this task not independently verifiable; no switch claimed. Read the candidate full narrative and source scopes, then matched the critical interfaces to original Brezis/Conway pages. Controller decisions received afterwards are included explicitly below. No mathematical whole-volume acceptance is expressed.

## Decision

**Dependency design accepted when read as candidate-v1 plus these binding amendments and B01 fixed-boundary-v3.** The unamended candidate-v1 is superseded on the listed points. B02 must fix the consolidated version/hash before B04 dispatch. Exact later manuscript labels remain planning, and source exhaustiveness is not implied. B03 may calibrate the fixed sections with clearly marked input statements; those cards are dependencies, not claims the other chapters were already written.

| ID | Candidate location / issue | Binding final design | Verification / downstream impact |
|---|---|---|---|
| D01 | §4 dual/adjoint naming correct, B03 sample F later uses X' | Use X* for continuous dual, T' for Banach transpose, T* for Hilbert adjoint. Sample F notation must follow this too | Prevents complex-linear versus conjugate-linear Riesz map ambiguity; 234,239–245 |
| D02 | 237.3 product compactness input was not a fixed proof | Prove Tychonoff via ultrafilters locally before Alaoglu; include all filter extension/compactness equivalence ingredients | No unverified dependency on V19 or unnamed prior topology theorem |
| D03 | 237.6 Eberlein–Smulian optional | Full theorem/proof included, plus reflexive sequence consequence; source proof supply ConwayV.13, since Brezis explicitly omits difficult converse | Distinguish compactness from sequential compactness; no sequence-only weak topology |
| D04 | 237 uniform convexity/Krein–Milman coverage absent | Add uniform convexity, Milman–Pettis, weak+norm strong convergence and normed-space Krein–Milman | Source responsibilities admitted in B01v3; general LCS form remains V19 |
| D05 | 236 complemented subspaces/inverses absent | Add bounded projections, complemented kernel/range and bounded left/right inverse criteria | Required by general Fredholm parametrix and index proofs |
| D06 | 241.6 Atkinson/index optional | Full bounded Banach Fredholm/Atkinson, compact stability, openness/local index constancy and additivity included. Use Hilbert-specific source only for Hilbert refinements | Core proof depends on 234/236/240, never on future spectral theorem |
| D07 | 241 Calkin route risks future algebra dependency | Parametrices modulo compact proved directly in241; define quotient ideal algebra in242 before essential spectrum | No 241→242→241 cycle |
| D08 | 243 contains holomorphic only;244.3 redefines continuous calculus | 243 includes `sec:243-continuous-calculus`: self-adjoint quadratic-form lemma and inverse permanence; characters/maximal ideals; local Stone–Weierstrass; normal norm=radius; continuous normal calculus. 244 consumes it for cyclic-L2/PVM/spectral theorem | 243 proof never invokes244; bounded-normal case included explicitly |
| D09 | 240/242/244 and B03 sample use L2 before245 construction | 238 local complex-L2 bridge, using controller-verified real V16Ch218 printed150–154 or a self-contained proof. State measurable a.e. equality, completeness, complex inner product explicitly | All early L2 examples have prior support. General Lp remains245 |
| D10 | 245.1 named only duals, but construction/completeness assigned there | Add actual Lp construction/norm/completeness, density, separability/reflexivity, endpoint distinctions, and a table of measure assumptions | Brezis global sigma-finite convention explicit; V16 RN finite signed proof needs complex assembly |
| D11 | 245 missing Brezis4.4–4.5 branch | Add convolution/Young, reflected-kernel pairing, essential support, local smoothness/mollifiers, translation continuity, Lp regularization/density, compactness via translation+tail control | These are source responsibilities with worked applications, not names in a reference list |
| D12 | 239 no Stampacchia and contraction prerequisite | Add real closed-convex coercive variational inequality and full contraction argument before Lax–Milgram/minimization application, or explicitly map it to245 with exact proof | Retain real versus complex variant conditions and actual strong/weak inequalities |
| D13 | 242 radius formula may reference243 integration | 242 supplies minimal contour/norm integration and radius proof;243 extends it. No forward-reference used as proof | Maintains linear reading |

## Conditions retained from the good candidate route

Quotient completeness is proved before open mapping; closed-range quotient estimate proved before Fredholm; inverse permanence for a closed star-subalgebra proved before any character-spectrum identification with operator spectrum; arbitrary convergent nets are not asserted to have a globally bounded range; normal polynomials are not silently treated as self-adjoint. Compact spectral eigenbasis includes kernel and separability/nonseparable qualifications. Every import is a verified exact prior theorem or a local bridge.

## Receipt and handoff

This task actually read candidate-v1 at the hash above; it accepts the amended dependency route, not a completed textbook. Next unique action: controller/expansion consolidate D01–D13 and B01v3 into a fixed B02 file/hash, return that receipt, then continue B03 fixed samples through thickening/refinement. No prior frozen volume or source ZIP was modified. No source PDF/TeX pair exists for this design record, and no build/visual/math final pass is claimed. OPEN: source named/unnamed item reconciliation continues; exact prior V16 source hash/location in the controller's verification manifest must accompany inherited proof imports. No additional user decision is requested by this task.
