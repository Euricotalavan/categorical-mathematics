# V18 B07 round2 Chapter238 repair receipt

2026-11-27 UTC. **Complete candidate delivered for the same B07 reviewer's recheck; repair author does not issue B07 PASS.** Scope is the newly identified converse parallelogram criterion and the coordinator's directly related example clarification. Main, B06 and current B07 production sources are untouched.

## Actual baseline and candidate

|File/state|Bytes|SHA-256|
|---|---:|---|
|Input `v18/b07/book/manuscript/ch238.tex`|31120|fcd3d1b1aa880c972b8edd8bb7b811017d9160599ffe7847660bb3a5fae823a5|
|Candidate `v18/records/b07/repairs/round2/ch238.tex`|33867|6d2fd7ac74218f0e0cd49112c0404f117acbe46a5f7d698a532740190f512d02|

Input bytes/hash were independently recomputed and match the Chapter238 entry in B06-FIXED, whose SHA is71fa22df8e62a7a1ed662731652b9d56f8349d98c0f56e89f87b0195577b85aa. This is the specified current B07 baseline; the repairs to242/243 belong to round1 and are neither replaced nor included here.

## Before / impact / after

Before, `prop:238-polarization` proved only necessity of the parallelogram identity and uniqueness/polarization when an inner product was already given. The max-norm example used this necessity correctly, but the in-scope reverse characterization from Brezis Chapter5 Comments Theorem5.12 / Exercise5.1 was absent.

After the existing sign explanation, candidate line65 adds `thm:238-jordan-von-neumann`: a real or complex norm is induced by an inner product iff it satisfies the parallelogram identity for every pair. It explicitly separates an inner-product norm on any normed space from the additional completeness required for a Hilbert space. The zero space is included without a nonzero restriction.

The full original proof defines the continuous symmetric real polarization B. Subtracting the parallelogram identities at (x+y,z) and (x−y,z) proves B(x+z,y)+B(x−z,y)=2B(x,y). Setting z=x supplies doubling, and the midpoint substitution then supplies additivity. Integer/rational homogeneity and continuity supply all real scalars. Real positive definiteness is exactly B(x,x)=||x||².

For complex scalars, Jx=ix preserves the norm. Real polarization gives B(Jx,Jy)=B(x,y), then B(Jx,y)=−B(x,Jy) and B(x,Jx)=0. The reconstruction <x,y>=B(x,y)+iB(x,Jy) is linear in the first slot, conjugate symmetric and positive definite, and gives the previously printed polarization signs. Its norm is the given norm, so the completeness statement follows directly. No spectral/projection theorem or later chapter is used.

The existing `ex:238-nonhilbert`, now line105, retains its max-norm calculation and adds the same e1/e2 computation in finite-exponent lp₂: left side2·2^(2/p), right side4. It adds the Lp instance only under the explicit existence of two disjoint measurable sets of positive finite measure, using their normalized indicators. Thus no false unrestricted measure-space claim is made. The already present maximum-norm example handles infinity.

## Actual affected checks and evidence

The inserted proof was reread independently of the source exercise hints. Checked the subtraction identity, midpoint/additivity, negative/rational/real homogeneity, J²=−I signs, complex linearity, conjugate symmetry, diagonal positivity, norm equality and zero-space scope. The first-slot example <1,i>=−i remains consistent. The original completion proposition immediately afterward still has precisely its original assumptions/proof. No later theorem is needed to justify the new result. The example calculations give an obstruction for every p≠2 within the stated range and hypotheses.

All original chapter labels remain in the same order. The sole new label is `thm:238-jordan-von-neumann`. No original theorem/proof/example/problem was removed. The exact diff and before/after text are in `ch238.patch` and `repair-manifest.json`. There is one inserted theorem/proof and a direct extension of the existing example, with no wider source branch added. No PDF compilation or page/layout QA is claimed.

The actual fixed Brezis PDF text layer was read at printed144/PDF159 (Comments Theorem5.12) and printed147/PDF162 (Exercises5.1–5.2). Source SHA1575d1bf37916451e25dcec1d683ba20818466b93bec56ec751eb7dbc647e21f. `suggested-source-map-additions.json` gives exact candidate labels/lines, source positions and the pending-B07 semantic state. The real-source obligation is supplied with an original complete complex extension. This closes one specifically discovered known omission if the B07 reviewer accepts it; it does not retrospectively make the earlier source inventory exhaustive.

## Handoff

Role: independent refinement, B07 round2 RETURN correction in authorized V18 B single Work (232–245 after231). Unique candidate for this correction is this directory's ch238.tex. Complete candidate/diff/manifest/source-map addition/build script/this receipt are delivered to coordinator in the shared workspace. Actual delivery onward and reading/recheck acknowledgement remain separate. Next action: same B07 reviewer checks the new theorem/proof and associated example; if accepted, coordinator merges this exact chapter together with the independently accepted round1 pair and regenerates the uniquely versioned source/PDF set. No B07 final approval is issued here.

OPEN: same-reviewer mathematical recheck and successor PDF/layout/hash verification; inherited source-exhaustiveness UNKNOWN remains. Model/mode unverified. Prior Git c27f36064ae039a23e03a7093684bfbf789179ef and adopted R1 template commit8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3 / ZIP SHA5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732 remain inherited authority and unchanged. No source derivative is released, no remote save or publication claimed, and no frozen volume/author draft/tool ZIP changed. Do not overwrite current production without coordinator merge, reopen unrelated topics, or interpret this as the sole final mathematical signature. No user intervention is required.
