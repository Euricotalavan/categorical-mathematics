# Verified transition checkpoints

These records identify private editable work checkpoints. The current source and paired PDF are identified by the release manifest. The checkpoints are snapshots for recovery and review.

| Stage | File | Version | SHA-256 |
| --- | --- | --- | --- |
| B03 | `V18-B03-Checkpoint-v1.zip` | 0 | `db1121a10982cb93ffa338d2cce582c903b82ee42bb6f512eb255b0547b7f415` |
| B04 | `V18-B04-Progress-v1.zip` | 0 | `fde495b0fa3e27057f805fdf0110b14364b9dd09a31d9a1e712a4ee2bccd6a98` |
| B05 | `V18-B05-Integrated-Checkpoint-v1.zip` | 0 | `1610afb9b66ef5343b479aa995f1ccc4073c42ed08b64004ac44c1e361c05e9a` |
| B06 | `V18-B06-Paired-Checkpoint-v1.zip` | 0 | `cde29afba84b916e65f97b3b1ac4a5fd08094c987a6da2b46cff4dc992f01ca4` |

The retained bytes were recovered, matched against the recorded digests, and tested as ZIP archives. The B03 sample includes the paired calibration PDF. The B05 fixed integrated source includes the independent review receipts that authorized it to enter layout. The B06 checkpoint fixes the type-set candidate received at the start of independent mathematical audit.
