# V18 design and representative-section decisions

2026-11-27 Taipei. The user assigned the ordinarily user-facing reader decisions to the coordinator. The coordinator approved the dependency design and use of the separately reviewed representative sections. The coordinator does not provide a mathematical final signature.

## Fixed design

The operative B-02 design is `V18-B02-design-v2.md`, SHA-256 `fa41c1e63d69b3e39a31a87cb410f4fa98eda70e96fd3fc034f93a9da0010be7`, read with the independently reviewed B-01 fixed boundary v3, SHA-256 `c0305595e986005a2fc166ca7b968b114267e6a7600d8ab51ff9a6c69735fe59`, and the independent dependency review, SHA-256 `44d3ad6aca32d1149c9f7fbcf7b2cf77ada9598a31ad3121c1a0ed92cbf092e0`. Where design v2 still describes a choice as open, the following specific decisions apply.

1. Chapter 237 includes the full relative Eberlein–Šmulian theorem and the normed-space Krein–Milman theorem. The proof of the first is original and independently checked before acceptance. The relevant Brezis and Conway source locations both state a version without furnishing the full proof. A local ultrafilter proof supplies Tychonoff before Alaoglu.
2. Chapter 238 introduces the complex Hilbert space $L^2$ before Chapters 240 and 242–244 need it. Chapter 239 distinguishes Hilbert Riesz from the measure representation used in 244, and treats coercive forms and a real closed-convex variational inequality.
3. Chapter 241 independently proves the bounded Banach Fredholm theory, index and Atkinson. Chapter 242 introduces the Calkin-algebra essential spectrum once the complex algebra structure is available.
4. Chapter 243 proves the holomorphic and continuous normal calculi. No step of either construction uses the spectral theorem of Chapter 244. Chapter 244 constructs spectral measures and the bounded normal representation, with self-adjoint, positive and compact specializations.
5. Chapter 245 develops the general $L^p$ setting and application workflows using verified V16 prerequisites, with explicit hypotheses for duality and compactness. It includes genuine applications to equations with a compact operator and variational approximation.
6. Every chapter is a distinct part of the same work. Agents write candidate copies in separate locations. Only a version with records of both proof development and independent refinement can be called accepted for integration.

This fixes the teaching responsibilities and stage route. The open source-level review remains explicit. Its extent will be stated independently of the textbook proof review. Page plausibility will be judged from the corresponding portions of sources and the compiled teaching units. The chapter ranges in the planning document are capacity estimates.

## Adopted B-03 sections

- Sections 234.2–234.3. Adopt the refined ch234 calibration source, SHA-256 `90d2fc1189dcd7d113d474512c3f1e57a082e64efdcf23a52a1ec53be78ee645`. Preserve the phase argument in complex Hahn–Banach, the norm-recovery distinction, and the explicit quotient-distance and closest-point examples.
- The continuous calculus for a normal operator (planned §243.6). Adopt refined spectral.tex, SHA-256 `aaa4fe0804f2f80f08472ed7ad1cf59487ed16e660ea52ef27457c2bf78e28f3`. Preserve the derivation of inverse permanence and the scalar approximation estimates. Chapter 242 must provide the explicitly named algebraic prerequisites, including the spectral-radius formula.
- The isolated ReadFlow PDF confirms the excerpt presentation. Its counters stand in for chapters outside the excerpts. Full manuscript placement and cross-references will be checked again on the integrated body. Proof-development and refinement receipts name the inputs and exact revisions.

## Next active stage

B-04 chapter drafting, proof development and refinement. The sole editable textbook body will be the integrated copies of ch232.tex through ch245.tex. Main verification will check labels, source-to-body correspondence and frozen reader decisions. B-05 will consume the bracketed chapter receipts and the fixed integrated body. B-06 begins after B-05. B-07 is fresh, independent proof-development review. B-08 produces the recoverable delivered source and matching PDF after verified sign-off.
