# Volume 18 fixed inputs

Taipei date 2026-11-27. The user selected the B single-Work variant for Volume 18, approved the listed copies for this work, delegated the usual reader decisions to the coordinator, and authorized all eight stages. The approval was received in this conversation. The source register below records what was actually retrieved. The publication package can carry this register and the independent mathematical exposition.

## Readable literature files

| ID | Actual edition landmark | PDF pages | Bytes | SHA-256 | Origin |
| --- | --- | ---: | ---: | --- | --- |
| V18-S01 | Haim Brezis, Springer English first edition, ©2011. eISBN 978-0-387-70914-7 | 614 | 2,608,077 | `1575d1bf37916451e25dcec1d683ba20818466b93bec56ec751eb7dbc647e21f` | University of Toronto Math file approved by user. Publisher DOI 10.1007/978-0-387-70914-7 |
| V18-S02 | Walter Rudin, McGraw-Hill second edition, international 1991 printing. Ordering ISBN 0-07-100944-2 on the international copyright page | 221 two-up spreads | 24,650,200 | `aa31e887a2533fd5d6e60d15d072f8a694c31b55e268847999ead8cf284e10b2` | McGill CS file approved by user. US-edition bibliographic ISBN 0-07-054236-8 is recorded separately |
| V18-S03 | John B. Conway, Springer second edition, corrected fourth printing 1997 of the 1990 text. Print ISBN 0-387-97245-5 | 414 | 7,279,538 | `c224068060b1386543141a9469d2fd32f8e39f462f09e76977cee2b82f51412d` | Mustansiriyah University course file approved by user. Publisher second-edition DOI 10.1007/978-1-4757-4383-8 identifies the separate eBook manifestation |

Brezis print page $p$ corresponds to PDF page $p+15$ for Arabic-numbered pages. Conway print page $p$ corresponds to PDF page $p+14$. Rudin uses scanned spreads and printing interrupts the page sequence at the part divisions. Its source citations use the visible printed number, with explicit spread coordinates when established. Formula glyphs in either OCR or original PDF text layers require inspection against rendered pages.

The extractor is the frozen project archive math-extractor-v0.4.zip, SHA-256 `c2d47e097447a836bcad63d5a030106b1ec261bac4ffe32a6aecc783aca244f3`. Rules and OCR were used privately to aid positioning. No model invocation was made by the extractor. The editable volume and its handoff contain original mathematics exposition, independent paraphrase, and citation locators.

## Published chapter continuation and verifiable prior material

Fixed repository commit `c27f36064ae039a23e03a7093684bfbf789179ef`.

- V17 published index `archive/v17/b08-audited-2026-11-27/README.md`. The published source ZIP SHA-256 is `5be11f092bac55f7c0c0f51215c496630f6d1c576b07740341d882c1f2be8c78`. It was retrieved and its hash checked against the repository's SHA256SUMS. The actual driver `book/layout/study/v17.tex` uses initial counter 223, inputs ch224 through ch231 in order, then enters back matter. The final actual manuscript heading is in `book/manuscript/ch231.tex`. Hence V18 starts at 232. The V18 planning list contains 14 titles, so its last chapter is 245.
- V16 published source `archive/v16/b08-expanded-2026-11-27/V16-Expanded-ReadFlow-R1-Source.zip`, SHA-256 `9e17716820f52f820397016f300922ed02855a0feae2c5dbf37c3c366ddb94c5`; retrieved bytes match. The actual theorem locations within its manuscript are below.

| Prerequisite | Already published location | How V18 uses it |
| --- | --- | --- |
| Carathéodory construction | V16 Ch. 208, `manuscript/ch208.tex` line 112 | The Borel construction in Chapter 244 |
| Product measure, Tonelli and Fubini | V16 Ch. 215, `manuscript/ch215.tex` lines 49, 132 and 175 | Integral operators in Chapters 240 and 245. The finite-rectangle density argument is proved in Chapter 240 |
| Dominated convergence | V16 Ch. 214, `manuscript/ch214.tex` line 94 | Scalar measure limit arguments in Chapters 244–245, with measures and majorants specified |
| Radon–Nikodym | V16 Ch. 217, `manuscript/ch217.tex` lines 99–109 | Finite signed absolutely continuous measure with a sigma-finite positive reference measure. Complex measures use real and imaginary parts |
| Hölder and Minkowski | V16 §218.2, `manuscript/ch218.tex` lines 79 and 96 | Scalar $L^p$ bounds. Absolute values and the same real inequalities handle complex scalars |
| Completeness of $L^p$ | V16 §218.3, `manuscript/ch218.tex` lines 150–154 | Complex $L^2$ bridge in V18 Ch. 238 and general complex $L^p$ bridge in Ch. 245 |
| Continuous approximants | V16 Ch. 219, `manuscript/ch219.tex` line 252 | Density of (C_c) in Lebesgue (L^1) on the stated domain. Any broader density needed in V18 has its own argument |

## Workflow, layout and responsibility

V18 uses curriculum and reference dossiers v4.1, production v4, literature workflow v3, and the B single-Work appendix v1. Layout baseline is ReadFlow R1 artifact commit `8b9dc7f3749de81e47de9f525d7c5e0b3f8036c3`, Library edition 3, SHA-256 `5f91243f32d7e76d643575a76488d5b1e26d4909aa3017bd812cb526bf5ed732`. The actual retrieved 7,007,679-byte ZIP was verified in this Work. The isolated layout engineer recorded the derivative font-path patch and the necessary font and tool dependencies. Producing the stub does not stamp the mathematical manuscript or count as B-06.

The coordinator manages version control, readiness and reader decisions. Expansion consists of three separate chapter-drafting tasks with isolated paths. Refinement and proof-development are independent tasks. Layout belongs to the layout task. The requested execution profiles of expansion, both drafting contributors, refinement and layout were GPT-6.1 Sol with High. Actual backend routing and reasoning mode were not independently inspectable by the agents. The proof-development task inherited the main task settings and reported the same verification limit. B-07 receives a fresh proof-development task after the B-06 PDF and source are fixed.
