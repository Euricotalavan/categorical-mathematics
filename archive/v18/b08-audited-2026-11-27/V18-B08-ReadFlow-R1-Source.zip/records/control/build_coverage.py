#!/usr/bin/env python3
"""Relocate the reviewed source responsibilities to exact manuscript lines."""

import argparse
import csv
import json
import re
from pathlib import Path

LABEL = re.compile(r"\\label\{([^{}]+)\}")


def label_locations(chapters):
    locations = {}
    for chapter in range(232, 246):
        path = chapters / f"ch{chapter}.tex"
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if line.lstrip().startswith("%"):
                continue
            for name in LABEL.findall(line):
                if name in locations:
                    raise ValueError(f"Duplicate label {name}")
                locations[name] = (chapter, path.name, line_number)
    return locations


def latest_maps(directory):
    latest = {}
    for path in sorted(directory.glob("*source-landings-v*.json")):
        stem, version_text = path.stem.rsplit("-v", 1)
        if version_text.isdecimal():
            candidate = (int(version_text), path)
            if stem not in latest or latest[stem][0] < candidate[0]:
                latest[stem] = candidate
    return [entry[1] for _, entry in sorted(latest.items())]


def read_rows(path):
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, list):
        return payload
    for key in ("rows", "landings", "responsibilities", "items"):
        if isinstance(payload.get(key), list):
            return payload[key]
    raise ValueError(f"Unrecognized source landing map {path.name}")


def field(row, names, fallback):
    for name in names:
        value = row.get(name)
        if value:
            if isinstance(value, str):
                return value
            return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return fallback


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--chapters", type=Path, required=True)
    cli.add_argument("--maps", type=Path, required=True)
    cli.add_argument("--output", type=Path, required=True)
    cli.add_argument("--unresolved", type=Path, required=True)
    args = cli.parse_args()

    actual = label_locations(args.chapters)
    result = []
    unresolved = []
    for mapping in latest_maps(args.maps):
        for row in read_rows(mapping):
            labels = row.get("labels") or row.get("label") or row.get("manuscript_label")
            if isinstance(labels, str):
                if labels in actual:
                    labels = [labels]
                else:
                    labels = [part.strip() for part in re.split(r"[,;]", labels)]
            if not labels:
                unresolved.append({"map": mapping.name, "reason": "No fixed label", "row": row})
                continue
            for label in labels:
                if label not in actual:
                    unresolved.append({"map": mapping.name, "reason": f"No actual label {label}", "row": row})
                    continue
                chapter, filename, line = actual[label]
                result.append({
                    "chapter": chapter, "filename": filename, "line": line, "label": label,
                    "source": field(row, ("source", "source_location", "literature"), "See reviewer map"),
                    "responsibility": field(row, ("responsibility", "item", "topic", "coverage"), "See reviewer map"),
                    "proof_or_read_state": field(
                        row, ("definition_statement_proof_example", "manuscript_status", "state", "status", "source_read"),
                        "See reviewer map and chapter proof receipt",
                    ),
                    "reviewer_map": mapping.name,
                })

    result.sort(key=lambda row: (row["chapter"], row["line"], row["source"]))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.unresolved.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(
            stream, delimiter="\t",
            fieldnames=["chapter", "filename", "line", "label", "source", "responsibility", "proof_or_read_state", "reviewer_map"],
        )
        writer.writeheader()
        writer.writerows(result)
    args.unresolved.write_text(json.dumps(unresolved, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"{len(result)} relocated source responsibilities. {len(unresolved)} pending locator entries.")
    raise SystemExit(bool(unresolved))


if __name__ == "__main__":
    main()
