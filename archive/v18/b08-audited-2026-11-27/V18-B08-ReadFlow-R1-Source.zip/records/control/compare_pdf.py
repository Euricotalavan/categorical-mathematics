"""Verify that a rebuilt or retained PDF has the same visible content and navigation."""

import argparse
import hashlib
import json
from pathlib import Path

import fitz


def canonical_link(link):
    values = []
    for key, value in sorted(link.items()):
        if key in ('xref', 'id'):
            continue
        if isinstance(value, (fitz.Rect, fitz.Point)):
            value = [round(coordinate, 4) for coordinate in value]
        values.append((key, value))
    return values


def compare(first_path, second_path):
    first_path, second_path = Path(first_path), Path(second_path)
    report = {
        'first': first_path.name,
        'second': second_path.name,
        'first_sha256': hashlib.sha256(first_path.read_bytes()).hexdigest(),
        'second_sha256': hashlib.sha256(second_path.read_bytes()).hexdigest(),
        'issues': [],
    }
    issues = report['issues']
    with fitz.open(first_path) as first, fitz.open(second_path) as second:
        report.update(first_pages=len(first), second_pages=len(second))
        if len(first) != len(second):
            issues.append('different page count')
        if first.get_toc() != second.get_toc():
            issues.append('different outline')
        if first.get_page_labels() != second.get_page_labels():
            issues.append('different page labels')
        for number, (left, right) in enumerate(zip(first, second), 1):
            if left.rect != right.rect:
                issues.append(f'page {number}: different geometry')
            if left.get_text() != right.get_text():
                issues.append(f'page {number}: different extracted text')
            if [canonical_link(link) for link in left.get_links()] != [canonical_link(link) for link in right.get_links()]:
                issues.append(f'page {number}: different links')
            if left.get_pixmap(dpi=108).samples != right.get_pixmap(dpi=108).samples:
                issues.append(f'page {number}: different rendered pixels at 108 dpi')
    return report


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('first')
    cli.add_argument('second')
    cli.add_argument('--report', type=Path, required=True)
    args = cli.parse_args()
    result = compare(args.first, args.second)
    args.report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    raise SystemExit(bool(result['issues']))
