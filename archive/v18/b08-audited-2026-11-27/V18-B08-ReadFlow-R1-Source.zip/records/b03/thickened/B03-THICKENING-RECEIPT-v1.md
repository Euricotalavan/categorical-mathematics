# V18 B-03 proof-development receipt

V18 · B single Work · calibration only · 2026-11-27, Taipei. The proof-development reviewer read the two complete fixed candidates independently and prepared minimal replacement files for refinement. Runtime model and reasoning settings are unverified. The coordinator retains the formal calibration gate and records the accepted replacement versions.

| Calibration | Fixed input and SHA-256 | Replacement and SHA-256 | Unified patch and SHA-256 |
| --- | --- | --- | --- |
| 234, complex Hahn–Banach, norming, distance | records/b03/expansion/ch234-calibration-v1.tex · 37b1a91d24c8aea24c5fea60f3e3c4150a8378d80fa077e0778b8ab160aa5587 | records/b03/thickened/ch234-calibration-v1.tex · fa760ba747f47d0a5c8a88ec8991fd628223c89b17ccaddf4bc1c4fde99b7348 | records/b03/thickened/ch234-calibration-v1.patch · 94f4a1f28c4722694a1a216e40447b1b949ddffc29d36026b1e7b2af16f98555 |
| 243, normal continuous functional calculus | drafts/calibration/spectral.tex · ad4c7e118bc9b22f352d19bc3cf71fb04788553301c621244ec00813586833d2 | records/b03/thickened/spectral.tex · 9de87bbbb40600288429c8600df5b091e469f5317aae1c894ff296607d901ebc | records/b03/thickened/spectral.patch · 059e1055a811be3d7f2158c29c26fdbd709308f75d5acf4bf45cd1f9322b29e4 |

## Chapter 234

| Original lines | Review evidence |
| --- | --- |
| 21–97 | Complex homogeneity follows from real linearity and the identity F(ix)=iF(x). The real part of g(im) is minus the imaginary part of g(m). Rotation by the conjugate phase gives the exact bound, including the case F(x)=0. The proof correctly assumes only the real sublinear extension theorem and the complex seminorm properties. |
| 99–151 | Upper bound for the extension comes from domination and lower bound from restriction. The line-generated norming functional is well defined for the nonzero vector. The zero vector and zero space use the admissible zero functional. |
| 153–226 | Distinct norming functionals are now exhibited by evaluating at (1,0). Closure preserves the distance and annihilator. The quotient identifies the positive distance with the norm of a nonzero coset. An approximating sequence from the original subspace establishes exact norm one for the pullback. |
| 228–304 | The diagonal distance is attained by taking the midpoint even over complex scalars. The dense proper subspace example is correct. The fixed functional on c0 does not attain its norm. The replacement uses its closed kernel to give a positive distance with no nearest point, via the explicitly computed approximating sequence. The final separation proof uses the positive real value of the functional, so the assertion makes sense over either field. |

The integrated section needs the preceding real Hahn–Banach proof and the Chapter 232 quotient construction. Cross-reference ch:232 must be resolved with the integrated chapter label. The original role proof was preserved, with an application added to clarify a genuinely different distance case. All twelve labels retain their original order. The coordinator is preparing the combined sample build.

## Chapter 243

| Original lines | Review evidence |
| --- | --- |
| 6–47 | Closure of the polynomial algebra preserves commutativity and adjoint. The phase-adjusted quadratic-form polarization gives the norm formula, including the zero form. The nonreal resolvent estimate controls the range and the adjoint kernel. The inverse permanence proof uses the lower bound of an already invertible operator and a Neumann series for A*A. It requires no spectral measure or spectrum-preservation assumption. |
| 50–65 | Maximality supplies a proper closed ideal and a division quotient. The revised proof establishes the division-to-scalars step using the bounded left multiplication operator and the nonempty operator spectrum. Identity normalization and the Neumann spectral bound can be inherited from Chapter 242. The adjoint rule for characters follows by decomposition into two self-adjoint parts. |
| 67–78 | The two finite-cover lattice steps are valid. The revised proof defines Bernstein polynomials, calculates the weighted variance and tail bound, and then derives uniform approximation of absolute values. Singletons and zero-width intervals are accounted for. |
| 80–110 | Adjoints and commuting polynomial evaluations give precisely the scalar values at all spectral points. The replacement proves the operator C* identity from the quadratic form, then uses dyadic powers and the previously proved spectral-radius limit. Existence, range, uniqueness and spectral mapping follow from norm preservation and inverse permanence. |
| 113–118 | The multiplication example now verifies the spectrum via bounded reciprocal and normalized indicators, including the two endpoints. The Jordan example explicitly identifies the resolvent and applies the two scalar Cauchy formulas. |

All seven labels retain their original order. An isolated six-page XeLaTeX probe using the pre-existing R1 style and Chapter 243 counter compiled. It raised no overfull boxes or missing-character diagnostics. This probe has no status as the B-06 integrated artifact or B-07 whole-volume audit. The student-facing prerequisites are the Hilbert adjoint, the closed-range estimate, Hahn–Banach, scalar Cauchy integration, and the Chapter 242 nonempty-spectrum and radius arguments. The contour and continuous calculi agree on the shared holomorphic domain by the integral argument to be checked in the whole Chapter 243.

## Pass criteria learned from both fragments

The conditional proof steps stay beside the result they support. A compressed estimate keeps its denominator, limit mode, quantifier and reason. Both samples benefit from a completely worked example that forces the reader to use those steps, followed by a failure case of a closely related assertion. The original candidates and their label identities are retained. Next recipient is the independent refinement role. No final mathematical audit has taken place.
