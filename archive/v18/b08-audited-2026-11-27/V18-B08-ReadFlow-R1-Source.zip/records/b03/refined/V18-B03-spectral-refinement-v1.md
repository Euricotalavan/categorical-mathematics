# V18 B-03 spectral calibration — independent refinement v1

Input actually read before any historical thickening review: `v18/records/b03/thickened/spectral.tex`, 12649 bytes, SHA-256 `9de87bbbb40600288429c8600df5b091e469f5317aae1c894ff296607d901ebc`. Expected controller hash matched: True. Scope: section243 continuous calculus only. First independent pass made against the actual full section. No prior self-assessment or thickening report was read to guide this pass.

Decision: **PASS for this representative section after the two small patches in refined/spectral.tex; not B04 whole-chapter or B07 whole-volume acceptance.** This assumes the exact named earlier inputs are supplied in the final sequential manuscript as required below. The calculus proof is mathematically complete within those inputs. The sample may be used as the depth/clarity calibration; its shortness does not set a volume page limit.

## Findings / corrections

| ID | Original location and impact | Revised text / disposition | Recheck evidence |
|---|---|---|---|
| S01 | Character lemma final clause only said operator subalgebra 'also adjoint closed'; inverse permanence additionally needs closure and inherited operator norm | Added norm closed, adjoint closed, contains I, inherited operator norm | Final character-star argument now legitimately invokes previous inverse-permanence lemma; application C*(N) satisfies all conditions |
| S02 | Example notation absolute value of N could seem to import later244 positive square root | Explicitly defined it as evaluating the continuous absolute-value function | Example now uses current theorem only; positivity/root uniqueness remain244 responsibilities |

## Independent proof checks

* Generated algebra: adjoint closure follows from taking conjugate/reversed polynomial coefficients; normality makes all polynomial generators commute; closure preserves multiplication and adjoint. Identity is included. Nonzero H avoids the empty-spectrum/zero-unit degeneracy.
* Self-adjoint norm: phase rotation makes the cross term real; polarization plus parallelogram gives the sharp bound. The nonreal-resolvent estimate gives closed range; kernel of the conjugate-shift adjoint gives density, hence surjectivity. No spectral measure is used.
* Inverse permanence: invertible A gives m>0 and quadratic-form bounds for Q=A*A; I-Q/M has norm at most1−m²/M<1. Neumann series in the same complete algebra supplies Q inverse and A inverse. No assumed spectral permanence is hidden.
* Characters: proper maximal ideal is closed using Neumann invertibility near I; quotient is a nonzero Banach division algebra. Left multiplication by b is a bounded operator; nonempty operator spectrum from242 yields b scalar. Composing the quotient map gives the desired character. Character values are spectrally bounded without initially assuming continuity. Corrected final clause gives star preservation.
* Scalar approximation: Bernstein weights, first/second moments and tail estimate establish uniform interval approximation; lattice closure and the double finite-cover argument establish Stone–Weierstrass. The g=0 and K empty cases are treated.
* Normal norm=radius: C-star identity gives normal-square norm equality, iterated dyadic powers, then spectral radius formula from242. Every element of C*(N) is normal. Character spectrum plus inverse permanence gives exactly the polynomial uniform norm, establishing representative independence before completion.
* Extension: uniform density and isometry give unique complete-limit construction; range closed plus dense polynomial image gives onto; norm continuity transfers algebra/star laws. Continuous spectral mapping uses invertibility of a scalar continuous function and the isomorphism, then inverse permanence.
* Models: L2 multiplication spectrum proven by reciprocal multiplier off the interval and localized approximate eigenvectors on it (including endpoints). Absolute value is continuous but not a restriction of a holomorphic function at0. Jump indicator is correctly deferred to Borel calculus. Nilpotent J distinguishes equal spectral point-values from derivatives in holomorphic calculus.

## Required earlier inputs, no future244 inputs

232 completeness/quotients;233 operator algebra and Neumann series;234 Zorn and normed dual basics;238 local complex-L2 Hilbert bridge;239 adjoints/orthogonality;242 nonempty complex operator spectrum and spectral radius formula;243 preceding contour calculus/Cauchy derivative formula only for the last nilpotent comparison. All are named dependencies, not asserted to have already passed this task. Inverse permanence, characters and uniform scalar approximation are proved inside the sample. The sample never uses244 spectral theorem, PVM, Borel calculus or later square-root construction.

## Handoff and residual scope

Refined file and minimal patch are new role-owned outputs; thickened input kept unchanged. Controller must verify input hash and merge exactly this file into the unique manuscript, updating source coverage locators. Next unique action: record representative-section calibration acceptance, continue B04 with these proof/detail standards and apply the shared B02 amended route. Whole243 integration/cross-references and source unnamed-item completeness remain later checks. No LaTeX build/PDF/full-page QA was performed here; content acceptance does not imply engineering or visual acceptance. Actual role model/mode remains unverified by this task. No user decision requested.
