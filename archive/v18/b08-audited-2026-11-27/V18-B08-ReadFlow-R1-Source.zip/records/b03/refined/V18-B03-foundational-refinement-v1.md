# V18 B-03 foundational calibration — independent refinement v1

2026-11-27 UTC. Input actually read independently before any historical review: `v18/records/b03/thickened/ch234-calibration-v1.tex`, 12621 bytes, SHA-256 `fa760ba747f47d0a5c8a88ec8991fd628223c89b17ccaddf4bc1c4fde99b7348`. Full two-section sample read in order, each definition/quantifier/proof and all four examples independently checked. Relevant fixed source text read: Conway III.6 printed78–81/PDF92–95; Brezis1.1 printed1–4/PDF16–19 and11.4 printed361–363/PDF376–378. Brezis closure warnings were previously visually checked at printed8–9/PDF23–24. No competing official manuscript made.

Decision: **PASS for representative-section mathematical refinement; no semantic patch required.** The source metadata comment was clarified to locate the complex extension supplement. This is B03 calibration, not whole234/B04, source-exhaustive B01, engineering/PDF or B07 whole-volume acceptance.

## Checks tied to the actual text

| Text location | Independent check | Result |
|---|---|---|
| Complex seminorm and complex extension theorem | Finite-valued seminorm; complex-linear subspace; real domination input. U(x)−iU(ix) is additive, real-homogeneous and commutes with i; extension values follow because im stays in M | Correct without completeness or closedness |
| Modulus bound | Phase lambda=conjugate(F(x))/abs(F(x)) treated only when F(x) nonzero; real-part domination evaluated at lambda*x; seminorm phase invariance removes artificial sqrt2 constant | Correct exact bound |
| Norm-preserving extension | Restriction gives reverse norm inequality; zero functional and zero space handled; real and complex cases kept separate | Correct |
| Norming theorem | One-dimensional representation unique for x nonzero; exact functional norm; x=0 maximum attained by zero functional, no impossible norm-one requirement in zero space | Correct |
| Nonunique functional example | Coefficients t,1−t have total modulus1; (1,1) gives equality and (1,0) distinguishes maps | Correct complex-linear example |
| Annihilator and distance preliminaries | Annihilator lives in X*, denoted M-circ distinct from Hilbert perpendicular. Continuity gives closure-invariance. Sequence argument is valid in norm metric | Correct; preserve notation consistently later |
| Quotient distance theorem | Quotient by closure(M), positive-distance case is nonzero coset; quotient norm needed but quotient completeness not needed. Norming theorem applied to quotient; pullback norm at most1; approximating sequence proves norm exactly1 | Correct for nonclosed M/incomplete X |
| Finite complex distance example | Triangle lower bound attained at midpoint; phase yields positive real f(x); displayed unit vector proves norm1 | Correct |
| Dense c00 warning | Sequence1/n belongs ell2; truncations show density/distance0; bounded functional vanishing on dense subset vanishes globally | Correct; ell2 source prerequisite232 |
| Fixed functional nonattainment | Weighted series absolutely converges; finite one-truncations approach1; at least one coordinate modulus strictly below1 gives strict estimate for every c0 unit-ball vector | Correct over R or C |
| Closed nonproximinal kernel | phi(u_N)=1/2; m_N lies in kernel; distances approach1/2; a putative minimizer would force a forbidden norm-attaining unit vector | Correct; explicitly shows functional maximum does not produce a nearest vector |
| Closure detection | One inclusion by continuity; reverse by positive quotient distance; density equivalence includes degenerate zero functional case | Correct; range-closure warning accurately anticipates later closed-range theorem |

## Required sequential inputs

232 normed spaces, c0/ell2, quotient norm and closure; earlier234 continuous dual norm and real dominated Hahn–Banach with Zorn proof. The sample explicitly states its real theorem input, rather than pretending to re-prove it. No weak topology, reflexivity, Hilbert adjoint or later chapter theorem is used. Shared dual notation X*, Banach transpose T' and Hilbert T* remain intact. Local annihilator M-circ should be adopted consistently by the parent or replaced globally before further dispatch; this is a notation integration point, not a defect in the proof.

## Handoff

New role output `ch234-calibration-v1.tex` plus minimal comment-only patch in this refined directory; input unchanged. Controller verifies baseline/hash, merges the same accepted mathematical text into unique main manuscript, updates section labels/source responsibility landing points, and records B03 calibration outcome. Both B03 samples have independent refinement evidence. No build/PDF/full-page QA performed here. Exact model/mode not independently verifiable. Whole-volume integration, all-source completeness and final mathematical acceptance remain their named later stages. No user decision required.
