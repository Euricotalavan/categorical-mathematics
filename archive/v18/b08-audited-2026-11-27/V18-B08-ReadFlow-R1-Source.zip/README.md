# Volume 18 — Functional Analysis and Bounded Operators

The English textbook covers Chapters 232–245 with the ReadFlow R1 template. It follows published Chapter 231 at commit `c27f36064ae039a23e03a7093684bfbf789179ef`. The mathematical body is `book/manuscript/ch232.tex` through `book/manuscript/ch245.tex`; its sole typesetting entry is `book/layout/study/v18.tex`.

`MANIFEST.json` identifies the approved source files, the exact paired PDF, and the independent B-07 review. Run `python verify.py` at the archive root to check their bytes and hashes. Then see `book/REBUILD.md` for the full XeLaTeX dependencies and Linux, Windows, and Prism instructions. The included fonts and typesetting components have accompanying notices.

From the archive root, build the book on a supported Linux TeX Live installation with:

```sh
cd book
python build.py --entry v18 --clean
```

The coverage ledger in `records/b08/COVERAGE.tsv` points to manuscript labels and line numbers. The source register and proof-review records are in `records/`. `records/b08/SOURCE-SCOPE.md` records the editions, source-reading limitations, and scope. Use `records/b08/HANDOFF.md` for the final stage status and resume information.
