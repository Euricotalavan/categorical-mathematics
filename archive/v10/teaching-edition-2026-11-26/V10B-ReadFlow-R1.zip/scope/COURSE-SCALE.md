# V10 — Proof Theory

課量先鎖；來源未簽核，不寫稿。id="V10"> V10 證明論 1 學期預估 · 8 章 逐卷正式定界待核 先備 數理邏輯 教完落點 完成核心演算的正規化／割消證明與算術應用。 預估 1 學期，48 接觸小時；其中新內容 36、例題 6、專題 3、評量 3 小時。課量為規劃估算。 章號 章名 印頁／預估課時 1 自然演繹與證明項 4.5 小時 2 序列演算 4.5 小時 3 正規化 4.5 小時 4 割消及其後果 4.5 小時 5 算術理論與表示 4.5 小時 6 不完備性 4.5 小時 7 一致性與相對一致性 4.5 小時 8 證明強度的標準例 4.5 小時

| 章 | 正文（每格 90 分） | 例題課 |
|---|---|---|
| 138 自然演繹與證明項 | formal rules with discharge and contexts ／ typed translation for a fixed fragment ／ a worked derivation and substitution lemma or counterexample | 45 分 |
| 139 序列演算 | antecedent and succedent and structural rules ／ translate one derivation with exact calculus ／ work through a permuted inference and compare classical/intuitionistic | 45 分 |
| 140 正規化 | detours and reductions in the chosen fragment ／ termination proof by a justified measure or computability argument ／ analyze normal forms and distinguish weak/strong normalization | 45 分 |
| 141 割消及其後果 | define rank and height, principal cases and permutations ／ prove selected fragment cut elimination with all inductive cases needed ／ trace a worked reduction and scope the subformula property | 45 分 |
| 142 算術理論與表示 | define the arithmetic language and chosen base ／ code finite syntax and proof predicates ／ show a selected representability lemma and distinguish meta/object statements | 45 分 |
| 143 不完備性 | diagonal lemma with explicit substitution ／ derive an incompleteness result with the exact consistency or soundness assumptions ／ distinguish second incompleteness, unprovable truth, and independence | 45 分 |
| 144 一致性與相對一致性 | separate consistency notions and coding ／ state and build a relative interpretation or conservative translation ／ compare an object-theory provability claim with the metatheoretic implication | 45 分 |
| 145 證明強度的標準例 | compare specified arithmetic fragments ／ define the selected ordinal or interpretation benchmark ／ illustrate what a bound measures and keep the full ordinal-analysis theorem outside scope unless actually justified | 45 分 |

合計 48 小時：正文 36、例題 6、整合專題 3、評量 3。先校準第 141 章。

- Every session maps to actual manuscript anchors with definitions and hypotheses, a teachable proof or construction with steps, worked reasoning, in-class check and answer. Proof and hour gates independent of PDF page count.
- One new step-by-step example and three graded practice exercises with full solutions per chapter.
- 2 sessions of 90 minutes; authentic problem, checkpoints, instructor solution and 100-point rubric.
- Question sheets and worked answer keys on separate pages; total 6 hours means two 120-minute sittings plus two 60-minute debriefs; total 3 hours means one 90-minute sitting and 90-minute debrief.
- B-01 primary-source decision before calibration. Calibrate one complete chapter, including teaching materials, before any full production.
- Pass exact scope, assigned chapter, mathematical source evidence, verified dependencies and approved notation to every job. Attach actual text, hash it, and stop if a required document is missing. Independent anchored math and depth audit sees full draft.
- Build and rasterize XeLaTeX PDF, verify manuscript counts and all hour plans, package exact source hashes, publish only when explicitly requested. Teaching hours remain planning estimates, not classroom measurements.

原參考卡書目候選（非原文證據）：
- Proof Theory
- Basic Proof Theory
- Structural Proof Theory
